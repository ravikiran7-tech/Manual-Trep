"""API tests for App+DB launch / progress / logs."""

from unittest.mock import patch

import json

import pytest

from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
from app.services.oracle_pg.app_db_change.report_packager import report_path
from tests.services.oracle_pg.app_db_change.run_helpers import (
    FINDINGS,
    KB,
    launch_and_complete,
    patch_app_db_workspace,
)

BASE = "/studio-ai-agents/api/app-db-transformation"


def _ws(monkeypatch, tmp_path):
    patch_app_db_workspace(monkeypatch, tmp_path)


def _inputs_dir(tmp_path, db_id="D1"):
    path = tmp_path / "ws" / "db-code-modernize" / db_id / "_claude"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _stage_default_inputs(tmp_path, db_id="D1"):
    inputs = _inputs_dir(tmp_path, db_id)
    import shutil

    shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
    shutil.copy(KB, inputs / "oracle-to-postgresql-rules_remediation.json")
    return inputs


def _no_background(coro, *args, **kwargs):
    coro.close()

    class _Task:
        cancelled = False

        def done(self):
            return False

        def add_done_callback(self, _cb):
            return None

    return _Task()


@pytest.mark.asyncio
async def test_launch_progress_logs_end_to_end(app_client, tmp_path, monkeypatch):
    tid, checkout, _ = await launch_and_complete(
        monkeypatch, tmp_path, app_id="A1", db_id="D1"
    )

    progress = app_client.get(f"{BASE}/{tid}/progress")
    assert progress.status_code == 200
    data = progress.json()
    assert data["overallStatus"] == "COMPLETED"
    assert data["currentMilestone"] == 5
    assert data["progressPercent"] == 100

    logs = app_client.get(f"{BASE}/{tid}/logs", params={"fromIndex": 0})
    assert logs.status_code == 200
    assert logs.json()["logs"]

    reports = tmp_path / "ws" / "db-code-modernize" / "D1" / "reports"
    nfs_report = reports / "post_transformation_report.json"
    assert nfs_report.exists()
    assert not (checkout / "post_transformation_report.json").exists()
    report = json.loads(nfs_report.read_text(encoding="utf-8"))
    assert report["transformationId"] == tid
    assert report["overallStatus"] == "COMPLETED"
    assert report_path(tid) == nfs_report

    by_app = app_client.post(f"{BASE}/internal/report", json={"appId": "A1", "dbId": "D1"})
    assert by_app.status_code == 200, by_app.text
    assert by_app.json()["transformationId"] == tid

    by_path = app_client.post(f"{BASE}/internal/report/path", json={"appId": "A1", "dbId": "D1"})
    assert by_path.status_code == 200
    assert by_path.json()["path"] == str(nfs_report)


def test_progress_not_found(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    r = app_client.get(f"{BASE}/DOES-NOT-EXIST/progress")
    assert r.status_code == 404


def test_launch_validation(app_client):
    r = app_client.post(f"{BASE}/launch", json={"appId": "x"})
    assert r.status_code == 400


def test_launch_rejects_missing_rules_remediation_file(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    inputs = _inputs_dir(tmp_path)
    import shutil

    shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
    body = {
        "appId": "A1",
        "dbId": "D1",
        "projectPath": str(tmp_path),
        "rulesRemediation": "does-not-exist.json",
    }
    r = app_client.post(f"{BASE}/launch", json=body)
    assert r.status_code == 400
    assert "rulesRemediation" in r.json()["detail"]["message"]


def test_launch_rejects_rules_remediation_outside_claude_dir(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    _stage_default_inputs(tmp_path)
    outside = tmp_path / "elsewhere.json"
    outside.write_text("{}", encoding="utf-8")
    body = {
        "appId": "A1",
        "dbId": "D1",
        "projectPath": str(tmp_path),
        "rulesRemediation": str(outside),
    }
    r = app_client.post(f"{BASE}/launch", json=body)
    assert r.status_code == 400
    message = r.json()["detail"]["message"]
    assert "rulesRemediation" in message
    assert "_claude" in message


def test_launch_defaults_to_the_conventional_input_files(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    _stage_default_inputs(tmp_path)
    nfs = tmp_path / "code"
    nfs.mkdir()
    body = {"appId": "A1", "dbId": "D1", "projectPath": str(nfs), "skipLlm": True}

    with patch("app.api.v1.app_db_transformation.asyncio.create_task", side_effect=_no_background):
        # job_manager also creates tasks — patch both.
        with patch(
            "app.services.oracle_pg.app_db_change.job_manager.asyncio.create_task",
            side_effect=_no_background,
        ):
            r = app_client.post(f"{BASE}/launch", json=body)
    assert r.status_code == 202, r.text
    assert r.json()["jobId"] == "A1"
    assert r.json()["transformationId"].startswith("APPDB-")


def test_launch_rejects_unsupported_project_type(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    _stage_default_inputs(tmp_path)
    body = {
        "appId": "A1",
        "dbId": "D1",
        "projectPath": str(tmp_path),
        "projectType": "dotnet",
    }
    r = app_client.post(f"{BASE}/launch", json=body)
    assert r.status_code == 400
    assert "projectType" in r.json()["detail"]["message"]


def test_unprefixed_path_not_registered(app_client):
    r = app_client.get("/api/app-db-transformation/DOES-NOT-EXIST/progress")
    assert r.status_code == 404


def test_report_not_found(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    r = app_client.post(f"{BASE}/internal/report", json={"appId": "no", "dbId": "no"})
    assert r.status_code == 404


def test_logs_stream_not_found(app_client):
    r = app_client.get(f"{BASE}/DOES-NOT-EXIST/logs/stream")
    assert r.status_code == 404


def test_logs_stream_route_registered():
    from app.api.v1.app_db_transformation import router

    paths = [getattr(route, "path", "") for route in router.routes]
    assert any("logs/stream" in path for path in paths)


@pytest.mark.asyncio
async def test_logs_stream_content_matches_db_job_shape(tmp_path, monkeypatch):
    from app.api.v1.app_db_transformation import _tail_sse_logs

    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    chunks = []
    async for chunk in _tail_sse_logs(tid):
        chunks.append(chunk)

    body = "".join(chunks)
    assert body.startswith("data: ")
    entries = [json.loads(c[len("data: ") :].strip()) for c in chunks]
    for entry in entries:
        assert {"timestamp", "phase", "icon", "message", "color", "seq", "jobId"} <= set(
            entry.keys()
        )
        assert entry["jobId"] == "A1"

    last = entries[-1]
    assert last["phase"] == "Completed"
    assert last["icon"] == "check"
