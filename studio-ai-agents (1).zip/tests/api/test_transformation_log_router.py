"""Tests for app/api/v1/transformation_log.py router."""
from unittest.mock import AsyncMock, MagicMock, patch

from app.models.transformation_log import ProcessTransformationLogResponse

BASE = "/studio-ai-agents/api/transformation-log"


def _payload():
    return {
        "analysisId": "a1",
        "operation": "cloudreadiness-analysis",
        "streamFilePath": "/stream.json",
        "outputLogPath": "/out.json",
    }


def _patch_service(service):
    return patch(
        "app.api.v1.transformation_log.get_transformation_log_service",
        return_value=service,
    )


def test_process_success(app_client):
    svc = MagicMock()
    svc.process_new_events = AsyncMock(
        return_value=ProcessTransformationLogResponse(
            status="success", message="ok", new_entries_count=2, total_entries_count=5
        )
    )
    with _patch_service(svc):
        r = app_client.post(f"{BASE}/process", json=_payload())
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "success"
    assert body["newEntriesCount"] == 2


def test_process_value_error_400(app_client):
    svc = MagicMock()
    svc.process_new_events = AsyncMock(side_effect=ValueError("path traversal"))
    with _patch_service(svc):
        r = app_client.post(f"{BASE}/process", json=_payload())
    assert r.status_code == 400
    assert r.json()["detail"]["message"] == "path traversal"


def test_process_file_not_found_400(app_client):
    svc = MagicMock()
    svc.process_new_events = AsyncMock(side_effect=FileNotFoundError("no file"))
    with _patch_service(svc):
        r = app_client.post(f"{BASE}/process", json=_payload())
    assert r.status_code == 400
    assert r.json()["detail"]["message"] == "no file"


def test_process_generic_exception_500(app_client):
    svc = MagicMock()
    svc.process_new_events = AsyncMock(side_effect=RuntimeError("boom"))
    with _patch_service(svc):
        r = app_client.post(f"{BASE}/process", json=_payload())
    assert r.status_code == 500
    assert "Internal processing error" in r.json()["detail"]["message"]


def test_process_missing_required_field_400(app_client):
    r = app_client.post(f"{BASE}/process", json={"analysisId": "a1"})
    assert r.status_code == 400