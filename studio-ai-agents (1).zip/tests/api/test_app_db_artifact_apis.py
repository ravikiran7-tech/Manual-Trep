"""Launch idempotency/concurrency, report caching & filtering, commit 410 APIs."""

from unittest.mock import patch

import pytest

from tests.services.oracle_pg.app_db_change.run_helpers import (
    FINDINGS,
    KB,
    launch_and_complete,
    patch_app_db_workspace,
)

BASE = "/studio-ai-agents/api/app-db-transformation"


def _ws(monkeypatch, tmp_path):
    patch_app_db_workspace(monkeypatch, tmp_path)


def _stage_inputs(tmp_path, db_id="D1"):
    import shutil

    inputs = tmp_path / "ws" / "db-code-modernize" / db_id / "_claude"
    inputs.mkdir(parents=True, exist_ok=True)
    shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
    shutil.copy(KB, inputs / "oracle-to-postgresql-rules_remediation.json")
    return inputs


def _checkout(root):
    root.mkdir(parents=True, exist_ok=True)
    return root


def _no_background(coro, *args, **kwargs):
    coro.close()

    class _Task:
        cancelled = False

        def done(self):
            return False

        def add_done_callback(self, _cb):
            return None

    return _Task()


def test_launch_is_idempotent_while_a_run_is_in_flight(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    nfs = _checkout(tmp_path / "code")
    _stage_inputs(tmp_path)
    body = {
        "appId": "A1",
        "dbId": "D1",
        "projectPath": str(nfs),
        "skipLlm": True,
    }

    with patch(
        "app.services.oracle_pg.app_db_change.job_manager.asyncio.create_task",
        side_effect=_no_background,
    ):
        first = app_client.post(f"{BASE}/launch", json=body)
        second = app_client.post(
            f"{BASE}/launch", json=body, headers={"Idempotency-Key": "abc-123"}
        )

    assert first.status_code == 202
    assert first.json()["jobId"] == "A1"
    assert first.json()["transformationId"].startswith("APPDB-")
    assert first.json().get("reused") is False or first.json()["status"] in {
        "QUEUED",
        "IN_PROGRESS",
    }
    assert second.status_code == 202
    assert second.json()["transformationId"] == first.json()["transformationId"]
    assert second.json()["jobId"] == "A1"
    assert second.json().get("reused") is True


def test_force_starts_a_parallel_run(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    nfs = _checkout(tmp_path / "code")
    _stage_inputs(tmp_path)
    body = {"appId": "A1", "dbId": "D1", "projectPath": str(nfs), "skipLlm": True}

    with patch(
        "app.services.oracle_pg.app_db_change.job_manager.asyncio.create_task",
        side_effect=_no_background,
    ):
        first = app_client.post(f"{BASE}/launch", json=body)
        forced = app_client.post(f"{BASE}/launch", json=body, params={"force": "true"})

    assert forced.status_code == 202
    assert forced.json().get("reused") is not True
    assert forced.json()["transformationId"] != first.json()["transformationId"]


def test_launch_rejected_when_concurrency_cap_reached(app_client, tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    nfs = _checkout(tmp_path / "code")
    _stage_inputs(tmp_path, "D1")
    _stage_inputs(tmp_path, "D2")
    monkeypatch.setattr(
        "app.api.v1.app_db_transformation.settings.app_db_job3",
        type(
            "_L",
            (),
            {
                "max_concurrent_jobs": 1,
                "reuse_in_flight_launch": True,
                "report_cache_max_age_seconds": 300,
                "zip_max_size_mb": 200,
            },
        )(),
    )
    body = {"appId": "A1", "dbId": "D1", "projectPath": str(nfs), "skipLlm": True}
    other = dict(body, appId="A2", dbId="D2")

    with patch(
        "app.services.oracle_pg.app_db_change.job_manager.asyncio.create_task",
        side_effect=_no_background,
    ):
        assert app_client.post(f"{BASE}/launch", json=body).status_code == 202
        capped = app_client.post(f"{BASE}/launch", json=other)

    assert capped.status_code == 429
    assert capped.headers["retry-after"] == "60"


@pytest.mark.asyncio
async def test_report_is_conditionally_cacheable(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    first = app_client.get(f"{BASE}/{tid}/report")
    assert first.status_code == 200
    etag = first.headers["etag"]
    assert etag
    assert "max-age" in first.headers["cache-control"]

    cached = app_client.get(f"{BASE}/{tid}/report", headers={"If-None-Match": etag})
    assert cached.status_code == 304


@pytest.mark.asyncio
async def test_report_filter_narrows_rules_and_files(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    full = app_client.get(f"{BASE}/{tid}/report").json()
    failed = app_client.get(f"{BASE}/{tid}/report", params={"filter": "failed"}).json()
    assert failed["filter"] == "failed"
    assert "rulesResults" in failed
    assert len(failed["rulesResults"]) <= len(full["rulesResults"])

    bad = app_client.get(f"{BASE}/{tid}/report", params={"filter": "nonsense"})
    assert bad.status_code == 400


@pytest.mark.asyncio
async def test_report_status_exposes_step_trace(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    body = app_client.get(f"{BASE}/{tid}/report/status").json()
    assert body["status"] == "COMPLETED"
    assert body["available"] is True
    assert body["fileSizeBytes"] > 0
    assert body["progressPercent"] == 100


@pytest.mark.asyncio
async def test_commit_routes_are_gone(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")
    assert app_client.get(f"{BASE}/{tid}/commit").status_code == 410
    assert app_client.post(f"{BASE}/{tid}/commit/retry", json={}).status_code == 410
    assert (
        app_client.post(
            f"{BASE}/{tid}/commit-result",
            json={"status": "COMPLETED", "commitHash": "abc"},
        ).status_code
        == 410
    )
