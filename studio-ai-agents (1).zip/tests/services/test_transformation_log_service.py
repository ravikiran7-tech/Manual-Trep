"""Tests for app.services.transformation_log_service."""
import json
from unittest.mock import AsyncMock, MagicMock

import pytest

import app.services.transformation_log_service as tls_mod
from app.services.transformation_log_service import (
    TransformationLogService,
    get_transformation_log_service,
    ALLOWED_ICONS,
    DEFAULT_ICON,
)
from app.models.transformation_log import (
    ProcessTransformationLogRequest,
    TransformationLogFile,
)
from app.core.config import get_settings


WORKSPACE = get_settings().workspace.base_path


@pytest.fixture
def provider():
    """Mock provider whose invoke_with_tools_agentic returns raw responses."""
    p = MagicMock()
    p.invoke_with_tools_agentic = AsyncMock(return_value=[])
    return p


@pytest.fixture
def provider_factory(provider):
    pf = MagicMock()
    pf.get_provider = AsyncMock(return_value=provider)
    return pf


@pytest.fixture
def service(provider_factory):
    return TransformationLogService(provider_factory)


@pytest.fixture
def ws_paths(tmp_path, monkeypatch):
    """Make the configured workspace base path point at tmp_path so the
    SecurityValidator path checks pass for files created under tmp_path."""
    fake_settings = MagicMock()
    fake_settings.workspace.base_path = str(tmp_path)
    monkeypatch.setattr(tls_mod, "get_settings", lambda: fake_settings)
    stream = tmp_path / "stream.json"
    out = tmp_path / "out" / "log.json"
    return stream, out


def _make_request(stream, out, **kw):
    return ProcessTransformationLogRequest(
        analysisId=kw.get("analysis_id", "abc123"),
        operation=kw.get("operation", "cloudreadiness-analysis"),
        streamFilePath=str(stream),
        outputLogPath=str(out),
        transformationType=kw.get("transformation_type", "cloudreadiness"),
    )


def _llm_anthropic(text):
    return [{"content": [{"type": "text", "text": text}]}]


# ---------------------------------------------------------------------------
# process_new_events
# ---------------------------------------------------------------------------
async def test_process_success(service, provider, ws_paths):
    stream, out = ws_paths
    stream.write_text(json.dumps([{"type": "system", "subtype": "init"}]), encoding="utf-8")

    entries = [{"timestamp": "10:00:00", "phase": "init", "icon": "play", "message": "Started"}]
    provider.invoke_with_tools_agentic.return_value = _llm_anthropic(json.dumps(entries))

    resp = await service.process_new_events(_make_request(stream, out))

    assert resp.status == "success"
    assert resp.new_entries_count == 1
    assert resp.last_processed_event_index == 1
    assert out.exists()
    written = json.loads(out.read_text(encoding="utf-8"))
    assert written["logs"][0]["color"] == ALLOWED_ICONS["play"]


async def test_process_no_new_events(service, provider, ws_paths):
    stream, out = ws_paths
    stream.write_text(json.dumps([{"type": "system"}]), encoding="utf-8")
    # Pre-existing log already processed the single event
    existing = TransformationLogFile(
        analysisId="abc123", operation="cloudreadiness-analysis",
        status="in_progress", lastProcessedEventIndex=1, logs=[],
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(existing.model_dump_json(by_alias=True), encoding="utf-8")

    resp = await service.process_new_events(_make_request(stream, out))
    assert resp.status == "no_new_events"
    assert resp.new_entries_count == 0
    provider.invoke_with_tools_agentic.assert_not_called()


async def test_process_completion_sets_completed(service, provider, ws_paths):
    stream, out = ws_paths
    events = [{"type": "result", "stop_reason": "end_turn"}]
    stream.write_text(json.dumps(events), encoding="utf-8")
    provider.invoke_with_tools_agentic.return_value = _llm_anthropic("[]")

    resp = await service.process_new_events(_make_request(stream, out))
    assert resp.status == "success"
    assert resp.log_file_status == "completed"
    assert resp.has_more_events is False


async def test_process_has_more_events(service, provider, ws_paths):
    stream, out = ws_paths
    service.max_events_per_chunk = 2
    events = [{"type": "x", "i": i} for i in range(5)]
    stream.write_text(json.dumps(events), encoding="utf-8")
    provider.invoke_with_tools_agentic.return_value = _llm_anthropic("[]")

    resp = await service.process_new_events(_make_request(stream, out))
    assert resp.has_more_events is True
    assert resp.last_processed_event_index == 2
    assert resp.total_stream_events == 5


# ---------------------------------------------------------------------------
# _read_log_file
# ---------------------------------------------------------------------------
def test_read_log_file_missing_creates_new(service, tmp_path):
    req = _make_request(tmp_path / "s.json", tmp_path / "o.json")
    lf = service._read_log_file(str(tmp_path / "nope.json"), req)
    assert lf.status == "in_progress"
    assert lf.analysis_id == "abc123"
    assert lf.logs == []


def test_read_log_file_existing(service, tmp_path):
    existing = TransformationLogFile(
        analysisId="abc123", operation="op", status="in_progress",
        lastProcessedEventIndex=3, logs=[],
    )
    p = tmp_path / "log.json"
    p.write_text(existing.model_dump_json(by_alias=True), encoding="utf-8")
    req = _make_request(tmp_path / "s.json", p)
    lf = service._read_log_file(str(p), req)
    assert lf.last_processed_event_index == 3


def test_read_log_file_corrupt_falls_back(service, tmp_path):
    p = tmp_path / "log.json"
    p.write_text("{ not valid json", encoding="utf-8")
    req = _make_request(tmp_path / "s.json", p)
    lf = service._read_log_file(str(p), req)
    assert lf.status == "in_progress"
    assert lf.logs == []


# ---------------------------------------------------------------------------
# _read_stream_events
# ---------------------------------------------------------------------------
def test_read_stream_events_missing(service, tmp_path):
    assert service._read_stream_events(str(tmp_path / "nope.json")) == []


def test_read_stream_events_empty(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text("   ", encoding="utf-8")
    assert service._read_stream_events(str(p)) == []


def test_read_stream_events_array(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text(json.dumps([{"a": 1}, {"b": 2}]), encoding="utf-8")
    assert len(service._read_stream_events(str(p))) == 2


def test_read_stream_events_incomplete_array(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text('[\n{"a": 1},\n{"b": 2}', encoding="utf-8")  # no closing bracket
    events = service._read_stream_events(str(p))
    assert len(events) == 2


def test_read_stream_events_object_with_events_key(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text(json.dumps({"events": [{"a": 1}]}), encoding="utf-8")
    assert service._read_stream_events(str(p)) == [{"a": 1}]


def test_read_stream_events_single_object(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text(json.dumps({"type": "x"}), encoding="utf-8")
    assert service._read_stream_events(str(p)) == [{"type": "x"}]


def test_read_stream_events_non_container(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text("123", encoding="utf-8")  # valid JSON but not list/dict
    assert service._read_stream_events(str(p)) == []


def test_read_stream_events_invalid_json(service, tmp_path):
    p = tmp_path / "s.json"
    p.write_text("{bad json,,,", encoding="utf-8")  # starts with { so no bracket fix
    assert service._read_stream_events(str(p)) == []


# ---------------------------------------------------------------------------
# _trim_events
# ---------------------------------------------------------------------------
def test_trim_events_truncates_long_text(service):
    long = "x" * 600
    out = service._trim_events([{"text": long, "other": 1}])
    assert "truncated" in out[0]["text"]
    assert len(out[0]["text"]) < 600


def test_trim_events_keeps_short_and_nonstr(service):
    out = service._trim_events([{"text": "short", "content": 123}])
    assert out[0]["text"] == "short"
    assert out[0]["content"] == 123


# ---------------------------------------------------------------------------
# _build_prompt
# ---------------------------------------------------------------------------
def test_build_prompt(service):
    sys_p, user_p = service._build_prompt([{"type": "x"}], "cloudreadiness")
    assert "cloudreadiness" in sys_p
    assert "Stream events to process" in user_p


# ---------------------------------------------------------------------------
# _call_llm — extracts across all 3 formats
# ---------------------------------------------------------------------------
async def test_call_llm_anthropic_format(service, provider):
    provider.invoke_with_tools_agentic.return_value = _llm_anthropic("hello")
    out = await service._call_llm("sys", "usr")
    assert out == "hello"


async def test_call_llm_bedrock_format(service, provider):
    provider.invoke_with_tools_agentic.return_value = [
        {"output": {"message": {"content": [{"text": "bed"}]}}}
    ]
    out = await service._call_llm("sys", "usr")
    assert out == "bed"


async def test_call_llm_openai_string_content(service, provider):
    provider.invoke_with_tools_agentic.return_value = [
        {"choices": [{"message": {"content": "azure-str"}}]}
    ]
    out = await service._call_llm("sys", "usr")
    assert out == "azure-str"


async def test_call_llm_openai_list_content(service, provider):
    provider.invoke_with_tools_agentic.return_value = [
        {"choices": [{"message": {"content": [{"text": "azure-list"}]}}]}
    ]
    out = await service._call_llm("sys", "usr")
    assert out == "azure-list"


async def test_call_llm_openai_malformed_choices_skipped(service, provider):
    provider.invoke_with_tools_agentic.return_value = [
        {"choices": ["not-a-dict", {"message": "not-a-dict"}, {}]}
    ]
    out = await service._call_llm("sys", "usr")
    assert out == ""


async def test_call_llm_empty(service, provider):
    provider.invoke_with_tools_agentic.return_value = [{}]
    out = await service._call_llm("sys", "usr")
    assert out == ""


async def test_call_llm_non_text_blocks_and_non_dict_output(service, provider):
    # content block that is not a text-type dict (305->304),
    # output present but not a dict (310->317),
    # bedrock message content block without "text" (313->312)
    provider.invoke_with_tools_agentic.return_value = [
        {
            "content": [{"type": "image"}, "not-a-dict"],
            "output": "string-not-dict",
        },
        {
            "output": {"message": {"content": [{"no_text": 1}]}},
        },
    ]
    out = await service._call_llm("sys", "usr")
    assert out == ""


async def test_call_llm_openai_list_block_without_text(service, provider):
    # 328->327: list content block that lacks "text"
    provider.invoke_with_tools_agentic.return_value = [
        {"choices": [{"message": {"content": [{"no_text": 1}, "x"]}}]}
    ]
    out = await service._call_llm("sys", "usr")
    assert out == ""


# ---------------------------------------------------------------------------
# _parse_llm_response
# ---------------------------------------------------------------------------
def test_parse_response_empty(service):
    assert service._parse_llm_response("") == []


def test_parse_response_plain_array(service):
    txt = json.dumps([{"timestamp": "1", "phase": "p", "icon": "code", "message": "m"}])
    entries = service._parse_llm_response(txt)
    assert len(entries) == 1
    assert entries[0].color == ALLOWED_ICONS["code"]


def test_parse_response_fenced_block(service):
    txt = "Here:\n```json\n[{\"icon\": \"check\", \"message\": \"done\"}]\n```\nthanks"
    entries = service._parse_llm_response(txt)
    assert len(entries) == 1
    assert entries[0].icon == "check"


def test_parse_response_unknown_icon_defaults(service):
    txt = json.dumps([{"icon": "nonexistent", "message": "m"}])
    entries = service._parse_llm_response(txt)
    assert entries[0].icon == DEFAULT_ICON


def test_parse_response_invalid_json(service):
    assert service._parse_llm_response("[ not json") == []


def test_parse_response_not_array(service):
    assert service._parse_llm_response('{"foo": "bar"}') == []


def test_parse_response_skips_bad_item(service):
    # an item that is not a dict triggers .get AttributeError -> skipped
    txt = json.dumps([{"icon": "play", "message": "ok"}, "notadict"])
    entries = service._parse_llm_response(txt)
    assert len(entries) == 1


def test_parse_response_no_brackets(service):
    # find("[") == -1 path, json.loads fails
    assert service._parse_llm_response("just some text") == []


# ---------------------------------------------------------------------------
# _detect_completion
# ---------------------------------------------------------------------------
def test_detect_completion_empty(service):
    assert service._detect_completion([]) is False


def test_detect_completion_result_end_turn(service):
    assert service._detect_completion([{"type": "result", "stop_reason": "end_turn"}]) is True


def test_detect_completion_message_stop_camel(service):
    assert service._detect_completion([{"type": "message_stop", "stopReason": "end_turn"}]) is True


def test_detect_completion_no_signal(service):
    assert service._detect_completion([{"type": "result", "stop_reason": "max_tokens"}]) is False


def test_detect_completion_other_events(service):
    assert service._detect_completion([{"type": "assistant"}]) is False


def test_detect_completion_message_stop_no_end_turn(service):
    # message_stop present but stop_reason not end_turn -> loop continues (415->406)
    assert service._detect_completion([{"type": "message_stop", "stop_reason": "pause"}]) is False


# ---------------------------------------------------------------------------
# _write_log_file
# ---------------------------------------------------------------------------
def test_write_log_file_creates_dirs(service, tmp_path):
    lf = TransformationLogFile(analysisId="a", operation="o", logs=[])
    target = tmp_path / "nested" / "deep" / "log.json"
    service._write_log_file(str(target), lf)
    assert target.exists()


# ---------------------------------------------------------------------------
# singleton
# ---------------------------------------------------------------------------
def test_get_service_singleton(monkeypatch):
    tls_mod._service_instance = None
    a = get_transformation_log_service()
    b = get_transformation_log_service()
    assert a is b
    assert isinstance(a, TransformationLogService)
