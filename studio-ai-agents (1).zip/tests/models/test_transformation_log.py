"""Tests for app.models.transformation_log."""
from app.models.transformation_log import (
    ProcessTransformationLogRequest,
    ProcessTransformationLogResponse,
    TransformationLogEntry,
    TransformationLogFile,
)


def test_process_request_by_alias():
    req = ProcessTransformationLogRequest(
        analysisId="A-1",
        operation="cloudreadiness-analysis",
        streamFilePath="/tmp/stream.json",
        outputLogPath="/tmp/out.json",
    )
    assert req.analysis_id == "A-1"
    assert req.operation == "cloudreadiness-analysis"
    assert req.stream_file_path == "/tmp/stream.json"
    assert req.output_log_path == "/tmp/out.json"
    # default
    assert req.transformation_type == "cloudreadiness"


def test_process_request_by_field_name_and_override_type():
    req = ProcessTransformationLogRequest(
        analysis_id="A-2",
        operation="cloudreadiness-fix",
        stream_file_path="/s",
        output_log_path="/o",
        transformation_type="dbmodernize",
    )
    assert req.analysis_id == "A-2"
    assert req.transformation_type == "dbmodernize"


def test_process_request_serialize_by_alias():
    req = ProcessTransformationLogRequest(
        analysisId="A-1",
        operation="op",
        streamFilePath="/s",
        outputLogPath="/o",
    )
    dumped = req.model_dump(by_alias=True)
    assert dumped["analysisId"] == "A-1"
    assert dumped["streamFilePath"] == "/s"
    assert dumped["outputLogPath"] == "/o"
    assert dumped["transformationType"] == "cloudreadiness"


def test_process_response_defaults():
    resp = ProcessTransformationLogResponse(status="success", message="ok")
    assert resp.new_entries_count == 0
    assert resp.total_entries_count == 0
    assert resp.last_processed_event_index == 0
    assert resp.total_stream_events == 0
    assert resp.has_more_events is False
    assert resp.log_file_status == "in_progress"


def test_process_response_by_alias():
    resp = ProcessTransformationLogResponse(
        status="success",
        message="done",
        newEntriesCount=3,
        totalEntriesCount=10,
        lastProcessedEventIndex=9,
        totalStreamEvents=12,
        hasMoreEvents=True,
        logFileStatus="completed",
    )
    assert resp.new_entries_count == 3
    assert resp.total_entries_count == 10
    assert resp.last_processed_event_index == 9
    assert resp.total_stream_events == 12
    assert resp.has_more_events is True
    assert resp.log_file_status == "completed"
    dumped = resp.model_dump(by_alias=True)
    assert dumped["hasMoreEvents"] is True


def test_log_entry():
    entry = TransformationLogEntry(
        timestamp="12:00:00",
        phase="initialization",
        icon="play",
        message="started",
        color="#4CAF50",
    )
    assert entry.timestamp == "12:00:00"
    assert entry.phase == "initialization"
    assert entry.icon == "play"
    assert entry.message == "started"
    assert entry.color == "#4CAF50"


def test_log_file_defaults_empty_logs():
    lf = TransformationLogFile(analysisId="A-1", operation="op")
    assert lf.analysis_id == "A-1"
    assert lf.operation == "op"
    assert lf.status == "in_progress"
    assert lf.last_processed_event_index == 0
    assert lf.last_updated_at == ""
    assert lf.logs == []


def test_log_file_with_entries_and_alias_dump():
    entry = TransformationLogEntry(
        timestamp="12:00:00", phase="p", icon="i", message="m", color="#000"
    )
    lf = TransformationLogFile(
        analysis_id="A-2",
        operation="op",
        status="completed",
        last_processed_event_index=5,
        last_updated_at="2026-06-19",
        logs=[entry],
    )
    assert len(lf.logs) == 1
    dumped = lf.model_dump(by_alias=True)
    assert dumped["analysisId"] == "A-2"
    assert dumped["lastProcessedEventIndex"] == 5
    assert dumped["lastUpdatedAt"] == "2026-06-19"
    assert dumped["logs"][0]["timestamp"] == "12:00:00"
