"""
Studio AI Engine - Python Implementation
FastAPI application entry point.

Replaces Java Spring Boot application with Python/FastAPI + AWS Bedrock.
"""
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Dict, Any

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.core.config import get_settings
from app.core.resilience import rate_limiter
from app.core.exceptions import (
    StudioAIEngineException,
    ValidationError,
    AuthenticationError,
    ProviderError,
    OperationTimeoutError,
    CircuitBreakerError
)

# Registers the orchestrator provider stack when LLM_USE_ORCHESTRATOR=true.
# No-op when the flag is unset; legacy ProviderFactory stays active.
import app.services.llm  # noqa: E402, F401


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Get settings
settings = get_settings()
nats_schema_generate_service = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.
    Handles startup and shutdown events with configuration validation
    and graceful resource cleanup.
    """
    # ========================================================================
    # STARTUP - Configuration Validation and Resource Initialization
    # ========================================================================
    logger.info("=" * 80)
    logger.info("Studio AI Engine - Python Implementation Starting")
    logger.info("=" * 80)

    try:
        # Validate critical configuration
        await validate_configuration()

        # Create required directories
        await initialize_workspace()

        # Initialize resources (HTTP clients, etc.)
        await initialize_resources()
        await initialize_nats_subscriber()
        await initialize_oracle_pg_jobs()

        logger.info(f"Application: {settings.app_name}")
        logger.info(f"Version: {settings.app_version}")
        logger.info(f"AWS Region: {settings.bedrock.region}")
        logger.info(f"Model: {settings.bedrock.default_model}")
        logger.info(f"Workspace: {settings.workspace.base_path}")
        logger.info("=" * 80)
        logger.info("✓ Application startup complete")
        logger.info("=" * 80)

    except Exception as e:
        logger.critical(f"✗ Application startup failed: {str(e)}", exc_info=True)
        raise

    yield

    # ========================================================================
    # SHUTDOWN - Graceful Resource Cleanup
    # ========================================================================
    logger.info("=" * 80)
    logger.info("Studio AI Engine shutting down gracefully...")
    logger.info("=" * 80)

    try:
        await cleanup_resources()
        logger.info("✓ Graceful shutdown complete")
    except Exception as e:
        logger.error(f"✗ Error during shutdown: {str(e)}", exc_info=True)

    logger.info("=" * 80)


async def validate_configuration():
    """
    Validate critical configuration on startup.
    Fails fast if configuration is invalid.

    Raises:
        ConfigurationError: If configuration is invalid
    """
    from app.core.exceptions import ConfigurationError
    from app.utils.encryption import EncryptionUtils
    import boto3

    logger.info("Validating configuration...")

    # Validate required settings
    if not settings.studio_core or not settings.studio_core.base_url:
        raise ConfigurationError(
            message="STUDIO_CORE_URL is not configured",
            details="Set STUDIO_CORE_URL environment variable"
        )

    if not settings.encryption_key:
        raise ConfigurationError(
            message="ENCRYPTION_KEY is not configured",
            details="Set ENCRYPTION_KEY environment variable"
        )

    if settings.nats.enabled and not settings.debug:
        if not (settings.enc_passphrase or "").strip():
            raise ConfigurationError(
                message="ENC_PASSPHRASE is not configured",
                details=(
                    "Set ENC_PASSPHRASE when NATS_ENABLED=true in non-debug environments, "
                    "or set NATS_ENABLED=false / DEBUG=true for local dev without encrypted NATS creds"
                ),
            )
        logger.info("  ✓ ENC_PASSPHRASE configured")

    # Validate encryption key format
    try:
        EncryptionUtils()
        logger.info("  ✓ Encryption key validated")
    except Exception as e:
        raise ConfigurationError(
            message="Invalid encryption key format",
            details=f"Encryption key must be valid base64: {str(e)}"
        )

    # Validate AWS credentials (allow IAM role fallback)
    try:
        session = boto3.Session(
            profile_name=settings.bedrock.profile if settings.bedrock.profile != "default" else None,
            region_name=settings.bedrock.region
        )
        # Test that credentials exist (doesn't make API call)
        credentials = session.get_credentials()
        if credentials is None:
            logger.warning("  ⚠ No AWS credentials found - will rely on IAM role or environment variables")
        else:
            logger.info(f"  ✓ AWS credentials validated")
    except Exception as e:
        # Don't fail on AWS credential validation - allow IAM role fallback
        logger.warning(f"  ⚠ AWS credential check skipped: {str(e)}")
        logger.info("  → Application will attempt to use IAM role or environment variables")

    # Validate workspace path exists and is writable
    workspace_path = Path(settings.workspace.base_path)

    try:
        workspace_path.mkdir(parents=True, exist_ok=True)
        # Unique per worker to avoid multi-process race on shared volumes (EFS).
        test_file = workspace_path / f".write_test.{os.getpid()}"
        test_file.touch()
        test_file.unlink(missing_ok=True)
        logger.info(f"  ✓ Workspace directory writable: {workspace_path}")
    except Exception as e:
        raise ConfigurationError(
            message="Workspace directory not writable",
            details=f"Path: {workspace_path}, Error: {str(e)}"
        )

    logger.info("✓ Configuration validation complete")


async def initialize_resources():
    """
    Initialize application resources (HTTP clients, etc.).
    """
    logger.info("Initializing resources...")

    # Resources are lazily initialized on first use
    # This just logs that we're ready
    logger.info("  ✓ Resources initialized (lazy loading enabled)")


async def initialize_oracle_pg_jobs():
    """Resume queued and in-progress Oracle PG transformation jobs when enabled."""
    if not settings.oracle_pg_agent.enabled or not settings.oracle_pg_agent.resume_on_startup:
        logger.info("Oracle PG job resume on startup disabled")
        return

    from app.services.oracle_pg.job_manager import get_job_manager

    manager = get_job_manager()
    resumed = await manager.resume_in_progress_jobs()
    if resumed:
        logger.info("  ✓ Resumed %s Oracle PG transformation job(s)", resumed)

    from app.services.oracle_pg.app_db_change.job_manager import get_app_db_job_manager

    app_db_manager = get_app_db_job_manager()
    app_db_resumed = await app_db_manager.resume_in_progress_jobs()
    if app_db_resumed:
        logger.info("  ✓ Resumed %s App+DB transformation job(s)", app_db_resumed)


async def initialize_nats_subscriber():
    """Start NATS subscriber for schema generation when enabled."""
    global nats_schema_generate_service
    if not settings.nats.enabled:
        logger.info("NATS schema-generation subscriber disabled")
        return

    from app.services.nats_schema_generate_service import NatsSchemaGenerateService

    nats_schema_generate_service = NatsSchemaGenerateService()
    await nats_schema_generate_service.start()
    logger.info("  ✓ NATS schema-generation subscriber started")


async def cleanup_resources():
    """
    Cleanup application resources on shutdown.
    Closes HTTP clients, flushes pending operations, resets circuit breakers.
    """
    logger.info("Cleaning up resources...")

    # Stop NATS subscriber/publisher
    try:
        if nats_schema_generate_service:
            await nats_schema_generate_service.stop()
            logger.info("  ✓ NATS schema-generation subscriber stopped")
    except Exception as e:
        logger.error(f"  ✗ Error stopping NATS subscriber: {e}")

    # Cleanup HTTP clients
    try:
        from app.clients.compass_client import cleanup_compass_client
        await cleanup_compass_client()
        logger.info("  ✓ Compass client closed")
    except Exception as e:
        logger.error(f"  ✗ Error closing Compass client: {e}")

    # Reset circuit breakers
    try:
        from app.core.resilience import reset_all_circuit_breakers
        reset_all_circuit_breakers()
        logger.info("  ✓ Circuit breakers reset")
    except Exception as e:
        logger.error(f"  ✗ Error resetting circuit breakers: {e}")

    logger.info("✓ Resource cleanup complete")


async def initialize_workspace():
    """
    Initialize workspace directory structure.
    Creates base folders similar to Java's ApplicationConfig.
    """
    try:
        base_path = Path(settings.workspace.base_path)

        # Create workspace directories (all outputs go to workspace)
        directories = [
            base_path,
            base_path / "versionUpgrade",
            base_path / "validation",
            base_path / "cloudreadiness",
            base_path / "db-code-modernize",
            base_path / "schema-modernization",
            base_path / "containerization",
            base_path / "dotnet-validation"
        ]

        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            logger.info(f"Ensured directory exists: {directory}")

        logger.info("Workspace initialization complete")

    except Exception as e:
        logger.error(f"Failed to initialize workspace: {str(e)}", exc_info=True)
        raise


# Create FastAPI application with context path
app = FastAPI(
    title="Studio AI Engine - Python",
    description="Python implementation of Studio AI Engine using AWS Bedrock API",
    version=settings.app_version,
    docs_url="/studio-ai-agents/docs",  # Swagger UI with context path
    redoc_url="/studio-ai-agents/redoc",
    openapi_url="/studio-ai-agents/openapi.json",  # OpenAPI schema with context path
    lifespan=lifespan
)

# Add rate limiter state
app.state.limiter = rate_limiter

# Add rate limit exceeded handler
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


# ============================================================================
# CORS MIDDLEWARE
# ============================================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allow_origins,
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=settings.cors_allow_methods,
    allow_headers=settings.cors_allow_headers,
    max_age=3600
)


# ============================================================================
# EXCEPTION HANDLERS
# ============================================================================

@app.exception_handler(StudioAIEngineException)
async def studio_exception_handler(request: Request, exc: StudioAIEngineException):
    """Handle custom Studio AI Engine exceptions."""
    logger.error(f"Studio exception: {exc.message}", exc_info=True)

    # Determine status code based on exception type
    if isinstance(exc, ValidationError):
        status_code = status.HTTP_400_BAD_REQUEST
    elif isinstance(exc, AuthenticationError):
        status_code = status.HTTP_401_UNAUTHORIZED
    elif isinstance(exc, ProviderError):
        status_code = status.HTTP_502_BAD_GATEWAY
    elif isinstance(exc, OperationTimeoutError):
        status_code = status.HTTP_504_GATEWAY_TIMEOUT
    elif isinstance(exc, CircuitBreakerError):
        status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    else:
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR

    return JSONResponse(
        status_code=status_code,
        content={
            "status": "error",
            "message": exc.message,
            "details": exc.details,
            "error_type": exc.__class__.__name__
        }
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle FastAPI validation errors."""
    logger.error(f"Validation error: {exc.errors()}")

    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "status": "error",
            "message": "Request validation failed",
            "details": exc.errors()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Handle unexpected exceptions.
    Logs full error internally but returns sanitized response to client.
    """
    import uuid

    # Generate unique error ID for tracking
    error_id = str(uuid.uuid4())

    # Log full error with traceback for internal debugging
    logger.error(
        f"Unexpected error [ID: {error_id}]: {str(exc)}",
        exc_info=True,
        extra={"error_id": error_id, "path": request.url.path}
    )

    # Return sanitized error to client (no stack trace in production)
    response_content = {
        "status": "error",
        "message": "An unexpected error occurred",
        "error_id": error_id  # For support tracking
    }

    # Only include exception details in debug mode
    if settings.debug:
        response_content["details"] = str(exc)
        response_content["type"] = exc.__class__.__name__
    else:
        response_content["support_message"] = (
            f"Please contact support with error ID: {error_id}"
        )

    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=response_content
    )


# ============================================================================
# ROOT ENDPOINTS (WITH CONTEXT PATH)
# ============================================================================

@app.get("/studio-ai-agents/", tags=["root"])
async def root() -> Dict[str, Any]:
    """Root endpoint - API information."""
    return {
        "service": "Studio AI Engine - Python",
        "version": settings.app_version,
        "status": "running",
        "provider": "AWS Bedrock",
        "model": settings.bedrock.default_model,
        "documentation": "/studio-ai-agents/docs"
    }


#@app.get("/studio-ai-agents/health", tags=["health"])
@app.api_route("/studio-ai-agents/health", methods=["GET", "HEAD"], tags=["health"])
async def health_check() -> Dict[str, Any]:
    """
    Health check endpoint.
    Verifies application is running and responsive.
    """
    from app.core.resilience import get_resilience_health

    resilience_health = get_resilience_health()

    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "resilience": resilience_health
    }


# Keep original /health endpoint for container health checks (no context path)
#@app.get("/health", tags=["health"], include_in_schema=False)
@app.api_route("/health", methods=["GET", "HEAD"], tags=["health"], include_in_schema=False)
async def health_check_legacy() -> Dict[str, Any]:
    """
    Legacy health check endpoint (without context path).
    Used by Docker healthcheck and ALB health checks.
    """
    from app.core.resilience import get_resilience_health

    resilience_health = get_resilience_health()

    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "resilience": resilience_health
    }


# ============================================================================
# IMPORT AND INCLUDE ROUTERS (WITH CONTEXT PATH)
# ============================================================================

# Import routers - Include implemented routers with /studio-ai-agents prefix
try:
    from app.api.v1 import claude
    app.include_router(claude.router, prefix="/studio-ai-agents")
    logger.info("Claude API router registered successfully at /studio-ai-agents/api/claude")
except ImportError as e:
    logger.warning(f"Claude router not available: {str(e)}")

try:
    from app.api.v1 import stream_visualization
    app.include_router(stream_visualization.router, prefix="/studio-ai-agents")
    logger.info("Stream visualization router registered successfully at /studio-ai-agents/api/stream")
except ImportError as e:
    logger.warning(f"Stream visualization router not available: {str(e)}")

# Build compilation and DotNet routers will be added in next phase
try:
    from app.api.v1 import build_compilation
    app.include_router(build_compilation.router, prefix="/studio-ai-agents")
    logger.info("Build compilation router registered successfully")
except ImportError as e:
    logger.warning(f"Build compilation router not yet implemented: {str(e)}")

try:
    from app.api.v1 import dotnet_build
    app.include_router(dotnet_build.router, prefix="/studio-ai-agents")
    logger.info("DotNet build router registered successfully")
except ImportError as e:
    logger.warning(f"DotNet build router not yet implemented: {str(e)}")

try:
    from app.api.v1 import transformation_log
    app.include_router(transformation_log.router, prefix="/studio-ai-agents")
    logger.info("Transformation log router registered successfully at /studio-ai-agents/api/transformation-log")
except ImportError as e:
    logger.warning(f"Transformation log router not available: {str(e)}")

try:
    from app.api.v1 import oracle_pg_transformation
    app.include_router(oracle_pg_transformation.router, prefix="/studio-ai-agents")
    logger.info(
        "Oracle PG transformation router registered at /studio-ai-agents/api/oracle-pg-transformation"
    )
except ImportError as e:
    logger.warning(f"Oracle PG transformation router not available: {str(e)}")

try:
    from app.api.v1 import app_db_transformation
    app.include_router(app_db_transformation.router, prefix="/studio-ai-agents")
    logger.info(
        "App+DB transformation router registered at /studio-ai-agents/api/app-db-transformation"
    )
except ImportError as e:
    logger.warning(f"App+DB transformation router not available: {str(e)}")

try:
    from app.api.v1 import llm_config_validation
    app.include_router(llm_config_validation.router, prefix="/studio-ai-agents")
    logger.info("LLM config validation router registered successfully at /studio-ai-agents/api/v1/llm")
except ImportError as e:
    logger.warning(f"LLM config validation router not available: {str(e)}")


# ============================================================================
# APPLICATION INFO
# ============================================================================

if __name__ == "__main__":
    import uvicorn

    # Run with uvicorn
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=settings.debug,
        log_level="info"
    )
