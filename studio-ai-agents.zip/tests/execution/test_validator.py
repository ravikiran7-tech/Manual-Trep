"""Tests for app.execution.validator.CompilerValidator."""
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from app.execution.validator import CompilerValidator
from app.state.models import ModuleNode


def _module(tmp_path, name="mod"):
    return ModuleNode(name=name, path=str(tmp_path))


# --------------------------------------------------------------------------
# validate_maven
# --------------------------------------------------------------------------
def test_validate_maven_success(tmp_path):
    module = _module(tmp_path)
    fake = MagicMock(returncode=0, stdout="ok", stderr="")
    with patch("app.execution.validator.subprocess.run", return_value=fake) as run:
        ok, msg = CompilerValidator.validate_maven(module)
    assert ok is True
    assert msg == "Build successful"
    # MAVEN_OPTS injected into env
    _, kwargs = run.call_args
    assert "MAVEN_OPTS" in kwargs["env"]
    assert "--add-opens" in kwargs["env"]["MAVEN_OPTS"]


def test_validate_maven_success_with_existing_maven_opts(tmp_path, monkeypatch):
    monkeypatch.setenv("MAVEN_OPTS", "-Xmx512m")
    module = _module(tmp_path)
    fake = MagicMock(returncode=0, stdout="ok", stderr="")
    with patch("app.execution.validator.subprocess.run", return_value=fake) as run:
        ok, _ = CompilerValidator.validate_maven(module)
    assert ok is True
    _, kwargs = run.call_args
    assert kwargs["env"]["MAVEN_OPTS"].startswith("-Xmx512m ")


def test_validate_maven_build_failure_uses_stderr(tmp_path):
    module = _module(tmp_path)
    fake = MagicMock(returncode=1, stdout="", stderr="compile error")
    with patch("app.execution.validator.subprocess.run", return_value=fake):
        ok, msg = CompilerValidator.validate_maven(module)
    assert ok is False
    assert "compile error" in msg


def test_validate_maven_build_failure_falls_back_to_stdout(tmp_path):
    module = _module(tmp_path)
    fake = MagicMock(returncode=1, stdout="stdout error", stderr="")
    with patch("app.execution.validator.subprocess.run", return_value=fake):
        ok, msg = CompilerValidator.validate_maven(module)
    assert ok is False
    assert "stdout error" in msg


def test_validate_maven_timeout(tmp_path):
    module = _module(tmp_path)
    with patch(
        "app.execution.validator.subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="mvn", timeout=300),
    ):
        ok, msg = CompilerValidator.validate_maven(module, timeout=300)
    assert ok is False
    assert "timeout" in msg.lower()


def test_validate_maven_not_found(tmp_path):
    module = _module(tmp_path)
    with patch("app.execution.validator.subprocess.run", side_effect=FileNotFoundError()):
        ok, msg = CompilerValidator.validate_maven(module)
    assert ok is False
    assert "Maven command not found" in msg


def test_validate_maven_generic_exception(tmp_path):
    module = _module(tmp_path)
    with patch("app.execution.validator.subprocess.run", side_effect=RuntimeError("boom")):
        ok, msg = CompilerValidator.validate_maven(module)
    assert ok is False
    assert "boom" in msg


# --------------------------------------------------------------------------
# validate_dotnet
# --------------------------------------------------------------------------
def test_validate_dotnet_success(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    fake = MagicMock(returncode=0, stdout="ok", stderr="")
    with patch("app.execution.validator.subprocess.run", return_value=fake):
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is True
    assert msg == "Build successful"


def test_validate_dotnet_no_csproj(tmp_path):
    module = _module(tmp_path)
    with patch("app.execution.validator.subprocess.run") as run:
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is False
    assert "No .csproj" in msg
    run.assert_not_called()


def test_validate_dotnet_build_failure(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    fake = MagicMock(returncode=1, stdout="", stderr="build failed")
    with patch("app.execution.validator.subprocess.run", return_value=fake):
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is False
    assert "build failed" in msg


def test_validate_dotnet_build_failure_fallback_stdout(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    fake = MagicMock(returncode=1, stdout="stdout fail", stderr="")
    with patch("app.execution.validator.subprocess.run", return_value=fake):
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is False
    assert "stdout fail" in msg


def test_validate_dotnet_timeout(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    with patch(
        "app.execution.validator.subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="dotnet", timeout=300),
    ):
        ok, msg = CompilerValidator.validate_dotnet(module, timeout=300)
    assert ok is False
    assert "timeout" in msg.lower()


def test_validate_dotnet_not_found(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    with patch("app.execution.validator.subprocess.run", side_effect=FileNotFoundError()):
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is False
    assert "dotnet command not found" in msg


def test_validate_dotnet_generic_exception(tmp_path):
    (tmp_path / "app.csproj").write_text("<Project/>")
    module = _module(tmp_path)
    with patch("app.execution.validator.subprocess.run", side_effect=RuntimeError("kaboom")):
        ok, msg = CompilerValidator.validate_dotnet(module)
    assert ok is False
    assert "kaboom" in msg


# --------------------------------------------------------------------------
# validate (dispatch)
# --------------------------------------------------------------------------
def test_validate_dispatch_maven(tmp_path):
    module = _module(tmp_path)
    with patch.object(CompilerValidator, "validate_maven", return_value=(True, "ok")) as m:
        ok, msg = CompilerValidator.validate(module, "maven", timeout=10)
    assert ok is True
    m.assert_called_once_with(module, 10)


def test_validate_dispatch_dotnet(tmp_path):
    module = _module(tmp_path)
    with patch.object(CompilerValidator, "validate_dotnet", return_value=(True, "ok")) as m:
        ok, msg = CompilerValidator.validate(module, "dotnet", timeout=20)
    assert ok is True
    m.assert_called_once_with(module, 20)


def test_validate_dispatch_unknown_raises(tmp_path):
    module = _module(tmp_path)
    with pytest.raises(ValueError, match="Unknown project type"):
        CompilerValidator.validate(module, "rust")