"""Tests for app.execution.artifact_manager.ArtifactManager."""
from unittest.mock import patch

import pytest

from app.execution.artifact_manager import ArtifactManager
from app.state.models import ModuleNode


# --------------------------------------------------------------------------
# hash_directory
# --------------------------------------------------------------------------
def test_hash_directory_basic_and_deterministic(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    (tmp_path / "b.txt").write_text("world")
    h1 = ArtifactManager.hash_directory(str(tmp_path))
    h2 = ArtifactManager.hash_directory(str(tmp_path))
    assert h1 and h1 == h2


def test_hash_directory_changes_with_content(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("hello")
    h1 = ArtifactManager.hash_directory(str(tmp_path))
    f.write_text("changed")
    h2 = ArtifactManager.hash_directory(str(tmp_path))
    assert h1 != h2


def test_hash_directory_nonexistent(tmp_path):
    assert ArtifactManager.hash_directory(str(tmp_path / "missing")) == ""


def test_hash_directory_not_a_dir(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("x")
    assert ArtifactManager.hash_directory(str(f)) == ""


def test_hash_directory_excludes_log_wildcard(tmp_path):
    (tmp_path / "keep.txt").write_text("data")
    h_before = ArtifactManager.hash_directory(str(tmp_path))
    (tmp_path / "noise.log").write_text("logs change all the time")
    h_after = ArtifactManager.hash_directory(str(tmp_path))
    # *.log excluded -> hash unchanged
    assert h_before == h_after


def test_hash_directory_excludes_directory_pattern(tmp_path):
    (tmp_path / "keep.txt").write_text("data")
    h_before = ArtifactManager.hash_directory(str(tmp_path))
    target = tmp_path / "target"
    target.mkdir()
    (target / "compiled.txt").write_text("artifact")
    h_after = ArtifactManager.hash_directory(str(tmp_path))
    # target/ dir excluded
    assert h_before == h_after


def test_hash_directory_excludes_exact_match(tmp_path):
    (tmp_path / "keep.txt").write_text("data")
    h_before = ArtifactManager.hash_directory(str(tmp_path))
    (tmp_path / "thing.dll").write_text("binary-ish")
    h_after = ArtifactManager.hash_directory(str(tmp_path))
    # *.dll excluded via wildcard
    assert h_before == h_after


def test_hash_directory_custom_exact_pattern(tmp_path):
    # 'secret' is an exact (non-wildcard, non-dir) pattern -> substring match
    (tmp_path / "keep.txt").write_text("data")
    (tmp_path / "secret_file.txt").write_text("hush")
    h_excluded = ArtifactManager.hash_directory(str(tmp_path), exclude_patterns=["secret"])
    h_included = ArtifactManager.hash_directory(str(tmp_path), exclude_patterns=["nomatch"])
    assert h_excluded != h_included


def test_hash_directory_permission_error_logged(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    with patch(
        "app.execution.artifact_manager.Path.read_bytes",
        side_effect=PermissionError("denied"),
    ):
        # Should not raise; permission errors are swallowed
        h = ArtifactManager.hash_directory(str(tmp_path))
    assert isinstance(h, str)


def test_hash_directory_generic_read_error_logged(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    with patch(
        "app.execution.artifact_manager.Path.read_bytes",
        side_effect=OSError("io error"),
    ):
        h = ArtifactManager.hash_directory(str(tmp_path))
    assert isinstance(h, str)


# --------------------------------------------------------------------------
# has_progress
# --------------------------------------------------------------------------
def test_has_progress_empty_directory_returns_false(tmp_path):
    # Empty dir -> hash of nothing is still a valid (non-empty) hash string.
    # Use a truly missing dir to get empty hash.
    module = ModuleNode(name="m", path=str(tmp_path / "missing"))
    assert ArtifactManager.has_progress(module) is False


def test_has_progress_first_time_initializes(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    module = ModuleNode(name="m", path=str(tmp_path))
    assert module.artifacts_hash is None
    assert ArtifactManager.has_progress(module) is True
    assert module.artifacts_hash is not None


def test_has_progress_no_change_returns_false(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    module = ModuleNode(name="m", path=str(tmp_path))
    ArtifactManager.has_progress(module)  # initialize
    assert ArtifactManager.has_progress(module) is False


def test_has_progress_change_detected_returns_true(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("hello")
    module = ModuleNode(name="m", path=str(tmp_path))
    ArtifactManager.has_progress(module)  # initialize
    f.write_text("changed content")
    old = module.artifacts_hash
    assert ArtifactManager.has_progress(module) is True
    assert module.artifacts_hash != old


# --------------------------------------------------------------------------
# update_hash
# --------------------------------------------------------------------------
def test_update_hash_success(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    module = ModuleNode(name="m", path=str(tmp_path))
    ArtifactManager.update_hash(module)
    assert module.artifacts_hash


def test_update_hash_success_with_prior_hash(tmp_path):
    (tmp_path / "a.txt").write_text("hello")
    module = ModuleNode(name="m", path=str(tmp_path), artifacts_hash="oldhash000000000")
    ArtifactManager.update_hash(module)
    assert module.artifacts_hash != "oldhash000000000"


def test_update_hash_failure_keeps_old(tmp_path):
    module = ModuleNode(name="m", path=str(tmp_path / "missing"), artifacts_hash="kept")
    ArtifactManager.update_hash(module)
    assert module.artifacts_hash == "kept"