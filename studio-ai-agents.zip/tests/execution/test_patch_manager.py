"""Tests for app.execution.patch_manager.PatchManager."""
from unittest.mock import patch

import pytest

from app.execution.patch_manager import PatchManager, PatchResult


# ==========================================================================
# apply_patch - top-level error handling
# ==========================================================================
def test_apply_patch_file_not_exist(tmp_path):
    res = PatchManager.apply_patch(str(tmp_path / "nope.txt"), "unified_diff", "x")
    assert res.success is False
    assert "does not exist" in res.error


def test_apply_patch_file_too_large(tmp_path):
    f = tmp_path / "big.txt"
    f.write_text("hi")
    with patch.object(PatchManager, "MAX_FILE_SIZE", 1):
        res = PatchManager.apply_patch(str(f), "unified_diff", "x")
    assert res.success is False
    assert "too large" in res.error


def test_apply_patch_binary_file_rejected(tmp_path):
    f = tmp_path / "bin.dat"
    f.write_bytes(b"abc\x00def")
    res = PatchManager.apply_patch(str(f), "unified_diff", "x")
    assert res.success is False
    assert "Binary" in res.error


def test_apply_patch_unicode_decode_error(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line1\nline2\n")
    with patch(
        "app.execution.patch_manager.Path.read_text",
        side_effect=UnicodeDecodeError("utf-8", b"", 0, 1, "bad"),
    ):
        res = PatchManager.apply_patch(str(f), "unified_diff", "@@ -1 +1 @@")
    assert res.success is False
    assert "binary or has invalid encoding" in res.error


def test_apply_patch_read_generic_error(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line1\n")
    with patch(
        "app.execution.patch_manager.Path.read_text",
        side_effect=OSError("disk error"),
    ):
        res = PatchManager.apply_patch(str(f), "unified_diff", "@@ -1 +1 @@")
    assert res.success is False
    assert "Failed to read file" in res.error


def test_apply_patch_unknown_format(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line1\n")
    res = PatchManager.apply_patch(str(f), "bogus", "data")
    assert res.success is False
    assert "Unknown patch format" in res.error


def test_apply_patch_write_exception(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line1\nline2\n")
    diff = "@@ -1,1 +1,1 @@\n-line1\n+newline1\n"
    with patch(
        "app.execution.patch_manager.Path.write_text",
        side_effect=OSError("cannot write"),
    ):
        res = PatchManager.apply_patch(str(f), "unified_diff", diff)
    assert res.success is False
    assert "Patch application failed" in res.error
    assert res.original_line_count == 2


# ==========================================================================
# unified_diff
# ==========================================================================
def test_apply_unified_diff_success(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line1\nline2\nline3\n")
    diff = "@@ -2,1 +2,1 @@\n-line2\n+CHANGED\n"
    res = PatchManager.apply_patch(str(f), "unified_diff", diff)
    assert res.success is True
    assert "CHANGED" in f.read_text()
    assert res.original_line_count == 3


def test_apply_unified_diff_with_context_and_add(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\n")
    # context line " a", remove b, add B and extra
    diff = "@@ -1,3 +1,3 @@\n a\n-b\n+B\n c\n"
    res = PatchManager.apply_patch(str(f), "unified_diff", diff)
    assert res.success is True
    # Assert the WHOLE file: the context lines must survive. Asserting only
    # that "B" appears is what let the context-destroying applier pass.
    assert f.read_text() == "a\nB\nc\n"


def test_apply_unified_diff_multiple_hunks_reverse(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("1\n2\n3\n4\n5\n")
    diff = (
        "@@ -1,1 +1,1 @@\n-1\n+ONE\n"
        "@@ -5,1 +5,1 @@\n-5\n+FIVE\n"
    )
    res = PatchManager.apply_patch(str(f), "unified_diff", diff)
    assert res.success is True
    content = f.read_text()
    assert "ONE" in content and "FIVE" in content


def test_apply_unified_diff_no_hunks(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    # No @@ at all -> validate_patch would reject, but call internal apply directly
    res = PatchManager._apply_unified_diff(["a\n", "b\n"], "no hunks here")
    assert res["success"] is False
    assert "No valid hunks" in res["error"]


def test_apply_unified_diff_header_without_ranges_still_opens_a_hunk():
    # An @@ line that doesn't carry ranges is the anchored dialect, so it MUST
    # open a hunk rather than be discarded. With no context and no removals
    # there is nothing to anchor to, so it is refused with actionable advice
    # instead of being silently dropped.
    res = PatchManager._apply_unified_diff(["a\n"], "@@ malformed @@\n+x\n")
    assert res["success"] is False
    assert "no anchor" in res["error"]
    assert "context line" in res["error"]


def test_apply_unified_diff_line_no_prefix_skipped():
    # A hunk line that does not start with " ", "-", or "+" is not added to
    # the hunk (collected only via the startswith filter), then iteration
    # continues. We feed such a line directly between valid +/- lines.
    diff = "@@ -1,1 +1,1 @@\n-old\n+new\nno-prefix-noise\n"
    res = PatchManager._apply_unified_diff(["old\n"], diff)
    assert res["success"] is True
    assert res["lines"] == ["new\n"]


def test_apply_unified_diff_parse_exception():
    with patch("app.execution.patch_manager.re.match", side_effect=RuntimeError("re boom")):
        res = PatchManager._apply_unified_diff(["a\n"], "@@ -1 +1 @@\n+x\n")
    assert res["success"] is False
    assert "Failed to parse unified diff" in res["error"]


# ==========================================================================
# unified_diff - regression cases for the silent-corruption bug
#
# Measured on APP351302 / task 427 (AWS dev, 2026-08-11): the model emitted a
# correct unified diff, the applier discarded the whole hunk body including the
# context lines, and reported SUCCESS. Two files were damaged, one left as
# invalid YAML. These tests pin the behaviour that must never come back.
# ==========================================================================
AUDIT_YAML = (
    "apiVersion: apps/v1\n"
    "kind: Deployment\n"
    "metadata:\n"
    "  name: sample-app\n"
    "spec:\n"
    "  replicas: 1\n"
    "  template:\n"
    "    spec:\n"
    "      containers:\n"
    "        - name: app\n"
    "          image: registry.example.com/app:1.0\n"
    "          securityContext:\n"
    "            runAsUser: 0\n"
    "            privileged: true\n"
    "          ports:\n"
    "            - containerPort: 8080\n"
)

AUDIT_YAML_FIXED = AUDIT_YAML.replace(
    "            privileged: true\n", "            privileged: false\n"
)


def test_audit_case_three_context_one_removal_one_addition(tmp_path):
    """THE audit failure: 3 context lines, 1 removal, 1 addition.

    Must apply as exactly one deletion and one insertion, leaving every
    context line intact. Before the fix this deleted the whole hunk span
    (16 -> 12 lines) and still reported success.
    """
    f = tmp_path / "deployment.yaml"
    f.write_text(AUDIT_YAML)
    diff = (
        "--- a/deployment.yaml\n"
        "+++ b/deployment.yaml\n"
        "@@ -12,5 +12,5 @@\n"
        "           securityContext:\n"
        "             runAsUser: 0\n"
        "-            privileged: true\n"
        "+            privileged: false\n"
        "           ports:\n"
        "             - containerPort: 8080\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == AUDIT_YAML_FIXED
    # One line swapped for one line: the line count must not move at all.
    assert res.original_line_count == 16
    assert res.new_line_count == 16
    # The context lines the old applier ate:
    content = f.read_text()
    assert "          securityContext:\n" in content
    assert "            runAsUser: 0\n" in content
    assert "          ports:\n" in content
    assert "            - containerPort: 8080\n" in content


def test_audit_case_anchored_dialect(tmp_path):
    """Same edit via the anchored '@@' dialect (no line ranges).

    Newer models emit this form; before the fix it was rejected outright with
    "No valid hunks found in diff", so no patch could ever be applied.
    """
    f = tmp_path / "deployment.yaml"
    f.write_text(AUDIT_YAML)
    diff = (
        "@@\n"
        "           securityContext:\n"
        "             runAsUser: 0\n"
        "-            privileged: true\n"
        "+            privileged: false\n"
        "           ports:\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == AUDIT_YAML_FIXED


def test_both_hunk_dialects_agree(tmp_path):
    """The numbered and anchored dialects must produce identical results."""
    body = (
        " b\n"
        "-c\n"
        "+C\n"
        " d\n"
    )
    original = "a\nb\nc\nd\ne\n"

    numbered = tmp_path / "numbered.txt"
    numbered.write_text(original)
    anchored = tmp_path / "anchored.txt"
    anchored.write_text(original)

    r1 = PatchManager.apply_patch(
        str(numbered), "unified_diff", "@@ -2,3 +2,3 @@\n" + body
    )
    r2 = PatchManager.apply_patch(str(anchored), "unified_diff", "@@\n" + body)

    assert r1.success is True and r2.success is True
    assert numbered.read_text() == anchored.read_text() == "a\nb\nC\nd\ne\n"


def test_hunk_located_by_content_when_line_number_is_wrong(tmp_path):
    """A stale/incorrect numbered header must not misplace the edit.

    The header claims line 1, but the content sits at line 4. Content wins.
    """
    f = tmp_path / "f.txt"
    f.write_text("one\ntwo\nthree\ntarget\nfive\n")
    diff = "@@ -1,1 +1,1 @@\n-target\n+TARGET\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "one\ntwo\nthree\nTARGET\nfive\n"


def test_identical_hunks_consume_successive_occurrences(tmp_path):
    """N hunks against N identical blocks must change N distinct occurrences.

    This is why the search runs forward from the previous hunk instead of
    always matching the first occurrence.
    """
    f = tmp_path / "f.txt"
    f.write_text("dup\nkeep\ndup\nkeep\ndup\n")
    diff = (
        "@@\n-dup\n+first\n"
        "@@\n-dup\n+second\n"
        "@@\n-dup\n+third\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "first\nkeep\nsecond\nkeep\nthird\n"


def test_unmatchable_hunk_is_refused_not_applied(tmp_path):
    """A hunk that matches nothing must fail loudly and leave the file alone."""
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    diff = "@@ -1,2 +1,2 @@\n-does not exist\n+replacement\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is False
    assert "does not match the file" in res.error
    # Actionable for the model, and the file is untouched.
    assert "Re-read the file" in res.error
    assert f.read_text() == "alpha\nbeta\n"


def test_context_whitespace_preserved_from_file(tmp_path):
    """Context is rebuilt from the FILE, so its original indentation survives
    even when the model's context lines are indented differently."""
    f = tmp_path / "f.py"
    f.write_text("def f():\n\tif x:\n\t\treturn 1\n\treturn 0\n")
    # Model sends spaces where the file uses tabs.
    diff = (
        "@@\n"
        "    if x:\n"
        "-        return 1\n"
        "+        return 2\n"
        "    return 0\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    content = f.read_text()
    # Untouched lines keep their tabs exactly.
    assert "\tif x:\n" in content
    assert "\treturn 0\n" in content
    assert "return 2" in content
    assert "return 1" not in content


def test_pure_insertion_hunk_with_numbered_header(tmp_path):
    """An addition-only hunk has no anchor of its own, so it needs the header."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    diff = "@@ -2,0 +2,1 @@\n+inserted\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\ninserted\nb\n"


def test_pure_insertion_without_anchor_is_refused(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")

    res = PatchManager.apply_patch(str(f), "unified_diff", "@@\n+inserted\n")

    assert res.success is False
    assert "no anchor" in res.error
    assert f.read_text() == "a\nb\n"


def test_multiple_hunks_applied_in_file_order(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("1\n2\n3\n4\n5\n")
    diff = (
        "@@ -1,1 +1,1 @@\n-1\n+ONE\n"
        "@@ -5,1 +5,1 @@\n-5\n+FIVE\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "ONE\n2\n3\n4\nFIVE\n"


def test_hunk_adding_more_lines_than_it_removes(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("start\nmiddle\nend\n")
    diff = (
        "@@ -1,3 +1,4 @@\n"
        " start\n"
        "-middle\n"
        "+middle-a\n"
        "+middle-b\n"
        " end\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "start\nmiddle-a\nmiddle-b\nend\n"
    assert res.new_line_count == 4


def test_hunk_deleting_lines_only(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("keep1\ndrop\nkeep2\n")
    diff = "@@ -1,3 +1,2 @@\n keep1\n-drop\n keep2\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "keep1\nkeep2\n"


def test_diff_file_headers_are_not_treated_as_hunk_body(tmp_path):
    """'---' / '+++' headers must not be mistaken for removed/added lines."""
    f = tmp_path / "f.txt"
    f.write_text("x\n")
    diff = (
        "--- a/f.txt\n"
        "+++ b/f.txt\n"
        "@@ -1,1 +1,1 @@\n"
        "-x\n"
        "+y\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "y\n"


def test_patch_on_last_line_without_trailing_newline(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb")  # no trailing newline
    diff = "@@\n-b\n+B\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\nB\n"


def test_blank_context_line_sent_as_bare_newline(tmp_path):
    """A blank context line whose leading space was stripped must still match.

    Most tooling (and many models) trim trailing whitespace, so a blank context
    line arrives as "\\n" rather than " \\n". Refusing these pushed the model
    towards re-emitting the whole file, which is what patching exists to avoid.
    """
    f = tmp_path / "x.py"
    f.write_text("def a():\n    return 1\n\ndef b():\n    return 2\n")
    diff = (
        "@@\n"
        "    return 1\n"
        "\n"                    # blank CONTEXT line, leading space stripped
        "-def b():\n"
        "+def bee():\n"
        "     return 2\n"
    )

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "def a():\n    return 1\n\ndef bee():\n    return 2\n"


def test_blank_context_line_sent_with_leading_space(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("a\n\nb\n")
    diff = "@@\n a\n \n-b\n+B\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\n\nB\n"


def test_trailing_blank_line_after_diff_is_not_hunk_content(tmp_path):
    """A blank line trailing the diff must not be absorbed as a context line."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    diff = "@@\n-b\n+B\n\n\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\nB\n"


def test_blank_line_between_hunks_is_not_absorbed(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\n")
    diff = "@@\n-a\n+A\n\n@@\n-c\n+C\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "A\nb\nC\n"


def test_invented_blank_context_line_still_applies(tmp_path):
    """If the model adds a blank context line the file does not have, the hunk
    is retried without it rather than refused."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\n")
    diff = "@@\n a\n\n-b\n+B\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\nB\nc\n"


def test_blank_trim_retry_that_also_fails_is_refused(tmp_path):
    """When neither the blank-inclusive nor the trimmed hunk matches, refuse."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    diff = "@@\n nowhere\n\n-alsonowhere\n+x\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is False
    assert "does not match the file" in res.error
    assert f.read_text() == "a\nb\n"


def test_hunk_anchored_only_by_a_blank_context_line_is_refused(tmp_path):
    """Trimming the blank leaves nothing to anchor to, so the hunk is refused
    rather than being placed by guesswork."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    diff = "@@\n\n+added\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is False
    assert f.read_text() == "a\nb\n"


def test_added_blank_line_is_preserved(tmp_path):
    """A '+' line that adds a blank line must survive the blank-line handling."""
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    diff = "@@\n a\n+\n b\n"

    res = PatchManager.apply_patch(str(f), "unified_diff", diff)

    assert res.success is True
    assert f.read_text() == "a\n\nb\n"


# ==========================================================================
# _locate
# ==========================================================================
def test_locate_exact_match():
    lines = ["a\n", "b\n", "c\n"]
    assert PatchManager._locate(lines, ["b\n"], None, 0) == 1


def test_locate_empty_block_returns_none():
    assert PatchManager._locate(["a\n"], [], None, 0) is None


def test_locate_block_longer_than_file_returns_none():
    assert PatchManager._locate(["a\n"], ["a\n", "b\n"], None, 0) is None


def test_locate_numbered_hint_wins_when_it_lands_on_a_match():
    lines = ["dup\n", "x\n", "dup\n"]
    assert PatchManager._locate(lines, ["dup\n"], 2, 0) == 2


def test_locate_searches_forward_from_cursor():
    lines = ["dup\n", "x\n", "dup\n"]
    assert PatchManager._locate(lines, ["dup\n"], None, 1) == 2


def test_locate_falls_back_behind_cursor_when_nothing_ahead():
    lines = ["dup\n", "x\n"]
    assert PatchManager._locate(lines, ["dup\n"], None, 5) == 0


def test_locate_indentation_insensitive_second_pass():
    lines = ["\t\tdeeply indented\n"]
    assert PatchManager._locate(lines, ["  deeply indented\n"], None, 0) == 0


def test_locate_no_match_returns_none():
    assert PatchManager._locate(["a\n"], ["zzz\n"], None, 0) is None


def test_locate_with_hint_falls_back_to_nearest_behind_cursor():
    # Matches exist but all sit behind the cursor, and the hint itself is not
    # one of them, so the match nearest the hint wins.
    lines = ["dup\n", "x\n", "dup\n", "y\n"]
    assert PatchManager._locate(lines, ["dup\n"], 3, 9) == 2
    assert PatchManager._locate(lines, ["dup\n"], 1, 9) == 0


# ==========================================================================
# _resolve_line - 1-based line-number mapping
# ==========================================================================
def test_resolve_line_one_based_without_old_text():
    lines = ["a\n", "b\n", "c\n"]
    assert PatchManager._resolve_line(lines, 1, None) == 0
    assert PatchManager._resolve_line(lines, 3, None) == 2


def test_resolve_line_out_of_range_without_old_text():
    assert PatchManager._resolve_line(["a\n"], 9, None) is None
    assert PatchManager._resolve_line(["a\n"], 0, None) is None


def test_resolve_line_prefers_one_based_when_old_text_matches():
    lines = ["alpha\n", "beta\n", "gamma\n"]
    assert PatchManager._resolve_line(lines, 2, "beta") == 1


def test_resolve_line_tolerates_zero_based_input():
    # A model that sent 0-based numbers still lands correctly because
    # old_text is the authority.
    lines = ["alpha\n", "beta\n", "gamma\n"]
    assert PatchManager._resolve_line(lines, 1, "beta") == 1


def test_resolve_line_finds_unique_match_elsewhere():
    lines = ["alpha\n", "beta\n", "gamma\n"]
    # Badly stale number, but the text occurs exactly once.
    assert PatchManager._resolve_line(lines, 99, "gamma") == 2


def test_resolve_line_picks_nearest_of_several_matches():
    lines = ["dup\n", "x\n", "dup\n", "y\n", "dup\n"]
    assert PatchManager._resolve_line(lines, 5, "dup") == 4


def test_resolve_line_returns_none_when_old_text_absent_from_file():
    assert PatchManager._resolve_line(["a\n"], 1, "nope") is None


def test_resolve_line_nearest_when_neither_offset_matches():
    # Neither the 1-based nor the 0-based reading of line 2 is "dup", and "dup"
    # occurs more than once, so the hit nearest the requested line wins.
    lines = ["dup\n", "x\n", "x\n", "dup\n"]
    assert PatchManager._resolve_line(lines, 2, "dup") == 0


# ==========================================================================
# line_edits
# ==========================================================================
def test_apply_line_edits_replace(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\ngamma\n")
    edits = [{"type": "replace", "line": 1, "old_text": "beta", "new_text": "BETA"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert "BETA\n" in f.read_text()


def test_apply_line_edits_replace_newtext_with_newline(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "replace", "line": 0, "old_text": "alpha", "new_text": "A\n"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text().startswith("A\n")


def test_apply_line_edits_insert(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    # 1-BASED: an insert names the line it goes BEFORE, so line 2 puts the new
    # text between "alpha" and "beta".
    edits = [{"type": "insert", "line": 2, "text": "inserted"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "alpha\ninserted\nbeta\n"


def test_apply_line_edits_insert_with_trailing_newline(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "insert", "line": 0, "text": "X\n"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text().startswith("X\n")


def test_apply_line_edits_delete(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\ngamma\n")
    # 1-BASED: line 2 is "beta". Under the old 0-based indexing this silently
    # removed "gamma" instead - the wrong line, with no error.
    edits = [{"type": "delete", "line": 2}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "alpha\ngamma\n"


def test_apply_line_edits_replace_mismatch(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "replace", "line": 0, "old_text": "WRONG", "new_text": "x"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is False
    assert "doesn't match expected content" in res.error


def test_apply_line_edits_negative_line(tmp_path):
    res = PatchManager._apply_line_edits(["a\n"], [{"type": "delete", "line": -1}])
    assert res["success"] is False
    assert "Invalid line number" in res["error"]


def test_apply_line_edits_none_line(tmp_path):
    res = PatchManager._apply_line_edits(["a\n"], [{"type": "delete"}])
    assert res["success"] is False
    assert "Invalid line number" in res["error"]


def test_apply_line_edits_out_of_bounds(tmp_path):
    res = PatchManager._apply_line_edits(["a\n"], [{"type": "delete", "line": 5}])
    assert res["success"] is False
    assert "out of bounds" in res["error"]


def test_apply_line_edits_unknown_type(tmp_path):
    res = PatchManager._apply_line_edits(["a\n", "b\n"], [{"type": "frob", "line": 0}])
    assert res["success"] is False
    assert "Unknown edit type" in res["error"]


def test_apply_line_edits_exception():
    # Passing a non-list to trigger the outer except (sorted on non-iterable dict edits)
    res = PatchManager._apply_line_edits(["a\n"], [{"type": "replace", "line": 0, "old_text": object()}])
    # old_text.rstrip() will fail -> exception path
    assert res["success"] is False
    assert "Failed to apply line edits" in res["error"]


def test_apply_line_edits_replace_last_line(tmp_path):
    """The last line is line len(file) under 1-based numbering.

    validate_patch used to reject this as out of bounds, so an edit to the
    final line of a file could never be applied at all.
    """
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\ngamma\n")
    edits = [{"type": "replace", "line": 3, "old_text": "gamma", "new_text": "GAMMA"}]

    ok, err = PatchManager.validate_patch(str(f), "line_edits", edits)
    assert ok is True, err

    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "alpha\nbeta\nGAMMA\n"


def test_apply_line_edits_replace_first_line_one_based(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "replace", "line": 1, "old_text": "alpha", "new_text": "ALPHA"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "ALPHA\nbeta\n"


def test_apply_line_edits_delete_last_line(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    res = PatchManager.apply_patch(str(f), "line_edits", [{"type": "delete", "line": 2}])
    assert res.success is True
    assert f.read_text() == "alpha\n"


def test_apply_line_edits_insert_appends_past_last_line(tmp_path):
    """line == len+1 is how "append" is spelled 1-based."""
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "insert", "line": 3, "text": "gamma"}]

    ok, err = PatchManager.validate_patch(str(f), "line_edits", edits)
    assert ok is True, err

    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "alpha\nbeta\ngamma\n"


def test_apply_line_edits_insert_far_past_end_refused(tmp_path):
    res = PatchManager._apply_line_edits(
        ["a\n"], [{"type": "insert", "line": 50, "text": "x"}]
    )
    assert res["success"] is False
    assert "out of bounds" in res["error"]


def test_apply_line_edits_delete_with_old_text_is_verified(tmp_path):
    """A delete carrying old_text is checked against the file, so a stale line
    number self-corrects instead of removing the wrong line."""
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\ngamma\n")
    edits = [{"type": "delete", "line": 1, "old_text": "gamma"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "alpha\nbeta\n"


def test_apply_line_edits_delete_with_wrong_old_text_refused(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("alpha\nbeta\n")
    edits = [{"type": "delete", "line": 1, "old_text": "not here"}]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is False
    assert f.read_text() == "alpha\nbeta\n"


def test_apply_line_edits_multiple_edits_one_based(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("one\ntwo\nthree\nfour\n")
    edits = [
        {"type": "replace", "line": 1, "old_text": "one", "new_text": "ONE"},
        {"type": "replace", "line": 4, "old_text": "four", "new_text": "FOUR"},
    ]
    res = PatchManager.apply_patch(str(f), "line_edits", edits)
    assert res.success is True
    assert f.read_text() == "ONE\ntwo\nthree\nFOUR\n"


def test_validate_patch_line_edits_last_line_allowed(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\n")
    ok, err = PatchManager.validate_patch(
        str(f), "line_edits", [{"type": "delete", "line": 3}]
    )
    assert ok is True
    assert err is None


def test_validate_patch_line_edits_append_position_allowed(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    ok, err = PatchManager.validate_patch(
        str(f), "line_edits", [{"type": "insert", "line": 3, "text": "c"}]
    )
    assert ok is True
    assert err is None


def test_validate_patch_line_edits_still_rejects_wild_numbers(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    ok, err = PatchManager.validate_patch(
        str(f), "line_edits", [{"type": "delete", "line": 500}]
    )
    assert ok is False
    assert "out of bounds" in err


# ==========================================================================
# structured edits
# ==========================================================================
def test_apply_structured_edits_success(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\nd\n")
    edits = {
        "edits": [
            {
                "range": {"start": {"line": 1}, "end": {"line": 2}},
                "new_text": "NEW1\nNEW2\n",
            }
        ]
    }
    res = PatchManager.apply_patch(str(f), "structured", edits)
    assert res.success is True
    assert "NEW1" in f.read_text()


def test_apply_structured_edits_no_trailing_newline(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\nc\n")
    edits = {
        "edits": [
            {"range": {"start": {"line": 0}, "end": {"line": 0}}, "new_text": "X"}
        ]
    }
    res = PatchManager.apply_patch(str(f), "structured", edits)
    assert res.success is True
    assert f.read_text().startswith("X\n")


def test_apply_structured_edits_multiple_reverse(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("1\n2\n3\n4\n")
    edits = {
        "edits": [
            {"range": {"start": {"line": 0}, "end": {"line": 0}}, "new_text": "ONE\n"},
            {"range": {"start": {"line": 3}, "end": {"line": 3}}, "new_text": "FOUR\n"},
        ]
    }
    res = PatchManager.apply_patch(str(f), "structured", edits)
    assert res.success is True
    content = f.read_text()
    assert "ONE" in content and "FOUR" in content


def test_apply_structured_edits_out_of_bounds(tmp_path):
    res = PatchManager._apply_structured_edits(
        ["a\n"],
        {"edits": [{"range": {"start": {"line": 0}, "end": {"line": 9}}, "new_text": "x"}]},
    )
    assert res["success"] is False
    assert "Invalid line range" in res["error"]


def test_apply_structured_edits_empty_newtext(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    edits = {
        "edits": [
            {"range": {"start": {"line": 0}, "end": {"line": 0}}, "new_text": ""}
        ]
    }
    res = PatchManager.apply_patch(str(f), "structured", edits)
    assert res.success is True


def test_apply_structured_edits_exception():
    # edits not a list-of-dicts -> .get on non-dict triggers exception
    res = PatchManager._apply_structured_edits(["a\n"], {"edits": ["notadict"]})
    assert res["success"] is False
    assert "Failed to apply structured edits" in res["error"]


# ==========================================================================
# compute_diff
# ==========================================================================
def test_compute_diff_produces_diff():
    diff = PatchManager.compute_diff("a\nb\n", "a\nc\n", "x.txt")
    assert "a/x.txt" in diff
    assert "+c" in diff or "-b" in diff


def test_compute_diff_no_change():
    diff = PatchManager.compute_diff("same\n", "same\n")
    assert diff == ""


# ==========================================================================
# validate_patch
# ==========================================================================
def test_validate_patch_file_not_exist(tmp_path):
    ok, err = PatchManager.validate_patch(str(tmp_path / "x.txt"), "unified_diff", "@@")
    assert ok is False
    assert "does not exist" in err


def test_validate_patch_str_too_large(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    with patch.object(PatchManager, "MAX_PATCH_SIZE", 1):
        ok, err = PatchManager.validate_patch(str(f), "unified_diff", "@@ huge")
    assert ok is False
    assert "too large" in err


def test_validate_patch_dict_too_large(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    with patch.object(PatchManager, "MAX_PATCH_SIZE", 1):
        ok, err = PatchManager.validate_patch(
            str(f), "structured", {"edits": [{"a": "x" * 10}]}
        )
    assert ok is False
    assert "too large" in err


def test_validate_patch_unicode_error(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    with patch(
        "app.execution.patch_manager.Path.read_text",
        side_effect=UnicodeDecodeError("utf-8", b"", 0, 1, "bad"),
    ):
        ok, err = PatchManager.validate_patch(str(f), "unified_diff", "@@ -1 +1 @@")
    assert ok is False
    assert "binary or has invalid encoding" in err


def test_validate_patch_read_generic_error(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    with patch(
        "app.execution.patch_manager.Path.read_text",
        side_effect=OSError("io"),
    ):
        ok, err = PatchManager.validate_patch(str(f), "unified_diff", "@@ -1 +1 @@")
    assert ok is False
    assert "Failed to read file" in err


def test_validate_patch_unified_not_string(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "unified_diff", ["not", "a", "string"])
    assert ok is False
    assert "must be a string" in err


def test_validate_patch_unified_missing_hunk(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "unified_diff", "no hunks")
    assert ok is False
    assert "missing hunk headers" in err


def test_validate_patch_unified_valid(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "unified_diff", "@@ -1 +1 @@")
    assert ok is True
    assert err is None


def test_validate_patch_line_edits_not_list(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "line_edits", {"not": "list"})
    assert ok is False
    assert "must be a list" in err


def test_validate_patch_line_edits_item_not_dict(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "line_edits", ["notdict"])
    assert ok is False
    assert "must be a dictionary" in err


def test_validate_patch_line_edits_missing_fields(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "line_edits", [{"type": "delete"}])
    assert ok is False
    assert "'type' and 'line'" in err


def test_validate_patch_line_edits_out_of_bounds(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(
        str(f), "line_edits", [{"type": "delete", "line": 99}]
    )
    assert ok is False
    assert "out of bounds" in err


def test_validate_patch_line_edits_valid(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(
        str(f), "line_edits", [{"type": "delete", "line": 0}]
    )
    assert ok is True


def test_validate_patch_structured_not_dict(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "structured", ["nope"])
    assert ok is False
    assert "must be a dictionary" in err


def test_validate_patch_structured_missing_edits(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(str(f), "structured", {"foo": "bar"})
    assert ok is False
    assert "'edits' field" in err


def test_validate_patch_structured_out_of_bounds(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("line\n")
    ok, err = PatchManager.validate_patch(
        str(f),
        "structured",
        {"edits": [{"range": {"start": {"line": 0}, "end": {"line": 50}}}]},
    )
    assert ok is False
    assert "out of bounds" in err


def test_validate_patch_structured_valid(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("a\nb\n")
    ok, err = PatchManager.validate_patch(
        str(f),
        "structured",
        {"edits": [{"range": {"start": {"line": 0}, "end": {"line": 0}}, "new_text": "x"}]},
    )
    assert ok is True


def test_validate_patch_non_str_non_collection_data(tmp_path):
    # patch_data that is neither str nor dict/list skips both size-check
    # branches and falls through to read + format checks.
    f = tmp_path / "f.txt"
    f.write_text("a\n")
    ok, err = PatchManager.validate_patch(str(f), "weird", 12345)
    assert ok is True
    assert err is None


def test_validate_patch_unknown_format_passthrough(tmp_path):
    # Unknown format falls through all elif blocks -> returns valid
    f = tmp_path / "f.txt"
    f.write_text("a\n")
    ok, err = PatchManager.validate_patch(str(f), "weird", "data")
    assert ok is True
    assert err is None


# ==========================================================================
# _is_binary_file
# ==========================================================================
def test_is_binary_file_true(tmp_path):
    f = tmp_path / "b.dat"
    f.write_bytes(b"abc\x00")
    assert PatchManager._is_binary_file(str(f)) is True


def test_is_binary_file_false(tmp_path):
    f = tmp_path / "t.txt"
    f.write_text("plain text")
    assert PatchManager._is_binary_file(str(f)) is False


def test_is_binary_file_open_error(tmp_path):
    assert PatchManager._is_binary_file(str(tmp_path / "missing")) is False