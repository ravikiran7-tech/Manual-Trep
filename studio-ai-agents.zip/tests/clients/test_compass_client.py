"""
Tests for app/clients/compass_client.py.

Covers the pydantic response models, the CompassClient (connection fetch &
parsing, HTTP error / 401 / 404 handling, timeouts, request errors, unexpected
errors, health check), and the module-level thread-safe singleton plus
cleanup helper.

No real HTTP is performed: the httpx.AsyncClient on the client instance is
replaced with an AsyncMock. Tenacity's backoff sleep is neutralised so the
``@with_resilience`` retry wrapper never waits, and the shared compass circuit
breaker is reset before every test so error-path tests don't trip it.
"""
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from app.clients import compass_client as cc
from app.clients.compass_client import (
    CompassClient,
    ConnectionConfiguration,
    ConnectionData,
    ConnectionResponse,
    cleanup_compass_client,
    get_compass_client,
)
from app.core.exceptions import ConfigurationError
from app.core.resilience import compass_circuit_breaker


def _reset_compass_breaker():
    """Force the shared compass circuit breaker back to a clean closed state.

    The repo's ``reset_circuit_breaker`` helper references a ``STATE_CLOSED``
    attribute that does not exist in the installed pybreaker version, so we
    reset via pybreaker's own ``close()`` API plus the failure counter.
    """
    try:
        compass_circuit_breaker.close()
    except Exception:
        pass
    try:
        compass_circuit_breaker._fail_counter = 0
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Autouse fixtures: keep tests fast & isolated
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _no_backoff_sleep():
    """Neutralise tenacity's async backoff so retries don't actually wait."""
    real_sleep = asyncio.sleep

    async def _fast_sleep(delay, *args, **kwargs):
        # Yield control but never wait the real (exponential) delay.
        return await real_sleep(0, *args, **kwargs)

    with patch("asyncio.sleep", new=_fast_sleep):
        yield


@pytest.fixture(autouse=True)
def _reset_breaker():
    """Reset the shared compass circuit breaker around every test."""
    _reset_compass_breaker()
    yield
    _reset_compass_breaker()


@pytest.fixture(autouse=True)
def _reset_singleton():
    """Ensure the module-level singleton starts and ends as None."""
    cc._default_client = None
    yield
    cc._default_client = None


def _make_response(status_code=200, json_data=None, text=""):
    """Build a MagicMock standing in for an httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json = MagicMock(return_value=json_data if json_data is not None else {})
    resp.text = text
    return resp


def _client_with_mock_get(get_side_effect=None, get_return=None):
    """Create a CompassClient whose underlying httpx get is mocked."""
    client = CompassClient()
    mock_http = AsyncMock()
    if get_side_effect is not None:
        mock_http.get = AsyncMock(side_effect=get_side_effect)
    else:
        mock_http.get = AsyncMock(return_value=get_return)
    client._http_client = mock_http
    return client, mock_http


# ===========================================================================
# MODEL TESTS
# ===========================================================================
class TestModels:
    def test_connection_configuration_aliases(self):
        cfg = ConnectionConfiguration(
            awsRegion="us-east-1",
            modelId="model-x",
            portkeyApiKey="pk-key",
            portkeyBaseUrl="https://pk",
            debugEnabled=True,
        )
        assert cfg.aws_region == "us-east-1"
        assert cfg.model_id == "model-x"
        assert cfg.portkey_api_key == "pk-key"
        assert cfg.portkey_base_url == "https://pk"
        assert cfg.debug_enabled is True

    def test_connection_configuration_defaults_and_populate_by_name(self):
        cfg = ConnectionConfiguration(aws_region="eu-west-1")
        assert cfg.aws_region == "eu-west-1"
        assert cfg.model_id is None
        assert cfg.debug_enabled is False

    def test_connection_data_is_active_enabled(self):
        cd = ConnectionData(providerType="aws-bedrock", status="enabled")
        assert cd.is_active() is True

    def test_connection_data_is_active_case_insensitive(self):
        cd = ConnectionData(providerType="aws-bedrock", status="ENABLED")
        assert cd.is_active() is True

    def test_connection_data_is_active_disabled(self):
        cd = ConnectionData(providerType="aws-bedrock", status="disabled")
        assert cd.is_active() is False

    def test_connection_data_default_status_enabled(self):
        cd = ConnectionData(providerType="aws-bedrock")
        assert cd.status == "enabled"
        assert cd.is_active() is True
        # default_factory configuration block
        assert isinstance(cd.configuration, ConnectionConfiguration)

    def test_connection_data_provider_type_required(self):
        with pytest.raises(Exception):
            ConnectionData()

    def test_connection_data_top_level_aliases(self):
        cd = ConnectionData(
            connectionId="CON-1",
            providerType="azure-ai-foundry",
            modelId="gpt-x",
            azureAiEndpoint="https://azure",
            authMethod="api-key",
            portkeyApiKey="pk",
            portkeyBaseUrl="https://pk",
            debugEnabled=True,
            modelParameters={"temperature": 0.5},
        )
        assert cd.connection_id == "CON-1"
        assert cd.model_id == "gpt-x"
        assert cd.azure_ai_endpoint == "https://azure"
        assert cd.auth_method == "api-key"
        assert cd.model_parameters == {"temperature": 0.5}

    def test_connection_response_is_success_true(self):
        resp = ConnectionResponse(status="SUCCESS", statusCode=200)
        assert resp.is_success() is True

    def test_connection_response_is_success_false_status(self):
        resp = ConnectionResponse(status="ERROR", statusCode=200)
        assert resp.is_success() is False

    def test_connection_response_is_success_false_code(self):
        resp = ConnectionResponse(status="SUCCESS", statusCode=500)
        assert resp.is_success() is False

    def test_connection_response_defaults(self):
        resp = ConnectionResponse()
        assert resp.status == "SUCCESS"
        assert resp.status_code == 200
        assert resp.data is None
        assert resp.is_success() is True


# ===========================================================================
# CLIENT INIT TESTS
# ===========================================================================
class TestInit:
    def test_init_defaults_from_settings(self):
        client = CompassClient()
        assert client.base_url.endswith("/")
        assert client.timeout is not None
        assert client.api_token is None
        assert "Authorization" not in client.headers
        assert client._http_client is None

    def test_init_adds_trailing_slash(self):
        client = CompassClient(base_url="https://example.com/api")
        assert client.base_url == "https://example.com/api/"

    def test_init_keeps_trailing_slash(self):
        client = CompassClient(base_url="https://example.com/api/")
        assert client.base_url == "https://example.com/api/"

    def test_init_with_api_token_sets_header(self):
        client = CompassClient(base_url="https://x/", api_token="tok-123")
        assert client.headers["Authorization"] == "Bearer tok-123"

    def test_init_empty_base_url_raises(self):
        # Both the explicit arg and the settings fallback must be falsy to hit
        # the ConfigurationError branch.
        fake_settings = MagicMock()
        fake_settings.studio_core.base_url = ""
        fake_settings.studio_core.timeout = 60
        with patch.object(cc, "settings", fake_settings):
            with pytest.raises(ConfigurationError) as exc:
                CompassClient(base_url="")
        assert "Studio Core URL is not configured" in str(exc.value)

    def test_init_custom_timeout(self):
        client = CompassClient(base_url="https://x/", timeout=5)
        assert client.timeout == 5


# ===========================================================================
# _ensure_client / close / context manager
# ===========================================================================
class TestLifecycle:
    async def test_ensure_client_creates_httpx_client(self):
        client = CompassClient(base_url="https://x/", timeout=7)
        assert client._http_client is None
        await client._ensure_client()
        assert isinstance(client._http_client, httpx.AsyncClient)
        # Calling again is a no-op (does not replace existing client)
        existing = client._http_client
        await client._ensure_client()
        assert client._http_client is existing
        await client.close()

    async def test_close_when_no_client(self):
        client = CompassClient(base_url="https://x/")
        # Should not raise even when client was never created
        await client.close()
        assert client._http_client is None

    async def test_close_aclose_called(self):
        client = CompassClient(base_url="https://x/")
        mock_http = AsyncMock()
        client._http_client = mock_http
        await client.close()
        mock_http.aclose.assert_awaited_once()
        assert client._http_client is None

    async def test_async_context_manager(self):
        async with CompassClient(base_url="https://x/") as client:
            assert isinstance(client._http_client, httpx.AsyncClient)
        # On exit the client is closed
        assert client._http_client is None


# ===========================================================================
# get_connections_by_component
# ===========================================================================
class TestGetConnections:
    async def test_success_with_data(self):
        json_data = {
            "status": "SUCCESS",
            "statusCode": 200,
            "data": [
                {
                    "connectionId": "CON-1",
                    "providerType": "aws-bedrock",
                    "status": "enabled",
                    "configuration": {"awsRegion": "us-east-1"},
                }
            ],
        }
        client, mock_http = _client_with_mock_get(
            get_return=_make_response(200, json_data)
        )
        resp = await client.get_connections_by_component("claude-code")
        assert resp.is_success()
        assert len(resp.data) == 1
        assert resp.data[0].provider_type == "aws-bedrock"
        assert resp.data[0].configuration.aws_region == "us-east-1"
        mock_http.get.assert_awaited_once()

    async def test_success_empty_data_logs_warning(self):
        json_data = {"status": "SUCCESS", "statusCode": 200, "data": []}
        client, _ = _client_with_mock_get(get_return=_make_response(200, json_data))
        resp = await client.get_connections_by_component("comp")
        assert resp.data == []

    async def test_success_none_data(self):
        json_data = {"status": "SUCCESS", "statusCode": 200}
        client, _ = _client_with_mock_get(get_return=_make_response(200, json_data))
        resp = await client.get_connections_by_component("comp")
        assert resp.data is None

    async def test_401_wrapped_as_configuration_error(self):
        # The 401 AuthenticationError is raised inside the try block, then the
        # generic `except Exception` handler re-wraps it as a ConfigurationError.
        client, _ = _client_with_mock_get(get_return=_make_response(401, text="nope"))
        with pytest.raises(ConfigurationError) as exc:
            await client.get_connections_by_component("comp")
        assert "Unexpected error fetching connections" in str(exc.value)
        assert "Authentication failed" in str(exc.value)

    async def test_404_returns_empty_response(self):
        client, _ = _client_with_mock_get(get_return=_make_response(404))
        resp = await client.get_connections_by_component("comp")
        assert resp.data == []
        assert "No connections found" in resp.message

    async def test_500_raises_configuration_error(self):
        client, _ = _client_with_mock_get(
            get_return=_make_response(500, text="server error")
        )
        with pytest.raises(ConfigurationError) as exc:
            await client.get_connections_by_component("comp")
        assert "status 500" in str(exc.value)

    async def test_400_raises_configuration_error(self):
        client, _ = _client_with_mock_get(get_return=_make_response(400, text="bad"))
        with pytest.raises(ConfigurationError):
            await client.get_connections_by_component("comp")

    async def test_timeout_raises_configuration_error(self):
        client, _ = _client_with_mock_get(
            get_side_effect=httpx.TimeoutException("timed out")
        )
        with pytest.raises(ConfigurationError) as exc:
            await client.get_connections_by_component("comp")
        assert "Timeout fetching connections" in str(exc.value)

    async def test_request_error_raises_configuration_error(self):
        client, _ = _client_with_mock_get(
            get_side_effect=httpx.ConnectError("conn refused")
        )
        with pytest.raises(ConfigurationError) as exc:
            await client.get_connections_by_component("comp")
        assert "Request error fetching connections" in str(exc.value)

    async def test_unexpected_error_raises_configuration_error(self):
        # response.json raises -> falls into generic Exception handler
        bad_resp = _make_response(200)
        bad_resp.json = MagicMock(side_effect=ValueError("bad json"))
        client, _ = _client_with_mock_get(get_return=bad_resp)
        with pytest.raises(ConfigurationError) as exc:
            await client.get_connections_by_component("comp")
        assert "Unexpected error fetching connections" in str(exc.value)

    async def test_ensure_client_invoked_when_no_http_client(self):
        # Don't pre-set _http_client; patch _ensure_client to inject a mock.
        client = CompassClient(base_url="https://x/")
        json_data = {"status": "SUCCESS", "statusCode": 200, "data": []}

        async def fake_ensure():
            mock_http = AsyncMock()
            mock_http.get = AsyncMock(return_value=_make_response(200, json_data))
            client._http_client = mock_http

        client._ensure_client = fake_ensure
        resp = await client.get_connections_by_component("comp")
        assert resp.data == []


# ===========================================================================
# get_active_connection
# ===========================================================================
class TestGetActiveConnection:
    async def test_returns_first_active(self):
        disabled = ConnectionData(providerType="aws-bedrock", status="disabled")
        enabled = ConnectionData(providerType="portkey", status="enabled")
        resp = ConnectionResponse(status="SUCCESS", statusCode=200, data=[disabled, enabled])
        client = CompassClient(base_url="https://x/")
        client.get_connections_by_component = AsyncMock(return_value=resp)

        active = await client.get_active_connection("comp")
        assert active is enabled
        assert active.provider_type == "portkey"

    async def test_no_data_returns_none(self):
        resp = ConnectionResponse(status="SUCCESS", statusCode=200, data=None)
        client = CompassClient(base_url="https://x/")
        client.get_connections_by_component = AsyncMock(return_value=resp)
        assert await client.get_active_connection("comp") is None

    async def test_empty_data_returns_none(self):
        resp = ConnectionResponse(status="SUCCESS", statusCode=200, data=[])
        client = CompassClient(base_url="https://x/")
        client.get_connections_by_component = AsyncMock(return_value=resp)
        assert await client.get_active_connection("comp") is None

    async def test_all_disabled_returns_none(self):
        d1 = ConnectionData(providerType="aws-bedrock", status="disabled")
        d2 = ConnectionData(providerType="portkey", status="disabled")
        resp = ConnectionResponse(status="SUCCESS", statusCode=200, data=[d1, d2])
        client = CompassClient(base_url="https://x/")
        client.get_connections_by_component = AsyncMock(return_value=resp)
        assert await client.get_active_connection("comp") is None


# ===========================================================================
# health_check
# ===========================================================================
class TestHealthCheck:
    async def test_health_ok(self):
        client, _ = _client_with_mock_get(get_return=_make_response(200))
        assert await client.health_check() is True

    async def test_health_non_200(self):
        client, _ = _client_with_mock_get(get_return=_make_response(503))
        assert await client.health_check() is False

    async def test_health_exception(self):
        client, _ = _client_with_mock_get(
            get_side_effect=httpx.ConnectError("down")
        )
        assert await client.health_check() is False

    async def test_health_ensures_client(self):
        client = CompassClient(base_url="https://x/")
        # patch _http_client creation by mocking get after ensure
        with patch.object(client, "_ensure_client", new=AsyncMock()):
            client._http_client = AsyncMock()
            client._http_client.get = AsyncMock(return_value=_make_response(200))
            assert await client.health_check() is True


# ===========================================================================
# Singleton getter & cleanup
# ===========================================================================
class TestSingleton:
    def test_get_compass_client_creates_and_caches(self):
        assert cc._default_client is None
        c1 = get_compass_client()
        assert isinstance(c1, CompassClient)
        # Second call returns the cached instance (fast path)
        c2 = get_compass_client()
        assert c1 is c2

    def test_get_compass_client_fast_path(self):
        existing = CompassClient(base_url="https://x/")
        cc._default_client = existing
        assert get_compass_client() is existing

    def test_get_compass_client_slow_path_double_check(self):
        # _default_client is None -> enters locked slow path and creates one
        cc._default_client = None
        client = get_compass_client()
        assert cc._default_client is client

    def test_get_compass_client_double_check_race(self):
        # Simulate a race: fast-path sees None, but another "thread" populated
        # the singleton before the lock is acquired -> inner `if` is False and
        # the existing instance is returned (407->410 branch).
        cc._default_client = None
        existing = CompassClient(base_url="https://race/")

        class _FakeLock:
            def __enter__(self_inner):
                cc._default_client = existing
                return self_inner

            def __exit__(self_inner, *exc):
                return False

        with patch.object(cc, "_client_lock", _FakeLock()):
            result = get_compass_client()
        assert result is existing

    async def test_cleanup_when_client_exists(self):
        mock_client = MagicMock()
        mock_client.close = AsyncMock()
        cc._default_client = mock_client
        await cleanup_compass_client()
        mock_client.close.assert_awaited_once()
        assert cc._default_client is None

    async def test_cleanup_when_no_client(self):
        cc._default_client = None
        await cleanup_compass_client()  # should be a no-op
        assert cc._default_client is None
