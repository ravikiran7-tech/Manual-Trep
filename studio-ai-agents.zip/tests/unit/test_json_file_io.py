"""Tests for app.utils.json_file_io."""
import json

import pytest

from app.utils.json_file_io import _read_json_file, read_json_file


def test_read_json_file_within_allowed_directory(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    (allowed / "settings.json").write_text('{"enabled": true}', encoding="utf-8")
    data = read_json_file("settings.json", allowed_directory=allowed)
    assert data == {"enabled": True}


def test_read_json_file_private_helper(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    (allowed / "settings.json").write_text('{"key": "value"}', encoding="utf-8")
    assert _read_json_file("settings.json", allowed_directory=allowed) == {"key": "value"}


def test_read_json_file_rejects_absolute_path(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    with pytest.raises(ValueError, match="Invalid filename"):
        read_json_file(str(tmp_path / "outside.json"), allowed_directory=allowed)


def test_read_json_file_rejects_relative_traversal(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    with pytest.raises(ValueError, match="Invalid filename"):
        read_json_file("../outside.json", allowed_directory=allowed)


def test_read_json_file_missing_returns_none(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    assert read_json_file("missing.json", allowed_directory=allowed) is None


def test_read_json_file_invalid_json_returns_none(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    (allowed / "bad.json").write_text("{not json", encoding="utf-8")
    assert read_json_file("bad.json", allowed_directory=allowed) is None


def test_read_json_file_non_object_returns_none(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    (allowed / "array.json").write_text(json.dumps([1, 2]), encoding="utf-8")
    assert read_json_file("array.json", allowed_directory=allowed) is None


def test_read_json_file_rejects_empty_filename(tmp_path):
    allowed = tmp_path / "config"
    allowed.mkdir()
    with pytest.raises(ValueError, match="Invalid filename"):
        read_json_file("  ", allowed_directory=allowed)
