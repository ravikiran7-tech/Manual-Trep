"""Tests for schema modernization SQL extraction (bash heredoc vs assistant text)."""
import tempfile
from pathlib import Path

import pytest

from app.services.operation_handlers.schema_modernization_handler import (
    SchemaModernizationHandler,
    _extract_sql_from_bash_heredoc,
)


def test_extract_sql_from_bash_heredoc_sample_stream_shape():
    cmd = (
        "cat > '/workspace/schema-modernization/2/_claude/schema-modernization-sql.sql' "
        "<< 'EOFSQL'\n"
        "CREATE TABLE t (id int);\n"
        "EOFSQL\n"
    )
    assert _extract_sql_from_bash_heredoc(cmd) == "CREATE TABLE t (id int);"


def test_extract_sql_from_bash_heredoc_last_delimiter_wins():
    cmd = (
        "cat > '/x/schema-modernization-sql.sql' << EOF\n"
        "ignore\n"
        "EOF\n"
        "cat > '/y/schema-modernization-sql.sql' << EOFSQL\n"
        "CREATE SCHEMA app;\n"
        "EOFSQL\n"
    )
    assert _extract_sql_from_bash_heredoc(cmd) == "CREATE SCHEMA app;"


def test_extract_sql_from_stream_prefers_workspace_file():
    handler = SchemaModernizationHandler()
    with tempfile.TemporaryDirectory() as tmp:
        sql_path = Path(tmp) / "schema-modernization-sql.sql"
        sql_path.write_text("FROM_DISK\n", encoding="utf-8")

        stream = [
            {
                "type": "assistant",
                "subtype": "text_delta",
                "text": "```json\n{\"migration_status\": \"completed\"}\n```",
            },
            {
                "type": "tool_use",
                "tool": {
                    "name": "bash",
                    "input": {
                        "command": (
                            "cat > '/ignored/schema-modernization-sql.sql' << X\n"
                            "CREATE TABLE noise ();\n"
                            "X\n"
                        )
                    },
                },
            },
        ]

        out = handler._extract_sql_from_stream(stream, sql_output_file=sql_path)
        assert out == "FROM_DISK"


def test_extract_sql_from_stream_bash_heredoc_when_no_file():
    handler = SchemaModernizationHandler()
    stream = [
        {
            "type": "assistant",
            "subtype": "text_delta",
            "text": "Summary only ```json\n{}\n```",
        },
        {
            "type": "tool_use",
            "tool": {
                "name": "bash",
                "input": {
                    "command": (
                        "cat > 'p/schema-modernization-sql.sql' << 'EOFSQL'\n"
                        "CREATE EXTENSION IF NOT EXISTS plpgsql;\n"
                        "EOFSQL\n"
                    )
                },
            },
        },
    ]
    with tempfile.TemporaryDirectory() as tmp:
        missing = Path(tmp) / "nope.sql"
        out = handler._extract_sql_from_stream(stream, sql_output_file=missing)
        assert "CREATE EXTENSION" in (out or "")


def test_extract_sql_from_stream_falls_back_to_sql_fence():
    handler = SchemaModernizationHandler()
    stream = [
        {
            "type": "assistant",
            "subtype": "text_delta",
            "text": "Here is DDL:\n```sql\nSELECT 1;\n```",
        },
    ]
    with tempfile.TemporaryDirectory() as tmp:
        out = handler._extract_sql_from_stream(stream, sql_output_file=Path(tmp) / "x.sql")
        assert out == "SELECT 1;"
