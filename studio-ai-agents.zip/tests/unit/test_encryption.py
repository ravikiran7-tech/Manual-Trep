"""Tests for app.utils.encryption."""
import base64
import hashlib

import pytest

import app.utils.encryption as enc_mod
from app.utils.encryption import (
    EncryptionUtils,
    decrypt_portkey_credentials,
    get_encryption_utils,
    is_base64_string,
    decrypt_gcm_values,
    decrypt_secret_if_base64_gcm,
)
from app.core.exceptions import ConfigurationError

TEST_KEY = "P3qcGy5Nj2oMXh17iisPDg=="  # 16 bytes base64


# ---------------------------------------------------------------------------
# EncryptionUtils.__init__
# ---------------------------------------------------------------------------
def test_init_with_explicit_key():
    utils = EncryptionUtils(TEST_KEY)
    assert len(utils.key) == 16


def test_init_uses_settings_key_when_none():
    # module-level `settings` already loaded from env via get_settings()
    utils = EncryptionUtils()
    assert len(utils.key) == 16


def test_init_24_byte_key():
    key = base64.b64encode(b"x" * 24).decode("ascii")
    utils = EncryptionUtils(key)
    assert len(utils.key) == 24


def test_init_32_byte_key():
    key = base64.b64encode(b"x" * 32).decode("ascii")
    utils = EncryptionUtils(key)
    assert len(utils.key) == 32


def test_init_missing_key(monkeypatch):
    # Force the fallback `settings.encryption_key` to be empty
    monkeypatch.setattr(enc_mod.settings, "encryption_key", "", raising=False)
    with pytest.raises(ConfigurationError) as exc:
        EncryptionUtils(None)
    assert "missing" in str(exc.value).lower()


def test_init_invalid_key_length():
    key = base64.b64encode(b"x" * 10).decode("ascii")  # 10 bytes -> invalid
    with pytest.raises(ConfigurationError) as exc:
        EncryptionUtils(key)
    assert "Invalid AES key length" in str(exc.value)


def test_init_invalid_base64():
    with pytest.raises(ConfigurationError) as exc:
        EncryptionUtils("!!!not-base64!!!@@@")
    assert "Invalid AES key" in str(exc.value)


# ---------------------------------------------------------------------------
# encrypt / decrypt round trip
# ---------------------------------------------------------------------------
def test_encrypt_decrypt_round_trip():
    utils = EncryptionUtils(TEST_KEY)
    enc = utils.encrypt("hello world")
    assert enc != "hello world"
    assert utils.decrypt(enc) == "hello world"


def test_encrypt_none():
    utils = EncryptionUtils(TEST_KEY)
    assert utils.encrypt(None) is None


def test_encrypt_empty():
    utils = EncryptionUtils(TEST_KEY)
    assert utils.encrypt("") == ""


def test_decrypt_none():
    utils = EncryptionUtils(TEST_KEY)
    assert utils.decrypt(None) is None


def test_decrypt_empty():
    utils = EncryptionUtils(TEST_KEY)
    assert utils.decrypt("") == ""


def test_decrypt_too_short():
    utils = EncryptionUtils(TEST_KEY)
    short = base64.b64encode(b"abc").decode("ascii")
    with pytest.raises(ValueError, match="too short"):
        utils.decrypt(short)


def test_decrypt_invalid_base64():
    utils = EncryptionUtils(TEST_KEY)
    with pytest.raises(ValueError, match="Failed to decrypt|Invalid Base64"):
        utils.decrypt("!!!not base64###")


def test_decrypt_tampered_ciphertext():
    utils = EncryptionUtils(TEST_KEY)
    enc = utils.encrypt("secret")
    raw = bytearray(base64.b64decode(enc))
    raw[-1] ^= 0xFF  # corrupt the tag
    tampered = base64.b64encode(bytes(raw)).decode("ascii")
    with pytest.raises(ValueError, match="Failed to decrypt"):
        utils.decrypt(tampered)


def test_encrypt_failure(monkeypatch):
    utils = EncryptionUtils(TEST_KEY)
    # Corrupt key so AESGCM raises during encrypt
    utils.key = b"too-short"
    with pytest.raises(ValueError, match="Failed to encrypt"):
        utils.encrypt("data")


# ---------------------------------------------------------------------------
# is_encrypted
# ---------------------------------------------------------------------------
def test_is_encrypted_empty():
    utils = EncryptionUtils(TEST_KEY)
    assert utils.is_encrypted("") is False


def test_is_encrypted_true():
    utils = EncryptionUtils(TEST_KEY)
    enc = utils.encrypt("some data here")
    assert utils.is_encrypted(enc) is True


def test_is_encrypted_short_base64():
    utils = EncryptionUtils(TEST_KEY)
    short = base64.b64encode(b"ab").decode("ascii")
    assert utils.is_encrypted(short) is False


def test_is_encrypted_invalid_base64(monkeypatch):
    utils = EncryptionUtils(TEST_KEY)

    def boom(*args, **kwargs):
        raise ValueError("bad base64")

    monkeypatch.setattr(enc_mod.base64, "b64decode", boom)
    assert utils.is_encrypted("anything") is False


def test_is_encrypted_plaintext():
    utils = EncryptionUtils(TEST_KEY)
    # 'plaintext' is technically not valid b64 length-wise -> b64decode may throw
    assert utils.is_encrypted("not encrypted!!") is False


# ---------------------------------------------------------------------------
# decrypt_portkey_credentials
# ---------------------------------------------------------------------------
def test_decrypt_portkey_credentials():
    utils = EncryptionUtils(TEST_KEY)
    enc = utils.encrypt("api-key-123")
    assert decrypt_portkey_credentials(enc, TEST_KEY) == "api-key-123"


# ---------------------------------------------------------------------------
# get_encryption_utils singleton
# ---------------------------------------------------------------------------
def test_get_encryption_utils_singleton():
    enc_mod._default_utils = None
    u1 = get_encryption_utils()
    u2 = get_encryption_utils()
    assert u1 is u2


# ---------------------------------------------------------------------------
# is_base64_string
# ---------------------------------------------------------------------------
def test_is_base64_string_empty():
    assert is_base64_string("") is False
    assert is_base64_string("   ") is False
    assert is_base64_string(None) is False


def test_is_base64_string_valid():
    assert is_base64_string(base64.b64encode(b"hello").decode()) is True


def test_is_base64_string_invalid():
    assert is_base64_string("not valid base64 @@@") is False


def test_is_base64_string_with_whitespace():
    val = "  " + base64.b64encode(b"hello").decode() + "  "
    assert is_base64_string(val) is True


def test_is_base64_string_typeerror_fallback(monkeypatch):
    real = base64.b64decode

    def fake(s, validate=False):
        if validate:
            raise TypeError("validate not supported")
        return real(s)

    monkeypatch.setattr(enc_mod.base64, "b64decode", fake)
    assert is_base64_string(base64.b64encode(b"hi").decode()) is True


# ---------------------------------------------------------------------------
# decrypt_gcm_values
# ---------------------------------------------------------------------------
def _gcm_encrypt(plaintext, passphrase):
    key_bytes = hashlib.sha256(passphrase.encode("utf-8")).digest()
    key_b64 = base64.b64encode(key_bytes).decode("ascii")
    return EncryptionUtils(encryption_key=key_b64).encrypt(plaintext)


def test_decrypt_gcm_values_none():
    assert decrypt_gcm_values(None, "pass") == ""


def test_decrypt_gcm_values_blank_passphrase():
    with pytest.raises(ValueError, match="passphrase is required"):
        decrypt_gcm_values("data", "   ")


def test_decrypt_gcm_values_round_trip():
    enc = _gcm_encrypt("secret-value", "my-pass")
    assert decrypt_gcm_values(enc, "my-pass") == "secret-value"


def test_decrypt_gcm_values_empty_string_result():
    # encrypting "" returns "" which decrypt returns "" -> out is "" not None
    enc = _gcm_encrypt("", "pass")
    assert decrypt_gcm_values(enc, "pass") == ""


# ---------------------------------------------------------------------------
# decrypt_secret_if_base64_gcm
# ---------------------------------------------------------------------------
def test_decrypt_secret_none():
    assert decrypt_secret_if_base64_gcm(None) == ""


def test_decrypt_secret_blank():
    assert decrypt_secret_if_base64_gcm("   ") == "   "


def test_decrypt_secret_not_base64():
    assert decrypt_secret_if_base64_gcm("plain text @@@") == "plain text @@@"


def test_decrypt_secret_with_passphrase():
    enc = _gcm_encrypt("topsecret", "test-passphrase")
    result = decrypt_secret_if_base64_gcm(enc, passphrase="test-passphrase")
    assert result == "topsecret"


def test_decrypt_secret_passphrase_fails_falls_through():
    # Valid base64, short enough that is_encrypted is False after the
    # passphrase decrypt path raises and is swallowed -> returns original.
    enc_mod._default_utils = None
    short_val = base64.b64encode(b"x" * 10).decode("ascii")
    result = decrypt_secret_if_base64_gcm(short_val, passphrase="wrong-pass")
    assert result == short_val


def test_decrypt_secret_via_encryption_key():
    enc_mod._default_utils = None
    util = get_encryption_utils()
    enc = util.encrypt("via-key-secret")
    result = decrypt_secret_if_base64_gcm(enc)  # no passphrase
    assert result == "via-key-secret"


def test_decrypt_secret_base64_but_not_encrypted():
    enc_mod._default_utils = None
    # Valid base64, too short to be "encrypted" -> returns original
    val = base64.b64encode(b"hi").decode("ascii")
    assert decrypt_secret_if_base64_gcm(val) == val
