"""Unit tests for app.utils.stream_utils."""
import json
import pytest

from app.utils.stream_utils import StreamParser, _extract_single_json_block_robust


class TestExtractJsonBlocksRobust:
    """Tests for JSON block extraction when payload contains interior backticks."""

    def test_extract_json_block_with_triple_backticks_inside_string(self):
        """JSON with embedded triple backticks in a string value is extracted and parses."""
        # Content value is "```\nFROM node\n```" (valid JSON with escaped newlines)
        text = (
            "Here is the result:\n"
            "```json\n"
            '{"files":[{"name":"Dockerfile","content":"```\\nFROM node\\n```"}]}\n'
            "```\n"
            "Done."
        )
        blocks = StreamParser.extract_json_blocks(text)
        assert len(blocks) == 1
        parsed = json.loads(blocks[0])
        assert parsed["files"][0]["name"] == "Dockerfile"
        assert "```" in parsed["files"][0]["content"]
        assert "FROM node" in parsed["files"][0]["content"]

    def test_robust_extractor_returns_none_when_no_json_block(self):
        """_extract_single_json_block_robust returns None when no ```json present."""
        assert _extract_single_json_block_robust("no block here") is None
        assert _extract_single_json_block_robust("```\nplain\n```") is None

    def test_robust_extractor_handles_json_array_root(self):
        """Root-level JSON array is extracted correctly."""
        text = """```json
[{"id": 1}, {"id": 2}]
```"""
        block, _ = _extract_single_json_block_robust(text)
        assert block is not None
        parsed = json.loads(block)
        assert parsed == [{"id": 1}, {"id": 2}]

    def test_fallback_to_regex_when_robust_invalid(self):
        """When robust extractor returns invalid JSON, fallback regex is used."""
        # Text where bracket-aware scan might run off (e.g. truncated) - use
        # a simple valid regex-style block so we get one block from fallback.
        text = """```json
{"simple": true}
```"""
        blocks = StreamParser.extract_json_blocks(text)
        assert len(blocks) == 1
        assert json.loads(blocks[0]) == {"simple": True}
