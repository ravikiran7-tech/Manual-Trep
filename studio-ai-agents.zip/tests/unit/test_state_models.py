"""Tests for app.state.models."""
from app.state.models import ModuleStatus, ModuleNode, GraphState


def test_module_status_values():
    assert ModuleStatus.PENDING.value == "pending"
    assert ModuleStatus.IN_PROGRESS.value == "in_progress"
    assert ModuleStatus.LOCKED.value == "locked"
    assert ModuleStatus.FAILED.value == "failed"
    assert ModuleStatus.SKIPPED.value == "skipped"


def test_module_node_defaults():
    node = ModuleNode(name="m1", path="/p")
    assert node.name == "m1"
    assert node.path == "/p"
    assert node.dependencies == []
    assert node.status == ModuleStatus.PENDING
    assert node.retries == 0
    assert node.artifacts_hash is None
    assert node.last_error is None
    assert node.transformation_plan is None
    assert node.files_changed == []
    assert node.events == []


def test_module_node_with_values():
    node = ModuleNode(
        name="m1", path="/p", dependencies=["d1"], status=ModuleStatus.LOCKED,
        retries=2, artifacts_hash="abc", last_error="err",
        transformation_plan={"x": 1}, files_changed=["f.cs"], events=[{"e": 1}]
    )
    assert node.dependencies == ["d1"]
    assert node.status == ModuleStatus.LOCKED
    assert node.retries == 2


def test_module_node_hash():
    node = ModuleNode(name="m1", path="/p1")
    assert hash(node) == hash("m1")


def test_module_node_equality():
    n1 = ModuleNode(name="m1", path="/p1")
    n2 = ModuleNode(name="m1", path="/different")
    n3 = ModuleNode(name="m2", path="/p1")
    assert n1 == n2
    assert n1 != n3
    assert n1 != "not-a-node"


def test_module_node_usable_in_set():
    n1 = ModuleNode(name="m1", path="/p1")
    n2 = ModuleNode(name="m1", path="/p2")
    s = {n1, n2}
    assert len(s) == 1


def test_module_node_repr():
    node = ModuleNode(name="m1", path="/p", dependencies=["a", "b"])
    r = repr(node)
    assert "ModuleNode(name=m1" in r
    assert "status=pending" in r
    assert "retries=0" in r
    assert "deps=2" in r


def _make_graph(*statuses):
    graph = {}
    for i, st in enumerate(statuses):
        node = ModuleNode(name=f"m{i}", path=f"/p{i}", status=st)
        graph[node.name] = node
    return graph


def test_graph_state_defaults():
    gs = GraphState(graph={}, project_path="/p", project_type="dotnet", total_modules=0)
    assert gs.completed_modules == 0
    assert gs.failed_modules == 0
    assert gs.current_iteration == 0
    assert gs.max_retries == 3


def test_graph_state_is_complete_true():
    graph = _make_graph(ModuleStatus.LOCKED, ModuleStatus.FAILED, ModuleStatus.SKIPPED)
    gs = GraphState(graph=graph, project_path="/p", project_type="maven", total_modules=3)
    assert gs.is_complete() is True


def test_graph_state_is_complete_false():
    graph = _make_graph(ModuleStatus.LOCKED, ModuleStatus.PENDING)
    gs = GraphState(graph=graph, project_path="/p", project_type="maven", total_modules=2)
    assert gs.is_complete() is False


def test_graph_state_is_complete_empty():
    gs = GraphState(graph={}, project_path="/p", project_type="maven", total_modules=0)
    assert gs.is_complete() is True  # all() over empty is True


def test_graph_state_has_failures_true():
    graph = _make_graph(ModuleStatus.LOCKED, ModuleStatus.FAILED)
    gs = GraphState(graph=graph, project_path="/p", project_type="maven", total_modules=2)
    assert gs.has_failures() is True


def test_graph_state_has_failures_false():
    graph = _make_graph(ModuleStatus.LOCKED, ModuleStatus.SKIPPED)
    gs = GraphState(graph=graph, project_path="/p", project_type="maven", total_modules=2)
    assert gs.has_failures() is False


def test_graph_state_get_progress():
    graph = _make_graph(
        ModuleStatus.LOCKED,
        ModuleStatus.FAILED,
        ModuleStatus.PENDING,
        ModuleStatus.IN_PROGRESS,
        ModuleStatus.SKIPPED,
    )
    gs = GraphState(
        graph=graph, project_path="/p", project_type="maven",
        total_modules=5, current_iteration=7,
    )
    progress = gs.get_progress()
    assert progress == {
        "total": 5,
        "locked": 1,
        "failed": 1,
        "pending": 1,
        "in_progress": 1,
        "skipped": 1,
        "completed": 3,
        "iteration": 7,
    }
