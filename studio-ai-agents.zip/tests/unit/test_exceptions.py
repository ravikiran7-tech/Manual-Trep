"""Tests for app.core.exceptions."""
import pytest

from app.core.exceptions import (
    StudioAIEngineException,
    ValidationError,
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    CompassClientError,
    OperationTimeoutError,
    CircuitBreakerError,
    RateLimitError,
    FileOperationError,
    StreamParsingError,
    ToolExecutionError,
    BuildCompilationError,
)


# ---------------------------------------------------------------------------
# Base exception
# ---------------------------------------------------------------------------
def test_base_message_only():
    e = StudioAIEngineException("oops")
    assert e.message == "oops"
    assert e.details is None
    assert str(e) == "oops"


def test_base_with_details():
    e = StudioAIEngineException("oops", details="more")
    assert str(e) == "oops Details: more"


def test_base_is_exception():
    with pytest.raises(StudioAIEngineException):
        raise StudioAIEngineException("x")


# ---------------------------------------------------------------------------
# ValidationError
# ---------------------------------------------------------------------------
def test_validation_error_no_field_no_details():
    e = ValidationError("bad")
    assert e.field is None
    assert str(e) == "bad"


def test_validation_error_with_field():
    e = ValidationError("bad", field="name")
    assert e.field == "name"
    assert str(e) == "bad (Field: name)"


def test_validation_error_with_field_and_details():
    e = ValidationError("bad", field="name", details="d")
    assert str(e) == "bad (Field: name) Details: d"


def test_validation_error_details_only():
    e = ValidationError("bad", details="d")
    assert str(e) == "bad Details: d"


# ---------------------------------------------------------------------------
# Simple pass-through subclasses
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("cls", [
    AuthenticationError,
    ConfigurationError,
    CompassClientError,
    CircuitBreakerError,
    StreamParsingError,
])
def test_simple_subclasses(cls):
    e = cls("msg")
    assert str(e) == "msg"
    assert isinstance(e, StudioAIEngineException)
    e2 = cls("msg", details="d")
    assert str(e2) == "msg Details: d"


# ---------------------------------------------------------------------------
# ProviderError
# ---------------------------------------------------------------------------
def test_provider_error_plain():
    e = ProviderError("fail")
    assert e.provider is None
    assert str(e) == "fail"


def test_provider_error_with_provider():
    e = ProviderError("fail", provider="bedrock")
    assert str(e) == "fail (Provider: bedrock)"


def test_provider_error_with_provider_and_details():
    e = ProviderError("fail", provider="bedrock", details="d")
    assert str(e) == "fail (Provider: bedrock) Details: d"


def test_provider_error_details_only():
    e = ProviderError("fail", details="d")
    assert str(e) == "fail Details: d"


# ---------------------------------------------------------------------------
# OperationTimeoutError
# ---------------------------------------------------------------------------
def test_timeout_error_plain():
    e = OperationTimeoutError("slow")
    assert e.timeout_seconds is None
    assert str(e) == "slow"


def test_timeout_error_with_seconds():
    e = OperationTimeoutError("slow", timeout_seconds=30)
    assert str(e) == "slow (Timeout: 30s)"


def test_timeout_error_with_seconds_and_details():
    e = OperationTimeoutError("slow", timeout_seconds=30, details="d")
    assert str(e) == "slow (Timeout: 30s) Details: d"


def test_timeout_error_details_only():
    e = OperationTimeoutError("slow", details="d")
    assert str(e) == "slow Details: d"


# ---------------------------------------------------------------------------
# RateLimitError
# ---------------------------------------------------------------------------
def test_rate_limit_error_plain():
    e = RateLimitError("limited")
    assert e.retry_after is None
    assert str(e) == "limited"


def test_rate_limit_error_with_retry():
    e = RateLimitError("limited", retry_after=10)
    assert str(e) == "limited (Retry after: 10s)"


def test_rate_limit_error_with_retry_and_details():
    e = RateLimitError("limited", retry_after=10, details="d")
    assert str(e) == "limited (Retry after: 10s) Details: d"


def test_rate_limit_error_details_only():
    e = RateLimitError("limited", details="d")
    assert str(e) == "limited Details: d"


# ---------------------------------------------------------------------------
# FileOperationError
# ---------------------------------------------------------------------------
def test_file_op_error_plain():
    e = FileOperationError("io")
    assert e.file_path is None
    assert str(e) == "io"


def test_file_op_error_with_path():
    e = FileOperationError("io", file_path="/f")
    assert str(e) == "io (File: /f)"


def test_file_op_error_with_path_and_details():
    e = FileOperationError("io", file_path="/f", details="d")
    assert str(e) == "io (File: /f) Details: d"


def test_file_op_error_details_only():
    e = FileOperationError("io", details="d")
    assert str(e) == "io Details: d"


# ---------------------------------------------------------------------------
# ToolExecutionError
# ---------------------------------------------------------------------------
def test_tool_error_plain():
    e = ToolExecutionError("bad")
    assert e.tool_name is None
    assert str(e) == "bad"


def test_tool_error_with_tool():
    e = ToolExecutionError("bad", tool_name="bash")
    assert str(e) == "bad (Tool: bash)"


def test_tool_error_with_tool_and_details():
    e = ToolExecutionError("bad", tool_name="bash", details="d")
    assert str(e) == "bad (Tool: bash) Details: d"


def test_tool_error_details_only():
    e = ToolExecutionError("bad", details="d")
    assert str(e) == "bad Details: d"


# ---------------------------------------------------------------------------
# BuildCompilationError
# ---------------------------------------------------------------------------
def test_build_error_plain():
    e = BuildCompilationError("fail")
    assert e.exit_code is None
    assert str(e) == "fail"


def test_build_error_with_exit_code():
    e = BuildCompilationError("fail", exit_code=1)
    assert str(e) == "fail (Exit code: 1)"


def test_build_error_exit_code_zero():
    # exit_code is not None -> 0 should still render
    e = BuildCompilationError("fail", exit_code=0)
    assert str(e) == "fail (Exit code: 0)"


def test_build_error_with_exit_code_and_details():
    e = BuildCompilationError("fail", exit_code=2, details="logs")
    assert str(e) == "fail (Exit code: 2) Details: logs"


def test_build_error_details_only():
    e = BuildCompilationError("fail", details="logs")
    assert str(e) == "fail Details: logs"
