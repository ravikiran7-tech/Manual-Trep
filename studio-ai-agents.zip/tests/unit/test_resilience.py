"""Unit tests for app.core.resilience.

Covers retry decorator creation, async circuit breaker, with_circuit_breaker,
with_timeout, with_resilience composite, status/health helpers and reset
functions. Sleeps and tenacity waits are patched so retries never block.
"""
import asyncio

import pytest

import app.core.resilience as res
from app.core.exceptions import (
    CircuitBreakerError,
    OperationTimeoutError,
    ProviderError,
)


def _force_close(breaker):
    """Reset a breaker to closed state without using the (broken on this
    pybreaker version) source reset_circuit_breaker helper."""
    breaker.close()
    breaker._state_storage.reset_counter()


@pytest.fixture(autouse=True)
def _reset_breakers():
    """Keep global circuit breakers clean and order-independent."""
    for cb in (res.bedrock_circuit_breaker, res.portkey_circuit_breaker, res.compass_circuit_breaker):
        _force_close(cb)
    yield
    for cb in (res.bedrock_circuit_breaker, res.portkey_circuit_breaker, res.compass_circuit_breaker):
        _force_close(cb)


@pytest.fixture(autouse=True)
def _no_wait(monkeypatch):
    """Make tenacity waits and asyncio sleeps instantaneous."""
    async def _fast_sleep(*a, **k):
        return None

    monkeypatch.setattr(res.asyncio, "sleep", _fast_sleep)


# ---------------------------------------------------------------------------
# create_retry_decorator
# ---------------------------------------------------------------------------
class TestCreateRetryDecorator:
    async def test_retries_then_succeeds(self, monkeypatch):
        # patch tenacity wait to zero by passing wait_max small + patch sleep
        calls = {"n": 0}

        @res.create_retry_decorator(max_attempts=3, wait_min=0, wait_max=0, multiplier=0,
                                    retry_exceptions=(ProviderError,))
        async def flaky():
            calls["n"] += 1
            if calls["n"] < 3:
                raise ProviderError("transient")
            return "ok"

        # tenacity uses time.sleep for sync but for async retry it awaits;
        # ensure no real wait by zero wait params
        result = await flaky()
        assert result == "ok"
        assert calls["n"] == 3

    async def test_reraises_after_max(self):
        @res.create_retry_decorator(max_attempts=2, wait_min=0, wait_max=0, multiplier=0,
                                    retry_exceptions=(ProviderError,))
        async def always_fail():
            raise ProviderError("nope")

        with pytest.raises(ProviderError):
            await always_fail()

    async def test_defaults_from_config(self):
        # Exercise the branch where args are None -> falls back to config
        dec = res.create_retry_decorator(retry_exceptions=(ProviderError,))
        assert callable(dec)


# ---------------------------------------------------------------------------
# AsyncCircuitBreaker.call_async
# ---------------------------------------------------------------------------
class TestAsyncCircuitBreaker:
    async def test_success(self):
        async def f(x):
            return x * 2

        result = await res.bedrock_circuit_breaker.call_async(f, 5)
        assert result == 10

    async def test_open_circuit_raises(self):
        cb = res.bedrock_circuit_breaker
        cb.open()  # force open
        try:
            with pytest.raises(CircuitBreakerError, match="Circuit breaker is open"):
                async def f():
                    return 1
                await cb.call_async(f)
        finally:
            _force_close(cb)

    async def test_exception_propagates(self):
        async def f():
            raise ProviderError("boom")

        with pytest.raises(ProviderError):
            await res.bedrock_circuit_breaker.call_async(f)


# ---------------------------------------------------------------------------
# with_circuit_breaker decorator
# ---------------------------------------------------------------------------
class TestWithCircuitBreaker:
    async def test_default_breaker_success(self):
        @res.with_circuit_breaker()
        async def f():
            return "ok"

        assert await f() == "ok"

    async def test_explicit_breaker(self):
        @res.with_circuit_breaker(res.portkey_circuit_breaker)
        async def f():
            return 42

        assert await f() == 42

    async def test_pybreaker_open_translated(self, monkeypatch):
        # Make call_async raise pybreaker's error -> translated to CircuitBreakerError
        from pybreaker import CircuitBreakerError as PyErr

        async def fake_call_async(func, *a, **k):
            raise PyErr("open!")

        monkeypatch.setattr(res.bedrock_circuit_breaker, "call_async", fake_call_async)

        @res.with_circuit_breaker(res.bedrock_circuit_breaker)
        async def f():
            return 1

        with pytest.raises(CircuitBreakerError, match="is open"):
            await f()


# ---------------------------------------------------------------------------
# with_timeout decorator
# ---------------------------------------------------------------------------
class TestWithTimeout:
    async def test_completes_within_timeout(self):
        @res.with_timeout(10)
        async def f():
            return "done"

        assert await f() == "done"

    async def test_times_out(self, monkeypatch):
        # Force asyncio.wait_for to raise TimeoutError without real waiting
        async def fake_wait_for(coro, timeout):
            # close the coroutine to avoid "never awaited" warnings
            coro.close()
            raise asyncio.TimeoutError()

        monkeypatch.setattr(res.asyncio, "wait_for", fake_wait_for)

        @res.with_timeout(1)
        async def slow():
            return "never"

        with pytest.raises(OperationTimeoutError, match="timed out"):
            await slow()

    async def test_default_timeout_branch(self):
        @res.with_timeout()
        async def f():
            return "ok"

        assert await f() == "ok"


# ---------------------------------------------------------------------------
# with_resilience composite
# ---------------------------------------------------------------------------
class TestWithResilience:
    async def test_with_circuit_breaker_path(self):
        @res.with_resilience(retry_attempts=2, retry_exceptions=(ProviderError,),
                             use_circuit_breaker=True, operation_name="op1")
        async def f():
            return "ok"

        assert await f() == "ok"
        assert f._resilience_config["operation_name"] == "op1"
        assert f._resilience_config["circuit_breaker"] is not None

    async def test_without_circuit_breaker_path(self):
        @res.with_resilience(use_circuit_breaker=False, retry_exceptions=(ProviderError,))
        async def f():
            return 99

        assert await f() == 99
        assert f._resilience_config["circuit_breaker"] is None

    async def test_retry_then_success(self):
        calls = {"n": 0}

        @res.with_resilience(retry_attempts=3, retry_exceptions=(ProviderError,),
                             use_circuit_breaker=False)
        async def flaky():
            calls["n"] += 1
            if calls["n"] < 2:
                raise ProviderError("retry me")
            return "recovered"

        # patch tenacity wait via create_retry_decorator defaults: ensure quick.
        # The autouse _no_wait patches asyncio.sleep used by tenacity async retry.
        assert await flaky() == "recovered"

    async def test_explicit_circuit_breaker(self):
        @res.with_resilience(circuit_breaker=res.compass_circuit_breaker,
                             retry_exceptions=(ProviderError,))
        async def f():
            return "c"

        assert await f() == "c"
        assert f._resilience_config["circuit_breaker"] == "compass_circuit_breaker"


# ---------------------------------------------------------------------------
# Status / health / reset helpers
# ---------------------------------------------------------------------------
class TestStatusHealthReset:
    def test_get_circuit_breaker_status(self):
        status = res.get_circuit_breaker_status(res.bedrock_circuit_breaker)
        assert status["name"] == "bedrock_circuit_breaker"
        assert status["state"] in ("closed", "open", "half-open")
        assert "fail_counter" in status
        assert "fail_max" in status

    def test_reset_circuit_breaker(self):
        # NOTE: source reset_circuit_breaker references breaker.STATE_CLOSED which
        # does not exist on the installed pybreaker version, so the function body
        # executes up to the AttributeError. We exercise that line and verify the
        # observable behaviour (raises). See report for the source bug.
        cb = res.portkey_circuit_breaker
        with pytest.raises(AttributeError):
            res.reset_circuit_breaker(cb)

    def test_reset_all(self):
        # reset_all delegates to reset_circuit_breaker which raises on this
        # pybreaker version (see test above). Exercises the delegation line.
        with pytest.raises(AttributeError):
            res.reset_all_circuit_breakers()

    def test_get_resilience_health(self):
        health = res.get_resilience_health()
        assert set(health["circuit_breakers"].keys()) == {"bedrock", "portkey", "compass"}
        assert health["rate_limiting"]["enabled"] is True
        assert "max_attempts" in health["retry_config"]
