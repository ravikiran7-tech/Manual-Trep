"""Tests for app.prompts.assessment_rules_batch prompt builders."""
from types import SimpleNamespace

from app.prompts.assessment_rules_batch import (
    ASSESSMENT_RULES_SCHEMA_EXAMPLE,
    ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE,
    build_assessment_rules_batch_prompt,
    format_rules_batch_for_prompt,
)


def test_build_prompt_substitutes_counts_and_schema():
    out = build_assessment_rules_batch_prompt(rules_batch="RULES_HERE", rule_count=3)
    assert "total 3 rules" in out
    assert "exactly 3 objects" in out
    assert "RULES_HERE" in out
    # schema example embedded verbatim
    assert '"detectionSchema"' in out
    assert ASSESSMENT_RULES_SCHEMA_EXAMPLE.strip()[:20] in out


def test_template_constant_is_format_string():
    assert "%(rule_count)d" in ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE
    assert "%(rules_batch)s" in ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE
    assert "%(schema)s" in ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE


def test_format_rules_basic():
    rules = [
        SimpleNamespace(
            rule_id="R1", domain="security", language="java",
            category="Security", issue_type="BLOCKER", severity="HIGH",
            name="SQL Injection", description="detect sqli", example=None,
        ),
        SimpleNamespace(
            rule_id="R2", domain="perf", language="php",
            category="Performance", issue_type="NEUTRAL", severity="MEDIUM",
            name="N+1", description="detect n plus one", example="   ",
        ),
    ]
    out = format_rules_batch_for_prompt(rules)
    assert "1. ruleId: R1" in out
    assert "2. ruleId: R2" in out
    assert "domain: security" in out
    assert "language: php" in out
    assert "name: SQL Injection" in out
    assert "category: Security" in out
    assert "issueType: BLOCKER" in out
    assert "severity: HIGH" in out
    # blank/None examples produce no example line
    assert "example:" not in out


def test_format_rules_with_example():
    rules = [
        SimpleNamespace(
            rule_id="R9", domain="d", language="ts", name="n",
            category="Code Quality", issue_type="NEUTRAL", severity="LOW",
            description="desc", example="  some code  ",
        ),
    ]
    out = format_rules_batch_for_prompt(rules)
    assert "example: some code" in out


def test_prompt_remediation_replaces_pathway_impacts():
    out = build_assessment_rules_batch_prompt(rules_batch="RULES_HERE", rule_count=1)
    assert '"pathwayImpacts"' not in out
    assert "M_UPGRADE" not in out
    assert "Do not emit pathwayImpacts" in out
    assert "Cloud Compatibility" in out
    assert "Software Portability" in out
    assert "Code Sustainability" in out
    assert "Security Health" in out
    assert "ECS Fargate" in out
    assert "ecs-fargate" in out
    assert "BOOSTER" in out
    assert '"isDefault": "True"' in out
    assert "Simple, Trivial, Major, Moderate, Complex" in out
    assert "detailed_description" in out
    assert "Do not add detailed_description" not in out
    assert "Do not shorten or thin it out because detailed_description exists" in out
    assert "Do not invent category, issueType, or severity" in out


def test_format_rules_empty_list():
    assert format_rules_batch_for_prompt([]) == ""


def test_format_rules_example_attribute_missing():
    """Rule object without an `example` attribute (getattr default None)."""
    r = SimpleNamespace(
        rule_id="R", domain="d", language="l", name="n", description="x",
        category="Code Quality", issue_type="NEUTRAL", severity="LOW",
    )
    out = format_rules_batch_for_prompt([r])
    assert "ruleId: R" in out
    assert "example:" not in out