"""Unit tests for app.core.llm_rate_limiter.

Covers TokenBucket refill/acquire/wait, LLMRateLimiter.acquire sequence
(semaphore, recovery, RPM/TPM buckets, adaptive delay), success/throttle
adaptive tuning, disabled mode, metrics, factory resolution and health.

All time and asyncio.sleep are patched so no real waiting occurs.
"""
import asyncio

import pytest

import app.core.llm_rate_limiter as mod
from app.core.llm_rate_limiter import LLMRateLimiter, TokenBucket
from app.core.exceptions import RateLimitError


@pytest.fixture
def fake_clock(monkeypatch):
    """A controllable monotonic clock + no-op async sleep that advances it."""
    state = {"t": 1000.0}

    def now():
        return state["t"]

    async def fake_sleep(seconds):
        state["t"] += max(0.0, seconds)

    monkeypatch.setattr(mod.time, "monotonic", now)
    monkeypatch.setattr(mod.asyncio, "sleep", fake_sleep)
    return state


def make_limiter(**overrides):
    defaults = dict(
        provider="test",
        max_concurrent=2,
        requests_per_minute=60,
        tokens_per_minute=6000,
        initial_delay=0.0,
        min_delay=0.1,
        max_delay=10.0,
        success_threshold=2,
        decrease_factor=0.5,
        increase_factor=2.0,
        throttle_recovery=5.0,
        default_estimated_tokens=100,
        enabled=True,
        enable_adaptive_delays=True,
        enable_token_tracking=True,
    )
    defaults.update(overrides)
    return LLMRateLimiter(**defaults)


# ---------------------------------------------------------------------------
# TokenBucket
# ---------------------------------------------------------------------------
class TestTokenBucket:
    async def test_acquire_when_full(self, fake_clock):
        b = TokenBucket(capacity=10, refill_rate=1.0)
        await b.acquire(5)
        assert b._tokens == pytest.approx(5)

    async def test_caps_request_at_capacity(self, fake_clock):
        b = TokenBucket(capacity=10, refill_rate=100.0)
        # Request more than capacity -> capped to 10, immediately available
        await b.acquire(1000)
        assert b._tokens == pytest.approx(0)

    async def test_waits_then_refills(self, fake_clock):
        b = TokenBucket(capacity=10, refill_rate=10.0)
        await b.acquire(10)  # empties bucket
        assert b._tokens == pytest.approx(0)
        # Next acquire of 5 needs 0.5s of refill; fake sleep advances clock
        await b.acquire(5)
        assert b._tokens == pytest.approx(0, abs=1e-6)

    async def test_refill_caps_at_capacity(self, fake_clock):
        b = TokenBucket(capacity=10, refill_rate=10.0)
        fake_clock["t"] += 100  # lots of elapsed time
        b._refill()
        assert b._tokens == pytest.approx(10)


# ---------------------------------------------------------------------------
# LLMRateLimiter.acquire — disabled
# ---------------------------------------------------------------------------
class TestDisabled:
    async def test_disabled_yields_immediately(self, fake_clock):
        rl = make_limiter(enabled=False)
        async with rl.acquire(estimated_tokens=999):
            pass
        # no metrics recorded
        assert rl.get_metrics()["total_calls"] == 0


# ---------------------------------------------------------------------------
# LLMRateLimiter.acquire — full sequence
# ---------------------------------------------------------------------------
class TestAcquireSequence:
    async def test_basic_success(self, fake_clock):
        rl = make_limiter()
        async with rl.acquire(estimated_tokens=100):
            pass
        m = rl.get_metrics()
        assert m["total_calls"] == 1
        assert m["throttle_count"] == 0

    async def test_default_tokens_used(self, fake_clock):
        rl = make_limiter()
        async with rl.acquire():  # no estimated_tokens -> default
            pass
        assert rl.get_metrics()["total_calls"] == 1

    async def test_no_rpm_no_tpm(self, fake_clock):
        rl = make_limiter(requests_per_minute=0, tokens_per_minute=0)
        assert rl._rpm_bucket is None
        assert rl._tpm_bucket is None
        async with rl.acquire(estimated_tokens=50):
            pass
        assert rl.get_metrics()["total_calls"] == 1

    async def test_token_tracking_disabled(self, fake_clock):
        rl = make_limiter(enable_token_tracking=False)
        assert rl._tpm_bucket is None

    async def test_adaptive_delay_applied(self, fake_clock):
        rl = make_limiter(initial_delay=2.0)
        start = fake_clock["t"]
        async with rl.acquire(estimated_tokens=10):
            pass
        # fake sleep advanced clock by the 2.0s adaptive delay
        assert fake_clock["t"] >= start + 2.0
        # wait_ms > 100 path exercised
        assert rl.get_metrics()["total_wait_ms"] > 100

    async def test_zero_concurrent_uses_large_semaphore(self, fake_clock):
        rl = make_limiter(max_concurrent=0)
        async with rl.acquire(estimated_tokens=10):
            pass
        assert rl.get_metrics()["total_calls"] == 1


# ---------------------------------------------------------------------------
# Throttle / recovery / success tuning
# ---------------------------------------------------------------------------
class TestThrottleAndSuccess:
    async def test_throttle_increases_delay_and_schedules_recovery(self, fake_clock):
        rl = make_limiter(initial_delay=1.0)
        with pytest.raises(RateLimitError):
            async with rl.acquire(estimated_tokens=10):
                raise RateLimitError("429")
        assert rl._current_delay == pytest.approx(2.0)  # 1.0 * increase 2.0
        assert rl._throttle_count == 1
        assert rl._recovery_until > fake_clock["t"]

    async def test_recovery_wait_on_next_acquire(self, fake_clock):
        rl = make_limiter(initial_delay=0.0, throttle_recovery=5.0)
        with pytest.raises(RateLimitError):
            async with rl.acquire(estimated_tokens=10):
                raise RateLimitError("429")
        # Next acquire should consume the recovery wait
        before = fake_clock["t"]
        async with rl.acquire(estimated_tokens=10):
            pass
        assert fake_clock["t"] >= before + 5.0
        assert rl._recovery_until == 0.0

    async def test_non_rate_limit_exception_leaves_delay(self, fake_clock):
        rl = make_limiter(initial_delay=1.0)
        with pytest.raises(ValueError):
            async with rl.acquire(estimated_tokens=10):
                raise ValueError("other")
        assert rl._current_delay == pytest.approx(1.0)  # unchanged
        assert rl._throttle_count == 0

    async def test_success_reduces_delay_after_threshold(self, fake_clock):
        rl = make_limiter(initial_delay=1.0, success_threshold=2, decrease_factor=0.5, min_delay=0.1)
        async with rl.acquire(estimated_tokens=10):
            pass
        assert rl._current_delay == pytest.approx(1.0)  # not yet
        async with rl.acquire(estimated_tokens=10):
            pass
        assert rl._current_delay == pytest.approx(0.5)  # reduced
        assert rl._consecutive_successes == 0

    async def test_success_delay_floors_at_min(self, fake_clock):
        rl = make_limiter(initial_delay=0.1, success_threshold=1, decrease_factor=0.5, min_delay=0.1)
        async with rl.acquire(estimated_tokens=10):
            pass
        assert rl._current_delay == pytest.approx(0.1)  # floored, no log reduction

    async def test_adaptive_disabled_skips_tuning(self, fake_clock):
        rl = make_limiter(enable_adaptive_delays=False, initial_delay=1.0)
        async with rl.acquire(estimated_tokens=10):
            pass
        assert rl._consecutive_successes == 0
        # throttle path on disabled adaptive still counts but no delay change
        with pytest.raises(RateLimitError):
            async with rl.acquire(estimated_tokens=10):
                raise RateLimitError("x")
        assert rl._throttle_count == 1
        assert rl._current_delay == pytest.approx(1.0)

    async def test_throttle_delay_capped_at_max(self, fake_clock):
        rl = make_limiter(initial_delay=8.0, increase_factor=2.0, max_delay=10.0)
        with pytest.raises(RateLimitError):
            async with rl.acquire(estimated_tokens=10):
                raise RateLimitError("x")
        assert rl._current_delay == pytest.approx(10.0)  # capped


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
class TestMetrics:
    async def test_metrics_shape(self, fake_clock):
        rl = make_limiter()
        m = rl.get_metrics()
        for key in ("provider", "enabled", "total_calls", "throttle_count",
                    "total_wait_ms", "avg_wait_ms", "current_delay_s",
                    "consecutive_successes", "recovery_pending_s"):
            assert key in m

    async def test_avg_wait_no_div_by_zero(self, fake_clock):
        rl = make_limiter()
        assert rl.get_metrics()["avg_wait_ms"] == 0.0


# ---------------------------------------------------------------------------
# Factory + module singletons + health
# ---------------------------------------------------------------------------
class TestFactoryAndHealth:
    def test_create_bedrock(self):
        rl = mod._create_rate_limiter("bedrock")
        assert rl.provider == "bedrock"

    def test_create_portkey(self):
        rl = mod._create_rate_limiter("portkey")
        assert rl.provider == "portkey"

    def test_create_unknown_provider(self):
        # override is None -> resolve falls back to global values
        rl = mod._create_rate_limiter("mystery")
        assert rl.provider == "mystery"

    def test_resolve_override_precedence(self, monkeypatch):
        # Build a fake settings with a non-zero bedrock override
        from app.core.config import get_settings
        settings = get_settings()
        cfg = settings.llm_rate_limiter

        class Override:
            requests_per_minute = 123
            tokens_per_minute = 0
            max_concurrent = 0

        original = cfg.bedrock
        cfg.bedrock = Override()
        try:
            rl = mod._create_rate_limiter("bedrock")
            # RPM bucket built from override 123 -> capacity 123
            assert rl._rpm_bucket._capacity == pytest.approx(123.0)
        finally:
            cfg.bedrock = original

    def test_get_health(self):
        health = mod.get_llm_rate_limiter_health()
        assert "bedrock" in health
        assert "portkey" in health
        assert health["bedrock"]["provider"] == "bedrock"
