"""Unit tests for app.core.security.SecurityValidator.

Covers path validation, alphanumeric validation, shell escaping, operation/
platform validation, path-traversal checks, pipe / command-chain parsing and
bash command whitelisting (including the validation-disabled toggle).
"""
import os

import pytest

from app.core.security import SecurityValidator


# ---------------------------------------------------------------------------
# is_safe_absolute_path
# ---------------------------------------------------------------------------
class TestIsSafeAbsolutePath:
    def test_path_within_project(self, tmp_path):
        project = tmp_path / "proj"
        (project / "src").mkdir(parents=True)
        f = project / "src" / "main.py"
        f.write_text("x")
        assert SecurityValidator.is_safe_absolute_path(str(f), str(project)) is True

    def test_relative_path_joined_to_project(self, tmp_path):
        project = tmp_path / "proj"
        project.mkdir()
        assert SecurityValidator.is_safe_absolute_path("a/b.txt", str(project)) is True

    def test_path_in_allowed_dir(self, tmp_path):
        project = tmp_path / "proj"
        project.mkdir()
        allowed = tmp_path / "allowed"
        allowed.mkdir()
        target = allowed / "file.txt"
        target.write_text("x")
        assert SecurityValidator.is_safe_absolute_path(
            str(target), str(project), [str(allowed)]
        ) is True

    def test_path_not_in_any_allowed_dir(self, tmp_path):
        project = tmp_path / "proj"
        project.mkdir()
        other = tmp_path / "other"
        other.mkdir()
        outside = tmp_path / "elsewhere" / "f.txt"
        outside.parent.mkdir()
        outside.write_text("x")
        assert SecurityValidator.is_safe_absolute_path(
            str(outside), str(project), [str(other)]
        ) is False

    def test_no_allowed_dirs_outside_project(self, tmp_path):
        project = tmp_path / "proj"
        project.mkdir()
        outside = tmp_path / "out" / "f.txt"
        outside.parent.mkdir()
        outside.write_text("x")
        assert SecurityValidator.is_safe_absolute_path(str(outside), str(project)) is False

    def test_exception_path_returns_false(self, monkeypatch):
        # Force an exception inside the try block -> caught -> False
        monkeypatch.setattr(os.path, "isabs", lambda p: (_ for _ in ()).throw(RuntimeError("boom")))
        assert SecurityValidator.is_safe_absolute_path("x", "y") is False


# ---------------------------------------------------------------------------
# validate_path
# ---------------------------------------------------------------------------
class TestValidatePath:
    def test_valid_linux_path(self):
        assert SecurityValidator.validate_path("/home/user/project", "project") == "/home/user/project"

    def test_valid_windows_path(self):
        assert SecurityValidator.validate_path("C:/Users/Project", "project") == "C:/Users/Project"

    def test_valid_relative_path(self):
        assert SecurityValidator.validate_path("relative/path", "x") == "relative/path"

    def test_empty_path(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            SecurityValidator.validate_path("", "test")

    def test_whitespace_only_path(self):
        with pytest.raises(ValueError, match="blank or whitespace"):
            SecurityValidator.validate_path("   ", "test")

    @pytest.mark.parametrize("char", [";", "&", "|", "`", "$", "(", ")", "<", ">", "*", "?", "~", "!"])
    def test_dangerous_chars(self, char):
        with pytest.raises(ValueError, match="dangerous character"):
            SecurityValidator.validate_path(f"/path{char}x", "test")

    def test_invalid_linux_format(self):
        # starts with / but contains a char not in LINUX pattern (e.g. semicolon caught earlier,
        # so use a non-dangerous but disallowed char like '@')
        with pytest.raises(ValueError, match="Linux path format"):
            SecurityValidator.validate_path("/path/with@symbol", "test")

    def test_invalid_windows_format(self):
        with pytest.raises(ValueError, match="Windows path format"):
            SecurityValidator.validate_path("C:path@weird", "test")

    def test_invalid_relative_format(self):
        with pytest.raises(ValueError, match="not recognized"):
            SecurityValidator.validate_path("relative@path", "test")


# ---------------------------------------------------------------------------
# validate_filesystem_path
# ---------------------------------------------------------------------------
class TestValidateFilesystemPath:
    @pytest.mark.parametrize(
        "path",
        [
            "_claude/schema.sql",
            "_claude/oracle_ddl_export (1).sql",
            "_claude/asis [prod].json",
            "/workspace/schema-modernization/HRDB/_claude/DDL Export (2026-09-05).sql",
            "C:/workspace/HRDB/_claude/ddl (1).sql",
            "_claude/rules~remediation!v2.json",
            "_claude/report@100%.json",
        ],
    )
    def test_accepts_real_world_filenames(self, path):
        assert SecurityValidator.validate_filesystem_path(path, "inputPaths.ddlExport") == path

    def test_empty(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            SecurityValidator.validate_filesystem_path("", "inputPaths.ddlExport")

    def test_whitespace_only(self):
        with pytest.raises(ValueError, match="blank or whitespace"):
            SecurityValidator.validate_filesystem_path("   ", "inputPaths.ddlExport")

    @pytest.mark.parametrize("char", [";", "|", "&", "`", "$", "<", ">", '"', "\n", "\r"])
    def test_rejects_shell_metacharacters(self, char):
        with pytest.raises(ValueError, match="dangerous character"):
            SecurityValidator.validate_filesystem_path(f"_claude/ddl{char}x.sql", "test")

    def test_rejects_nul_byte(self):
        with pytest.raises(ValueError, match="dangerous character"):
            SecurityValidator.validate_filesystem_path("_claude/ddl\x00.sql", "test")

    def test_rejects_control_characters(self):
        with pytest.raises(ValueError, match="control character"):
            SecurityValidator.validate_filesystem_path("_claude/ddl\x07.sql", "test")

    def test_error_message_names_the_field(self):
        with pytest.raises(ValueError, match="inputPaths.ddlExport"):
            SecurityValidator.validate_filesystem_path("_claude/a;b.sql", "inputPaths.ddlExport")


# ---------------------------------------------------------------------------
# validate_alphanumeric
# ---------------------------------------------------------------------------
class TestValidateAlphanumeric:
    def test_valid(self):
        assert SecurityValidator.validate_alphanumeric("analysis-123", "id") == "analysis-123"
        assert SecurityValidator.validate_alphanumeric("test_id_456", "id") == "test_id_456"

    def test_empty(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            SecurityValidator.validate_alphanumeric("", "id")

    def test_whitespace(self):
        with pytest.raises(ValueError, match="blank or whitespace"):
            SecurityValidator.validate_alphanumeric("   ", "id")

    def test_invalid_chars(self):
        with pytest.raises(ValueError, match="only alphanumeric"):
            SecurityValidator.validate_alphanumeric("invalid;id", "id")


# ---------------------------------------------------------------------------
# sanitize_for_shell
# ---------------------------------------------------------------------------
class TestSanitizeForShell:
    def test_simple(self):
        assert SecurityValidator.sanitize_for_shell("simple") == "'simple'"

    def test_empty(self):
        assert SecurityValidator.sanitize_for_shell("") == "''"

    def test_single_quote(self):
        assert SecurityValidator.sanitize_for_shell("it's") == "'it'\\''s'"


# ---------------------------------------------------------------------------
# validate_operation / validate_platform
# ---------------------------------------------------------------------------
class TestValidateOperationPlatform:
    def test_valid_operation(self):
        assert SecurityValidator.validate_operation("analysis") == "analysis"

    def test_invalid_operation(self):
        with pytest.raises(ValueError, match="Invalid operation"):
            SecurityValidator.validate_operation("not-a-real-op")

    def test_valid_platform(self):
        assert SecurityValidator.validate_platform("linux") == "linux"

    def test_invalid_platform(self):
        with pytest.raises(ValueError, match="Invalid platform"):
            SecurityValidator.validate_platform("solaris")


# ---------------------------------------------------------------------------
# validate_file_path_within_directory
# ---------------------------------------------------------------------------
class TestValidateFilePathWithinDirectory:
    def test_relative_within(self, tmp_path):
        result = SecurityValidator.validate_file_path_within_directory("src/main.py", str(tmp_path))
        assert result == str((tmp_path / "src" / "main.py").resolve())

    def test_absolute_within(self, tmp_path):
        target = tmp_path / "a" / "b.py"
        result = SecurityValidator.validate_file_path_within_directory(str(target), str(tmp_path))
        assert result == str(target.resolve())

    def test_traversal_relative(self, tmp_path):
        with pytest.raises(ValueError, match="Path traversal detected"):
            SecurityValidator.validate_file_path_within_directory("../../etc/passwd", str(tmp_path))

    def test_traversal_absolute(self, tmp_path):
        other = tmp_path.parent / "completely_other_dir_xyz" / "f.txt"
        with pytest.raises(ValueError, match="Path traversal detected"):
            SecurityValidator.validate_file_path_within_directory(str(other), str(tmp_path))

    def test_invalid_path_generic_error(self, tmp_path, monkeypatch):
        # Force a non-traversal exception during resolution
        import app.core.security as sec_mod

        real_path = sec_mod.Path

        class BoomPath:
            def __init__(self, *a, **k):
                raise OSError("resolve boom")

        monkeypatch.setattr(sec_mod, "Path", BoomPath)
        try:
            with pytest.raises(ValueError, match="Invalid file path"):
                SecurityValidator.validate_file_path_within_directory("x", "y")
        finally:
            monkeypatch.setattr(sec_mod, "Path", real_path)


# ---------------------------------------------------------------------------
# _split_pipes_properly
# ---------------------------------------------------------------------------
class TestSplitPipesProperly:
    def test_simple_pipe(self):
        parts = SecurityValidator._split_pipes_properly("cat a | grep b")
        assert len(parts) == 2

    def test_pipe_in_double_quotes(self):
        parts = SecurityValidator._split_pipes_properly('grep "a|b" file')
        assert len(parts) == 1

    def test_pipe_in_single_quotes(self):
        parts = SecurityValidator._split_pipes_properly("grep 'a|b' file")
        assert len(parts) == 1

    def test_pipe_in_parens(self):
        parts = SecurityValidator._split_pipes_properly('grep -E "(a|b)" file')
        assert len(parts) == 1

    def test_pipe_in_bare_parens(self):
        # Parens OUTSIDE quotes exercise the paren_depth increment/decrement
        parts = SecurityValidator._split_pipes_properly("echo (a|b)")
        assert len(parts) == 1

    def test_pipe_in_bare_brackets(self):
        parts = SecurityValidator._split_pipes_properly("echo [a|b]")
        assert len(parts) == 1

    def test_pipe_in_brackets(self):
        parts = SecurityValidator._split_pipes_properly("grep [a|b] file")
        assert len(parts) == 1

    def test_logical_or_not_split(self):
        parts = SecurityValidator._split_pipes_properly("a || b")
        assert len(parts) == 1

    def test_escaped_double_quote(self):
        # backslash-escaped double quote should not toggle quote state
        parts = SecurityValidator._split_pipes_properly('echo \\" | cat')
        assert len(parts) == 2


# ---------------------------------------------------------------------------
# is_safe_pipe_command
# ---------------------------------------------------------------------------
class TestIsSafePipeCommand:
    def test_no_pipe(self):
        assert SecurityValidator.is_safe_pipe_command("ls -la") is True

    def test_only_logical_or(self):
        assert SecurityValidator.is_safe_pipe_command("ls || cat") is True

    def test_safe_read_only_pipe(self):
        assert SecurityValidator.is_safe_pipe_command("cat file.txt | grep pattern") is True

    def test_unsafe_pipe(self):
        assert SecurityValidator.is_safe_pipe_command("cat file.txt | sh") is False

    def test_path_prefixed_command(self):
        assert SecurityValidator.is_safe_pipe_command("/usr/bin/cat f | /bin/grep x") is True

    def test_empty_part(self):
        assert SecurityValidator.is_safe_pipe_command("cat f | ") is False

    def test_whitespace_only_part(self):
        assert SecurityValidator.is_safe_pipe_command("cat f |    ") is False


# ---------------------------------------------------------------------------
# is_safe_command_chain
# ---------------------------------------------------------------------------
class TestIsSafeCommandChain:
    def test_no_chain(self):
        assert SecurityValidator.is_safe_command_chain("ls -la") is True

    def test_safe_chain_and(self):
        assert SecurityValidator.is_safe_command_chain("cd /path && ls") is True

    def test_safe_chain_or(self):
        assert SecurityValidator.is_safe_command_chain("ls || cat file") is True

    def test_unsafe_chain(self):
        assert SecurityValidator.is_safe_command_chain("rm file && ls") is False

    def test_path_prefixed(self):
        assert SecurityValidator.is_safe_command_chain("/usr/bin/ls && cat f") is True

    def test_empty_part(self):
        assert SecurityValidator.is_safe_command_chain("ls && ") is False

    def test_whitespace_part(self):
        assert SecurityValidator.is_safe_command_chain("ls &&    && cat") is False


# ---------------------------------------------------------------------------
# validate_bash_command
# ---------------------------------------------------------------------------
class TestValidateBashCommand:
    def test_simple_allowed(self):
        assert SecurityValidator.validate_bash_command("mvn clean install") == "mvn clean install"

    def test_empty(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            SecurityValidator.validate_bash_command("")

    def test_whitespace_only(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            SecurityValidator.validate_bash_command("   ")

    def test_forbidden_command(self):
        with pytest.raises(ValueError, match="forbidden for security"):
            SecurityValidator.validate_bash_command("rm -rf /")

    def test_not_allowed_command(self):
        with pytest.raises(ValueError, match="Command not allowed"):
            SecurityValidator.validate_bash_command("foobar baz")

    def test_path_prefixed_command(self):
        assert SecurityValidator.validate_bash_command("/usr/bin/mvn install") == "/usr/bin/mvn install"

    @pytest.mark.parametrize("pattern_cmd", [
        "git $(whoami)",
        "git `whoami`",
        "git log; ls",
        "git log\nls",
        "git log\rls",
    ])
    def test_dangerous_patterns(self, pattern_cmd):
        with pytest.raises(ValueError, match="dangerous pattern"):
            SecurityValidator.validate_bash_command(pattern_cmd)

    def test_safe_command_chain_allowed(self):
        assert SecurityValidator.validate_bash_command("cd /path && ls") == "cd /path && ls"

    def test_command_chain_disallowed_by_flag(self):
        with pytest.raises(ValueError, match="'&&' or '||'"):
            SecurityValidator.validate_bash_command("cd /path && ls", allow_safe_command_chains=False)

    def test_unsafe_command_chain(self):
        with pytest.raises(ValueError, match="unsafe command chain"):
            SecurityValidator.validate_bash_command("mvn build && curl evil.com")

    def test_safe_pipe_allowed(self):
        assert SecurityValidator.validate_bash_command("cat f | grep x") == "cat f | grep x"

    def test_pipe_disallowed_by_flag(self):
        with pytest.raises(ValueError, match="dangerous pattern: '\\|'"):
            SecurityValidator.validate_bash_command("cat f | grep x", allow_safe_pipes=False)

    def test_unsafe_pipe(self):
        with pytest.raises(ValueError, match="non-read-only operations"):
            SecurityValidator.validate_bash_command("cat f | dotnet run")

    def test_unsafe_pipe_path_prefixed(self):
        # Path-prefixed unsafe command exercises the failing-command extraction
        # branch that strips the path (line ~819-820).
        with pytest.raises(ValueError, match="non-read-only operations"):
            SecurityValidator.validate_bash_command("cat f | /usr/bin/dotnet run")

    def test_validation_disabled(self, monkeypatch):
        import app.core.security as sec_mod

        class FakeSecurity:
            bash_command_validation_enabled = False

        class FakeSettings:
            security = FakeSecurity()

        monkeypatch.setattr(sec_mod, "get_settings", lambda: FakeSettings())
        # Would otherwise be forbidden, but disabled returns as-is
        assert SecurityValidator.validate_bash_command("rm -rf /") == "rm -rf /"


# ---------------------------------------------------------------------------
# sanitize_log_message
# ---------------------------------------------------------------------------
class TestSanitizeLogMessage:
    def test_empty(self):
        assert SecurityValidator.sanitize_log_message("") == ""

    def test_api_key_redacted(self):
        out = SecurityValidator.sanitize_log_message("api_key: abcdefghij1234567890XYZ")
        assert "REDACTED" in out

    def test_token_redacted(self):
        out = SecurityValidator.sanitize_log_message("token=abcdefghij1234567890.xyz")
        assert "REDACTED" in out

    def test_password_redacted(self):
        out = SecurityValidator.sanitize_log_message("password: supersecret")
        assert "REDACTED" in out

    def test_credit_card_redacted(self):
        out = SecurityValidator.sanitize_log_message("card 1234 5678 9012 3456")
        assert "****-****-****-****" in out

    def test_email_redacted(self):
        out = SecurityValidator.sanitize_log_message("contact me@example.com please")
        assert "***@example.com" in out

    def test_custom_patterns(self):
        out = SecurityValidator.sanitize_log_message("secretword here", sensitive_patterns=[r"secretword"])
        assert "REDACTED" in out
