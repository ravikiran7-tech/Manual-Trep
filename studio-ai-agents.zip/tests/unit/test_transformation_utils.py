"""Tests for app.utils.transformation_utils (FixResultMerger / merge_fix_result)."""
import json

import pytest

from app.utils.transformation_utils import FixResultMerger, merge_fix_result


def _dump(obj):
    return json.dumps(obj)


# ---------------------------------------------------------------------------
# _parse_duration_to_seconds
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "duration,expected",
    [
        ("2m 15s", 135),
        ("1h 2m 15s", 3735),
        ("45s", 45),
        ("1h", 3600),
        ("2m", 120),
        ("", 0),
        ("garbage text", 0),
        ("0s", 0),
    ],
)
def test_parse_duration_to_seconds(duration, expected):
    assert FixResultMerger._parse_duration_to_seconds(duration) == expected


# ---------------------------------------------------------------------------
# _format_seconds_to_duration
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "seconds,expected",
    [
        (0, "0s"),
        (45, "45s"),
        (120, "2m 0s"),
        (135, "2m 15s"),
        (3600, "1h 0s"),
        (3735, "1h 2m 15s"),
    ],
)
def test_format_seconds_to_duration(seconds, expected):
    assert FixResultMerger._format_seconds_to_duration(seconds) == expected


# ---------------------------------------------------------------------------
# merge - top level / error handling
# ---------------------------------------------------------------------------
def test_merge_raises_on_empty_list():
    with pytest.raises(ValueError, match="No valid JSON blocks found"):
        FixResultMerger.merge([])


def test_merge_raises_when_all_blocks_invalid():
    with pytest.raises(ValueError, match="No valid JSON blocks found"):
        FixResultMerger.merge(["not json", "{broken"])


def test_merge_skips_invalid_blocks_and_uses_valid_ones():
    valid = _dump({
        "application": {"duration": "1s", "name": "app"},
        "executiveSummary": {"totalViolations": 1, "violationsResolved": 1},
        "rulesResults": [],
        "fileModifications": [],
        "metadata": {"env": "prod"},
    })
    result = FixResultMerger.merge(["not json", valid])
    assert result["application"]["name"] == "app"
    assert result["executiveSummary"]["totalViolations"] == 1


def test_merge_fix_result_function_delegates_to_merger():
    valid = _dump({
        "application": {"duration": "1s"},
        "executiveSummary": {},
        "rulesResults": [],
        "fileModifications": [],
        "metadata": None,
    })
    result = merge_fix_result([valid])
    assert set(result.keys()) == {
        "application", "executiveSummary", "rulesResults",
        "fileModifications", "metadata",
    }


# ---------------------------------------------------------------------------
# _merge_application
# ---------------------------------------------------------------------------
def test_merge_application_sums_durations_and_keeps_first_fields():
    blocks = [
        {"application": {"duration": "1m 0s", "name": "app", "version": "1.0"}},
        {"application": {"duration": "30s"}},
    ]
    merged = FixResultMerger._merge_application(blocks)
    assert merged["duration"] == "1m 30s"
    assert merged["name"] == "app"
    assert merged["version"] == "1.0"
    assert "completedOn" in merged


def test_merge_application_missing_application_key_defaults_empty():
    blocks = [{}, {"application": {"duration": "10s"}}]
    merged = FixResultMerger._merge_application(blocks)
    assert merged["duration"] == "10s"


def test_merge_application_missing_duration_contributes_zero():
    blocks = [{"application": {"name": "app"}}, {"application": {"duration": "5s"}}]
    merged = FixResultMerger._merge_application(blocks)
    assert merged["duration"] == "5s"


def test_merge_application_first_block_application_none():
    blocks = [{"application": None}, {"application": {"duration": "5s"}}]
    merged = FixResultMerger._merge_application(blocks)
    assert merged["duration"] == "5s"


# ---------------------------------------------------------------------------
# _merge_executive_summary
# ---------------------------------------------------------------------------
def test_merge_executive_summary_sums_fields_and_computes_success_rate():
    blocks = [
        {"executiveSummary": {
            "blockerTypes": 1, "totalRulesProcessed": 2, "totalViolations": 10,
            "violationsResolved": 8, "violationsFailed": 2, "filesModified": 3,
        }},
        {"executiveSummary": {
            "blockerTypes": 1, "totalRulesProcessed": 1, "totalViolations": 5,
            "violationsResolved": 5, "violationsFailed": 0, "filesModified": 2,
        }},
    ]
    merged = FixResultMerger._merge_executive_summary(blocks)
    assert merged["totalViolations"] == 15
    assert merged["violationsResolved"] == 13
    assert merged["filesModified"] == 5
    assert merged["successRate"] == round((13 / 15) * 100, 2)


def test_merge_executive_summary_zero_total_violations_gives_zero_rate():
    blocks = [{"executiveSummary": {}}]
    merged = FixResultMerger._merge_executive_summary(blocks)
    assert merged["totalViolations"] == 0
    assert merged["successRate"] == 0


def test_merge_executive_summary_missing_key_and_none_values():
    blocks = [{}, {"executiveSummary": {"totalViolations": None, "violationsResolved": 3}}]
    merged = FixResultMerger._merge_executive_summary(blocks)
    assert merged["totalViolations"] == 0
    assert merged["violationsResolved"] == 3


# ---------------------------------------------------------------------------
# _merge_rules_results
# ---------------------------------------------------------------------------
def test_merge_rules_results_combines_same_rule_name():
    blocks = [
        {"rulesResults": [
            {"ruleName": "R1", "filesImpacted": 1, "violations": 2, "success": 2, "failed": 0},
        ]},
        {"rulesResults": [
            {"ruleName": "R1", "filesImpacted": 1, "violations": 1, "success": 1, "failed": 0},
        ]},
    ]
    merged = FixResultMerger._merge_rules_results(blocks)
    assert len(merged) == 1
    r1 = merged[0]
    assert r1["filesImpacted"] == 2
    assert r1["violations"] == 3
    assert r1["success"] == 3
    assert r1["failed"] == 0


def test_merge_rules_results_appends_new_rule_names_preserving_order():
    blocks = [
        {"rulesResults": [{"ruleName": "R1", "filesImpacted": 1, "violations": 1, "success": 1, "failed": 0}]},
        {"rulesResults": [{"ruleName": "R2", "filesImpacted": 2, "violations": 2, "success": 1, "failed": 1}]},
    ]
    merged = FixResultMerger._merge_rules_results(blocks)
    assert [r["ruleName"] for r in merged] == ["R1", "R2"]


def test_merge_rules_results_missing_key_and_empty_blocks():
    blocks = [{}, {"rulesResults": None}, {"rulesResults": []}]
    merged = FixResultMerger._merge_rules_results(blocks)
    assert merged == []


def test_merge_rules_results_missing_numeric_fields_default_to_zero():
    blocks = [
        {"rulesResults": [{"ruleName": "R1"}]},
        {"rulesResults": [{"ruleName": "R1", "violations": 4}]},
    ]
    merged = FixResultMerger._merge_rules_results(blocks)
    assert merged[0]["violations"] == 4
    assert merged[0]["filesImpacted"] == 0


# ---------------------------------------------------------------------------
# _merge_file_modifications
# ---------------------------------------------------------------------------
def test_merge_file_modifications_sums_numeric_and_concats_lists():
    blocks = [
        {"fileModifications": [
            {"filePath": "A.java", "linesChanged": 5, "issues": ["x"]},
        ]},
        {"fileModifications": [
            {"filePath": "A.java", "linesChanged": 3, "issues": ["y"]},
        ]},
    ]
    merged = FixResultMerger._merge_file_modifications(blocks)
    assert len(merged) == 1
    entry = merged[0]
    assert entry["filePath"] == "A.java"
    assert entry["linesChanged"] == 8
    assert entry["issues"] == ["x", "y"]


def test_merge_file_modifications_new_file_path_appended_in_order():
    blocks = [
        {"fileModifications": [{"filePath": "A.java", "linesChanged": 1}]},
        {"fileModifications": [{"filePath": "B.java", "linesChanged": 2}]},
    ]
    merged = FixResultMerger._merge_file_modifications(blocks)
    assert [m["filePath"] for m in merged] == ["A.java", "B.java"]


def test_merge_file_modifications_bool_value_not_summed():
    blocks = [
        {"fileModifications": [{"filePath": "A.java", "success": True}]},
        {"fileModifications": [{"filePath": "A.java", "success": False}]},
    ]
    merged = FixResultMerger._merge_file_modifications(blocks)
    # bool is excluded from numeric summation branch -> not summed, no key overwrite path taken
    assert merged[0]["filePath"] == "A.java"


def test_merge_file_modifications_missing_list_default_to_empty():
    blocks = [{}, {"fileModifications": None}, {"fileModifications": []}]
    merged = FixResultMerger._merge_file_modifications(blocks)
    assert merged == []


def test_merge_file_modifications_existing_list_field_none_defaults_to_empty():
    blocks = [
        {"fileModifications": [{"filePath": "A.java"}]},
        {"fileModifications": [{"filePath": "A.java", "issues": ["z"]}]},
    ]
    merged = FixResultMerger._merge_file_modifications(blocks)
    assert merged[0]["issues"] == ["z"]


# ---------------------------------------------------------------------------
# _merge_metadata
# ---------------------------------------------------------------------------
def test_merge_metadata_none_when_first_block_missing_metadata():
    blocks = [{}, {"metadata": {"a": 1}}]
    assert FixResultMerger._merge_metadata(blocks) is None


def test_merge_metadata_identical_across_blocks_returned_as_is():
    meta = {"env": "prod", "version": "1.0"}
    blocks = [{"metadata": meta}, {"metadata": dict(meta)}]
    result = FixResultMerger._merge_metadata(blocks)
    assert result == meta
    assert "_mergeWarning" not in result


def test_merge_metadata_differs_adds_merge_warning():
    blocks = [{"metadata": {"env": "prod"}}, {"metadata": {"env": "staging"}}]
    result = FixResultMerger._merge_metadata(blocks)
    assert result["env"] == "prod"
    assert "_mergeWarning" in result


# ---------------------------------------------------------------------------
# merge - full integration across all sections
# ---------------------------------------------------------------------------
def test_merge_full_integration_two_blocks():
    block1 = _dump({
        "application": {"duration": "1m 0s", "name": "app"},
        "executiveSummary": {
            "totalViolations": 4, "violationsResolved": 4, "filesModified": 1,
        },
        "rulesResults": [
            {"ruleName": "R1", "filesImpacted": 1, "violations": 4, "success": 4, "failed": 0},
        ],
        "fileModifications": [
            {"filePath": "A.java", "linesChanged": 4},
        ],
        "metadata": {"env": "prod"},
    })
    block2 = _dump({
        "application": {"duration": "30s"},
        "executiveSummary": {
            "totalViolations": 2, "violationsResolved": 1, "filesModified": 1,
        },
        "rulesResults": [
            {"ruleName": "R1", "filesImpacted": 1, "violations": 2, "success": 1, "failed": 1},
            {"ruleName": "R2", "filesImpacted": 1, "violations": 1, "success": 1, "failed": 0},
        ],
        "fileModifications": [
            {"filePath": "B.java", "linesChanged": 2},
        ],
        "metadata": {"env": "prod"},
    })
    result = FixResultMerger.merge([block1, block2])

    assert result["application"]["duration"] == "1m 30s"
    assert result["application"]["name"] == "app"

    summary = result["executiveSummary"]
    assert summary["totalViolations"] == 6
    assert summary["violationsResolved"] == 5
    assert summary["successRate"] == round((5 / 6) * 100, 2)

    rules = {r["ruleName"]: r for r in result["rulesResults"]}
    assert rules["R1"]["violations"] == 6
    assert rules["R1"]["failed"] == 1
    assert rules["R2"]["violations"] == 1

    files = {f["filePath"]: f for f in result["fileModifications"]}
    assert files["A.java"]["linesChanged"] == 4
    assert files["B.java"]["linesChanged"] == 2

    assert result["metadata"] == {"env": "prod"}
