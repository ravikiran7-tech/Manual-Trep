"""Additional unit tests for app.utils.stream_utils.

Covers StreamParser methods, builders, convenience functions, and edge cases
not already exercised by tests/unit/test_stream_utils.py.
"""
import json
from pathlib import Path

import pytest

from app.utils.stream_utils import (
    StreamParser,
    StreamEventBuilder,
    _extract_single_json_block_robust,
    parse_stream_file,
    extract_response_from_stream,
)


def _write_jsonl(tmp_path: Path, events) -> Path:
    p = tmp_path / "stream.jsonl"
    lines = [json.dumps(e) for e in events]
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# parse_stream_file (static method)
# ---------------------------------------------------------------------------
class TestParseStreamFile:
    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="Stream file not found"):
            StreamParser.parse_stream_file(tmp_path / "nope.jsonl")

    def test_parses_valid_lines_skips_blank_and_malformed(self, tmp_path):
        p = tmp_path / "s.jsonl"
        p.write_text(
            '{"type": "system"}\n'
            "\n"  # blank skipped
            "   \n"  # whitespace skipped
            "{ not json\n"  # malformed -> warning, skipped
            '{"type": "result"}\n',
            encoding="utf-8",
        )
        events = StreamParser.parse_stream_file(p)
        assert len(events) == 2
        assert events[0]["type"] == "system"
        assert events[1]["type"] == "result"

    def test_read_error_propagates(self, tmp_path, monkeypatch):
        p = tmp_path / "s.jsonl"
        p.write_text('{"type":"x"}\n', encoding="utf-8")

        import app.utils.stream_utils as mod

        def boom(*a, **k):
            raise OSError("disk error")

        monkeypatch.setattr(mod, "open", boom, raising=False)
        with pytest.raises(OSError, match="disk error"):
            StreamParser.parse_stream_file(p)


# ---------------------------------------------------------------------------
# extract_final_result
# ---------------------------------------------------------------------------
class TestExtractFinalResult:
    def test_returns_last_result(self):
        events = [
            {"type": "result", "id": 1},
            {"type": "assistant"},
            {"type": "result", "id": 2},
        ]
        assert StreamParser.extract_final_result(events)["id"] == 2

    def test_none_when_absent(self):
        assert StreamParser.extract_final_result([{"type": "assistant"}]) is None


# ---------------------------------------------------------------------------
# extract_assistant_messages / full response
# ---------------------------------------------------------------------------
class TestAssistantMessages:
    def test_collects_text_deltas(self):
        events = [
            {"type": "assistant", "subtype": "text_delta", "text": "Hello "},
            {"type": "assistant", "subtype": "text_delta", "text": "world"},
            {"type": "assistant", "subtype": "text_delta", "text": ""},  # empty skipped
            {"type": "assistant", "subtype": "other", "text": "ignored"},  # wrong subtype
            {"type": "user", "subtype": "text_delta", "text": "nope"},  # wrong type
        ]
        msgs = StreamParser.extract_assistant_messages(events)
        assert msgs == ["Hello ", "world"]

    def test_full_response_concatenates(self):
        events = [
            {"type": "assistant", "subtype": "text_delta", "text": "foo"},
            {"type": "assistant", "subtype": "text_delta", "text": "bar"},
        ]
        assert StreamParser.extract_full_assistant_response(events) == "foobar"

    def test_full_response_empty(self):
        assert StreamParser.extract_full_assistant_response([]) == ""


# ---------------------------------------------------------------------------
# extract_tool_use_events
# ---------------------------------------------------------------------------
class TestToolUseEvents:
    def test_collects_tool_use(self):
        events = [
            {"type": "tool_use", "name": "Read"},
            {"type": "assistant"},
            {"type": "tool_use", "name": "Write"},
        ]
        tools = StreamParser.extract_tool_use_events(events)
        assert [t["name"] for t in tools] == ["Read", "Write"]

    def test_empty_when_none(self):
        assert StreamParser.extract_tool_use_events([{"type": "assistant"}]) == []


# ---------------------------------------------------------------------------
# extract_metadata
# ---------------------------------------------------------------------------
class TestExtractMetadata:
    def test_from_result(self):
        events = [
            {"type": "result", "input_tokens": 10, "output_tokens": 5,
             "stop_reason": "end_turn", "is_error": False},
        ]
        md = StreamParser.extract_metadata(events)
        assert md["input_tokens"] == 10
        assert md["output_tokens"] == 5
        assert md["total_tokens"] == 15
        assert md["stop_reason"] == "end_turn"
        assert md["is_error"] is False

    def test_no_result_defaults(self):
        md = StreamParser.extract_metadata([{"type": "assistant"}])
        assert md["total_tokens"] == 0
        assert md["stop_reason"] is None
        assert md["is_error"] is False

    def test_error_event_sets_flags(self):
        events = [
            {"type": "result", "input_tokens": 1, "output_tokens": 1},
            {"type": "error", "error": "boom"},
        ]
        md = StreamParser.extract_metadata(events)
        assert md["is_error"] is True
        assert md["error_message"] == "boom"

    def test_error_event_default_message(self):
        md = StreamParser.extract_metadata([{"type": "error"}])
        assert md["is_error"] is True
        assert md["error_message"] == "Unknown error"


# ---------------------------------------------------------------------------
# is_stream_successful
# ---------------------------------------------------------------------------
class TestIsStreamSuccessful:
    def test_success(self):
        events = [{"type": "result", "is_error": False}]
        assert StreamParser.is_stream_successful(events) is True

    def test_failure(self):
        events = [{"type": "error", "error": "x"}]
        assert StreamParser.is_stream_successful(events) is False


# ---------------------------------------------------------------------------
# extract_json_blocks / parse_json_block
# ---------------------------------------------------------------------------
class TestJsonBlocks:
    def test_robust_path_valid(self):
        text = '```json\n{"a": 1}\n```'
        assert StreamParser.extract_json_blocks(text) == ['{"a": 1}']

    def test_fallback_when_robust_invalid_json(self):
        # robust extractor returns a substring that is NOT valid JSON ->
        # falls through to regex, which captures the raw (still invalid) text.
        text = '```json\n{"a": 1,}\n```'  # trailing comma invalid
        blocks = StreamParser.extract_json_blocks(text)
        assert len(blocks) == 1
        assert "a" in blocks[0]

    def test_no_block(self):
        assert StreamParser.extract_json_blocks("plain text") == []

    def test_parse_json_block_first_valid(self):
        text = '```json\n{"k": "v"}\n```'
        assert StreamParser.parse_json_block(text) == {"k": "v"}

    def test_parse_json_block_no_blocks(self):
        assert StreamParser.parse_json_block("nothing") is None

    def test_parse_json_block_all_invalid(self, monkeypatch):
        # Force extract_json_blocks to yield only invalid blocks so the loop
        # exhausts and returns None.
        monkeypatch.setattr(
            StreamParser, "extract_json_blocks",
            staticmethod(lambda t: ["{bad json", "also bad}"]),
        )
        assert StreamParser.parse_json_block("anything") is None


# ---------------------------------------------------------------------------
# _extract_single_json_block_robust edge cases
# ---------------------------------------------------------------------------
class TestRobustExtractorEdges:
    def test_block_marker_but_no_opening_bracket(self):
        # ```json followed by non-{[ char -> returns None
        assert _extract_single_json_block_robust("```json\nhello") is None

    def test_block_marker_at_eof(self):
        # ```json then only whitespace then EOF -> i>=n -> None
        assert _extract_single_json_block_robust("```json\n   ") is None

    def test_unterminated_block_returns_none(self):
        # opens brace but never closes -> scanning falls off end -> None
        assert _extract_single_json_block_robust('```json\n{"a": 1') is None

    def test_escaped_quote_inside_string(self):
        text = '```json\n{"a": "he said \\"hi\\""}\n```'
        block, _ = _extract_single_json_block_robust(text)
        assert json.loads(block)["a"] == 'he said "hi"'

    def test_multiple_whitespace_chars_before_bracket(self):
        # Several whitespace chars after ```json marker force the
        # whitespace-skip loop to iterate (advances past spaces/tabs/newlines).
        text = '```json \t\n\r  {"a": 1}\n```'
        block, _ = _extract_single_json_block_robust(text)
        assert json.loads(block) == {"a": 1}


# ---------------------------------------------------------------------------
# filter_events_by_type
# ---------------------------------------------------------------------------
class TestFilterEvents:
    def test_filter_by_type_only(self):
        events = [
            {"type": "assistant", "subtype": "text_delta"},
            {"type": "user"},
            {"type": "assistant", "subtype": "other"},
        ]
        out = StreamParser.filter_events_by_type(events, "assistant")
        assert len(out) == 2

    def test_filter_by_type_and_subtype(self):
        events = [
            {"type": "assistant", "subtype": "text_delta"},
            {"type": "assistant", "subtype": "other"},
        ]
        out = StreamParser.filter_events_by_type(events, "assistant", "text_delta")
        assert len(out) == 1
        assert out[0]["subtype"] == "text_delta"

    def test_filter_no_match(self):
        assert StreamParser.filter_events_by_type([{"type": "x"}], "y") == []


# ---------------------------------------------------------------------------
# extract_costs
# ---------------------------------------------------------------------------
class TestExtractCosts:
    def test_no_result_returns_none(self):
        assert StreamParser.extract_costs([{"type": "assistant"}]) is None

    def test_result_without_costs_returns_none(self):
        assert StreamParser.extract_costs([{"type": "result"}]) is None

    def test_all_costs(self):
        events = [{"type": "result", "input_cost": 0.1,
                   "output_cost": 0.2, "total_cost": 0.3}]
        costs = StreamParser.extract_costs(events)
        assert costs == {"input_cost": 0.1, "output_cost": 0.2, "total_cost": 0.3}

    def test_partial_costs(self):
        events = [{"type": "result", "total_cost": 0.5}]
        assert StreamParser.extract_costs(events) == {"total_cost": 0.5}


# ---------------------------------------------------------------------------
# StreamEventBuilder
# ---------------------------------------------------------------------------
class TestStreamEventBuilder:
    def test_system_event(self):
        ev = StreamEventBuilder.create_system_event("init")
        assert ev["type"] == "system"
        assert ev["subtype"] == "init"
        assert isinstance(ev["timestamp"], int)

    def test_assistant_text_delta(self):
        ev = StreamEventBuilder.create_assistant_text_delta("hi")
        assert ev["type"] == "assistant"
        assert ev["subtype"] == "text_delta"
        assert ev["text"] == "hi"

    def test_result_event(self):
        ev = StreamEventBuilder.create_result_event(10, 20, "max_tokens", True)
        assert ev["type"] == "result"
        assert ev["input_tokens"] == 10
        assert ev["output_tokens"] == 20
        assert ev["stop_reason"] == "max_tokens"
        assert ev["is_error"] is True

    def test_result_event_defaults(self):
        ev = StreamEventBuilder.create_result_event(1, 2)
        assert ev["stop_reason"] == "end_turn"
        assert ev["is_error"] is False

    def test_error_event(self):
        ev = StreamEventBuilder.create_error_event("oops")
        assert ev["type"] == "error"
        assert ev["error"] == "oops"


# ---------------------------------------------------------------------------
# Convenience module-level functions
# ---------------------------------------------------------------------------
class TestConvenienceFunctions:
    def test_parse_stream_file_returns_events_and_metadata(self, tmp_path):
        events = [
            StreamEventBuilder.create_assistant_text_delta("hello"),
            StreamEventBuilder.create_result_event(7, 3),
        ]
        p = _write_jsonl(tmp_path, events)
        parsed_events, metadata = parse_stream_file(p)
        assert len(parsed_events) == 2
        assert metadata["total_tokens"] == 10

    def test_extract_response_from_stream(self, tmp_path):
        events = [
            StreamEventBuilder.create_assistant_text_delta("foo"),
            StreamEventBuilder.create_assistant_text_delta("bar"),
        ]
        p = _write_jsonl(tmp_path, events)
        assert extract_response_from_stream(p) == "foobar"