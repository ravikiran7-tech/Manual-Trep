"""Tests for app.core.config."""
import pytest

import app.core.config as config_mod
from app.core.config import (
    parse_comma_separated_list,
    BedrockConfig,
    PortkeyConfig,
    ResilienceConfig,
    TimeoutConfig,
    WorkspaceConfig,
    StudioCoreConfig,
    OpenAICompatibleConfig,
    AgenticConfig,
    BedrockRateLimiterConfig,
    PortkeyRateLimiterConfig,
    LLMRateLimiterConfig,
    SecurityConfig,
    NatsConfig,
    Settings,
    get_settings,
    reload_settings,
)


# ---------------------------------------------------------------------------
# parse_comma_separated_list
# ---------------------------------------------------------------------------
def test_parse_csv_none():
    assert parse_comma_separated_list(None) == []


def test_parse_csv_string():
    assert parse_comma_separated_list("a, b ,c") == ["a", "b", "c"]


def test_parse_csv_string_with_empties():
    assert parse_comma_separated_list("a,,b, ,c") == ["a", "b", "c"]


def test_parse_csv_list_passthrough():
    assert parse_comma_separated_list(["x", "y"]) == ["x", "y"]


def test_parse_csv_other_type():
    assert parse_comma_separated_list(123) == []


# ---------------------------------------------------------------------------
# Nested config defaults
# ---------------------------------------------------------------------------
def test_bedrock_config_defaults():
    c = BedrockConfig()
    assert c.region == "us-east-1"
    assert c.profile is None
    assert c.max_tokens == 64000
    assert c.temperature == 0.0


def test_portkey_config_default():
    assert PortkeyConfig().base_url == "https://api.portkey.ai/v1"


def test_resilience_config_defaults():
    c = ResilienceConfig()
    assert c.retry_max_attempts == 3
    assert c.circuit_breaker_fail_threshold == 5
    assert c.rate_limit_per_minute == 60


def test_timeout_config_defaults():
    c = TimeoutConfig()
    assert c.default == 3000
    assert c.upgrade_operations == 3600
    assert c.build_compilation == 1800


def test_workspace_config_default():
    assert WorkspaceConfig().base_path  # set from env WORKSPACE_BASE_PATH


def test_studio_core_config():
    c = StudioCoreConfig(base_url="http://x")
    assert c.base_url == "http://x"
    assert c.compass_component == "Platform Model"
    assert c.timeout == 60


def test_openai_compatible_config_defaults():
    """Generation knobs must carry their own defaults: without them the private
    LLM silently inherits the Bedrock max_tokens/temperature."""
    c = OpenAICompatibleConfig()
    assert c.max_tokens == 64000
    assert c.temperature == 0.0
    assert c.enable_thinking is None
    assert c.timeout == 3600.0


def test_openai_compatible_config_reads_env(monkeypatch):
    monkeypatch.setenv("OPENAI_COMPAT_MAX_TOKENS", "8192")
    monkeypatch.setenv("OPENAI_COMPAT_TEMPERATURE", "0.7")
    c = OpenAICompatibleConfig()
    assert c.max_tokens == 8192
    assert c.temperature == 0.7


def test_openai_compatible_config_has_no_connection_fields():
    """base_url / default_model / api_key come from Compass per call."""
    fields = set(OpenAICompatibleConfig.model_fields)
    assert fields == {"max_tokens", "temperature", "enable_thinking", "timeout", "stream"}


def test_agentic_config_defaults():
    c = AgenticConfig()
    assert c.enabled is True
    assert c.max_iterations == 10
    assert c.unlimited_iterations is True
    assert c.skip_validation is True


def test_bedrock_rate_limiter_defaults():
    c = BedrockRateLimiterConfig()
    assert c.requests_per_minute == 0
    assert c.tokens_per_minute == 0
    assert c.max_concurrent == 0


def test_portkey_rate_limiter_defaults():
    c = PortkeyRateLimiterConfig()
    assert c.requests_per_minute == 0


def test_llm_rate_limiter_defaults():
    c = LLMRateLimiterConfig()
    # env sets enabled=false
    assert c.enabled is False
    assert c.requests_per_minute == 30
    assert c.tokens_per_minute == 100000
    assert c.max_concurrent == 5
    assert isinstance(c.bedrock, BedrockRateLimiterConfig)
    assert isinstance(c.portkey, PortkeyRateLimiterConfig)


# ---------------------------------------------------------------------------
# SecurityConfig
# ---------------------------------------------------------------------------
def test_security_config_defaults():
    c = SecurityConfig()
    assert c.validation_enabled is True
    assert c.allowed_directories == "/test-code,/studio-app"


def test_security_get_allowed_directories_list():
    c = SecurityConfig()
    assert c.get_allowed_directories_list() == ["/test-code", "/studio-app"]


def test_security_get_allowed_directories_list_custom():
    c = SecurityConfig(allowed_directories="/a, /b , ,/c")
    assert c.get_allowed_directories_list() == ["/a", "/b", "/c"]


def test_security_get_allowed_directories_list_non_str():
    # Defensive branch: when allowed_directories is not a string, return [].
    c = SecurityConfig()
    object.__setattr__(c, "allowed_directories", ["/a", "/b"])
    assert c.get_allowed_directories_list() == []


# ---------------------------------------------------------------------------
# NatsConfig
# ---------------------------------------------------------------------------
def test_nats_config_defaults():
    c = NatsConfig()
    # env sets NATS_ENABLED=false
    assert c.enabled is False
    assert c.servers == ["nats://localhost:4222"]
    assert c.client_name == "studio-ai-agents"
    assert c.schema_generate_request_subject == "schema.generate.request"


def test_nats_servers_csv_parsing():
    c = NatsConfig(servers="nats://a:4222, nats://b:4222")
    assert c.servers == ["nats://a:4222", "nats://b:4222"]


def test_nats_servers_none():
    c = NatsConfig(servers=None)
    assert c.servers == []


def test_nats_servers_list():
    c = NatsConfig(servers=["nats://x:4222"])
    assert c.servers == ["nats://x:4222"]


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
def test_settings_builds(settings):
    assert settings.app_name == "studio-ai-engine-python"
    assert settings.debug is True
    assert settings.studio_core_url
    # nested configs initialized
    assert settings.bedrock is not None
    assert settings.studio_core is not None
    assert settings.studio_core.base_url == settings.studio_core_url


def test_settings_cors_default_list(settings):
    assert settings.cors_allow_origins == ["*"]


def test_settings_cors_parse_string():
    s = Settings(cors_allow_origins="http://a, http://b")
    assert s.cors_allow_origins == ["http://a", "http://b"]


def test_settings_cors_parse_list_passthrough():
    s = Settings(cors_allow_methods=["GET", "POST"])
    assert s.cors_allow_methods == ["GET", "POST"]


def test_settings_cors_all_three_fields():
    s = Settings(
        cors_allow_origins="a,b",
        cors_allow_methods="GET",
        cors_allow_headers="X-Custom",
    )
    assert s.cors_allow_origins == ["a", "b"]
    assert s.cors_allow_methods == ["GET"]
    assert s.cors_allow_headers == ["X-Custom"]


# ---------------------------------------------------------------------------
# get_timeout_for_operation
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("operation,attr", [
    ("fix-upgrade", "upgrade_operations"),
    ("cloudreadiness-fix", "upgrade_operations"),
    ("db-code-modernize-fix", "upgrade_operations"),
    ("schema-modernization", "schema_modernization"),
    ("build-compilation", "build_compilation"),
    ("dotnet-build-compilation", "build_compilation"),
    ("analysis", "default"),
    ("anything-else", "default"),
])
def test_get_timeout_for_operation(settings, operation, attr):
    expected = getattr(settings.timeouts, attr)
    assert settings.get_timeout_for_operation(operation) == expected


# ---------------------------------------------------------------------------
# Singleton get_settings / reload_settings
# ---------------------------------------------------------------------------
def test_get_settings_singleton(reset_settings_singleton):
    s1 = get_settings()
    s2 = get_settings()
    assert s1 is s2


def test_get_settings_fast_path(reset_settings_singleton):
    # First call populates the singleton, second returns via fast path.
    config_mod.settings = None
    first = get_settings()
    assert config_mod.settings is first
    # fast path: settings is not None
    second = get_settings()
    assert second is first


def test_reload_settings_creates_new(reset_settings_singleton):
    first = get_settings()
    reloaded = reload_settings()
    assert reloaded is not first
    assert config_mod.settings is reloaded


def test_reload_settings_when_none(reset_settings_singleton):
    config_mod.settings = None
    s = reload_settings()
    assert s is not None
    assert isinstance(s, Settings)