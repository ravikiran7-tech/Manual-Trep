"""Tests for app.utils.path_utils.

NOTE: app/utils/path_utils.py currently fails to import under Python 3.13 due to
a pre-existing SyntaxError: the docstring of ``convert_to_wsl_path`` contains the
literal text ``C:\\Users\\test`` (an unescaped ``\\U`` sequence) which Python 3.13
rejects as a truncated ``\\UXXXXXXXX`` unicode escape. Since source under app/ may
not be modified, these tests are skipped when the module cannot be imported. The
tests themselves are complete and will run/pass once the source escape is fixed.
"""
import platform as platform_mod
from pathlib import Path
from unittest.mock import patch

import pytest

try:
    from app.utils.path_utils import (
        PathUtils,
        to_wsl_path,
        to_windows_path,
        normalize_for_platform,
        resolve_secure_work_directory,
    )
    _IMPORT_ERROR = None
except SyntaxError as exc:  # pragma: no cover - pre-existing source defect
    _IMPORT_ERROR = exc

pytestmark = pytest.mark.skipif(
    _IMPORT_ERROR is not None,
    reason=f"app.utils.path_utils has a pre-existing SyntaxError: {_IMPORT_ERROR}",
)


# ---------------------------------------------------------------------------
# is_windows_path / is_wsl_path
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("path,expected", [
    ("C:\\Users\\test", True),
    ("D:/foo", True),
    ("z:\\bar", True),
    ("/home/user", False),
    ("/mnt/c/foo", False),
    ("relative/path", False),
])
def test_is_windows_path(path, expected):
    assert PathUtils.is_windows_path(path) is expected


@pytest.mark.parametrize("path,expected", [
    ("/mnt/c/Users/test", True),
    ("/mnt/d/foo", True),
    ("/home/user", False),
    ("/mnt/", False),       # len <= 6
    ("/mnt/cc", True),      # len > 6
    ("C:\\foo", False),
])
def test_is_wsl_path(path, expected):
    assert PathUtils.is_wsl_path(path) is expected


# ---------------------------------------------------------------------------
# convert_to_wsl_path
# ---------------------------------------------------------------------------
def test_convert_to_wsl_path():
    assert PathUtils.convert_to_wsl_path("C:\\Users\\test\\file.txt") == "/mnt/c/Users/test/file.txt"


def test_convert_to_wsl_path_forward_slashes():
    assert PathUtils.convert_to_wsl_path("D:/foo/bar") == "/mnt/d/foo/bar"


def test_convert_to_wsl_path_invalid():
    with pytest.raises(ValueError, match="Not a Windows path"):
        PathUtils.convert_to_wsl_path("/home/user")


# ---------------------------------------------------------------------------
# convert_to_windows_path
# ---------------------------------------------------------------------------
def test_convert_to_windows_path():
    assert PathUtils.convert_to_windows_path("/mnt/c/Users/test") == "C:\\Users\\test"


def test_convert_to_windows_path_invalid():
    with pytest.raises(ValueError, match="Not a WSL mount path"):
        PathUtils.convert_to_windows_path("/home/user")


# ---------------------------------------------------------------------------
# normalize_path
# ---------------------------------------------------------------------------
def test_normalize_wsl_from_windows():
    assert PathUtils.normalize_path("C:\\Users\\test", "wsl") == "/mnt/c/Users/test"


def test_normalize_wsl_already_wsl():
    assert PathUtils.normalize_path("/mnt/c/foo", "wsl") == "/mnt/c/foo"


def test_normalize_wsl_linux_passthrough():
    assert PathUtils.normalize_path("/home/user", "wsl") == "/home/user"


def test_normalize_windows_already_windows():
    assert PathUtils.normalize_path("C:/Users/test", "windows") == "C:\\Users\\test"


def test_normalize_windows_from_wsl():
    assert PathUtils.normalize_path("/mnt/c/Users/test", "windows") == "C:\\Users\\test"


def test_normalize_windows_linux_passthrough():
    assert PathUtils.normalize_path("/home/user", "windows") == "/home/user"


def test_normalize_linux_from_windows():
    assert PathUtils.normalize_path("C:\\Users\\test", "linux") == "/mnt/c/Users/test"


def test_normalize_linux_already_wsl():
    assert PathUtils.normalize_path("/mnt/c/foo", "linux") == "/mnt/c/foo"


def test_normalize_linux_plain():
    assert PathUtils.normalize_path("foo\\bar", "linux") == "foo/bar"


def test_normalize_default_platform_windows():
    with patch.object(platform_mod, "system", return_value="Windows"):
        assert PathUtils.normalize_path("C:/foo") == "C:\\foo"


def test_normalize_default_platform_linux():
    with patch.object(platform_mod, "system", return_value="Linux"):
        assert PathUtils.normalize_path("/home/user") == "/home/user"


# ---------------------------------------------------------------------------
# get_current_platform
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("system,expected", [
    ("Windows", "windows"),
    ("Linux", "linux"),
    ("Darwin", "macos"),
    ("FreeBSD", "freebsd"),
])
def test_get_current_platform(system, expected):
    with patch.object(platform_mod, "system", return_value=system):
        assert PathUtils.get_current_platform() == expected


# ---------------------------------------------------------------------------
# is_absolute_path
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("path,expected", [
    ("C:\\foo", True),
    ("/home/user", True),
    ("relative/path", False),
    ("./foo", False),
])
def test_is_absolute_path(path, expected):
    assert PathUtils.is_absolute_path(path) is expected


# ---------------------------------------------------------------------------
# join_paths
# ---------------------------------------------------------------------------
def test_join_paths_empty():
    assert PathUtils.join_paths() == ""


def test_join_paths_single():
    assert PathUtils.join_paths("foo") == str(Path("foo"))


def test_join_paths_multiple():
    result = PathUtils.join_paths("a", "b", "c.txt")
    assert result == str(Path("a") / "b" / "c.txt")


# ---------------------------------------------------------------------------
# ensure_directory_exists
# ---------------------------------------------------------------------------
def test_ensure_directory_exists(tmp_path):
    target = tmp_path / "sub" / "dir"
    result = PathUtils.ensure_directory_exists(str(target))
    assert result == Path(str(target))
    assert target.exists()
    assert target.is_dir()


def test_ensure_directory_exists_already_present(tmp_path):
    # exist_ok=True -> no error on second call
    PathUtils.ensure_directory_exists(str(tmp_path))
    result = PathUtils.ensure_directory_exists(str(tmp_path))
    assert result.exists()


# ---------------------------------------------------------------------------
# get_file_extension / get_filename / get_parent_directory
# ---------------------------------------------------------------------------
def test_get_file_extension():
    assert PathUtils.get_file_extension("/path/file.txt") == ".txt"
    assert PathUtils.get_file_extension("/path/file") == ""


def test_get_filename_with_extension():
    assert PathUtils.get_filename("/path/to/file.txt") == "file.txt"


def test_get_filename_without_extension():
    assert PathUtils.get_filename("/path/to/file.txt", with_extension=False) == "file"


def test_get_parent_directory():
    assert PathUtils.get_parent_directory("/path/to/file.txt") == str(Path("/path/to"))


# ---------------------------------------------------------------------------
# convenience functions
# ---------------------------------------------------------------------------
def test_to_wsl_path():
    assert to_wsl_path("C:\\foo") == "/mnt/c/foo"


def test_to_windows_path():
    assert to_windows_path("/mnt/c/foo") == "C:\\foo"


def test_normalize_for_platform():
    assert normalize_for_platform("C:\\foo", "wsl") == "/mnt/c/foo"


def test_resolve_secure_work_directory_returns_explicit_path():
    assert resolve_secure_work_directory("aid-1", "/custom/project") == "/custom/project"


def test_resolve_secure_work_directory_creates_workspace_dir(monkeypatch, tmp_path):
    monkeypatch.setattr(
        "app.utils.path_utils.get_settings",
        lambda: type("S", (), {"workspace": type("W", (), {"base_path": str(tmp_path)})()})(),
    )
    resolved = resolve_secure_work_directory("aid-secure", None)
    assert "/tmp" not in resolved
    assert str(tmp_path) in resolved
    assert Path(resolved).is_dir()
