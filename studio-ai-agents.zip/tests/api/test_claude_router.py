"""Tests for app/api/v1/claude.py router."""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.main import app
from app.api.v1.claude import get_claude_service
from app.core.exceptions import ValidationError
from app.models.responses import (
    ClaudeCliResponse,
    SchemaModernizationResponse,
    AssessmentRulesBatchResponse,
)

BASE = "/studio-ai-agents/api/claude"


@pytest.fixture
def claude_service():
    """Override get_claude_service with an AsyncMock service."""
    svc = AsyncMock()
    app.dependency_overrides[get_claude_service] = lambda: svc
    yield svc
    app.dependency_overrides.clear()


# --------------------------------------------------------------------------
# health & sleep-test
# --------------------------------------------------------------------------
def test_health(app_client):
    r = app_client.get(f"{BASE}/health")
    assert r.status_code == 200
    assert r.json() == "Claude CLI API is running"


def test_sleep_test_success(app_client):
    # The module's `settings.timeouts` has no `sleep_test_minutes` attribute, so
    # inject a mock timeouts config and patch asyncio.sleep to return immediately.
    import app.api.v1.claude as claude_mod

    fake_timeouts = MagicMock()
    fake_timeouts.sleep_test_minutes = 1
    with patch.object(claude_mod.settings, "timeouts", fake_timeouts), \
         patch("app.api.v1.claude.asyncio.sleep", new=AsyncMock(return_value=None)):
        r = app_client.get(f"{BASE}/sleep-test")
    assert r.status_code == 200
    assert "Sleep test completed" in r.json()


def test_sleep_test_generic_error(app_client):
    import app.api.v1.claude as claude_mod

    fake_timeouts = MagicMock()
    fake_timeouts.sleep_test_minutes = 1
    with patch.object(claude_mod.settings, "timeouts", fake_timeouts), \
         patch("app.api.v1.claude.asyncio.sleep",
               new=AsyncMock(side_effect=RuntimeError("boom"))):
        r = app_client.get(f"{BASE}/sleep-test")
    assert r.status_code == 500
    assert "Sleep test failed" in r.json()["detail"]


def test_sleep_test_cancelled(app_client):
    import asyncio as _asyncio
    import app.api.v1.claude as claude_mod

    fake_timeouts = MagicMock()
    fake_timeouts.sleep_test_minutes = 1
    with patch.object(claude_mod.settings, "timeouts", fake_timeouts), \
         patch("app.api.v1.claude.asyncio.sleep",
               new=AsyncMock(side_effect=_asyncio.CancelledError())):
        r = app_client.get(f"{BASE}/sleep-test")
    assert r.status_code == 500
    assert "cancelled" in r.json()["detail"]


# --------------------------------------------------------------------------
# executeCommandWithPrompt
# --------------------------------------------------------------------------
def test_execute_command_success(app_client, claude_service):
    claude_service.execute_non_interactive_command.return_value = ClaudeCliResponse(
        status="success", message="ok", exit_code=0, output="out", output_file_path="/p"
    )
    r = app_client.post(
        f"{BASE}/executeCommandWithPrompt",
        json={"projectPath": "/proj", "operation": "analysis", "analysisId": "a1"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "success"
    assert body["outputFilePath"] == "/p"


def test_execute_command_service_error_status(app_client, claude_service):
    # status != success -> logged as warning, still returns 200
    claude_service.execute_non_interactive_command.return_value = ClaudeCliResponse(
        status="error", message="bad", exit_code=1, error="err"
    )
    r = app_client.post(
        f"{BASE}/executeCommandWithPrompt",
        json={"projectPath": "/proj", "operation": "analysis"},
    )
    assert r.status_code == 200
    assert r.json()["status"] == "error"


def test_execute_command_validation_error(app_client, claude_service):
    claude_service.execute_non_interactive_command.side_effect = ValidationError(
        "bad input", field="prompt"
    )
    r = app_client.post(
        f"{BASE}/executeCommandWithPrompt",
        json={"projectPath": "/proj", "operation": "analysis"},
    )
    assert r.status_code == 400
    assert r.json()["detail"]["field"] == "prompt"


def test_execute_command_timeout_error(app_client, claude_service):
    claude_service.execute_non_interactive_command.side_effect = TimeoutError("slow")
    r = app_client.post(
        f"{BASE}/executeCommandWithPrompt",
        json={"projectPath": "/proj", "operation": "analysis"},
    )
    assert r.status_code == 504
    assert "timed out" in r.json()["detail"]["message"]


def test_execute_command_generic_exception(app_client, claude_service):
    claude_service.execute_non_interactive_command.side_effect = RuntimeError("kaboom")
    r = app_client.post(
        f"{BASE}/executeCommandWithPrompt",
        json={"projectPath": "/proj", "operation": "analysis"},
    )
    # generic exception -> returns ClaudeCliResponse error with 200
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "error"
    assert body["exitCode"] == -1


def test_execute_command_missing_required_field(app_client, claude_service):
    # Missing required projectPath -> RequestValidationError with a serializable
    # error list -> validation_exception_handler returns 400.
    r = app_client.post(f"{BASE}/executeCommandWithPrompt", json={"operation": "analysis"})
    assert r.status_code == 400
    assert r.json()["status"] == "error"


# --------------------------------------------------------------------------
# schema-modernization
# --------------------------------------------------------------------------
def _schema_payload():
    return {
        "analysisId": "s1",
        "sourceDbType": "Oracle",
        "targetDbType": "PostgreSQL",
        "sourceSchemaPath": "/s.sql",
    }


def test_schema_modernization_success(app_client, claude_service):
    claude_service.execute_schema_modernization.return_value = SchemaModernizationResponse(
        status="success", message="done", output_file_path="/out", analysis_id="s1"
    )
    r = app_client.post(f"{BASE}/schema-modernization", json=_schema_payload())
    assert r.status_code == 200
    assert r.json()["status"] == "success"


def test_schema_modernization_error_status_raises_500(app_client, claude_service):
    claude_service.execute_schema_modernization.return_value = SchemaModernizationResponse(
        status="error", message="failed", error_details="boom", analysis_id="s1"
    )
    r = app_client.post(f"{BASE}/schema-modernization", json=_schema_payload())
    assert r.status_code == 500


def test_schema_modernization_validation_error(app_client, claude_service):
    claude_service.execute_schema_modernization.side_effect = ValidationError(
        "bad", field="sourceDbType"
    )
    r = app_client.post(f"{BASE}/schema-modernization", json=_schema_payload())
    assert r.status_code == 400
    assert r.json()["detail"]["analysisId"] == "s1"


def test_schema_modernization_generic_exception(app_client, claude_service):
    claude_service.execute_schema_modernization.side_effect = RuntimeError("kaboom")
    r = app_client.post(f"{BASE}/schema-modernization", json=_schema_payload())
    # generic exception -> returns SchemaModernizationResponse error with 200
    assert r.status_code == 200
    assert r.json()["status"] == "error"


# --------------------------------------------------------------------------
# assessment-rules-batch
# --------------------------------------------------------------------------
def _batch_payload():
    return {
        "analysisId": "b1",
        "rules": [
            {
                "ruleId": "R1",
                "domain": "security",
                "language": "java",
                "name": "n",
                "description": "d",
            }
        ],
    }


def test_assessment_batch_success(app_client, claude_service):
    claude_service.execute_assessment_rules_batch.return_value = AssessmentRulesBatchResponse(
        status="success", message="ok", analysis_id="b1", rule_count_expected=1
    )
    r = app_client.post(f"{BASE}/assessment-rules-batch", json=_batch_payload())
    assert r.status_code == 200
    assert r.json()["status"] == "success"


def test_assessment_batch_error_status_raises_500(app_client, claude_service):
    claude_service.execute_assessment_rules_batch.return_value = AssessmentRulesBatchResponse(
        status="error", message="failed", analysis_id="b1", rule_count_expected=1
    )
    r = app_client.post(f"{BASE}/assessment-rules-batch", json=_batch_payload())
    assert r.status_code == 500


def test_assessment_batch_validation_error(app_client, claude_service):
    claude_service.execute_assessment_rules_batch.side_effect = ValidationError(
        "bad", field="rules"
    )
    r = app_client.post(f"{BASE}/assessment-rules-batch", json=_batch_payload())
    assert r.status_code == 400
    assert r.json()["detail"]["analysisId"] == "b1"


def test_assessment_batch_generic_exception(app_client, claude_service):
    claude_service.execute_assessment_rules_batch.side_effect = RuntimeError("kaboom")
    r = app_client.post(f"{BASE}/assessment-rules-batch", json=_batch_payload())
    assert r.status_code == 200
    assert r.json()["status"] == "error"


def test_assessment_batch_empty_rules_422(app_client, claude_service):
    r = app_client.post(
        f"{BASE}/assessment-rules-batch", json={"analysisId": "b1", "rules": []}
    )
    assert r.status_code == 400

#Test    
