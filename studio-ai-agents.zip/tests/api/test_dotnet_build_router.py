"""Tests for app/api/v1/dotnet_build.py router."""
from unittest.mock import AsyncMock, patch

from app.models.dotnet_build import BuildResult

BASE = "/studio-ai-agents/api/validation"


def _result():
    return BuildResult(
        exit_code=0, success=True, build_status="SUCCESS", errors=0, warnings=1, total_time="0:00:10"
    )


def _payload():
    return {
        "projectLocation": "/proj",
        "analysisId": "a1",
        "platform": "linux",
        "applicationName": "App",
        "technology": "java",
        "buildType": "maven",
        "version": "17",
    }


# --------------------------------------------------------------------------
# dotnet-executeBuild
# --------------------------------------------------------------------------
def test_dotnet_build_success(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_dotnet_build",
        new=AsyncMock(return_value=_result()),
    ):
        r = app_client.post(f"{BASE}/dotnet-executeBuild", json=_payload())
    assert r.status_code == 200
    body = r.json()
    assert body["buildStatus"] == "SUCCESS"
    assert body["success"] is True


def test_dotnet_build_failure_500(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_dotnet_build",
        new=AsyncMock(side_effect=RuntimeError("dotnet missing")),
    ):
        r = app_client.post(f"{BASE}/dotnet-executeBuild", json=_payload())
    assert r.status_code == 500
    assert r.json()["detail"] == "dotnet missing"


def test_dotnet_build_missing_required_field(app_client):
    r = app_client.post(f"{BASE}/dotnet-executeBuild", json={"analysisId": "a1"})
    assert r.status_code == 400


# --------------------------------------------------------------------------
# executeBuild (Java)
# --------------------------------------------------------------------------
def test_java_build_success(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_java_build",
        new=AsyncMock(return_value=_result()),
    ):
        r = app_client.post(f"{BASE}/executeBuild", json=_payload())
    assert r.status_code == 200
    assert r.json()["buildStatus"] == "SUCCESS"


def test_java_build_value_error_400(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_java_build",
        new=AsyncMock(side_effect=ValueError("bad version")),
    ):
        r = app_client.post(f"{BASE}/executeBuild", json=_payload())
    assert r.status_code == 400
    assert r.json()["detail"] == "bad version"


def test_java_build_not_implemented_400(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_java_build",
        new=AsyncMock(side_effect=NotImplementedError("gradle unsupported")),
    ):
        r = app_client.post(f"{BASE}/executeBuild", json=_payload())
    assert r.status_code == 400
    assert r.json()["detail"] == "gradle unsupported"


def test_java_build_generic_500(app_client):
    with patch(
        "app.api.v1.dotnet_build.execute_java_build",
        new=AsyncMock(side_effect=RuntimeError("boom")),
    ):
        r = app_client.post(f"{BASE}/executeBuild", json=_payload())
    assert r.status_code == 500
    assert r.json()["detail"] == "boom"