"""Tests for app/api/v1/stream_visualization.py router."""
from unittest.mock import AsyncMock

import pytest

from app.main import app
from app.api.v1.stream_visualization import get_stream_visualization_service
from app.core.exceptions import ValidationError
from app.models.responses import StreamVisualizationResponse

BASE = "/studio-ai-agents/api/stream"


@pytest.fixture
def stream_service():
    svc = AsyncMock()
    app.dependency_overrides[get_stream_visualization_service] = lambda: svc
    yield svc
    app.dependency_overrides.clear()


# --------------------------------------------------------------------------
# health
# --------------------------------------------------------------------------
def test_health(app_client):
    r = app_client.get(f"{BASE}/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "healthy"
    assert body["service"] == "StreamVisualizationService"


# --------------------------------------------------------------------------
# GET /{analysisId}/{operation}
# --------------------------------------------------------------------------
def test_get_stream_success(app_client, stream_service):
    stream_service.get_stream_data.return_value = StreamVisualizationResponse(
        analysis_id="a1", operation="analysis", status="success", stream_data="{}"
    )
    r = app_client.get(f"{BASE}/a1/analysis")
    assert r.status_code == 200
    assert r.json()["analysisId"] == "a1"


def test_get_stream_not_found(app_client, stream_service):
    stream_service.get_stream_data.return_value = StreamVisualizationResponse(
        analysis_id="a1", operation="analysis", status="not_found", message="nope"
    )
    r = app_client.get(f"{BASE}/a1/analysis")
    assert r.status_code == 404
    assert r.json()["detail"]["status"] == "not_found"


def test_get_stream_error_status(app_client, stream_service):
    stream_service.get_stream_data.return_value = StreamVisualizationResponse(
        analysis_id="a1", operation="analysis", status="error", message="bad"
    )
    r = app_client.get(f"{BASE}/a1/analysis")
    assert r.status_code == 500
    assert r.json()["detail"]["status"] == "error"


def test_get_stream_validation_error(app_client, stream_service):
    stream_service.get_stream_data.side_effect = ValidationError("bad", field="analysisId")
    r = app_client.get(f"{BASE}/a1/analysis")
    assert r.status_code == 400
    assert r.json()["detail"]["field"] == "analysisId"


def test_get_stream_generic_exception(app_client, stream_service):
    stream_service.get_stream_data.side_effect = RuntimeError("boom")
    r = app_client.get(f"{BASE}/a1/analysis")
    assert r.status_code == 500
    assert "failed" in r.json()["detail"]["message"]


def test_get_stream_invalid_format_422(app_client, stream_service):
    r = app_client.get(f"{BASE}/a1/analysis?format=xml")
    assert r.status_code == 400  # request validation -> app handler 400


# --------------------------------------------------------------------------
# GET /summary/{analysisId}/{operation}
# --------------------------------------------------------------------------
def test_get_summary_success(app_client, stream_service):
    stream_service.get_stream_summary.return_value = {"status": "success", "exists": True}
    r = app_client.get(f"{BASE}/summary/a1/analysis")
    assert r.status_code == 200
    assert r.json()["exists"] is True


def test_get_summary_validation_error(app_client, stream_service):
    stream_service.get_stream_summary.side_effect = ValidationError("bad", field="operation")
    r = app_client.get(f"{BASE}/summary/a1/analysis")
    assert r.status_code == 400
    assert r.json()["detail"]["field"] == "operation"


def test_get_summary_generic_exception(app_client, stream_service):
    stream_service.get_stream_summary.side_effect = RuntimeError("boom")
    r = app_client.get(f"{BASE}/summary/a1/analysis")
    assert r.status_code == 500


# --------------------------------------------------------------------------
# GET /list/{analysisId}
# NOTE: the catch-all "/{analysisId}/{operation}" route is registered before
# "/list/{analysisId}", so an HTTP GET to "/list/a1" is matched by the
# two-segment route (analysisId="list", operation="a1"). The list handler is
# therefore unreachable via HTTP and is exercised by calling it directly.
# --------------------------------------------------------------------------
async def test_list_streams_success():
    from app.api.v1.stream_visualization import list_available_streams

    svc = AsyncMock()
    svc.list_available_streams.return_value = [{"operation": "analysis"}]
    result = await list_available_streams(analysis_id="a1", stream_service=svc)
    assert result["total_streams"] == 1
    assert result["analysisId"] == "a1"


async def test_list_streams_validation_error():
    from fastapi import HTTPException
    from app.api.v1.stream_visualization import list_available_streams

    svc = AsyncMock()
    svc.list_available_streams.side_effect = ValidationError("bad", field="analysisId")
    with pytest.raises(HTTPException) as exc:
        await list_available_streams(analysis_id="a1", stream_service=svc)
    assert exc.value.status_code == 400
    assert exc.value.detail["field"] == "analysisId"


async def test_list_streams_generic_exception():
    from fastapi import HTTPException
    from app.api.v1.stream_visualization import list_available_streams

    svc = AsyncMock()
    svc.list_available_streams.side_effect = RuntimeError("boom")
    with pytest.raises(HTTPException) as exc:
        await list_available_streams(analysis_id="a1", stream_service=svc)
    assert exc.value.status_code == 500