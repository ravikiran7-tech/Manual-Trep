"""Tests for app/main.py: endpoints, exception handlers, lifespan helpers."""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.main as main
from app.main import app
from app.core.exceptions import (
    StudioAIEngineException,
    ValidationError,
    AuthenticationError,
    ProviderError,
    OperationTimeoutError,
    CircuitBreakerError,
    ConfigurationError,
)


# ==========================================================================
# Root / health endpoints
# ==========================================================================
def test_root(app_client):
    r = app_client.get("/studio-ai-agents/")
    assert r.status_code == 200
    body = r.json()
    assert body["service"] == "Studio AI Engine - Python"
    assert body["status"] == "running"


def test_health_with_context_path(app_client):
    r = app_client.get("/studio-ai-agents/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_health_legacy(app_client):
    r = app_client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_health_head(app_client):
    r = app_client.head("/health")
    assert r.status_code == 200


# ==========================================================================
# Exception handlers — register temporary routes that raise
# ==========================================================================
@pytest.fixture
def exc_routes():
    """Register temporary routes to trigger app-level exception handlers."""
    @app.get("/__test_raise/studio")
    async def _raise_studio():
        raise StudioAIEngineException("base boom", details="d")

    @app.get("/__test_raise/validation")
    async def _raise_validation():
        raise ValidationError("invalid", field="f")

    @app.get("/__test_raise/auth")
    async def _raise_auth():
        raise AuthenticationError("no auth")

    @app.get("/__test_raise/provider")
    async def _raise_provider():
        raise ProviderError("bedrock down", provider="bedrock")

    @app.get("/__test_raise/timeout")
    async def _raise_timeout():
        raise OperationTimeoutError("too slow", timeout_seconds=5)

    @app.get("/__test_raise/circuit")
    async def _raise_circuit():
        raise CircuitBreakerError("open")

    @app.get("/__test_raise/generic")
    async def _raise_generic():
        raise RuntimeError("unexpected boom")

    yield
    # Remove the temporary routes we added.
    app.router.routes = [
        rt for rt in app.router.routes
        if not (getattr(rt, "path", "").startswith("/__test_raise/"))
    ]


@pytest.mark.parametrize(
    "suffix,expected",
    [
        ("studio", 500),
        ("validation", 400),
        ("auth", 401),
        ("provider", 502),
        ("timeout", 504),
        ("circuit", 503),
    ],
)
def test_studio_exception_handler_status_codes(app_client, exc_routes, suffix, expected):
    r = app_client.get(f"/__test_raise/{suffix}")
    assert r.status_code == expected
    body = r.json()
    assert body["status"] == "error"
    assert "error_type" in body


def test_general_exception_handler_debug(app_client, exc_routes):
    # settings.debug is True in test env -> details + type included
    r = app_client.get("/__test_raise/generic")
    assert r.status_code == 500
    body = r.json()
    assert body["status"] == "error"
    assert "error_id" in body
    assert body["details"] == "unexpected boom"
    assert body["type"] == "RuntimeError"


def test_general_exception_handler_non_debug(app_client, exc_routes):
    with patch.object(main.settings, "debug", False):
        r = app_client.get("/__test_raise/generic")
    assert r.status_code == 500
    body = r.json()
    assert "support_message" in body
    assert "details" not in body


def test_validation_exception_handler(app_client):
    # Hitting the claude execute endpoint with a bad body triggers
    # RequestValidationError -> validation_exception_handler.
    r = app_client.post(
        "/studio-ai-agents/api/claude/executeCommandWithPrompt", json={}
    )
    assert r.status_code == 400
    body = r.json()
    assert body["status"] == "error"
    assert body["message"] == "Request validation failed"
    assert isinstance(body["details"], list)


# ==========================================================================
# Lifespan helpers
# ==========================================================================
async def test_validate_configuration_success():
    fake_session = MagicMock()
    fake_session.get_credentials.return_value = MagicMock()  # creds present
    with patch("boto3.Session", return_value=fake_session), \
         patch.object(Path, "mkdir"), \
         patch.object(Path, "touch"), \
         patch.object(Path, "unlink"):
        await main.validate_configuration()


async def test_validate_configuration_no_aws_credentials():
    fake_session = MagicMock()
    fake_session.get_credentials.return_value = None  # no creds -> warning branch
    with patch("boto3.Session", return_value=fake_session), \
         patch.object(Path, "mkdir"), \
         patch.object(Path, "touch"), \
         patch.object(Path, "unlink"):
        await main.validate_configuration()


async def test_validate_configuration_aws_exception_swallowed():
    with patch("boto3.Session", side_effect=RuntimeError("aws err")), \
         patch.object(Path, "mkdir"), \
         patch.object(Path, "touch"), \
         patch.object(Path, "unlink"):
        # AWS error is swallowed (warning), not raised
        await main.validate_configuration()


async def test_validate_configuration_missing_studio_core():
    with patch.object(main.settings, "studio_core", None):
        with pytest.raises(ConfigurationError, match="STUDIO_CORE_URL"):
            await main.validate_configuration()


async def test_validate_configuration_missing_encryption_key():
    with patch.object(main.settings, "encryption_key", ""):
        with pytest.raises(ConfigurationError, match="ENCRYPTION_KEY"):
            await main.validate_configuration()


async def test_validate_configuration_nats_enabled_missing_passphrase():
    nats = MagicMock()
    nats.enabled = True
    with patch.object(main.settings, "nats", nats), \
         patch.object(main.settings, "debug", False), \
         patch.object(main.settings, "enc_passphrase", "  "):
        with pytest.raises(ConfigurationError, match="ENC_PASSPHRASE"):
            await main.validate_configuration()


async def test_validate_configuration_nats_enabled_with_passphrase():
    nats = MagicMock()
    nats.enabled = True
    fake_session = MagicMock()
    fake_session.get_credentials.return_value = MagicMock()
    with patch.object(main.settings, "nats", nats), \
         patch.object(main.settings, "debug", False), \
         patch.object(main.settings, "enc_passphrase", "secret"), \
         patch("boto3.Session", return_value=fake_session), \
         patch.object(Path, "mkdir"), \
         patch.object(Path, "touch"), \
         patch.object(Path, "unlink"):
        await main.validate_configuration()


async def test_validate_configuration_invalid_encryption_key():
    with patch("app.utils.encryption.EncryptionUtils", side_effect=ValueError("bad key")):
        with pytest.raises(ConfigurationError, match="Invalid encryption key"):
            await main.validate_configuration()


async def test_validate_configuration_workspace_not_writable():
    fake_session = MagicMock()
    fake_session.get_credentials.return_value = MagicMock()
    with patch("boto3.Session", return_value=fake_session), \
         patch.object(Path, "mkdir", side_effect=PermissionError("denied")):
        with pytest.raises(ConfigurationError, match="Workspace directory not writable"):
            await main.validate_configuration()


async def test_initialize_resources():
    await main.initialize_resources()  # just logs


async def test_initialize_workspace_success():
    with patch.object(Path, "mkdir") as m:
        await main.initialize_workspace()
        assert m.call_count >= 1


async def test_initialize_workspace_failure():
    with patch.object(Path, "mkdir", side_effect=OSError("disk full")):
        with pytest.raises(OSError):
            await main.initialize_workspace()


async def test_initialize_nats_subscriber_disabled():
    nats = MagicMock()
    nats.enabled = False
    with patch.object(main.settings, "nats", nats):
        await main.initialize_nats_subscriber()


async def test_initialize_nats_subscriber_enabled():
    nats = MagicMock()
    nats.enabled = True
    fake_service = MagicMock()
    fake_service.start = AsyncMock()
    fake_cls = MagicMock(return_value=fake_service)
    mod = MagicMock()
    mod.NatsSchemaGenerateService = fake_cls
    with patch.object(main.settings, "nats", nats), \
         patch.dict("sys.modules", {"app.services.nats_schema_generate_service": mod}):
        await main.initialize_nats_subscriber()
        fake_service.start.assert_awaited_once()
    main.nats_schema_generate_service = None  # reset global


async def test_cleanup_resources_all_success():
    fake_service = MagicMock()
    fake_service.stop = AsyncMock()
    with patch.object(main, "nats_schema_generate_service", fake_service), \
         patch("app.clients.compass_client.cleanup_compass_client", new=AsyncMock()), \
         patch("app.core.resilience.reset_all_circuit_breakers"):
        await main.cleanup_resources()
        fake_service.stop.assert_awaited_once()


async def test_cleanup_resources_no_nats():
    with patch.object(main, "nats_schema_generate_service", None), \
         patch("app.clients.compass_client.cleanup_compass_client", new=AsyncMock()), \
         patch("app.core.resilience.reset_all_circuit_breakers"):
        await main.cleanup_resources()


async def test_cleanup_resources_errors_swallowed():
    fake_service = MagicMock()
    fake_service.stop = AsyncMock(side_effect=RuntimeError("nats err"))
    with patch.object(main, "nats_schema_generate_service", fake_service), \
         patch("app.clients.compass_client.cleanup_compass_client",
               new=AsyncMock(side_effect=RuntimeError("compass err"))), \
         patch("app.core.resilience.reset_all_circuit_breakers",
               side_effect=RuntimeError("cb err")):
        # all errors are caught and logged, no raise
        await main.cleanup_resources()


# ==========================================================================
# lifespan context manager
# ==========================================================================
async def test_lifespan_success():
    with patch.object(main, "validate_configuration", new=AsyncMock()), \
         patch.object(main, "initialize_workspace", new=AsyncMock()), \
         patch.object(main, "initialize_resources", new=AsyncMock()), \
         patch.object(main, "initialize_nats_subscriber", new=AsyncMock()), \
         patch.object(main, "cleanup_resources", new=AsyncMock()):
        async with main.lifespan(app):
            pass


async def test_lifespan_startup_failure():
    with patch.object(main, "validate_configuration",
                      new=AsyncMock(side_effect=ConfigurationError("bad"))):
        with pytest.raises(ConfigurationError):
            async with main.lifespan(app):
                pass


async def test_lifespan_shutdown_error_swallowed():
    with patch.object(main, "validate_configuration", new=AsyncMock()), \
         patch.object(main, "initialize_workspace", new=AsyncMock()), \
         patch.object(main, "initialize_resources", new=AsyncMock()), \
         patch.object(main, "initialize_nats_subscriber", new=AsyncMock()), \
         patch.object(main, "cleanup_resources",
                      new=AsyncMock(side_effect=RuntimeError("shutdown err"))):
        # shutdown error is caught/logged, not raised
        async with main.lifespan(app):
            pass
