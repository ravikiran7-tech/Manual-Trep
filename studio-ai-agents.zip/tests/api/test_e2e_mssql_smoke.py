"""E2E smoke: MSSQL schema (Job 2) API + MSSQL App+DB (Job 3) API."""

from __future__ import annotations

import json

import pytest

from app.services.mssql_app_db.infer_launch import ENGINE_MSSQL, ENGINE_ORACLE, infer_engine_for_db
from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.mssql_test_assets import stage_mssql_inputs
from tests.services.mssql_app_db.run_helpers import launch_mssql_and_complete, patch_mssql_app_db_workspace
from tests.services.oracle_pg.app_db_change.run_helpers import (
    stage_fixture_inputs,
    stage_job2_complete,
)

APP_DB = "/studio-ai-agents/api/app-db-transformation"


@pytest.mark.asyncio
async def test_smoke_app_db_mssql_java_e2e(app_client, tmp_path, monkeypatch):
    """Launch → progress → jobs → logs → report for Java MSSQL App+DB."""
    tid, checkout, _ = await launch_mssql_and_complete(
        monkeypatch,
        tmp_path,
        lang="java",
        app_id="SMOKE-J",
        db_id="SMOKE-APPDB-J",
        app_client=app_client,
    )
    progress = app_client.get(f"{APP_DB}/{tid}/progress")
    assert progress.status_code == 200
    assert progress.json()["overallStatus"] == "COMPLETED"

    cfg = json.loads(ws.job_config_path("SMOKE-APPDB-J").read_text(encoding="utf-8"))
    assert cfg["appId"] == "SMOKE-J"
    assert infer_engine_for_db("SMOKE-APPDB-J") == ENGINE_MSSQL
    assert checkout.exists()


def test_smoke_app_db_launch_routing_oracle_vs_mssql(app_client, tmp_path, monkeypatch):
    from tests.services.oracle_pg.app_db_change.run_helpers import patch_app_db_workspace

    patch_app_db_workspace(monkeypatch, tmp_path)
    checkout = tmp_path / "p"
    checkout.mkdir()
    stage_job2_complete("DB-O")
    stage_fixture_inputs("DB-O", checkout)
    assert infer_engine_for_db("DB-O") == ENGINE_ORACLE

    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    stage_job2_complete("DB-M")
    stage_mssql_inputs(ws.inputs_dir("DB-M"), checkout, lang="java")
    assert infer_engine_for_db("DB-M") == ENGINE_MSSQL

