"""App+DB API tests for MSSQL Java and C# launch / read paths."""

from __future__ import annotations

import json

import pytest

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)
from app.services.oracle_pg.app_db_change.progress_tracker import get_progress_tracker
from app.services.mssql_app_db.routing import get_tracker_for_transformation
from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.mssql_test_assets import stage_mssql_inputs
from tests.services.mssql_app_db.run_helpers import launch_mssql_and_complete, patch_mssql_app_db_workspace

BASE = "/studio-ai-agents/api/app-db-transformation"


@pytest.mark.asyncio
@pytest.mark.parametrize("lang", ["java", "csharp"])
async def test_mssql_api_launch_progress_jobs_route(app_client, tmp_path, monkeypatch, lang):
    db_id = f"MSSQL-{lang.upper()}"
    tid, checkout, _ = await launch_mssql_and_complete(
        monkeypatch,
        tmp_path,
        lang=lang,
        app_id="APPX",
        db_id=db_id,
        app_client=app_client,
    )

    progress = app_client.get(f"{BASE}/{tid}/progress")
    assert progress.status_code == 200, progress.text
    body = progress.json()
    assert body["overallStatus"] == "COMPLETED"
    assert "Violation Remediations" in body["milestones"][1]["title"]
    assert body["milestones"][1]["description"] == (
        "Remediating MSSQL-language dependency violations in source files"
    )

    job_status = app_client.get(f"{BASE}/jobs/APPX")
    assert job_status.status_code == 200
    assert job_status.json()["status"] in ("completed", "COMPLETED", "Completed")

    logs = app_client.get(f"{BASE}/{tid}/logs", params={"fromIndex": 0})
    assert logs.status_code == 200
    assert logs.json()["logs"]

    report = app_client.get(f"{BASE}/{tid}/report")
    assert report.status_code == 200
    assert report.json()["overallStatus"] == "COMPLETED"

    assert get_tracker_for_transformation(tid) is get_progress_tracker()

    config = json.loads(ws.job_config_path(db_id).read_text(encoding="utf-8"))
    assert config["projectType"] == lang
    assert "sourceDialect" not in config
    assert checkout.exists()


def test_mssql_java_default_input_filenames_accepted(app_client, tmp_path, monkeypatch):
    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    db_id = "MSSQL-JAVA-DEF"
    checkout = tmp_path / "proj"
    stage_mssql_inputs(ws.inputs_dir(db_id), checkout, "java")

    body = {
        "appId": "AJ",
        "dbId": db_id,
        "projectType": "java",
        "projectPath": str(checkout),
        "skipLlm": True,
    }
    r = app_client.post(f"{BASE}/launch", json=body)
    assert r.status_code == 202, r.text
    assert r.json()["transformationId"].startswith("APPDB-")


def test_mssql_csharp_project_type_aliases(app_client, tmp_path, monkeypatch):
    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    db_id = "MSSQL-CS"
    checkout = tmp_path / "proj"
    stage_mssql_inputs(ws.inputs_dir(db_id), checkout, "csharp")

    for idx, project_type in enumerate(("csharp", "c#", "cs")):
        db = f"{db_id}-{idx}"
        stage_mssql_inputs(ws.inputs_dir(db), checkout, "csharp")
        body = {
            "appId": f"A-{project_type}",
            "dbId": db,
            "projectType": project_type,
            "projectPath": str(checkout),
            "skipLlm": True,
        }
        r = app_client.post(f"{BASE}/launch", json=body)
        assert r.status_code == 202, (project_type, r.text)


@pytest.mark.parametrize("project_type", ("dotnet", ".net", "netcore"))
def test_mssql_dotnet_aliases_treated_as_csharp(app_client, tmp_path, monkeypatch, project_type):
    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    db_id = f"MSSQL-{project_type.replace('.', '')}"
    checkout = tmp_path / "p"
    stage_mssql_inputs(ws.inputs_dir(db_id), checkout, "csharp")
    r = app_client.post(
        f"{BASE}/launch",
        json={
            "appId": "A1",
            "dbId": db_id,
            "projectType": project_type,
            "projectPath": str(checkout),
            "skipLlm": True,
        },
    )
    assert r.status_code == 202, r.text
    config = json.loads(ws.job_config_path(db_id).read_text(encoding="utf-8"))
    assert config["projectType"] == "csharp"


def test_mssql_missing_inputs_returns_400(app_client, tmp_path, monkeypatch):
    from tests.services.oracle_pg.app_db_change.run_helpers import stage_job2_complete

    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    stage_job2_complete("EMPTY")
    r = app_client.post(
        f"{BASE}/launch",
        json={
            "appId": "A1",
            "dbId": "EMPTY",
            "projectPath": str(tmp_path),
            "inputPaths": {
                "dependencyFindings": FINDINGS_JAVA_MSSQL,
                "rulesRemediation": RULES_JAVA_MSSQL,
            },
        },
    )
    assert r.status_code == 400
