"""Tests for app/api/dependencies.py."""
from unittest.mock import MagicMock, patch

import app.api.dependencies as deps


def test_get_provider_factory_dependency():
    with patch.object(deps, "get_provider_factory", return_value="PF") as m:
        assert deps.get_provider_factory_dependency() == "PF"
        m.assert_called_once()


def test_get_compass_client_dependency():
    with patch.object(deps, "get_compass_client", return_value="CC") as m:
        assert deps.get_compass_client_dependency() == "CC"
        m.assert_called_once()


async def test_get_claude_service():
    sentinel = object()
    with patch("app.services.claude_service.get_claude_service", return_value=sentinel) as m:
        result = await deps.get_claude_service()
        assert result is sentinel
        m.assert_called_once()


async def test_get_build_compilation_service():
    # The module app.services.build_compilation_service does not exist in the
    # codebase, so inject a fake module into sys.modules for the in-function import.
    import sys

    sentinel = object()
    fake_mod = MagicMock()
    fake_mod.get_build_compilation_service = MagicMock(return_value=sentinel)
    with patch.dict(sys.modules, {"app.services.build_compilation_service": fake_mod}):
        result = await deps.get_build_compilation_service()
        assert result is sentinel
        fake_mod.get_build_compilation_service.assert_called_once()


async def test_get_stream_visualization_service():
    sentinel = object()
    with patch(
        "app.services.stream_visualization_service.get_stream_visualization_service",
        return_value=sentinel,
    ) as m:
        result = await deps.get_stream_visualization_service()
        assert result is sentinel
        m.assert_called_once()


def test_get_request_identifier_x_forwarded_for():
    req = MagicMock()
    req.headers = {"X-Forwarded-For": "1.2.3.4, 5.6.7.8"}
    assert deps.get_request_identifier(req) == "1.2.3.4"


def test_get_request_identifier_client_host():
    req = MagicMock()
    req.headers = {}
    req.client = MagicMock()
    req.client.host = "9.9.9.9"
    assert deps.get_request_identifier(req) == "9.9.9.9"


def test_get_request_identifier_no_client():
    req = MagicMock()
    req.headers = {}
    req.client = None
    assert deps.get_request_identifier(req) == "unknown"