"""API tests: MSSQL launch, then Oracle read URLs for status/SSE/objects/artifacts."""

from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager

import pytest
from fastapi.testclient import TestClient

from tests.services.mssql_pg.conftest import stage_compass_files

PREFIX = "/studio-ai-agents"
ORACLE = f"{PREFIX}/api/oracle-pg-transformation"
MSSQL_LAUNCH = f"{PREFIX}/api/mssql-pg-transformation/launch"


@pytest.fixture
def fake_model_caller():
    async def _caller(prompt: str):
        obj_type = "TABLE"
        schema = "dbo"
        name = "object"
        for token in ("SCHEMA", "SEQUENCE", "TABLE", "VIEW", "FUNCTION", "PROCEDURE", "TRIGGER", "INDEX", "SYNONYM"):
            if f'"objectType": "{token}"' in prompt:
                obj_type = token
                break
        for line in prompt.splitlines():
            if '"schema":' in line:
                schema = line.split(":", 1)[1].strip().strip('",')
            if '"name":' in line and "objectType" not in line:
                name = line.split(":", 1)[1].strip().strip('",')
        qualified = f"{schema}.{name.lower()}"
        code_by_type = {
            "SCHEMA": f"CREATE SCHEMA IF NOT EXISTS {name.lower()};",
            "TABLE": f"CREATE TABLE {qualified} (id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL);",
            "VIEW": f"CREATE OR REPLACE VIEW {qualified} AS SELECT id, name FROM dbo.customers;",
            "PROCEDURE": f"CREATE OR REPLACE PROCEDURE {qualified}(p_id integer)\nLANGUAGE plpgsql\nAS $$\nBEGIN\n    CALL dbo.helper(p_id);\nEND;\n$$;",
            "FUNCTION": f"CREATE OR REPLACE FUNCTION {qualified}() RETURNS integer LANGUAGE sql AS $$ SELECT 1; $$;",
        }
        code = code_by_type.get(obj_type, f"-- converted {obj_type} {qualified}")
        return json.dumps(
            {
                "conversionStatus": "SUCCESS",
                "convertedCode": code,
                "convertedName": None,
                "newSignature": None,
                "confidenceScore": "HIGH",
                "changesApplied": ["type mapping"],
                "comments": [],
                "requiresManualReview": False,
                "reviewGuidance": [],
                "callerUpdatesNeeded": [],
            }
        )

    return _caller


@pytest.fixture
def api_client(tmp_path, monkeypatch):
    from app.core.config import get_settings
    from app.services.db_transformation.sources import reset_adapter_cache
    from app.services.mssql_pg.job_manager import reset_job_manager

    settings = get_settings()
    monkeypatch.setattr(settings, "claude_workspace", str(tmp_path))
    reset_job_manager()
    reset_adapter_cache()

    import app.main as main

    @asynccontextmanager
    async def noop_lifespan(app):
        yield

    main.app.router.lifespan_context = noop_lifespan
    with TestClient(main.app) as test_client:
        yield test_client, tmp_path

    reset_job_manager()
    reset_adapter_cache()


def test_mssql_launch_ai_agent_defaults_like_oracle():
    from app.models.mssql_pg_transformation import LaunchMssqlPgTransformationRequest

    input_paths = {
        "ddlExport": "script.sql",
        "asisSchema": "asis.json",
        "incompatibilityResults": "incompat.json",
        "rulesRemediation": "rules_remediation.json",
        "schemaAnalysis": "analysis.json",
    }
    omitted = LaunchMssqlPgTransformationRequest(
        dbName="SalesDB",
        targetDatabaseVersion="16",
        inputPaths=input_paths,
    )
    null_sent = LaunchMssqlPgTransformationRequest(
        dbName="SalesDB",
        targetDatabaseVersion="16",
        aiAgent=None,
        inputPaths=input_paths,
    )
    assert omitted.ai_agent == "claude-sonnet-5-5"
    assert null_sent.ai_agent == "claude-sonnet-5-5"


def test_mssql_launch_rejects_missing_inputs(api_client):
    test_client, _ = api_client
    response = test_client.post(
        MSSQL_LAUNCH,
        json={"dbName": "SalesDB", "targetDatabaseVersion": "16", "inputPaths": {}},
    )
    assert response.status_code == 400


def test_mssql_launch_rejects_legacy_input_path_names(api_client):
    test_client, _ = api_client
    response = test_client.post(
        MSSQL_LAUNCH,
        json={
            "dbName": "SalesDB",
            "targetDatabaseVersion": "16",
            "inputPaths": {
                "rulesCsv": "rules.csv",
                "remediationKb": "kb.json",
                "asisSchema": "asis.json",
                "incompatibilityResults": "incompat.json",
                "schemaAnalysis": "analysis.json",
                "ddlScript": "script.sql",
            },
        },
    )
    assert response.status_code == 400


def test_mssql_launch_rejects_missing_schema_analysis(api_client):
    test_client, _ = api_client
    response = test_client.post(
        MSSQL_LAUNCH,
        json={
            "dbName": "SalesDB",
            "targetDatabaseVersion": "16",
            "inputPaths": {
                "ddlExport": "script.sql",
                "asisSchema": "asis.json",
                "incompatibilityResults": "incompat.json",
                "rulesRemediation": "rules_remediation.json",
            },
        },
    )
    assert response.status_code == 400
    message = str(response.json()["detail"])
    assert "schemaAnalysis" in message


def test_mssql_launch_and_oracle_status(api_client, fake_model_caller, monkeypatch):
    test_client, _ = api_client
    from app.services.mssql_pg.workspace import job_root

    db_name = "ResortsLiteDB"
    input_paths = stage_compass_files(job_root(db_name) / "_claude", db_name=db_name)
    monkeypatch.setattr("app.services.mssql_pg.orchestrator.make_sdk_caller", lambda config: fake_model_caller)

    response = test_client.post(
        MSSQL_LAUNCH,
        json={
            "jobId": "api01",
            "analysisId": "8",
            "dbName": db_name,
            "sourceDatabaseVersion": "SQL Server 2019",
            "targetDatabaseVersion": "16",
            "ruleScope": "all",
            "selectedRules": [],
            "inputPaths": input_paths,
        },
    )
    assert response.status_code == 202
    body = response.json()
    assert body["jobId"] == "api01"
    assert body["status"] == "queued"
    assert db_name in body["workspacePath"]
    assert "schema-modernization" in body["workspacePath"].replace("\\", "/")

    config = json.loads((job_root(db_name) / "job_config.json").read_text(encoding="utf-8"))
    assert config["engine"] == "mssql"
    assert config["analysisId"] == "8"
    assert config["ruleScope"] == "all"
    assert config["selectedRules"] == []
    assert config["aiAgent"] == "claude-sonnet-5-5"
    assert set(config["inputPaths"]) == {
        "ddlExport",
        "asisSchema",
        "incompatibilityResults",
        "rulesRemediation",
        "schemaAnalysis",
    }

    status = test_client.get(f"{ORACLE}/jobs/api01")
    assert status.status_code == 200
    payload = status.json()
    assert payload["jobId"] == "api01"
    assert payload["status"] in {"queued", "in_progress", "completed", "completed_with_warnings"}

    removed_status = test_client.get(f"{PREFIX}/api/mssql-pg-transformation/jobs/api01")
    assert removed_status.status_code == 404
    removed_stream = test_client.get(f"{PREFIX}/api/mssql-pg-transformation/jobs/api01/stream")
    assert removed_stream.status_code == 404


def test_oracle_status_404_for_unknown_job(api_client):
    test_client, _ = api_client
    response = test_client.get(f"{ORACLE}/jobs/doesnotexist")
    assert response.status_code == 404


def test_shared_database_transformations_router_removed(api_client):
    test_client, _ = api_client
    response = test_client.get(f"{PREFIX}/api/database-transformations/mssql/jobs/x/objects")
    assert response.status_code == 404


def test_oracle_urls_serve_mssql_job_after_launch(api_client, fake_model_caller, monkeypatch):
    test_client, _ = api_client
    from app.services.mssql_pg.job_manager import get_job_manager
    from app.services.mssql_pg.workspace import job_root

    db_name = "ResortsLiteDB"
    input_paths = stage_compass_files(job_root(db_name) / "_claude", db_name=db_name)
    monkeypatch.setattr("app.services.mssql_pg.orchestrator.make_sdk_caller", lambda config: fake_model_caller)

    manager = get_job_manager()

    async def _run():
        await manager.launch({"jobId": "api02", "dbName": db_name, "targetDatabaseVersion": "16", "inputPaths": input_paths})
        task = next(iter(manager._tasks.values()), None)
        if task is not None:
            await task

    asyncio.run(_run())

    status = test_client.get(f"{ORACLE}/jobs/api02")
    assert status.status_code == 200
    body = status.json()
    assert body["status"] == "completed"
    assert body["message"] == "DB Modernization Completed"
    assert body["objectsTotal"] == 6
    assert body["progressPercent"] == 100
    assert body["artifacts"]

    objects = test_client.get(f"{ORACLE}/jobs/api02/objects")
    assert objects.status_code == 200
    payload = objects.json()
    assert payload["total"] == 6
    assert payload["objects"]

    summary = test_client.get(f"{ORACLE}/jobs/api02/transformation-summary")
    assert summary.status_code == 200
    assert summary.json()["summary"]["conversionResult"]["total_objects"] == 6

    artifacts = test_client.get(f"{ORACLE}/jobs/api02/artifacts")
    assert artifacts.status_code == 200
    names = {a["name"] for a in artifacts.json()["artifacts"]}
    assert "transformation_summary.json" in names
    assert "Manual_Review_Checklist.csv" in names
    assert f"{db_name}_complete_schema.sql" in names
    assert f"{db_name}_postgresql_scripts.zip" in names
    for suffix in (
        "create_schemas.sql",
        "create_sequences.sql",
        "create_types.sql",
        "create_tables.sql",
        "create_primary_keys.sql",
        "create_unique_constraints.sql",
        "create_foreign_keys.sql",
        "create_check_constraints.sql",
        "create_indexes.sql",
        "create_views.sql",
        "create_materialized_views.sql",
        "create_functions.sql",
        "create_procedures.sql",
        "create_triggers.sql",
        "create_security_policies.sql",
        "create_synonyms.sql",
    ):
        assert f"{db_name}_{suffix}" in names

    download = test_client.get(f"{ORACLE}/jobs/api02/artifacts/download")
    assert download.status_code == 200
    assert download.headers["content-type"].startswith("application/zip")

    one = test_client.get(f"{ORACLE}/jobs/api02/artifacts/transformation_summary.json")
    assert one.status_code == 200

    bad = test_client.get(f"{ORACLE}/jobs/api02/artifacts/not_a_real_file.sql")
    assert bad.status_code == 404

    stream = test_client.get(f"{ORACLE}/jobs/api02/stream")
    assert stream.status_code == 200
    assert "progress_updated" in stream.text
    # Phases publish their own percent. The bar must see those values, not only the final 100.
    assert '"progressPercent": 20' in stream.text or '"progressPercent":20' in stream.text
    assert '"progressPercent": 100' in stream.text or '"progressPercent":100' in stream.text

    logs = test_client.get(f"{ORACLE}/jobs/api02/logs/stream")
    assert logs.status_code == 200


def test_oracle_existing_routes_still_registered(api_client):
    test_client, _ = api_client
    response = test_client.get(f"{ORACLE}/jobs/doesnotexist")
    assert response.status_code == 404
    response = test_client.post(f"{ORACLE}/launch", json={})
    assert response.status_code == 400


def test_mssql_launch_accepts_absolute_schema_modernization_paths(api_client):
    """studio-core stages Compass files under schema-modernization/{db}/_claude and sends absolute paths."""
    test_client, _ = api_client
    from app.services.mssql_pg.workspace import job_root

    db_name = "DB0150"
    claude = job_root(db_name) / "_claude"
    staged = stage_compass_files(claude, db_name=db_name)
    ddl = claude / "test_schema_simple.sql"
    (claude / staged["ddlExport"]).replace(ddl)
    absolute_inputs = {key: str((claude / name).resolve()) for key, name in staged.items()}
    absolute_inputs["ddlExport"] = str(ddl.resolve())

    response = test_client.post(
        MSSQL_LAUNCH,
        json={
            "jobId": "DB0150",
            "dbName": db_name,
            "targetDatabaseVersion": "16",
            "inputPaths": absolute_inputs,
        },
    )
    assert response.status_code == 202
    workspace = response.json()["workspacePath"].replace("\\", "/")
    assert workspace.endswith("schema-modernization/DB0150")
    assert "mssql-pg-transformation" not in workspace


def test_locate_job_uses_mssql_engine_in_shared_package(api_client, tmp_path):
    from app.services.db_transformation.sources import SourceType, locate_job, reset_adapter_cache
    from app.services.mssql_pg.progress import default_progress, save_progress

    reset_adapter_cache()
    root = tmp_path / "schema-modernization" / "DB0150"
    (root / "state").mkdir(parents=True)
    (root / "job_config.json").write_text(
        json.dumps({"jobId": "DB0150", "dbName": "DB0150", "engine": "mssql"}),
        encoding="utf-8",
    )
    save_progress("DB0150", default_progress("DB0150"))

    located = locate_job("DB0150")
    assert located is not None
    assert located.source == SourceType.MSSQL
    assert located.folder_key == "DB0150"


def test_locate_job_prefers_oracle_folder(api_client, tmp_path):
    from app.services.db_transformation.sources import SourceType, locate_job, reset_adapter_cache
    from app.services.oracle_pg.progress import default_progress, save_progress

    reset_adapter_cache()
    oracle_root = tmp_path / "schema-modernization" / "SharedId"
    (oracle_root / "state").mkdir(parents=True)
    (oracle_root / "job_config.json").write_text(
        json.dumps({"jobId": "shared01", "dbName": "SharedId"}),
        encoding="utf-8",
    )
    progress = default_progress("shared01")
    save_progress("SharedId", progress)

    located = locate_job("shared01")
    assert located is not None
    assert located.source == SourceType.ORACLE
    assert located.folder_key == "SharedId"
