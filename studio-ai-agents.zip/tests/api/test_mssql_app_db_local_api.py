"""Local API contract smoke for MSSQL App+DB (launch, status, stream, logs, progress)."""

from __future__ import annotations

import json

import pytest

from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.run_helpers import launch_mssql_and_complete, patch_mssql_app_db_workspace

BASE = "/studio-ai-agents/api/app-db-transformation"


@pytest.mark.asyncio
async def test_mssql_local_api_launch_status_progress_logs_stream(app_client, tmp_path, monkeypatch):
    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    app_id = "APP-LOCAL-1"
    db_id = "DB-LOCAL-MSSQL"

    tid, checkout, launch_body = await launch_mssql_and_complete(
        monkeypatch,
        tmp_path,
        lang="java",
        app_id=app_id,
        db_id=db_id,
        app_client=app_client,
    )
    assert launch_body["jobId"] == app_id
    assert launch_body["status"] in ("QUEUED", "IN_PROGRESS", "COMPLETED")

    by_app = app_client.get(f"{BASE}/jobs/{app_id}")
    assert by_app.status_code == 200, by_app.text
    status = by_app.json()
    assert status["transformationId"] == tid
    assert status["progressPercent"] == 100
    assert status["status"] in ("completed", "COMPLETED", "Completed")

    by_db = app_client.get(f"{BASE}/jobs/{db_id}")
    assert by_db.status_code == 200
    assert by_db.json()["transformationId"] == tid

    progress = app_client.get(f"{BASE}/{tid}/progress")
    assert progress.status_code == 200
    prog = progress.json()
    assert prog["overallStatus"] == "COMPLETED"
    assert prog["progressPercent"] == 100

    logs = app_client.get(f"{BASE}/{tid}/logs", params={"fromIndex": 0})
    assert logs.status_code == 200
    assert len(logs.json()["logs"]) >= 1

    job_logs = app_client.get(f"{BASE}/jobs/{app_id}/logs", params={"fromIndex": 0})
    assert job_logs.status_code == 200
    assert job_logs.json()["logs"]

    report = app_client.get(f"{BASE}/{tid}/report")
    assert report.status_code == 200
    assert report.json().get("overallStatus") == "COMPLETED"

    stream = app_client.get(f"{BASE}/jobs/{app_id}/stream", timeout=30)
    assert stream.status_code == 200
    body = stream.text
    assert "data:" in body
    assert "progress" in body.lower() or "progressPercent" in body

    log_stream = app_client.get(f"{BASE}/jobs/{app_id}/logs/stream", timeout=30)
    assert log_stream.status_code == 200
    assert "data:" in log_stream.text

    assert ws.state_path(db_id).is_file()
    state = json.loads(ws.state_path(db_id).read_text(encoding="utf-8"))
    assert state["app_id"] == app_id
    assert checkout.exists()


@pytest.mark.asyncio
async def test_mssql_local_api_with_llm_mocked_progress_and_logs(app_client, tmp_path, monkeypatch):
    """LLM path (skipLlm=false) with mocked remediator — progress and logs still update."""
    app_id = "APP-LLM-1"
    db_id = "DB-LLM-MSSQL"
    tid, checkout, _ = await launch_mssql_and_complete(
        monkeypatch,
        tmp_path,
        lang="java",
        app_id=app_id,
        db_id=db_id,
        app_client=app_client,
        skip_llm=False,
    )
    dao = checkout / "src/main/java/com/example/Dao.java"
    assert "postgresql" in dao.read_text(encoding="utf-8").lower()

    progress = app_client.get(f"{BASE}/{tid}/progress")
    assert progress.status_code == 200
    assert progress.json()["overallStatus"] == "COMPLETED"

    logs = app_client.get(f"{BASE}/{tid}/logs", params={"fromIndex": 0}).json()["logs"]
    messages = " ".join(entry.get("message", "") for entry in logs).lower()
    assert "remediat" in messages or "claude" in messages or "transformation" in messages
