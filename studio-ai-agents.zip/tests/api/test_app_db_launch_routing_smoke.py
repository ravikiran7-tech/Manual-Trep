"""Smoke: ``POST /launch`` routes to Oracle vs MSSQL engines from staged inputs."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from app.services.mssql_app_db.infer_launch import ENGINE_MSSQL, ENGINE_ORACLE, infer_engine_for_db
from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.mssql_test_assets import stage_mssql_inputs
from tests.services.oracle_pg.app_db_change.run_helpers import (
    patch_app_db_workspace,
    stage_fixture_inputs,
    stage_job2_complete,
)

BASE = "/studio-ai-agents/api/app-db-transformation"


def _no_background(coro, *args, **kwargs):
    coro.close()

    class _Task:
        cancelled = False

        def done(self):
            return False

        def add_done_callback(self, _cb):
            return None

    return _Task()


@pytest.mark.parametrize(
    "db_id,engine",
    [
        ("ORACLE-SMOKE", ENGINE_ORACLE),
        ("MSSQL-SMOKE", ENGINE_MSSQL),
    ],
)
def test_launch_smoke_routes_by_staged_inputs(app_client, tmp_path, monkeypatch, db_id, engine):
    patch_app_db_workspace(monkeypatch, tmp_path)
    checkout = tmp_path / "proj"
    checkout.mkdir()
    stage_job2_complete(db_id)

    if engine == ENGINE_MSSQL:
        stage_mssql_inputs(ws.inputs_dir(db_id), checkout, lang="java")
    else:
        stage_fixture_inputs(db_id, checkout)

    assert infer_engine_for_db(db_id) == engine

    oracle_launch = AsyncMock(
        return_value={
            "transformationId": "APPDB-ORACLE-MOCK",
            "jobId": "A1",
            "status": "QUEUED",
            "message": "oracle",
        }
    )
    mssql_launch = AsyncMock(
        return_value={
            "transformationId": "APPDB-MSSQL-MOCK",
            "jobId": "A1",
            "status": "QUEUED",
            "message": "mssql",
        }
    )

    body = {
        "appId": "A1",
        "dbId": db_id,
        "projectPath": str(checkout),
        "projectType": "java",
        "skipLlm": True,
    }

    with patch(
        "app.api.v1.app_db_transformation_dispatch.asyncio.create_task",
        side_effect=_no_background,
    ):
        with patch(
            "app.services.oracle_pg.app_db_change.job_manager.AppDbJobManager.launch",
            oracle_launch,
        ):
            with patch(
                "app.services.mssql_app_db.job_manager.MssqlAppDbJobManager.launch",
                mssql_launch,
            ):
                resp = app_client.post(f"{BASE}/launch", json=body)

    assert resp.status_code == 202, resp.text
    if engine == ENGINE_MSSQL:
        mssql_launch.assert_awaited_once()
        oracle_launch.assert_not_awaited()
        assert resp.json()["transformationId"] == "APPDB-MSSQL-MOCK"
        args = mssql_launch.await_args.args[0]
        assert args.get("dbId") == db_id
        assert args.get("skipLlm") is True
    else:
        oracle_launch.assert_awaited_once()
        mssql_launch.assert_not_awaited()
        assert resp.json()["transformationId"] == "APPDB-ORACLE-MOCK"


def test_oracle_pathway_prompt_unchanged_for_m_basic():
    from app.services.oracle_pg.app_db_change.agent_runner import render_remediator_prompt

    basic = render_remediator_prompt(
        plan={"pathway": "M-Basic", "violations": [], "catalogSubset": {}},
        project_path="/checkout",
    )
    assert "application*.properties" in basic
    assert "MSSQL" not in basic
