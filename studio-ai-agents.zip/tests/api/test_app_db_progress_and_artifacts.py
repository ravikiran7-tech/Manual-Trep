"""App+DB job status, SSE progress stream and artifact APIs."""

import json
import zipfile

import pytest

from app.services.oracle_pg.app_db_change import artifacts as artifact_ops
from app.services.oracle_pg.app_db_change import events as event_bus
from app.services.oracle_pg.app_db_change.progress_tracker import job_dir
from tests.services.oracle_pg.app_db_change.run_helpers import launch_and_complete

BASE = "/studio-ai-agents/api/app-db-transformation"


@pytest.mark.asyncio
async def test_job_status_matches_db_job_contract(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")
    r = app_client.get(f"{BASE}/jobs/{tid}")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["jobId"] == "A1"
    assert body["transformationId"] == tid
    assert body["status"] == "completed"
    assert body["overallStatus"] == "COMPLETED"
    assert body["phase"] == "Completed"
    assert body["progressPercent"] == 100
    assert body["objectsConverted"] == body["filesModified"] >= 1
    assert body["objectsTotal"] >= body["objectsConverted"]
    assert body["errorDetail"] is None
    assert body["reportAvailable"] is True
    assert "commit" not in body
    assert "commitStatus" not in body
    assert body["startedAt"] and body["completedAt"]
    assert body["durationSeconds"] is not None
    assert body["statusText"] == "Transformation complete"


@pytest.mark.asyncio
async def test_job_status_resolves_by_db_id_and_app_id(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    by_db = app_client.get(f"{BASE}/jobs/D1")
    assert by_db.status_code == 200
    assert by_db.json()["transformationId"] == tid
    assert by_db.json()["jobId"] == "A1"

    by_app = app_client.get(f"{BASE}/jobs/A1")
    assert by_app.status_code == 200
    assert by_app.json()["transformationId"] == tid
    assert by_app.json()["jobId"] == "A1"

    assert app_client.get(f"{BASE}/jobs/NOPE").status_code == 404


@pytest.mark.asyncio
async def test_job_stream_resolves_by_app_id(app_client, tmp_path, monkeypatch):
    await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")
    r = app_client.get(f"{BASE}/jobs/A1/stream")
    assert r.status_code == 200, r.text
    assert "progress_updated" in r.text
    assert '"jobId": "A1"' in r.text


@pytest.mark.asyncio
async def test_progress_stream_percent_and_terminal_extras(tmp_path, monkeypatch):
    from app.api.v1.app_db_transformation import _tail_progress_events

    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    chunks = [chunk async for chunk in _tail_progress_events(tid)]
    events = [
        json.loads(chunk[len("data: ") :].strip())
        for chunk in chunks
        if chunk.startswith("data: ")
    ]
    progress = [e for e in events if e["type"] == "progress_updated"]
    assert progress
    percents = [e["progressPercent"] for e in progress]
    assert percents == sorted(percents)
    assert percents[-1] == 100
    terminal = progress[-1]
    assert terminal["status"] == "completed"
    assert terminal["jobId"] == "A1"
    assert terminal["transformationId"] == tid
    assert terminal["reportAvailable"] is True
    assert "commit" not in terminal
    assert event_bus.is_terminal_event(terminal)


@pytest.mark.asyncio
async def test_progress_stream_ends_on_failure(tmp_path, monkeypatch):
    from app.api.v1.app_db_transformation import _tail_progress_events
    from app.services.oracle_pg.app_db_change.job_manager import get_app_db_job_manager
    from tests.services.oracle_pg.app_db_change.run_helpers import (
        patch_app_db_workspace,
        stage_fixture_inputs,
    )

    patch_app_db_workspace(monkeypatch, tmp_path)
    db_id = "D1"
    checkout = tmp_path / "checkout"
    checkout.mkdir()
    stage_fixture_inputs(db_id, checkout)

    async def _boom(**_kwargs):
        return __import__(
            "app.services.oracle_pg.agent_runner", fromlist=["SessionResult"]
        ).SessionResult(success=False, error_message="forced remediator failure")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.orchestrator.run_app_db_remediator_session",
        _boom,
    )

    manager = get_app_db_job_manager()
    started = await manager.launch(
        {
            "appId": "A1",
            "dbId": db_id,
            "projectPath": str(checkout),
            "inputPaths": {
                "dependencyFindings": "java-oracle-dependency.json",
                "rulesRemediation": "oracle-to-postgresql-rules_remediation.json",
            },
        }
    )
    tid = started["transformationId"]
    assert started["jobId"] == "A1"
    task = manager._tasks.get(db_id)
    if task is not None:
        await task

    events = [
        json.loads(chunk[len("data: ") :].strip())
        async for chunk in _tail_progress_events(tid)
        if chunk.startswith("data: ")
    ]
    terminal = events[-1]
    assert terminal["status"] == "failed"
    assert terminal["phase"] == "Failed"
    assert terminal["errorDetail"]
    assert terminal["statusText"] == "Transformation failed"


@pytest.mark.asyncio
async def test_progress_endpoint_exposes_percent_metrics_and_groups(
    app_client, tmp_path, monkeypatch
):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    body = app_client.get(f"{BASE}/{tid}/progress").json()
    assert body["progressPercent"] == 100
    assert body["overallStatus"] == "COMPLETED"
    assert body["bannerMessage"] == "App-DB Dependency Code Changes Completed Successfully."
    assert body["metrics"]["filesModified"] >= 1
    assert "commit" not in body
    groups = {m["id"]: m["group"] for m in body["milestones"]}
    assert groups == {
        1: "Configurations",
        2: "Transformation",
        3: "Transformation",
        4: "Artifacts",
        5: "Transformation",
    }


@pytest.mark.asyncio
async def test_report_endpoint_returns_display_blocks(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    r = app_client.get(f"{BASE}/{tid}/report")
    assert r.status_code == 200, r.text
    report = r.json()
    assert report["header"]["title"].startswith("Post-Transformation Report:")
    assert len(report["metadataRow"]) == 5
    assert len(report["executiveSummary"]["summaryCards"]) == 4
    assert "commit" not in report
    assert app_client.get(f"{BASE}/APPDB-NOPE/report").status_code == 404


@pytest.mark.asyncio
async def test_commit_routes_return_gone(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    assert app_client.get(f"{BASE}/{tid}/commit").status_code == 410
    assert app_client.post(f"{BASE}/{tid}/commit/retry", json={}).status_code == 410
    assert (
        app_client.post(
            f"{BASE}/{tid}/commit-result",
            json={"status": "COMPLETED", "commitHash": "a3f92bc9998887"},
        ).status_code
        == 410
    )

    artifacts = {
        a["key"]: a for a in app_client.get(f"{BASE}/{tid}/artifacts").json()["artifacts"]
    }
    assert "githubCommit" not in artifacts
    assert artifacts["postTransformationReport"]["exists"] is True
    assert artifacts["transformedCode"]["exists"] is True


@pytest.mark.asyncio
async def test_transformed_code_zip_download(app_client, tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    archive = artifact_ops.zip_path(tid)
    assert archive.is_file()
    names = zipfile.ZipFile(archive).namelist()
    assert "post_transformation_report.json" in names

    r = app_client.get(f"{BASE}/{tid}/artifacts/download")
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/zip"


@pytest.mark.asyncio
async def test_events_persisted_for_late_subscribers(tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")
    events = event_bus.read_events(job_dir(tid))
    assert [e for e in events if e["type"] == "progress_updated"]
    assert [e for e in events if e["type"] == "artifact_ready"]
    assert not [e for e in events if e.get("type") == "commit_updated"]


@pytest.mark.asyncio
async def test_logs_reachable_by_job_id_and_transformation_id(
    app_client, tmp_path, monkeypatch
):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")

    by_tid = app_client.get(f"{BASE}/{tid}/logs", params={"fromIndex": 0})
    by_job = app_client.get(f"{BASE}/jobs/{tid}/logs", params={"fromIndex": 0})
    by_app = app_client.get(f"{BASE}/jobs/A1/logs", params={"fromIndex": 0})
    by_db = app_client.get(f"{BASE}/jobs/D1/logs", params={"fromIndex": 0})
    for r in (by_tid, by_job, by_app, by_db):
        assert r.status_code == 200, r.text
    assert by_job.json() == by_tid.json() == by_app.json() == by_db.json()
    assert by_tid.json()["logs"]


@pytest.mark.asyncio
async def test_job_status_response_carries_every_field_the_sse_event_does(
    app_client, tmp_path, monkeypatch
):
    tid, _, _ = await launch_and_complete(monkeypatch, tmp_path, app_id="A1", db_id="D1")
    from app.services.oracle_pg.app_db_change.progress_tracker import get_progress_tracker

    source = get_progress_tracker().get_status_payload(tid)
    body = app_client.get(f"{BASE}/jobs/{tid}").json()
    missing = sorted(set(source) - set(body))
    assert not missing, f"response model drops fields present in the payload: {missing}"
    assert "commit" not in body
    assert body["reportStatus"] == "COMPLETED"
    assert body["reportFileSizeBytes"] > 0
