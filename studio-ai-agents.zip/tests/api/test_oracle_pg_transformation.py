"""API tests for Oracle PG transformation router."""
import json
import shutil
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from app.services.oracle_pg.progress import STATUS_COMPLETED, STATUS_QUEUED, save_progress, default_progress

BASE = "/studio-ai-agents/api/oracle-pg-transformation"
FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "oracle_pg"
MODERNIZATION = "schema-modernization"


def _launch_payload() -> dict:
    return {
        "dbName": "HRDB",
        "targetDatabaseVersion": "16",
        "inputPaths": {
            "ddlExport": "_claude/schema.sql",
            "asisSchema": "_claude/asis.json",
            "incompatibilityResults": "_claude/incompat.json",
            "rulesRemediation": "_claude/remediation.json",
        },
        "selectedRules": ["dbm-oracle-pgsql-001"],
        "ruleScope": "all",
        "jobId": "JOBTEST01",
    }


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("15", "15"),
        ("16", "16"),
        ("15.0", "15"),
        ("16.0", "16"),
        (15, "15"),
        (16.0, "16"),
    ],
)
def test_launch_request_normalizes_target_database_version(raw, expected):
    from app.models.oracle_pg_transformation import LaunchOraclePgTransformationRequest

    request = LaunchOraclePgTransformationRequest(
        dbName="HRDB",
        targetDatabaseVersion=raw,
        inputPaths={
            "ddlExport": "_claude/schema.sql",
            "asisSchema": "_claude/asis.json",
            "incompatibilityResults": "_claude/incompat.json",
            "rulesRemediation": "_claude/remediation.json",
        },
    )
    assert request.target_database_version == expected


def test_launch_returns_202(app_client):
    with patch(
        "app.api.v1.oracle_pg_transformation.get_job_manager"
    ) as mock_get:
        manager = mock_get.return_value
        manager.launch = AsyncMock(
            return_value={
                "jobId": "JOBTEST01",
                "status": STATUS_QUEUED,
                "workspacePath": "/tmp/schema-modernization/HRDB",
                "dbName": "HRDB",
            }
        )
        r = app_client.post(f"{BASE}/launch", json=_launch_payload())
    assert r.status_code == 202
    body = r.json()
    assert body["jobId"] == "JOBTEST01"
    assert body["status"] == STATUS_QUEUED


def test_get_job_status(app_client, tmp_path, monkeypatch):
    db_name = "JOBSTAT01"
    base = tmp_path / MODERNIZATION / db_name
    base.mkdir(parents=True)

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())
    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    progress = default_progress(db_name)
    progress["status"] = "in_progress"
    progress["progressPercent"] = 35
    save_progress(db_name, progress)

    r = app_client.get(f"{BASE}/jobs/{db_name}")
    assert r.status_code == 200
    assert r.json()["progressPercent"] == 35


def test_get_job_status_includes_timing_when_completed(app_client, tmp_path, monkeypatch):
    db_name = "JOBTIME01"
    base = tmp_path / MODERNIZATION / db_name
    (base / "output").mkdir(parents=True)
    (base / "state").mkdir(parents=True)

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())
    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    progress = default_progress(db_name)
    progress["status"] = STATUS_COMPLETED
    progress["startedAt"] = "2026-01-01T00:00:00+00:00"
    progress["completedAt"] = "2026-01-01T01:00:00+00:00"
    save_progress(db_name, progress)

    summary = {
        "executiveSummary": {
            "successfullyConverted": 5,
            "requiresReview": 1,
            "failed": 0,
            "totalObjects": 6,
        }
    }
    (base / "output" / "transformation_summary.json").write_text(
        json.dumps(summary), encoding="utf-8"
    )

    r = app_client.get(f"{BASE}/jobs/{db_name}")
    assert r.status_code == 200
    body = r.json()
    assert body["durationSeconds"] == 3600
    assert body["duration"] == "60m"
    assert body["executiveSummary"]["successfullyConverted"] == 5


def test_get_transformation_summary(app_client, tmp_path, monkeypatch):
    db_name = "JOBSUM01"
    base = tmp_path / MODERNIZATION / db_name
    (base / "output").mkdir(parents=True)
    (base / "state").mkdir(parents=True)

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())
    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    progress = default_progress(db_name)
    progress["status"] = STATUS_COMPLETED
    save_progress(db_name, progress)

    payload = {"databaseMetadata": {"databaseId": "DB1"}, "executiveSummary": {"totalObjects": 3}}
    (base / "output" / "transformation_summary.json").write_text(
        json.dumps(payload), encoding="utf-8"
    )

    r = app_client.get(f"{BASE}/jobs/{db_name}/transformation-summary")
    assert r.status_code == 200
    body = r.json()
    assert body["jobId"] == db_name
    assert body["summary"]["databaseMetadata"]["databaseId"] == "DB1"


def test_get_transformation_summary_not_completed(app_client, tmp_path, monkeypatch):
    db_name = "JOBPEND01"
    base = tmp_path / MODERNIZATION / db_name
    base.mkdir(parents=True)

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())
    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    progress = default_progress(db_name)
    progress["status"] = "in_progress"
    save_progress(db_name, progress)

    r = app_client.get(f"{BASE}/jobs/{db_name}/transformation-summary")
    assert r.status_code == 404


def test_get_job_status_not_found(app_client):
    r = app_client.get(f"{BASE}/jobs/DOESNOTEXIST")
    assert r.status_code == 404


def test_logs_stream_not_found(app_client):
    r = app_client.get(f"{BASE}/jobs/DOESNOTEXIST/logs/stream")
    assert r.status_code == 404


def test_logs_stream_route_registered():
    from app.api.v1.oracle_pg_transformation import router

    paths = [getattr(route, "path", "") for route in router.routes]
    assert any("logs/stream" in path for path in paths)


def _patch_oracle_pg_workspace(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())
    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )


@pytest.mark.asyncio
async def test_job_stream_no_keepalive_when_completed(tmp_path, monkeypatch):
    from app.api.v1.oracle_pg_transformation import _tail_events

    db_name = "STREAMDONE01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)
    (tmp_path / MODERNIZATION / db_name).mkdir(parents=True)

    progress = default_progress(db_name)
    progress["status"] = STATUS_COMPLETED
    progress["message"] = "DB Modernization Completed"
    save_progress(db_name, progress)

    chunks: list[str] = []
    async for chunk in _tail_events(db_name):
        chunks.append(chunk)

    body = "".join(chunks)
    assert ": keepalive" not in body
    assert "progress_updated" in body
    assert "completed" in body


@pytest.mark.asyncio
async def test_logs_stream_no_keepalive_when_completed(tmp_path, monkeypatch):
    from app.api.v1.oracle_pg_transformation import _tail_logs
    from app.services.oracle_pg.hooks import append_log_entry_sync
    from app.services.oracle_pg.live_logs import build_log_entry

    db_name = "LOGSDONE01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)
    (tmp_path / MODERNIZATION / db_name).mkdir(parents=True)

    progress = default_progress(db_name)
    progress["status"] = STATUS_COMPLETED
    save_progress(db_name, progress)

    append_log_entry_sync(
        db_name,
        build_log_entry(db_name, message="DB Modernization Completed", icon="check"),
    )

    chunks: list[str] = []
    async for chunk in _tail_logs(db_name):
        chunks.append(chunk)

    body = "".join(chunks)
    assert ": keepalive" not in body
    assert "DB Modernization Completed" in body


@pytest.mark.asyncio
async def test_mssql_schema_logs_tail_streams_from_mssql_hooks(tmp_path, monkeypatch):
    """MSSQL jobs notify ``mssql_pg.hooks``; log SSE must subscribe there."""
    from app.api.v1.mssql_pg_log_stream import tail_mssql_pg_logs
    from app.services.db_transformation.sources import JOB_ENGINE_FIELD, JOB_ENGINE_MSSQL
    from app.services.mssql_pg.hooks import append_log
    from app.services.mssql_pg.progress import STATUS_COMPLETED

    db_name = "MSSQLLOGS01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)

    class _MssqlSettings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: _MssqlSettings())

    root = tmp_path / MODERNIZATION / db_name
    (root / "stream").mkdir(parents=True)
    (root / "state").mkdir(parents=True)
    (root / "job_config.json").write_text(
        json.dumps({"jobId": db_name, JOB_ENGINE_FIELD: JOB_ENGINE_MSSQL}),
        encoding="utf-8",
    )
    (root / "state" / "progress.json").write_text(
        json.dumps({"jobId": db_name, "status": STATUS_COMPLETED}),
        encoding="utf-8",
    )

    append_log(db_name, "Completed", "MSSQL schema log line", icon="check")

    chunks: list[str] = []
    async for chunk in tail_mssql_pg_logs(db_name):
        chunks.append(chunk)

    body = "".join(chunks)
    assert ": keepalive" not in body
    assert "MSSQL schema log line" in body


@pytest.mark.asyncio
async def test_mssql_schema_progress_stream_backfills_when_events_file_empty(tmp_path, monkeypatch):
    """After refresh, completed jobs must still emit at least one progress_updated."""
    from app.services.db_transformation.sources import SourceType, get_adapter
    from app.services.db_transformation.streaming import tail_progress_events
    from app.services.db_transformation.sources import JOB_ENGINE_FIELD, JOB_ENGINE_MSSQL
    from app.services.mssql_pg.progress import STATUS_COMPLETED, default_progress

    db_name = "MSSQLBACKFILL01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)

    class _MssqlSettings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: _MssqlSettings())

    root = tmp_path / MODERNIZATION / db_name
    (root / "stream").mkdir(parents=True)
    (root / "state").mkdir(parents=True)
    (root / "job_config.json").write_text(
        json.dumps({"jobId": db_name, JOB_ENGINE_FIELD: JOB_ENGINE_MSSQL}),
        encoding="utf-8",
    )
    # events.jsonl intentionally missing — only progress.json on disk
    completed = default_progress(db_name)
    completed["status"] = STATUS_COMPLETED
    completed["progressPercent"] = 100
    completed["message"] = "DB Modernization Completed"
    (root / "state" / "progress.json").write_text(json.dumps(completed), encoding="utf-8")

    adapter = get_adapter(SourceType.MSSQL)
    chunks: list[str] = []
    async for chunk in tail_progress_events(db_name, db_name, adapter):
        chunks.append(chunk)

    body = "".join(chunks)
    assert "progress_updated" in body
    assert "progressPercent" in body


@pytest.mark.asyncio
async def test_mssql_schema_progress_stream_replays_intermediate_percent(tmp_path, monkeypatch):
    """MSSQL progress SSE must surface incremental progressPercent, not only completion."""
    from app.api.v1.mssql_pg_log_stream import tail_mssql_pg_events
    from app.services.db_transformation.sources import JOB_ENGINE_FIELD, JOB_ENGINE_MSSQL
    from app.services.mssql_pg.hooks import notify_progress_update
    from app.services.mssql_pg.progress import STATUS_COMPLETED, STATUS_IN_PROGRESS, default_progress

    db_name = "MSSQLPROG01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)

    class _MssqlSettings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: _MssqlSettings())

    root = tmp_path / MODERNIZATION / db_name
    (root / "stream").mkdir(parents=True)
    (root / "state").mkdir(parents=True)
    (root / "job_config.json").write_text(
        json.dumps({"jobId": db_name, JOB_ENGINE_FIELD: JOB_ENGINE_MSSQL}),
        encoding="utf-8",
    )

    mid = default_progress(db_name)
    mid["status"] = STATUS_IN_PROGRESS
    mid["progressPercent"] = 42
    mid["message"] = "AI-guided conversion: 2/4 objects processed"
    notify_progress_update(db_name, mid)

    finished = default_progress(db_name)
    finished["status"] = STATUS_COMPLETED
    finished["progressPercent"] = 100
    finished["message"] = "DB Modernization Completed"
    notify_progress_update(db_name, finished)

    chunks: list[str] = []
    async for chunk in tail_mssql_pg_events(db_name):
        chunks.append(chunk)

    body = "".join(chunks)
    assert "progress_updated" in body
    assert '"progressPercent": 42' in body or '"progressPercent":42' in body.replace(" ", "")


@pytest.mark.asyncio
async def test_job_stream_sends_keepalive_while_in_progress(tmp_path, monkeypatch):
    import asyncio

    from app.api.v1.oracle_pg_transformation import _tail_events

    db_name = "STREAMLIVE01"
    _patch_oracle_pg_workspace(tmp_path, monkeypatch)
    (tmp_path / MODERNIZATION / db_name / "stream").mkdir(parents=True)

    progress = default_progress(db_name)
    progress["status"] = "in_progress"
    save_progress(db_name, progress)

    original_wait_for = asyncio.wait_for
    timeouts = {"count": 0}

    async def wait_for_with_timeout(coro, timeout):
        timeouts["count"] += 1
        if timeouts["count"] == 1:
            coro.close()
            raise asyncio.TimeoutError()
        return await original_wait_for(coro, timeout=timeout)

    monkeypatch.setattr(asyncio, "wait_for", wait_for_with_timeout)

    chunks: list[str] = []
    async for chunk in _tail_events(db_name):
        chunks.append(chunk)
        if ": keepalive" in chunk:
            break

    assert any(": keepalive" in chunk for chunk in chunks)


def test_launch_missing_input_paths(app_client):
    r = app_client.post(
        f"{BASE}/launch",
        json={
            "dbName": "HRDB",
            "targetDatabaseVersion": "16",
        },
    )
    assert r.status_code == 400


@pytest.mark.asyncio
async def test_launch_compass_input_paths_in_place(tmp_path, monkeypatch):
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "DBTEST01"
    root = tmp_path / MODERNIZATION / db_name
    claude = root / "_claude"
    claude.mkdir(parents=True)

    ddl = claude / "schema.sql"
    ddl.write_text("CREATE TABLE app.customers (id NUMBER);", encoding="utf-8")
    shutil.copy(FIXTURES / "oracle-dbschema-asis.json", claude / "asis.json")
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-incompatability-results.json",
        claude / "incompat.json",
    )
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-rules_remediation.json",
        claude / "remediation.json",
    )

    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    with patch.object(JobManager, "_enqueue", new_callable=AsyncMock):
        manager = JobManager()
        result = await manager.launch(
            {
                "jobId": db_name,
                "dbName": db_name,
                "targetDatabaseVersion": "16",
                "inputPaths": {
                    "ddlExport": str(ddl),
                    "asisSchema": str(claude / "asis.json"),
                    "incompatibilityResults": str(claude / "incompat.json"),
                    "rulesRemediation": str(claude / "remediation.json"),
                },
            }
        )

    assert result["jobId"] == db_name
    config = json.loads((root / "job_config.json").read_text(encoding="utf-8"))
    assert config["inputMode"] == "compass_files"
    assert config["inputPaths"]["ddlExport"] == "_claude/schema.sql"
    assert config["inputPaths"]["rulesRemediation"] == "_claude/remediation.json"
    assert config["selectedRules"] == []
    assert not (root / "input" / "oracle_ddl_export.sql").exists()


@pytest.mark.asyncio
async def test_launch_accepts_parentheses_in_artifact_names(tmp_path, monkeypatch):
    """Compass exports are often named 'foo (1).sql'; those must not be rejected."""
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "DBTEST04"
    root = tmp_path / MODERNIZATION / db_name
    claude = root / "_claude"
    claude.mkdir(parents=True)

    ddl = claude / "oracle_ddl_export (1).sql"
    ddl.write_text("CREATE TABLE app.customers (id NUMBER);", encoding="utf-8")
    shutil.copy(FIXTURES / "oracle-dbschema-asis.json", claude / "asis (1).json")
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-incompatability-results.json",
        claude / "incompat.json",
    )
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-rules_remediation.json",
        claude / "remediation.json",
    )

    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    with patch.object(JobManager, "_enqueue", new_callable=AsyncMock):
        manager = JobManager()
        result = await manager.launch(
            {
                "jobId": db_name,
                "dbName": db_name,
                "targetDatabaseVersion": "16",
                "inputPaths": {
                    "ddlExport": str(ddl),
                    "asisSchema": str(claude / "asis (1).json"),
                    "incompatibilityResults": str(claude / "incompat.json"),
                    "rulesRemediation": str(claude / "remediation.json"),
                },
            }
        )

    assert result["jobId"] == db_name
    config = json.loads((root / "job_config.json").read_text(encoding="utf-8"))
    assert config["inputPaths"]["ddlExport"] == "_claude/oracle_ddl_export (1).sql"
    assert config["inputPaths"]["asisSchema"] == "_claude/asis (1).json"


@pytest.mark.asyncio
async def test_launch_rejects_shell_metacharacters_in_input_paths(tmp_path, monkeypatch):
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "DBTEST05"
    root = tmp_path / MODERNIZATION / db_name
    (root / "_claude").mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    manager = JobManager()
    with pytest.raises(ValueError, match="dangerous character"):
        await manager.launch(
            {
                "dbName": db_name,
                "targetDatabaseVersion": "16",
                "inputPaths": {
                    "ddlExport": "_claude/schema.sql; rm -rf /",
                    "asisSchema": "_claude/asis.json",
                    "incompatibilityResults": "_claude/incompat.json",
                    "rulesRemediation": "_claude/remediation.json",
                },
            }
        )


@pytest.mark.asyncio
async def test_launch_missing_rules_remediation(tmp_path, monkeypatch):
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "DBTEST03"
    root = tmp_path / MODERNIZATION / db_name
    claude = root / "_claude"
    claude.mkdir(parents=True)
    ddl = claude / "schema.sql"
    ddl.write_text("CREATE TABLE app.t (id int);", encoding="utf-8")
    shutil.copy(FIXTURES / "oracle-dbschema-asis.json", claude / "asis.json")
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-incompatability-results.json",
        claude / "incompat.json",
    )

    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    manager = JobManager()
    with pytest.raises(ValueError, match="rulesRemediation"):
        await manager.launch(
            {
                "dbName": db_name,
                "targetDatabaseVersion": "16",
                "inputPaths": {
                    "ddlExport": str(ddl),
                    "asisSchema": str(claude / "asis.json"),
                    "incompatibilityResults": str(claude / "incompat.json"),
                },
            }
        )


@pytest.mark.asyncio
async def test_launch_rejects_paths_outside_claude(tmp_path, monkeypatch):
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "DBTEST02"
    root = tmp_path / MODERNIZATION / db_name
    (root / "_claude").mkdir(parents=True)
    outside = root / "input" / "schema.sql"
    outside.parent.mkdir(parents=True)
    outside.write_text("CREATE TABLE t (id int);", encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.job_manager.settings.claude_workspace",
        str(tmp_path),
    )

    manager = JobManager()
    with pytest.raises(ValueError, match="_claude"):
        await manager.launch(
            {
                "dbName": db_name,
                "targetDatabaseVersion": "16",
                "inputPaths": {
                    "ddlExport": str(outside),
                    "asisSchema": str(FIXTURES / "oracle-dbschema-asis.json"),
                    "incompatibilityResults": str(
                        FIXTURES / "oracle-to-postgresql-incompatability-results.json"
                    ),
                    "rulesRemediation": str(
                        FIXTURES / "oracle-to-postgresql-rules_remediation.json"
                    ),
                },
            }
        )


@pytest.mark.asyncio
async def test_orchestrator_compass_skips_initializer(tmp_path, monkeypatch):
    from app.services.oracle_pg import orchestrator as orch_mod
    from app.services.oracle_pg.agent_runner import SessionResult
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "COMPASS01"
    root = tmp_path / MODERNIZATION / db_name
    claude = root / "_claude"
    for sub in ("input", "state", "output", "stream"):
        (root / sub).mkdir(parents=True)
    claude.mkdir(parents=True)

    shutil.copy(FIXTURES / "oracle-dbschema-asis.json", claude / "asis.json")
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-incompatability-results.json",
        claude / "incompat.json",
    )
    shutil.copy(
        FIXTURES / "oracle-to-postgresql-rules_remediation.json",
        claude / "remediation.json",
    )
    (claude / "schema.sql").write_text("CREATE TABLE app.t (id int);", encoding="utf-8")

    def _job_root(name, workspace_override=None):
        return tmp_path / MODERNIZATION / name

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.jobs_base",
        lambda workspace_override=None: tmp_path / MODERNIZATION,
    )
    monkeypatch.setattr("app.services.oracle_pg.workspace.job_root", _job_root)
    monkeypatch.setattr("app.services.oracle_pg.workspace.ensure_job_dirs", _job_root)
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.job_config_path",
        lambda name, workspace_override=None: _job_root(name) / "job_config.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.input_dir",
        lambda name, workspace_override=None: _job_root(name) / "input",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.state_dir",
        lambda name, workspace_override=None: _job_root(name) / "state",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.output_dir",
        lambda name, workspace_override=None: _job_root(name) / "output",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.conversion_plan_path",
        lambda name, workspace_override=None: _job_root(name) / "state" / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.progress_path",
        lambda name, workspace_override=None: _job_root(name) / "state" / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.discover_workspace_override",
        lambda name: str(tmp_path),
    )

    config = {
        "jobId": db_name,
        "dbName": "HRDB",
        "targetDatabaseVersion": "16",
        "inputMode": "compass_files",
        "inputPaths": {
            "ddlExport": "_claude/schema.sql",
            "asisSchema": "_claude/asis.json",
            "incompatibilityResults": "_claude/incompat.json",
            "rulesRemediation": "_claude/remediation.json",
        },
        "selectedRules": [],
        "ruleScope": "all",
        "claudeWorkspace": str(tmp_path),
    }
    with (_job_root(db_name) / "job_config.json").open("w", encoding="utf-8") as fh:
        json.dump(config, fh)

    save_progress(db_name, default_progress(db_name))

    sessions = []

    async def fake_session(*args, **kwargs):
        session_kind = args[3] if len(args) > 3 else kwargs.get("session_kind")
        sessions.append(session_kind)
        if session_kind == "converter":
            plan_path = root / "state" / "conversion-plan.json"
            data = json.loads(plan_path.read_text(encoding="utf-8"))
            for obj in data["objects"]:
                obj["status"] = "converted"
                obj["conversionStatus"] = "auto_converted"
            plan_path.write_text(json.dumps(data), encoding="utf-8")
        return SessionResult(success=True, session_id="sess-1", subtype="success")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)

    manager = JobManager()
    orchestrator = orch_mod.TransformationOrchestrator(manager)
    await orchestrator.run(db_name)

    assert "initializer" not in sessions
    plan = json.loads((root / "state" / "conversion-plan.json").read_text(encoding="utf-8"))
    assert len(plan["objects"]) >= 60
    customer = next(
        (
            o
            for o in plan["objects"]
            if o.get("schema") == "app" and o.get("name") == "customers"
        ),
        None,
    )
    assert customer is not None
    assert customer["incompatibilities"]
    assert customer["incompatibilities"][0]["remediation"]["remediationId"]
    assert (root / "state" / "remediation-index.json").exists()


@pytest.mark.asyncio
async def test_orchestrator_migrate_with_mocked_sdk(tmp_path, monkeypatch):
    from app.services.oracle_pg import orchestrator as orch_mod
    from app.services.oracle_pg.agent_runner import SessionResult
    from app.services.oracle_pg.job_manager import JobManager

    db_name = "ORCH01"
    root = tmp_path / MODERNIZATION / db_name
    for sub in ("input", "state", "output", "stream"):
        (root / sub).mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.jobs_base",
        lambda workspace_override=None: tmp_path / MODERNIZATION,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.job_root",
        lambda name, workspace_override=None: tmp_path / MODERNIZATION / name,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.ensure_job_dirs",
        lambda name, workspace_override=None: tmp_path / MODERNIZATION / name,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.job_config_path",
        lambda name, workspace_override=None: root / "job_config.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.input_dir",
        lambda name, workspace_override=None: root / "input",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.state_dir",
        lambda name, workspace_override=None: root / "state",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.output_dir",
        lambda name, workspace_override=None: root / "output",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.conversion_plan_path",
        lambda name, workspace_override=None: root / "state" / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.progress_path",
        lambda name, workspace_override=None: root / "state" / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.discover_workspace_override",
        lambda name: str(tmp_path),
    )

    config = {
        "jobId": db_name,
        "dbName": "HRDB",
        "targetDatabaseVersion": "16",
        "selectedRules": ["dbm-oracle-pgsql-001"],
        "ruleScope": "all",
        "claudeWorkspace": str(tmp_path),
    }
    with (root / "job_config.json").open("w", encoding="utf-8") as fh:
        json.dump(config, fh)

    with (root / "state" / "conversion-plan.json").open("w", encoding="utf-8") as fh:
        json.dump(
            {
                "objects": [
                    {
                        "objectId": "T1",
                        "type": "TABLE",
                        "schema": "HR",
                        "name": "ORDERS",
                        "status": "pending",
                    }
                ]
            },
            fh,
        )

    save_progress(db_name, default_progress(db_name))

    async def fake_session(*args, **kwargs):
        session_kind = args[3] if len(args) > 3 else kwargs.get("session_kind")
        if session_kind == "converter":
            plan_path = root / "state" / "conversion-plan.json"
            data = json.loads(plan_path.read_text(encoding="utf-8"))
            data["objects"][0]["status"] = "converted"
            data["objects"][0]["conversionStatus"] = "require_review"
            plan_path.write_text(json.dumps(data), encoding="utf-8")
        return SessionResult(success=True, session_id="sess-1", subtype="success")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(
        orch_mod,
        "conversion_plan_exists",
        lambda name, workspace_override=None: True,
    )

    manager = JobManager()
    orchestrator = orch_mod.TransformationOrchestrator(manager)
    await orchestrator.run(db_name)

    progress = json.loads((root / "state" / "progress.json").read_text(encoding="utf-8"))
    assert progress["status"] == "completed"
    assert (root / "output" / "post_transformation_report.json").exists()
