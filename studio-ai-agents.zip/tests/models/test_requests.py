"""Tests for app.models.requests."""
import pytest
from pydantic import ValidationError

from app.models.requests import (
    ClaudeCliRequest,
    SchemaModernizationRequest,
    AssessmentRuleInputItem,
    AssessmentRulesBatchRequest,
    BuildCompilationRequest,
)


# ---------------------------------------------------------------------------
# ClaudeCliRequest
# ---------------------------------------------------------------------------
def test_claude_cli_minimal_defaults():
    req = ClaudeCliRequest(projectPath="/p")
    assert req.project_path == "/p"
    assert req.prompt is None
    assert req.analysis_id is None
    assert req.operation == "analysis"
    assert req.platform == "linux"
    assert req.project_type is None


def test_claude_cli_by_field_name():
    req = ClaudeCliRequest(project_path="/p", analysis_id="A-1", project_type="dotnet")
    assert req.project_path == "/p"
    assert req.analysis_id == "A-1"
    assert req.project_type == "dotnet"


def test_claude_cli_missing_project_path():
    with pytest.raises(ValidationError):
        ClaudeCliRequest(prompt="hi")


def test_claude_cli_java_version_none_and_value():
    assert ClaudeCliRequest(projectPath="/p", javaVersion=None).java_version is None
    req = ClaudeCliRequest(projectPath="/p", javaVersion="17")
    assert req.java_version == "17"
    # lenient - any string allowed
    assert ClaudeCliRequest(projectPath="/p", javaVersion="weird").java_version == "weird"


def test_claude_cli_dotnet_version_none_and_value():
    assert ClaudeCliRequest(projectPath="/p", dotnetVersion=None).dotnet_version is None
    req = ClaudeCliRequest(projectPath="/p", dotnetVersion="8.0")
    assert req.dotnet_version == "8.0"
    assert ClaudeCliRequest(projectPath="/p", dotnetVersion="legacy").dotnet_version == "legacy"


def test_claude_cli_valid_operation():
    req = ClaudeCliRequest(projectPath="/p", operation="cloudreadiness-fix")
    assert req.operation == "cloudreadiness-fix"


def test_claude_cli_invalid_operation():
    with pytest.raises(ValidationError) as exc:
        ClaudeCliRequest(projectPath="/p", operation="bogus-op")
    assert "Invalid operation" in str(exc.value)


def test_claude_cli_valid_platform():
    req = ClaudeCliRequest(projectPath="/p", platform="windows")
    assert req.platform == "windows"


def test_claude_cli_invalid_platform():
    with pytest.raises(ValidationError) as exc:
        ClaudeCliRequest(projectPath="/p", platform="solaris")
    assert "Invalid platform" in str(exc.value)


@pytest.mark.parametrize("operation", ["fix-upgrade", "build-compilation"])
def test_is_prompt_required_false_for_file_ops(operation):
    req = ClaudeCliRequest(projectPath="/p", operation=operation, prompt=None)
    assert req.is_prompt_required() is False


def test_is_prompt_required_mon_analysis():
    req = ClaudeCliRequest(
        projectPath="/p", operation="analysis", analysisId="MON-123", prompt=None
    )
    assert req.is_prompt_required() is False


def test_is_prompt_required_analysis_non_mon_no_prompt():
    req = ClaudeCliRequest(
        projectPath="/p", operation="analysis", analysisId="ABC-123", prompt=None
    )
    assert req.is_prompt_required() is True


def test_is_prompt_required_blank_prompt():
    req = ClaudeCliRequest(projectPath="/p", operation="analysis", prompt="   ")
    assert req.is_prompt_required() is True


def test_is_prompt_required_with_prompt():
    req = ClaudeCliRequest(projectPath="/p", operation="analysis", prompt="do something")
    assert req.is_prompt_required() is False


def test_is_prompt_required_analysis_no_analysis_id():
    req = ClaudeCliRequest(projectPath="/p", operation="analysis", prompt="x")
    assert req.is_prompt_required() is False


def test_claude_cli_alias_dump():
    req = ClaudeCliRequest(projectPath="/p", analysisId="A", operationSuffix="s",
                           claudeWorkspace="/ws", projectType="java")
    dumped = req.model_dump(by_alias=True)
    assert dumped["projectPath"] == "/p"
    assert dumped["analysisId"] == "A"
    assert dumped["operationSuffix"] == "s"
    assert dumped["claudeWorkspace"] == "/ws"
    assert dumped["projectType"] == "java"


# ---------------------------------------------------------------------------
# SchemaModernizationRequest
# ---------------------------------------------------------------------------
def test_schema_modernization_minimal():
    req = SchemaModernizationRequest(
        analysisId="S-1", sourceDbType="Oracle", targetDbType="PostgreSQL"
    )
    assert req.analysis_id == "S-1"
    assert req.source_db_type == "Oracle"
    assert req.target_db_type == "PostgreSQL"
    assert req.platform == "linux"
    assert req.source_schema_path is None


def test_schema_modernization_invalid_platform():
    with pytest.raises(ValidationError) as exc:
        SchemaModernizationRequest(
            analysisId="S-1", sourceDbType="Oracle", targetDbType="PostgreSQL",
            platform="bad"
        )
    assert "Invalid platform" in str(exc.value)


def test_schema_modernization_valid_platform_windows():
    req = SchemaModernizationRequest(
        analysisId="S-1", sourceDbType="Oracle", targetDbType="PostgreSQL",
        platform="windows"
    )
    assert req.platform == "windows"


def test_schema_modernization_missing_required():
    with pytest.raises(ValidationError):
        SchemaModernizationRequest(sourceDbType="Oracle", targetDbType="PostgreSQL")


# ---------------------------------------------------------------------------
# AssessmentRuleInputItem & AssessmentRulesBatchRequest
# ---------------------------------------------------------------------------
def test_assessment_rule_input_item():
    item = AssessmentRuleInputItem(
        ruleId="R-1", domain="security", language="dotnet",
        name="rule", description="desc",
        category="Security", issueType="BLOCKER", severity="HIGH",
    )
    assert item.rule_id == "R-1"
    assert item.domain == "security"
    assert item.language == "dotnet"
    assert item.name == "rule"
    assert item.description == "desc"
    assert item.category == "Security"
    assert item.issue_type == "BLOCKER"
    assert item.severity == "HIGH"
    assert item.example is None


def test_assessment_rule_input_item_with_example_field_name():
    item = AssessmentRuleInputItem(
        rule_id="R-2", domain="d", language="Java", name="n",
        description="de", example="sample",
        category="Code Quality", issue_type="NEUTRAL", severity="LOW",
    )
    assert item.rule_id == "R-2"
    assert item.example == "sample"


def test_assessment_rule_input_item_missing_required():
    with pytest.raises(ValidationError):
        AssessmentRuleInputItem(ruleId="R", domain="d", language="l", name="n")


def test_assessment_batch_request():
    item = AssessmentRuleInputItem(
        ruleId="R-1", domain="d", language="l", name="n", description="de",
        category="Code Quality", issueType="NEUTRAL", severity="MEDIUM",
    )
    req = AssessmentRulesBatchRequest(analysisId="B-1", rules=[item])
    assert req.analysis_id == "B-1"
    assert len(req.rules) == 1
    assert req.platform == "linux"
    assert req.project_path is None


def test_assessment_batch_request_empty_rules():
    with pytest.raises(ValidationError):
        AssessmentRulesBatchRequest(analysisId="B-1", rules=[])


def test_assessment_batch_invalid_platform():
    item = AssessmentRuleInputItem(
        ruleId="R-1", domain="d", language="l", name="n", description="de",
        category="Code Quality", issueType="NEUTRAL", severity="MEDIUM",
    )
    with pytest.raises(ValidationError) as exc:
        AssessmentRulesBatchRequest(analysisId="B", rules=[item], platform="bad")
    assert "Invalid platform" in str(exc.value)


def test_assessment_batch_valid_platform_windows():
    item = AssessmentRuleInputItem(
        ruleId="R-1", domain="d", language="l", name="n", description="de",
        category="Code Quality", issueType="NEUTRAL", severity="MEDIUM",
    )
    req = AssessmentRulesBatchRequest(
        analysisId="B", rules=[item], platform="windows", projectPath="/proj"
    )
    assert req.platform == "windows"
    assert req.project_path == "/proj"


# ---------------------------------------------------------------------------
# BuildCompilationRequest
# ---------------------------------------------------------------------------
def test_build_compilation_request_default_operation():
    req = BuildCompilationRequest(projectPath="/p")
    assert req.operation == "build-compilation"
    assert req.project_path == "/p"
    # inherits is_prompt_required
    assert req.is_prompt_required() is False


def test_build_compilation_request_override():
    req = BuildCompilationRequest(projectPath="/p", javaVersion="17", analysisId="b-1")
    assert req.java_version == "17"
    assert req.analysis_id == "b-1"
