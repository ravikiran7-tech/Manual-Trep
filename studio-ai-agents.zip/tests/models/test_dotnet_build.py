"""Tests for app.models.dotnet_build."""
import pytest
from pydantic import ValidationError

from app.models.dotnet_build import BuildRequest, BuildResult


def test_build_request_minimal_by_alias():
    req = BuildRequest(projectLocation="/p", analysisId="A-1")
    assert req.project_location == "/p"
    assert req.analysis_id == "A-1"
    assert req.platform is None
    assert req.claude_workspace is None
    assert req.application_name is None
    assert req.build_file is None
    assert req.technology is None
    assert req.build_type is None
    assert req.version is None
    assert req.skip_tests is False


def test_build_request_by_field_name():
    req = BuildRequest(
        project_location="/p",
        analysis_id="A-2",
        claude_workspace="/ws",
        application_name="App",
        build_file="sln.sln",
        build_type="maven",
        skip_tests=True,
    )
    assert req.claude_workspace == "/ws"
    assert req.application_name == "App"
    assert req.build_file == "sln.sln"
    assert req.build_type == "maven"
    assert req.skip_tests is True


def test_build_request_full_alias_dump():
    req = BuildRequest(
        projectLocation="/p",
        analysisId="A-3",
        platform="linux",
        claudeWorkspace="/ws",
        applicationName="App",
        buildFile="pom.xml",
        technology="java",
        buildType="maven",
        version="17",
        skipTests=False,
    )
    dumped = req.model_dump(by_alias=True)
    assert dumped["projectLocation"] == "/p"
    assert dumped["analysisId"] == "A-3"
    assert dumped["claudeWorkspace"] == "/ws"
    assert dumped["applicationName"] == "App"
    assert dumped["buildFile"] == "pom.xml"
    assert dumped["buildType"] == "maven"
    assert dumped["skipTests"] is False


def test_build_request_missing_required():
    with pytest.raises(ValidationError):
        BuildRequest(projectLocation="/p")
    with pytest.raises(ValidationError):
        BuildRequest(analysisId="A")


def test_build_result_minimal():
    res = BuildResult(exitCode=0, success=True, buildStatus="SUCCESS")
    assert res.exit_code == 0
    assert res.success is True
    assert res.build_status == "SUCCESS"
    assert res.compilation_errors == []
    assert res.test_failures == []
    assert res.errors == 0
    assert res.warnings == 0
    assert res.total_time == "N/A"


def test_build_result_full():
    res = BuildResult(
        exit_code=1,
        success=False,
        build_status="FAILURE",
        compilation_errors=["err1"],
        test_failures=["t1", "t2"],
        errors=3,
        warnings=2,
        total_time="0:01:23",
    )
    assert res.compilation_errors == ["err1"]
    assert res.test_failures == ["t1", "t2"]
    assert res.errors == 3
    assert res.warnings == 2
    assert res.total_time == "0:01:23"


def test_build_result_alias_dump():
    res = BuildResult(exitCode=0, success=True, buildStatus="SUCCESS")
    dumped = res.model_dump(by_alias=True)
    assert dumped["exitCode"] == 0
    assert dumped["buildStatus"] == "SUCCESS"
    assert dumped["compilationErrors"] == []
    assert dumped["testFailures"] == []
    assert dumped["totalTime"] == "N/A"


def test_build_result_missing_required():
    with pytest.raises(ValidationError):
        BuildResult(success=True, buildStatus="SUCCESS")
