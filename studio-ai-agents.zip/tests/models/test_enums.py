"""Tests for app.models.enums."""
import pytest

from app.models.enums import (
    OperationType,
    Platform,
    ProviderType,
    DatabaseType,
    JavaVersion,
    DotnetVersion,
)


@pytest.mark.parametrize("member,value", [
    (OperationType.ANALYSIS, "analysis"),
    (OperationType.FIX_UPGRADE, "fix-upgrade"),
    (OperationType.BUILD_COMPILATION, "build-compilation"),
    (OperationType.TEST_EXECUTION, "test-execution"),
    (OperationType.TEST_CREATION, "test-creation"),
    (OperationType.CLOUDREADINESS_ANALYSIS, "cloudreadiness-analysis"),
    (OperationType.CLOUDREADINESS_FIX, "cloudreadiness-fix"),
    (OperationType.DB_CODE_MODERNIZE_ANALYSIS, "db-code-modernize-analysis"),
    (OperationType.DB_CODE_MODERNIZE_FIX, "db-code-modernize-fix"),
    (OperationType.SCHEMA_MODERNIZATION, "schema-modernization"),
    (OperationType.DOTNET_BUILD_COMPILATION, "dotnet-build-compilation"),
    (OperationType.DOTNET_TEST_EXECUTION, "dotnet-test-execution"),
    (OperationType.TEST_EXECUTION_BUILD, "test-executionBuild"),
    (OperationType.CONTAINERIZATION_ANALYSIS, "containerization-analysis"),
    (OperationType.SELECTIVE_FIX, "selective-fix"),
    (OperationType.GENERATION, "generation"),
    (OperationType.SUMMARY, "summary"),
])
def test_operation_type_values(member, value):
    assert member.value == value
    assert OperationType(value) is member
    # str enum behaviour
    assert member == value


def test_operation_type_invalid():
    with pytest.raises(ValueError):
        OperationType("not-an-operation")


@pytest.mark.parametrize("member,value", [
    (Platform.LINUX, "linux"),
    (Platform.WINDOWS, "windows"),
])
def test_platform_values(member, value):
    assert member.value == value
    assert Platform(value) is member


def test_platform_invalid():
    with pytest.raises(ValueError):
        Platform("solaris")


@pytest.mark.parametrize("member,value", [
    (ProviderType.BEDROCK, "aws-bedrock"),
    (ProviderType.PORTKEY, "portkey"),
])
def test_provider_type_values(member, value):
    assert member.value == value
    assert ProviderType(value) is member


@pytest.mark.parametrize("member,value", [
    (DatabaseType.ORACLE, "Oracle"),
    (DatabaseType.POSTGRESQL, "PostgreSQL"),
    (DatabaseType.MYSQL, "MySQL"),
    (DatabaseType.MSSQL, "MSSQL"),
    (DatabaseType.DB2, "DB2"),
])
def test_database_type_values(member, value):
    assert member.value == value
    assert DatabaseType(value) is member


@pytest.mark.parametrize("member,value", [
    (JavaVersion.JAVA_8, "8"),
    (JavaVersion.JAVA_17, "17"),
    (JavaVersion.JAVA_21, "21"),
])
def test_java_version_values(member, value):
    assert member.value == value
    assert JavaVersion(value) is member


@pytest.mark.parametrize("member,value", [
    (DotnetVersion.DOTNET_6, "6.0"),
    (DotnetVersion.DOTNET_7, "7.0"),
    (DotnetVersion.DOTNET_8, "8.0"),
    (DotnetVersion.DOTNET_10, "10.0"),
])
def test_dotnet_version_values(member, value):
    assert member.value == value
    assert DotnetVersion(value) is member


def test_all_enums_are_str():
    assert isinstance(OperationType.ANALYSIS, str)
    assert isinstance(Platform.LINUX, str)
    assert isinstance(ProviderType.BEDROCK, str)
    assert isinstance(DatabaseType.ORACLE, str)
    assert isinstance(JavaVersion.JAVA_8, str)
    assert isinstance(DotnetVersion.DOTNET_6, str)


def test_enum_membership_counts():
    assert len(list(OperationType)) == 17
    assert len(list(Platform)) == 2
    assert len(list(ProviderType)) == 2
    assert len(list(DatabaseType)) == 5
    assert len(list(JavaVersion)) == 3
    assert len(list(DotnetVersion)) == 4
