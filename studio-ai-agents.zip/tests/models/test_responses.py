"""Tests for app.models.responses."""
import pytest
from pydantic import ValidationError

from app.models.responses import (
    ClaudeCliResponse,
    SchemaModernizationResponse,
    AssessmentRuleBatchItem,
    AssessmentRulesBatchResponse,
    DotnetBuildCompilationResponse,
    BuildCompilationResponse,
    StreamVisualizationResponse,
)


# ---------------------------------------------------------------------------
# ClaudeCliResponse
# ---------------------------------------------------------------------------
def test_claude_cli_response_basic():
    r = ClaudeCliResponse(status="success", message="ok")
    assert r.status == "success"
    assert r.exit_code == 0
    assert r.output is None
    assert r.error is None
    assert r.summary is None


def test_claude_cli_response_missing_required():
    with pytest.raises(ValidationError):
        ClaudeCliResponse(message="no status")


def test_claude_cli_create_success_defaults():
    r = ClaudeCliResponse.create_success()
    assert r.status == "success"
    assert r.message == "Command executed successfully"
    assert r.exit_code == 0
    assert r.output == ""
    assert r.error == ""
    assert r.output_file_path == ""


def test_claude_cli_create_success_with_values():
    r = ClaudeCliResponse.create_success(
        message="done", exit_code=2, output="out", output_file_path="/f"
    )
    assert r.message == "done"
    assert r.exit_code == 2
    assert r.output == "out"
    assert r.output_file_path == "/f"


def test_claude_cli_create_error_defaults():
    r = ClaudeCliResponse.create_error("boom")
    assert r.status == "error"
    assert r.message == "boom"
    assert r.exit_code == -1
    assert r.output == ""
    assert r.error == "boom"  # falls back to message
    assert r.output_file_path == ""


def test_claude_cli_create_error_with_error():
    r = ClaudeCliResponse.create_error("boom", exit_code=5, error="detail")
    assert r.exit_code == 5
    assert r.error == "detail"


def test_claude_cli_response_alias_dump():
    r = ClaudeCliResponse(status="success", message="m", exitCode=0,
                          outputFilePath="/f")
    dumped = r.model_dump(by_alias=True)
    assert dumped["exitCode"] == 0
    assert dumped["outputFilePath"] == "/f"


# ---------------------------------------------------------------------------
# SchemaModernizationResponse
# ---------------------------------------------------------------------------
def test_schema_response_basic():
    r = SchemaModernizationResponse(status="success", message="m")
    assert r.output_file_path is None
    assert r.content is None
    assert r.error_details is None


def test_schema_response_create_error_defaults():
    r = SchemaModernizationResponse.create_error("failed")
    assert r.status == "error"
    assert r.message == "failed"
    assert r.error_details == "failed"
    assert r.analysis_id is None


def test_schema_response_create_error_with_id():
    r = SchemaModernizationResponse.create_error("failed", analysis_id="S-1")
    assert r.analysis_id == "S-1"


def test_schema_response_alias():
    r = SchemaModernizationResponse(
        status="success", message="m", outputFilePath="/f", errorDetails="e",
        analysisId="S", sourceDbType="Oracle", targetDbType="PostgreSQL"
    )
    assert r.output_file_path == "/f"
    assert r.source_db_type == "Oracle"
    dumped = r.model_dump(by_alias=True)
    assert dumped["outputFilePath"] == "/f"
    assert dumped["sourceDbType"] == "Oracle"


# ---------------------------------------------------------------------------
# AssessmentRuleBatchItem & AssessmentRulesBatchResponse
# ---------------------------------------------------------------------------
def test_assessment_batch_item_defaults():
    item = AssessmentRuleBatchItem()
    assert item.rule_id is None
    assert item.assessment_schema == {}
    assert item.detection_schema == {}


def test_assessment_batch_item_by_alias():
    item = AssessmentRuleBatchItem(
        ruleId="R-1",
        assessmentSchema={"a": 1},
        detectionSchema={"d": 2},
    )
    assert item.rule_id == "R-1"
    assert item.assessment_schema == {"a": 1}
    assert item.detection_schema == {"d": 2}
    dumped = item.model_dump(by_alias=True)
    assert dumped["ruleId"] == "R-1"
    assert dumped["assessmentSchema"] == {"a": 1}


def test_assessment_batch_response_basic():
    r = AssessmentRulesBatchResponse(status="success", message="m")
    assert r.analysis_id is None
    assert r.rules is None
    assert r.rule_count_expected is None


def test_assessment_batch_response_full():
    item = AssessmentRuleBatchItem(ruleId="R-1")
    r = AssessmentRulesBatchResponse(
        status="success", message="m", analysisId="B-1",
        ruleCountExpected=1, ruleCountReturned=1, rules=[item],
        rawResponse="raw", outputFilePath="/f", errorDetails="none"
    )
    assert r.analysis_id == "B-1"
    assert r.rule_count_expected == 1
    assert r.rule_count_returned == 1
    assert len(r.rules) == 1
    assert r.raw_response == "raw"
    assert r.output_file_path == "/f"
    assert r.error_details == "none"
    dumped = r.model_dump(by_alias=True)
    assert dumped["analysisId"] == "B-1"
    assert dumped["ruleCountExpected"] == 1


def test_assessment_batch_response_missing_required():
    with pytest.raises(ValidationError):
        AssessmentRulesBatchResponse(status="success")


# ---------------------------------------------------------------------------
# DotnetBuildCompilationResponse
# ---------------------------------------------------------------------------
def test_dotnet_build_response_with_summary_dict():
    r = DotnetBuildCompilationResponse(
        status="success", message="m",
        summary={"buildStatus": "SUCCESS"},
    )
    assert r.summary.build_status == "SUCCESS"
    assert r.output_file_path is None


def test_dotnet_build_response_summary_obj_and_alias():
    summary = DotnetBuildCompilationResponse.BuildCompilationSummary(buildStatus="FAILED")
    r = DotnetBuildCompilationResponse(
        status="error", message="m", outputFilePath="/f", summary=summary
    )
    assert r.summary.build_status == "FAILED"
    dumped = r.model_dump(by_alias=True)
    assert dumped["outputFilePath"] == "/f"
    assert dumped["summary"]["buildStatus"] == "FAILED"


def test_dotnet_build_summary_by_field_name():
    summary = DotnetBuildCompilationResponse.BuildCompilationSummary(build_status="PARTIAL")
    assert summary.build_status == "PARTIAL"


def test_dotnet_build_response_missing_summary():
    with pytest.raises(ValidationError):
        DotnetBuildCompilationResponse(status="success", message="m")


# ---------------------------------------------------------------------------
# BuildCompilationResponse
# ---------------------------------------------------------------------------
def test_build_compilation_response_defaults():
    r = BuildCompilationResponse(assessmentId="b-1", status="success", message="m")
    assert r.assessment_id == "b-1"
    assert r.cached is False
    assert r.output_file_path is None
    assert r.build_output is None


def test_build_compilation_response_full_alias():
    r = BuildCompilationResponse(
        assessmentId="b-1", status="success", message="m", cached=True,
        outputFilePath="/f", buildOutput="BUILD SUCCESS"
    )
    assert r.cached is True
    assert r.output_file_path == "/f"
    assert r.build_output == "BUILD SUCCESS"
    dumped = r.model_dump(by_alias=True)
    assert dumped["assessmentId"] == "b-1"
    assert dumped["buildOutput"] == "BUILD SUCCESS"


def test_build_compilation_response_missing_required():
    with pytest.raises(ValidationError):
        BuildCompilationResponse(status="success", message="m")


# ---------------------------------------------------------------------------
# StreamVisualizationResponse
# ---------------------------------------------------------------------------
def test_stream_viz_defaults():
    r = StreamVisualizationResponse(analysisId="A-1", operation="analysis")
    assert r.analysis_id == "A-1"
    assert r.operation == "analysis"
    assert r.stream_data is None
    assert r.status == "success"
    assert r.message == "Stream data retrieved successfully"


def test_stream_viz_full_alias():
    r = StreamVisualizationResponse(
        analysisId="A-1", operation="analysis", streamData="{}",
        status="error", message="oops"
    )
    assert r.stream_data == "{}"
    assert r.status == "error"
    dumped = r.model_dump(by_alias=True)
    assert dumped["analysisId"] == "A-1"
    assert dumped["streamData"] == "{}"


def test_stream_viz_missing_required():
    with pytest.raises(ValidationError):
        StreamVisualizationResponse(operation="analysis")
