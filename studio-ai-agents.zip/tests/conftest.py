"""
Global pytest configuration and reusable fixtures.

IMPORTANT: Environment variables MUST be set *before* any ``app.*`` module is
imported, because several modules call ``get_settings()`` at import time
(e.g. ``app.services.tool_executor``, ``app.utils.encryption``). pytest imports
this conftest before collecting/​importing any test module, so setting
``os.environ`` here at module top-level guarantees a valid configuration is in
place for the whole test session.

No real external services (Claude, Bedrock, Portkey, Azure, Compass, NATS) are
ever contacted: NATS is disabled, DEBUG is on, and individual tests mock the
network/SDK boundaries.
"""
import os
import sys
import tempfile

# ---------------------------------------------------------------------------
# 1. Environment configuration (must run at import time, before `app` imports)
# ---------------------------------------------------------------------------
# A 16-byte (128-bit) AES key, Base64-encoded. Matches the documented sample in
# .env.example and decodes to exactly 16 bytes.
_TEST_ENCRYPTION_KEY = "P3qcGy5Nj2oMXh17iisPDg=="

_TEST_WORKSPACE = os.path.join(tempfile.gettempdir(), "studio-ai-agents-test-workspace")

_TEST_ENV = {
    # Required (no defaults in Settings)
    "STUDIO_CORE_URL": "https://studio-core.test.local/studio-core",
    "ENCRYPTION_KEY": _TEST_ENCRYPTION_KEY,
    # Decryption passphrase used by NATS / GCM helpers
    "ENC_PASSPHRASE": "test-passphrase",
    # Keep the app self-contained and offline
    "NATS_ENABLED": "false",
    "DEBUG": "true",
    "COMPASS_COMPONENT": "Studio",
    "CLAUDE_WORKSPACE": _TEST_WORKSPACE,
    "WORKSPACE_BASE_PATH": _TEST_WORKSPACE,
    # Disable the proactive LLM rate limiter so tests never sleep on real timers
    "LLM_RATE_LIMITER_ENABLED": "false",
    # Deterministic AWS / model config
    "AWS_REGION": "us-east-1",
    "AWS_PROFILE": "default",
    "BEDROCK_MODEL_ID_SONNET": "anthropic.claude-3-sonnet-20240229-v1:0",
    "BEDROCK_DEFAULT_MODEL": "anthropic.claude-3-sonnet-20240229-v1:0",
    # A throwaway API key value for any code that reads it
    "CLAUDE_API_KEY": "test-claude-api-key",
    "PORTKEY_API_KEY": "test-portkey-api-key",
}

for _k, _v in _TEST_ENV.items():
    os.environ[_k] = _v

os.makedirs(_TEST_WORKSPACE, exist_ok=True)

import pytest  # noqa: E402


# ---------------------------------------------------------------------------
# 2. Settings fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session", autouse=True)
def _ensure_test_env():
    """Guarantee the test environment stays applied for the whole session."""
    for k, v in _TEST_ENV.items():
        os.environ[k] = v
    yield


@pytest.fixture
def settings():
    """A fresh, fully-populated Settings instance built from the test env."""
    from app.core.config import Settings

    return Settings()


@pytest.fixture
def reset_settings_singleton():
    """Reset the global settings singleton before and after a test.

    Use when a test mutates env vars and needs ``get_settings()`` to rebuild.
    """
    import app.core.config as config_mod

    original = config_mod.settings
    config_mod.settings = None
    yield
    config_mod.settings = original


# ---------------------------------------------------------------------------
# 3. Encryption helpers
# ---------------------------------------------------------------------------
@pytest.fixture
def encryption_key():
    """The Base64 test AES key (16 bytes)."""
    return _TEST_ENCRYPTION_KEY


@pytest.fixture
def encryption_utils():
    """An EncryptionUtils instance using the test key."""
    from app.utils.encryption import EncryptionUtils

    return EncryptionUtils(_TEST_ENCRYPTION_KEY)


# ---------------------------------------------------------------------------
# 4. Compass connection fixtures (shared shape used across LLM/provider tests)
# ---------------------------------------------------------------------------
@pytest.fixture
def make_connection():
    """Factory returning a ConnectionData with the given provider type/config."""
    from app.clients.compass_client import ConnectionConfiguration, ConnectionData

    def _make(provider_type: str = "aws-bedrock", connection_id: str = "CON-TEST",
              status: str = "enabled", **cfg_fields):
        cfg = ConnectionConfiguration(**cfg_fields)
        return ConnectionData(
            connection_id=connection_id,
            component="Studio",
            provider_type=provider_type,
            configuration=cfg,
            status=status,
        )

    return _make


# ---------------------------------------------------------------------------
# 5. FastAPI test client (lifespan NOT triggered -> no NATS/AWS startup)
# ---------------------------------------------------------------------------
@pytest.fixture
def app_client():
    """A FastAPI TestClient.

    NOTE: constructed WITHOUT the ``with`` context-manager form so Starlette
    does not run the lifespan (which would try NATS/AWS/workspace startup).
    """
    from fastapi.testclient import TestClient

    from app.main import app

    client = TestClient(app, raise_server_exceptions=False)
    return client


# ---------------------------------------------------------------------------
# 6. Generic async mock helper
# ---------------------------------------------------------------------------
@pytest.fixture
def anyio_backend():
    """Force asyncio backend if anyio-based code is exercised."""
    return "asyncio"
