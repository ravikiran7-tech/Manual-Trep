"""Tests for app.graph.builders dependency graph construction."""
import pytest

from app.graph.builders import (
    DependencyGraphBuilder,
    MavenGraphBuilder,
    DotnetGraphBuilder,
    JavaScriptGraphBuilder,
)
from app.state.models import ModuleNode


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


POM_PARENT = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.example</groupId>
  <artifactId>parent</artifactId>
  <version>1.0.0</version>
  <packaging>pom</packaging>
  <modules>
    <module>service-a</module>
    <module>service-b</module>
  </modules>
</project>
"""

POM_CHILD = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <artifactId>{name}</artifactId>
  <version>1.0.0</version>
</project>
"""

POM_NO_MODULES = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <artifactId>solo</artifactId>
  <version>1.0.0</version>
</project>
"""


CSPROJ_WEB = """<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\\Lib\\Lib.csproj" />
  </ItemGroup>
</Project>
"""

CSPROJ_LIB = """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup>
</Project>
"""


# ---------------------------------------------------------------------------
# detect_project_type
# ---------------------------------------------------------------------------
def test_detect_maven(tmp_path):
    _write(tmp_path / "pom.xml", POM_NO_MODULES)
    assert DependencyGraphBuilder.detect_project_type(tmp_path) == "maven"


def test_detect_dotnet(tmp_path):
    _write(tmp_path / "App" / "App.csproj", CSPROJ_LIB)
    assert DependencyGraphBuilder.detect_project_type(tmp_path) == "dotnet"


def test_detect_javascript(tmp_path):
    _write(tmp_path / "package.json", '{"name": "m-basic-app", "version": "1.0.0"}')
    assert DependencyGraphBuilder.detect_project_type(tmp_path) == "javascript"


def test_detect_maven_takes_priority_over_dotnet(tmp_path):
    _write(tmp_path / "pom.xml", POM_NO_MODULES)
    _write(tmp_path / "App" / "App.csproj", CSPROJ_LIB)
    assert DependencyGraphBuilder.detect_project_type(tmp_path) == "maven"


def test_detect_unknown_raises(tmp_path):
    with pytest.raises(ValueError, match="Unknown project type"):
        DependencyGraphBuilder.detect_project_type(tmp_path)


# ---------------------------------------------------------------------------
# DependencyGraphBuilder.build_graph dispatch
# ---------------------------------------------------------------------------
def test_build_graph_dispatch_maven(tmp_path):
    _write(tmp_path / "pom.xml", POM_NO_MODULES)
    graph = DependencyGraphBuilder.build_graph(tmp_path)
    assert isinstance(graph, dict)
    assert all(isinstance(n, ModuleNode) for n in graph.values())


def test_build_graph_dispatch_dotnet(tmp_path):
    _write(tmp_path / "App" / "App.csproj", CSPROJ_LIB)
    graph = DependencyGraphBuilder.build_graph(tmp_path)
    assert "App" in graph


def test_build_graph_dispatch_javascript(tmp_path):
    _write(tmp_path / "package.json", '{"name": "m-basic-app", "version": "1.0.0"}')
    graph = DependencyGraphBuilder.build_graph(tmp_path)
    assert len(graph) == 1
    assert tmp_path.name in graph
    assert graph[tmp_path.name].dependencies == []


def test_build_graph_unknown_raises(tmp_path):
    with pytest.raises(ValueError):
        DependencyGraphBuilder.build_graph(tmp_path)


def test_build_graph_unsupported_type(tmp_path, monkeypatch):
    """Force detect_project_type to return an unsupported type to hit the else branch."""
    _write(tmp_path / "pom.xml", POM_NO_MODULES)
    monkeypatch.setattr(
        DependencyGraphBuilder, "detect_project_type", staticmethod(lambda p: "ruby")
    )
    with pytest.raises(ValueError, match="Unsupported project type"):
        DependencyGraphBuilder.build_graph(tmp_path)


# ---------------------------------------------------------------------------
# MavenGraphBuilder.parse_pom_dependencies
# ---------------------------------------------------------------------------
def test_parse_pom_with_modules(tmp_path):
    pom = tmp_path / "pom.xml"
    _write(pom, POM_PARENT)
    deps = MavenGraphBuilder.parse_pom_dependencies(pom)
    assert deps == ["service-a", "service-b"]


def test_parse_pom_no_modules(tmp_path):
    pom = tmp_path / "pom.xml"
    _write(pom, POM_NO_MODULES)
    assert MavenGraphBuilder.parse_pom_dependencies(pom) == []


def test_parse_pom_malformed_returns_empty(tmp_path):
    pom = tmp_path / "pom.xml"
    _write(pom, "<project><modules><module>broken")
    assert MavenGraphBuilder.parse_pom_dependencies(pom) == []


def test_parse_pom_missing_file_returns_empty(tmp_path):
    """Non-existent file triggers the generic Exception handler."""
    assert MavenGraphBuilder.parse_pom_dependencies(tmp_path / "nope.xml") == []


def test_parse_pom_empty_module_text(tmp_path):
    """A <module/> with no text should be skipped (covers `if module_elem.text`)."""
    pom_empty = """<?xml version="1.0"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modules>
    <module></module>
    <module>real</module>
  </modules>
</project>
"""
    pom = tmp_path / "pom.xml"
    _write(pom, pom_empty)
    assert MavenGraphBuilder.parse_pom_dependencies(pom) == ["real"]


# ---------------------------------------------------------------------------
# MavenGraphBuilder.build_graph
# ---------------------------------------------------------------------------
def test_maven_build_graph_multi_module(tmp_path):
    _write(tmp_path / "pom.xml", POM_PARENT)
    _write(tmp_path / "service-a" / "pom.xml", POM_CHILD.format(name="service-a"))
    _write(tmp_path / "service-b" / "pom.xml", POM_CHILD.format(name="service-b"))

    graph = MavenGraphBuilder.build_graph(tmp_path)
    # 3 pom files -> parent dir name + 2 children
    assert "service-a" in graph
    assert "service-b" in graph
    parent_name = tmp_path.name
    assert parent_name in graph
    assert graph[parent_name].dependencies == ["service-a", "service-b"]
    assert graph["service-a"].dependencies == []


def test_maven_build_graph_no_pom_raises(tmp_path):
    with pytest.raises(ValueError, match="No pom.xml"):
        MavenGraphBuilder.build_graph(tmp_path)


def test_maven_build_graph_duplicate_module_names_skipped(tmp_path):
    """Two pom.xml in dirs with the same name -> only the first is kept."""
    _write(tmp_path / "x" / "mod" / "pom.xml", POM_NO_MODULES)
    _write(tmp_path / "y" / "mod" / "pom.xml", POM_NO_MODULES)
    graph = MavenGraphBuilder.build_graph(tmp_path)
    assert "mod" in graph
    # only a single 'mod' entry despite two pom files
    assert sum(1 for k in graph if k == "mod") == 1


# ---------------------------------------------------------------------------
# DotnetGraphBuilder.is_web_sdk_project
# ---------------------------------------------------------------------------
def test_is_web_sdk_true(tmp_path):
    p = tmp_path / "Web.csproj"
    _write(p, CSPROJ_WEB)
    assert DotnetGraphBuilder.is_web_sdk_project(p) is True


def test_is_web_sdk_false(tmp_path):
    p = tmp_path / "Lib.csproj"
    _write(p, CSPROJ_LIB)
    assert DotnetGraphBuilder.is_web_sdk_project(p) is False


def test_is_web_sdk_error_returns_false(tmp_path):
    assert DotnetGraphBuilder.is_web_sdk_project(tmp_path / "missing.csproj") is False


# ---------------------------------------------------------------------------
# DotnetGraphBuilder.parse_csproj_dependencies
# ---------------------------------------------------------------------------
def test_parse_csproj_deps(tmp_path):
    p = tmp_path / "Web.csproj"
    _write(p, CSPROJ_WEB)
    assert DotnetGraphBuilder.parse_csproj_dependencies(p) == ["Lib"]


def test_parse_csproj_no_deps(tmp_path):
    p = tmp_path / "Lib.csproj"
    _write(p, CSPROJ_LIB)
    assert DotnetGraphBuilder.parse_csproj_dependencies(p) == []


def test_parse_csproj_reference_without_include(tmp_path):
    """ProjectReference with empty Include attribute is ignored."""
    content = """<Project Sdk="Microsoft.NET.Sdk">
  <ItemGroup>
    <ProjectReference Include="" />
  </ItemGroup>
</Project>
"""
    p = tmp_path / "Lib.csproj"
    _write(p, content)
    assert DotnetGraphBuilder.parse_csproj_dependencies(p) == []


def test_parse_csproj_malformed_returns_empty(tmp_path):
    p = tmp_path / "Bad.csproj"
    _write(p, "<Project><ItemGroup")
    assert DotnetGraphBuilder.parse_csproj_dependencies(p) == []


def test_parse_csproj_missing_file_returns_empty(tmp_path):
    assert DotnetGraphBuilder.parse_csproj_dependencies(tmp_path / "nope.csproj") == []


# ---------------------------------------------------------------------------
# DotnetGraphBuilder.build_graph
# ---------------------------------------------------------------------------
def test_dotnet_build_graph_single(tmp_path):
    _write(tmp_path / "App" / "App.csproj", CSPROJ_LIB)
    graph = DotnetGraphBuilder.build_graph(tmp_path)
    assert list(graph.keys()) == ["App"]


def test_dotnet_build_graph_web_sdk_filtering(tmp_path):
    """When multiple projects and a Web SDK exists, only web projects are used."""
    _write(tmp_path / "Web" / "Web.csproj", CSPROJ_WEB)
    _write(tmp_path / "Lib" / "Lib.csproj", CSPROJ_LIB)
    _write(tmp_path / "Tests" / "Tests.csproj", CSPROJ_LIB)
    graph = DotnetGraphBuilder.build_graph(tmp_path)
    assert "Web" in graph
    assert "Lib" not in graph
    assert "Tests" not in graph
    assert graph["Web"].dependencies == ["Lib"]


def test_dotnet_build_graph_no_web_sdk_uses_all(tmp_path):
    """Multiple non-web projects -> all are kept."""
    _write(tmp_path / "Lib" / "Lib.csproj", CSPROJ_LIB)
    _write(tmp_path / "Core" / "Core.csproj", CSPROJ_LIB)
    graph = DotnetGraphBuilder.build_graph(tmp_path)
    assert set(graph.keys()) == {"Lib", "Core"}


def test_dotnet_build_graph_no_csproj_raises(tmp_path):
    with pytest.raises(ValueError, match="No .csproj"):
        DotnetGraphBuilder.build_graph(tmp_path)


def test_dotnet_build_graph_duplicate_names_skipped(tmp_path):
    """Two non-web projects with the same stem -> only first kept (covers skip branch)."""
    _write(tmp_path / "a" / "Same.csproj", CSPROJ_LIB)
    _write(tmp_path / "b" / "Same.csproj", CSPROJ_LIB)
    graph = DotnetGraphBuilder.build_graph(tmp_path)
    assert list(graph.keys()) == ["Same"]


# ---------------------------------------------------------------------------
# JavaScriptGraphBuilder.build_graph
# ---------------------------------------------------------------------------
def test_javascript_build_graph_single_module(tmp_path):
    _write(tmp_path / "package.json", '{"name": "m-basic-app", "version": "1.0.0"}')
    graph = JavaScriptGraphBuilder.build_graph(tmp_path)
    assert list(graph.keys()) == [tmp_path.name]
    assert graph[tmp_path.name].path == str(tmp_path)


def test_javascript_build_graph_no_package_json_raises(tmp_path):
    with pytest.raises(ValueError, match="No package.json"):
        JavaScriptGraphBuilder.build_graph(tmp_path)