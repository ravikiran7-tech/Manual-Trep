"""Tests for app.graph.resolver topological resolution and cycle detection."""
from app.graph.resolver import GraphResolver
from app.state.models import ModuleNode, ModuleStatus


def _node(name, deps=None, status=ModuleStatus.PENDING):
    return ModuleNode(name=name, path=f"/tmp/{name}", dependencies=deps or [], status=status)


def _graph(*nodes):
    return {n.name: n for n in nodes}


# ---------------------------------------------------------------------------
# get_ready_modules
# ---------------------------------------------------------------------------
def test_ready_no_deps():
    g = _graph(_node("a"), _node("b"))
    ready = GraphResolver.get_ready_modules(g)
    assert {m.name for m in ready} == {"a", "b"}


def test_ready_blocked_until_dep_locked():
    g = _graph(_node("a"), _node("b", deps=["a"]))
    ready = GraphResolver.get_ready_modules(g)
    assert {m.name for m in ready} == {"a"}  # b blocked

    g["a"].status = ModuleStatus.LOCKED
    ready = GraphResolver.get_ready_modules(g)
    assert {m.name for m in ready} == {"b"}


def test_ready_skips_non_pending():
    g = _graph(
        _node("a", status=ModuleStatus.LOCKED),
        _node("b", status=ModuleStatus.IN_PROGRESS),
        _node("c"),
    )
    ready = GraphResolver.get_ready_modules(g)
    assert {m.name for m in ready} == {"c"}


def test_ready_missing_dependency_is_ignored():
    """A dependency not in the graph (e.g. external/parent POM) does not block."""
    g = _graph(_node("a", deps=["external-parent"]))
    ready = GraphResolver.get_ready_modules(g)
    assert {m.name for m in ready} == {"a"}


def test_ready_dep_failed_blocks():
    g = _graph(_node("a", status=ModuleStatus.FAILED), _node("b", deps=["a"]))
    ready = GraphResolver.get_ready_modules(g)
    assert ready == []


def test_ready_none_found():
    g = _graph(_node("a", status=ModuleStatus.LOCKED))
    assert GraphResolver.get_ready_modules(g) == []


# ---------------------------------------------------------------------------
# validate_graph (cycle detection)
# ---------------------------------------------------------------------------
def test_validate_acyclic():
    g = _graph(_node("a"), _node("b", deps=["a"]), _node("c", deps=["b"]))
    assert GraphResolver.validate_graph(g) is True


def test_validate_detects_cycle():
    g = _graph(_node("a", deps=["b"]), _node("b", deps=["a"]))
    assert GraphResolver.validate_graph(g) is False


def test_validate_self_cycle():
    g = _graph(_node("a", deps=["a"]))
    assert GraphResolver.validate_graph(g) is False


def test_validate_ignores_external_deps():
    g = _graph(_node("a", deps=["not-in-graph"]))
    assert GraphResolver.validate_graph(g) is True


def test_validate_diamond_no_cycle():
    g = _graph(
        _node("a"),
        _node("b", deps=["a"]),
        _node("c", deps=["a"]),
        _node("d", deps=["b", "c"]),
    )
    assert GraphResolver.validate_graph(g) is True


def test_validate_already_visited_branch():
    """Shared dependency exercises the `node_name in visited` early-return path.

    'shared' is reached during the DFS rooted at 'x', so when the outer loop
    later reaches 'shared' it is already visited (covers the loop-skip arc).
    """
    g = _graph(
        _node("x", deps=["shared"]),
        _node("shared"),
        _node("y", deps=["shared"]),
    )
    assert GraphResolver.validate_graph(g) is True


# ---------------------------------------------------------------------------
# get_execution_order
# ---------------------------------------------------------------------------
def test_execution_order_layers():
    g = _graph(
        _node("a"),
        _node("b", deps=["a"]),
        _node("c", deps=["a"]),
        _node("d", deps=["b", "c"]),
    )
    layers = GraphResolver.get_execution_order(g)
    assert layers[0] == ["a"]
    assert set(layers[1]) == {"b", "c"}
    assert layers[2] == ["d"]


def test_execution_order_single_layer():
    g = _graph(_node("a"), _node("b"))
    layers = GraphResolver.get_execution_order(g)
    assert len(layers) == 1
    assert set(layers[0]) == {"a", "b"}


def test_execution_order_with_external_dep():
    g = _graph(_node("a", deps=["external"]))
    layers = GraphResolver.get_execution_order(g)
    assert layers == [["a"]]


def test_execution_order_breaks_on_cycle():
    """Circular dependency makes a layer empty -> loop breaks, leaving modules unresolved."""
    g = _graph(_node("a", deps=["b"]), _node("b", deps=["a"]))
    layers = GraphResolver.get_execution_order(g)
    # No layer can be produced -> empty result
    assert layers == []


def test_execution_order_empty_graph():
    assert GraphResolver.get_execution_order({}) == []
