"""Tests for app.orchestrator.graph_orchestrator.

The orchestrator drives modules through an AI provider (mocked) and validation.
We patch the collaborators where graph_orchestrator imports them.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import app.orchestrator.graph_orchestrator as go
from app.orchestrator.graph_orchestrator import GraphOrchestrator
from app.state.models import ModuleNode, ModuleStatus, GraphState


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _patch_tool_executor():
    """ToolExecutor is constructed in __init__ - stub it so no real init runs."""
    with patch.object(go, "ToolExecutor") as te:
        te.return_value = MagicMock()
        yield te


def _node(name, deps=None, base=None):
    path = f"/proj/{name}" if base is None else str(base / name)
    return ModuleNode(name=name, path=path, dependencies=deps or [])


def _real_node(tmp_path, name, deps=None, kind="maven"):
    """Create a real module directory so os.listdir/os.path.exists work."""
    d = tmp_path / name
    d.mkdir(parents=True, exist_ok=True)
    if kind == "maven":
        (d / "pom.xml").write_text("<project/>", encoding="utf-8")
    elif kind == "dotnet":
        (d / f"{name}.csproj").write_text("<Project/>", encoding="utf-8")
    return ModuleNode(name=name, path=str(d), dependencies=deps or [])


def _make_provider(events=None, agentic=None):
    """Build a provider_factory whose provider returns canned agentic events."""
    if events is None:
        events = [
            {"type": "tool_use", "tool": {"name": "code_editor",
             "input": {"operation": "write", "path": "/proj/a/F.java"}}}
        ]
    provider = MagicMock()
    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=agentic if agentic else None,
        return_value=events,
    )
    if agentic:
        provider.invoke_with_tools_agentic = AsyncMock(side_effect=agentic)
    factory = MagicMock()
    factory.get_provider = AsyncMock(return_value=provider)
    return factory, provider


def _orch(factory, **kw):
    return GraphOrchestrator(project_path="/proj", provider_factory=factory, **kw)


# Patch all the static collaborators used during orchestrate().
def _patch_pipeline(graph, project_type="maven", validate=True):
    """Returns a context-manager stack patching graph build/validate/artifacts."""
    patches = [
        patch.object(go.DependencyGraphBuilder, "build_graph",
                     staticmethod(lambda p: graph)),
        patch.object(go.DependencyGraphBuilder, "detect_project_type",
                     staticmethod(lambda p: project_type)),
        patch.object(go.GraphResolver, "validate_graph",
                     staticmethod(lambda g: validate)),
        patch.object(go.ArtifactManager, "hash_directory",
                     staticmethod(lambda *a, **k: "")),
        patch.object(go.ArtifactManager, "update_hash",
                     staticmethod(lambda m: None)),
        patch.object(go.ArtifactManager, "has_progress",
                     staticmethod(lambda m: True)),
    ]
    return patches


def _apply(patches):
    for p in patches:
        p.start()


def _stop(patches):
    for p in patches:
        p.stop()


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------
def test_init_sets_attributes(_patch_tool_executor):
    factory, _ = _make_provider()
    o = _orch(factory, max_retries=5, validation_timeout=99, skip_validation=True)
    assert o.max_retries == 5
    assert o.validation_timeout == 99
    assert o.skip_validation is True
    assert str(o.project_path) == "/proj" or str(o.project_path).endswith("proj")
    _patch_tool_executor.assert_called_once()


# ---------------------------------------------------------------------------
# orchestrate - happy paths
# ---------------------------------------------------------------------------
async def test_orchestrate_single_module_skip_validation(tmp_path):
    graph = {"a": _real_node(tmp_path, "a")}
    factory, provider = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)
    try:
        state = await o.orchestrate("do it")
    finally:
        _stop(patches)
    assert state.graph["a"].status == ModuleStatus.LOCKED
    assert state.is_complete()
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_orchestrate_single_module_with_validation_success(tmp_path):
    graph = {"a": _real_node(tmp_path, "a")}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=False)
    patches = _patch_pipeline(graph)
    _apply(patches)
    with patch.object(go.CompilerValidator, "validate",
                      staticmethod(lambda m, pt, timeout: (True, ""))):
        try:
            state = await o.orchestrate("do it")
        finally:
            _stop(patches)
    assert state.graph["a"].status == ModuleStatus.LOCKED


async def test_orchestrate_multi_module_dependency_ordering(tmp_path):
    """b depends on a -> a must lock first, then b becomes ready."""
    graph = {"a": _real_node(tmp_path, "a"),
             "b": _real_node(tmp_path, "b", deps=["a"])}
    factory, provider = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)
    try:
        state = await o.orchestrate("go")
    finally:
        _stop(patches)
    assert state.graph["a"].status == ModuleStatus.LOCKED
    assert state.graph["b"].status == ModuleStatus.LOCKED
    # at least 2 iterations because b only unlocked after a
    assert state.current_iteration >= 2


# ---------------------------------------------------------------------------
# orchestrate - validation failure / retries
# ---------------------------------------------------------------------------
async def test_orchestrate_validation_fail_then_success(tmp_path):
    graph = {"a": _real_node(tmp_path, "a")}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=False, max_retries=3)
    patches = _patch_pipeline(graph)
    _apply(patches)
    results = iter([(False, "compile error"), (True, "")])
    with patch.object(go.CompilerValidator, "validate",
                      staticmethod(lambda m, pt, timeout: next(results))):
        try:
            state = await o.orchestrate("go")
        finally:
            _stop(patches)
    assert state.graph["a"].status == ModuleStatus.LOCKED
    assert state.graph["a"].retries == 1


async def test_orchestrate_validation_exceeds_max_retries(tmp_path):
    graph = {"a": _real_node(tmp_path, "a")}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=False, max_retries=2)
    patches = _patch_pipeline(graph)
    _apply(patches)
    with patch.object(go.CompilerValidator, "validate",
                      staticmethod(lambda m, pt, timeout: (False, "x" * 800))):
        try:
            state = await o.orchestrate("go")
        finally:
            _stop(patches)
    assert state.graph["a"].status == ModuleStatus.FAILED
    assert state.failed_modules == 1
    assert state.graph["a"].retries == 2


async def test_orchestrate_transformation_returns_false_retries_then_fails(tmp_path):
    """Provider returns no events -> _apply_transformation False -> exception path."""
    graph = {"a": _real_node(tmp_path, "a")}
    factory, provider = _make_provider(events=[])  # no events => returns False
    o = _orch(factory, skip_validation=True, max_retries=2)
    patches = _patch_pipeline(graph)
    _apply(patches)
    try:
        state = await o.orchestrate("go")
    finally:
        _stop(patches)
    assert state.graph["a"].status == ModuleStatus.FAILED


async def test_orchestrate_no_progress_on_retry_skips(tmp_path):
    """On a retry, has_progress False -> module SKIPPED."""
    graph = {"a": _real_node(tmp_path, "a")}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=False, max_retries=3)
    # Build pipeline patches WITHOUT the has_progress entry; control it separately.
    patches = [
        patch.object(go.DependencyGraphBuilder, "build_graph",
                     staticmethod(lambda p: graph)),
        patch.object(go.DependencyGraphBuilder, "detect_project_type",
                     staticmethod(lambda p: "maven")),
        patch.object(go.GraphResolver, "validate_graph",
                     staticmethod(lambda g: True)),
        patch.object(go.ArtifactManager, "hash_directory",
                     staticmethod(lambda *a, **k: "")),
        patch.object(go.ArtifactManager, "update_hash",
                     staticmethod(lambda m: None)),
    ]
    _apply(patches)
    # First attempt validates False -> retries. Second attempt: has_progress False -> SKIPPED.
    with patch.object(go.CompilerValidator, "validate",
                      staticmethod(lambda m, pt, timeout: (False, "err"))), \
         patch.object(go.ArtifactManager, "has_progress",
                      staticmethod(lambda m: False)):
        try:
            state = await o.orchestrate("go")
        finally:
            _stop(patches)
    assert state.graph["a"].status == ModuleStatus.SKIPPED


# ---------------------------------------------------------------------------
# orchestrate - error / edge cases
# ---------------------------------------------------------------------------
async def test_orchestrate_build_graph_failure_raises():
    factory, _ = _make_provider()
    o = _orch(factory)
    with patch.object(go.DependencyGraphBuilder, "build_graph",
                      staticmethod(lambda p: (_ for _ in ()).throw(RuntimeError("boom")))):
        with pytest.raises(ValueError, match="Failed to build dependency graph"):
            await o.orchestrate("go")


async def test_orchestrate_cycle_detected_raises():
    graph = {"a": _node("a", deps=["b"]), "b": _node("b", deps=["a"])}
    factory, _ = _make_provider()
    o = _orch(factory)
    patches = _patch_pipeline(graph, validate=False)
    _apply(patches)
    try:
        with pytest.raises(ValueError, match="Circular dependencies"):
            await o.orchestrate("go")
    finally:
        _stop(patches)


async def test_orchestrate_detect_type_failure_raises():
    graph = {"a": _node("a")}
    factory, _ = _make_provider()
    o = _orch(factory)
    patches = [
        patch.object(go.DependencyGraphBuilder, "build_graph",
                     staticmethod(lambda p: graph)),
        patch.object(go.GraphResolver, "validate_graph",
                     staticmethod(lambda g: True)),
        patch.object(go.DependencyGraphBuilder, "detect_project_type",
                     staticmethod(lambda p: (_ for _ in ()).throw(RuntimeError("nope")))),
    ]
    _apply(patches)
    try:
        with pytest.raises(ValueError, match="Failed to detect project type"):
            await o.orchestrate("go")
    finally:
        _stop(patches)


async def test_orchestrate_stuck_pending_marked_failed():
    """get_ready_modules returns [] but a module is still PENDING -> marked FAILED."""
    graph = {"a": _node("a")}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)
    with patch.object(go.GraphResolver, "get_ready_modules",
                      staticmethod(lambda g: [])):
        try:
            state = await o.orchestrate("go")
        finally:
            _stop(patches)
    assert state.graph["a"].status == ModuleStatus.FAILED
    assert "Dependency resolution failed" in state.graph["a"].last_error


async def test_orchestrate_no_ready_no_pending_breaks(tmp_path):
    """ready empty + nothing pending (a module stuck IN_PROGRESS) -> 'all processed' break."""
    n = _real_node(tmp_path, "a")
    graph = {"a": n}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)

    # is_complete False (IN_PROGRESS is not terminal) but no PENDING modules and
    # no ready modules -> hits the "All modules processed" break (lines 169-170).
    call_count = {"n": 0}

    def _ready(g):
        call_count["n"] += 1
        n.status = ModuleStatus.IN_PROGRESS
        return []

    with patch.object(go.GraphResolver, "get_ready_modules", staticmethod(_ready)):
        try:
            state = await o.orchestrate("go")
        finally:
            _stop(patches)
    assert call_count["n"] == 1
    assert state.graph["a"].status == ModuleStatus.IN_PROGRESS


async def test_apply_transformation_duplicate_paths_not_readded(tmp_path):
    """Write/patch events with paths already in files_changed hit the loop-back branch."""
    (tmp_path / "pom.xml").write_text("<project/>", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[],
                   files_changed=["/x/A.java", "/x/B.java"])
    events = [
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "write", "path": "/x/A.java"}}},  # dup
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "patch", "path": "/x/B.java"}}},  # dup
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "write", "path": ""}}},  # empty path (write)
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "patch", "path": ""}}},  # empty path (patch)
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "read", "path": "/x/A.java"}}},  # non write/patch op
    ]
    factory, _ = _make_provider(events=events)
    o = _orch(factory, skip_validation=True)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True
    # no duplicates added
    assert m.files_changed == ["/x/A.java", "/x/B.java"]


async def test_orchestrate_empty_graph_completes_immediately():
    graph = {}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)
    try:
        state = await o.orchestrate("go")
    finally:
        _stop(patches)
    assert state.is_complete()
    assert state.total_modules == 0


async def test_orchestrate_initial_hash_logging_branch(tmp_path):
    """Module with a pre-set artifacts_hash hits the `if module.artifacts_hash` branch."""
    n = _real_node(tmp_path, "a")
    n.artifacts_hash = "abc123def456ghij7890"  # pre-set so the logging branch runs
    graph = {"a": n}
    factory, _ = _make_provider()
    o = _orch(factory, skip_validation=True)
    patches = _patch_pipeline(graph)
    _apply(patches)
    try:
        state = await o.orchestrate("go")
    finally:
        _stop(patches)
    assert state.graph["a"].status == ModuleStatus.LOCKED


# ---------------------------------------------------------------------------
# _apply_transformation directly
# ---------------------------------------------------------------------------
async def test_apply_transformation_records_writes_and_patches(tmp_path):
    (tmp_path / "pom.xml").write_text("<project/>", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    events = [
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "write", "path": "/x/A.java"}}},
        {"type": "tool_use", "tool": {"name": "code_editor",
         "input": {"operation": "patch", "path": "/x/B.java"}}},
        {"type": "text", "text": "thinking"},
        {"type": "tool_use", "tool": {"name": "bash", "input": {}}},
    ]
    factory, provider = _make_provider(events=events)
    o = _orch(factory, skip_validation=False)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True
    assert "/x/A.java" in m.files_changed
    assert "/x/B.java" in m.files_changed
    assert len(m.events) == 4


async def test_apply_transformation_javascript_detection(tmp_path):
    (tmp_path / "package.json").write_text("{}", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    factory, provider = _make_provider()
    o = _orch(factory, skip_validation=True)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_apply_transformation_dotnet_detection(tmp_path):
    (tmp_path / "App.csproj").write_text("<Project/>", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    factory, provider = _make_provider()
    o = _orch(factory, skip_validation=True)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True
    # dotnet branch: project_type passed into prompt builder; no error
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_apply_transformation_no_writes_warns(tmp_path):
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    events = [{"type": "text", "text": "only explored"}]
    factory, _ = _make_provider(events=events)
    o = _orch(factory, skip_validation=True)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True  # events exist, just no writes
    assert m.files_changed == []


async def test_apply_transformation_no_events_returns_false(tmp_path):
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    factory, _ = _make_provider(events=[])
    o = _orch(factory, skip_validation=True)
    assert await o._apply_transformation(m, "do it") is False


async def test_apply_transformation_provider_exception_returns_false(tmp_path):
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    factory = MagicMock()
    factory.get_provider = AsyncMock(side_effect=RuntimeError("provider down"))
    o = _orch(factory, skip_validation=True)
    assert await o._apply_transformation(m, "do it") is False


async def test_apply_transformation_retry_skip_validation_adds_guidance(tmp_path):
    """retry>0 with skip_validation appends the extra retry guidance block."""
    (tmp_path / "pom.xml").write_text("<project/>", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[], retries=1)
    captured = {}

    async def _agentic(prompt, project_path, enable_tools, on_event):
        captured["prompt"] = prompt
        return [{"type": "tool_use", "tool": {"name": "code_editor",
                 "input": {"operation": "write", "path": "/x/A.java"}}}]

    factory, provider = _make_provider()
    provider.invoke_with_tools_agentic = AsyncMock(side_effect=_agentic)
    o = _orch(factory, skip_validation=True, max_retries=3)
    ok = await o._apply_transformation(m, "do it")
    assert ok is True
    assert "RETRY ATTEMPT 2 of 3" in captured["prompt"]


async def test_apply_transformation_on_event_passed_through(tmp_path):
    (tmp_path / "pom.xml").write_text("<project/>", encoding="utf-8")
    m = ModuleNode(name="a", path=str(tmp_path), dependencies=[])
    cb = MagicMock()
    factory, provider = _make_provider()
    o = _orch(factory, skip_validation=True)
    await o._apply_transformation(m, "do it", on_event=cb)
    _, kwargs = provider.invoke_with_tools_agentic.await_args
    assert kwargs["on_event"] is cb


# ---------------------------------------------------------------------------
# _format_compilation_errors
# ---------------------------------------------------------------------------
def test_format_compilation_errors_empty():
    factory, _ = _make_provider()
    o = _orch(factory)
    assert "No detailed error" in o._format_compilation_errors("", 1)


def test_format_compilation_errors_with_keywords():
    factory, _ = _make_provider()
    o = _orch(factory)
    raw = "\x1b[31m[ERROR] cannot find symbol\x1b[0m\n  symbol: method foo()\n[INFO] building"
    out = o._format_compilation_errors(raw, 2)
    assert "cannot find symbol" in out
    assert "\x1b[" not in out  # ANSI stripped


def test_format_compilation_errors_fallback_no_keywords():
    factory, _ = _make_provider()
    o = _orch(factory)
    out = o._format_compilation_errors("just some plain text without markers", 1)
    assert "just some plain text" in out


def test_format_compilation_errors_detail_and_symbol_branches():
    """Cover blank-line skip, [..]/colon detail line, and symbol-keyword line."""
    factory, _ = _make_provider()
    o = _orch(factory)
    raw = (
        "[ERROR] compilation failed\n"
        "\n"  # blank line -> continue (line 487)
        "[detail] /path/File.java\n"  # in_error_section + startswith '[' (line 493)
        "symbol: variable x\n"  # symbol keyword (line 496/498)
    )
    out = o._format_compilation_errors(raw, 0)
    assert "compilation failed" in out
    assert "/path/File.java" in out
    assert "variable x" in out


def test_format_compilation_errors_symbol_only_no_error_section():
    """A symbol line with no preceding error keyword hits the elif at line 496."""
    factory, _ = _make_provider()
    o = _orch(factory)
    out = o._format_compilation_errors("import statement here", 0)
    assert "import statement here" in out


# ---------------------------------------------------------------------------
# _rollback_module
# ---------------------------------------------------------------------------
async def test_rollback_with_changed_files():
    factory, _ = _make_provider()
    o = _orch(factory)
    m = ModuleNode(name="a", path="/x", dependencies=[], files_changed=["A.java"])
    await o._rollback_module(m)  # should not raise


async def test_rollback_no_changed_files():
    factory, _ = _make_provider()
    o = _orch(factory)
    m = ModuleNode(name="a", path="/x", dependencies=[])
    await o._rollback_module(m)  # should not raise