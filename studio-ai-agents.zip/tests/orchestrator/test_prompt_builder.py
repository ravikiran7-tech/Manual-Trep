"""Tests for app.orchestrator.prompt_builder."""
from app.orchestrator.prompt_builder import TransformationPromptBuilder
from app.state.models import ModuleNode


def _module(name="svc", deps=None):
    return ModuleNode(name=name, path=f"/tmp/{name}", dependencies=deps or [])


def test_build_full_prompt_maven():
    m = _module(deps=["dep-a", "dep-b"])
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="Migrate to Java 17",
        module=m,
        project_type="maven",
    )
    assert "TRANSFORMATION MISSION" in out
    assert "Migrate to Java 17" in out
    assert "MAVEN POM.XML GUIDANCE" in out
    assert ".NET PROJECT GUIDANCE" not in out
    assert "dep-a, dep-b" in out
    assert "MANDATORY WORKFLOW" in out
    assert "COMPLETION CRITERIA" in out


def test_build_full_prompt_dotnet():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="Upgrade framework",
        module=_module(),
        project_type="dotnet",
    )
    assert ".NET PROJECT GUIDANCE" in out
    assert "MAVEN POM.XML GUIDANCE" not in out


def test_build_full_prompt_javascript():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="Fix M-Basic blockers",
        module=_module(),
        project_type="javascript",
    )
    assert "JAVASCRIPT / NODE.JS PROJECT GUIDANCE" in out
    assert "MAVEN POM.XML GUIDANCE" not in out
    assert ".NET PROJECT GUIDANCE" not in out


def test_build_unknown_project_type_no_guidance():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="x", module=_module(), project_type="rust"
    )
    assert "MAVEN POM.XML GUIDANCE" not in out
    assert ".NET PROJECT GUIDANCE" not in out


def test_no_dependencies_shows_none():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="x", module=_module(deps=[]), project_type="maven"
    )
    assert "**Dependencies**: None" in out


def test_empty_base_prompt_uses_fallback():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="   ", module=_module(), project_type="maven"
    )
    assert "Transform the codebase according to the requirements" in out


def test_clean_architecture_note_added():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="Apply Clean Architecture please",
        module=_module(),
        project_type="maven",
    )
    assert "ARCHITECTURE REQUIREMENT" in out


def test_no_clean_architecture_note_when_absent():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="just refactor", module=_module(), project_type="maven"
    )
    assert "ARCHITECTURE REQUIREMENT" not in out


def test_retry_guidance_included():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="x",
        module=_module(),
        project_type="maven",
        is_retry=True,
        last_error="error: cannot find symbol\n\nMyClass",
        retry_count=2,
    )
    assert "RETRY ATTEMPT 3" in out
    assert "cannot find symbol" in out


def test_retry_guidance_skipped_without_error():
    out = TransformationPromptBuilder.build_transformation_prompt(
        base_prompt="x",
        module=_module(),
        project_type="maven",
        is_retry=True,
        last_error=None,
        retry_count=1,
    )
    assert "Previous Attempt Failed" not in out


def test_format_module_path_passthrough():
    assert TransformationPromptBuilder.format_module_path("/a/b") == "/a/b"