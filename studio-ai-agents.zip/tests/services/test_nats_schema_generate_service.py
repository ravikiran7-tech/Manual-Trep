"""Tests for app.services.nats_schema_generate_service."""
import json
import sqlite3
import sys
import types
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.services.nats_schema_generate_service as nats_mod
from app.services.nats_schema_generate_service import (
    NatsSchemaGenerateService,
    SecretService,
    Secrets,
    NatsSecrets,
    _format_nats_endpoint_for_log,
    _normalize_nats_server_url,
    _parse_nats_servers,
    _validate_uniform_transport,
    _merge_nats_from_process_env,
    _read_sqlite_env_config,
    _parse_auth_enabled,
    _decrypt_nats_credentials,
)
from app.models.responses import AssessmentRulesBatchResponse


# ===========================================================================
# Pure helper functions
# ===========================================================================
@pytest.mark.parametrize("url,expected", [
    ("", "<empty>"),
    ("   ", "<empty>"),
    ("hostonly", "<unparseable>"),
    ("nats://host:4222", "nats://host:4222"),
    ("nats://host", "nats://host"),
    ("nats://", "nats://<no-host>"),
])
def test_format_nats_endpoint_for_log(url, expected):
    assert _format_nats_endpoint_for_log(url) == expected


def test_format_endpoint_strips_userinfo():
    out = _format_nats_endpoint_for_log("nats://user:pass@host:4222")
    assert "user" not in out and "pass" not in out
    assert out == "nats://host:4222"


def test_normalize_empty():
    assert _normalize_nats_server_url("") == ""


def test_normalize_adds_default_port():
    assert _normalize_nats_server_url("nats://host") == "nats://host:4222"


def test_normalize_no_scheme_adds_nats():
    assert _normalize_nats_server_url("host:4222") == "nats://host:4222"


def test_normalize_with_userinfo_and_default_port():
    out = _normalize_nats_server_url("nats://u:p@host")
    assert out == "nats://u:p@host:4222"


def test_normalize_with_username_only():
    out = _normalize_nats_server_url("nats://u@host")
    assert out == "nats://u@host:4222"


def test_normalize_ws_unchanged():
    assert _normalize_nats_server_url("ws://host:8080") == "ws://host:8080"


def test_normalize_keeps_explicit_port():
    assert _normalize_nats_server_url("nats://host:5000") == "nats://host:5000"


def test_parse_servers_multiple():
    servers = _parse_nats_servers("nats://a:4222 , nats://b:4222 ; nats://c:4222")
    assert servers == ["nats://a:4222", "nats://b:4222", "nats://c:4222"]


def test_parse_servers_empty_raises():
    with pytest.raises(RuntimeError):
        _parse_nats_servers("  , ; ")


def test_validate_uniform_ok():
    _validate_uniform_transport(["nats://a:4222", "tls://b:4222"])  # no raise


def test_validate_uniform_mixed_raises():
    with pytest.raises(RuntimeError):
        _validate_uniform_transport(["nats://a:4222", "ws://b:8080"])


def test_merge_from_process_env(monkeypatch):
    monkeypatch.setenv("NATS_URL", "nats://override:4222")
    monkeypatch.delenv("NATS_USERNAME", raising=False)
    out = _merge_nats_from_process_env({"NATS_URL": "old", "X": "y"})
    assert out["NATS_URL"] == "nats://override:4222"
    assert out["X"] == "y"


@pytest.mark.parametrize("raw,expected", [
    (None, False),
    ("true", True),
    ("TRUE", True),
    ("1", True),
    ("yes", True),
    ("false", False),
    ("anything", False),
])
def test_parse_auth_enabled(raw, expected):
    assert _parse_auth_enabled(raw) is expected


# ===========================================================================
# _read_sqlite_env_config
# ===========================================================================
def test_read_sqlite_env_config_success(tmp_path):
    db = tmp_path / "config.db"
    conn = sqlite3.connect(str(db))
    conn.execute("CREATE TABLE env_config (key TEXT, value TEXT)")
    conn.execute("INSERT INTO env_config VALUES ('NATS_URL', 'nats://h:4222')")
    conn.execute("INSERT INTO env_config VALUES ('NULLVAL', NULL)")
    conn.execute("INSERT INTO env_config VALUES (NULL, 'orphan')")
    conn.commit()
    conn.close()

    out = _read_sqlite_env_config(str(db))
    assert out["NATS_URL"] == "nats://h:4222"
    assert out["NULLVAL"] == ""
    assert None not in out  # key is None row skipped


def test_read_sqlite_env_config_missing_db(tmp_path):
    # No env_config table -> exception caught -> empty dict
    out = _read_sqlite_env_config(str(tmp_path / "nope.db"))
    assert out == {}


# ===========================================================================
# SecretService
# ===========================================================================
def test_resolve_sqlite_path_jdbc():
    out = SecretService._resolve_sqlite_path(
        "jdbc:sqlite:/etc/app-config/config.db",
        "/etc/app-config",
    )
    assert out.endswith("config.db")
    assert "jdbc" not in out


def test_resolve_sqlite_path_plain():
    out = SecretService._resolve_sqlite_path(
        "/etc/app-config/config.db",
        "/etc/app-config",
    )
    assert out.endswith("config.db")


def test_resolve_sqlite_path_rejects_traversal():
    with pytest.raises(ValueError, match="Path traversal"):
        SecretService._resolve_sqlite_path(
            "jdbc:sqlite:/etc/app-config/../../etc/passwd",
            "/etc/app-config",
        )


def test_map_to_service_secrets():
    secrets = SecretService._map_to_service_secrets({
        "NATS_URL": "u", "NATS_USERNAME": "user",
        "NATS_PASSWORD": "pw", "NATS_AUTH_ENABLED": "true",
    })
    assert secrets.nats.url == "u"
    assert secrets.nats.user == "user"
    assert secrets.nats.password == "pw"
    assert secrets.nats.auth_enabled == "true"


def test_load_all_secrets(tmp_path, monkeypatch):
    db = tmp_path / "config.db"
    conn = sqlite3.connect(str(db))
    conn.execute("CREATE TABLE env_config (key TEXT, value TEXT)")
    conn.execute("INSERT INTO env_config VALUES ('NATS_URL', 'nats://db:4222')")
    conn.commit()
    conn.close()
    monkeypatch.delenv("NATS_URL", raising=False)

    svc = SecretService(str(db), allowed_directory=str(tmp_path))
    secrets = svc.load_all_secrets()
    assert secrets.nats.url == "nats://db:4222"


# ===========================================================================
# _decrypt_nats_credentials (plaintext passes through with test passphrase)
# ===========================================================================
def test_decrypt_nats_credentials_plaintext():
    nats = NatsSecrets(user="plainuser", password="plainpw")
    _decrypt_nats_credentials(nats, "test-passphrase")
    # plaintext (not base64-looking) passes through unchanged
    assert nats.user == "plainuser"
    assert nats.password == "plainpw"


# ===========================================================================
# Service construction & _build_analysis_id / _parse_request_payload / validate
# ===========================================================================
@pytest.fixture
def service():
    claude = MagicMock()
    claude.execute_assessment_rules_batch = AsyncMock()
    return NatsSchemaGenerateService(claude_service=claude)


def test_build_analysis_id():
    aid = NatsSchemaGenerateService._build_analysis_id()
    assert aid.startswith("schema-gen-")


def test_init_default_claude_service():
    with patch.object(nats_mod, "get_claude_service", return_value="claude") as g:
        svc = NatsSchemaGenerateService()
        g.assert_called_once()
        assert svc._claude_service == "claude"


def _valid_rule(**over):
    base = {
        "domain": "java", "name": "rule1", "description": "desc",
        "ruleId": "R1", "language": "java",
        "category": "Code Quality", "issueType": "NEUTRAL", "severity": "MEDIUM",
    }
    base.update(over)
    return base


def test_parse_request_payload_valid(service):
    raw = json.dumps({"analysisId": "AID", "rules": [_valid_rule(example="ex")]}).encode()
    out = service._parse_request_payload(raw)
    assert out["analysisId"] == "AID"
    assert out["rules"][0]["example"] == "ex"
    assert out["rules"][0]["domain"] == "java"
    assert out["rules"][0]["category"] == "Code Quality"
    assert out["rules"][0]["issueType"] == "NEUTRAL"
    assert out["rules"][0]["severity"] == "MEDIUM"


def test_parse_request_payload_generates_analysis_id(service):
    raw = json.dumps({"rules": [_valid_rule()]}).encode()
    out = service._parse_request_payload(raw)
    assert out["analysisId"].startswith("schema-gen-")
    # example absent -> omitted
    assert "example" not in out["rules"][0]


def test_parse_request_payload_not_object(service):
    with pytest.raises(ValueError, match="JSON object"):
        service._parse_request_payload(json.dumps([1, 2]).encode())


def test_parse_request_payload_rules_not_list(service):
    with pytest.raises(ValueError, match="non-empty list"):
        service._parse_request_payload(json.dumps({"rules": "x"}).encode())


def test_parse_request_payload_rules_empty(service):
    with pytest.raises(ValueError, match="non-empty list"):
        service._parse_request_payload(json.dumps({"rules": []}).encode())


def test_parse_request_payload_rule_not_object(service):
    with pytest.raises(ValueError, match="must be an object"):
        service._parse_request_payload(json.dumps({"rules": ["x"]}).encode())


def test_validate_rule_missing_field(service):
    with pytest.raises(ValueError, match="non-blank"):
        service._validate_rule(_valid_rule(domain="  "), 0)


def test_validate_rule_bad_example(service):
    with pytest.raises(ValueError, match="example must be a string"):
        service._validate_rule(_valid_rule(example=123), 0)


def test_validate_rule_example_none_ok(service):
    service._validate_rule(_valid_rule(example=None), 0)  # no raise


# ===========================================================================
# _publish_result
# ===========================================================================
async def test_publish_result_no_connection(service):
    with pytest.raises(RuntimeError, match="not available"):
        await service._publish_result(
            AssessmentRulesBatchResponse(status="ok", message="m")
        )


async def test_publish_result_ok(service):
    nc = MagicMock()
    nc.publish = AsyncMock()
    nc.flush = AsyncMock()
    service._nc = nc
    await service._publish_result(
        AssessmentRulesBatchResponse(status="ok", message="m", analysis_id="AID")
    )
    nc.publish.assert_awaited_once()
    nc.flush.assert_awaited_once()


# ===========================================================================
# _on_message
# ===========================================================================
async def test_on_message_success(service):
    async def mock_execute(request, on_progress=None):
        response = AssessmentRulesBatchResponse(
            status="success",
            message="done",
            analysis_id="AID",
            is_final=True,
            chunk_index=1,
            chunk_count=1,
        )
        if on_progress is not None:
            await on_progress(response)
        return response

    service._claude_service.execute_assessment_rules_batch = AsyncMock(
        side_effect=mock_execute
    )
    service._publish_result = AsyncMock()
    msg = MagicMock()
    msg.data = json.dumps({"analysisId": "AID", "rules": [_valid_rule()]}).encode()

    await service._on_message(msg)

    service._claude_service.execute_assessment_rules_batch.assert_awaited_once()
    service._publish_result.assert_awaited_once()
    published = service._publish_result.call_args[0][0]
    assert published.status == "success"


async def test_on_message_error_publishes_failure(service):
    service._publish_result = AsyncMock()
    msg = MagicMock()
    msg.data = b"not json"

    await service._on_message(msg)

    service._publish_result.assert_awaited_once()
    failure = service._publish_result.call_args[0][0]
    assert failure.status == "error"
    assert failure.analysis_id  # generated id since parse failed before analysis_id set


async def test_on_message_error_keeps_analysis_id(service):
    # analysisId parsed, but downstream LLM raises
    service._claude_service.execute_assessment_rules_batch.side_effect = RuntimeError("llm boom")
    service._publish_result = AsyncMock()
    msg = MagicMock()
    msg.data = json.dumps({"analysisId": "KEEPME", "rules": [_valid_rule()]}).encode()

    await service._on_message(msg)

    failure = service._publish_result.call_args[0][0]
    assert failure.status == "error"
    assert failure.analysis_id == "KEEPME"


# ===========================================================================
# start() / stop()
# ===========================================================================
def _patched_settings(tmp_path, enabled=True, auth=False):
    s = MagicMock()
    s.nats.enabled = enabled
    s.nats.sqlite_config_db_path = str(tmp_path / "config.db")
    s.nats.sqlite_config_allowed_dir = str(tmp_path)
    s.nats.client_name = "test-client"
    s.nats.connect_timeout_seconds = 1
    s.nats.reconnect_wait_seconds = 1
    s.nats.max_reconnects = 1
    s.nats.schema_generate_request_subject = "schema.generate.request"
    s.nats.schema_generate_result_subject = "schema.generate.result"
    s.nats.project_path = "/tmp"
    s.nats.platform = "linux"
    s.enc_passphrase = "test-passphrase"
    return s


def _seed_db(tmp_path, **rows):
    db = tmp_path / "config.db"
    conn = sqlite3.connect(str(db))
    conn.execute("CREATE TABLE env_config (key TEXT, value TEXT)")
    for k, v in rows.items():
        conn.execute("INSERT INTO env_config VALUES (?, ?)", (k, v))
    conn.commit()
    conn.close()


def _fake_nats_module():
    mod = types.ModuleType("nats")
    nc = MagicMock()
    nc.subscribe = AsyncMock(return_value=MagicMock())
    nc.connected_url = "nats://connected:4222"
    mod.connect = AsyncMock(return_value=nc)
    return mod, nc


async def test_start_disabled(service, tmp_path, monkeypatch):
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path, enabled=False))
    await service.start()
    assert service._started is False


async def test_start_already_started(service):
    service._started = True
    await service.start()  # returns immediately, no error
    assert service._started is True


async def test_start_import_error(service, tmp_path, monkeypatch):
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path))
    monkeypatch.setitem(sys.modules, "nats", None)  # forces ImportError
    with pytest.raises(RuntimeError, match="nats. module is not available"):
        await service.start()


async def test_start_success_no_auth(service, tmp_path, monkeypatch):
    _seed_db(tmp_path, NATS_URL="nats://host:4222")
    monkeypatch.delenv("NATS_URL", raising=False)
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path))
    fake_mod, nc = _fake_nats_module()
    monkeypatch.setitem(sys.modules, "nats", fake_mod)

    await service.start()

    assert service._started is True
    fake_mod.connect.assert_awaited_once()
    # no auth -> no user/password kwargs
    kwargs = fake_mod.connect.call_args.kwargs
    assert "user" not in kwargs
    nc.subscribe.assert_awaited_once()


async def test_start_success_with_auth(service, tmp_path, monkeypatch):
    _seed_db(
        tmp_path, NATS_URL="nats://host:4222",
        NATS_USERNAME="u", NATS_PASSWORD="p", NATS_AUTH_ENABLED="true",
    )
    for k in ("NATS_URL", "NATS_USERNAME", "NATS_PASSWORD", "NATS_AUTH_ENABLED"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path, auth=True))
    fake_mod, nc = _fake_nats_module()
    monkeypatch.setitem(sys.modules, "nats", fake_mod)

    await service.start()

    kwargs = fake_mod.connect.call_args.kwargs
    assert kwargs["user"] == "u"
    assert kwargs["password"] == "p"


async def test_start_missing_url_raises(service, tmp_path, monkeypatch):
    _seed_db(tmp_path)  # no NATS_URL
    monkeypatch.delenv("NATS_URL", raising=False)
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path))
    fake_mod, _ = _fake_nats_module()
    monkeypatch.setitem(sys.modules, "nats", fake_mod)

    with pytest.raises(RuntimeError, match="NATS_URL is missing"):
        await service.start()


async def test_start_decrypt_failure_raises(service, tmp_path, monkeypatch):
    _seed_db(tmp_path, NATS_URL="nats://host:4222")
    monkeypatch.delenv("NATS_URL", raising=False)
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path))
    fake_mod, _ = _fake_nats_module()
    monkeypatch.setitem(sys.modules, "nats", fake_mod)
    monkeypatch.setattr(
        nats_mod, "_decrypt_nats_credentials",
        MagicMock(side_effect=RuntimeError("decrypt boom")),
    )

    with pytest.raises(RuntimeError, match="Failed to decrypt"):
        await service.start()


async def test_start_error_cb_callable(service, tmp_path, monkeypatch):
    _seed_db(tmp_path, NATS_URL="nats://host:4222")
    monkeypatch.delenv("NATS_URL", raising=False)
    monkeypatch.setattr(nats_mod, "settings", _patched_settings(tmp_path))
    fake_mod, _ = _fake_nats_module()
    monkeypatch.setitem(sys.modules, "nats", fake_mod)

    await service.start()
    # invoke the registered error callback for coverage
    err_cb = fake_mod.connect.call_args.kwargs["error_cb"]
    await err_cb(Exception("simulated"))


async def test_stop_not_started(service):
    await service.stop()  # no-op
    assert service._started is False


async def test_stop_full(service):
    sub = MagicMock()
    sub.unsubscribe = AsyncMock()
    nc = MagicMock()
    nc.drain = AsyncMock()
    nc.close = AsyncMock()
    service._subscription = sub
    service._nc = nc
    service._started = True

    await service.stop()

    sub.unsubscribe.assert_awaited_once()
    nc.drain.assert_awaited_once()
    nc.close.assert_awaited_once()
    assert service._started is False
    assert service._nc is None


async def test_stop_started_no_handles(service):
    # _started True but subscription/nc None -> skips inner branches
    service._started = True
    service._subscription = None
    service._nc = None
    await service.stop()
    assert service._started is False