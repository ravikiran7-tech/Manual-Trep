import json
from pathlib import Path

from app.services.mssql_pg.artifact_packager import (
    FIELDNAMES,
    build_complete_schema,
    build_manual_review_checklist,
    render_phase_script,
    build_transformation_summary,
    package_all_artifacts,
    validate_complete_schema_matches,
    write_phase_scripts,
)
from app.services.mssql_pg.progress import SCRIPT_ORDER, save_conversion_plan, save_progress, default_progress


def _obj(obj_type, name, *, status="converted", conversion="SUCCESS", confidence="HIGH", review=False, code="", phase=4, **extra):
    entry = {
        "type": obj_type,
        "schema": "dbo",
        "name": name,
        "status": status,
        "conversionStatus": conversion,
        "confidenceScore": confidence,
        "requiresManualReview": review,
        "convertedCode": code or f"-- {obj_type} {name}",
        "executionPhase": phase,
        "phaseOrder": extra.pop("phaseOrder", 1),
        "outputFile": extra.pop("outputFile", "create_tables.sql"),
        "reviewGuidance": extra.pop("reviewGuidance", []),
        "comments": extra.pop("comments", []),
        "incompatibilities": extra.pop("incompatibilities", []),
    }
    entry.update(extra)
    return entry


def test_manual_review_checklist_has_eight_columns_and_sorts_riskiest_first():
    plan = [
        _obj("TABLE", "High", confidence="HIGH", review=True, reviewGuidance=[{"reason": "x", "priority": "LOW"}]),
        _obj("VIEW", "Manual", confidence="MANUAL", review=True, reviewGuidance=[{"reason": "y", "priority": "CRITICAL"}]),
        _obj("FUNCTION", "Low", confidence="LOW", review=True, reviewGuidance=[{"reason": "z", "priority": "HIGH"}]),
    ]
    rows = build_manual_review_checklist(plan, "DB1")
    assert [r["Source Object"].split(".")[-1] for r in rows] == ["Manual", "Low", "High"]
    assert list(rows[0].keys()) == FIELDNAMES
    assert len(FIELDNAMES) == 8
    assert rows[0]["Phase File"].startswith("DB1_") or rows[0]["Phase File"] == ""


def test_phase_script_limits_comment_words_and_separates_objects():
    long_note = " ".join(f"w{i}" for i in range(80))
    long_reason = " ".join(f"g{i}" for i in range(120))
    plan = [
        _obj(
            "TABLE",
            "T1",
            review=True,
            reviewGuidance=[{"reason": long_reason, "priority": "HIGH"}],
            incompatibilities=[{"rule_id": "PG-080", "remediation": {"note_template": long_note}}],
            comments=[long_note],
        ),
        _obj("TABLE", "T2"),
    ]
    text = render_phase_script(plan)
    assert "-- ----------" in text
    assert text.count("w0") == 2
    assert "w50" not in text
    assert "g99" in text
    assert "g100" not in text


def test_write_phase_scripts_and_complete_schema_match(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.workspace_base", lambda override=None: tmp_path)
    monkeypatch.setattr("app.services.mssql_pg.artifact_packager.output_dir", lambda job_id, override=None: tmp_path / "output")

    plan = [
        _obj("SCHEMA", "sales", code="CREATE SCHEMA IF NOT EXISTS sales;", phase=1, phaseOrder=1),
        _obj("TABLE", "T1", code="CREATE TABLE dbo.t1(id int);", phase=4, phaseOrder=2),
    ]
    written = write_phase_scripts("job1", "DB1", plan)
    assert len(written) == 16
    assert all((tmp_path / "output" / name).exists() for name in written)

    complete = build_complete_schema("job1", "DB1")
    assert complete.exists()
    assert validate_complete_schema_matches("job1", "DB1") is True
    text = complete.read_text(encoding="utf-8")
    assert "CREATE SCHEMA IF NOT EXISTS sales;" in text
    assert "CREATE TABLE dbo.t1(id int);" in text


def test_transformation_summary_reconciliation(tmp_path):
    plan = [
        _obj("TABLE", "T1", conversion="SUCCESS"),
        _obj("VIEW", "V1", conversion="PARTIAL"),
        _obj("FUNCTION", "F1", conversion="UNCONVERTIBLE", status="failed"),
    ]
    skipped = [{"object_name": "Missing", "reason": "SOURCE_NOT_FOUND"}]
    summary = build_transformation_summary(
        plan,
        skipped,
        {"dbName": "SalesDB", "targetDatabaseVersion": "16"},
        "DB1",
        total_objects_expected=4,
    )
    assert summary["conversionResult"]["total_objects"] == 4
    assert summary["conversionResult"]["converted"] == 2
    assert summary["conversionResult"]["deliverable_converted"] == 2
    assert summary["conversionResult"]["failed"] == 1
    assert summary["conversionResult"]["skipped"] == 1
    assert "duration" in summary["timing"]
    assert summary["reconciliation"]["isConsistent"] is True
    assert summary["executiveSummary"] == {
        "successfullyConverted": 2,
        "requiresReview": 0,
        "failed": 1,
        "totalObjects": 3,
    }
    tables = next(row for row in summary["objectsByType"] if row["objectType"] == "Tables")
    views = next(row for row in summary["objectsByType"] if row["objectType"] == "Views")
    functions = next(row for row in summary["objectsByType"] if row["objectType"] == "Functions")
    assert tables["autoConverted"] == 1
    assert views["autoConverted"] == 1
    assert functions["autoConverted"] == 0
    assert functions["total"] == 1


def test_transformation_summary_database_id_is_not_the_sql_name():
    plan = [_obj("TABLE", "T1", conversion="SUCCESS")]
    summary = build_transformation_summary(
        plan,
        [],
        {
            "dbName": "sqlOp",
            "databaseName": "ResortsLiteDB",
            "dbId": "ResortsLiteDB",
            "jobId": "DB031S",
            "targetDatabaseVersion": "15",
            "sourceDatabaseVersion": "SQL Server 2017",
        },
        "sqlOp",
    )
    assert summary["database"]["id"] == "DB031S"
    assert summary["database"]["name"] == "sqlOp"
    assert summary["databaseMetadata"]["databaseId"] == "DB031S"


def test_transformation_summary_database_id_skips_unknown_database():
    plan = [_obj("TABLE", "T1", conversion="SUCCESS")]
    summary = build_transformation_summary(
        plan,
        [],
        {
            "dbName": "msqldf",
            "dbId": "UnknownDatabase",
            "jobId": "DB031S",
            "targetDatabaseVersion": "15",
            "sourceDatabaseVersion": "SQL Server 2016",
        },
        "msqldf",
    )
    assert summary["database"]["id"] == "DB031S"
    assert summary["database"]["name"] == "msqldf"
    assert summary["databaseMetadata"]["databaseId"] == "DB031S"


def test_transformation_summary_database_id_skips_placeholder_config_dbid():
    plan = [_obj("TABLE", "T1", conversion="SUCCESS")]
    summary = build_transformation_summary(
        plan,
        [],
        {"dbName": "DbMSSQL1", "dbId": "TestDB", "targetDatabaseVersion": "16"},
        "DbMSSQL1",
    )
    assert summary["database"]["id"] == "DbMSSQL1"
    assert summary["databaseMetadata"]["databaseId"] == "DbMSSQL1"


def test_package_all_artifacts_writes_zip_and_checklist(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.workspace_base", lambda override=None: tmp_path)
    out = tmp_path / "mssql-pg-transformation" / "job1" / "output"
    state = tmp_path / "mssql-pg-transformation" / "job1" / "state"
    out.mkdir(parents=True)
    state.mkdir(parents=True)

    monkeypatch.setattr("app.services.mssql_pg.artifact_packager.output_dir", lambda job_id, override=None: out)
    monkeypatch.setattr("app.services.mssql_pg.progress.conversion_plan_path", lambda job_id, override=None: state / "conversion-plan.json")
    monkeypatch.setattr("app.services.mssql_pg.progress.progress_path", lambda job_id, override=None: state / "progress.json")

    plan = [_obj("TABLE", "T1", code="CREATE TABLE dbo.t1(id int);", phase=4, review=True, confidence="LOW")]
    save_conversion_plan("job1", plan)
    save_progress("job1", default_progress("job1"))

    result = package_all_artifacts("job1", "DB1", {"dbName": "SalesDB"}, plan, [], total_objects_expected=1)
    assert result["completeSchemaValid"] is True
    assert (out / "DB1_postgresql_scripts.zip").exists()
    assert (out / "transformation_summary.json").exists()
    assert (out / "post_transformation_report.json").exists()
    assert (out / "Manual_Review_Checklist.csv").exists()
    for suffix in SCRIPT_ORDER:
        assert (out / f"DB1_{suffix}").exists()
