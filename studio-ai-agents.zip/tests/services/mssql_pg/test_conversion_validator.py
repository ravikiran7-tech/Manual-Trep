import json

import pytest

from app.services.mssql_pg.conversion_validator import ValidationError, extract_json, parse_and_validate, unconvertible_result


def _obj(floor="HIGH"):
    return {"schema": "dbo", "name": "T1", "confidenceFloor": floor}


def _response(**overrides):
    base = {
        "conversionStatus": "SUCCESS",
        "convertedCode": "CREATE TABLE dbo.t1 (id int);",
        "confidenceScore": "HIGH",
    }
    base.update(overrides)
    return json.dumps(base)


def test_extract_json_plain():
    assert extract_json('{"a": 1}') == {"a": 1}


def test_extract_json_with_markdown_fence():
    text = "Here you go:\n```json\n{\"a\": 1}\n```"
    assert extract_json(text) == {"a": 1}


def test_extract_json_with_surrounding_prose():
    text = "Sure thing. {\"a\": 1} Hope that helps."
    assert extract_json(text) == {"a": 1}


def test_extract_json_empty_raises():
    with pytest.raises(ValidationError):
        extract_json("")


def test_extract_json_invalid_raises():
    with pytest.raises(ValidationError):
        extract_json("not json at all without braces")


def test_parse_and_validate_success():
    result = parse_and_validate(_response(), _obj())
    assert result["conversionStatus"] == "SUCCESS"
    assert result["confidenceScore"] == "HIGH"
    assert result["requiresManualReview"] is False


def test_parse_and_validate_enforces_floor():
    result = parse_and_validate(_response(confidenceScore="HIGH"), _obj(floor="LOW"))
    assert result["confidenceScore"] == "LOW"
    assert result["requiresManualReview"] is True


def test_parse_and_validate_rejects_bad_status():
    with pytest.raises(ValidationError, match="conversionStatus"):
        parse_and_validate(_response(conversionStatus="WRONG"), _obj())


def test_parse_and_validate_rejects_empty_code_when_not_unconvertible():
    with pytest.raises(ValidationError, match="convertedCode"):
        parse_and_validate(_response(convertedCode=""), _obj())


def test_parse_and_validate_allows_empty_code_when_unconvertible():
    result = parse_and_validate(_response(conversionStatus="UNCONVERTIBLE", convertedCode=""), _obj())
    assert result["conversionStatus"] == "UNCONVERTIBLE"


def test_parse_and_validate_normalizes_caller_updates():
    response = _response(callerUpdatesNeeded=[{"reason": "udt_elimination", "replacement_type": "jsonb"}, {"reason": "bogus"}])
    result = parse_and_validate(response, _obj())
    assert len(result["callerUpdatesNeeded"]) == 1
    assert result["callerUpdatesNeeded"][0]["reason"] == "UDT_ELIMINATION"


def test_unconvertible_result_shape():
    result = unconvertible_result(_obj(), "timeout")
    assert result["conversionStatus"] == "UNCONVERTIBLE"
    assert result["confidenceScore"] == "MANUAL"
    assert result["requiresManualReview"] is True
    assert result["reviewGuidance"][0]["reason"] == "timeout"
