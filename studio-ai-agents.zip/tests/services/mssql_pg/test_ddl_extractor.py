"""Tests for the T-SQL CREATE/ALTER DDL block parser."""

from app.services.mssql_pg.ddl_extractor import index_ddl_blocks, lookup_block, parse_ddl_script

SAMPLE_DDL = """
CREATE TABLE dbo.Customers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL
)
GO

CREATE VIEW dbo.ActiveCustomers
AS
SELECT * FROM dbo.Customers WHERE Active = 1
GO

CREATE OR ALTER PROCEDURE dbo.GetCustomer
    @Id INT
AS
BEGIN
    SELECT * FROM dbo.Customers WHERE Id = @Id;
END
GO

ALTER TABLE dbo.Customers ADD CONSTRAINT FK_Customers_Region FOREIGN KEY (RegionId) REFERENCES dbo.Regions(Id)
GO

CREATE NONCLUSTERED INDEX IX_Customers_Name ON dbo.Customers(Name)
GO
"""


def test_parse_ddl_script_finds_all_blocks():
    blocks = parse_ddl_script(SAMPLE_DDL, "sample.sql")
    types = {(b.schema, b.name): b.object_type for b in blocks}
    assert types[("dbo", "Customers")] == "TABLE"
    assert types[("dbo", "ActiveCustomers")] == "VIEW"
    assert types[("dbo", "GetCustomer")] == "PROCEDURE"
    assert types[("dbo", "IX_Customers_Name")] == "INDEX"


def test_parse_ddl_script_resolves_alter_constraint_type():
    blocks = parse_ddl_script(SAMPLE_DDL, "sample.sql")
    fk = next(b for b in blocks if b.name == "FK_Customers_Region")
    assert fk.object_type == "FOREIGN_KEY"
    assert "REFERENCES dbo.Regions" in fk.ddl


def test_block_ddl_is_bounded_by_go_statement():
    blocks = parse_ddl_script(SAMPLE_DDL, "sample.sql")
    table_block = next(b for b in blocks if b.name == "Customers" and b.object_type == "TABLE")
    assert "CREATE TABLE dbo.Customers" in table_block.ddl
    assert "ActiveCustomers" not in table_block.ddl


def test_index_and_lookup_block_fallback_to_dbo(tmp_path):
    path = tmp_path / "sample.sql"
    path.write_text(SAMPLE_DDL, encoding="utf-8")
    index = index_ddl_blocks(path)
    found = lookup_block(index, "dbo", "Customers")
    assert found is not None
    assert found.object_type == "TABLE"
    missing = lookup_block(index, "unknown_schema", "Nope")
    assert missing is None


def test_index_ddl_blocks_reads_bom(tmp_path):
    path = tmp_path / "bom.sql"
    path.write_text(SAMPLE_DDL, encoding="utf-8-sig")
    index = index_ddl_blocks(path)
    assert ("dbo", "customers") in index
