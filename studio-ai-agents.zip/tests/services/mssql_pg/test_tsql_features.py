from app.services.mssql_pg.tsql_features import detect_features, merged_features


def test_detect_features_finds_common_constructs():
    ddl = """
    CREATE PROCEDURE dbo.Foo AS
    BEGIN TRY
        BEGIN TRAN
        EXEC sp_executesql @sql
        DECLARE cur CURSOR FOR SELECT 1
        SELECT TOP 10 * FROM #temp
        IF 1=1 RAISERROR('x', 16, 1)
        ELSE THROW
    END TRY
    BEGIN CATCH
    END CATCH
    """
    features = detect_features(ddl)
    assert features["has_error_handling"] is True
    assert features["has_transaction_control"] is True
    assert features["has_dynamic_sql"] is True
    assert features["has_cursor"] is True
    assert features["has_temp_tables"] is True
    assert features["uses_top"] is True
    assert features["uses_raiserror"] is True
    assert features["uses_throw"] is True
    assert features["is_multi_branch"] is True


def test_detect_features_ignores_comments():
    ddl = "-- BEGIN TRAN\n/* CURSOR */\nSELECT 1"
    features = detect_features(ddl)
    assert features["has_transaction_control"] is False
    assert features["has_cursor"] is False


def test_detect_features_empty_input():
    assert detect_features(None) == {}
    assert detect_features("") == {}


def test_merged_features_declared_flags_win():
    obj = {
        "sourceCode": {"ddl": "BEGIN TRAN SELECT 1"},
        "structuralMetadata": {"features": {"has_transaction_control": False}, "is_clr": True},
    }
    merged = merged_features(obj)
    assert merged["has_transaction_control"] is False
    assert merged["is_clr"] is True
