import app.core.config as config_mod


def test_mssql_pg_agent_default_sonnet_model_is_5_5():
    from app.core.config import MssqlPgAgentConfig

    assert MssqlPgAgentConfig().sonnet_model_id == "us.anthropic.claude-sonnet-5-5"


def test_mssql_bedrock_env_matches_oracle_shape(reset_settings_singleton, monkeypatch):
    from app.core.config import get_settings

    monkeypatch.delenv("MSSQL_PG_AGENT_SONNET_MODEL_ID", raising=False)
    monkeypatch.delenv("ORACLE_PG_AGENT_SONNET_MODEL_ID", raising=False)
    config_mod.settings = None

    settings = get_settings()
    oracle_env = settings.oracle_pg_agent.bedrock_env("us-east-1")
    mssql_env = settings.mssql_pg_agent.bedrock_env("us-east-1")

    assert set(mssql_env) == set(oracle_env)
    for key in oracle_env:
        assert mssql_env[key] == oracle_env[key]
    assert mssql_env["CLAUDE_CODE_USE_BEDROCK"] == "1"
    assert mssql_env["AWS_REGION"] == "us-east-1"


def test_mssql_bedrock_env_honors_mssql_sonnet_override(reset_settings_singleton, monkeypatch):
    from app.core.config import get_settings

    monkeypatch.setenv("ORACLE_PG_AGENT_SONNET_MODEL_ID", "global.anthropic.claude-sonnet-5-5")
    monkeypatch.setenv("MSSQL_PG_AGENT_SONNET_MODEL_ID", "us.anthropic.claude-sonnet-5-5")
    config_mod.settings = None

    settings = get_settings()
    mssql_env = settings.mssql_pg_agent.bedrock_env("us-east-1")
    oracle_env = settings.oracle_pg_agent.bedrock_env("us-east-1")
    assert mssql_env["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "us.anthropic.claude-sonnet-5-5"
    assert oracle_env["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "global.anthropic.claude-sonnet-5-5"


def test_mssql_bedrock_env_uses_mssql_timeout_fields(reset_settings_singleton, monkeypatch):
    from app.core.config import get_settings

    monkeypatch.setenv("MSSQL_PG_AGENT_API_TIMEOUT_MS", "120000")
    monkeypatch.setenv("ORACLE_PG_AGENT_API_TIMEOUT_MS", "600000")
    config_mod.settings = None

    settings = get_settings()
    mssql_env = settings.mssql_pg_agent.bedrock_env("us-east-1")
    assert mssql_env["API_TIMEOUT_MS"] == "120000"
