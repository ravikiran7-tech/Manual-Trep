from app.services.mssql_pg.report_status import resolve_ui_conversion_status


def _obj(**kwargs):
    obj = {
        "type": "TABLE",
        "status": "converted",
        "conversionStatus": "SUCCESS",
        "confidenceScore": "HIGH",
        "requiresManualReview": False,
        "isClr": False,
        "isEncrypted": False,
        "incompatibilities": [],
    }
    obj.update(kwargs)
    return obj


def test_no_findings_or_partial_review_flag_is_auto_converted():
    assert resolve_ui_conversion_status(_obj()) == "auto_converted"
    assert (
        resolve_ui_conversion_status(_obj(conversionStatus="PARTIAL", requiresManualReview=True, confidenceScore="MEDIUM"))
        == "auto_converted"
    )


def test_ds_and_sc_low_are_auto_converted():
    assert resolve_ui_conversion_status(_obj(incompatibilities=[{"compatibility": "DS"}])) == "auto_converted"
    assert (
        resolve_ui_conversion_status(_obj(incompatibilities=[{"compatibility": "SC", "severity": "LOW"}]))
        == "auto_converted"
    )


def test_sc_high_and_low_confidence_are_require_review():
    assert (
        resolve_ui_conversion_status(_obj(incompatibilities=[{"compatibility": "SC", "severity": "HIGH"}]))
        == "require_review"
    )
    assert (
        resolve_ui_conversion_status(_obj(incompatibilities=[{"compatibility": "SC", "complexity": "medium"}]))
        == "require_review"
    )
    assert resolve_ui_conversion_status(_obj(confidenceScore="LOW")) == "require_review"


def test_ns_clr_encrypted_manual_are_manual_implementation():
    assert (
        resolve_ui_conversion_status(_obj(incompatibilities=[{"compatibility": "NS"}])) == "manual_implementation"
    )
    assert resolve_ui_conversion_status(_obj(isClr=True)) == "manual_implementation"
    assert resolve_ui_conversion_status(_obj(isEncrypted=True)) == "manual_implementation"
    assert resolve_ui_conversion_status(_obj(confidenceScore="MANUAL")) == "manual_implementation"


def test_unconvertible_is_failed():
    assert resolve_ui_conversion_status(_obj(conversionStatus="UNCONVERTIBLE", status="failed")) == "failed"
