"""End-to-end: six Compass inputs -> four passes -> artifacts, with a fake model."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from tests.services.mssql_pg.conftest import stage_compass_files


@pytest.fixture
def isolated_workspace(tmp_path, monkeypatch):
    from app.core.config import get_settings
    from app.services.db_transformation.sources import reset_adapter_cache
    from app.services.mssql_pg.job_manager import reset_job_manager

    settings = get_settings()
    monkeypatch.setattr(settings, "claude_workspace", str(tmp_path))
    reset_job_manager()
    reset_adapter_cache()
    yield tmp_path
    reset_job_manager()
    reset_adapter_cache()


def test_e2e_four_passes_produce_all_artifacts(isolated_workspace, fake_model_caller, monkeypatch):
    from app.services.mssql_pg.agent_runner import make_sdk_caller
    from app.services.mssql_pg.job_manager import get_job_manager
    from app.services.mssql_pg.progress import load_progress
    from app.services.mssql_pg.workspace import job_root, output_dir

    db_name = "ResortsLiteDB"
    claude = job_root(db_name) / "_claude"
    input_paths = stage_compass_files(claude, db_name=db_name)

    monkeypatch.setattr(
        "app.services.mssql_pg.orchestrator.make_sdk_caller",
        lambda config: fake_model_caller,
    )

    manager = get_job_manager()
    request = {
        "jobId": "e2e01",
        "dbName": db_name,
        "targetDatabaseVersion": "16",
        "inputPaths": input_paths,
    }

    async def _run():
        launched = await manager.launch(request)
        task = next(iter(manager._tasks.values()), None)
        if task is not None:
            await task
        return launched

    launched = asyncio.run(_run())
    assert launched["jobId"] == "e2e01"
    assert launched["status"] == "queued"

    progress = load_progress(db_name)
    assert progress["status"] == "completed"
    assert progress["message"] == "DB Modernization Completed"
    assert progress["progressPercent"] == 100
    assert progress["jobId"] == "e2e01"
    assert progress["objectsTotal"] == 6
    assert progress["artifacts"]
    events = (job_root(db_name) / "stream" / "events.jsonl").read_text(encoding="utf-8").strip().splitlines()
    last_event = json.loads(events[-1])
    assert last_event["type"] == "progress_updated"
    assert last_event["status"] == "completed"
    assert last_event["message"] == "DB Modernization Completed"
    assert last_event["progressPercent"] == 100
    assert last_event["objectsTotal"] == 6
    assert last_event["duration"]

    out = output_dir(db_name)
    assert (out / "transformation_summary.json").exists()
    assert (out / "post_transformation_report.json").exists()
    assert (out / f"{db_name}_complete_schema.sql").exists()
    assert (out / "Manual_Review_Checklist.csv").exists()
    assert (out / f"{db_name}_postgresql_scripts.zip").exists()
    for suffix in (
        "create_schemas.sql",
        "create_tables.sql",
        "create_views.sql",
        "create_procedures.sql",
        "create_synonyms.sql",
    ):
        assert (out / f"{db_name}_{suffix}").exists()

    summary = json.loads((out / "transformation_summary.json").read_text(encoding="utf-8"))
    assert summary["conversionResult"]["total_objects"] == 6
    assert summary["conversionResult"]["converted"] >= 5
    assert summary["conversionResult"]["deliverable_converted"] == summary["conversionResult"]["converted"]
    assert "duration" in summary["timing"]
    assert summary["reconciliation"]["isConsistent"] is True
    assert summary["executiveSummary"]["successfullyConverted"] >= 1
    assert summary["executiveSummary"]["totalObjects"] == 6
    assert (
        summary["executiveSummary"]["successfullyConverted"]
        + summary["executiveSummary"]["requiresReview"]
        + summary["executiveSummary"]["failed"]
        == 6
    )

    complete = (out / f"{db_name}_complete_schema.sql").read_text(encoding="utf-8")
    assert "CREATE SCHEMA IF NOT EXISTS sales;" in complete
    assert "CREATE TABLE" in complete
    tables = (out / f"{db_name}_create_tables.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE" in tables
