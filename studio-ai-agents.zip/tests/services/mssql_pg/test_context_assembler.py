import pytest

from app.services.mssql_pg.context_assembler import assemble_context
from app.services.mssql_pg.ddl_extractor import index_ddl_blocks

DDL_TEXT = """
CREATE TABLE dbo.Orders (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL
)
GO

CREATE VIEW dbo.OrderSummary AS SELECT * FROM dbo.Orders
GO
"""


@pytest.fixture
def ddl_index(tmp_path):
    path = tmp_path / "script.sql"
    path.write_text(DDL_TEXT, encoding="utf-8")
    return index_ddl_blocks(path)


def _asis(total_objects=3):
    return {
        "statistics": {"total_objects": total_objects},
        "database_objects": {
            "tables": [{"name": "Orders", "schema": "dbo"}],
            "views": [{"name": "OrderSummary", "schema": "dbo"}],
            "functions": [{"name": "GetTotal", "schema": "dbo"}],
        },
    }


def test_assemble_context_basic_counts(ddl_index):
    plan, skipped, warnings = assemble_context(
        asis=_asis(),
        incompatibilities={"incompatibilities": []},
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    assert len(plan) == 2  # function has no DDL -> skipped
    assert len(skipped) == 1
    assert skipped[0]["object_name"] == "GetTotal"
    assert skipped[0]["reason"] == "SOURCE_NOT_FOUND"


def test_assemble_context_attaches_source_ddl(ddl_index):
    plan, _, _ = assemble_context(
        asis=_asis(),
        incompatibilities={"incompatibilities": []},
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    table = next(o for o in plan if o["type"] == "TABLE")
    assert "CREATE TABLE dbo.Orders" in table["sourceCode"]["ddl"]
    assert table["executionPhase"] == 4
    assert table["confidenceFloor"] in {"HIGH", "MEDIUM", "LOW"}


def test_assemble_context_attaches_remediation_and_flags_unhandled(ddl_index):
    incompat = {
        "incompatibilities": [
            {"object_name": "Orders", "schema": "dbo", "rule_id": "PG-100", "compatibility": "NS"},
        ]
    }
    plan, _, warnings = assemble_context(
        asis=_asis(),
        incompatibilities=incompat,
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    table = next(o for o in plan if o["type"] == "TABLE")
    assert table["incompatibilities"][0]["remediation_status"] == "UNHANDLED"
    assert table["requiresManualReview"] is True
    assert any("PG-100" in w or "Remediation" in w for w in warnings)


def test_assemble_context_continues_when_statistics_mismatch_is_large(ddl_index):
    plan, skipped, warnings = assemble_context(
        asis=_asis(total_objects=99),
        incompatibilities={"incompatibilities": []},
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    assert len(plan) == 2
    assert len(skipped) == 1
    assert any("AS-IS object count 99" in warning and "Continuing" in warning for warning in warnings)


def test_assemble_context_warns_when_count_mismatch_is_within_five_percent(ddl_index):
    asis = _asis(total_objects=24)
    asis["database_objects"]["schemas"] = [{"name": f"s{i}", "schema": f"s{i}"} for i in range(20)]
    plan, skipped, warnings = assemble_context(
        asis=asis,
        incompatibilities={"incompatibilities": []},
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    assert len(plan) + len(skipped) == 23
    assert any("AS-IS object count 24" in warning and "Continuing" in warning for warning in warnings)


def test_assemble_context_warns_when_incompatibility_object_missing_from_ddl(ddl_index):
    _, _, warnings = assemble_context(
        asis=_asis(),
        incompatibilities={
            "incompatibilities": [{"object_name": "GetTotal", "schema": "dbo", "rule_id": "PG-080", "compatibility": "SC"}]
        },
        analysis={"object_intelligence": {}},
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    assert any("source DDL" in warning and "GetTotal" in warning for warning in warnings)


def test_assemble_context_links_ai_analysis_by_name(ddl_index):
    analysis = {
        "object_intelligence": {
            "tables": [{"object_name": "Orders", "notes": "x"}],
        }
    }
    plan, _, _ = assemble_context(
        asis=_asis(),
        incompatibilities={"incompatibilities": []},
        analysis=analysis,
        remediation_kb={},
        ddl_index=ddl_index,
        file_name="script.sql",
    )
    table = next(o for o in plan if o["type"] == "TABLE")
    assert table["aiAnalysis"]["notes"] == "x"
