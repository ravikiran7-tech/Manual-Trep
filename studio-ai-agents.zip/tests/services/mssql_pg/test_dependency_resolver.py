from app.services.mssql_pg.dependency_resolver import resolve_dependencies, rewrite_exec_to_call


def _obj(**overrides):
    base = {
        "type": "PROCEDURE",
        "schema": "dbo",
        "name": "P1",
        "convertedCode": "",
        "callerUpdatesNeeded": [],
        "requiresManualReview": False,
        "reviewGuidance": [],
        "confidenceScore": "HIGH",
        "changesApplied": [],
        "conversionSource": "AI",
    }
    base.update(overrides)
    return base


def test_rewrite_exec_to_call_simple():
    code = "BEGIN\nEXEC dbo.DoWork @Id = 1\nEND;"
    new_code, count = rewrite_exec_to_call(code, {"dbo.dowork"})
    assert count == 1
    assert "CALL dbo.dowork(Id => 1)" in new_code


def test_rewrite_exec_to_call_ignores_sp_executesql():
    code = "EXEC sp_executesql @sql"
    new_code, count = rewrite_exec_to_call(code, {"dbo.dowork"})
    assert count == 0
    assert new_code == code


def test_resolve_dependencies_applies_exec_to_call_across_plan():
    caller = _obj(name="Caller", convertedCode="CALL_PLACEHOLDER\nEXEC dbo.Worker\n")
    worker = _obj(name="Worker", convertedCode="CREATE OR REPLACE PROCEDURE dbo.worker() LANGUAGE plpgsql AS $$ BEGIN END; $$;")
    plan = [caller, worker]
    audit = resolve_dependencies(plan)
    assert audit["execToCallRewrites"] == 1
    assert "CALL dbo.worker" in caller["convertedCode"]


def test_resolve_dependencies_synonym_resolution_patches_callers():
    synonym = _obj(
        type="SYNONYM",
        name="SynCust",
        convertedCode="-- synonym",
        convertedName="dbo.customers",
        callerUpdatesNeeded=[{"reason": "SYNONYM_RESOLUTION", "callee": "dbo.SynCust", "target": "dbo.customers"}],
    )
    view = _obj(type="VIEW", name="V1", convertedCode="CREATE VIEW dbo.v1 AS SELECT * FROM dbo.SynCust;")
    plan = [synonym, view]
    audit = resolve_dependencies(plan)
    assert "dbo.customers" in view["convertedCode"]
    assert "SynCust" not in view["convertedCode"]
    assert any(a["reason"] == "SYNONYM_RESOLUTION" for a in audit["callerUpdates"])


def test_resolve_dependencies_udt_elimination_patches_callers():
    udt = _obj(
        type="USER_DEFINED_TYPE",
        name="MyType",
        convertedCode="CREATE DOMAIN dbo.mytype AS jsonb;",
        callerUpdatesNeeded=[{"reason": "UDT_ELIMINATION", "callee": "dbo.MyType", "replacement_type": "jsonb"}],
    )
    proc = _obj(name="UsesType", convertedCode="CREATE OR REPLACE PROCEDURE dbo.usestype(p1 dbo.MyType) LANGUAGE plpgsql AS $$ BEGIN END; $$;")
    plan = [udt, proc]
    resolve_dependencies(plan)
    assert "jsonb" in proc["convertedCode"]
    assert "MyType" not in proc["convertedCode"]


def test_resolve_dependencies_flags_signature_change_callers_for_manual_review():
    callee = _obj(
        name="Callee",
        convertedCode="CREATE OR REPLACE PROCEDURE dbo.callee(p1 int) LANGUAGE plpgsql AS $$ BEGIN END; $$;",
        callerUpdatesNeeded=[{"reason": "SIGNATURE_CHANGE", "callee": "dbo.Callee", "detail": "param added"}],
    )
    caller = _obj(name="Caller", convertedCode="CALL dbo.Callee(1);")
    plan = [callee, caller]
    audit = resolve_dependencies(plan)
    assert caller["requiresManualReview"] is True
    assert caller["confidenceScore"] == "LOW"
    assert any(a["action"] == "FLAGGED_FOR_REVIEW" for a in audit["callerUpdates"])


def test_resolve_dependencies_rewrites_structured_column_rename_and_flags_caller():
    table = _obj(
        type="TABLE",
        name="T",
        convertedCode="CREATE TABLE dbo.t(customer_id int);",
        callerUpdatesNeeded=[
            {"reason": "TABLE_COLUMN_RENAME", "callee": "dbo.T", "old_name": "CustomerId", "new_name": "customer_id"}
        ],
    )
    view = _obj(type="VIEW", name="V", convertedCode="CREATE VIEW dbo.v AS SELECT CustomerId FROM dbo.t;")
    audit = resolve_dependencies([table, view])
    assert "customer_id" in view["convertedCode"]
    assert "CustomerId" not in view["convertedCode"]
    assert view["requiresManualReview"] is True
    assert any(entry["action"] == "PATCHED" for entry in audit["callerUpdates"])


def test_resolve_dependencies_logs_instead_of_conversion_without_flagging():
    trigger = _obj(
        type="TRIGGER",
        name="Trg1",
        convertedCode="CREATE OR REPLACE FUNCTION dbo.trg1_fn() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END; $$;",
        callerUpdatesNeeded=[{"reason": "INSTEAD_OF_CONVERSION", "callee": "dbo.Trg1", "detail": "rewrote as AFTER trigger"}],
    )
    plan = [trigger]
    audit = resolve_dependencies(plan)
    assert any(a["reason"] == "INSTEAD_OF_CONVERSION" and a["action"] == "LOGGED_ONLY" for a in audit["callerUpdates"])
    assert trigger["requiresManualReview"] is False


def test_resolve_dependencies_pg081_guard_flags_function_emitted_for_procedure():
    proc = _obj(
        name="BadProc",
        conversionSource="AI",
        convertedCode="CREATE OR REPLACE FUNCTION dbo.badproc() RETURNS void LANGUAGE plpgsql AS $$ BEGIN END; $$;",
    )
    audit = resolve_dependencies([proc])
    assert proc["requiresManualReview"] is True
    assert any(a["reason"] == "PG-081" for a in audit["callerUpdates"])
