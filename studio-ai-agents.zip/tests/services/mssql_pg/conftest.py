"""Shared fixtures for MSSQL PG transformation tests."""

from __future__ import annotations

import json

import pytest


EXECUTION_ORDER = {
    "phase_1_schemas": [],
    "phase_2_sequences": [],
    "phase_3_user_defined_types": [],
    "phase_4_partition_functions": [],
    "phase_5_partition_schemes": [],
    "phase_6_tables": [],
    "phase_7_primary_keys": [],
    "phase_8_unique_constraints": [],
    "phase_9_foreign_keys": [],
    "phase_10_check_constraints": [],
    "phase_11_indexes": [],
    "phase_12_views": ["dbo.CustomerView"],
    "phase_13_functions": [],
    "phase_14_stored_procedures": ["dbo.Helper", "dbo.GetCustomer"],
    "phase_15_triggers": [],
    "phase_16_synonyms": [],
}

SAMPLE_DDL = """
CREATE SCHEMA Sales
GO

CREATE TABLE dbo.Customers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL
)
GO

CREATE VIEW dbo.CustomerView AS SELECT Id, Name FROM dbo.Customers
GO

CREATE PROCEDURE dbo.GetCustomer
    @Id INT
AS
BEGIN
    EXEC dbo.Helper @Id
    SELECT * FROM dbo.Customers WHERE Id = @Id
END
GO

CREATE PROCEDURE dbo.Helper
    @Id INT
AS
BEGIN
    SELECT @Id
END
GO

CREATE SYNONYM dbo.CustSyn FOR dbo.Customers
GO
"""


def _oracle_rules_catalog(rule_count: int = 116) -> dict:
    """Oracle-shaped rulesRemediation JSON used by both engines."""
    rules = []
    for i in range(1, rule_count + 1):
        rule_id = f"PG-{i:03d}"
        rules.append(
            {
                "ruleId": rule_id,
                "ruleName": f"rule {i}",
                "severity": "HIGH" if i == 1 else "LOW",
                "impact": "High" if i == 1 else "Low",
                "description": "use identity" if i == 1 else f"rule {i}",
                "remediations": [
                    {
                        "default": True,
                        "description": "use identity" if i == 1 else f"rule {i}",
                        "detailedDescription": "GENERATED ALWAYS AS IDENTITY" if i == 1 else f"steps {i}",
                    }
                ],
            }
        )
    return {"rules": rules}


def stage_compass_files(claude_dir, *, db_name="ResortsLiteDB"):
    """Write the five Oracle-aligned Compass artifacts under ``claude_dir``."""
    claude_dir.mkdir(parents=True, exist_ok=True)

    rules = claude_dir / "rules_remediation.json"
    rules.write_text(json.dumps(_oracle_rules_catalog()), encoding="utf-8")

    asis = claude_dir / "asis.json"
    asis.write_text(
        json.dumps(
            {
                "metadata": {"database_name": db_name, "database_id": "DB1"},
                "statistics": {"total_objects": 6},
                "database_objects": {
                    "schemas": [{"name": "Sales", "schema": "dbo"}],
                    "tables": [{"name": "Customers", "schema": "dbo"}],
                    "views": [{"name": "CustomerView", "schema": "dbo"}],
                    "stored_procedures": [
                        {"name": "GetCustomer", "schema": "dbo"},
                        {"name": "Helper", "schema": "dbo"},
                    ],
                    "synonyms": [{"name": "CustSyn", "schema": "dbo", "referenced_object": "dbo.Customers"}],
                },
            }
        ),
        encoding="utf-8",
    )

    incompat = claude_dir / "incompat.json"
    incompat.write_text(
        json.dumps(
            {
                "metadata": {"database_name": db_name},
                "incompatibilities": [
                    {"object_name": "Customers", "schema": "dbo", "rule_id": "PG-001", "compatibility": "SC", "description": "IDENTITY"},
                ],
            }
        ),
        encoding="utf-8",
    )

    analysis = claude_dir / "analysis.json"
    analysis.write_text(
        json.dumps(
            {
                "execution_order": EXECUTION_ORDER,
                "object_intelligence": {
                    "tables": [{"object_name": "Customers", "notes": "identity table"}],
                    "views": [{"object_name": "CustomerView", "calls": ["dbo.CustSyn"]}],
                    "stored_procedures": [
                        {"object_name": "GetCustomer", "calls": ["dbo.Helper"]},
                        {"object_name": "Helper"},
                    ],
                    "synonyms": [{"object_name": "CustSyn"}],
                },
            }
        ),
        encoding="utf-8",
    )

    ddl = claude_dir / "script.sql"
    ddl.write_text(SAMPLE_DDL, encoding="utf-8")

    return {
        "ddlExport": "script.sql",
        "asisSchema": "asis.json",
        "incompatibilityResults": "incompat.json",
        "rulesRemediation": "rules_remediation.json",
        "schemaAnalysis": "analysis.json",
    }


@pytest.fixture
def fake_model_caller():
    """Return an async caller that emits a well-formed conversion for any object type."""

    async def _caller(prompt: str):
        obj_type = "TABLE"
        schema = "dbo"
        name = "object"
        if '"objectType":' in prompt:
            for token in ("SCHEMA", "SEQUENCE", "TABLE", "VIEW", "FUNCTION", "PROCEDURE", "TRIGGER", "INDEX", "SYNONYM"):
                if f'"objectType": "{token}"' in prompt:
                    obj_type = token
                    break
        for line in prompt.splitlines():
            if '"schema":' in line:
                schema = line.split(":", 1)[1].strip().strip('",')
            if '"name":' in line and "objectType" not in line:
                name = line.split(":", 1)[1].strip().strip('",')
        qualified = f"{schema}.{name.lower()}"
        code_by_type = {
            "SCHEMA": f"CREATE SCHEMA IF NOT EXISTS {name.lower()};",
            "TABLE": f"CREATE TABLE {qualified} (id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL);",
            "VIEW": f"CREATE OR REPLACE VIEW {qualified} AS SELECT id, name FROM dbo.customers;",
            "PROCEDURE": f"CREATE OR REPLACE PROCEDURE {qualified}(p_id integer)\nLANGUAGE plpgsql\nAS $$\nBEGIN\n    CALL dbo.helper(p_id);\nEND;\n$$;",
            "FUNCTION": f"CREATE OR REPLACE FUNCTION {qualified}() RETURNS integer LANGUAGE sql AS $$ SELECT 1; $$;",
            "TRIGGER": f"CREATE OR REPLACE FUNCTION {qualified}_fn() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END; $$;",
            "INDEX": f"CREATE INDEX {name.lower()} ON dbo.customers (name);",
            "SYNONYM": f"-- SYNONYM {qualified} resolved to dbo.customers",
        }
        code = code_by_type.get(obj_type, f"-- converted {obj_type} {qualified}")
        return json.dumps(
            {
                "conversionStatus": "SUCCESS",
                "convertedCode": code,
                "convertedName": None,
                "newSignature": f"{qualified}(p_id integer)" if obj_type == "PROCEDURE" else None,
                "confidenceScore": "HIGH",
                "changesApplied": ["type mapping"],
                "comments": [],
                "requiresManualReview": False,
                "reviewGuidance": [],
                "callerUpdatesNeeded": [],
            }
        )

    return _caller
