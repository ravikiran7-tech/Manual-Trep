from app.services.mssql_pg.execution_order import apply_execution_order, order_phase


def _obj(obj_type, name, schema="dbo", code="", **extra):
    entry = {
        "type": obj_type,
        "schema": schema,
        "name": name,
        "convertedCode": code,
        "changesApplied": [],
        "requiresManualReview": False,
        "reviewGuidance": [],
        "confidenceScore": "HIGH",
    }
    entry.update(extra)
    return entry


def test_order_phase_is_alphabetical_when_no_edges():
    objects = [_obj("INDEX", "Z"), _obj("INDEX", "A"), _obj("INDEX", "M")]
    ordered, cycles = order_phase(objects)
    assert [o["name"] for o in ordered] == ["A", "M", "Z"]
    assert cycles == []


def test_order_phase_respects_same_type_ddl_references():
    objects = [
        _obj("VIEW", "V2", code="CREATE VIEW dbo.v2 AS SELECT * FROM dbo.v1"),
        _obj("VIEW", "V1", code="CREATE VIEW dbo.v1 AS SELECT 1"),
    ]
    ordered, cycles = order_phase(objects)
    assert [o["name"] for o in ordered] == ["V1", "V2"]
    assert cycles == []


def test_order_phase_breaks_cycle_alphabetically():
    objects = [
        _obj("VIEW", "B", code="CREATE VIEW dbo.b AS SELECT * FROM dbo.a"),
        _obj("VIEW", "A", code="CREATE VIEW dbo.a AS SELECT * FROM dbo.b"),
    ]
    ordered, cycles = order_phase(objects)
    assert {o["name"] for o in ordered} == {"A", "B"}
    assert cycles
    assert "dbo.A" in cycles[0] or "dbo.a" in cycles[0] or "dbo.B" in cycles[0]


def test_apply_execution_order_assigns_phase_and_output_file():
    plan = [
        _obj("TABLE", "T1", code="CREATE TABLE dbo.t1(id int);"),
        _obj("VIEW", "V1", code="CREATE VIEW dbo.v1 AS SELECT 1;"),
        _obj("PROCEDURE", "P1", code="CREATE OR REPLACE PROCEDURE dbo.p1() LANGUAGE plpgsql AS $$ BEGIN END; $$;"),
    ]
    result = apply_execution_order(plan)
    assert result["totalObjects"] == 3
    by_type = {o["type"]: o for o in plan}
    assert by_type["TABLE"]["executionPhase"] == 4
    assert by_type["TABLE"]["outputFile"] == "create_tables.sql"
    assert by_type["VIEW"]["executionPhase"] == 10
    assert by_type["VIEW"]["outputFile"] == "create_views.sql"
    assert by_type["PROCEDURE"]["executionPhase"] == 13
    assert all(o["phaseOrder"] is not None for o in plan)


def test_apply_execution_order_marks_fk_cycle_deferrable():
    plan = [
        _obj(
            "FOREIGN_KEY",
            "FK_A_B",
            code="ALTER TABLE dbo.a ADD CONSTRAINT fk_a_b FOREIGN KEY (b_id) REFERENCES dbo.b(id);",
            owningTable="dbo.a",
        ),
        _obj(
            "FOREIGN_KEY",
            "FK_B_A",
            code="ALTER TABLE dbo.b ADD CONSTRAINT fk_b_a FOREIGN KEY (a_id) REFERENCES dbo.a(id);",
            owningTable="dbo.b",
        ),
    ]
    result = apply_execution_order(plan)
    assert any(a["type"] == "FK_CYCLE" for a in result["cyclesHandled"])
    assert all("DEFERRABLE INITIALLY DEFERRED" in o["convertedCode"] for o in plan)


def test_apply_execution_order_flags_view_and_procedure_phase_violations():
    plan = [
        _obj("VIEW", "BadView", code="CREATE VIEW dbo.badview AS SELECT * FROM dbo.proc1"),
        _obj("PROCEDURE", "Proc1", code="BEGIN CALL dbo.trg1(); END"),
        _obj("TRIGGER", "Trg1", code="CREATE TRIGGER dbo.trg1 ON dbo.t AFTER INSERT AS BEGIN SELECT 1 END", owningTable="dbo.missing"),
    ]
    result = apply_execution_order(plan)
    errors = result["validationErrors"]
    assert any("after phase 10" in error for error in errors)
    assert any("after phase 12" in error for error in errors)


def test_apply_execution_order_adds_forward_declaration_for_procedure_cycle():
    plan = [
        _obj(
            "PROCEDURE",
            "A",
            code="CREATE OR REPLACE PROCEDURE dbo.a() LANGUAGE plpgsql AS $$ BEGIN CALL dbo.b(); END; $$;",
        ),
        _obj(
            "PROCEDURE",
            "B",
            code="CREATE OR REPLACE PROCEDURE dbo.b() LANGUAGE plpgsql AS $$ BEGIN CALL dbo.a(); END; $$;",
        ),
    ]
    result = apply_execution_order(plan)
    assert any(a["type"] == "PROCEDURE_CYCLE" for a in result["cyclesHandled"])
    assert all(o["requiresManualReview"] for o in plan)
    first = next(o for o in plan if o["name"] == "A")
    assert "forward declaration" not in (first.get("convertedCode") or "")
