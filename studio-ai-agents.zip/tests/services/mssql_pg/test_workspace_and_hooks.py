import json

from app.services.mssql_pg.hooks import _api_job_id, append_log
from app.services.mssql_pg.progress import default_progress, save_progress
from app.services.mssql_pg.workspace import (
    WORKSPACE_SUBDIR,
    _resolve_input_file_path,
    ensure_job_dirs,
    events_path,
    job_root,
    logs_path,
    reset_job_conversion_state,
    resolve_folder_key,
    validate_under_claude_dir,
)


def test_job_root_uses_schema_modernization_package(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    root = job_root("SalesDB")
    assert root == tmp_path / "schema-modernization" / "SalesDB"
    assert WORKSPACE_SUBDIR == "schema-modernization"


def test_absolute_compass_path_under_schema_modernization_is_accepted(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    claude = ensure_job_dirs("DB0150") / "_claude"
    sql = claude / "test_schema_simple.sql"
    sql.write_text("CREATE TABLE dbo.t (id int);", encoding="utf-8")
    resolved = _resolve_input_file_path("DB0150", str(sql.resolve()))
    assert resolved == sql.resolve()


def test_validate_under_claude_dir_rejects_outside(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    ensure_job_dirs("SalesDB")
    outside = job_root("SalesDB") / "state" / "x.json"
    outside.write_text("{}", encoding="utf-8")
    try:
        validate_under_claude_dir("SalesDB", outside)
        assert False, "should have raised"
    except ValueError as exc:
        assert "_claude" in str(exc)


def test_resolve_folder_key_maps_job_id_to_dbname(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    root = ensure_job_dirs("SalesDB")
    (root / "job_config.json").write_text(json.dumps({"jobId": "job-99", "dbName": "SalesDB"}), encoding="utf-8")
    assert resolve_folder_key("job-99") == "SalesDB"
    assert resolve_folder_key("SalesDB") == "SalesDB"
    assert resolve_folder_key("missing") is None


def test_hooks_events_carry_api_job_id(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    root = ensure_job_dirs("SalesDB")
    (root / "job_config.json").write_text(json.dumps({"jobId": "api-job", "dbName": "SalesDB"}), encoding="utf-8")
    assert _api_job_id("SalesDB") == "api-job"

    progress = default_progress("api-job")
    save_progress("SalesDB", progress)
    events = (root / "stream" / "events.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert events
    payload = json.loads(events[-1])
    assert payload["jobId"] == "api-job"
    assert payload["type"] == "progress_updated"
    assert payload["objectsTotal"] == 0
    assert payload["objectsConverted"] == 0
    assert payload["sessionsCompleted"] == 0
    assert "startedAt" not in payload

    logs = (root / "stream" / "logs.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert json.loads(logs[-1])["icon"] == "info"

    completed = dict(progress)
    completed["status"] = "completed"
    completed["phase"] = "Completed"
    completed["message"] = "DB Modernization Completed"
    completed["progressPercent"] = 100
    completed["startedAt"] = "2026-10-30T10:00:00+00:00"
    completed["completedAt"] = "2026-10-30T10:01:05+00:00"
    from app.services.mssql_pg.hooks import progress_updated_event

    finished = progress_updated_event("SalesDB", completed)
    assert finished["status"] == "completed"
    assert finished["message"] == "DB Modernization Completed"
    assert finished["duration"]
    assert finished["durationSeconds"] is not None

    append_log("SalesDB", "Validating Inputs", "hello")
    logs = (root / "stream" / "logs.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert json.loads(logs[-1])["jobId"] == "api-job"
    assert json.loads(logs[-1])["message"] == "hello"


def test_reset_job_conversion_state_clears_stale_streams(tmp_path, monkeypatch):
    monkeypatch.setattr("app.services.mssql_pg.workspace.get_settings", lambda: type("S", (), {"claude_workspace": str(tmp_path)})())
    ensure_job_dirs("SalesDB")
    events = events_path("SalesDB")
    logs = logs_path("SalesDB")
    events.write_text('{"jobId":"old"}\n', encoding="utf-8")
    logs.write_text('{"jobId":"old"}\n', encoding="utf-8")
    reset_job_conversion_state("SalesDB")
    assert not events.exists()
    assert not logs.exists()
