from app.services.mssql_pg.confidence import highest_priority, lowest, structural_floor


def test_lowest_picks_riskiest():
    assert lowest("HIGH", "MEDIUM") == "MEDIUM"
    assert lowest("LOW", "MANUAL") == "MANUAL"
    assert lowest("HIGH", None) == "HIGH"
    assert lowest() == "HIGH"


def test_structural_floor_clr_and_encrypted_are_manual():
    clr_obj = {"type": "FUNCTION", "structuralMetadata": {"is_clr": True}, "sourceCode": {}}
    assert structural_floor(clr_obj) == "MANUAL"
    encrypted_obj = {"type": "VIEW", "structuralMetadata": {"is_encrypted": True}, "sourceCode": {}}
    assert structural_floor(encrypted_obj) == "MANUAL"


def test_structural_floor_plain_table_is_high():
    obj = {
        "type": "TABLE",
        "structuralMetadata": {"columns": [{"name": "id"}]},
        "sourceCode": {"ddl": "CREATE TABLE t (id int)"},
        "aiAnalysis": {"x": 1},
    }
    assert structural_floor(obj) == "HIGH"


def test_structural_floor_identity_table_is_medium():
    obj = {
        "type": "TABLE",
        "structuralMetadata": {"columns": [{"name": "id", "is_identity": True}]},
        "sourceCode": {"ddl": "CREATE TABLE t (id int IDENTITY(1,1))"},
        "aiAnalysis": {"x": 1},
    }
    assert structural_floor(obj) == "MEDIUM"


def test_structural_floor_computed_non_persisted_column_is_low():
    obj = {
        "type": "TABLE",
        "structuralMetadata": {"columns": [{"name": "calc", "is_computed": True, "is_persisted": False}]},
        "sourceCode": {},
    }
    assert structural_floor(obj) == "LOW"


def test_structural_floor_columnstore_index_is_manual():
    obj = {"type": "INDEX", "structuralMetadata": {"index_type": "COLUMNSTORE"}, "sourceCode": {}}
    assert structural_floor(obj) == "MANUAL"


def test_structural_floor_cross_server_synonym_is_manual():
    obj = {"type": "SYNONYM", "structuralMetadata": {"referenced_object": "srv.db.sch.tbl"}, "sourceCode": {}}
    assert structural_floor(obj) == "MANUAL"


def test_structural_floor_simple_synonym_is_high():
    obj = {"type": "SYNONYM", "structuralMetadata": {"referenced_object": "dbo.tbl"}, "sourceCode": {}, "aiAnalysis": {"x": 1}}
    assert structural_floor(obj) == "HIGH"


def test_structural_floor_missing_ai_analysis_downgrades_to_low():
    obj = {"type": "TABLE", "structuralMetadata": {"columns": []}, "sourceCode": {}, "aiAnalysis": None}
    assert structural_floor(obj) == "LOW"


def test_structural_floor_unhandled_ns_incompatibility_downgrades():
    obj = {
        "type": "TABLE",
        "structuralMetadata": {"columns": []},
        "sourceCode": {},
        "aiAnalysis": {"x": 1},
        "incompatibilities": [{"remediation_status": "UNHANDLED", "compatibility": "NS"}],
    }
    assert structural_floor(obj) == "LOW"


def test_structural_floor_procedure_with_linked_server_is_manual():
    obj = {
        "type": "PROCEDURE",
        "structuralMetadata": {},
        "sourceCode": {"ddl": "SELECT * FROM OPENQUERY(srv, 'select 1')"},
    }
    assert structural_floor(obj) == "MANUAL"


def test_highest_priority_picks_most_severe():
    assert highest_priority(["LOW", "CRITICAL", "MEDIUM"]) == "CRITICAL"
    assert highest_priority([]) == "MEDIUM"
