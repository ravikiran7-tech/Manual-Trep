"""Tests for the Oracle-aligned Compass input validation gate (ticket AC1)."""

import json

import pytest

from app.services.mssql_pg.input_validator import (
    InputValidationError,
    database_id,
    filter_incompatibilities_by_scope,
    validate_inputs,
)


def _write_json(path, payload):
    path.write_text(json.dumps(payload), encoding="utf-8")


def _oracle_rules(rule_ids=None, *, impact_by_id=None):
    rule_ids = rule_ids or ["PG-001"]
    impact_by_id = impact_by_id or {}
    rules = []
    for rid in rule_ids:
        impact = impact_by_id.get(rid, "Low")
        rules.append(
            {
                "ruleId": rid,
                "ruleName": rid,
                "severity": "HIGH" if str(impact).lower() == "high" else "LOW",
                "impact": impact,
                "description": f"desc {rid}",
                "remediations": [
                    {
                        "default": True,
                        "description": f"note {rid}",
                        "detailedDescription": f"steps {rid}",
                    }
                ],
            }
        )
    return {"rules": rules}


EXECUTION_ORDER = {
    "phase_1_schemas": [],
    "phase_2_sequences": [],
    "phase_3_user_defined_types": [],
    "phase_4_partition_functions": [],
    "phase_5_partition_schemes": [],
    "phase_6_tables": [],
    "phase_7_primary_keys": [],
    "phase_8_unique_constraints": [],
    "phase_9_foreign_keys": [],
    "phase_10_check_constraints": [],
    "phase_11_indexes": [],
    "phase_12_views": [],
    "phase_13_functions": [],
    "phase_14_stored_procedures": [],
    "phase_15_triggers": [],
    "phase_16_synonyms": [],
}


@pytest.fixture
def valid_inputs(tmp_path):
    rules = tmp_path / "rules_remediation.json"
    _write_json(rules, _oracle_rules([f"PG-{i:03d}" for i in range(1, 117)]))

    asis = tmp_path / "asis.json"
    _write_json(
        asis,
        {
            "metadata": {"database_name": "SalesDB"},
            "statistics": {"total_objects": 2},
            "database_objects": {"tables": [{"name": "Orders", "schema": "dbo"}]},
        },
    )

    incompat = tmp_path / "incompat.json"
    _write_json(incompat, {"metadata": {"database_name": "SalesDB"}, "incompatibilities": []})

    analysis = tmp_path / "analysis.json"
    _write_json(analysis, {"execution_order": EXECUTION_ORDER, "object_intelligence": {}})

    ddl = tmp_path / "script.sql"
    ddl.write_text("CREATE TABLE dbo.Orders (Id INT);", encoding="utf-8")

    return {
        "rules_remediation": rules,
        "asis_schema": asis,
        "incompatibility_results": incompat,
        "schema_analysis": analysis,
        "ddl_export": ddl,
    }


def test_validate_inputs_happy_path(valid_inputs):
    result = validate_inputs(**valid_inputs)
    assert result["database_name"] == "SalesDB"
    assert len(result["rules"]) == 116
    assert "PG-001" in result["remediation_kb"]
    assert result["remediation_kb"]["PG-001"]["note_template"] == "note PG-001"
    assert result["remediation_kb"]["PG-001"]["conversion_steps"] == "steps PG-001"
    assert result["warnings"] == []


def test_validate_inputs_warns_on_unexpected_rule_count(valid_inputs):
    _write_json(valid_inputs["rules_remediation"], _oracle_rules(["PG-001"] * 10))
    result = validate_inputs(**valid_inputs)
    assert any("expected 116" in w for w in result["warnings"])


def test_validate_inputs_rejects_missing_file(valid_inputs, tmp_path):
    valid_inputs["ddl_export"] = tmp_path / "missing.sql"
    with pytest.raises(InputValidationError, match="missing or empty"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_rejects_empty_ddl(valid_inputs):
    valid_inputs["ddl_export"].write_text("", encoding="utf-8")
    with pytest.raises(InputValidationError, match="DDL script"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_rejects_db_name_mismatch(valid_inputs):
    _write_json(
        valid_inputs["incompatibility_results"],
        {"metadata": {"database_name": "OtherDB"}, "incompatibilities": []},
    )
    with pytest.raises(InputValidationError, match="does not match"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_warns_when_execution_order_keys_do_not_match(valid_inputs):
    _write_json(valid_inputs["schema_analysis"], {"execution_order": {"phase_1_schemas": []}})
    result = validate_inputs(**valid_inputs)
    assert any("execution_order" in w for w in result["warnings"])


def test_validate_inputs_rejects_zero_total_objects(valid_inputs):
    _write_json(
        valid_inputs["asis_schema"],
        {
            "metadata": {"database_name": "SalesDB"},
            "statistics": {"total_objects": 0},
            "database_objects": {},
        },
    )
    with pytest.raises(InputValidationError, match="total_objects"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_accepts_null_rules_when_there_are_no_violations(valid_inputs):
    _write_json(valid_inputs["rules_remediation"], {"rules": None})
    result = validate_inputs(**valid_inputs)
    assert result["rules"] == []
    assert result["remediation_kb"] == {}
    assert result["warnings"] == []


def test_validate_inputs_accepts_empty_rules_array(valid_inputs):
    _write_json(valid_inputs["rules_remediation"], {"rules": []})
    result = validate_inputs(**valid_inputs)
    assert result["rules"] == []
    assert result["remediation_kb"] == {}


def test_validate_inputs_rejects_rule_with_no_remediations(valid_inputs):
    _write_json(
        valid_inputs["rules_remediation"],
        {"rules": [{"ruleId": "PG-001", "ruleName": "identity", "severity": "HIGH", "remediations": []}]},
    )
    with pytest.raises(InputValidationError, match="Rule has no remediations"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_rejects_rule_with_null_remediations(valid_inputs):
    _write_json(
        valid_inputs["rules_remediation"],
        {"rules": [{"ruleId": "PG-001", "ruleName": "identity", "remediations": None}]},
    )
    with pytest.raises(InputValidationError, match="Rule has no remediations"):
        validate_inputs(**valid_inputs)


def test_validate_inputs_rejects_rules_remediation_without_rule_ids(valid_inputs):
    _write_json(valid_inputs["rules_remediation"], {"rules": [{"description": "no id"}]})
    with pytest.raises(InputValidationError, match="ruleId"):
        validate_inputs(**valid_inputs)


def test_database_id_prefers_scan_metadata_db_id():
    payload = {"scan_metadata": {"database_id": "DB-0099"}, "metadata": {"database_name": "Sales"}}
    assert database_id(payload, "fallback") == "DB-0099"


def test_database_id_falls_back_to_name():
    payload = {"metadata": {"database_name": "Sales DB!"}}
    assert database_id(payload, "fallback") == "Sales_DB_"


def test_database_id_ignores_placeholder_scan_id():
    """Compass sample/TestDB must not win over the real database name in metadata."""
    payload = {"scan_metadata": {"databaseId": "TestDB"}, "metadata": {"database_name": "DbMSSQL1"}}
    assert database_id(payload, "fallback") == "DbMSSQL1"


def test_database_name_reads_nested_source_database(valid_inputs):
    asis = json.loads(valid_inputs["asis_schema"].read_text(encoding="utf-8"))
    asis.pop("metadata")
    asis["scan_metadata"] = {"source_database": {"database_name": "SalesDB", "vendor": "MSSQL"}}
    valid_inputs["asis_schema"].write_text(json.dumps(asis), encoding="utf-8")
    result = validate_inputs(**valid_inputs)
    assert result["database_name"] == "SalesDB"


def test_rules_remediation_accepts_legacy_dict_keyed_by_rule_id(valid_inputs):
    valid_inputs["rules_remediation"].write_text(
        json.dumps({"remediations": {"PG-004": {"ruleId": "PG-004", "conversionSteps": ["rewrite"]}}}),
        encoding="utf-8",
    )
    result = validate_inputs(**valid_inputs)
    assert result["remediation_kb"]["PG-004"]["conversion_steps"] == ["rewrite"]


def test_filter_custom_scope_keeps_selected_rules():
    incompat = {
        "incompatibilities": [
            {"object_name": "Orders", "rule_id": "PG-001"},
            {"object_name": "Orders", "rule_id": "PG-002"},
        ]
    }
    filtered = filter_incompatibilities_by_scope(
        incompat,
        rule_scope="custom",
        selected_rules=["PG-002"],
        remediation_kb={},
    )
    assert [row["rule_id"] for row in filtered["incompatibilities"]] == ["PG-002"]


def test_filter_high_impact_keeps_high_rules_only():
    incompat = {
        "incompatibilities": [
            {"object_name": "Orders", "rule_id": "PG-001"},
            {"object_name": "Orders", "rule_id": "PG-002"},
        ]
    }
    kb = {
        "PG-001": {"severity": "HIGH", "impact": "High"},
        "PG-002": {"severity": "LOW", "impact": "Low"},
    }
    filtered = filter_incompatibilities_by_scope(
        incompat,
        rule_scope="high_impact",
        selected_rules=[],
        remediation_kb=kb,
    )
    assert [row["rule_id"] for row in filtered["incompatibilities"]] == ["PG-001"]


def test_validate_inputs_applies_custom_rule_scope(valid_inputs):
    _write_json(
        valid_inputs["incompatibility_results"],
        {
            "metadata": {"database_name": "SalesDB"},
            "incompatibilities": [
                {"object_name": "Orders", "schema": "dbo", "rule_id": "PG-001"},
                {"object_name": "Orders", "schema": "dbo", "rule_id": "PG-002"},
            ],
        },
    )
    result = validate_inputs(**valid_inputs, rule_scope="custom", selected_rules=["PG-001"])
    rows = result["incompatibilities"]["incompatibilities"]
    assert [row["rule_id"] for row in rows] == ["PG-001"]
