import asyncio
import json

import pytest

from app.services.mssql_pg.converter import convert_object, convert_plan


def _success_response(code="CREATE TABLE dbo.t1(id int);"):
    return json.dumps({"conversionStatus": "SUCCESS", "convertedCode": code, "confidenceScore": "HIGH"})


def test_convert_object_uses_deterministic_stub_without_caller():
    obj = {
        "type": "FUNCTION",
        "schema": "dbo",
        "name": "ClrFunc",
        "isClr": True,
        "isEncrypted": False,
        "structuralMetadata": {"parameters": [{"name": "x", "data_type": "int"}], "return_type": "int"},
    }

    async def _caller(prompt):
        raise AssertionError("should not call the model for CLR objects")

    result = asyncio.run(convert_object(obj, _caller, timeout_seconds=5, timeout_retries=0))
    assert result["conversionSource"] == "DETERMINISTIC"
    assert result["confidenceScore"] == "MANUAL"


def test_convert_object_success_on_first_call():
    obj = {"type": "TABLE", "schema": "dbo", "name": "T1", "isClr": False, "isEncrypted": False, "structuralMetadata": {}, "confidenceFloor": "HIGH", "sourceCode": {}, "incompatibilities": []}

    async def _caller(prompt):
        return _success_response()

    result = asyncio.run(convert_object(obj, _caller, timeout_seconds=5, timeout_retries=0))
    assert result["conversionStatus"] == "SUCCESS"
    assert result["conversionSource"] == "AI"
    assert result["status"] == "converted"


def test_convert_object_retries_after_timeout_then_succeeds():
    attempts = {"count": 0}

    async def _caller(prompt):
        attempts["count"] += 1
        if attempts["count"] == 1:
            await asyncio.sleep(10)
        return _success_response()

    obj = {"type": "TABLE", "schema": "dbo", "name": "T1", "isClr": False, "isEncrypted": False, "structuralMetadata": {}, "confidenceFloor": "HIGH", "sourceCode": {}, "incompatibilities": []}
    result = asyncio.run(convert_object(obj, _caller, timeout_seconds=0.05, timeout_retries=1))
    assert result["conversionStatus"] == "SUCCESS"
    assert attempts["count"] == 2


def test_convert_object_repairs_invalid_response():
    attempts = {"count": 0}

    async def _caller(prompt):
        attempts["count"] += 1
        if attempts["count"] == 1:
            return "not valid json"
        return _success_response()

    obj = {"type": "TABLE", "schema": "dbo", "name": "T1", "isClr": False, "isEncrypted": False, "structuralMetadata": {}, "confidenceFloor": "HIGH", "sourceCode": {}, "incompatibilities": []}
    result = asyncio.run(convert_object(obj, _caller, timeout_seconds=5, timeout_retries=0))
    assert result["conversionStatus"] == "SUCCESS"
    assert result["conversionSource"] == "AI_REPAIRED"


def test_convert_object_falls_back_to_unconvertible_after_exhausting_retries():
    async def _caller(prompt):
        return "garbage, not json, still garbage"

    obj = {"type": "TABLE", "schema": "dbo", "name": "T1", "isClr": False, "isEncrypted": False, "structuralMetadata": {}, "confidenceFloor": "HIGH", "sourceCode": {}, "incompatibilities": []}
    result = asyncio.run(convert_object(obj, _caller, timeout_seconds=5, timeout_retries=0))
    assert result["conversionStatus"] == "UNCONVERTIBLE"
    assert result["status"] == "failed"
    assert result["requiresManualReview"] is True


def test_convert_plan_retries_failed_objects_through_the_model():
    failed = {
        "type": "PRIMARY_KEY",
        "schema": "dbo",
        "name": "PK_Resorts",
        "status": "failed",
        "conversionStatus": "UNCONVERTIBLE",
        "owningTable": "dbo.Resorts",
        "isClr": False,
        "isEncrypted": False,
        "sourceCode": {"ddl": "CREATE TABLE [dbo].[Resorts] (id int);", "origin": "OWNING_TABLE_DDL"},
        "structuralMetadata": {
            "constraint_name": "PK_Resorts",
            "owning_table": "dbo.Resorts",
            "columns": ["ResortID"],
        },
        "confidenceFloor": "HIGH",
        "incompatibilities": [],
    }

    async def _caller(prompt):
        return _success_response("ALTER TABLE dbo.resorts ADD PRIMARY KEY (resortid);")

    result = asyncio.run(convert_plan([failed], caller_factory=lambda: _caller, concurrency=1, timeout_seconds=5, timeout_retries=0))
    assert result[0]["conversionStatus"] == "SUCCESS"
    assert result[0]["conversionSource"] == "AI"


def test_convert_plan_skips_already_converted_objects():
    done_obj = {"type": "TABLE", "schema": "dbo", "name": "Done", "status": "converted", "conversionStatus": "SUCCESS"}
    pending_obj = {
        "type": "TABLE",
        "schema": "dbo",
        "name": "Pending",
        "status": "pending",
        "isClr": False,
        "isEncrypted": False,
        "structuralMetadata": {},
        "confidenceFloor": "HIGH",
        "sourceCode": {},
        "incompatibilities": [],
    }
    plan = [done_obj, pending_obj]

    called = {"count": 0}

    async def _caller(prompt):
        called["count"] += 1
        return _success_response()

    result = asyncio.run(convert_plan(plan, caller_factory=lambda: _caller, concurrency=2, timeout_seconds=5, timeout_retries=0))
    assert called["count"] == 1
    assert result[1]["conversionStatus"] == "SUCCESS"
    assert result[0] is done_obj


def test_convert_plan_respects_concurrency_limit():
    in_flight = {"current": 0, "max": 0}

    async def _caller(prompt):
        in_flight["current"] += 1
        in_flight["max"] = max(in_flight["max"], in_flight["current"])
        await asyncio.sleep(0.05)
        in_flight["current"] -= 1
        return _success_response()

    plan = [
        {
            "type": "TABLE",
            "schema": "dbo",
            "name": f"T{i}",
            "status": "pending",
            "isClr": False,
            "isEncrypted": False,
            "structuralMetadata": {},
            "confidenceFloor": "HIGH",
            "sourceCode": {},
            "incompatibilities": [],
        }
        for i in range(6)
    ]
    asyncio.run(convert_plan(plan, caller_factory=lambda: _caller, concurrency=2, timeout_seconds=5, timeout_retries=0))
    assert in_flight["max"] <= 2
