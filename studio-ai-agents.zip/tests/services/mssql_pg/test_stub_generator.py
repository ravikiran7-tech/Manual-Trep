from app.services.mssql_pg.stub_generator import deterministic_result, map_type, pg_qualified


def test_map_type_common_sql_server_types():
    assert map_type("INT") == "integer"
    assert map_type("NVARCHAR(100)") == "varchar(100)"
    assert map_type("NVARCHAR(MAX)") == "text"
    assert map_type("DATETIME2") == "timestamp"
    assert map_type("UNIQUEIDENTIFIER") == "uuid"
    assert map_type(None) == "text"


def test_pg_qualified_strips_brackets_and_lowercases():
    assert pg_qualified("[dbo]", "[MyTable]") == "dbo.mytable"


def test_deterministic_result_encrypted_object_is_unconvertible():
    obj = {"type": "VIEW", "schema": "dbo", "name": "V1", "isEncrypted": True, "isClr": False, "structuralMetadata": {}}
    result = deterministic_result(obj)
    assert result["conversionStatus"] == "UNCONVERTIBLE"
    assert result["confidenceScore"] == "MANUAL"


def test_deterministic_result_clr_function_emits_stub():
    obj = {
        "type": "FUNCTION",
        "schema": "dbo",
        "name": "ClrFunc",
        "isClr": True,
        "isEncrypted": False,
        "structuralMetadata": {"parameters": [{"name": "x", "data_type": "int"}], "return_type": "int"},
    }
    result = deterministic_result(obj)
    assert "RAISE EXCEPTION" in result["convertedCode"]
    assert result["confidenceScore"] == "MANUAL"
    assert result["callerUpdatesNeeded"][0]["reason"] == "CLR_REPLACEMENT"


def test_deterministic_result_schema_goes_to_the_model():
    obj = {"type": "SCHEMA", "schema": "dbo", "name": "Sales", "isClr": False, "isEncrypted": False, "structuralMetadata": {}}
    assert deterministic_result(obj) is None


def test_deterministic_result_columnstore_index_goes_to_the_model():
    obj = {
        "type": "INDEX",
        "schema": "dbo",
        "name": "IX1",
        "isClr": False,
        "isEncrypted": False,
        "structuralMetadata": {"index_type": "COLUMNSTORE"},
        "sourceCode": {},
    }
    assert deterministic_result(obj) is None


def test_deterministic_result_synonym_goes_to_the_model():
    obj = {
        "type": "SYNONYM",
        "schema": "dbo",
        "name": "Syn1",
        "isClr": False,
        "isEncrypted": False,
        "structuralMetadata": {"referenced_object": "dbo.tbl", "referenced_schema": "dbo", "referenced_name": "tbl"},
    }
    assert deterministic_result(obj) is None


def test_deterministic_result_returns_none_for_regular_table():
    obj = {"type": "TABLE", "schema": "dbo", "name": "T1", "isClr": False, "isEncrypted": False, "structuralMetadata": {}}
    assert deterministic_result(obj) is None
