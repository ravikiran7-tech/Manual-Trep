"""Dependency plan assembly (catalog scope) — no fixture files required."""

import json

from app.services.oracle_pg.app_db_change.input_adapter import build_dependency_resolution_plan


def test_plan_skips_dependency_rows_whose_rule_is_not_in_kb(tmp_path):
    findings_path = tmp_path / "findings.json"
    findings_path.write_text(
        json.dumps(
            {
                "scan_results": {
                    "Results": [
                        {
                            "violationDetails": [
                                {
                                    "filename": "src/App.java",
                                    "violations": [
                                        {"ruleId": "in-scope", "beginLine": 1, "endLine": 1},
                                        {"ruleId": "out-of-scope", "beginLine": 2, "endLine": 2},
                                    ],
                                }
                            ]
                        }
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    catalog_path = tmp_path / "rules.json"
    catalog_path.write_text(
        json.dumps(
            {
                "rules": [
                    {
                        "ruleId": "in-scope",
                        "ruleName": "In scope",
                        "remediations": [{"default": True, "detailedDescription": "Fix it"}],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    plan = build_dependency_resolution_plan(
        findings_path=findings_path,
        catalog_path=catalog_path,
        app_id="A1",
        db_id="D1",
    )

    assert len(plan["violations"]) == 1
    assert plan["violations"][0]["ruleId"] == "in-scope"
    assert plan["violations"][0]["status"] == "pending"
    assert any("unselected ruleId=out-of-scope" in w for w in plan["assemblyWarnings"])
