"""Job 3's ``projectPath`` may be resolved instead of supplied.

When a caller does not already know the application's checkout location, it
may send ``tenantId``+``planId`` instead and let Job 3 derive it from the same
NFS convention Job 1/M-Upgrade's own output already uses:

    {nfs_base_path}/{tenantId}/{appId}/transformed-code/{planId}/studio-workspace/{componentName}

This mirrors studio-core's own ``TransformationCodeDownloadServiceImpl``
(and ``ArtifactsListServiceImpl`` / ``HtmlReportServiceImpl`` /
``PreviewReportServiceImpl``), which build the identical path and discover
``componentName`` by listing ``studio-workspace/``.
"""

import pytest

from app.services.oracle_pg.app_db_change import workspace as ws


def _settings(monkeypatch, nfs_base_path):
    class _AppDbJob3:
        pass

    class _Settings:
        pass

    job3 = _AppDbJob3()
    job3.nfs_base_path = str(nfs_base_path)
    settings = _Settings()
    settings.app_db_job3 = job3

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: settings,
    )


def test_an_explicit_project_path_is_returned_as_is(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    resolved = ws.resolve_project_path(
        "/some/explicit/checkout", app_id="APP1", tenant_id=None, plan_id=None
    )
    assert resolved == "/some/explicit/checkout"


def test_without_project_path_tenant_and_plan_are_required(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    with pytest.raises(ValueError, match="tenantId and planId"):
        ws.resolve_project_path(None, app_id="APP1", tenant_id=None, plan_id=None)
    with pytest.raises(ValueError, match="tenantId and planId"):
        ws.resolve_project_path(None, app_id="APP1", tenant_id="TNT1001", plan_id=None)


def test_derives_the_path_from_tenant_app_and_plan(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    workspace_dir = (
        tmp_path / "TNT1001" / "APP172687" / "transformed-code" / "101" / "studio-workspace"
    )
    component = workspace_dir / "Bvcmp"
    component.mkdir(parents=True)

    resolved = ws.resolve_project_path(
        None, app_id="APP172687", tenant_id="TNT1001", plan_id="101"
    )
    assert resolved == str(component)


def test_the_reserved_artifacts_folder_is_never_treated_as_the_component(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    workspace_dir = (
        tmp_path / "TNT1001" / "APP172687" / "transformed-code" / "101" / "studio-workspace"
    )
    (workspace_dir / "artifacts").mkdir(parents=True)
    component = workspace_dir / "Bvcmp"
    component.mkdir()

    resolved = ws.resolve_project_path(
        None, app_id="APP172687", tenant_id="TNT1001", plan_id="101"
    )
    assert resolved == str(component)


def test_a_missing_transformed_code_workspace_raises_a_clear_error(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    with pytest.raises(ValueError, match="Transformed-code workspace not found"):
        ws.resolve_project_path(
            None, app_id="APP172687", tenant_id="TNT1001", plan_id="101"
        )


def test_no_component_directory_raises_a_clear_error(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    workspace_dir = (
        tmp_path / "TNT1001" / "APP172687" / "transformed-code" / "101" / "studio-workspace"
    )
    (workspace_dir / "artifacts").mkdir(parents=True)

    with pytest.raises(ValueError, match="No component directory found"):
        ws.resolve_project_path(
            None, app_id="APP172687", tenant_id="TNT1001", plan_id="101"
        )


def test_multiple_component_directories_raise_instead_of_guessing(monkeypatch, tmp_path):
    _settings(monkeypatch, tmp_path)
    workspace_dir = (
        tmp_path / "TNT1001" / "APP172687" / "transformed-code" / "101" / "studio-workspace"
    )
    (workspace_dir / "Bvcmp").mkdir(parents=True)
    (workspace_dir / "OtherComponent").mkdir(parents=True)

    with pytest.raises(ValueError, match="Multiple component directories"):
        ws.resolve_project_path(
            None, app_id="APP172687", tenant_id="TNT1001", plan_id="101"
        )


@pytest.mark.parametrize("bad", ["../evil", "a/b"])
def test_path_traversal_in_tenant_or_plan_id_is_rejected(monkeypatch, tmp_path, bad):
    _settings(monkeypatch, tmp_path)
    with pytest.raises(ValueError):
        ws.resolve_project_path(None, app_id="APP172687", tenant_id=bad, plan_id="101")
    with pytest.raises(ValueError):
        ws.resolve_project_path(None, app_id="APP172687", tenant_id="TNT1001", plan_id=bad)
