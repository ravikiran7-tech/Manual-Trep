"""Shared helpers to drive App+DB Job 3 through the live orchestrator path in tests."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.job_manager import (
    get_app_db_job_manager,
    reset_app_db_job_manager,
)
from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
from app.services.oracle_pg.agent_runner import SessionResult

FIXTURES = Path(__file__).parent / "fixtures"
FINDINGS = FIXTURES / "java-oracle-dependency.json"
KB = FIXTURES / "oracle-to-postgresql-rules_remediation.json"
JAVA_SRC = FIXTURES / "java_src"


def patch_app_db_workspace(monkeypatch, tmp_path: Path):
    class _Settings:
        claude_workspace = str(tmp_path / "ws")

        class oracle_pg_agent:
            enabled = True

        class app_db_job3:
            max_concurrent_jobs = 4
            reuse_in_flight_launch = True
            report_generation_timeout_seconds = 300
            report_cache_max_age_seconds = 300
            zip_max_size_mb = 200
            nfs_base_path = str(tmp_path / "nfs")

    settings = _Settings()
    for target in (
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        "app.services.oracle_pg.app_db_change.job_manager.get_settings",
    ):
        monkeypatch.setattr(target, lambda: settings)
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.job_manager.settings",
        settings,
    )
    for api_mod in ("app_db_transformation", "app_db_transformation_dispatch"):
        try:
            monkeypatch.setattr(f"app.api.v1.{api_mod}.settings", settings)
        except Exception:  # noqa: BLE001
            pass
    reset_progress_tracker()
    reset_app_db_job_manager()
    return settings


def stage_job2_complete(db_id: str) -> None:
    reports = ws.reports_dir(db_id)
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "schema_job_status.json").write_text(
        json.dumps({"job2Status": "COMPLETED"}),
        encoding="utf-8",
    )


def _write_oracle_fixture_inputs(inputs: Path, checkout: Path) -> None:
    findings = {
        "violations": [
            {
                "ruleId": "oracle-java-001",
                "file": "src/main/java/com/example/Dao.java",
                "beginLine": 10,
                "endLine": 12,
            }
        ]
    }
    kb = {
        "rules": [
            {
                "ruleId": "oracle-java-001",
                "ruleName": "Oracle JDBC URL",
                "category": "connectivity",
                "severity": "High",
                "remediations": [
                    {
                        "default": True,
                        "description": "Use PostgreSQL JDBC URL",
                        "detailedDescription": "jdbc:postgresql://localhost:5432/app",
                    }
                ],
            }
        ]
    }
    inputs.mkdir(parents=True, exist_ok=True)
    (inputs / "java-oracle-dependency.json").write_text(
        json.dumps(findings, indent=2),
        encoding="utf-8",
    )
    (inputs / "oracle-to-postgresql-rules_remediation.json").write_text(
        json.dumps(kb, indent=2),
        encoding="utf-8",
    )
    dao = checkout / "src/main/java/com/example/Dao.java"
    dao.parent.mkdir(parents=True, exist_ok=True)
    dao.write_text(
        """package com.example;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dao {
    public Connection open() throws Exception {
        return DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:orcl",
            "user",
            "pass");
    }
}
""",
        encoding="utf-8",
    )


def stage_fixture_inputs(db_id: str, checkout: Path) -> None:
    inputs = ws.inputs_dir(db_id)
    inputs.mkdir(parents=True, exist_ok=True)
    stage_job2_complete(db_id)
    if FINDINGS.is_file() and KB.is_file():
        shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
        shutil.copy(KB, inputs / "oracle-to-postgresql-rules_remediation.json")
        for src in JAVA_SRC.rglob("*.java"):
            dest = checkout / src.relative_to(JAVA_SRC)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(src, dest)
        return
    _write_oracle_fixture_inputs(inputs, checkout)


async def _fake_remediator(*, transformation_id, checkout, plan):
    for item in plan.get("violations") or []:
        if str(item.get("status") or "").lower() != "pending" or not item.get("file"):
            continue
        path = Path(checkout) / item["file"]
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        path.write_text(
            text.replace(
                "jdbc:oracle:thin:@localhost:1521:orcl",
                "jdbc:postgresql://localhost:5432/app",
            ).replace("ORDER_SEQ.NEXTVAL", "nextval('order_seq')"),
            encoding="utf-8",
        )
    return SessionResult(success=True, result_text="ok")


async def launch_and_complete(
    monkeypatch,
    tmp_path: Path,
    *,
    app_id: str = "APP0010",
    db_id: str = "DB0010",
    pathway: str = "M-Upgrade",
    skip_llm: bool = False,
) -> Tuple[str, Path, Dict[str, Any]]:
    """Launch Job 3 with mocked Claude (unless skip_llm) and await completion."""
    patch_app_db_workspace(monkeypatch, tmp_path)
    checkout = tmp_path / "checkout"
    checkout.mkdir(parents=True, exist_ok=True)
    stage_fixture_inputs(db_id, checkout)

    if not skip_llm:
        monkeypatch.setattr(
            "app.services.oracle_pg.app_db_change.orchestrator.run_app_db_remediator_session",
            _fake_remediator,
        )

    manager = get_app_db_job_manager()
    started = await manager.launch(
        {
            "appId": app_id,
            "dbId": db_id,
            "projectPath": str(checkout),
            "pathway": pathway,
            "skipLlm": skip_llm,
            "appName": "OrderService",
            "dbName": "ORCLPROD",
            "sourceDatabaseVersion": "19c",
            "targetDatabaseVersion": "15.0",
            "targetBranch": "main",
            "repositoryUrl": "https://github.com/acme/order-service.git",
            "inputPaths": {
                "dependencyFindings": "java-oracle-dependency.json",
                "rulesRemediation": "oracle-to-postgresql-rules_remediation.json",
            },
        }
    )
    tid = started["transformationId"]
    task = manager._tasks.get(db_id)
    if task is not None:
        await task
    return tid, checkout, started
