"""post_transformation_report.json packager tests."""

from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
import json

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.report_packager import (
    REPORT_FILENAME,
    build_post_transformation_report,
    report_path,
    report_path_for_db,
    resolve_report,
    resolve_report_location,
    write_post_transformation_report,
)


def _seed_state(db_id, transformation_id, app_id):
    """Minimal reports/state.json so app/db lookups can resolve the job."""
    ws.ensure_reports_dir(db_id)
    ws.state_path(db_id).write_text(
        json.dumps(
            {
                "transformation_id": transformation_id,
                "app_id": app_id,
                "db_id": db_id,
                "created_at": "2026-09-02T10:00:00",
                "updated_at": "2026-09-02T10:01:00",
            }
        ),
        encoding="utf-8",
    )


def test_write_ui_ready_camel_case_report(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path / "ws")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    reset_progress_tracker()
    report = build_post_transformation_report(
        transformation_id="APPDB-TEST",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        files_scanned=4,
        violations_found=1,
        applied_changes=[
            {
                "file": "application.properties",
                "violations_fixed": ["ora-java-001"],
                "changes": [{"reason": "JDBC URL"}],
            }
        ],
        timing={"startedAt": "2026-09-02T10:00:00", "completedAt": "2026-09-02T10:01:00"},
    )
    nfs = tmp_path / "nfs"
    nfs.mkdir()
    path = write_post_transformation_report(report, nfs_mount_path=str(nfs))
    # The report goes to db-code-modernize/{dbId}/reports — never the checkout.
    assert path == report_path_for_db("D1")
    assert path == ws.reports_dir("D1") / REPORT_FILENAME
    assert path.exists()
    assert not (nfs / REPORT_FILENAME).exists()
    assert report["transformationId"] == "APPDB-TEST"
    assert report["executiveSummary"]["successfullyConverted"] == 1
    assert report["appliedChanges"][0]["violationsFixed"] == ["ora-java-001"]
    assert path.read_text(encoding="utf-8")
    _seed_state("D1", "APPDB-TEST", "A1")
    found = resolve_report(app_id="A1", db_id="D1")
    assert found is not None
    assert found["transformationId"] == "APPDB-TEST"
    assert resolve_report(app_id="no", db_id="no") is None


def test_resolve_report_location_returns_name_and_path(tmp_path, monkeypatch):
    """Path-only lookup for the database service: name + path, nothing else."""

    class _Settings:
        claude_workspace = str(tmp_path / "ws")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    reset_progress_tracker()

    nfs = tmp_path / "nfs"
    nfs.mkdir()
    report = build_post_transformation_report(
        transformation_id="APPDB-LOC",
        app_id="A9",
        db_id="D9",
        pathway="M-Upgrade",
        nfs_mount_path=str(nfs),
        files_scanned=1,
        violations_found=0,
        applied_changes=[],
        timing={"startedAt": "2026-09-07T10:00:00", "completedAt": "2026-09-07T10:00:01"},
    )
    write_post_transformation_report(report, nfs_mount_path=str(nfs))
    _seed_state("D9", "APPDB-LOC", "A9")
    expected = str(report_path_for_db("D9"))

    # The single location on the shared mount: db-code-modernize/{dbId}/reports.
    assert resolve_report_location(app_id="A9", db_id="D9") == {
        "transformationId": "APPDB-LOC",
        "name": REPORT_FILENAME,
        "path": expected,
    }

    # transformationId may be supplied explicitly.
    assert resolve_report_location(
        app_id="A9", db_id="D9", transformation_id="APPDB-LOC"
    )["path"] == expected

    # Unknown ids, and ids that do not match the resolved transformation.
    assert resolve_report_location(app_id="no", db_id="no") is None
    assert resolve_report_location(
        app_id="A9", db_id="WRONG", transformation_id="APPDB-LOC"
    ) is None

    # Report removed -> no path at all rather than one that does not exist.
    report_path("APPDB-LOC").unlink()
    assert resolve_report_location(app_id="A9", db_id="D9") is None


def test_report_includes_rules_results_and_summary_text():
    outcomes = [
        {
            "rule_id": "ora-java-001",
            "rule_name": "Oracle JDBC URL",
            "category": "jdbc",
            "file": "application.properties",
            "status": "RESOLVED",
            "bullets": ["Updated JDBC URL from Oracle to PostgreSQL"],
            "reason": None,
        },
        {
            "rule_id": "ora-java-002",
            "rule_name": "Oracle sequence usage",
            "category": "sql",
            "file": "Query.java",
            "status": "FAILED",
            "bullets": [],
            "reason": "File not found in checkout — manual review required",
        },
    ]
    report = build_post_transformation_report(
        transformation_id="APPDB-RULES",
        app_id="A1",
        db_id="D1",
        app_name="Order Service",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        files_scanned=4,
        violations_found=2,
        skipped_targets=1,
        applied_changes=[
            {
                "file": "application.properties",
                "violations_fixed": ["ora-java-001"],
                "changes": [{"reason": "Updated JDBC URL from Oracle to PostgreSQL"}],
            }
        ],
        violation_outcomes=outcomes,
        timing={"startedAt": "2026-09-02T10:00:00", "completedAt": "2026-09-02T10:01:40"},
    )
    # executiveSummary: resolved/failed derived from outcomes, not just skipped_targets
    assert report["executiveSummary"]["totalRulesProcessed"] == 2
    assert report["executiveSummary"]["violationsResolved"] == 1
    assert report["executiveSummary"]["violationsFailed"] == 1
    assert report["executiveSummary"]["successRate"] == 50.0

    # rulesResults: one row per rule, M-Upgrade has no compat rows
    rule_names = [r["ruleName"] for r in report["rulesResults"]]
    assert "Oracle JDBC URL" in rule_names
    assert "Oracle sequence usage" in rule_names
    resolved_row = next(r for r in report["rulesResults"] if r["ruleName"] == "Oracle JDBC URL")
    assert resolved_row["success"] == 1 and resolved_row["failed"] == 0
    failed_row = next(r for r in report["rulesResults"] if r["ruleName"] == "Oracle sequence usage")
    assert failed_row["success"] == 0 and failed_row["failed"] == 1
    assert not any(r["category"] == "postgresql-compatibility" for r in report["rulesResults"])

    # fileModifications: fixed panel from applied changes, failed panel from outcomes
    files = {m["filePath"]: m for m in report["fileModifications"]}
    assert files["application.properties"]["violationsFixed"] == 1
    assert files["application.properties"]["fixed"]
    assert files["Query.java"]["violationsFailed"] == 1
    assert files["Query.java"]["failed"]

    # manualReview surfaces the failed violation with guidance
    assert len(report["manualReview"]) == 1
    assert report["manualReview"][0]["rule"] == "Oracle sequence usage"

    # AI-style summary sentence (FR4)
    assert "Order Service" in report["summaryText"]
    assert "1 Oracle-Java dependency violations" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied Oracle-Java dependency rules"

    # duration derived from timing
    assert report["timing"]["durationSeconds"] == 100
    assert report["timing"]["duration"] == "1m 40s"

    # GitHub commit is not part of Job 3 reports
    assert "commit" not in report


def test_commit_scope_excludes_config_files_on_m_upgrade():
    # A violation fixed application.properties (config), and the general PG
    # compat pass touched application.yml (config) too — matches a real
    # M-Upgrade job where a rule happens to target a non-Java file.
    outcomes = [
        {
            "rule_id": "ora-java-001",
            "rule_name": "ora-java-001",
            "category": "jdbc",
            "file": "src/main/resources/application.properties",
            "status": "RESOLVED",
            "bullets": ["Updated Spring datasource properties for PostgreSQL"],
            "reason": None,
        }
    ]
    applied = [
        {
            "file": "src/main/resources/application.properties",
            "violations_fixed": ["ora-java-001"],
            "changes": [{"reason": "Updated Spring datasource properties for PostgreSQL"}],
        },
        {
            "file": "src/main/resources/application.yml",
            "violations_fixed": [],
            "changes": [{"reason": "Updated Spring datasource YAML for PostgreSQL"}],
        },
        {
            "file": "src/main/java/com/example/DbConfig.java",
            "violations_fixed": [],
            "changes": [{"reason": "Updated JDBC URL from Oracle to PostgreSQL"}],
        },
    ]
    compat = [applied[1]]  # the yml change came from the compat pass, not a rule
    report = build_post_transformation_report(
        transformation_id="APPDB-SCOPE",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        violations_found=1,
        applied_changes=applied,
        violation_outcomes=outcomes,
        compat_applied=compat,
    )
    assert "commit" not in report
    # Config-file changes are still visible in the full report
    file_paths = {m["filePath"] for m in report["fileModifications"]}
    assert "src/main/resources/application.properties" in file_paths
    assert "src/main/resources/application.yml" in file_paths
    applied_paths = {c["file"] for c in report["appliedChanges"]}
    assert "src/main/resources/application.properties" in applied_paths


def test_commit_scope_includes_config_and_container_files_for_container_pathway():
    applied = [
        {"file": "application.yml", "changes": [{"reason": "Updated Spring datasource YAML for PostgreSQL"}]},
        {"file": "pom.xml", "changes": [{"reason": "Added PostgreSQL JDBC Maven dependency"}]},
        {"file": "Dockerfile", "changes": [{"reason": "Updated Dockerfile PostgreSQL environment"}]},
        {"file": "docker-compose.yml", "changes": [{"reason": "Created Postgres compose"}]},
        {"file": ".github/workflows/ci.yml", "changes": [{"reason": "unexpected touch"}]},
    ]
    report = build_post_transformation_report(
        transformation_id="APPDB-SCOPE-2",
        app_id="A1",
        db_id="D1",
        pathway="M-Container-Mono",
        nfs_mount_path="/nfs/app",
        violations_found=0,
        applied_changes=applied,
    )
    assert "commit" not in report
    # CI/CD files are flagged for manual review instead
    manual_files = {m["file"] for m in report["manualReview"]}
    assert ".github/workflows/ci.yml" in manual_files
    file_paths = {m["filePath"] for m in report["fileModifications"]}
    assert "docker-compose.yml" in file_paths
    assert "application.yml" in file_paths


def test_container_pathway_adds_compat_rule_rows():
    compat = [
        {
            "file": "docker-compose.yml",
            "changes": [{"reason": "Created Postgres compose"}],
        },
        {
            "file": "application.properties",
            "changes": [{"reason": "Updated Spring datasource properties for PostgreSQL"}],
        },
    ]
    report = build_post_transformation_report(
        transformation_id="APPDB-CONTAINER",
        app_id="A1",
        db_id="D1",
        pathway="M-Container-Mono",
        nfs_mount_path="/nfs/app",
        violations_found=0,
        applied_changes=compat,
        compat_applied=compat,
    )
    categories = {r["ruleName"] for r in report["rulesResults"]}
    assert "Docker Compose PostgreSQL Updates" in categories
    assert "Dockerfile PostgreSQL Updates" in categories
    assert "Datasource Configuration Updates" in categories
    # M-Upgrade has none of these
    upgrade_report = build_post_transformation_report(
        transformation_id="APPDB-UPGRADE",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        violations_found=0,
        compat_applied=compat,
    )
    assert upgrade_report["rulesResults"] == []
    assert "0 Oracle-Java" in upgrade_report["summaryText"] or "no Oracle-Java" in upgrade_report["summaryText"]


def test_summary_and_rules_table_use_custom_violation_profile():
    """MSSQL App+DB passes violation_profile_label so copy matches MSSQL-Java."""
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        violations_found=2,
        violation_outcomes=[
            {
                "rule_id": "r1",
                "rule_name": "StringToVarcharMapping",
                "category": "jdbc",
                "file": "src/Main.java",
                "status": "FAILED",
                "reason": "No file change detected",
            },
            {
                "rule_id": "r1",
                "rule_name": "StringToVarcharMapping",
                "category": "jdbc",
                "file": "src/Other.java",
                "status": "FAILED",
                "reason": "No file change detected",
            },
        ],
        violation_profile_label="MSSQL-Java",
    )
    assert "0 MSSQL-Java dependency violations" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-Java dependency rules"


def test_zero_violations_summary_uses_custom_profile():
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL-2",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        violations_found=0,
        violation_profile_label="MSSQL-Java",
    )
    assert "no MSSQL-Java violations in scope" in report["summaryText"]