"""Job 3 rewrite tests: flatten/join plan, launch, mocked Claude, COMPLETED without commit."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.input_adapter import (
    build_and_write_plan,
    build_dependency_resolution_plan,
    flatten_dependency_findings,
)
from app.services.oracle_pg.app_db_change.job_manager import (
    get_app_db_job_manager,
    reset_app_db_job_manager,
)
from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
from app.services.oracle_pg.agent_runner import SessionResult

FIXTURES = Path(__file__).parent / "fixtures"
FINDINGS = FIXTURES / "java-oracle-dependency.json"
KB = FIXTURES / "oracle-to-postgresql-rules_remediation.json"
JAVA_SRC = FIXTURES / "java_src"


def _settings(tmp_path: Path):
    class _Settings:
        claude_workspace = str(tmp_path / "ws")

        class oracle_pg_agent:
            enabled = True

        class app_db_job3:
            max_concurrent_jobs = 4
            reuse_in_flight_launch = True
            report_generation_timeout_seconds = 300
            nfs_base_path = str(tmp_path / "nfs")

    return _Settings()


def _patch_workspace(monkeypatch, tmp_path: Path):
    settings = _settings(tmp_path)
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: settings,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: settings,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.job_manager.get_settings",
        lambda: settings,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.job_manager.settings",
        settings,
    )
    reset_progress_tracker()
    reset_app_db_job_manager()
    return settings


def _stage_inputs(db_id: str, checkout: Path) -> None:
    inputs = ws.inputs_dir(db_id)
    inputs.mkdir(parents=True, exist_ok=True)
    shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
    shutil.copy(KB, inputs / "oracle-to-postgresql-rules_remediation.json")
    for src in JAVA_SRC.rglob("*.java"):
        dest = checkout / src.relative_to(JAVA_SRC)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, dest)


def test_flatten_violation_details_from_real_shape():
    data = json.loads(FINDINGS.read_text(encoding="utf-8"))
    findings = flatten_dependency_findings(data)
    assert len(findings) == 4
    assert {f["ruleId"] for f in findings} == {"ora-java-010", "ora-java-006", "ora-java-999"}
    assert all("file" in f for f in findings)
    order = next(f for f in findings if f["file"].endswith("Order.java"))
    assert order["beginLine"] == 12
    assert order["ruleId"] == "ora-java-010"


def test_join_plan_skips_findings_not_in_remediation_catalog():
    plan = build_dependency_resolution_plan(
        findings_path=FINDINGS,
        catalog_path=KB,
        app_id="APP0010",
        db_id="DB0010",
        pathway="M-Upgrade",
        project_path="/tmp/checkout",
    )
    pending = [v for v in plan["violations"] if v["status"] == "pending"]
    failed = [v for v in plan["violations"] if v["status"] == "failed"]
    assert len(pending) == 3
    assert len(failed) == 0
    assert {v["ruleId"] for v in plan["violations"]} == {"ora-java-006", "ora-java-010"}
    assert any("unselected ruleId=ora-java-999" in w for w in plan["assemblyWarnings"])
    # KB rules with zero findings are ignored (catalogSubset only lists used rules).
    catalog_ids = {r["ruleId"] for r in plan["catalogSubset"]["rules"]}
    assert catalog_ids == {"ora-java-006", "ora-java-010"}
    assert all(v.get("remediationText") for v in pending)


def test_claude_path_reject_outside_inputs(tmp_path, monkeypatch):
    _patch_workspace(monkeypatch, tmp_path)
    outside = tmp_path / "Downloads" / "rules.json"
    outside.parent.mkdir(parents=True)
    outside.write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match="must be under"):
        ws.resolve_input_file("DB0010", str(outside), label="inputPaths.rulesRemediation")


@pytest.mark.asyncio
async def test_launch_plan_mocked_claude_completes_without_commit(tmp_path, monkeypatch):
    _patch_workspace(monkeypatch, tmp_path)
    db_id = "DB0010"
    checkout = tmp_path / "checkout"
    checkout.mkdir()
    _stage_inputs(db_id, checkout)

    async def _fake_remediator(*, transformation_id, checkout, plan):
        # Simulate Claude editing the listed Java files.
        for item in plan.get("violations") or []:
            if item.get("status") != "pending" or not item.get("file"):
                continue
            path = Path(checkout) / item["file"]
            if path.is_file():
                text = path.read_text(encoding="utf-8")
                path.write_text(
                    text.replace("jdbc:oracle:thin:@localhost:1521:orcl", "jdbc:postgresql://localhost:5432/app")
                    .replace("ORDER_SEQ.NEXTVAL", "nextval('order_seq')"),
                    encoding="utf-8",
                )
        return SessionResult(success=True, result_text="ok")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.orchestrator.run_app_db_remediator_session",
        _fake_remediator,
    )

    manager = get_app_db_job_manager()
    started = await manager.launch(
        {
            "appId": "APP0010",
            "dbId": db_id,
            "projectPath": str(checkout),
            "inputPaths": {
                "dependencyFindings": "java-oracle-dependency.json",
                "rulesRemediation": "oracle-to-postgresql-rules_remediation.json",
            },
            "pathway": "M-Upgrade",
            "skipLlm": False,
        }
    )
    tid = started["transformationId"]
    assert started["status"] == "QUEUED"
    assert ws.job_config_path(db_id).is_file()

    # Drain the background task started by launch.
    task = manager._tasks.get(db_id)
    if task is not None:
        await task

    progress = manager.tracker.get_progress(tid)
    assert progress["overall_status"] == "COMPLETED"
    assert progress["progress_percent"] == 100
    assert [m["status"] for m in progress["milestones"]] == ["COMPLETED"] * 5
    assert "commit" not in progress
    assert progress["report"]["available"] is True

    plan_file = ws.plan_path(db_id)
    assert plan_file.is_file()
    plan = json.loads(plan_file.read_text(encoding="utf-8"))
    assert plan["summary"]["totalFindings"] == 4

    report_path = ws.reports_dir(db_id) / "post_transformation_report.json"
    assert report_path.is_file()
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["overallStatus"] == "COMPLETED"
    assert "commit" not in report

    order = (checkout / "com/example/entity/Order.java").read_text(encoding="utf-8")
    assert "jdbc:postgresql://" in order


@pytest.mark.asyncio
async def test_skip_llm_marks_pending_failed_but_still_completes(tmp_path, monkeypatch):
    _patch_workspace(monkeypatch, tmp_path)
    db_id = "DB0011"
    checkout = tmp_path / "checkout2"
    checkout.mkdir()
    _stage_inputs(db_id, checkout)

    manager = get_app_db_job_manager()
    started = await manager.launch(
        {
            "appId": "APP0011",
            "dbId": db_id,
            "projectPath": str(checkout),
            "skipLlm": True,
        }
    )
    tid = started["transformationId"]
    task = manager._tasks.get(db_id)
    if task is not None:
        await task

    progress = manager.tracker.get_progress(tid)
    assert progress["overall_status"] == "COMPLETED"
    assert "commit" not in progress
    plan = json.loads(ws.plan_path(db_id).read_text(encoding="utf-8"))
    pending_like = [v for v in plan["violations"] if "skipLlm" in str(v.get("reason") or "")]
    assert pending_like


@pytest.mark.asyncio
async def test_claude_failure_marks_job_failed(tmp_path, monkeypatch):
    _patch_workspace(monkeypatch, tmp_path)
    db_id = "DB0013"
    checkout = tmp_path / "checkout3"
    checkout.mkdir()
    _stage_inputs(db_id, checkout)

    async def _fail(*, transformation_id, checkout, plan):
        return SessionResult(success=False, error_message="SDK boom")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.orchestrator.run_app_db_remediator_session",
        _fail,
    )

    manager = get_app_db_job_manager()
    started = await manager.launch(
        {
            "appId": "APP0013",
            "dbId": db_id,
            "projectPath": str(checkout),
            "skipLlm": False,
        }
    )
    tid = started["transformationId"]
    task = manager._tasks.get(db_id)
    if task is not None:
        await task

    progress = manager.tracker.get_progress(tid)
    assert progress["overall_status"] == "FAILED"


def test_build_and_write_plan_under_reports(tmp_path, monkeypatch):
    _patch_workspace(monkeypatch, tmp_path)
    db_id = "DB0012"
    inputs = ws.inputs_dir(db_id)
    inputs.mkdir(parents=True)
    shutil.copy(FINDINGS, inputs / "java-oracle-dependency.json")
    shutil.copy(KB, inputs / "oracle-to-postgresql-rules_remediation.json")
    plan, path = build_and_write_plan(
        db_id=db_id,
        app_id="APP0012",
        findings_path=inputs / "java-oracle-dependency.json",
        catalog_path=inputs / "oracle-to-postgresql-rules_remediation.json",
    )
    assert path == ws.plan_path(db_id)
    assert path.is_file()
    assert plan["dbId"] == db_id
