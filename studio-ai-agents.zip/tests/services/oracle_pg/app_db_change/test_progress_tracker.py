"""Progress tracker milestone and log tests."""

import json

import pytest

from app.services.oracle_pg.app_db_change.progress_tracker import (
    MILESTONE_FINAL,
    STATUS_COMPLETED,
    STATUS_IN_PROGRESS,
    ProgressTracker,
)


def test_milestone_sequence_and_logs(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    tracker = ProgressTracker()
    tracker.initialize_tracking("APPDB-TEST")
    tracker.update_milestone("APPDB-TEST", 1, STATUS_IN_PROGRESS)
    tracker.add_log_entry("APPDB-TEST", "INFO", "loading rules")
    tracker.update_milestone("APPDB-TEST", 1, STATUS_COMPLETED)
    for mid in (2, 3, 4, 5):
        tracker.update_milestone("APPDB-TEST", mid, STATUS_IN_PROGRESS)
        tracker.add_log_entry("APPDB-TEST", "INFO", f"milestone {mid}")
        tracker.update_milestone("APPDB-TEST", mid, STATUS_COMPLETED)

    progress = tracker.get_progress("APPDB-TEST")
    assert progress["overall_status"] == STATUS_COMPLETED
    assert progress["current_milestone"] == 5
    assert [m["status"] for m in progress["milestones"]] == [STATUS_COMPLETED] * 5
    assert progress["progress_percent"] == 100
    assert progress["banner_message"] == "App-DB Dependency Code Changes Completed Successfully."

    first = tracker.get_logs("APPDB-TEST", from_index=0)
    assert len(first["logs"]) >= 5
    page = tracker.get_logs("APPDB-TEST", from_index=2)
    assert page["logs"][0]["message"] == first["logs"][2]["message"]
    assert page["has_more"] is False


def test_banner_message_across_all_three_states(tmp_path, monkeypatch):
    """FR3 Section 1 — the exact Overall Progress banner text, per state."""

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    tracker = ProgressTracker()
    tracker.initialize_tracking("APPDB-BANNER")
    assert (
        tracker.get_progress("APPDB-BANNER")["banner_message"]
        == "App-DB Dependency Transformation in progress."
    )
    assert (
        tracker.get_status_payload("APPDB-BANNER")["bannerMessage"]
        == "App-DB Dependency Transformation in progress."
    )

    tracker.mark_failed("APPDB-BANNER", "boom")
    assert (
        tracker.get_progress("APPDB-BANNER")["banner_message"]
        == "App-DB Dependency Transformation encountered an error."
    )
    assert (
        tracker.get_status_payload("APPDB-BANNER")["bannerMessage"]
        == "App-DB Dependency Transformation encountered an error."
    )

    tracker.initialize_tracking("APPDB-BANNER-2")
    for mid in (1, 2, 3, 4, 5):
        tracker.update_milestone("APPDB-BANNER-2", mid, STATUS_IN_PROGRESS)
        tracker.update_milestone("APPDB-BANNER-2", mid, STATUS_COMPLETED)
    assert (
        tracker.get_status_payload("APPDB-BANNER-2")["bannerMessage"]
        == "App-DB Dependency Code Changes Completed Successfully."
    )


def test_unknown_id_raises(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    tracker = ProgressTracker()
    try:
        tracker.get_progress("missing")
        assert False, "expected KeyError"
    except KeyError:
        pass


def test_add_log_entry_accepts_schema_style_icon(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    tracker = ProgressTracker()
    tracker.initialize_tracking("APPDB-TEST", app_id="A1", db_id="D1")
    entry = tracker.add_log_entry(
        "APPDB-TEST",
        "INFO",
        "Reading pom.xml",
        icon="search",
    )
    assert entry["icon"] == "search"
    assert entry["color"] == "#2196F3"


def test_public_job_id_is_app_id(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    tracker = ProgressTracker()
    tracker.initialize_tracking("APPDB-TEST", app_id="A1", db_id="D1")
    tracker.add_log_entry("APPDB-TEST", "INFO", "queued")

    payload = tracker.get_status_payload("APPDB-TEST")
    assert payload["jobId"] == "A1"
    assert payload["transformationId"] == "APPDB-TEST"
    assert payload["appId"] == "A1"
    assert tracker.public_job_id("APPDB-TEST") == "A1"
    assert tracker.resolve_job_id("A1") == "APPDB-TEST"
    assert tracker.resolve_job_id("D1") == "APPDB-TEST"
    assert tracker.get_logs("APPDB-TEST")["logs"][0]["jobId"] == "A1"


@pytest.mark.asyncio
async def test_tail_sse_logs_reads_logs_jsonl_from_disk(tmp_path, monkeypatch):
    from app.api.v1.app_db_transformation import _tail_sse_logs

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )

    tid = "APPDB-LOGSSE"
    tracker = ProgressTracker()
    tracker.initialize_tracking(tid, app_id="A1", db_id="D1")
    tracker.add_log_entry(tid, "INFO", "Reading Foo.java", icon="search")
    tracker.update_milestone(tid, MILESTONE_FINAL, STATUS_IN_PROGRESS)
    tracker.update_milestone(tid, MILESTONE_FINAL, STATUS_COMPLETED)
    tracker.add_log_entry(tid, "INFO", "Transformation completed")

    entries = []
    async for chunk in _tail_sse_logs(tid):
        if chunk.startswith("data: "):
            entries.append(json.loads(chunk[len("data: ") :].strip()))

    assert any(e["icon"] == "search" and e["color"] == "#2196F3" for e in entries)
    assert entries[-1]["icon"] == "check"
    assert entries[-1]["phase"] == "Completed"
