"""Report display blocks (FR2-FR8) for App+DB post-transformation reports."""

import json

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
from app.services.oracle_pg.app_db_change.report_packager import (
    NO_FAILURES_PLACEHOLDER,
    NO_VIOLATIONS_LABEL,
    build_post_transformation_report,
    write_post_transformation_report,
)


def _ws(monkeypatch, tmp_path):
    class _Settings:
        claude_workspace = str(tmp_path / "ws")

    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )
    reset_progress_tracker()


def _report(**overrides):
    kwargs = dict(
        transformation_id="APPDB-DISPLAY",
        app_id="A1",
        db_id="D1",
        pathway="M-Basic",
        nfs_mount_path="/nfs/app",
        app_name="OrderService",
        db_name="ORCLPROD",
        oracle_version="19c",
        files_scanned=6,
        violations_found=2,
        applied_changes=[
            {
                "file": "src/main/resources/application.properties",
                "violations_fixed": ["ora-java-001"],
                "changes": [
                    {"reason": "Updated spring.datasource.url to PostgreSQL JDBC URL format"},
                    {"reason": "Replaced OracleDriver with PostgreSQL JDBC Driver", "line": 14},
                ],
            }
        ],
        violation_outcomes=[
            {
                "rule_id": "ora-java-001",
                "rule_name": "Oracle JDBC URL",
                "category": "jdbc",
                "file": "src/main/resources/application.properties",
                "status": "RESOLVED",
            },
            {
                "rule_id": "ora-java-022",
                "rule_name": "Oracle proprietary API",
                "category": "api",
                "file": "src/main/java/Legacy.java",
                "status": "FAILED",
                "reason": "No remediation available — manual review required",
            },
        ],
        compat_applied=[
            {
                "file": "pom.xml",
                "changes": [
                    {"reason": "Replaced ojdbc dependency with postgresql JDBC driver in pom.xml"}
                ],
            }
        ],
        timing={"startedAt": "2026-09-04T10:00:00", "completedAt": "2026-09-04T10:02:30"},
        target_branch="main",
        repository_url="https://github.com/acme/order-service.git",
    )
    kwargs.update(overrides)
    return build_post_transformation_report(**kwargs)


def test_header_and_metadata_row():
    report = _report()
    assert report["header"]["title"] == (
        "Post-Transformation Report: App-DB Dependency Code Changes for M-Basic + DB pathway"
    )
    assert report["header"]["subtitle"] == "Post transformation summary"

    labels = [row["label"] for row in report["metadataRow"]]
    assert labels == [
        "Application Name",
        "Application ID",
        "Transformation Pathway",
        "Duration",
        "Completed On",
    ]
    values = {row["key"]: row["value"] for row in report["metadataRow"]}
    assert values["applicationName"] == "OrderService"
    assert values["applicationId"] == "A1"
    assert values["transformationPathway"] == "M-Basic + DB-Modernize"
    assert values["duration"] == "2m 30s"
    # FR3 "Completed On" — MMM DD, YYYY, HH:MM AM/PM
    assert values["completedOn"] == "Sep 04, 2026, 10:02 AM"


def test_summary_cards_with_violations():
    cards = {c["key"]: c for c in _report()["executiveSummary"]["summaryCards"]}
    assert [c for c in cards] == [
        "totalRulesProcessed",
        "totalViolations",
        "filesModified",
        "successRate",
    ]
    assert cards["totalRulesProcessed"]["value"] == 2
    assert cards["totalViolations"]["displayValue"] == "2"
    assert cards["totalViolations"]["subLabel"]["text"] == "1 Resolved / 1 Failed"
    assert cards["successRate"]["displayValue"] == "50%"


def test_summary_cards_with_zero_violations():
    report = _report(violations_found=0, violation_outcomes=[])
    cards = {c["key"]: c for c in report["executiveSummary"]["summaryCards"]}
    assert cards["totalViolations"]["displayValue"] == NO_VIOLATIONS_LABEL
    assert "subLabel" not in cards["totalViolations"]
    assert cards["successRate"]["displayValue"] == "N/A"
    assert report["executiveSummary"]["successRateDisplay"] == "N/A"
    assert "no Oracle-Java violations in scope" in report["summaryText"]


def test_rules_table_numbering_and_highlight():
    report = _report()
    table = report["rulesTable"]
    assert table["heading"] == "Rule by Rule Results"
    assert table["subHeading"] == "Code changes by applied Oracle-Java dependency rules"
    assert table["columns"][0] == "S.No"
    rows = report["rulesResults"]
    assert table["title"] == f"Rules ({len(rows)})"
    assert [r["sNo"] for r in rows] == list(range(1, len(rows) + 1))

    failed_row = next(r for r in rows if r["ruleName"] == "Oracle proprietary API")
    assert failed_row["failed"] == 1
    assert failed_row["highlight"] is True
    resolved_row = next(r for r in rows if r["ruleName"] == "Oracle JDBC URL")
    assert resolved_row["highlight"] is False
    assert resolved_row["violationsDisplay"] == "1"

    # M-Basic adds exactly the four non-container categories, all with N/A violations.
    compat = [r for r in rows if r["category"] == "postgresql-compatibility"]
    assert [r["ruleName"] for r in compat] == [
        "Datasource Configuration Updates",
        "JDBC Driver Replacement",
        "ORM / Persistence Configuration",
        "Connection Pool Migration",
    ]
    assert all(r["violations"] == "N/A" for r in compat)
    driver_row = next(r for r in compat if r["ruleName"] == "JDBC Driver Replacement")
    assert driver_row["success"] == 1


def test_m_upgrade_has_no_compat_rows():
    rows = _report(pathway="M-Upgrade")["rulesResults"]
    assert all(r["category"] != "postgresql-compatibility" for r in rows)


def test_container_pathway_lists_all_eight_compat_rows():
    rows = _report(pathway="M-Container-Mono")["rulesResults"]
    compat = [r["ruleName"] for r in rows if r["category"] == "postgresql-compatibility"]
    assert compat == [
        "Datasource Configuration Updates",
        "JDBC Driver Replacement",
        "ORM / Persistence Configuration",
        "Connection Pool Migration",
        "Dockerfile PostgreSQL Updates",
        "Docker Compose PostgreSQL Updates",
        "Kubernetes Manifest Updates",
        "Health Check Configuration",
    ]


def test_file_modification_panels_and_badges():
    report = _report()
    section = report["filesSection"]
    assert section["heading"] == "File Modification Details"
    assert section["subHeading"] == "Detailed breakdown of dependency code changes at file level"
    assert section["title"] == f"Modified Files ({len(report['fileModifications'])})"
    assert section["noFailuresPlaceholder"] == NO_FAILURES_PLACEHOLDER
    assert section["manualReviewLabel"] == "Requires Manual Review"

    fixed_file = report["fileModifications"][0]
    assert fixed_file["filePath"] == "src/main/resources/application.properties"
    assert fixed_file["badges"]["fixedLabel"] == "1 Violations Fixed"
    assert fixed_file["badges"]["failedLabel"] == "0 Violations Failed"
    assert fixed_file["hasFailures"] is False
    # Line numbers are rendered into the bullet (FR6 example wording).
    assert "Replaced OracleDriver with PostgreSQL JDBC Driver (Line 14)" in fixed_file["fixed"]

    failed_file = next(
        f for f in report["fileModifications"] if f["filePath"] == "src/main/java/Legacy.java"
    )
    assert failed_file["violationsFailed"] == 1
    assert failed_file["hasFailures"] is True
    assert failed_file["failed"] == [
        "Oracle proprietary API: No remediation available — manual review required"
    ]
    assert failed_file["manualReview"] == failed_file["failed"]


def test_cicd_findings_become_manual_review_items():
    report = _report(cicd_findings=["Jenkinsfile"])
    reasons = {(item["file"], item["reason"]) for item in report["manualReview"]}
    assert (
        "Jenkinsfile",
        "CI-CD pipeline Oracle JDBC reference detected — manual replacement required",
    ) in reasons
    # Never committed, always reported via manualReview.
    assert any(item.get("file") == "Jenkinsfile" for item in report["manualReview"])
    assert "commit" not in report


def test_footer_block():
    footer = _report()["footer"]
    assert footer["saved"] is True
    assert footer["savedText"] == "Report saved successfully"
    assert footer["downloadPdf"] == {"enabled": True, "label": "Download PDF"}
    assert footer["generatedOnText"].startswith("Report generated on ")
    assert footer["generatedOnText"].endswith(("AM", "PM"))


def test_report_omits_commit_block():
    assert "commit" not in _report()


def test_zero_violation_summary_still_renders():
    report = _report(violations_found=0, violation_outcomes=[])
    assert "commit" not in report
    assert report["summaryText"]


def test_finalize_report_timing_restamps_duration(tmp_path, monkeypatch):
    """FR3 Duration is start→completion, not start→report-generation."""
    from app.services.oracle_pg.app_db_change.report_packager import finalize_report_timing

    _ws(monkeypatch, tmp_path)
    # Report written mid-run: completedAt == the report's own timestamp.
    written = _report(
        timing={"startedAt": "2026-09-04T10:00:00", "completedAt": "2026-09-04T10:00:04"}
    )
    write_post_transformation_report(written, nfs_mount_path=str(tmp_path / "nope"))
    assert written["timing"]["duration"] == "4s"

    final = finalize_report_timing(
        "APPDB-DISPLAY",
        started_at="2026-09-04T10:00:00",
        completed_at="2026-09-04T10:02:30",
    )
    assert final["timing"]["duration"] == "2m 30s"
    assert final["timing"]["durationSeconds"] == 150
    assert final["application"]["duration"] == "2m 30s"
    row = {r["key"]: r["value"] for r in final["metadataRow"]}
    assert row["duration"] == "2m 30s"
    assert row["completedOn"] == "Sep 04, 2026, 10:02 AM"
    # Persisted, so a re-open shows the corrected duration.
    on_disk = json.loads(
        (ws.reports_dir("D1") / "post_transformation_report.json").read_text(
            encoding="utf-8"
        )
    )
    assert on_disk["timing"]["duration"] == "2m 30s"


def test_rules_table_exposes_both_counts():
    """The table mixes Oracle-Java rule rows with pathway compatibility rows, so
    the row count and the "rules processed" count differ — both are published."""
    container = _report(pathway="M-Container-Mono")
    table = container["rulesTable"]
    assert table["rowCount"] == len(container["rulesResults"])
    assert table["title"] == f"Rules ({table['rowCount']})"
    assert table["rulesProcessed"] == container["executiveSummary"]["totalRulesProcessed"]
    assert table["compatibilityRows"] == table["rowCount"] - table["rulesProcessed"]

    # On M-Upgrade there are no compatibility rows, so the two coincide.
    upgrade = _report(pathway="M-Upgrade")["rulesTable"]
    assert upgrade["compatibilityRows"] == 0
    assert upgrade["rowCount"] == upgrade["rulesProcessed"]
