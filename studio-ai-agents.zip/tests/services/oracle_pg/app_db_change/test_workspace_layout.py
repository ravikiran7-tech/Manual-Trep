"""Workspace layout and containment for App+DB Job 3."""

import json

import pytest

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.progress_tracker import (
    job_dir,
    reset_progress_tracker,
)
from tests.services.oracle_pg.app_db_change.run_helpers import launch_and_complete, patch_app_db_workspace


def _ws(monkeypatch, tmp_path):
    patch_app_db_workspace(monkeypatch, tmp_path)


def test_paths_match_the_java_package_builder(tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    base = tmp_path / "ws" / "db-code-modernize" / "DB0114"
    assert ws.db_root("DB0114") == base
    assert ws.inputs_dir("DB0114") == base / "_claude"
    assert ws.reports_dir("DB0114") == base / "reports"
    assert ws.state_path("DB0114").parent == base / "reports"
    assert ws.events_path("DB0114").parent == base / "reports"
    assert ws.logs_path("DB0114").parent == base / "reports"
    assert ws.request_path("DB0114").parent == base / "reports"
    assert ws.job_config_path("DB0114").parent == base / "reports"


@pytest.mark.parametrize(
    "value",
    ["../../etc/passwd", "..", "../reports/state.json", "/etc/passwd", ""],
)
def test_inputs_cannot_escape_the_claude_dir(tmp_path, monkeypatch, value):
    _ws(monkeypatch, tmp_path)
    with pytest.raises(ValueError):
        ws.resolve_input_file("DB0114", value)


def test_inputs_may_be_nested_inside_the_claude_dir(tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    resolved = ws.resolve_input_file("DB0114", "sub/dir/rules.json")
    assert resolved == (ws.inputs_dir("DB0114") / "sub/dir/rules.json").resolve()


@pytest.mark.parametrize("db_id", ["../evil", "a/b", "", None])
def test_db_id_must_be_a_single_safe_segment(tmp_path, monkeypatch, db_id):
    _ws(monkeypatch, tmp_path)
    with pytest.raises(ValueError):
        ws.db_root(db_id)


def test_rules_are_read_from_the_claude_dir(tmp_path, monkeypatch):
    _ws(monkeypatch, tmp_path)
    inputs = ws.inputs_dir("DB0114")
    inputs.mkdir(parents=True)
    payload = {"rules": [{"ruleId": "ora-java-001"}]}
    (inputs / ws.DEFAULT_RULES_REMEDIATION_FILENAME).write_text(
        json.dumps(payload), encoding="utf-8"
    )

    for value in (
        ws.DEFAULT_RULES_REMEDIATION_FILENAME,
        str(inputs / ws.DEFAULT_RULES_REMEDIATION_FILENAME),
    ):
        resolved = ws.resolve_input_file("DB0114", value)
        loaded = json.loads(resolved.read_text(encoding="utf-8"))
        assert loaded["rules"][0]["ruleId"] == "ora-java-001"


@pytest.mark.asyncio
async def test_a_run_writes_only_into_reports(tmp_path, monkeypatch):
    tid, checkout, _ = await launch_and_complete(
        monkeypatch, tmp_path, app_id="APP1", db_id="DB0114"
    )

    reports = ws.reports_dir("DB0114")
    names = {p.name for p in reports.iterdir()}
    assert "post_transformation_report.json" in names
    assert "state.json" in names
    assert "logs.jsonl" in names
    assert "events.jsonl" in names
    assert "job_config.json" in names
    assert "dependency-resolution-plan.json" in names
    assert any(n.endswith("_job3_modified_files.zip") for n in names)
    assert job_dir(tid) == reports
    assert not (checkout / "post_transformation_report.json").exists()
    assert not (checkout / "state.json").exists()
    lines = ws.logs_path("DB0114").read_text(encoding="utf-8").strip().splitlines()
    assert lines and all(json.loads(line).get("jobId") == "APP1" for line in lines)


@pytest.mark.asyncio
async def test_state_survives_a_tracker_restart(tmp_path, monkeypatch):
    tid, _, _ = await launch_and_complete(
        monkeypatch, tmp_path, app_id="APP1", db_id="DB0114"
    )

    tracker = reset_progress_tracker()
    assert tracker.exists(tid)
    assert tracker.resolve_job_id(tid) == tid
    assert tracker.resolve_job_id("DB0114") == tid
    assert tracker.resolve_job_id("APP1") == tid
    assert tracker.get_progress(tid)["progress_percent"] == 100
    assert tracker.get_logs(tid)["logs"]
