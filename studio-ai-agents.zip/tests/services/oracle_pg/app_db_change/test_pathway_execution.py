"""Focused tests for App+DB pathway-specific compatibility handling."""

from pathlib import Path

from app.services.oracle_pg.app_db_change.agent_runner import render_remediator_prompt
from app.services.oracle_pg.app_db_change.orchestrator import _classify_changes
from app.services.oracle_pg.app_db_change.pathways import (
    compatibility_change_reason,
    compatibility_instructions,
    normalize_pathway,
)


def test_pathway_normalization_and_unknown_pathway_are_safe():
    assert normalize_pathway("m_basic") == "M-Basic"
    assert normalize_pathway("mcontainermono") == "M-Container-Mono"
    assert compatibility_instructions("M-Upgrade") == ""
    assert compatibility_instructions("custom") == ""


def test_prompt_scope_is_only_expanded_for_compatibility_pathways():
    upgrade = render_remediator_prompt(
        plan={"pathway": "M-Upgrade", "violations": [], "catalogSubset": {}},
        project_path="/checkout",
    )
    basic = render_remediator_prompt(
        plan={"pathway": "M-Basic", "violations": [], "catalogSubset": {}},
        project_path="/checkout",
    )
    container = render_remediator_prompt(
        plan={"pathway": "M-Container-Mono", "violations": [], "catalogSubset": {}},
        project_path="/checkout",
    )

    assert "Edit ONLY the files listed" in upgrade
    assert "application*.properties" not in upgrade
    assert "application*.properties" in basic
    assert "MUST inspect every existing compatibility file" in basic
    assert "Do not skip these files merely because they are absent from the violation plan" in basic
    assert "Dockerfile" not in basic
    assert "Dockerfile" in container
    assert "Do not edit CI/CD pipeline files" in container


def test_prompt_lists_existing_compatibility_files(tmp_path: Path):
    properties = tmp_path / "src/main/resources/application.properties"
    properties.parent.mkdir(parents=True)
    properties.write_text("spring.datasource.url=jdbc:oracle:thin:@db:1521:orcl", encoding="utf-8")
    (tmp_path / "pom.xml").write_text("<project />", encoding="utf-8")
    (tmp_path / "Dockerfile").write_text("FROM eclipse-temurin:17", encoding="utf-8")

    basic = render_remediator_prompt(
        plan={"pathway": "M-Basic", "violations": [], "catalogSubset": {}},
        project_path=str(tmp_path),
    )
    container = render_remediator_prompt(
        plan={"pathway": "M-Container-Mono", "violations": [], "catalogSubset": {}},
        project_path=str(tmp_path),
    )

    assert "- src/main/resources/application.properties" in basic
    assert "- pom.xml" in basic
    assert "- Dockerfile" not in basic
    assert "- Dockerfile" in container
    assert "Complete this inspection even after all plan violations are fixed" in container


def test_compatibility_file_classification_respects_pathway():
    assert compatibility_change_reason("application.yml", "M-Upgrade") is None
    assert "datasource" in (
        compatibility_change_reason("src/main/resources/application.yml", "M-Basic") or ""
    )
    assert compatibility_change_reason("Dockerfile", "M-Basic") is None
    assert "Dockerfile" in (
        compatibility_change_reason("Dockerfile", "M-Container-Mono") or ""
    )
    assert "Kubernetes" in (
        compatibility_change_reason("k8s/deployment.yaml", "M-Container-Mono") or ""
    )
    assert compatibility_change_reason(".github/workflows/ci.yml", "M-Container-Mono") is None


def test_changed_plan_files_are_not_double_counted_as_compatibility():
    pending = [{"file": "src/main/resources/application.yml", "ruleId": "ora-java-1"}]
    changed = [
        "src/main/resources/application.yml",
        "pom.xml",
        "src/main/java/com/example/Order.java",
    ]

    applied, compat = _classify_changes(changed, pending, "M-Basic")

    assert [entry["file"] for entry in applied] == changed
    assert [entry["file"] for entry in compat] == ["pom.xml"]
    assert "driver" in compat[0]["changes"][0]["reason"].lower()
    plan_entry = next(entry for entry in applied if entry["file"].endswith("application.yml"))
    assert plan_entry["changes"] == [{"reason": "ora-java-1"}]


def test_plan_file_bullets_use_rule_and_remediation():
    pending = [
        {
            "file": "src/main/java/com/sit/entity/Doctor.java",
            "ruleId": "ora-java-006",
            "ruleName": "Oracle JDBC URL",
            "remediationText": "Replace the Oracle JDBC URL with the PostgreSQL URL",
            "beginLine": 12,
        },
        {
            "file": "src/main/java/com/sit/entity/Doctor.java",
            "ruleId": "ora-java-010",
            "ruleName": "Oracle driver",
            "remediationText": "Replace OracleDriver with the PostgreSQL driver",
            "beginLine": 18,
        },
    ]

    applied, compat = _classify_changes(
        ["src/main/java/com/sit/entity/Doctor.java"],
        pending,
        "M-Upgrade",
    )

    assert compat == []
    assert applied[0]["changes"] == [
        {
            "reason": "Oracle JDBC URL — Replace the Oracle JDBC URL with the PostgreSQL URL",
            "line": 12,
        },
        {
            "reason": "Oracle driver — Replace OracleDriver with the PostgreSQL driver",
            "line": 18,
        },
    ]
