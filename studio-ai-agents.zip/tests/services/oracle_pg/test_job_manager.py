"""Tests for Oracle PG job manager resume and enqueue behavior."""
from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock

import pytest

from app.services.oracle_pg.job_manager import JobManager
from app.services.oracle_pg.progress import (
    STATUS_COMPLETED,
    STATUS_IN_PROGRESS,
    STATUS_QUEUED,
    default_progress,
    save_progress,
)
from app.services.oracle_pg.workspace import ensure_job_dirs, job_config_path, job_root


def _patch_workspace(tmp_path, monkeypatch, *, max_concurrent_jobs: int = 5) -> None:
    class _Settings:
        claude_workspace = str(tmp_path)
        oracle_pg_agent = type("OraclePg", (), {"max_concurrent_jobs": max_concurrent_jobs})()

    settings = _Settings()
    monkeypatch.setattr("app.services.oracle_pg.job_manager.settings", settings)
    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: settings,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.notify_progress_update",
        lambda *_args, **_kwargs: None,
    )


def _write_job_config(folder_key: str, *, job_id: str | None = None) -> None:
    path = job_config_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(
            {
                "jobId": job_id or folder_key,
                "dbName": folder_key,
                "frozenAt": "2026-01-01T00:00:00+00:00",
                "inputPaths": {},
            },
            fh,
        )


@pytest.mark.asyncio
async def test_resume_enqueues_queued_jobs(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch)

    for name in ("db_queued_a", "db_queued_b"):
        ensure_job_dirs(name)
        _write_job_config(name)
        progress = default_progress(name)
        progress["status"] = STATUS_QUEUED
        save_progress(name, progress)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock()

    resumed = await manager.resume_in_progress_jobs()

    assert resumed == 2
    assert len(manager._tasks) == 2


@pytest.mark.asyncio
async def test_resume_enqueues_in_progress_jobs(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch)

    ensure_job_dirs("db_running")
    _write_job_config("db_running")
    progress = default_progress("db_running")
    progress["status"] = STATUS_IN_PROGRESS
    save_progress("db_running", progress)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock()

    resumed = await manager.resume_in_progress_jobs()

    assert resumed == 1
    assert "db_running" in manager._tasks


@pytest.mark.asyncio
async def test_resume_skips_mssql_jobs_in_shared_package(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch)

    ensure_job_dirs("db_mssql")
    path = job_config_path("db_mssql")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(
            {
                "jobId": "db_mssql",
                "dbName": "db_mssql",
                "engine": "mssql",
                "frozenAt": "2026-01-01T00:00:00+00:00",
            },
            fh,
        )
    progress = default_progress("db_mssql")
    progress["status"] = STATUS_QUEUED
    save_progress("db_mssql", progress)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock()

    resumed = await manager.resume_in_progress_jobs()

    assert resumed == 0
    assert manager._tasks == {}


@pytest.mark.asyncio
async def test_resume_skips_completed_jobs(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch)

    ensure_job_dirs("db_done")
    _write_job_config("db_done")
    progress = default_progress("db_done")
    progress["status"] = STATUS_COMPLETED
    save_progress("db_done", progress)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock()

    resumed = await manager.resume_in_progress_jobs()

    assert resumed == 0
    assert manager._tasks == {}


@pytest.mark.asyncio
async def test_enqueue_does_not_create_duplicate_tasks(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch)

    ensure_job_dirs("db_dup")
    _write_job_config("db_dup")
    progress = default_progress("db_dup")
    progress["status"] = STATUS_QUEUED
    save_progress("db_dup", progress)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock()

    await manager._enqueue("db_dup")
    await manager._enqueue("db_dup")

    assert len(manager._tasks) == 1


@pytest.mark.asyncio
async def test_resume_orders_queued_jobs_by_updated_at(tmp_path, monkeypatch):
    _patch_workspace(tmp_path, monkeypatch, max_concurrent_jobs=1)

    order: list[str] = []

    async def _record_run(folder_key: str) -> None:
        order.append(folder_key)
        await asyncio.sleep(0)

    for name, updated_at in (
        ("db_late", "2026-01-03T00:00:00+00:00"),
        ("db_early", "2026-01-01T00:00:00+00:00"),
    ):
        ensure_job_dirs(name)
        _write_job_config(name)
        progress = default_progress(name)
        progress["status"] = STATUS_QUEUED
        progress["updatedAt"] = updated_at
        progress_path = job_root(name) / "state" / "progress.json"
        with progress_path.open("w", encoding="utf-8") as fh:
            json.dump(progress, fh)

    manager = JobManager()
    manager._orchestrator.run = AsyncMock(side_effect=_record_run)

    resumed = await manager.resume_in_progress_jobs()
    assert resumed == 2

    await asyncio.gather(*manager._tasks.values())

    assert order == ["db_early", "db_late"]
