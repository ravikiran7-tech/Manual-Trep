"""Tests for Oracle PG live log formatters."""
from pathlib import Path

import pytest

from app.services.oracle_pg.progress import (
    PHASE_COMPLETED,
    PHASE_FAILED,
    PHASE_INITIALIZE,
    PHASE_MIGRATING,
)
from app.services.oracle_pg.live_logs import (
    format_assistant_text,
    format_post_tool_use,
    format_progress_event,
    format_session_start,
    format_tool_use_block,
    relative_path,
    set_current_phase,
)


@pytest.fixture(autouse=True)
def reset_phase():
    set_current_phase("JOB1", PHASE_INITIALIZE)
    yield


def test_format_progress_event_completed():
    entry = format_progress_event(
        "JOB1",
        {"phase": PHASE_COMPLETED, "status": "completed", "message": "Transformation complete"},
    )
    assert entry["icon"] == "check"
    assert entry["message"] == "Transformation complete"
    assert entry["phase"] == PHASE_COMPLETED


def test_format_progress_event_failed():
    entry = format_progress_event(
        "JOB1",
        {
            "phase": PHASE_FAILED,
            "status": "failed",
            "message": "Job failed",
            "errorDetail": "timeout",
        },
    )
    assert entry["icon"] == "warning"
    assert "timeout" in entry["message"]


def test_format_session_start_converter():
    set_current_phase("JOB1", PHASE_MIGRATING)
    entry = format_session_start("JOB1", "converter", batch_type="TABLE")
    assert entry["icon"] == "play"
    assert "TABLE" in entry["message"]
    assert entry["phase"] == PHASE_MIGRATING


def test_format_post_tool_use_read():
    root = Path("/workspace/schema-modernization/HRDB")
    entry = format_post_tool_use(
        "JOB1",
        "Read",
        {"file_path": str(root / "state" / "conversion-plan.json")},
        job_root=root,
    )
    assert entry is not None
    assert entry["icon"] == "search"
    assert "Reading state/conversion-plan.json" in entry["message"]


def test_format_post_tool_use_write_sql():
    root = Path("/workspace/schema-modernization/HRDB")
    entry = format_post_tool_use(
        "JOB1",
        "Write",
        {"file_path": str(root / "output" / "tables.sql")},
        job_root=root,
    )
    assert entry is not None
    assert entry["icon"] == "lightning"
    assert entry["message"] == "Writing SQL script: tables.sql"


def test_format_post_tool_use_glob():
    entry = format_post_tool_use("JOB1", "Glob", {"pattern": "**/*.sql"})
    assert entry is not None
    assert "Searching files" in entry["message"]


def test_format_post_tool_use_grep():
    entry = format_post_tool_use(
        "JOB1",
        "Grep",
        {"pattern": "CREATE TABLE", "path": "/tmp/schema.sql"},
    )
    assert entry is not None
    assert "CREATE TABLE" in entry["message"]


def test_format_post_tool_use_skips_progress_json():
    entry = format_post_tool_use(
        "JOB1",
        "Write",
        {"file_path": "/job/state/progress.json"},
    )
    assert entry is None


def test_format_assistant_text_truncates():
    long_text = "word " * 100
    entry = format_assistant_text("JOB1", long_text)
    assert entry is not None
    assert len(entry["message"]) <= 200


def test_format_tool_use_block_read():
    entry = format_tool_use_block("JOB1", "Read", {"file_path": "/job/state/plan.json"})
    assert entry is not None
    assert "plan.json" in entry["message"]


def test_relative_path_from_job_root():
    root = Path("/workspace/schema-modernization/HRDB")
    rel = relative_path(root, str(root / "output" / "tables.sql"))
    assert rel == "output/tables.sql"
