"""Unit tests for Oracle PG Claude session runner initialize-timeout handling."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.services.oracle_pg import agent_runner as runner
from app.services.oracle_pg.agent_runner import (
    _is_initialize_timeout,
    _kill_orphaned_claude_clis,
)


class ResultMessage:
    def __init__(
        self,
        session_id="sess-1",
        subtype="success",
        result="ok",
        total_cost_usd=0.01,
    ):
        self.session_id = session_id
        self.subtype = subtype
        self.result = result
        self.total_cost_usd = total_cost_usd


def _fake_proc(
    proc_root: Path,
    pid: int,
    cmdline: bytes,
    children: list[int],
    cwd: Path | None = None,
) -> None:
    proc_dir = proc_root / str(pid)
    task_dir = proc_dir / "task" / str(pid)
    task_dir.mkdir(parents=True)
    (proc_dir / "cmdline").write_bytes(cmdline)
    (task_dir / "children").write_text(
        " ".join(str(child) for child in children) + ("\n" if children else ""),
        encoding="utf-8",
    )
    if cwd is not None:
        (proc_dir / "cwd").write_text(str(cwd), encoding="utf-8")


BUNDLED_CMDLINE = (
    b"/venv/lib/python3.12/site-packages/claude_agent_sdk/_bundled/claude"
    b"\x00--output-format\x00stream-json"
)


def test_is_initialize_timeout_detects_control_request():
    assert _is_initialize_timeout("Control request timeout: initialize")
    assert _is_initialize_timeout(RuntimeError("Control request timeout: initialize"))
    assert not _is_initialize_timeout("Control request timeout: other")
    assert not _is_initialize_timeout("CLI process exited")
    assert not _is_initialize_timeout(RuntimeError("boom"))


def test_kill_orphaned_claude_clis_only_this_job_workspace(tmp_path):
    proc = tmp_path / "proc"
    job_a = tmp_path / "schema-modernization" / "JOBA"
    job_b = tmp_path / "schema-modernization" / "JOBB"
    job_a.mkdir(parents=True)
    job_b.mkdir(parents=True)

    _fake_proc(proc, 50, b"python\x00worker", [100, 101], cwd=tmp_path)
    _fake_proc(proc, 100, BUNDLED_CMDLINE, [], cwd=job_a)
    _fake_proc(proc, 101, BUNDLED_CMDLINE, [], cwd=job_b)
    _fake_proc(proc, 53, b"/usr/bin/claude\x00--help", [], cwd=job_a)
    _fake_proc(proc, 300, BUNDLED_CMDLINE, [], cwd=job_a)

    killed: list[int] = []
    result = _kill_orphaned_claude_clis(job_a, proc_root=proc, kill_fn=killed.append)

    assert set(result) == {100, 300}
    assert set(killed) == {100, 300}


def test_kill_orphaned_claude_clis_does_not_touch_parallel_job(tmp_path):
    proc = tmp_path / "proc"
    job_a = tmp_path / "schema-modernization" / "JOBA"
    job_b = tmp_path / "schema-modernization" / "JOBB"
    job_a.mkdir(parents=True)
    job_b.mkdir(parents=True)

    _fake_proc(proc, 50, b"python\x00worker", [100, 101], cwd=tmp_path)
    _fake_proc(proc, 100, BUNDLED_CMDLINE, [], cwd=job_a)
    _fake_proc(proc, 101, BUNDLED_CMDLINE, [], cwd=job_b)

    killed: list[int] = []
    result = _kill_orphaned_claude_clis(job_a, proc_root=proc, kill_fn=killed.append)

    assert result == [100]
    assert killed == [100]


@pytest.fixture
def stub_sdk(monkeypatch):
    types_mod = SimpleNamespace(ResultMessage=ResultMessage)
    sdk_mod = SimpleNamespace(types=types_mod)
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", sdk_mod)
    monkeypatch.setitem(sys.modules, "claude_agent_sdk.types", types_mod)
    monkeypatch.setattr(runner, "_build_options", lambda *args, **kwargs: SimpleNamespace())
    monkeypatch.setattr(runner, "append_log_entry", AsyncMock())
    monkeypatch.setattr(runner, "append_sdk_message", AsyncMock())
    return ResultMessage


@pytest.mark.asyncio
async def test_run_agent_session_retries_once_on_initialize_timeout(
    monkeypatch, tmp_path, stub_sdk
):
    calls = {"n": 0}
    killed = {"n": 0}

    async def fake_iter(prompt, options):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("Control request timeout: initialize")
        yield stub_sdk()

    def fake_kill(*_args, **_kwargs):
        killed["n"] += 1
        return [123]

    monkeypatch.setattr(runner, "_iter_sdk_messages", fake_iter)
    monkeypatch.setattr(runner, "_kill_orphaned_claude_clis", fake_kill)
    monkeypatch.setattr(runner.asyncio, "sleep", AsyncMock())

    result = await runner.run_agent_session(
        "JOBRETRY",
        tmp_path,
        {"jobId": "JOBRETRY", "dbName": "HRDB", "targetDatabaseVersion": "16"},
        "initializer",
    )

    assert calls["n"] == 2
    assert killed["n"] == 2
    assert result.success is True
    assert result.session_id == "sess-1"
    assert result.error_message is None
    runner.asyncio.sleep.assert_awaited_once_with(2)


@pytest.mark.asyncio
async def test_run_agent_session_does_not_retry_other_errors(
    monkeypatch, tmp_path, stub_sdk
):
    calls = {"n": 0}

    async def fake_iter(prompt, options):
        calls["n"] += 1
        raise RuntimeError("CLI process exited with code 1")
        yield  # pragma: no cover — keeps this an async generator

    monkeypatch.setattr(runner, "_iter_sdk_messages", fake_iter)

    killed = {"n": 0}

    def cleanup_kill(*_args, **_kwargs):
        killed["n"] += 1
        return []

    monkeypatch.setattr(runner, "_kill_orphaned_claude_clis", cleanup_kill)
    monkeypatch.setattr(runner.asyncio, "sleep", AsyncMock())

    result = await runner.run_agent_session(
        "JOBNORETRY",
        tmp_path,
        {"jobId": "JOBNORETRY", "dbName": "HRDB", "targetDatabaseVersion": "16"},
        "initializer",
    )

    assert calls["n"] == 1
    assert killed["n"] == 1
    assert result.success is False
    assert result.error_message == "CLI process exited with code 1"
    runner.asyncio.sleep.assert_not_awaited()
