"""Unit tests for app.services.oracle_pg.orchestrator.TransformationOrchestrator.

All AI agent sessions, dependency resolution, execution-order application, and
artifact packaging are mocked — no real Claude Agent SDK, filesystem outside
tmp_path, or subprocess is ever invoked.
"""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.services.oracle_pg.orchestrator as orch_mod
from app.services.oracle_pg.agent_runner import SessionResult
from app.services.oracle_pg.orchestrator import (
    TransformationOrchestrator,
    conversion_plan_exists,
)
from app.services.oracle_pg.progress import (
    PHASE_FAILED,
    STATUS_FAILED,
    default_progress,
    load_progress,
    save_progress,
)
from app.services.oracle_pg.workspace import (
    conversion_plan_path,
    job_config_path,
    state_dir,
)


def _write_config(job_id: str, workspace: str, **overrides) -> dict:
    config = {
        "jobId": job_id,
        "dbName": "HRDB",
        "targetDatabaseVersion": "16",
        "selectedRules": ["dbm-oracle-pgsql-001"],
        "ruleScope": "all",
        "claudeWorkspace": workspace,
    }
    config.update(overrides)
    path = job_config_path(job_id, workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config), encoding="utf-8")
    return config


def _write_plan(job_id: str, workspace: str, objects: list[dict]) -> None:
    path = conversion_plan_path(job_id, workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"objects": objects}), encoding="utf-8")


def _make_orchestrator():
    manager = MagicMock()
    manager.clear_running = MagicMock()
    return TransformationOrchestrator(manager), manager


# ---------------------------------------------------------------------------
# run() — missing config
# ---------------------------------------------------------------------------
async def test_run_missing_config_logs_and_returns(tmp_path, monkeypatch):
    monkeypatch.setattr(orch_mod, "discover_workspace_override", lambda job_id: str(tmp_path))
    orchestrator, manager = _make_orchestrator()

    await orchestrator.run("NOPE")

    manager.clear_running.assert_called_once_with("NOPE")


# ---------------------------------------------------------------------------
# run() — full happy path (single object, all phases mocked)
# ---------------------------------------------------------------------------
async def test_run_full_happy_path(tmp_path, monkeypatch):
    job_id = "ORCHTEST01"
    workspace = str(tmp_path)
    monkeypatch.setattr(orch_mod, "discover_workspace_override", lambda jid: workspace)

    _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [
        {"objectId": "T1", "type": "TABLE", "schema": "HR", "name": "ORDERS", "status": "pending"}
    ])
    save_progress(job_id, default_progress(job_id))

    async def fake_session(jid, root, config, kind, *, batch_type=None, resume_session_id=None):
        if kind == "converter":
            plan_path = conversion_plan_path(jid, workspace)
            data = json.loads(plan_path.read_text(encoding="utf-8"))
            data["objects"][0]["status"] = "converted"
            data["objects"][0]["conversionStatus"] = "auto_converted"
            plan_path.write_text(json.dumps(data), encoding="utf-8")
        return SessionResult(success=True, session_id="sess-1", subtype="success")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: True)
    monkeypatch.setattr(orch_mod, "resolve_dependencies", MagicMock())
    monkeypatch.setattr(orch_mod, "apply_execution_order", MagicMock())
    monkeypatch.setattr(orch_mod, "package_all_artifacts", MagicMock())
    monkeypatch.setattr(orch_mod, "list_artifacts", lambda jid, db, workspace_override=None: [])

    orchestrator, manager = _make_orchestrator()
    await orchestrator.run(job_id)

    progress = load_progress(job_id)
    assert progress["status"] == "completed"
    assert progress["phase"] == "Completed"
    assert progress["progressPercent"] == 100
    manager.clear_running.assert_called_once_with(job_id)


# ---------------------------------------------------------------------------
# run() — initializer failure marks job failed
# ---------------------------------------------------------------------------
async def test_run_initializer_failure_marks_failed(tmp_path, monkeypatch):
    job_id = "ORCHFAIL01"
    workspace = str(tmp_path)
    monkeypatch.setattr(orch_mod, "discover_workspace_override", lambda jid: workspace)

    _write_config(job_id, workspace)
    save_progress(job_id, default_progress(job_id))

    async def fake_session(jid, root, config, kind, *, batch_type=None, resume_session_id=None):
        return SessionResult(success=False, error_message="initializer exploded")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: False)

    orchestrator, manager = _make_orchestrator()
    await orchestrator.run(job_id)

    progress = load_progress(job_id)
    assert progress["status"] == STATUS_FAILED
    assert progress["phase"] == PHASE_FAILED
    assert progress["errorDetail"] == "initializer exploded"
    manager.clear_running.assert_called_once_with(job_id)


async def test_run_converter_failure_marks_failed(tmp_path, monkeypatch):
    job_id = "ORCHFAIL02"
    workspace = str(tmp_path)
    monkeypatch.setattr(orch_mod, "discover_workspace_override", lambda jid: workspace)

    _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [
        {"objectId": "T1", "type": "TABLE", "schema": "HR", "name": "ORDERS", "status": "pending"}
    ])
    save_progress(job_id, default_progress(job_id))

    async def fake_session(jid, root, config, kind, *, batch_type=None, resume_session_id=None):
        if kind == "converter":
            return SessionResult(success=False, error_message="converter boom")
        return SessionResult(success=True, session_id="sess-1", subtype="success")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: True)

    orchestrator, manager = _make_orchestrator()
    await orchestrator.run(job_id)

    progress = load_progress(job_id)
    assert progress["status"] == STATUS_FAILED
    assert progress["errorDetail"] == "converter boom"


# ---------------------------------------------------------------------------
# _phase_initialize — compass input mode
# ---------------------------------------------------------------------------
async def test_phase_initialize_compass_mode_builds_plan(tmp_path, monkeypatch):
    job_id = "COMPASSUNIT01"
    workspace = str(tmp_path)
    config = _write_config(
        job_id, workspace,
        inputMode="compass_files",
        inputPaths={"asisSchema": "a", "incompatibilityResults": "b",
                    "rulesRemediation": "c", "ddlExport": "d"},
    )
    save_progress(job_id, default_progress(job_id))

    orchestrator, _ = _make_orchestrator()
    monkeypatch.setattr(orchestrator, "_build_plan_from_compass",
                        lambda jid, cfg: [{"objectId": "O1", "type": "TABLE", "status": "pending"}])
    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: False)

    root = tmp_path
    await orchestrator._phase_initialize(job_id, root, config, workspace)

    progress = load_progress(job_id)
    assert progress["objectsTotal"] == 0 or progress["phase"] == "Schema Analysis"


async def test_phase_initialize_skips_when_plan_exists(tmp_path, monkeypatch):
    job_id = "SKIPINIT01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [{"objectId": "O1", "type": "TABLE", "status": "converted"}])
    save_progress(job_id, default_progress(job_id))

    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: True)
    session_mock = AsyncMock()
    monkeypatch.setattr(orch_mod, "run_agent_session", session_mock)

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_initialize(job_id, tmp_path, config, workspace)

    session_mock.assert_not_awaited()


async def test_phase_initialize_bootstraps_from_assessment(tmp_path, monkeypatch):
    job_id = "BOOTSTRAP01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    save_progress(job_id, default_progress(job_id))

    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: False)

    async def fake_session(jid, root, cfg, kind, *, batch_type=None, resume_session_id=None):
        return SessionResult(success=True)

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)

    orchestrator, _ = _make_orchestrator()
    bootstrap_mock = MagicMock()
    monkeypatch.setattr(orchestrator, "_bootstrap_plan_from_assessment", bootstrap_mock)

    await orchestrator._phase_initialize(job_id, tmp_path, config, workspace)

    bootstrap_mock.assert_called_once_with(job_id, config, workspace)


async def test_phase_initialize_raises_on_initializer_failure(tmp_path, monkeypatch):
    job_id = "INITFAIL01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    save_progress(job_id, default_progress(job_id))

    monkeypatch.setattr(orch_mod, "conversion_plan_exists", lambda jid, workspace_override=None: False)

    async def fake_session(jid, root, cfg, kind, *, batch_type=None, resume_session_id=None):
        return SessionResult(success=False, error_message=None)

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)

    orchestrator, _ = _make_orchestrator()
    with pytest.raises(RuntimeError, match="Initializer session failed"):
        await orchestrator._phase_initialize(job_id, tmp_path, config, workspace)


# ---------------------------------------------------------------------------
# _phase_environment
# ---------------------------------------------------------------------------
async def test_phase_environment_writes_context(tmp_path):
    job_id = "ENVTEST01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    save_progress(job_id, default_progress(job_id))

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_environment(job_id, config, workspace)

    ctx_path = state_dir(job_id, workspace) / "pg_version_context.json"
    assert ctx_path.exists()
    ctx = json.loads(ctx_path.read_text(encoding="utf-8"))
    assert ctx["dbName"] == "HRDB"


# ---------------------------------------------------------------------------
# _phase_migrate — MAX_CONVERTER_SESSIONS guard
# ---------------------------------------------------------------------------
async def test_phase_migrate_stops_at_max_sessions(tmp_path, monkeypatch):
    job_id = "MAXSESS01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [
        {"objectId": "T1", "type": "TABLE", "schema": "HR", "name": "ORDERS", "status": "pending"}
    ])
    save_progress(job_id, default_progress(job_id))

    monkeypatch.setattr(orch_mod, "MAX_CONVERTER_SESSIONS", 2)

    async def fake_session(jid, root, cfg, kind, *, batch_type=None, resume_session_id=None):
        # Never marks the object converted -> batch stays pending forever.
        return SessionResult(success=True)

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_migrate(job_id, tmp_path, config, workspace)

    progress = load_progress(job_id)
    assert progress["sessionsCompleted"] == 2


async def test_phase_migrate_no_pending_batches_completes_immediately(tmp_path):
    job_id = "NOPENDING01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [
        {"objectId": "T1", "type": "TABLE", "status": "converted", "conversionStatus": "auto_converted"}
    ])
    save_progress(job_id, default_progress(job_id))

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_migrate(job_id, tmp_path, config, workspace)

    progress = load_progress(job_id)
    assert progress["sessionsCompleted"] == 0


# ---------------------------------------------------------------------------
# _mark_batch_converted
# ---------------------------------------------------------------------------
def test_mark_batch_converted_sets_defaults(tmp_path):
    job_id = "MARKBATCH01"
    workspace = str(tmp_path)
    _write_plan(job_id, workspace, [
        {"objectId": "O1", "type": "TABLE", "status": "pending"},
        {"objectId": "O2", "type": "VIEW", "status": "pending"},
    ])

    orchestrator, _ = _make_orchestrator()
    orchestrator._mark_batch_converted(job_id, "TABLE", workspace)

    plan = json.loads(conversion_plan_path(job_id, workspace).read_text(encoding="utf-8"))
    obj1 = next(o for o in plan["objects"] if o["objectId"] == "O1")
    obj2 = next(o for o in plan["objects"] if o["objectId"] == "O2")
    assert obj1["status"] == "converted"
    assert obj1["conversionStatus"] == "require_review"
    assert obj1["requiresManualReview"] is True
    assert obj2["status"] == "pending"


def test_mark_batch_converted_low_confidence_flags_manual_review(tmp_path):
    job_id = "MARKBATCH02"
    workspace = str(tmp_path)
    _write_plan(job_id, workspace, [
        {
            "objectId": "O1", "type": "FUNCTION", "status": "pending",
            "expectedConversionStatus": "auto_converted",
            "confidenceScore": "LOW",
        },
    ])

    orchestrator, _ = _make_orchestrator()
    orchestrator._mark_batch_converted(job_id, "FUNCTION", workspace)

    plan = json.loads(conversion_plan_path(job_id, workspace).read_text(encoding="utf-8"))
    obj = plan["objects"][0]
    assert obj["conversionStatus"] == "auto_converted"
    assert obj["requiresManualReview"] is True


def test_mark_batch_converted_missing_plan_noop(tmp_path):
    job_id = "MARKBATCH03"
    workspace = str(tmp_path)
    orchestrator, _ = _make_orchestrator()
    orchestrator._mark_batch_converted(job_id, "TABLE", workspace)  # no raise, no file


def test_mark_batch_converted_no_change_noop(tmp_path):
    job_id = "MARKBATCH04"
    workspace = str(tmp_path)
    _write_plan(job_id, workspace, [
        {"objectId": "O1", "type": "TABLE", "status": "converted"},
    ])
    path = conversion_plan_path(job_id, workspace)
    before = path.read_text(encoding="utf-8")

    orchestrator, _ = _make_orchestrator()
    orchestrator._mark_batch_converted(job_id, "TABLE", workspace)

    assert path.read_text(encoding="utf-8") == before


# ---------------------------------------------------------------------------
# _phase_resolve_dependencies / _phase_apply_execution_order
# ---------------------------------------------------------------------------
async def test_phase_resolve_dependencies_calls_resolver(tmp_path, monkeypatch):
    job_id = "RESOLVE01"
    workspace = str(tmp_path)
    save_progress(job_id, default_progress(job_id))
    _write_plan(job_id, workspace, [])

    mock_resolve = MagicMock()
    monkeypatch.setattr(orch_mod, "resolve_dependencies", mock_resolve)

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_resolve_dependencies(job_id, workspace)

    mock_resolve.assert_called_once_with(job_id, workspace)
    progress = load_progress(job_id)
    assert progress["phase"] == "Dependency Resolution"


async def test_phase_apply_execution_order_calls_helper(tmp_path, monkeypatch):
    job_id = "ORDER01"
    workspace = str(tmp_path)
    save_progress(job_id, default_progress(job_id))
    _write_plan(job_id, workspace, [])

    mock_order = MagicMock()
    monkeypatch.setattr(orch_mod, "apply_execution_order", mock_order)

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_apply_execution_order(job_id, workspace)

    mock_order.assert_called_once_with(job_id, workspace)
    progress = load_progress(job_id)
    assert progress["phase"] == "Execution Order Application"


# ---------------------------------------------------------------------------
# _phase_artifacts
# ---------------------------------------------------------------------------
async def test_phase_artifacts_completes_job(tmp_path, monkeypatch):
    job_id = "ARTIFACTS01"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [
        {"objectId": "O1", "type": "TABLE", "status": "converted"}
    ])
    save_progress(job_id, default_progress(job_id))

    async def fake_session(jid, root, cfg, kind, *, batch_type=None, resume_session_id=None):
        return SessionResult(success=True)

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(orch_mod, "package_all_artifacts", MagicMock())
    monkeypatch.setattr(orch_mod, "list_artifacts", lambda jid, db, workspace_override=None: ["a.zip"])

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_artifacts(job_id, tmp_path, config, workspace)

    progress = load_progress(job_id)
    assert progress["status"] == "completed"
    assert progress["phase"] == "Completed"
    assert progress["progressPercent"] == 100
    assert progress["artifacts"] == ["a.zip"]
    assert progress["completedAt"] is not None


async def test_phase_artifacts_logs_warning_on_agent_failure(tmp_path, monkeypatch, caplog):
    job_id = "ARTIFACTS02"
    workspace = str(tmp_path)
    config = _write_config(job_id, workspace)
    _write_plan(job_id, workspace, [])
    save_progress(job_id, default_progress(job_id))

    async def fake_session(jid, root, cfg, kind, *, batch_type=None, resume_session_id=None):
        return SessionResult(success=False, error_message="artifact gen issue")

    monkeypatch.setattr(orch_mod, "run_agent_session", fake_session)
    monkeypatch.setattr(orch_mod, "package_all_artifacts", MagicMock())
    monkeypatch.setattr(orch_mod, "list_artifacts", lambda jid, db, workspace_override=None: [])

    orchestrator, _ = _make_orchestrator()
    await orchestrator._phase_artifacts(job_id, tmp_path, config, workspace)

    progress = load_progress(job_id)
    # Job still completes even when artifact agent reports issues.
    assert progress["status"] == "completed"


# ---------------------------------------------------------------------------
# _bootstrap_plan_from_assessment
# ---------------------------------------------------------------------------
def test_bootstrap_plan_from_assessment_no_file_noop(tmp_path):
    job_id = "NOASSESS01"
    workspace = str(tmp_path)
    orchestrator, _ = _make_orchestrator()
    orchestrator._bootstrap_plan_from_assessment(job_id, {}, workspace)
    assert not conversion_plan_path(job_id, workspace).exists()


def test_bootstrap_plan_from_assessment_builds_plan_dict_wrapped(tmp_path):
    job_id = "ASSESSDICT01"
    workspace = str(tmp_path)
    from app.services.oracle_pg.workspace import input_dir

    assessment_dir = input_dir(job_id, workspace)
    assessment_dir.mkdir(parents=True)
    assessment = {
        "objects": [
            {"type": "table", "schema": "HR", "name": "EMP", "classification": "SC",
             "complexity": "low", "ruleIds": ["r1"]},
        ]
    }
    (assessment_dir / "assessment.json").write_text(json.dumps(assessment), encoding="utf-8")

    orchestrator, _ = _make_orchestrator()
    orchestrator._bootstrap_plan_from_assessment(job_id, {}, workspace)

    plan = json.loads(conversion_plan_path(job_id, workspace).read_text(encoding="utf-8"))
    assert len(plan["objects"]) == 1
    obj = plan["objects"][0]
    assert obj["objectId"] == "OBJ_0001"
    assert obj["type"] == "TABLE"
    assert obj["outputFile"] == "create_tables.sql"


def test_bootstrap_plan_from_assessment_builds_plan_bare_list(tmp_path):
    job_id = "ASSESSLIST01"
    workspace = str(tmp_path)
    from app.services.oracle_pg.workspace import input_dir

    assessment_dir = input_dir(job_id, workspace)
    assessment_dir.mkdir(parents=True)
    assessment = [
        {"type": "VIEW", "schema": "HR", "name": "V1", "classification": "MC", "complexity": "high"},
    ]
    (assessment_dir / "assessment.json").write_text(json.dumps(assessment), encoding="utf-8")

    orchestrator, _ = _make_orchestrator()
    orchestrator._bootstrap_plan_from_assessment(job_id, {}, workspace)

    plan = json.loads(conversion_plan_path(job_id, workspace).read_text(encoding="utf-8"))
    assert plan["objects"][0]["objectId"] == "OBJ_0001"
    assert plan["objects"][0]["type"] == "VIEW"


def test_bootstrap_plan_from_assessment_non_list_objects_noop(tmp_path):
    job_id = "ASSESSBAD01"
    workspace = str(tmp_path)
    from app.services.oracle_pg.workspace import input_dir

    assessment_dir = input_dir(job_id, workspace)
    assessment_dir.mkdir(parents=True)
    (assessment_dir / "assessment.json").write_text(
        json.dumps({"objects": "not-a-list"}), encoding="utf-8"
    )

    orchestrator, _ = _make_orchestrator()
    orchestrator._bootstrap_plan_from_assessment(job_id, {}, workspace)

    assert not conversion_plan_path(job_id, workspace).exists()


# ---------------------------------------------------------------------------
# _build_plan_from_compass
# ---------------------------------------------------------------------------
def test_build_plan_from_compass_invokes_input_adapter(tmp_path, monkeypatch):
    job_id = "COMPASSPLAN01"
    workspace = str(tmp_path)
    config = _write_config(
        job_id, workspace,
        inputPaths={
            "asisSchema": "asis.json",
            "incompatibilityResults": "incompat.json",
            "rulesRemediation": "remediation.json",
            "ddlExport": "schema.sql",
            "schemaAnalysis": "schema_analysis.json",
        },
        ruleScope="all",
        selectedRules=["r1"],
    )

    fake_plan = [{"objectId": "O1", "type": "TABLE", "status": "pending"}]
    monkeypatch.setattr(
        orch_mod, "build_plan_from_compass_files",
        lambda *a, **k: (fake_plan, {"r1": {}}, [], ["warn1"]),
    )
    write_norm = MagicMock()
    write_remediation = MagicMock()
    write_skipped = MagicMock()
    monkeypatch.setattr(orch_mod, "write_normalized_assessment", write_norm)
    monkeypatch.setattr(orch_mod, "write_remediation_index", write_remediation)
    monkeypatch.setattr(orch_mod, "write_skipped_objects", write_skipped)

    orchestrator, _ = _make_orchestrator()
    result = orchestrator._build_plan_from_compass(job_id, config)

    assert result == fake_plan
    plan_on_disk = json.loads(conversion_plan_path(job_id, workspace).read_text(encoding="utf-8"))
    assert plan_on_disk["objects"] == fake_plan
    assert plan_on_disk["assemblyWarnings"] == ["warn1"]
    write_norm.assert_called_once()
    write_remediation.assert_called_once()
    write_skipped.assert_not_called()


def test_build_plan_from_compass_with_skipped_objects(tmp_path, monkeypatch):
    job_id = "COMPASSSKIP01"
    workspace = str(tmp_path)
    config = _write_config(
        job_id, workspace,
        inputPaths={
            "asisSchema": "asis.json",
            "incompatibilityResults": "incompat.json",
            "rulesRemediation": "remediation.json",
            "ddlExport": "schema.sql",
        },
    )

    monkeypatch.setattr(
        orch_mod, "build_plan_from_compass_files",
        lambda *a, **k: ([], {}, [{"objectId": "SKIP1"}], []),
    )
    monkeypatch.setattr(orch_mod, "write_normalized_assessment", MagicMock())
    monkeypatch.setattr(orch_mod, "write_remediation_index", MagicMock())
    write_skipped = MagicMock()
    monkeypatch.setattr(orch_mod, "write_skipped_objects", write_skipped)

    orchestrator, _ = _make_orchestrator()
    orchestrator._build_plan_from_compass(job_id, config)

    write_skipped.assert_called_once()


# ---------------------------------------------------------------------------
# conversion_plan_exists
# ---------------------------------------------------------------------------
def test_conversion_plan_exists_true(tmp_path):
    job_id = "PLANEXISTS01"
    workspace = str(tmp_path)
    _write_plan(job_id, workspace, [])
    assert conversion_plan_exists(job_id, workspace) is True


def test_conversion_plan_exists_false(tmp_path):
    job_id = "PLANEXISTS02"
    workspace = str(tmp_path)
    assert conversion_plan_exists(job_id, workspace) is False
