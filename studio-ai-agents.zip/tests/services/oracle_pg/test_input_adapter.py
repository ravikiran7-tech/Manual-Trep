"""Tests for Compass JSON input adapter."""
from pathlib import Path

import pytest

from app.services.oracle_pg.input_adapter import (
    aggregate_incompatibilities,
    aggregate_incompatibilities_detailed,
    attach_remediations,
    build_conversion_plan,
    build_plan_from_compass_files,
    load_asis_objects,
    load_remediation_catalog,
    normalize_object_type,
)

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures" / "oracle_pg"


@pytest.fixture
def asis_path():
    return FIXTURES / "oracle-dbschema-asis.json"


@pytest.fixture
def incompat_path():
    return FIXTURES / "oracle-to-postgresql-incompatability-results.json"


@pytest.fixture
def remediation_path():
    return FIXTURES / "oracle-to-postgresql-rules_remediation.json"


def test_normalize_object_type_aliases():
    assert normalize_object_type("STORED_PROCEDURE") == "PROCEDURE"
    assert normalize_object_type("GLOBAL_TEMPORARY_TABLE") == "TABLE"
    assert normalize_object_type("table") == "TABLE"
    assert normalize_object_type(None, "sequences") == "SEQUENCE"


def test_load_asis_objects_counts(asis_path):
    objects = load_asis_objects(asis_path)
    assert len(objects) >= 60
    types = {obj["type"] for obj in objects}
    assert "TABLE" in types
    assert "PROCEDURE" in types
    assert "TRIGGER" in types


def test_load_remediation_catalog(remediation_path):
    catalog = load_remediation_catalog(remediation_path)
    assert len(catalog) >= 60
    sample = catalog["ASSESS-ORACLE-PG-006"]
    assert sample["remediation"]["remediationId"] == "REM-ORACLE-PG-006"
    assert sample["remediation"]["description"]


def test_aggregate_incompatibilities_worst_case(incompat_path):
    grouped = aggregate_incompatibilities(incompat_path)
    assert len(grouped) > 0
    key = ("app", "customers", "TABLE")
    assert key in grouped
    assert grouped[key]["classification"] in ("SC", "NS", "DS")
    assert grouped[key]["ruleIds"]


def test_aggregate_incompatibilities_detailed_preserves_rows(incompat_path):
    detailed = aggregate_incompatibilities_detailed(incompat_path)
    key = ("app", "customers", "TABLE")
    assert key in detailed
    assert len(detailed[key]) >= 1
    assert detailed[key][0]["ruleId"]
    assert "affectedElement" in detailed[key][0]


def test_attach_remediations_missing_rule_raises(remediation_path):
    catalog = load_remediation_catalog(remediation_path)
    with pytest.raises(ValueError, match="No remediation found"):
        attach_remediations([{"ruleId": "ASSESS-ORACLE-PG-MISSING"}], catalog)


def test_build_plan_includes_remediations_per_object(asis_path, incompat_path, remediation_path):
    plan, _catalog_subset, _skipped, _warnings = build_plan_from_compass_files(
        asis_path, incompat_path, remediation_path
    )
    customer = next(
        (
            o
            for o in plan
            if o["schema"] == "app" and o["name"] == "customers" and o["type"] == "TABLE"
        ),
        None,
    )
    assert customer is not None
    assert customer["incompatibilities"]
    remediation_ids = {inc["remediation"]["remediationId"] for inc in customer["incompatibilities"]}
    assert "REM-ORACLE-PG-006" in remediation_ids
    assert "REM-ORACLE-PG-011" in remediation_ids


def test_build_plan_from_compass_files(asis_path, incompat_path, remediation_path):
    plan, catalog_subset, skipped, warnings = build_plan_from_compass_files(
        asis_path, incompat_path, remediation_path
    )
    assert len(plan) >= 73
    schemas = [obj for obj in plan if obj["type"] == "SCHEMA"]
    defaults = [obj for obj in plan if obj["type"] == "DEFAULT"]
    assert len(schemas) >= 1
    assert len(defaults) >= 10
    for obj in plan:
        assert obj["status"] == "pending"
        assert obj["expectedConversionStatus"] in (
            "auto_converted",
            "require_review",
            "manual_implementation",
        )
    assert catalog_subset


def test_build_plan_seeds_metadata_fields(asis_path, incompat_path, remediation_path):
    plan, _, _, _ = build_plan_from_compass_files(asis_path, incompat_path, remediation_path)
    sample = plan[0]
    assert "confidenceScore" in sample
    assert "requiresManualReview" in sample
    assert "changes" in sample
    assert sample["outputFile"].startswith("create_")


def test_build_plan_splits_constraint_subtypes(asis_path):
    objects = load_asis_objects(asis_path)
    pk_types = {o["type"] for o in objects if o.get("sourceSection") == "constraints"}
    assert "PRIMARY_KEY" in pk_types or "CHECK" in pk_types
    assert "DEFAULT" in pk_types


def test_default_constraints_receive_table_default_remediations(
    asis_path, incompat_path, remediation_path
):
    plan, _, _, _ = build_plan_from_compass_files(
        asis_path, incompat_path, remediation_path
    )
    default_obj = next(
        (
            o
            for o in plan
            if o["type"] == "DEFAULT"
            and o["schema"] == "app"
            and o["name"] == "DF_customers_customer_id"
        ),
        None,
    )
    assert default_obj is not None
    assert default_obj["owningTable"] == "customers"
    remediation_ids = {
        inc.get("remediation", {}).get("remediationId")
        for inc in default_obj.get("incompatibilities", [])
    }
    assert "REM-ORACLE-PG-011" in remediation_ids or "REM-ORACLE-PG-015" in remediation_ids


def test_build_conversion_plan_merges_classification(asis_path, incompat_path, remediation_path):
    asis = load_asis_objects(asis_path)
    incompat = aggregate_incompatibilities(incompat_path)
    details = aggregate_incompatibilities_detailed(incompat_path)
    catalog = load_remediation_catalog(remediation_path)
    plan = build_conversion_plan(
        asis,
        incompat,
        incompat_details=details,
        remediation_catalog=catalog,
        include_schemas=True,
    )
    customer = next(
        (
            o
            for o in plan
            if o["schema"] == "app" and o["name"] == "customers" and o["type"] == "TABLE"
        ),
        None,
    )
    assert customer is not None
    assert customer["classification"] in ("SC", "NS", "DS")
    assert customer["ruleIds"]
    assert customer["incompatibilities"]
