"""Tests for Pass 3 execution order."""

from app.services.oracle_pg.execution_order import _topological_sort


def test_topological_sort_orders_dependencies():
    names = ["child", "parent"]
    edges = {"child": {"parent"}}
    ordered = _topological_sort(names, edges)
    assert ordered.index("parent") < ordered.index("child")


def test_topological_sort_handles_cycles_gracefully():
    names = ["a", "b"]
    edges = {"a": {"b"}, "b": {"a"}}
    ordered = _topological_sort(names, edges)
    assert len(ordered) == 2
