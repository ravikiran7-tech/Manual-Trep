"""Tests for Oracle PG transformation agent prompts."""

from app.services.oracle_pg.prompts import converter_prompt


def test_converter_prompt_scopes_to_single_batch():
    config = {
        "jobId": "JOB01",
        "dbName": "HRDB",
        "targetDatabaseVersion": "16",
        "inputPaths": {"ddlExport": "_claude/schema.sql"},
    }
    prompt = converter_prompt(config, "TABLE")

    assert 'THIS SESSION ASSIGNED BATCH: TABLE' in prompt
    assert "HRDB_create_tables.sql" in prompt
    assert 'type is "TABLE"' in prompt
    assert "Do NOT convert, mark converted, or write SQL for any other object type" in prompt
    assert "Do NOT write or edit state/progress.json" in prompt
    assert "HRDB_create_procedures.sql" not in prompt
    assert "HRDB_00_README.txt" in prompt  # forbidden deliverable named explicitly


def test_converter_prompt_uses_batch_output_script():
    config = {
        "jobId": "JOB02",
        "dbName": "DB0090",
        "targetDatabaseVersion": "16",
    }
    prompt = converter_prompt(config, "PROCEDURE")

    assert "DB0090_create_procedures.sql" in prompt
    assert "Write or append SQL ONLY to output/DB0090_create_procedures.sql" in prompt
