"""Tests for artifact packager script normalization and reporting."""
import json

from app.services.oracle_pg.report_metrics import REPORT_OBJECT_TYPE_ORDER
from app.services.oracle_pg.artifact_packager import (
    _format_source_location_for_display,
    _review_reason,
    build_complete_schema,
    build_manual_review_checklist,
    build_post_transformation_report,
    build_transformation_summary,
    normalize_output_scripts,
    write_manual_review_csv,
    write_report,
)


def test_normalize_output_scripts_renames_unprefixed(tmp_path, monkeypatch):
    job_id = "PKG01"
    db_name = "HRDB"
    out = tmp_path / "schema-modernization" / job_id / "output"
    out.mkdir(parents=True)
    (out / "create_tables.sql").write_text("CREATE TABLE t (id int);", encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )

    renamed = normalize_output_scripts(job_id, db_name)
    assert renamed == ["HRDB_create_tables.sql"]
    assert (out / "HRDB_create_tables.sql").exists()


def test_normalize_legacy_script_names(tmp_path, monkeypatch):
    job_id = "LEG01"
    db_name = "HRDB"
    out = tmp_path / "schema-modernization" / job_id / "output"
    out.mkdir(parents=True)
    (out / "04_tables.sql").write_text("CREATE TABLE t (id int);", encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )

    renamed = normalize_output_scripts(job_id, db_name)
    assert "HRDB_create_tables.sql" in renamed


def test_build_report_includes_input_sources(tmp_path, monkeypatch):
    job_id = "RPT01"
    state = tmp_path / "schema-modernization" / job_id / "state"
    state.mkdir(parents=True)
    plan = {
        "objects": [
            {
                "objectId": "T1",
                "type": "TABLE",
                "schema": "app",
                "name": "orders",
                "status": "converted",
                "conversionStatus": "auto_converted",
                "expectedConversionStatus": "auto_converted",
                "confidenceScore": "HIGH",
                "outputFile": "create_tables.sql",
            }
        ]
    }
    (state / "conversion-plan.json").write_text(json.dumps(plan), encoding="utf-8")
    (state / "progress.json").write_text(
        json.dumps({"startedAt": "2026-01-01T00:00:00+00:00", "updatedAt": "2026-01-01T01:00:00+00:00"}),
        encoding="utf-8",
    )

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.conversion_plan_path",
        lambda jid, override=None: state / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.progress.progress_path",
        lambda jid, override=None: state / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.load_progress",
        lambda jid: json.loads((state / "progress.json").read_text(encoding="utf-8")),
    )

    config = {
        "inputPaths": {
            "ddlExport": "_claude/schema.sql",
            "asisSchema": "_claude/asis.json",
        }
    }
    report = build_post_transformation_report(job_id, "HRDB", job_config=config)
    assert report["inputSources"]["ddlExport"] == "_claude/schema.sql"
    assert "conversionSummaryByType" in report
    assert "timing" in report


def test_format_source_location_strips_directory():
    assert (
        _format_source_location_for_display("_claude/Oracle_Complex_Schema 4.sql:42-87")
        == "Oracle_Complex_Schema 4.sql:42-87"
    )
    assert _format_source_location_for_display("schema.sql:10-20") == "schema.sql:10-20"


def test_manual_review_csv_includes_low_confidence(tmp_path, monkeypatch):
    job_id = "CSV01"
    state = tmp_path / "schema-modernization" / job_id / "state"
    state.mkdir(parents=True)
    plan = [
        {
            "schema": "app",
            "name": "proc1",
            "type": "PROCEDURE",
            "status": "converted",
            "confidenceScore": "LOW",
            "requiresManualReview": True,
            "reviewGuidance": "Verify transaction boundaries",
            "sourceLocation": "_claude/schema.sql:10-20",
            "outputFile": "create_procedures.sql",
        },
        {
            "schema": "app",
            "name": "t1",
            "type": "TABLE",
            "status": "converted",
            "confidenceScore": "HIGH",
            "requiresManualReview": False,
            "outputFile": "create_tables.sql",
        },
    ]
    (state / "conversion-plan.json").write_text(json.dumps({"objects": plan}), encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.conversion_plan_path",
        lambda jid, override=None: state / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )

    rows = build_manual_review_checklist(plan, "HRDB")
    assert len(rows) == 1
    assert rows[0]["Source Object"] == "app.proc1"
    assert rows[0]["Confidence"] == "LOW"
    assert rows[0]["Source Location"] == "schema.sql:10-20"

    path = write_manual_review_csv(job_id, "HRDB")
    assert path.exists()
    content = path.read_text(encoding="utf-8")
    assert "Review Reason" in content
    assert "_claude/" not in content
    assert "schema.sql:10-20" in content

    saved_plan = json.loads((state / "conversion-plan.json").read_text(encoding="utf-8"))
    assert saved_plan["objects"][0]["sourceLocation"] == "_claude/schema.sql:10-20"


def test_review_reason_accepts_string_and_object_changes():
    reason = _review_reason(
        {
            "reviewGuidance": "Verify column types",
            "changes": [
                {
                    "changeType": "TYPE_MAP",
                    "description": "NUMBER -> NUMERIC",
                    "requiresReview": True,
                },
                {
                    "changeType": "NOISE",
                    "description": "should be skipped",
                    "requiresReview": False,
                },
                "CHAR(3) -> CHAR(3) [REM-ASSESS-ORACLE-PG-058-001]",
                "  ",
                None,
            ],
        }
    )
    assert reason == (
        "Verify column types; NUMBER -> NUMERIC; "
        "CHAR(3) -> CHAR(3) [REM-ASSESS-ORACLE-PG-058-001]"
    )

    rows = build_manual_review_checklist(
        [
            {
                "schema": "b",
                "name": "currency",
                "type": "TABLE",
                "status": "converted",
                "confidenceScore": "HIGH",
                "requiresManualReview": True,
                "changes": [
                    "VARCHAR2(60) -> VARCHAR(60) [REM-ASSESS-ORACLE-PG-059-001]",
                ],
                "outputFile": "create_tables.sql",
            }
        ],
        "DB0125",
    )
    assert len(rows) == 1
    assert "VARCHAR2(60) -> VARCHAR(60)" in rows[0]["Review Reason"]


def test_build_complete_schema_concatenates_phases(tmp_path, monkeypatch):
    job_id = "CPL01"
    db_name = "HRDB"
    out = tmp_path / "schema-modernization" / job_id / "output"
    out.mkdir(parents=True)
    (out / f"{db_name}_create_schemas.sql").write_text("-- schema", encoding="utf-8")
    (out / f"{db_name}_create_tables.sql").write_text("CREATE TABLE t (id int);", encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )

    path = build_complete_schema(job_id, db_name)
    text = path.read_text(encoding="utf-8")
    assert "CREATE SCHEMAS" in text
    assert "PHASE" not in text
    assert "CREATE TABLE t" in text


def test_transformation_summary_math():
    plan = [
        {
            "type": "TABLE",
            "status": "converted",
            "conversionStatus": "auto_converted",
            "confidenceScore": "HIGH",
            "requiresManualReview": False,
        },
        {
            "type": "PROCEDURE",
            "status": "converted",
            "conversionStatus": "manual_implementation",
            "confidenceScore": "MANUAL",
            "requiresManualReview": True,
        },
    ]
    summary = build_transformation_summary(
        plan,
        {"sourceDatabaseVersion": "Oracle 19c", "targetDatabaseVersion": "16"},
        "HRDB",
    )
    assert summary["conversionResult"]["total_objects"] == 2
    assert summary["conversionResult"]["converted"] == 2
    assert summary["conversionResult"]["deliverable_converted"] == 2
    assert summary["conversionResult"]["conversion_rate"] == "100%"
    assert summary["conversionResult"]["auto_conversion_rate"] == "50%"
    assert summary["reviewNeeded"]["objects_requiring_review"] == 1
    assert summary["reviewNeeded"]["manual_follow_up_required"] == 1
    assert summary["reviewNeeded"]["could_not_convert"] == 0


def test_transformation_summary_includes_ac_fields():
    plan = [
        {
            "type": "TABLE",
            "status": "converted",
            "conversionStatus": "auto_converted",
            "confidenceScore": "HIGH",
        },
        {
            "type": "PROCEDURE",
            "status": "converted",
            "conversionStatus": "require_review",
            "confidenceScore": "MEDIUM",
        },
    ]
    progress = {
        "startedAt": "2026-01-01T00:00:00+00:00",
        "completedAt": "2026-01-01T00:30:00+00:00",
    }
    job_config = {
        "jobId": "SUM01",
        "sourceDatabaseVersion": "Oracle 19c",
        "targetDatabaseVersion": "16",
    }
    summary = build_transformation_summary(
        plan,
        job_config,
        "HRDB",
        progress=progress,
        job_id="SUM01",
    )
    assert summary["timing"]["durationSeconds"] == 1800
    assert summary["timing"]["duration"] == "30m"
    assert summary["executiveSummary"]["successfullyConverted"] == 1
    assert summary["executiveSummary"]["requiresReview"] == 1
    assert summary["executiveSummary"]["totalObjects"] == 2
    assert len(summary["objectsByType"]) == len(REPORT_OBJECT_TYPE_ORDER)
    assert summary["confidenceBreakdown"]["high"] == 1
    assert summary["confidenceBreakdown"]["medium"] == 1
    assert "databaseMetadata" in summary
    assert "generatedScripts" in summary


def test_build_report_includes_executive_summary_and_failed(tmp_path, monkeypatch):
    job_id = "RPT02"
    state = tmp_path / "schema-modernization" / job_id / "state"
    state.mkdir(parents=True)
    plan = {
        "objects": [
            {
                "objectId": "T1",
                "type": "TABLE",
                "status": "failed",
            }
        ]
    }
    (state / "conversion-plan.json").write_text(json.dumps(plan), encoding="utf-8")
    (state / "progress.json").write_text(
        json.dumps(
            {
                "startedAt": "2026-01-01T00:00:00+00:00",
                "completedAt": "2026-01-01T01:00:00+00:00",
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.conversion_plan_path",
        lambda jid, override=None: state / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.progress.progress_path",
        lambda jid, override=None: state / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: tmp_path / "schema-modernization" / jid / "output",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.load_progress",
        lambda jid: json.loads((state / "progress.json").read_text(encoding="utf-8")),
    )

    report = build_post_transformation_report(job_id, "HRDB")
    assert report["summary"]["failed"] == 1
    assert report["executiveSummary"]["failed"] == 1
    assert report["timing"]["durationSeconds"] == 3600
    assert "objectsByType" in report


def _patch_report_job_paths(tmp_path, monkeypatch, job_id: str):
    state = tmp_path / "schema-modernization" / job_id / "state"
    state.mkdir(parents=True)
    out = tmp_path / "schema-modernization" / job_id / "output"
    out.mkdir(parents=True)
    plan = {"objects": []}
    (state / "conversion-plan.json").write_text(json.dumps(plan), encoding="utf-8")

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.conversion_plan_path",
        lambda jid, override=None: state / "conversion-plan.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.progress.progress_path",
        lambda jid, override=None: state / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.output_dir",
        lambda jid, override=None: out,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.artifact_packager.load_progress",
        lambda jid: json.loads((state / "progress.json").read_text(encoding="utf-8")),
    )
    return state, out


def test_write_report_timing_null_without_completed_at(tmp_path, monkeypatch):
    job_id = "TIM01"
    state, _out = _patch_report_job_paths(tmp_path, monkeypatch, job_id)
    (state / "progress.json").write_text(
        json.dumps({"startedAt": "2026-01-01T00:00:00+00:00"}),
        encoding="utf-8",
    )

    write_report(job_id, "HRDB")
    report = json.loads(
        (_out / "post_transformation_report.json").read_text(encoding="utf-8")
    )
    assert report["timing"]["startedAt"] == "2026-01-01T00:00:00+00:00"
    assert report["timing"]["completedAt"] is None
    assert report["timing"]["durationSeconds"] is None


def test_write_report_timing_populated_when_completed_at_set(tmp_path, monkeypatch):
    job_id = "TIM02"
    state, out = _patch_report_job_paths(tmp_path, monkeypatch, job_id)
    (state / "progress.json").write_text(
        json.dumps(
            {
                "startedAt": "2026-01-01T00:00:00+00:00",
                "completedAt": "2026-01-01T00:30:00+00:00",
            }
        ),
        encoding="utf-8",
    )

    write_report(job_id, "HRDB")
    report = json.loads((out / "post_transformation_report.json").read_text(encoding="utf-8"))
    assert report["timing"]["completedAt"] == "2026-01-01T00:30:00+00:00"
    assert report["timing"]["durationSeconds"] == 1800
    assert report["timing"]["duration"] == "30m"
