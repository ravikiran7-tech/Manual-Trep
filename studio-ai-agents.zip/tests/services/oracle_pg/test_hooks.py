"""Tests for Oracle PG SSE hooks."""
import asyncio
import json
import sys

import pytest

from app.services.oracle_pg.hooks import (
    append_log_entry,
    is_ui_stream_event,
    make_progress_hooks,
    notify_progress_update,
    progress_updated_event,
    should_persist_sdk_message,
    subscribe,
    subscribe_logs,
    unsubscribe_all,
    unsubscribe_logs,
)
from app.services.oracle_pg.progress import PHASE_INITIALIZE, PHASE_MIGRATING, default_progress, save_progress


def test_is_ui_stream_event_filters_noise():
    assert is_ui_stream_event({"type": "progress_updated", "progressPercent": 1})
    assert is_ui_stream_event({"type": "sql_written", "filePath": "out.sql"})
    assert is_ui_stream_event({"type": "file_read", "filePath": "state/plan.json"})
    assert is_ui_stream_event(
        {"type": "file_search", "tool": "Grep", "pattern": "CREATE TABLE"}
    )
    assert not is_ui_stream_event(
        {"type": "sdk_message", "messageType": "SystemMessage", "subtype": "thinking_tokens"}
    )
    assert is_ui_stream_event(
        {"type": "sdk_message", "messageType": "ResultMessage", "subtype": "success"}
    )
    assert is_ui_stream_event(
        {"type": "sdk_message", "messageType": "SystemMessage", "subtype": "thinking_tokens"},
        verbose=True,
    )


def test_should_persist_sdk_message():
    assert not should_persist_sdk_message(
        {"type": "sdk_message", "messageType": "AssistantMessage"}
    )
    assert should_persist_sdk_message(
        {"type": "sdk_message", "messageType": "ResultMessage", "subtype": "success"}
    )


def test_progress_updated_event_shape():
    progress = default_progress("JOB1")
    progress.update(
        {
            "status": "in_progress",
            "phase": PHASE_MIGRATING,
            "progressPercent": 42,
            "message": "Migrating",
            "objectsTotal": 10,
            "objectsConverted": 4,
            "notes": ["batch done"],
        }
    )
    event = progress_updated_event("JOB1", progress)
    assert event["type"] == "progress_updated"
    assert event["progressPercent"] == 42
    assert event["latestNote"] == "batch done"


def test_progress_updated_event_includes_timing():
    progress = default_progress("JOB1")
    progress["startedAt"] = "2026-01-01T00:00:00+00:00"
    progress["completedAt"] = "2026-01-01T00:10:00+00:00"
    event = progress_updated_event("JOB1", progress)
    assert event["durationSeconds"] == 600
    assert event["duration"] == "10m"


def test_notify_progress_update_persists_event(tmp_path, monkeypatch):
    job_id = "JOBHOOK1"
    stream_dir = tmp_path / "schema-modernization" / job_id / "stream"
    stream_dir.mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.events_path",
        lambda jid: stream_dir / "events.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid: stream_dir / "logs.meta.json",
    )

    progress = default_progress(job_id)
    progress["status"] = "in_progress"
    progress["progressPercent"] = 15

    notify_progress_update(job_id, progress)

    lines = (stream_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["type"] == "progress_updated"
    assert event["progressPercent"] == 15

    log_lines = (stream_dir / "logs.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(log_lines) == 1
    log_entry = json.loads(log_lines[0])
    assert log_entry["seq"] == 1
    assert "message" in log_entry
    assert "icon" in log_entry


@pytest.mark.asyncio
async def test_append_log_entry_notifies_subscriber(tmp_path, monkeypatch):
    job_id = "JOBLOG1"
    stream_dir = tmp_path / "schema-modernization" / job_id / "stream"
    stream_dir.mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid: stream_dir / "logs.meta.json",
    )

    received: list[dict] = []

    async def on_log(entry: dict) -> None:
        received.append(entry)

    subscribe_logs(job_id, on_log)

    await append_log_entry(
        job_id,
        {"message": "Reading plan", "icon": "search", "phase": PHASE_INITIALIZE, "color": "#2196F3"},
    )

    assert received
    assert received[0]["message"] == "Reading plan"
    assert received[0]["seq"] == 1

    lines = (stream_dir / "logs.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1

    unsubscribe_logs(job_id)


@pytest.mark.asyncio
async def test_logs_jsonl_replay(tmp_path, monkeypatch):
    job_id = "JOBLOG3"
    stream_dir = tmp_path / "schema-modernization" / job_id / "stream"
    stream_dir.mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid: stream_dir / "logs.meta.json",
    )

    await append_log_entry(
        job_id,
        {
            "message": "Starting initializer session",
            "icon": "play",
            "phase": PHASE_INITIALIZE,
            "color": "#4CAF50",
        },
    )

    lines = (stream_dir / "logs.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    entry = json.loads(lines[0])
    assert entry["message"] == "Starting initializer session"
    assert entry["seq"] == 1


@pytest.mark.asyncio
async def test_save_progress_notifies_sse_subscriber(tmp_path, monkeypatch):
    job_id = "JOBHOOK2"
    base = tmp_path / "schema-modernization" / job_id
    state = base / "state"
    stream_dir = base / "stream"
    state.mkdir(parents=True)
    stream_dir.mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.progress_path",
        lambda jid: state / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.events_path",
        lambda jid: stream_dir / "events.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid: stream_dir / "logs.meta.json",
    )

    received: list[dict] = []

    async def on_event(event: dict) -> None:
        received.append(event)

    subscribe(job_id, on_event)

    progress = default_progress(job_id)
    progress["progressPercent"] = 25
    save_progress(job_id, progress)

    await asyncio.sleep(0.05)

    assert received
    assert received[-1]["type"] == "progress_updated"
    assert received[-1]["progressPercent"] == 25

    unsubscribe_all(job_id)


@pytest.mark.asyncio
async def test_post_tool_use_read_broadcasts_file_read(tmp_path, monkeypatch):
    job_id = "JOBREAD1"
    job_dir = tmp_path / "schema-modernization" / job_id
    stream_dir = job_dir / "stream"
    stream_dir.mkdir(parents=True)

    class _HookMatcher:
        def __init__(self, matcher: str, hooks: list) -> None:
            self.matcher = matcher
            self.hooks = hooks

    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.HookMatcher = _HookMatcher
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.job_root",
        lambda jid, workspace_override=None: job_dir,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.events_path",
        lambda jid, workspace_override=None: stream_dir / "events.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid, workspace_override=None: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid, workspace_override=None: stream_dir / "logs.meta.json",
    )

    hooks = make_progress_hooks(job_id)
    assert hooks is not None
    on_tool_use = hooks["PostToolUse"][0].hooks[0]

    plan_path = str(job_dir / "state" / "conversion-plan.json")
    await on_tool_use(
        {
            "tool_name": "Read",
            "tool_input": {"file_path": plan_path},
        },
        None,
        None,
    )

    events = [
        json.loads(line)
        for line in (stream_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    assert len(events) == 1
    assert events[0]["type"] == "file_read"
    assert events[0]["tool"] == "Read"
    assert events[0]["filePath"] == plan_path

    log_lines = (stream_dir / "logs.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(log_lines) == 1
    log_entry = json.loads(log_lines[0])
    assert log_entry["icon"] == "search"
    assert "Reading" in log_entry["message"]


@pytest.mark.asyncio
async def test_post_tool_use_grep_broadcasts_file_search(tmp_path, monkeypatch):
    job_id = "JOBGREP1"
    job_dir = tmp_path / "schema-modernization" / job_id
    stream_dir = job_dir / "stream"
    stream_dir.mkdir(parents=True)

    class _HookMatcher:
        def __init__(self, matcher: str, hooks: list) -> None:
            self.matcher = matcher
            self.hooks = hooks

    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.HookMatcher = _HookMatcher
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.job_root",
        lambda jid, workspace_override=None: job_dir,
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.events_path",
        lambda jid, workspace_override=None: stream_dir / "events.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_path",
        lambda jid, workspace_override=None: stream_dir / "logs.jsonl",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.hooks.logs_meta_path",
        lambda jid, workspace_override=None: stream_dir / "logs.meta.json",
    )

    hooks = make_progress_hooks(job_id)
    assert hooks is not None
    on_tool_use = hooks["PostToolUse"][0].hooks[0]

    ddl_path = str(job_dir / "_claude" / "schema.sql")
    await on_tool_use(
        {
            "tool_name": "Grep",
            "tool_input": {"pattern": "CREATE TABLE", "path": ddl_path},
        },
        None,
        None,
    )

    events = [
        json.loads(line)
        for line in (stream_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    assert len(events) == 1
    assert events[0]["type"] == "file_search"
    assert events[0]["tool"] == "Grep"
    assert events[0]["pattern"] == "CREATE TABLE"
    assert events[0]["path"] == ddl_path
