"""Tests for schema-modernization workspace path helpers."""
from pathlib import Path

import pytest

from app.services.oracle_pg.workspace import (
    MODERNIZATION_SUBDIR,
    claude_inputs_dir,
    ensure_path_under_job_root,
    job_root,
    read_json_file_at,
    relative_to_job_root,
    resolve_folder_key,
    validate_under_claude_dir,
    write_json_file_at,
)


def test_job_root_under_schema_modernization(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    root = job_root("DB0090")
    assert root == tmp_path / MODERNIZATION_SUBDIR / "DB0090"
    assert claude_inputs_dir("DB0090") == root / "_claude"


def test_validate_under_claude_dir_rejects_outside(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    db_name = "DB1"
    claude = claude_inputs_dir(db_name)
    claude.mkdir(parents=True)
    outside = job_root(db_name) / "input" / "x.sql"
    outside.parent.mkdir(parents=True)
    outside.write_text("x", encoding="utf-8")

    with pytest.raises(ValueError, match="_claude"):
        validate_under_claude_dir(db_name, outside)


def test_relative_to_job_root_from_claude_file(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    db_name = "DB1"
    claude = claude_inputs_dir(db_name)
    claude.mkdir(parents=True)
    ddl = claude / "schema.sql"
    ddl.write_text("CREATE TABLE t (id int);", encoding="utf-8")

    rel = relative_to_job_root(db_name, ddl)
    assert rel == "_claude/schema.sql"


def test_resolve_folder_key_by_job_id_in_config(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    db_name = "DB0090"
    job_id = "JOB-TRACK-99"
    root = job_root(db_name)
    root.mkdir(parents=True)
    (root / "job_config.json").write_text(
        f'{{"jobId": "{job_id}", "dbName": "{db_name}"}}',
        encoding="utf-8",
    )

    assert resolve_folder_key(job_id, str(tmp_path)) == db_name
    assert resolve_folder_key(db_name, str(tmp_path)) == db_name


def test_ensure_path_under_job_root_rejects_traversal(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    db_name = "DB1"
    job_root(db_name).mkdir(parents=True)
    with pytest.raises(ValueError, match="Path traversal"):
        ensure_path_under_job_root(db_name, Path("../../etc/passwd"))


def test_read_json_file_at_reads_under_job_root(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr(
        "app.services.oracle_pg.workspace.get_settings",
        lambda: _Settings(),
    )

    db_name = "DB1"
    root = job_root(db_name)
    root.mkdir(parents=True)
    target = root / "state" / "data.json"
    target.parent.mkdir(parents=True)
    write_json_file_at(db_name, target, {"ok": True})

    assert read_json_file_at(db_name, "state/data.json") == {"ok": True}
