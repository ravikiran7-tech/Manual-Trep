"""Tests for Pass 2 dependency resolution."""

from app.services.oracle_pg.dependency_resolver import _replace_package_calls


def test_replace_package_calls_updates_snippet():
    caller = {
        "convertedSqlSnippet": "BEGIN pkg_config.set_region('NA'); END;",
        "changes": [],
        "reviewGuidance": "",
    }
    count = _replace_package_calls(caller, "pkg_config", ["set_region"])
    assert count == 1
    assert "pkg_config." not in caller["convertedSqlSnippet"]
    assert "set_region(" in caller["convertedSqlSnippet"]
    assert caller["requiresManualReview"] is True
    assert caller["changes"]
