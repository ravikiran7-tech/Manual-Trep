"""Unit tests for Oracle PG rule engine."""
from app.services.oracle_pg.rule_engine import (
    filter_selected_rules,
    lookup_rule,
    resolve_confidence_score,
    resolve_conversion_status,
    rules_for_object_type,
    user_facing_status,
)


def test_lookup_rule_found():
    rule = lookup_rule("dbm-oracle-pgsql-001")
    assert rule is not None
    assert rule["ruleId"] == "dbm-oracle-pgsql-001"
    assert "NUMBER" in rule["mapping"]


def test_lookup_rule_missing():
    assert lookup_rule("dbm-oracle-pgsql-999") is None


def test_filter_high_impact():
    filtered = filter_selected_rules(
        ["dbm-oracle-pgsql-001", "dbm-oracle-pgsql-004"],
        "high_impact",
    )
    assert "dbm-oracle-pgsql-001" in filtered
    assert "dbm-oracle-pgsql-004" not in filtered


def test_resolve_conversion_status():
    assert resolve_conversion_status("DS", "high") == "auto_converted"
    assert resolve_conversion_status("NS", "low") == "manual_implementation"
    assert resolve_conversion_status("SC", "low") == "auto_converted"
    assert resolve_conversion_status("SC", "high") == "require_review"


def test_rules_for_object_type():
    rules = rules_for_object_type(
        ["dbm-oracle-pgsql-001", "dbm-oracle-pgsql-008"],
        "TABLE",
    )
    assert "dbm-oracle-pgsql-001" in rules
    assert "dbm-oracle-pgsql-008" not in rules


def test_resolve_confidence_score():
    assert resolve_confidence_score("DS", "high") == "HIGH"
    assert resolve_confidence_score("NS", "low") == "MANUAL"
    assert resolve_confidence_score("SC", "medium") == "MEDIUM"


def test_user_facing_status():
    assert user_facing_status("auto_converted") == "Successfully Converted"
    assert user_facing_status("manual_implementation") == "Manual Implementation"
