"""Unit tests for Oracle PG report metric builders."""
from pathlib import Path

from app.services.oracle_pg.report_metrics import (
    REPORT_OBJECT_TYPE_ORDER,
    build_confidence_breakdown,
    build_executive_summary,
    build_objects_by_type,
    build_timing_block,
    format_duration,
    load_compass_metadata,
)


def test_format_duration():
    assert format_duration(None) is None
    assert format_duration(0) == "0s"
    assert format_duration(5) == "5s"
    assert format_duration(65) == "1m 5s"
    assert format_duration(120) == "2m"


def test_build_timing_block():
    progress = {
        "startedAt": "2026-01-01T00:00:00+00:00",
        "completedAt": "2026-01-01T01:00:00+00:00",
    }
    timing = build_timing_block(progress)
    assert timing["durationSeconds"] == 3600
    assert timing["duration"] == "60m"


def test_build_executive_summary():
    plan = [
        {"status": "converted", "conversionStatus": "auto_converted"},
        {"status": "converted", "conversionStatus": "require_review"},
        {"status": "converted", "conversionStatus": "manual_implementation"},
        {"status": "failed"},
    ]
    summary = build_executive_summary(plan)
    assert summary == {
        "successfullyConverted": 1,
        "requiresReview": 2,
        "failed": 1,
        "totalObjects": 4,
    }


def test_build_confidence_breakdown():
    plan = [
        {"confidenceScore": "HIGH"},
        {"confidenceScore": "MEDIUM"},
        {"confidenceScore": "LOW"},
        {"confidenceScore": "MANUAL"},
    ]
    breakdown = build_confidence_breakdown(plan)
    assert breakdown == {"high": 1, "medium": 1, "low": 1, "manualRequired": 1}


def test_build_objects_by_type_rollup_constraints():
    plan = [
        {"type": "PRIMARY_KEY", "status": "converted", "conversionStatus": "auto_converted"},
        {"type": "FOREIGN_KEY", "status": "converted", "conversionStatus": "require_review"},
        {"type": "UNIQUE", "status": "converted", "conversionStatus": "auto_converted"},
        {"type": "CHECK", "status": "failed"},
        {"type": "TABLE", "status": "converted", "conversionStatus": "auto_converted"},
    ]
    rows = build_objects_by_type(plan)
    assert len(rows) == len(REPORT_OBJECT_TYPE_ORDER)
    constraints = next(r for r in rows if r["objectType"] == "Constraints")
    assert constraints["total"] == 4
    assert constraints["autoConverted"] == 2
    assert constraints["needReview"] == 1
    assert constraints["manualEffortRequired"] == 0
    tables = next(r for r in rows if r["objectType"] == "Tables")
    assert tables["total"] == 1
    others = next(r for r in rows if r["objectType"] == "Others")
    assert others["total"] == 0


def test_build_objects_by_type_tables_exclude_others():
    plan = [
        {"type": "TABLE", "status": "converted", "conversionStatus": "auto_converted"},
        {"type": "TABLE", "status": "converted", "conversionStatus": "require_review"},
        {"type": "DEFAULT", "status": "converted", "conversionStatus": "auto_converted"},
        {"type": "SEQUENCE", "status": "converted", "conversionStatus": "require_review"},
        {"type": "SCHEMA", "status": "converted", "conversionStatus": "require_review"},
        {"type": "TYPE", "status": "converted", "conversionStatus": "manual_implementation"},
    ]
    rows = build_objects_by_type(plan)
    assert [r["objectType"] for r in rows] == list(REPORT_OBJECT_TYPE_ORDER)
    tables = next(r for r in rows if r["objectType"] == "Tables")
    assert tables["total"] == 2
    assert tables["autoConverted"] == 1
    assert tables["needReview"] == 1
    others = next(r for r in rows if r["objectType"] == "Others")
    assert others["total"] == 4
    assert others["autoConverted"] == 1
    assert others["needReview"] == 2
    assert others["manualEffortRequired"] == 1


def test_load_compass_metadata_from_fixture(tmp_path, monkeypatch):
    job_id = "META01"
    db_name = "HRDB"
    claude = tmp_path / "schema-modernization" / db_name / "_claude"
    claude.mkdir(parents=True)

    fixtures = Path(__file__).resolve().parents[2] / "fixtures" / "oracle_pg"
    incompat_src = fixtures / "oracle-to-postgresql-incompatability-results.json"
    asis_src = fixtures / "oracle-dbschema-asis.json"
    (claude / "incompat.json").write_text(incompat_src.read_text(encoding="utf-8"), encoding="utf-8")
    (claude / "asis.json").write_text(asis_src.read_text(encoding="utf-8"), encoding="utf-8")

    job_config = {
        "dbName": db_name,
        "sourceDatabaseVersion": "Oracle 19c",
        "targetDatabaseVersion": "16",
        "inputPaths": {
            "incompatibilityResults": "_claude/incompat.json",
            "asisSchema": "_claude/asis.json",
        },
    }

    monkeypatch.setattr(
        "app.services.oracle_pg.report_metrics.input_path",
        lambda jid, key, cfg: tmp_path / "schema-modernization" / db_name / cfg["inputPaths"][key],
    )

    metadata = load_compass_metadata(
        job_id, job_config, db_name, workspace_override=str(tmp_path)
    )
    assert metadata["databaseId"] == "DB0090"
    assert metadata["sourceDatabase"] == "Oracle 19c"
    assert metadata["targetDatabase"] == "PostgreSQL 16"
