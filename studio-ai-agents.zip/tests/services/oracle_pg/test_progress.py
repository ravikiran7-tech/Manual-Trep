"""Unit tests for Oracle PG progress helpers."""
import json

from app.services.oracle_pg.progress import (
    OBJECT_BATCH_ORDER,
    PHASE_COMPLETED,
    PHASE_INITIALIZE,
    PHASE_MIGRATING,
    compute_progress_percent,
    default_progress,
    finalize_plan_conversion_status,
    is_job_terminal,
    is_terminal_job_status,
    is_terminal_progress_event,
    next_pending_batch,
    normalize_phase,
    save_progress,
    update_progress_from_plan,
)


def test_compute_progress_percent_migrating():
    assert compute_progress_percent(PHASE_MIGRATING, 100, 50) == 50
    assert compute_progress_percent(PHASE_MIGRATING, 0, 0) == 20
    assert compute_progress_percent(PHASE_COMPLETED, 10, 10, artifacts_done=True) == 100


def test_normalize_phase_legacy_aliases():
    assert normalize_phase("migrating_schema") == PHASE_MIGRATING
    assert normalize_phase("initializing") == PHASE_INITIALIZE
    assert normalize_phase(PHASE_MIGRATING) == PHASE_MIGRATING


def test_next_pending_batch_order():
    plan = [
        {"type": "INDEX", "status": "pending"},
        {"type": "TABLE", "status": "pending"},
    ]
    assert next_pending_batch(plan) == "TABLE"


def test_object_batch_order_includes_default():
    table_idx = OBJECT_BATCH_ORDER.index("TABLE")
    default_idx = OBJECT_BATCH_ORDER.index("DEFAULT")
    pk_idx = OBJECT_BATCH_ORDER.index("PRIMARY_KEY")
    assert table_idx < default_idx < pk_idx


def test_finalize_plan_conversion_status_backfills():
    plan = [
        {
            "status": "converted",
            "conversionStatus": None,
            "expectedConversionStatus": "manual_implementation",
            "confidenceScore": "MANUAL",
        }
    ]
    updated = finalize_plan_conversion_status(plan)
    assert updated == 1
    assert plan[0]["conversionStatus"] == "manual_implementation"
    assert plan[0]["requiresManualReview"] is True


def test_next_pending_batch_none():
    plan = [{"type": "TABLE", "status": "converted"}]
    assert next_pending_batch(plan) is None


def test_update_progress_from_plan(tmp_path, monkeypatch):
    job_id = "JOB001"
    base = tmp_path / "schema-modernization" / job_id
    state = base / "state"
    state.mkdir(parents=True)

    monkeypatch.setattr(
        "app.services.oracle_pg.progress.progress_path",
        lambda jid: state / "progress.json",
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.progress.conversion_plan_path",
        lambda jid: state / "conversion-plan.json",
    )

    save_progress(job_id, default_progress(job_id))
    with (state / "conversion-plan.json").open("w", encoding="utf-8") as fh:
        json.dump(
            {
                "objects": [
                    {"type": "TABLE", "status": "converted"},
                    {"type": "TABLE", "status": "pending"},
                ]
            },
            fh,
        )

    progress = update_progress_from_plan(job_id, PHASE_MIGRATING)
    assert progress["objectsTotal"] == 2
    assert progress["objectsConverted"] == 1
    assert progress["progressPercent"] == 50


def test_is_terminal_job_status():
    assert is_terminal_job_status("completed")
    assert is_terminal_job_status("failed")
    assert not is_terminal_job_status("in_progress")
    assert not is_terminal_job_status(None)


def test_is_terminal_progress_event():
    assert is_terminal_progress_event(
        {"type": "progress_updated", "status": "completed"}
    )
    assert not is_terminal_progress_event(
        {"type": "progress_updated", "status": "in_progress"}
    )
    assert not is_terminal_progress_event({"type": "sql_written"})


def test_is_job_terminal(tmp_path, monkeypatch):
    job_id = "TERM01"
    base = tmp_path / "schema-modernization" / job_id
    base.mkdir(parents=True)

    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.oracle_pg.workspace.get_settings", lambda: _Settings())

    save_progress(job_id, default_progress(job_id))
    assert not is_job_terminal(job_id)

    progress = default_progress(job_id)
    progress["status"] = "completed"
    save_progress(job_id, progress)
    assert is_job_terminal(job_id)
