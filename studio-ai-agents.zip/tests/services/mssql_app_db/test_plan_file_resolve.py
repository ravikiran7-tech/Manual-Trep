"""Plan file paths vs checkout layout."""

from pathlib import Path

from app.services.mssql_app_db.file_ops import (
    matches_plan_file,
    normalize_violation_paths_in_plan,
    resolve_plan_file_under_checkout,
)


def test_resolve_direct_relative_path(tmp_path):
    rel = "src/main/java/com/example/Dao.java"
    (tmp_path / rel).parent.mkdir(parents=True)
    (tmp_path / rel).write_text("class Dao {}", encoding="utf-8")
    assert resolve_plan_file_under_checkout(tmp_path, rel) == rel


def test_resolve_suffix_when_plan_omits_module_prefix(tmp_path):
    rel = "BootApp/src/main/java/com/acme/Foo.java"
    (tmp_path / rel).parent.mkdir(parents=True)
    (tmp_path / rel).write_text("class Foo {}", encoding="utf-8")
    assert resolve_plan_file_under_checkout(tmp_path, "src/main/java/com/acme/Foo.java") == rel


def test_resolve_absolute_scan_path_to_workspace_relative(tmp_path):
    rel = "ContosoUniversity/Models/Department.cs"
    (tmp_path / rel).parent.mkdir(parents=True)
    (tmp_path / rel).write_text("class Department {}", encoding="utf-8")
    scan_path = (
        "/modernize-data/TNT1001/APP772815/sourcecode/CMP631280/"
        "contosoUniversity4dot7/ContosoUniversity/Models/Department.cs"
    )
    assert resolve_plan_file_under_checkout(tmp_path, scan_path) == rel


def test_normalize_violation_paths_in_plan(tmp_path):
    rel = "ContosoUniversity/Controllers/StudentsController.cs"
    (tmp_path / rel).parent.mkdir(parents=True)
    (tmp_path / rel).write_text("class StudentsController {}", encoding="utf-8")
    abs_path = (
        "/modernize-data/tenant/app/sourcecode/pkg/contosoUniversity4dot7/"
        "ContosoUniversity/Controllers/StudentsController.cs"
    )
    plan = {"violations": [{"ruleId": "x", "file": abs_path, "status": "pending"}]}
    notes = normalize_violation_paths_in_plan(plan, tmp_path)
    assert plan["violations"][0]["file"] == rel
    assert notes


def test_matches_plan_file_uses_checkout_canonical_path(tmp_path):
    rel = "ContosoUniversity/Models/Student.cs"
    (tmp_path / rel).parent.mkdir(parents=True)
    (tmp_path / rel).write_text("x", encoding="utf-8")
    scan_path = "/data/scan/ContosoUniversity/Models/Student.cs"
    assert matches_plan_file(rel, scan_path, checkout=tmp_path)


def test_resolve_returns_none_when_ambiguous(tmp_path):
    for rel in ("a/Foo.java", "b/Foo.java"):
        (tmp_path / rel).parent.mkdir(parents=True)
        (tmp_path / rel).write_text("x", encoding="utf-8")
    assert resolve_plan_file_under_checkout(tmp_path, "Foo.java") is None
