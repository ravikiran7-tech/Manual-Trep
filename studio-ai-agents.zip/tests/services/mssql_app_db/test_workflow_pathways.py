"""MSSQL App+DB: pathways, languages, and violation resolution (mocked LLM)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.services.mssql_app_db.pathways import (
    PATHWAY_BASIC,
    PATHWAY_CONTAINER,
    PATHWAY_UPGRADE,
    compatibility_instructions,
    normalize_mssql_pathway,
)
from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.run_helpers import launch_mssql_and_complete, patch_mssql_app_db_workspace

PATHWAYS = (
    "M-Upgrade",
    "M-Basic",
    "M-Container-Mono",
    "M-Container-Mono + DB-Modernize",
)


@pytest.mark.parametrize("pathway,expected", [
    ("M-Upgrade", PATHWAY_UPGRADE),
    ("M-Basic", PATHWAY_BASIC),
    ("M-Container-Mono", PATHWAY_CONTAINER),
    ("M-Container-Mono + DB-Modernize", PATHWAY_CONTAINER),
    ("m-basic + something", PATHWAY_BASIC),
])
def test_normalize_mssql_pathway_compound_labels(pathway, expected):
    assert normalize_mssql_pathway(pathway) == expected


@pytest.mark.parametrize("pathway,java_scope,csharp_scope", [
    ("M-Upgrade", "", ""),
    ("M-Basic", "pom.xml", "appsettings"),
    ("M-Container-Mono + DB-Modernize", "Dockerfile", "docker-compose"),
])
def test_compat_scope_follows_pathway(pathway, java_scope, csharp_scope):
    java = compatibility_instructions(pathway, "java")
    csharp = compatibility_instructions(pathway, "csharp")
    if not java_scope:
        assert java == ""
        assert csharp == ""
    else:
        assert java_scope.lower() in java.lower()
        assert csharp_scope.lower() in csharp.lower()


@pytest.mark.asyncio
@pytest.mark.parametrize("lang", ["java", "csharp"])
@pytest.mark.parametrize("pathway", PATHWAYS)
async def test_violations_resolve_when_kb_file_and_rule_match(
    monkeypatch,
    tmp_path,
    lang,
    pathway,
):
    """When findings, ruleId, KB remediation, and on-disk file align, status → resolved."""
    db_id = f"WF-{lang}-{pathway[:4].replace(' ', '')}"
    tid, checkout, _ = await launch_mssql_and_complete(
        monkeypatch,
        tmp_path,
        lang=lang,
        app_id="APP-WF",
        db_id=db_id,
        skip_llm=False,
        via_api=False,
        pathway=pathway,
    )
    assert tid

    plan = json.loads(ws.plan_path(db_id).read_text(encoding="utf-8"))
    pending_resolved = [
        v
        for v in plan.get("violations") or []
        if str(v.get("status")).lower() == "resolved"
    ]
    assert pending_resolved, f"expected at least one resolved violation: {plan.get('violations')}"

    report_path = ws.reports_dir(db_id) / "post_transformation_report.json"
    assert report_path.is_file()
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report.get("overallStatus") == "COMPLETED"

    config = json.loads(ws.job_config_path(db_id).read_text(encoding="utf-8"))
    assert normalize_mssql_pathway(config.get("pathway") or pathway) in {
        PATHWAY_UPGRADE,
        PATHWAY_BASIC,
        PATHWAY_CONTAINER,
    }

    if lang == "java":
        dao = checkout / "src/main/java/com/example/Dao.java"
        assert "postgresql" in dao.read_text(encoding="utf-8").lower()
    else:
        program = checkout / "App/Program.cs"
        assert "port=5432" in program.read_text(encoding="utf-8").lower()
