"""Stage MSSQL App+DB inputs under ``_claude/``."""

from __future__ import annotations

import json
from pathlib import Path

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _java_findings_payload() -> dict:
    return {
        "scan_results": {
            "Results": [
                {
                    "violationDetails": [
                        {
                            "filename": "src/main/java/com/example/Dao.java",
                            "violations": [
                                {"ruleId": "sql-java-001", "beginLine": 8, "endLine": 8},
                            ],
                        }
                    ]
                }
            ]
        }
    }


def _csharp_findings_payload() -> dict:
    return {
        "scan_results": {
            "Results": [
                {
                    "violationDetails": [
                        {
                            "filename": "App/Program.cs",
                            "violations": [
                                {"ruleId": "sql-csharp-001", "beginLine": 6, "endLine": 6},
                            ],
                        }
                    ]
                }
            ]
        }
    }


def _java_kb_payload() -> dict:
    return {
        "rules": [
            {
                "ruleId": "sql-java-001",
                "ruleName": "SqlServerJdbcUrl",
                "category": "connectivity",
                "severity": "Critical",
                "description": "Use PostgreSQL JDBC URL",
                "remediations": [
                    {
                        "default": True,
                        "description": "Replace SQL Server JDBC with PostgreSQL",
                        "detailedDescription": "jdbc:postgresql://localhost:5432/app",
                    }
                ],
            }
        ]
    }


def _csharp_kb_payload() -> dict:
    return {
        "rules": [
            {
                "ruleId": "sql-csharp-001",
                "ruleName": "SqlServerConnectionString",
                "category": "connectivity",
                "severity": "Critical",
                "description": "Use Npgsql connection string",
                "remediations": [
                    {
                        "default": True,
                        "description": "Host=localhost;Database=app",
                        "detailedDescription": "Host=localhost;Port=5432;Database=app",
                    }
                ],
            }
        ]
    }


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _stage_java_sources(checkout: Path) -> None:
    dao = checkout / "src/main/java/com/example/Dao.java"
    dao.parent.mkdir(parents=True, exist_ok=True)
    dao.write_text(
        """package com.example;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dao {
    public Connection open() throws Exception {
        return DriverManager.getConnection(
            "jdbc:sqlserver://localhost:1433;databaseName=app",
            "user",
            "pass");
    }
}
""",
        encoding="utf-8",
    )


def _stage_csharp_sources(checkout: Path) -> None:
    app = checkout / "App"
    app.mkdir(parents=True, exist_ok=True)
    (app / "App.csproj").write_text(
        '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType>'
        "<TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>",
        encoding="utf-8",
    )
    (app / "Program.cs").write_text(
        """using System;
class Program {
    static void Main() {
        var cs = "Server=localhost;Database=app;User Id=sa;Password=secret;";
        Console.WriteLine(cs);
    }
}
""",
        encoding="utf-8",
    )


def stage_mssql_inputs(inputs_dir: Path, checkout: Path, lang: str = "java") -> None:
    inputs_dir.mkdir(parents=True, exist_ok=True)
    checkout.mkdir(parents=True, exist_ok=True)
    if lang == "csharp":
        _write_json(inputs_dir / RULES_CSHARP_MSSQL, _csharp_kb_payload())
        _write_json(inputs_dir / FINDINGS_CSHARP_MSSQL, _csharp_findings_payload())
        _stage_csharp_sources(checkout)
    else:
        _write_json(inputs_dir / RULES_JAVA_MSSQL, _java_kb_payload())
        _write_json(inputs_dir / FINDINGS_JAVA_MSSQL, _java_findings_payload())
        _stage_java_sources(checkout)
    reports = inputs_dir.parent / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "schema_job_status.json").write_text(
        json.dumps({"job2Status": "COMPLETED"}),
        encoding="utf-8",
    )
