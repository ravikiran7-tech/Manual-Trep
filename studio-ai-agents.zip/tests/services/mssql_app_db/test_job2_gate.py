"""Job 2 gate accepts schema-modernization progress when marker file is absent."""

from __future__ import annotations

import json

from app.services.mssql_app_db import job2_gate
from app.services.oracle_pg.workspace import MODERNIZATION_SUBDIR


def test_job2_gate_accepts_schema_modernization_progress(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.mssql_app_db.job2_gate.get_settings", lambda: _Settings())
    db_id = "DB0292"
    progress_dir = tmp_path / MODERNIZATION_SUBDIR / db_id / "state"
    progress_dir.mkdir(parents=True)
    (progress_dir / "progress.json").write_text(
        json.dumps({"jobId": db_id, "status": "completed", "phase": "Completed"}),
        encoding="utf-8",
    )
    ok, reason = job2_gate.job2_completed_for_db(db_id)
    assert ok is True
    assert reason is None


def test_job2_gate_rejects_in_progress_schema_job(tmp_path, monkeypatch):
    class _Settings:
        claude_workspace = str(tmp_path)

    monkeypatch.setattr("app.services.mssql_app_db.job2_gate.get_settings", lambda: _Settings())
    db_id = "DB0292"
    progress_dir = tmp_path / MODERNIZATION_SUBDIR / db_id / "state"
    progress_dir.mkdir(parents=True)
    (progress_dir / "progress.json").write_text(
        json.dumps({"jobId": db_id, "status": "in_progress"}),
        encoding="utf-8",
    )
    ok, reason = job2_gate.job2_completed_for_db(db_id)
    assert ok is False
    assert reason and "in_progress" in reason
