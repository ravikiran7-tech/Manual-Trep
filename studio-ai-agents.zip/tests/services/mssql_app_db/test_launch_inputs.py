"""MSSQL remediation KB is chosen by rule ids, not by file name."""

from __future__ import annotations

import json
from pathlib import Path

from app.services.mssql_app_db.launch_inputs import (
    find_mssql_findings_file,
    find_mssql_remediation_file,
    remediation_rule_ids,
)


def _write(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_remediation_file_is_found_by_rule_id_not_name(tmp_path: Path):
    _write(
        tmp_path / "oracle-to-postgresql-rules_remediation.json",
        {"rules": [{"ruleId": "ASSESS-ORACLE-PG-001", "remediations": [{"description": "oracle"}]}]},
    )
    kb = tmp_path / "Db-dependency" / "team-export.json"
    _write(
        kb,
        {
            "rules": [
                {
                    "ruleId": "sql-java-014",
                    "remediation": "Replace jdbc:sqlserver with jdbc:postgresql",
                }
            ]
        },
    )
    found = find_mssql_remediation_file(tmp_path, "java")
    assert found == kb
    assert remediation_rule_ids(found) == {"sql-java-014"}


def test_explicit_mssql_file_wins_over_a_larger_other_file(tmp_path: Path):
    preferred = tmp_path / "custom-kb.json"
    _write(
        preferred,
        {"rules": [{"ruleId": "sql-java-001", "remediationText": "use varchar"}]},
    )
    _write(
        tmp_path / "other.json",
        {
            "rules": [
                {"ruleId": "sql-java-001", "remediationText": "a"},
                {"ruleId": "sql-java-002", "remediationText": "b"},
            ]
        },
    )
    assert find_mssql_remediation_file(tmp_path, "java", preferred) == preferred


def test_findings_file_is_the_one_that_overlaps_the_kb(tmp_path: Path):
    kb = tmp_path / "kb.json"
    findings = tmp_path / "nested" / "whatever.json"
    _write(kb, {"rules": [{"ruleId": "sql-csharp-003", "remediationText": "use Npgsql"}]})
    _write(
        tmp_path / "Java-Oracle-dependency.json",
        {
            "scan_results": {
                "Results": [
                    {
                        "violationDetails": [
                            {"filename": "A.java", "violations": [{"ruleId": "ora-java-001"}]}
                        ]
                    }
                ]
            }
        },
    )
    _write(
        findings,
        {
            "scan_results": {
                "Results": [
                    {
                        "violationDetails": [
                            {"filename": "Program.cs", "violations": [{"ruleId": "sql-csharp-003"}]}
                        ]
                    }
                ]
            }
        },
    )
    found = find_mssql_findings_file(
        tmp_path, remediation_rule_ids(kb), skip=kb
    )
    assert found == findings
