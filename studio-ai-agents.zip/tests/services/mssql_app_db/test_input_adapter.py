"""MSSQL App+DB dependency plan builder tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.services.mssql_app_db.input_adapter import build_dependency_resolution_plan
from app.services.mssql_app_db.source_profile import (
    default_dependency_findings_filename,
    default_rules_remediation_filename,
)


def _findings(path: Path, rule_ids: list[str], filename: str = "src/App.java") -> None:
    rows = []
    for rid in rule_ids:
        rows.append(
            {
                "filename": filename,
                "violations": [{"ruleId": rid, "beginLine": 10, "endLine": 10}],
            }
        )
    payload = {"scan_results": {"Results": [{"violationDetails": rows}]}}
    path.write_text(json.dumps(payload), encoding="utf-8")


def _flat_kb(path: Path, rules: list[dict]) -> None:
    path.write_text(json.dumps(rules), encoding="utf-8")


def test_default_filenames():
    assert default_dependency_findings_filename("mssql", "java") == "Java-MSSQL-dependency.json"
    assert default_rules_remediation_filename("mssql", "csharp") == "csharp-mssql-remediation-kb.json"


def test_rule_scope_high_impact(tmp_path: Path):
    findings = tmp_path / "f.json"
    kb = tmp_path / "kb.json"
    _findings(findings, ["sql-java-001", "sql-java-002"])
    _flat_kb(
        kb,
        [
            {"rule_id": "sql-java-001", "rule_name": "A", "severity": "Critical"},
            {"rule_id": "sql-java-002", "rule_name": "B", "severity": "Low"},
        ],
    )
    plan = build_dependency_resolution_plan(
        findings_path=findings,
        catalog_path=kb,
        app_id="A1",
        db_id="D1",
        rule_scope="high_impact",
    )
    assert plan["summary"]["findingsInScope"] == 1
    assert plan["violations"][0]["ruleId"] == "sql-java-001"
    assert "files" not in plan


def test_empty_scope_message(tmp_path: Path):
    findings = tmp_path / "f.json"
    kb = tmp_path / "kb.json"
    findings.write_text(json.dumps({"scan_results": {"Results": []}}), encoding="utf-8")
    _flat_kb(kb, [{"rule_id": "sql-java-001", "severity": "High"}])
    plan = build_dependency_resolution_plan(
        findings_path=findings,
        catalog_path=kb,
        app_id="A1",
        db_id="D1",
    )
    assert plan["summary"]["emptyScopeMessage"]


def test_normalize_source_dialect():
    from app.services.mssql_app_db.source_profile import normalize_source_database

    assert normalize_source_database("SQL Server") == "mssql"
    with pytest.raises(ValueError, match="sourceDialect"):
        normalize_source_database("mysql")


def test_csharp_absolute_scan_path_remaps_to_checkout(tmp_path: Path):
    checkout = tmp_path / "workspace"
    rel = "ContosoUniversity/Controllers/StudentsController.cs"
    (checkout / rel).parent.mkdir(parents=True)
    (checkout / rel).write_text("class StudentsController {}", encoding="utf-8")
    abs_name = (
        "/modernize-data/TNT1001/APP477564/sourcecode/CMP195227/SC943480/"
        "ContosoUniversity-master/ContosoUniversity-master/ContosoUniversity/"
        "Controllers/StudentsController.cs"
    )
    findings = tmp_path / "f.json"
    kb = tmp_path / "kb.json"
    findings.write_text(
        json.dumps(
            {
                "scan_results": {
                    "Results": [
                        {
                            "violationDetails": [
                                {
                                    "filename": abs_name,
                                    "violations": [
                                        {"ruleId": "sql-csharp-0127", "beginLine": 38, "endLine": 38}
                                    ],
                                }
                            ]
                        }
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    _flat_kb(
        kb,
        [
            {
                "ruleId": "sql-csharp-0127",
                "ruleName": "LinqToSqlQueryUsage",
                "severity": "Medium",
                "remediations": [{"default": True, "detailedDescription": "Migrate LINQ"}],
            }
        ],
    )
    plan = build_dependency_resolution_plan(
        findings_path=findings,
        catalog_path=kb,
        app_id="APP477564",
        db_id="D1",
        project_path=str(checkout),
        project_type="csharp",
    )
    row = plan["violations"][0]
    assert row["status"] == "pending"
    assert row["file"] == rel
    assert row.get("scanFile") == abs_name


def test_literal_resolves_properties_when_config_file_changes(tmp_path: Path):
    from app.services.mssql_app_db.literal_edits import apply_literal_remediations
    from app.services.mssql_app_db.orchestrator import _violation_match_kind

    checkout = tmp_path / "app"
    servlet = checkout / "src/main/java/com/acme/WeatherServlet.java"
    props = checkout / "src/main/resources/application.properties"
    servlet.parent.mkdir(parents=True)
    props.parent.mkdir(parents=True)
    servlet.write_text("public class WeatherServlet {}", encoding="utf-8")
    props.write_text("db.url=jdbc:sqlserver://localhost:1433", encoding="utf-8")
    pending = [
        {
            "status": "pending",
            "ruleId": "sql-java-013",
            "ruleName": "PropertiesFileConfiguration",
            "file": "src/main/java/com/acme/WeatherServlet.java",
        }
    ]
    notes = apply_literal_remediations(checkout, pending, project_type="java")
    assert notes
    assert "postgresql" in props.read_text(encoding="utf-8")
    assert (
        _violation_match_kind(
            pending[0],
            {"src/main/resources/application.properties"},
            checkout,
            "java",
        )
        == "config_file"
    )
