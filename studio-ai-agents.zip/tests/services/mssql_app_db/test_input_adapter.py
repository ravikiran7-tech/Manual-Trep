"""MSSQL App+DB dependency plan builder tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.services.mssql_app_db.input_adapter import build_dependency_resolution_plan
from app.services.mssql_app_db.source_profile import (
    default_dependency_findings_filename,
    default_rules_remediation_filename,
)


def _findings(path: Path, rule_ids: list[str], filename: str = "src/App.java") -> None:
    rows = []
    for rid in rule_ids:
        rows.append(
            {
                "filename": filename,
                "violations": [{"ruleId": rid, "beginLine": 10, "endLine": 10}],
            }
        )
    payload = {"scan_results": {"Results": [{"violationDetails": rows}]}}
    path.write_text(json.dumps(payload), encoding="utf-8")


def _flat_kb(path: Path, rules: list[dict]) -> None:
    path.write_text(json.dumps(rules), encoding="utf-8")


def test_default_filenames():
    assert default_dependency_findings_filename("mssql", "java") == "Java-MSSQL-dependency.json"
    assert default_rules_remediation_filename("mssql", "csharp") == "csharp-mssql-remediation-kb.json"


def test_rule_scope_high_impact(tmp_path: Path):
    findings = tmp_path / "f.json"
    kb = tmp_path / "kb.json"
    _findings(findings, ["sql-java-001", "sql-java-002"])
    _flat_kb(
        kb,
        [
            {"rule_id": "sql-java-001", "rule_name": "A", "severity": "Critical"},
            {"rule_id": "sql-java-002", "rule_name": "B", "severity": "Low"},
        ],
    )
    plan = build_dependency_resolution_plan(
        findings_path=findings,
        catalog_path=kb,
        app_id="A1",
        db_id="D1",
        rule_scope="high_impact",
    )
    assert plan["summary"]["findingsInScope"] == 1
    assert plan["violations"][0]["ruleId"] == "sql-java-001"
    assert "files" not in plan


def test_empty_scope_message(tmp_path: Path):
    findings = tmp_path / "f.json"
    kb = tmp_path / "kb.json"
    findings.write_text(json.dumps({"scan_results": {"Results": []}}), encoding="utf-8")
    _flat_kb(kb, [{"rule_id": "sql-java-001", "severity": "High"}])
    plan = build_dependency_resolution_plan(
        findings_path=findings,
        catalog_path=kb,
        app_id="A1",
        db_id="D1",
    )
    assert plan["summary"]["emptyScopeMessage"]


def test_normalize_source_dialect():
    from app.services.mssql_app_db.source_profile import normalize_source_database

    assert normalize_source_database("SQL Server") == "mssql"
    with pytest.raises(ValueError, match="sourceDialect"):
        normalize_source_database("mysql")
