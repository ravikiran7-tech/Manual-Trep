"""MSSQL App+DB report uses MSSQL-Java / MSSQL-C# wording in summary + rules table."""

from __future__ import annotations

from app.services.mssql_app_db.report_packager import build_post_transformation_report


def test_mssql_java_report_summary_and_subheading_are_mssql_java():
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL-J",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        project_type="java",
        violations_found=1,
        violation_outcomes=[
            {
                "rule_id": "rule-1",
                "rule_name": "SomeRule",
                "category": "jdbc",
                "file": "src/App.java",
                "status": "FAILED",
                "reason": "test",
            },
        ],
    )
    assert "MSSQL-Java dependency violations" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-Java dependency rules"


def test_mssql_csharp_report_summary_and_subheading_are_mssql_csharp():
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL-CS",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        project_type="csharp",
        violations_found=0,
    )
    assert "no MSSQL-C# violations in scope" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-C# dependency rules"


def test_report_implies_mssql_from_sql_java_rule_ids():
    from app.services.mssql_app_db.report_packager import report_implies_mssql

    assert report_implies_mssql(
        {"rulesResults": [{"ruleId": "sql-java-131", "ruleName": "StringToVarcharMapping"}]}
    )


def test_ensure_mssql_report_labels_rewrites_oracle_java_copy():
    from app.services.mssql_app_db.report_packager import ensure_mssql_report_labels

    stale = {
        "appId": "APP402077",
        "pathway": "M-Upgrade",
        "summaryText": (
            "The automated App-DB dependency transformation of APP402077 for the M-Upgrade pathway "
            "concluded with resolution of 0 Oracle-Java dependency violations across 0 files, "
            "with 0 additional PostgreSQL compatibility changes applied."
        ),
        "executiveSummary": {
            "totalViolations": 2,
            "violationsResolved": 0,
            "filesModified": 0,
            "description": "Oracle-Java dependency violations",
        },
        "rulesTable": {"subHeading": "Code changes by applied Oracle-Java dependency rules"},
        "metadata": {"projectType": "java"},
        "rulesResults": [{"ruleId": "sql-java-131", "ruleName": "StringToVarcharMapping"}],
    }
    fixed = ensure_mssql_report_labels(stale)
    assert "MSSQL-Java dependency violations" in fixed["summaryText"]
    assert "Oracle-Java" not in fixed["summaryText"]
    assert fixed["metadata"]["languageProfile"] == "MSSQL-Java"
    assert fixed["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-Java dependency rules"
