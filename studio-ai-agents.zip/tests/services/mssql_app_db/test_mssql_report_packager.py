"""MSSQL App+DB report uses MSSQL-Java / MSSQL-C# wording in summary + rules table."""

from __future__ import annotations

from app.services.mssql_app_db.report_packager import build_post_transformation_report


def test_mssql_java_report_summary_and_subheading_are_mssql_java():
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL-J",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        project_type="java",
        violations_found=1,
        violation_outcomes=[
            {
                "rule_id": "rule-1",
                "rule_name": "SomeRule",
                "category": "jdbc",
                "file": "src/App.java",
                "status": "FAILED",
                "reason": "test",
            },
        ],
    )
    assert "MSSQL-Java dependency violations" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-Java dependency rules"


def test_mssql_csharp_report_summary_and_subheading_are_mssql_csharp():
    report = build_post_transformation_report(
        transformation_id="APPDB-MSSQL-CS",
        app_id="A1",
        db_id="D1",
        pathway="M-Upgrade",
        nfs_mount_path="/nfs/app",
        project_type="csharp",
        violations_found=0,
    )
    assert "no MSSQL-C# violations in scope" in report["summaryText"]
    assert report["rulesTable"]["subHeading"] == "Code changes by applied MSSQL-C# dependency rules"
