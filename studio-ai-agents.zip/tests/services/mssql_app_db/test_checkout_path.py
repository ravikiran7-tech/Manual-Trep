"""MSSQL Job 3 NFS checkout visibility (mount prefix rewrite)."""

from pathlib import Path

import pytest

from app.services.mssql_app_db.checkout_path import (
    candidate_tails,
    locate_checkout,
    resolve_against_mounts,
    resolve_visible_checkout,
)


def test_candidate_tails_strips_studio_data_prefix():
    raw = (
        "/modernize-data/studio-data/TNT1001/APP1/"
        "transformed-code/252/studio-workspace/Eksa"
    )
    tails = candidate_tails(raw)
    assert tails == [
        "TNT1001/APP1/transformed-code/252/studio-workspace/Eksa",
        "studio-data/TNT1001/APP1/transformed-code/252/studio-workspace/Eksa",
    ]


def test_resolve_against_mounts_rewrites_to_studio_app(tmp_path):
    mount = tmp_path / "studio-app"
    component = (
        mount
        / "TNT1001"
        / "APP172687"
        / "transformed-code"
        / "101"
        / "studio-workspace"
        / "Bvcmp"
    )
    component.mkdir(parents=True)
    requested = (
        "/modernize-data/studio-data/TNT1001/APP172687/"
        "transformed-code/101/studio-workspace/Bvcmp"
    )
    found, tried = resolve_against_mounts(requested, [mount])
    assert found == str(component)
    assert tried


def test_locate_checkout_returns_existing_path(tmp_path):
    checkout = tmp_path / "proj"
    checkout.mkdir()
    assert locate_checkout(str(checkout)) == str(checkout)


def test_locate_checkout_raises_when_missing():
    with pytest.raises(FileNotFoundError, match="NFS mount path not found"):
        locate_checkout("/modernize-data/studio-data/no/such/path")


def test_resolve_visible_checkout_derives_when_explicit_stale(monkeypatch, tmp_path):
    mount = tmp_path / "studio-app"
    component = (
        mount
        / "TNT1001"
        / "APP172687"
        / "transformed-code"
        / "101"
        / "studio-workspace"
        / "Bvcmp"
    )
    component.mkdir(parents=True)

    class _AppDbJob3:
        nfs_base_path = str(mount)

    class _Settings:
        claude_workspace = str(mount / "claude-workspace")
        app_db_job3 = _AppDbJob3()
        security = None

    monkeypatch.setattr(
        "app.core.config.get_settings",
        lambda: _Settings(),
    )
    monkeypatch.setattr(
        "app.services.oracle_pg.app_db_change.workspace.get_settings",
        lambda: _Settings(),
    )

    resolved = resolve_visible_checkout(
        "/wrong/Eksa",
        app_id="APP172687",
        tenant_id="TNT1001",
        plan_id="101",
    )
    assert resolved == str(component)
