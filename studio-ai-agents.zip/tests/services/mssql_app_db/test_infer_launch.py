"""MSSQL vs Oracle App+DB launch routing."""

from __future__ import annotations

from app.services.mssql_app_db.constants import FINDINGS_JAVA_MSSQL, RULES_JAVA_MSSQL
from app.services.mssql_app_db.infer_launch import ENGINE_MSSQL, ENGINE_ORACLE, infer_engine_for_launch


def test_launch_prefers_staged_mssql_inputs_over_oracle_paths_in_body():
    request = {
        "dbId": "DB0301",
        "inputPaths": {
            "dependencyFindings": f"_claude/{FINDINGS_JAVA_MSSQL}",
            "rulesRemediation": f"_claude/{RULES_JAVA_MSSQL}",
        },
    }
    assert infer_engine_for_launch(request) == ENGINE_MSSQL


def test_launch_source_dialect_mssql():
    request = {
        "dbId": "DB0301",
        "sourceDialect": "mssql",
        "inputPaths": {
            "dependencyFindings": "java-oracle-dependency.json",
        },
    }
    assert infer_engine_for_launch(request) == ENGINE_MSSQL


def test_launch_oracle_when_only_oracle_filenames():
    request = {
        "dbId": "DB1",
        "inputPaths": {
            "dependencyFindings": "_claude/java-oracle-dependency.json",
            "rulesRemediation": "_claude/oracle-to-postgresql-rules_remediation.json",
        },
    }
    assert infer_engine_for_launch(request) == ENGINE_ORACLE
