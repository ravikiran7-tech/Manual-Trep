"""MSSQL App+DB API test helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional, Tuple
from unittest.mock import patch

from app.services.mssql_app_db.job_manager import reset_mssql_app_db_job_manager
from app.services.oracle_pg.agent_runner import SessionResult
from app.services.oracle_pg.app_db_change.progress_tracker import reset_progress_tracker
from app.services.oracle_pg.app_db_change import workspace as ws
from tests.services.mssql_app_db.mssql_test_assets import stage_mssql_inputs
from tests.services.oracle_pg.app_db_change.run_helpers import patch_app_db_workspace


def patch_mssql_app_db_workspace(monkeypatch, tmp_path: Path):
    settings = patch_app_db_workspace(monkeypatch, tmp_path)
    for target in (
        "app.services.oracle_pg.app_db_change.progress_tracker.get_settings",
        "app.services.mssql_app_db.job_manager.get_settings",
    ):
        monkeypatch.setattr(target, lambda: settings, raising=False)
    for api_mod in ("app_db_transformation_dispatch",):
        try:
            monkeypatch.setattr(f"app.api.v1.{api_mod}.settings", settings)
        except Exception:  # noqa: BLE001
            pass
    reset_progress_tracker()
    reset_mssql_app_db_job_manager()
    return settings


async def _fake_mssql_remediator(*, transformation_id, checkout, plan, **kwargs):
    for item in plan.get("violations") or []:
        if str(item.get("status") or "").lower() != "pending" or not item.get("file"):
            continue
        path = Path(checkout) / item["file"]
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        text = text.replace(
            "jdbc:sqlserver://localhost:1433;databaseName=app",
            "jdbc:postgresql://localhost:5432/app",
        ).replace(
            "Server=localhost;Database=app;User Id=sa;Password=secret;",
            "Host=localhost;Port=5432;Database=app;",
        )
        path.write_text(text, encoding="utf-8")
    return SessionResult(success=True, result_text="mssql-llm-mock")


async def launch_mssql_and_complete(
    monkeypatch,
    tmp_path: Path,
    *,
    lang: str = "java",
    app_id: str = "APP1",
    db_id: str = "MSSQL-1",
    app_client: Any | None = None,
    via_api: bool = True,
    skip_llm: bool = True,
    pathway: str = "M-Upgrade",
) -> Tuple[str, Path, dict]:
    """Launch MSSQL App+DB and await orchestrator completion."""
    from app.services.mssql_app_db.job_manager import get_mssql_app_db_job_manager

    patch_mssql_app_db_workspace(monkeypatch, tmp_path)
    checkout = tmp_path / "checkout"
    checkout.mkdir(parents=True, exist_ok=True)
    stage_mssql_inputs(ws.inputs_dir(db_id), checkout, lang=lang)

    if not skip_llm:
        monkeypatch.setattr(
            "app.services.mssql_app_db.orchestrator.run_app_db_remediator_session",
            _fake_mssql_remediator,
        )

    body = {
        "appId": app_id,
        "dbId": db_id,
        "projectPath": str(checkout),
        "projectType": "csharp" if lang == "csharp" else "java",
        "pathway": pathway,
        "skipLlm": skip_llm,
    }

    if via_api and app_client is not None:
        response = app_client.post(
            "/studio-ai-agents/api/app-db-transformation/launch",
            json=body,
        )
        assert response.status_code == 202, response.text
        payload = response.json()
        tid = payload["transformationId"]
    else:
        manager = get_mssql_app_db_job_manager()
        started = await manager.launch(body)
        tid = started["transformationId"]
        payload = started

    manager = get_mssql_app_db_job_manager()
    task = manager._tasks.get(db_id)
    if task is not None:
        await task
    return tid, checkout, payload
