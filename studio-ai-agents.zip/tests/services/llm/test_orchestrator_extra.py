"""Additional LLMOrchestrator coverage: agentic loops, security gates, retries,
event emission, graph state conversion, error translation, usage helpers."""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from app.core.exceptions import ProviderError, RateLimitError
from app.services.llm import orchestrator as orch_mod
from app.services.llm.orchestrator import (
    LLMOrchestrator,
    _accumulate_usage,
    _build_usage_summary_event,
    _enhance_tool_error,
    _compose_system_prompt,
    _emit,
    _emit_sync,
    _execute_with_write_retry,
    _graph_state_to_events,
    _log_per_turn_usage,
    _security_rejection_reason,
)
from app.services.llm.protocol import ChatMessage, ChatResponse, ToolUse


class _NoopRateLimiter:
    @asynccontextmanager
    async def acquire(self, estimated_tokens: int = 0):
        yield


class _RaisingRateLimiter:
    def __init__(self, exc):
        self._exc = exc

    @asynccontextmanager
    async def acquire(self, estimated_tokens: int = 0):
        raise self._exc
        yield  # pragma: no cover


class ScriptedProvider:
    name = "scripted"
    model_id = "scripted-model"

    def __init__(self, responses, chat_exc=None):
        self._responses = list(responses)
        self._chat_exc = chat_exc
        self.calls: list[dict[str, Any]] = []

    async def chat(self, *, messages, system, tools, max_tokens, temperature):
        self.calls.append({"messages": messages, "system": system, "tools": tools})
        if self._chat_exc is not None:
            raise self._chat_exc
        return self._responses.pop(0)

    async def health_check(self):
        return {"provider": self.name, "status": "healthy"}


def _orch(provider, rate_limiter=None):
    return LLMOrchestrator(
        provider=provider,
        rate_limiter=rate_limiter or _NoopRateLimiter(),
        circuit_breaker=None,
        max_tokens=100,
        temperature=0.0,
    )


def _resp(**kw):
    kw.setdefault("raw", {})
    return ChatResponse(**kw)


# --------------------------------------------------------------- properties / simple


def test_model_id_and_provider_name_properties():
    o = _orch(ScriptedProvider([]))
    assert o.model_id == "scripted-model"
    assert o.provider_name == "scripted"


@pytest.mark.asyncio
async def test_invoke_simple_passes_max_and_temp():
    provider = ScriptedProvider([_resp(text_blocks=["x"], stop_reason="end_turn", raw={"r": 1})])
    o = _orch(provider)
    out = await o.invoke_simple("hi", max_tokens=42, temperature=0.9)
    assert out == {"r": 1}


@pytest.mark.asyncio
async def test_health_check_delegates_to_provider():
    o = _orch(ScriptedProvider([]))
    assert (await o.health_check())["status"] == "healthy"


# --------------------------------------------------------------- enable_tools=False


@pytest.mark.asyncio
async def test_invoke_with_tools_disabled_emits_usage_summary_and_returns():
    provider = ScriptedProvider(
        [_resp(text_blocks=["done"], stop_reason="end_turn",
               usage={"input_tokens": 2, "output_tokens": 1, "total_input_tokens": 2})]
    )
    o = _orch(provider)
    events = await o.invoke_with_tools(
        prompt="p", project_path="/tmp/proj", enable_tools=False
    )
    assert events[-1]["subtype"] == "usage_summary"
    # No tools => tools arg is None on the single call.
    assert provider.calls[0]["tools"] is None
    assert len(provider.calls) == 1


@pytest.mark.asyncio
async def test_invoke_with_tools_process_response_false_appends_raw():
    provider = ScriptedProvider(
        [_resp(text_blocks=["done"], stop_reason="end_turn", raw={"raw": "yes"})]
    )
    o = _orch(provider)
    events = await o.invoke_with_tools(
        prompt="p", project_path="/tmp", enable_tools=False, process_response=False
    )
    assert {"raw": "yes"} in events


@pytest.mark.asyncio
async def test_invoke_with_tools_agentic_prepend_project_context_false():
    provider = ScriptedProvider(
        [_resp(text_blocks=["done"], stop_reason="end_turn")]
    )
    o = _orch(provider)
    await o.invoke_with_tools_agentic(
        prompt="only-prompt",
        project_path="/tmp/proj",
        enable_tools=False,
        prepend_project_context=False,
    )
    assert provider.calls[0]["messages"][0].content[0] == "only-prompt"


@pytest.mark.asyncio
async def test_invoke_with_tools_agentic_prepend_project_context_true_by_default():
    provider = ScriptedProvider(
        [_resp(text_blocks=["done"], stop_reason="end_turn")]
    )
    o = _orch(provider)
    await o.invoke_with_tools_agentic(
        prompt="only-prompt",
        project_path="/tmp/proj",
        enable_tools=False,
    )
    assert (
        provider.calls[0]["messages"][0].content[0]
        == "Project directory: /tmp/proj\n\nonly-prompt"
    )


# --------------------------------------------------------------- max_tokens stop


@pytest.mark.asyncio
async def test_loop_breaks_on_max_tokens(tmp_path):
    provider = ScriptedProvider([_resp(text_blocks=["partial"], stop_reason="max_tokens")])
    o = _orch(provider)
    events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))
    assert len(provider.calls) == 1
    assert events[-1]["subtype"] == "usage_summary"


@pytest.mark.asyncio
async def test_loop_breaks_on_other_stop_reason(tmp_path):
    provider = ScriptedProvider([_resp(text_blocks=["x"], stop_reason="other")])
    o = _orch(provider)
    await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))
    assert len(provider.calls) == 1


@pytest.mark.asyncio
async def test_loop_breaks_when_tool_use_but_no_tool_uses(tmp_path):
    # stop_reason tool_use but empty tool_uses -> break.
    provider = ScriptedProvider([_resp(text_blocks=["x"], stop_reason="tool_use", tool_uses=[])])
    o = _orch(provider)
    await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))
    assert len(provider.calls) == 1


# --------------------------------------------------------------- max_iterations event


@pytest.mark.asyncio
async def test_max_iterations_reached_event_emitted(tmp_path):
    # Always tool_use -> never end_turn -> hit cap and emit max_iterations_reached.
    responses = [
        _resp(
            text_blocks=["t"],
            tool_uses=[ToolUse(tool_use_id=f"t{i}", name="bash", input={"command": "echo"})],
            stop_reason="tool_use",
        )
        for i in range(10)
    ]
    provider = ScriptedProvider(responses)
    o = _orch(provider)

    fake_exec = MagicMock()
    fake_exec.execute_tool.return_value = MagicMock(success=True, error=None, execution_time_ms=1)
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model",
        return_value={"content": "ok"},
    ):
        events = await o.invoke_with_tools(prompt="loop", project_path=str(tmp_path))

    subtypes = [e.get("subtype") for e in events]
    assert "max_iterations_reached" in subtypes


# --------------------------------------------------------------- agentic variants


@pytest.mark.asyncio
async def test_invoke_with_tools_agentic_with_event_callback(tmp_path):
    provider = ScriptedProvider([_resp(text_blocks=["done"], stop_reason="end_turn")])
    o = _orch(provider)
    collected = []

    async def on_event(ev):
        collected.append(ev)

    fake_settings = MagicMock()
    fake_settings.agentic.max_iterations = 3
    fake_settings.agentic.unlimited_iterations = False
    with patch.object(orch_mod, "_settings", fake_settings):
        events = await o.invoke_with_tools_agentic(
            prompt="p", project_path=str(tmp_path), on_event=on_event
        )
    assert collected  # callback fired
    assert any(e.get("subtype") == "usage_summary" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_agentic_unlimited(tmp_path):
    provider = ScriptedProvider([_resp(text_blocks=["done"], stop_reason="end_turn")])
    o = _orch(provider)
    fake_settings = MagicMock()
    fake_settings.agentic.max_iterations = 0  # triggers unlimited branch
    fake_settings.agentic.unlimited_iterations = True
    with patch.object(orch_mod, "_settings", fake_settings):
        await o.invoke_with_tools_agentic(prompt="p", project_path=str(tmp_path))
    assert len(provider.calls) == 1


@pytest.mark.asyncio
async def test_agentic_graph_falls_back_without_factory(tmp_path):
    provider = ScriptedProvider([_resp(text_blocks=["done"], stop_reason="end_turn")])
    o = _orch(provider)
    fake_settings = MagicMock()
    fake_settings.agentic.max_iterations = 2
    fake_settings.agentic.unlimited_iterations = False
    with patch.object(orch_mod, "_settings", fake_settings):
        events = await o.invoke_with_tools_agentic_graph(
            prompt="p", project_path=str(tmp_path), provider_factory=None
        )
    assert any(e.get("subtype") == "usage_summary" for e in events)


@pytest.mark.asyncio
async def test_agentic_graph_uses_graph_orchestrator(tmp_path):
    provider = ScriptedProvider([])
    o = _orch(provider)

    fake_state = _make_graph_state()
    fake_orch_instance = MagicMock()

    async def fake_orchestrate(prompt, on_event=None):
        return fake_state

    fake_orch_instance.orchestrate = fake_orchestrate
    graph_orch_cls = MagicMock(return_value=fake_orch_instance)

    fake_module = MagicMock()
    with patch.dict(
        "sys.modules",
        {"app.orchestrator.graph_orchestrator": MagicMock(GraphOrchestrator=graph_orch_cls)},
    ):
        events = await o.invoke_with_tools_agentic_graph(
            prompt="p",
            project_path=str(tmp_path),
            provider_factory=lambda: provider,
        )
    assert any(e.get("subtype") == "graph_start" for e in events)
    assert any(e.get("subtype") == "graph_complete" for e in events)


@pytest.mark.asyncio
async def test_agentic_graph_raises_on_orchestrate_failure(tmp_path):
    provider = ScriptedProvider([])
    o = _orch(provider)
    fake_orch_instance = MagicMock()

    async def fake_orchestrate(prompt, on_event=None):
        raise RuntimeError("graph boom")

    fake_orch_instance.orchestrate = fake_orchestrate
    graph_orch_cls = MagicMock(return_value=fake_orch_instance)
    with patch.dict(
        "sys.modules",
        {"app.orchestrator.graph_orchestrator": MagicMock(GraphOrchestrator=graph_orch_cls)},
    ):
        with pytest.raises(RuntimeError):
            await o.invoke_with_tools_agentic_graph(
                prompt="p", project_path=str(tmp_path), provider_factory=lambda: provider
            )


# --------------------------------------------------------------- _chat error paths


@pytest.mark.asyncio
async def test_chat_propagates_rate_limit_error(tmp_path):
    provider = ScriptedProvider([_resp()])
    o = _orch(provider, rate_limiter=_RaisingRateLimiter(RateLimitError(message="rl")))
    with pytest.raises(RateLimitError):
        await o.invoke_simple("hi")


@pytest.mark.asyncio
async def test_chat_propagates_provider_error():
    provider = ScriptedProvider([], chat_exc=ProviderError(message="pe", provider="scripted"))
    o = _orch(provider)
    with pytest.raises(ProviderError):
        await o.invoke_simple("hi")


@pytest.mark.asyncio
async def test_chat_wraps_unexpected_error_in_provider_error():
    provider = ScriptedProvider([], chat_exc=RuntimeError("weird"))
    o = _orch(provider)
    with pytest.raises(ProviderError) as exc:
        await o.invoke_simple("hi")
    assert "Unexpected LLM error" in str(exc.value)


# --------------------------------------------------------------- security gate in _execute_tools


@pytest.mark.asyncio
async def test_execute_tools_security_rejection_then_success(tmp_path):
    # First response asks for an unsafe bash command, second ends.
    first = _resp(
        tool_uses=[ToolUse(tool_use_id="t1", name="bash", input={"command": "rm -rf /"})],
        stop_reason="tool_use",
    )
    second = _resp(text_blocks=["ok"], stop_reason="end_turn")
    provider = ScriptedProvider([first, second])
    o = _orch(provider)

    fake_settings = MagicMock()
    fake_settings.agentic.tool_execution_timeout = 30
    fake_settings.agentic.max_consecutive_errors = 3

    fake_exec = MagicMock()
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model", return_value={"content": "x"}
    ), patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator._security_rejection_reason",
        return_value="dangerous command",
    ):
        events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))

    rejected = [e for e in events if e["type"] == "tool_result" and not e["success"]]
    assert rejected
    # executor.execute_tool never called because rejected before execution.
    fake_exec.execute_tool.assert_not_called()


@pytest.mark.asyncio
async def test_execute_tools_security_rejection_trips_consecutive_cap(tmp_path):
    first = _resp(
        tool_uses=[
            ToolUse(tool_use_id=f"t{i}", name="bash", input={"command": "bad"})
            for i in range(3)
        ],
        stop_reason="tool_use",
    )
    provider = ScriptedProvider([first, _resp(text_blocks=["x"], stop_reason="end_turn")])
    o = _orch(provider)

    fake_settings = MagicMock()
    fake_settings.agentic.tool_execution_timeout = 30
    fake_settings.agentic.max_consecutive_errors = 3

    fake_exec = MagicMock()
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model", return_value={"content": "x"}
    ), patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator._security_rejection_reason", return_value="bad",
    ):
        events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))

    errors = [e for e in events if e["type"] == "error"]
    assert errors
    assert "Max consecutive failures" in errors[-1]["error"]
    # Loop short circuits -> only the initial provider call.
    assert len(provider.calls) == 1


@pytest.mark.asyncio
async def test_execute_tools_failure_enhances_error_and_continues(tmp_path):
    first = _resp(
        tool_uses=[ToolUse(tool_use_id="t1", name="code_editor",
                           input={"path": "a.py", "operation": "read"})],
        stop_reason="tool_use",
    )
    provider = ScriptedProvider([first, _resp(text_blocks=["ok"], stop_reason="end_turn")])
    o = _orch(provider)

    fake_settings = MagicMock()
    fake_settings.agentic.tool_execution_timeout = 30
    fake_settings.agentic.max_consecutive_errors = 5

    fake_exec = MagicMock()
    fake_exec.execute_tool.return_value = MagicMock(success=False, error="disk full", execution_time_ms=1)
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model", return_value={"content": "err"}
    ), patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator._security_rejection_reason", return_value=None,
    ):
        events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))

    # One failing tool but cap not reached -> loop continued to end_turn.
    assert len(provider.calls) == 2
    tool_results = [e for e in events if e["type"] == "tool_result"]
    assert tool_results and tool_results[0]["success"] is False


# --------------------------------------------------------------- write retry


def test_execute_with_write_retry_success_and_verified(tmp_path):
    target = tmp_path / "out.txt"
    target.write_text("data")
    executor = MagicMock()
    executor.execute_tool.return_value = MagicMock(success=True, error=None)
    result = _execute_with_write_retry(
        executor, "code_editor", {"path": str(target), "operation": "write"}, "t1", str(tmp_path)
    )
    assert result.success is True
    executor.execute_tool.assert_called_once()


def test_execute_with_write_retry_verification_fails_then_retries(tmp_path):
    # File never created -> verification fails on every attempt; sleeps patched.
    executor = MagicMock()
    executor.execute_tool.return_value = MagicMock(success=True, error=None)
    with patch("app.services.llm.orchestrator.time.sleep") as sleep_mock:
        result = _execute_with_write_retry(
            executor, "code_editor",
            {"path": "missing.txt", "operation": "write"}, "t1", str(tmp_path)
        )
    assert result.success is False
    assert "verification failed" in result.error
    assert executor.execute_tool.call_count == 3
    assert sleep_mock.call_count == 2


def test_execute_with_write_retry_no_path_returns_result(tmp_path):
    executor = MagicMock()
    executor.execute_tool.return_value = MagicMock(success=True, error=None)
    result = _execute_with_write_retry(
        executor, "code_editor", {"operation": "write"}, "t1", str(tmp_path)
    )
    assert result.success is True


def test_execute_with_write_retry_failing_executor_retries(tmp_path):
    executor = MagicMock()
    executor.execute_tool.return_value = MagicMock(success=False, error="perm denied")
    with patch("app.services.llm.orchestrator.time.sleep"):
        result = _execute_with_write_retry(
            executor, "code_editor",
            {"path": "x.txt", "operation": "write"}, "t1", str(tmp_path)
        )
    assert result.success is False
    assert executor.execute_tool.call_count == 3


@pytest.mark.asyncio
async def test_write_operation_uses_retry_path(tmp_path):
    target = tmp_path / "f.txt"
    first = _resp(
        tool_uses=[ToolUse(tool_use_id="t1", name="code_editor",
                           input={"path": str(target), "operation": "write", "content": "x"})],
        stop_reason="tool_use",
    )
    provider = ScriptedProvider([first, _resp(text_blocks=["ok"], stop_reason="end_turn")])
    o = _orch(provider)

    fake_settings = MagicMock()
    fake_settings.agentic.tool_execution_timeout = 30
    fake_settings.agentic.max_consecutive_errors = 5

    def exec_side_effect(name, inp, tuid):
        target.write_text("written")
        return MagicMock(success=True, error=None, execution_time_ms=1)

    fake_exec = MagicMock()
    fake_exec.execute_tool.side_effect = exec_side_effect
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model", return_value={"content": "ok"}
    ), patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator._security_rejection_reason", return_value=None,
    ):
        events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))
    assert any(e["type"] == "tool_result" and e["success"] for e in events)


# --------------------------------------------------------------- _normalize security filter


def test_normalize_emits_security_error_for_unsafe_tool(tmp_path):
    provider = ScriptedProvider([])
    o = _orch(provider)
    resp = _resp(
        tool_uses=[ToolUse(tool_use_id="t1", name="bash", input={"command": "rm -rf /"})],
        stop_reason="tool_use",
    )
    with patch("app.services.llm.orchestrator._security_rejection_reason", return_value="unsafe"):
        events = o._normalize(resp, str(tmp_path))
    assert any(e["type"] == "error" and "Security validation failed" in e["error"] for e in events)
    # No tool_use event emitted for the rejected tool.
    assert not any(e["type"] == "tool_use" for e in events)


# --------------------------------------------------------------- pure helpers


def test_compose_system_prompt_with_and_without_user_prompt():
    assert _compose_system_prompt(None).strip()
    composed = _compose_system_prompt("CUSTOM")
    assert composed.startswith("CUSTOM")


def test_enhance_tool_error_code_editor():
    tu = ToolUse(tool_use_id="t", name="code_editor", input={"operation": "write", "path": "a.py"})
    msg = _enhance_tool_error(tu, "base")
    assert "Operation: write" in msg and "File path: a.py" in msg


def test_enhance_tool_error_bash():
    tu = ToolUse(tool_use_id="t", name="bash", input={"command": "ls -la"})
    msg = _enhance_tool_error(tu, "base")
    assert "Command: ls -la" in msg


def test_security_rejection_reason_safe_returns_none():
    # No command -> None.
    assert _security_rejection_reason("bash", {}, "/tmp") is None
    assert _security_rejection_reason("code_editor", {}, "/tmp") is None
    assert _security_rejection_reason("other_tool", {"x": 1}, "/tmp") is None


def test_security_rejection_reason_path_traversal():
    fake_settings = MagicMock()
    fake_settings.security.path_traversal_protection_enabled = True
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings):
        reason = _security_rejection_reason("code_editor", {"path": "../etc/passwd"}, "/tmp")
    assert reason and ".." in reason


def test_security_rejection_reason_unsafe_bash():
    fake_settings = MagicMock()
    fake_settings.security.bash_command_validation_enabled = True
    fake_settings.security.allow_safe_pipes = False
    fake_settings.security.allow_safe_command_chains = False
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator.SecurityValidator.validate_bash_command",
        side_effect=ValueError("nope"),
    ):
        reason = _security_rejection_reason("bash", {"command": "rm -rf /"}, "/tmp")
    assert reason == "nope"


def test_security_rejection_reason_bash_validation_disabled():
    fake_settings = MagicMock()
    fake_settings.security.bash_command_validation_enabled = False
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings):
        assert _security_rejection_reason("bash", {"command": "anything"}, "/tmp") is None


def test_security_rejection_reason_path_validation_disabled():
    fake_settings = MagicMock()
    fake_settings.security.path_traversal_protection_enabled = False
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings):
        assert _security_rejection_reason("code_editor", {"path": "../x"}, "/tmp") is None


def test_security_rejection_reason_absolute_path_outside_allowed():
    fake_settings = MagicMock()
    fake_settings.security.path_traversal_protection_enabled = True
    fake_settings.security.get_allowed_directories_list.return_value = []
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator.SecurityValidator.is_safe_absolute_path",
        return_value=False,
    ):
        reason = _security_rejection_reason("code_editor", {"path": "/etc/passwd"}, "/tmp")
    assert reason and "outside allowed" in reason


def test_tool_input_is_safe_warns_when_validation_disabled():
    from app.services.llm.orchestrator import _tool_input_is_safe

    fake_settings = MagicMock()
    fake_settings.security.bash_command_validation_enabled = False
    fake_settings.security.path_traversal_protection_enabled = False
    events: list = []
    with patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings):
        assert _tool_input_is_safe("bash", {"command": "ls"}, "/tmp", events, 0) is True
        assert _tool_input_is_safe(
            "code_editor", {"path": "a.py"}, "/tmp", events, 0
        ) is True
    assert events == []


@pytest.mark.asyncio
async def test_execute_tools_failure_trips_consecutive_cap(tmp_path):
    first = _resp(
        tool_uses=[
            ToolUse(tool_use_id=f"t{i}", name="bash", input={"command": "false"})
            for i in range(3)
        ],
        stop_reason="tool_use",
    )
    provider = ScriptedProvider([first, _resp(text_blocks=["x"], stop_reason="end_turn")])
    o = _orch(provider)

    fake_settings = MagicMock()
    fake_settings.agentic.tool_execution_timeout = 30
    fake_settings.agentic.max_consecutive_errors = 3

    fake_exec = MagicMock()
    fake_exec.execute_tool.return_value = MagicMock(success=False, error="cmd failed", execution_time_ms=1)
    with patch("app.services.tool_executor.ToolExecutor", return_value=fake_exec), patch(
        "app.services.tool_executor.format_tool_result_for_model", return_value={"content": "x"}
    ), patch("app.services.llm.orchestrator.get_settings", return_value=fake_settings), patch(
        "app.services.llm.orchestrator._security_rejection_reason", return_value=None,
    ):
        events = await o.invoke_with_tools(prompt="p", project_path=str(tmp_path))

    errors = [e for e in events if e["type"] == "error"]
    assert errors and "Max consecutive failures" in errors[-1]["error"]
    assert len(provider.calls) == 1


def test_accumulate_and_build_usage_summary():
    totals: dict = {}
    _accumulate_usage(totals, None)  # no-op
    _accumulate_usage(totals, {"input_tokens": 5, "cache_read_input_tokens": 5,
                               "output_tokens": 2, "total_input_tokens": 10})
    _accumulate_usage(totals, {"input_tokens": 3, "total_input_tokens": 3})
    summary = _build_usage_summary_event(totals, turns=2, provider_name="scripted", timestamp=1)
    assert summary["turns"] == 2
    assert summary["total_input_tokens"] == 13
    assert summary["cache_hit_rate"] == round(5 / 13, 4)


def test_build_usage_summary_zero_total():
    summary = _build_usage_summary_event({}, turns=1, provider_name="p", timestamp=0)
    assert summary["cache_hit_rate"] == 0.0


def test_log_per_turn_usage_skips_empty(caplog):
    _log_per_turn_usage("p", "m", None)  # no usage
    _log_per_turn_usage("p", "m", {"input_tokens": 0, "output_tokens": 0})  # all zero
    # With data it logs without error.
    _log_per_turn_usage("p", "m", {"input_tokens": 10, "output_tokens": 2,
                                   "cache_read_input_tokens": 5})


@pytest.mark.asyncio
async def test_emit_handles_sync_and_async_callbacks():
    seen = []

    async def async_cb(ev):
        seen.append(("a", ev))

    def sync_cb(ev):
        seen.append(("s", ev))

    await _emit(None, [{"x": 1}])  # None is a no-op
    await _emit(async_cb, [{"x": 1}])
    await _emit(sync_cb, [{"x": 2}])
    assert ("a", {"x": 1}) in seen
    assert ("s", {"x": 2}) in seen


def test_emit_sync_noop_and_call():
    seen = []
    _emit_sync(None, {"x": 1})
    _emit_sync(lambda ev: seen.append(ev), {"y": 2})
    assert seen == [{"y": 2}]


# --------------------------------------------------------------- graph state conversion


def _make_graph_state():
    class Status:
        def __init__(self, val):
            self.value = val

    module = MagicMock()
    module.name = "mod-a"
    module.path = "src/a"
    module.status = Status("locked")
    module.retries = 1
    module.files_changed = ["a.py"]
    module.last_error = None
    module.events = [{"type": "tool_use", "tool": {}}]

    state = MagicMock()
    state.total_modules = 1
    state.graph = {"mod-a": module}
    state.current_iteration = 2
    state.get_progress.return_value = {"locked": 1, "failed": 0, "skipped": 0}
    return state


def test_graph_state_to_events_emits_summary_events():
    state = _make_graph_state()
    collected = []
    events = _graph_state_to_events(state, on_event=lambda ev: collected.append(ev))
    subtypes = [e.get("subtype") for e in events]
    assert "graph_start" in subtypes
    assert "graph_complete" in subtypes
    assert any(e["type"] == "module_completed" for e in events)
    # Module events carried over with module context.
    assert any(e.get("module") == "mod-a" and e["type"] == "tool_use" for e in events)
    assert collected  # on_event fired