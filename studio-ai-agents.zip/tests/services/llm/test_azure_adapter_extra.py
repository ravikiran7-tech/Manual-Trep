"""Additional AzureAdapter coverage: init, chat, health, sanitize, errors, helpers."""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.core.exceptions import (
    AuthenticationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.adapters import azure as azure_mod
from app.services.llm.adapters.azure import (
    AzureAdapter,
    _is_openai_model,
    _message_to_azure,
    _model_info_to_dict,
    _normalize_usage,
    _raise_translated,
    _sanitize_schema_for_openai,
    _stringify_arguments,
    _to_dict,
)
from app.services.llm.protocol import ChatMessage, ToolSpec, ToolUse


def _patch_client(complete_return=None, complete_side_effect=None,
                  model_info=None, model_info_side_effect=None):
    """Patch the lazily-imported Azure ChatCompletionsClient + credentials."""
    client = MagicMock()
    client.complete = AsyncMock(return_value=complete_return, side_effect=complete_side_effect)
    client.get_model_info = AsyncMock(return_value=model_info, side_effect=model_info_side_effect)
    client_cls = MagicMock(return_value=client)

    inference_aio = SimpleNamespace(ChatCompletionsClient=client_cls)
    credentials = SimpleNamespace(AzureKeyCredential=MagicMock())
    identity_aio = SimpleNamespace(DefaultAzureCredential=MagicMock())
    core_exc = SimpleNamespace(HttpResponseError=azure_mod_http_error())

    patches = patch.dict(
        "sys.modules",
        {
            "azure.ai.inference.aio": inference_aio,
            "azure.core.credentials": credentials,
            "azure.identity.aio": identity_aio,
            "azure.core.exceptions": core_exc,
        },
    )
    return patches, client, client_cls


def azure_mod_http_error():
    # Reuse the real HttpResponseError class so isinstance checks behave.
    from azure.core.exceptions import HttpResponseError

    return HttpResponseError


# --------------------------------------------------------------- construction


def test_init_with_api_key_uses_key_credential():
    patches, client, client_cls = _patch_client()
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude", api_key="secret")
        assert a.endpoint == "https://e"
        assert a.model_id == "claude"
        client_cls.assert_called_once()


def test_init_without_api_key_uses_default_credential():
    patches, client, client_cls = _patch_client()
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="gpt-5", api_key=None)
        # credential_scopes forced for AI Foundry.
        _, kwargs = client_cls.call_args
        assert kwargs["credential_scopes"] == [
            "https://cognitiveservices.azure.com/.default"
        ]


def test_init_failure_raises_provider_error():
    client_cls = MagicMock(side_effect=RuntimeError("init fail"))
    inference_aio = SimpleNamespace(ChatCompletionsClient=client_cls)
    identity_aio = SimpleNamespace(DefaultAzureCredential=MagicMock())
    with patch.dict(
        "sys.modules",
        {
            "azure.ai.inference.aio": inference_aio,
            "azure.identity.aio": identity_aio,
        },
    ):
        with pytest.raises(ProviderError):
            AzureAdapter(endpoint="https://e", model_id="m", api_key=None)


# --------------------------------------------------------------- chat


@pytest.mark.asyncio
async def test_chat_openai_model_uses_max_completion_tokens():
    raw = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content="hi", tool_calls=None),
                finish_reason="stop",
            )
        ],
        usage=None,
    )
    patches, client, _ = _patch_client(complete_return=raw)
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="gpt-5", api_key="k")
        out = await a.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system="sys",
            tools=[ToolSpec(name="bash", description="d", input_schema={"type": "object"})],
            max_tokens=99,
            temperature=0.5,
        )
        assert out.text_blocks == ["hi"]
        body = client.complete.call_args.kwargs
        assert body["model_extras"] == {"max_completion_tokens": 99}
        assert "max_tokens" not in body
        assert body["messages"][0]["role"] == "system"
        assert body["tool_choice"] == "auto"


@pytest.mark.asyncio
async def test_chat_non_openai_model_uses_max_tokens():
    raw = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content="hi", tool_calls=None),
                finish_reason="stop",
            )
        ],
        usage=None,
    )
    patches, client, _ = _patch_client(complete_return=raw)
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude-sonnet", api_key="k")
        await a.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system=None, tools=None, max_tokens=77, temperature=0.0,
        )
        body = client.complete.call_args.kwargs
        assert body["max_tokens"] == 77
        assert "model_extras" not in body
        assert body["temperature"] == 0.0


@pytest.mark.asyncio
async def test_chat_sonnet_55_omits_temperature():
    raw = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content="hi", tool_calls=None),
                finish_reason="stop",
            )
        ],
        usage=None,
    )
    patches, client, _ = _patch_client(complete_return=raw)
    with patches:
        a = AzureAdapter(
            endpoint="https://e",
            model_id="claude-sonnet-5-5",
            api_key="k",
        )
        await a.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system=None,
            tools=None,
            max_tokens=32,
            temperature=0.0,
        )
        body = client.complete.call_args.kwargs
        assert "temperature" not in body
        assert body["max_tokens"] == 32


@pytest.mark.asyncio
async def test_chat_http_response_error_translated_to_rate_limit():
    from azure.core.exceptions import HttpResponseError

    err = HttpResponseError(message="too many")
    err.status_code = 429
    patches, client, _ = _patch_client(complete_side_effect=err)
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude", api_key="k")
        with pytest.raises(RateLimitError):
            await a.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_chat_generic_exception_raises_provider_error():
    patches, client, _ = _patch_client(complete_side_effect=RuntimeError("boom"))
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude", api_key="k")
        with pytest.raises(ProviderError):
            await a.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


# --------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_check_healthy():
    info = SimpleNamespace(
        model_name="claude", model_provider_name="anthropic", model_type="chat"
    )
    patches, client, _ = _patch_client(model_info=info)
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude", api_key="k")
        out = await a.health_check()
        assert out["status"] == "healthy"
        assert out["model_info"]["model_name"] == "claude"


@pytest.mark.asyncio
async def test_health_check_unhealthy():
    patches, client, _ = _patch_client(model_info_side_effect=RuntimeError("nope"))
    with patches:
        a = AzureAdapter(endpoint="https://e", model_id="claude", api_key="k")
        out = await a.health_check()
        assert out["status"] == "unhealthy"
        assert "nope" in out["error"]


# --------------------------------------------------------------- helpers


def test_sanitize_schema_adds_items_to_array():
    schema = {
        "type": "object",
        "properties": {
            "tags": {"type": "array"},
            "mixed": {"type": ["string", "array"]},
        },
    }
    out = _sanitize_schema_for_openai(schema)
    assert out["properties"]["tags"]["items"] == {}
    assert out["properties"]["mixed"]["items"] == {}


def test_sanitize_schema_preserves_existing_items_and_scalars():
    schema = {"type": "array", "items": {"type": "string"}}
    assert _sanitize_schema_for_openai(schema) == schema
    assert _sanitize_schema_for_openai("scalar") == "scalar"
    assert _sanitize_schema_for_openai([{"type": "array"}])[0]["items"] == {}


def test_message_to_azure_user_with_tool_use_block_becomes_text():
    msg = ChatMessage(
        role="user",
        content=[ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"})],
    )
    out = _message_to_azure(msg)
    assert out[0]["role"] == "user"
    assert "[tool_use:bash]" in out[0]["content"]


def test_message_to_azure_assistant_text_only_no_tool_calls():
    out = _message_to_azure(ChatMessage(role="assistant", content=["just text"]))
    assert out[0]["content"] == "just text"
    assert "tool_calls" not in out[0]


def test_message_to_azure_assistant_empty_content():
    out = _message_to_azure(ChatMessage(role="assistant", content=[]))
    assert out[0]["content"] == ""


def test_stringify_arguments_typeerror_fallback():
    # A non-JSON-serializable value falls back to str().
    val = {"x": {1, 2, 3}}  # set is not JSON serializable
    out = _stringify_arguments(val)
    assert isinstance(out, str)


def test_to_dict_variants():
    assert _to_dict(None) == {}
    assert _to_dict({"a": 1}) == {"a": 1}

    class HasAsDict:
        def as_dict(self):
            return {"k": "v"}

    assert _to_dict(HasAsDict()) == {"k": "v"}

    class BadAsDict:
        def as_dict(self):
            raise RuntimeError("fail")

    out = _to_dict(BadAsDict())
    assert "_repr" in out


def test_model_info_to_dict_variants():
    assert _model_info_to_dict(None) == {}
    assert _model_info_to_dict({"a": 1}) == {"a": 1}
    info = SimpleNamespace(model_name="m", model_provider_name="p", model_type="t")
    out = _model_info_to_dict(info)
    assert out["model_name"] == "m"


def test_is_openai_model():
    assert _is_openai_model("gpt-4o")
    assert _is_openai_model("o1-preview")
    assert _is_openai_model("o3")
    assert _is_openai_model("o4-mini")
    assert not _is_openai_model("claude-sonnet")


def test_normalize_usage_with_cache_details():
    usage = _normalize_usage(
        SimpleNamespace(
            prompt_tokens=100,
            completion_tokens=20,
            prompt_tokens_details=SimpleNamespace(cached_tokens=40),
        )
    )
    assert usage["total_input_tokens"] == 100
    assert usage["cache_read_input_tokens"] == 40
    assert usage["input_tokens"] == 60
    assert usage["cache_write_input_tokens"] == 0


def test_normalize_usage_none():
    usage = _normalize_usage(None)
    assert usage["total_input_tokens"] == 0
    assert usage["provider"] == "azure"


def test_raise_translated_auth():
    err = SimpleNamespace(status_code=403, response=None)
    with pytest.raises(AuthenticationError):
        _raise_translated(err)


def test_raise_translated_generic():
    err = SimpleNamespace(status_code=500, response=None)
    with pytest.raises(ProviderError):
        _raise_translated(err)


def test_raise_translated_rate_limit_via_response_object():
    err = SimpleNamespace(status_code=None, response=SimpleNamespace(status_code=429))
    with pytest.raises(RateLimitError):
        _raise_translated(err)