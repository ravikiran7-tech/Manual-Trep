"""Sanity tests for protocol dataclasses."""
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    ToolResult,
    ToolSpec,
    ToolUse,
)


def test_toolspec_is_frozen():
    t = ToolSpec(name="x", description="y", input_schema={})
    try:
        t.name = "z"  # type: ignore[misc]
    except Exception:
        return
    raise AssertionError("ToolSpec should be frozen")


def test_chat_message_accepts_mixed_content():
    msg = ChatMessage(
        role="user",
        content=[
            "hello",
            ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"}),
            ToolResult(tool_use_id="t1", content="ok"),
        ],
    )
    assert msg.role == "user"
    assert len(msg.content) == 3


def test_chat_response_defaults():
    r = ChatResponse()
    assert r.stop_reason == "end_turn"
    assert r.text_blocks == []
    assert r.tool_uses == []
    assert r.raw == {}
