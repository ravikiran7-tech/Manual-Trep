"""OrchestratorProviderFactory dispatch tests."""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.clients.compass_client import ConnectionConfiguration, ConnectionData
from app.core.exceptions import ConfigurationError
from app.services.llm import factory as factory_mod
from app.services.llm import rate_limiting as rl
from app.services.llm.adapters import openai_compatible as oai_mod
from app.services.llm.adapters.openai_compatible import OpenAICompatibleAdapter
from app.services.llm.factory import OrchestratorProviderFactory
from app.services.llm.orchestrator import LLMOrchestrator


# Aliases that ConnectionData carries at the top level rather than inside
# configuration{} (the Concierto private LLM payload shape).
_TOP_LEVEL_ALIASES = ("caiBaseUrl", "caiApiKey", "caiModel")


def _connection(provider_type: str, **fields) -> ConnectionData:
    top_level = {k: fields.pop(k) for k in _TOP_LEVEL_ALIASES if k in fields}
    cfg = ConnectionConfiguration(**fields)
    return ConnectionData(
        connection_id="CON-TEST",
        component="Studio",
        provider_type=provider_type,
        configuration=cfg,
        status="enabled",
        **top_level,
    )


@pytest.mark.asyncio
async def test_get_provider_returns_orchestrator_for_bedrock():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("aws-bedrock", awsRegion="us-east-1", modelId="m-1")
    )

    # Patch the registry entry directly; the factory resolves adapters through
    # _ADAPTER_REGISTRY.get(...), so patching the module-level symbol isn't
    # enough.
    fake_adapter_cls = MagicMock()
    fake_adapter = MagicMock()
    fake_adapter.name = "aws-bedrock"
    fake_adapter.model_id = "m-1"
    fake_adapter_cls.from_connection.return_value = fake_adapter

    with patch.dict(
        factory_mod._ADAPTER_REGISTRY,
        {"aws-bedrock": fake_adapter_cls},
    ):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
        provider = await f.get_provider()

        assert isinstance(provider, LLMOrchestrator)
        assert provider.provider_name == "aws-bedrock"
        fake_adapter_cls.from_connection.assert_called_once()


@pytest.mark.asyncio
async def test_get_provider_dispatches_concierto_private_llm_with_resilience():
    """concierto-private-llm resolves to a fully wrapped OpenAICompatibleAdapter.

    The registry entry alone is not enough: LLMOrchestrator is built with
    get_rate_limiter(adapter.name) / get_circuit_breaker(adapter.name), and both
    raise KeyError for an unregistered adapter name.
    """
    enc = MagicMock()
    enc.is_encrypted.return_value = False
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection(
            "concierto-private-llm",
            caiBaseUrl="http://cei-host:14000",
            caiModel="gemma-4",
            caiApiKey="sk-dummy",
        )
    )

    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=enc)
    provider = await f.get_provider()

    assert isinstance(provider, LLMOrchestrator)
    assert isinstance(provider.provider, OpenAICompatibleAdapter)
    assert provider.provider_name == "openai-compatible"
    assert provider.provider.base_url == "http://cei-host:14000"
    assert provider.provider.model_id == "gemma-4"
    # No KeyError from rate_limiting: both are real, registered instances.
    assert provider.rate_limiter is rl.get_rate_limiter("openai-compatible")
    assert provider.circuit_breaker is rl.get_circuit_breaker("openai-compatible")


@pytest.mark.asyncio
async def test_private_llm_does_not_inherit_bedrock_generation_settings():
    """LLMOrchestrator falls back to _settings.bedrock.* for max_tokens and
    temperature when they are not passed, so the factory must pass this
    provider's own OPENAI_COMPAT_* values explicitly.
    """
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection(
            "concierto-private-llm",
            caiBaseUrl="http://cei-host:14000",
            caiModel="gemma-4",
        )
    )
    enc = MagicMock()
    enc.is_encrypted.return_value = False

    oc = SimpleNamespace(max_tokens=12345, temperature=0.25)
    bedrock = factory_mod._settings.bedrock
    assert (bedrock.max_tokens, bedrock.temperature) != (12345, 0.25), \
        "fixture must differ from the Bedrock settings for this test to mean anything"

    with patch.object(oai_mod, "_settings", SimpleNamespace(openai_compatible=oc)):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=enc)
        provider = await f.get_provider()

    assert provider.max_tokens == 12345
    assert provider.temperature == 0.25
    assert provider.max_tokens != bedrock.max_tokens


@pytest.mark.asyncio
async def test_bedrock_orchestrator_keeps_its_existing_defaults():
    """Only the private LLM gets explicit generation settings; the other
    adapters stay on the orchestrator's existing Bedrock fallback.
    """
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("aws-bedrock", awsRegion="us-east-1", modelId="m-1")
    )

    fake_adapter_cls = MagicMock()
    fake_adapter = MagicMock()
    fake_adapter.name = "aws-bedrock"
    fake_adapter.model_id = "m-1"
    fake_adapter_cls.from_connection.return_value = fake_adapter

    with patch.dict(factory_mod._ADAPTER_REGISTRY, {"aws-bedrock": fake_adapter_cls}):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
        provider = await f.get_provider()

    bedrock = factory_mod._settings.bedrock
    assert provider.max_tokens == bedrock.max_tokens
    assert provider.temperature == bedrock.temperature


def test_generation_settings_only_applies_to_openai_compatible():
    assert factory_mod._generation_settings("aws-bedrock") == {}
    assert factory_mod._generation_settings("portkey") == {}
    assert factory_mod._generation_settings("azure") == {}
    assert set(factory_mod._generation_settings("openai-compatible")) == {
        "max_tokens", "temperature"
    }


@pytest.mark.asyncio
async def test_get_provider_raises_on_unknown_provider_type():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("someprovider-unknown")
    )

    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    with pytest.raises(ConfigurationError):
        await f.get_provider()


@pytest.mark.asyncio
async def test_get_provider_raises_when_no_active_connection():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(return_value=None)

    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    with pytest.raises(ConfigurationError):
        await f.get_provider()


@pytest.mark.asyncio
async def test_get_provider_type_returns_connection_provider_type():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("azure", modelId="claude-sonnet-4-5")
    )

    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    assert await f.get_provider_type() == "azure"
