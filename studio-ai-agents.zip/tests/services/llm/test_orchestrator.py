"""Orchestrator tests — focused on the tool loop and event normalization.

We use a fake LLMProvider ("ScriptedProvider") that returns a pre-planned
sequence of ChatResponse objects. This exercises the tool loop, retry logic,
and normalization without any SDK.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from app.services.llm.orchestrator import LLMOrchestrator
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    ReasoningBlock,
    ToolSpec,
    ToolUse,
)


class _NoopRateLimiter:
    @asynccontextmanager
    async def acquire(self, estimated_tokens: int = 0):
        yield


class ScriptedProvider:
    """Returns a pre-planned sequence of ChatResponses."""

    name = "scripted"
    model_id = "scripted-model"

    def __init__(self, responses: list[ChatResponse]) -> None:
        self._responses = list(responses)
        self.calls: list[dict[str, Any]] = []

    async def chat(self, *, messages, system, tools, max_tokens, temperature) -> ChatResponse:
        self.calls.append(
            {
                "messages": messages,
                "system": system,
                "tools": tools,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }
        )
        return self._responses.pop(0)

    async def health_check(self) -> dict[str, Any]:
        return {"provider": self.name, "status": "healthy"}


def _orchestrator(provider: ScriptedProvider) -> LLMOrchestrator:
    return LLMOrchestrator(
        provider=provider,
        rate_limiter=_NoopRateLimiter(),
        circuit_breaker=None,
        max_tokens=100,
        temperature=0.0,
    )


# ---------------------------------------------- simple end_turn, no tools


@pytest.mark.asyncio
async def test_invoke_simple_returns_raw_dict():
    resp = ChatResponse(
        text_blocks=["hello world"],
        stop_reason="end_turn",
        raw={"whatever": True},
    )
    provider = ScriptedProvider([resp])
    orch = _orchestrator(provider)

    out = await orch.invoke_simple("hi")
    assert out == {"whatever": True}
    assert len(provider.calls) == 1


@pytest.mark.asyncio
async def test_invoke_with_tools_end_turn_no_tools_emits_text_events():
    resp = ChatResponse(
        text_blocks=["done"],
        stop_reason="end_turn",
        raw={},
        usage={
            "input_tokens": 3,
            "output_tokens": 1,
            "cache_read_input_tokens": 0,
            "cache_write_input_tokens": 0,
            "total_input_tokens": 3,
            "provider": "scripted",
        },
    )
    provider = ScriptedProvider([resp])
    orch = _orchestrator(provider)

    events = await orch.invoke_with_tools(prompt="p", project_path="/tmp/proj")

    # Must start with system init; the loop now appends a trailing
    # system/usage_summary event after the per-turn result event.
    assert events[0]["type"] == "system"
    assert events[-1]["type"] == "system"
    assert events[-1]["subtype"] == "usage_summary"
    result_events = [e for e in events if e["type"] == "result"]
    assert len(result_events) == 1
    assert result_events[-1]["input_tokens"] == 3
    assert result_events[-1]["output_tokens"] == 1
    # Must include exactly one text_delta event.
    text_events = [e for e in events if e.get("subtype") == "text_delta"]
    assert len(text_events) == 1
    assert text_events[0]["text"] == "done"
    # Only one provider call because stop_reason is end_turn.
    assert len(provider.calls) == 1


# --------------------------------------------- single tool_use -> end_turn


@pytest.mark.asyncio
async def test_invoke_with_tools_single_tool_use_round_trip(tmp_path):
    first = ChatResponse(
        text_blocks=["let me read"],
        tool_uses=[
            ToolUse(tool_use_id="t1", name="code_editor", input={"path": "a.txt", "operation": "read"})
        ],
        stop_reason="tool_use",
        raw={},
    )
    second = ChatResponse(
        text_blocks=["ok, done"],
        stop_reason="end_turn",
        raw={},
    )
    provider = ScriptedProvider([first, second])
    orch = _orchestrator(provider)

    # Mock ToolExecutor so no real filesystem access.
    fake_executor = MagicMock()
    fake_executor.execute_tool.return_value = MagicMock(
        success=True, error=None, execution_time_ms=5
    )

    with patch(
        "app.services.tool_executor.ToolExecutor", return_value=fake_executor
    ), patch(
        "app.services.tool_executor.format_tool_result_for_model",
        return_value={"content": "file contents"},
    ):
        events = await orch.invoke_with_tools(
            prompt="read the file",
            project_path=str(tmp_path),
        )

    # Must have a tool_use event and a tool_result event, then a final end_turn message_stop.
    tool_use_events = [e for e in events if e["type"] == "tool_use"]
    tool_result_events = [e for e in events if e["type"] == "tool_result"]
    message_stops = [e for e in events if e["type"] == "message_stop"]

    assert len(tool_use_events) == 1
    assert tool_use_events[0]["tool"]["name"] == "code_editor"
    assert len(tool_result_events) == 1
    assert tool_result_events[0]["success"] is True
    # Two message_stops: one per provider turn.
    assert len(message_stops) == 2
    assert message_stops[-1]["stop_reason"] == "end_turn"

    # Provider was called twice (initial + follow-up with tool results).
    assert len(provider.calls) == 2
    # Second call's conversation must contain a user turn with the tool result.
    second_msgs: list[ChatMessage] = provider.calls[1]["messages"]
    assert any(
        m.role == "user" and any(hasattr(c, "content") for c in m.content)
        for m in second_msgs
    )


@pytest.mark.asyncio
async def test_tool_turn_replays_reasoning_block(tmp_path):
    signed = {"reasoningContent": {"reasoningText": {"text": "", "signature": "sig"}}}
    reasoning = ReasoningBlock(payload=signed)
    tool = ToolUse(tool_use_id="t1", name="bash", input={"command": "echo"})
    first = ChatResponse(
        text_blocks=["looking"],
        tool_uses=[tool],
        stop_reason="tool_use",
        ordered_content=[reasoning, "looking", tool],
    )
    second = ChatResponse(text_blocks=["done"], stop_reason="end_turn")
    provider = ScriptedProvider([first, second])
    orch = _orchestrator(provider)

    fake_executor = MagicMock()
    fake_executor.execute_tool.return_value = MagicMock(
        success=True, error=None, execution_time_ms=1
    )
    with patch(
        "app.services.tool_executor.ToolExecutor", return_value=fake_executor
    ), patch(
        "app.services.tool_executor.format_tool_result_for_model",
        return_value={"content": "ok"},
    ):
        await orch.invoke_with_tools(prompt="run", project_path=str(tmp_path))

    assistant = next(m for m in provider.calls[1]["messages"] if m.role == "assistant")
    assert assistant.content[0] == reasoning
    assert assistant.content[1] == "looking"
    assert assistant.content[2] == tool


# --------------------------------------------- tool_use never stops → respects max_turns


@pytest.mark.asyncio
async def test_invoke_with_tools_stops_after_max_turns(tmp_path):
    """Even if model keeps requesting tools, orchestrator stops at 5 follow-ups."""
    # 7 tool-use responses in a row — orchestrator should cap at 5 follow-ups.
    responses = [
        ChatResponse(
            text_blocks=["calling"],
            tool_uses=[ToolUse(tool_use_id=f"t{i}", name="bash", input={"command": "echo"})],
            stop_reason="tool_use",
            raw={},
        )
        for i in range(7)
    ]
    provider = ScriptedProvider(responses)
    orch = _orchestrator(provider)

    fake_executor = MagicMock()
    fake_executor.execute_tool.return_value = MagicMock(success=True, error=None, execution_time_ms=1)

    with patch(
        "app.services.tool_executor.ToolExecutor", return_value=fake_executor
    ), patch(
        "app.services.tool_executor.format_tool_result_for_model",
        return_value={"content": "ok"},
    ):
        await orch.invoke_with_tools(
            prompt="loop",
            project_path=str(tmp_path),
        )

    # Initial call + up to 5 follow-ups = 6 calls max.
    assert len(provider.calls) <= 6


# --------------------------------------------- consecutive failures short-circuit


@pytest.mark.asyncio
async def test_invoke_with_tools_stops_after_consecutive_tool_failures(tmp_path):
    # 5 tool uses, all of which will fail.
    first = ChatResponse(
        text_blocks=[],
        tool_uses=[
            ToolUse(tool_use_id=f"t{i}", name="bash", input={"command": "false"})
            for i in range(5)
        ],
        stop_reason="tool_use",
        raw={},
    )
    # We don't expect the orchestrator to ask the model again after tripping
    # the consecutive-failures guard, but include a sentinel to be safe.
    sentinel = ChatResponse(text_blocks=["should not see"], stop_reason="end_turn", raw={})
    provider = ScriptedProvider([first, sentinel])
    orch = _orchestrator(provider)

    fake_executor = MagicMock()
    fake_executor.execute_tool.return_value = MagicMock(
        success=False, error="failed", execution_time_ms=1
    )

    # Drop the consecutive-failure ceiling to 3 so 5 failing tools trips it.
    # Production reads this from settings.agentic.max_consecutive_errors
    # (default 10) — matches legacy bedrock_client/portkey_client behaviour.
    fake_settings = MagicMock()
    fake_settings.agentic.max_consecutive_errors = 3
    fake_settings.agentic.tool_execution_timeout = 30

    with patch(
        "app.services.tool_executor.ToolExecutor", return_value=fake_executor
    ), patch(
        "app.services.tool_executor.format_tool_result_for_model",
        return_value={"content": "failed"},
    ), patch(
        "app.services.llm.orchestrator.get_settings",
        return_value=fake_settings,
    ):
        events = await orch.invoke_with_tools(
            prompt="fails",
            project_path=str(tmp_path),
        )

    errors = [e for e in events if e["type"] == "error"]
    assert errors, "Orchestrator should emit an error event when tripping the failure guard"
    assert "Max consecutive failures" in errors[-1]["error"]
    # Only the initial provider call — no follow-up after short circuit.
    assert len(provider.calls) == 1
