"""Additional OrchestratorProviderFactory coverage: error paths, health, defaults."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.clients.compass_client import ConnectionConfiguration, ConnectionData
from app.core.exceptions import ConfigurationError, ProviderError
from app.services.llm import factory as factory_mod
from app.services.llm.factory import OrchestratorProviderFactory


def _connection(provider_type: str, **cfg_fields) -> ConnectionData:
    cfg = ConnectionConfiguration(**cfg_fields)
    return ConnectionData(
        connection_id="CON-TEST",
        component="Studio",
        provider_type=provider_type,
        configuration=cfg,
        status="enabled",
    )


def test_factory_default_construction_uses_defaults():
    # No compass_client / encryption_utils passed -> defaults constructed.
    with patch.object(factory_mod, "CompassClient") as compass_cls, patch.object(
        factory_mod, "get_encryption_utils"
    ) as get_enc:
        compass_cls.return_value = MagicMock()
        get_enc.return_value = MagicMock()
        f = OrchestratorProviderFactory()
        assert f.compass_client is compass_cls.return_value
        assert f.encryption_utils is get_enc.return_value


@pytest.mark.asyncio
async def test_get_provider_reraises_configuration_error_from_adapter():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("aws-bedrock", awsRegion="us-east-1", modelId="m-1")
    )
    fake_adapter_cls = MagicMock()
    fake_adapter_cls.from_connection.side_effect = ConfigurationError(
        message="bad config"
    )
    with patch.dict(factory_mod._ADAPTER_REGISTRY, {"aws-bedrock": fake_adapter_cls}):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
        with pytest.raises(ConfigurationError):
            await f.get_provider()


@pytest.mark.asyncio
async def test_get_provider_wraps_unexpected_adapter_error_in_provider_error():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("portkey", modelId="m-1")
    )
    fake_adapter_cls = MagicMock()
    fake_adapter_cls.from_connection.side_effect = RuntimeError("boom")
    with patch.dict(factory_mod._ADAPTER_REGISTRY, {"portkey": fake_adapter_cls}):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
        with pytest.raises(ProviderError) as exc:
            await f.get_provider()
        assert "Failed to create portkey adapter" in str(exc.value)


@pytest.mark.asyncio
async def test_get_provider_uses_explicit_component():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(
        return_value=_connection("azure", modelId="claude-sonnet-4-5")
    )
    fake_adapter_cls = MagicMock()
    fake_adapter = MagicMock()
    fake_adapter.name = "azure"
    fake_adapter.model_id = "claude-sonnet-4-5"
    fake_adapter_cls.from_connection.return_value = fake_adapter
    with patch.dict(factory_mod._ADAPTER_REGISTRY, {"azure": fake_adapter_cls}):
        f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
        await f.get_provider(component="MyComponent")
    compass.get_active_connection.assert_awaited_once_with("MyComponent")


@pytest.mark.asyncio
async def test_get_provider_type_returns_none_when_no_connection():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(return_value=None)
    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    assert await f.get_provider_type() is None


@pytest.mark.asyncio
async def test_get_provider_type_returns_none_on_exception():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(side_effect=RuntimeError("down"))
    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    assert await f.get_provider_type() is None


@pytest.mark.asyncio
async def test_health_check_reports_compass_up():
    compass = MagicMock()
    compass.health_check = AsyncMock(return_value=True)
    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    health = await f.health_check()
    assert health["compass"] is True
    assert health["providers"] == {}


@pytest.mark.asyncio
async def test_health_check_handles_compass_failure():
    compass = MagicMock()
    compass.health_check = AsyncMock(side_effect=RuntimeError("unreachable"))
    f = OrchestratorProviderFactory(compass_client=compass, encryption_utils=MagicMock())
    health = await f.health_check()
    assert health["compass"] is False
