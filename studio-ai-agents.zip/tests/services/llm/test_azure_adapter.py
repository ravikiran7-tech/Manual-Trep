"""AzureAdapter translation tests.

Azure SDK construction is lazy-imported inside AzureAdapter.__init__, so we
only test the pure translation helpers without constructing the adapter. This
keeps the test independent of azure-* package installation state.
"""
from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.clients.compass_client import ConnectionData
from app.core.exceptions import ConfigurationError
from app.services.llm.adapters.azure import (
    AzureAdapter,
    _map_finish_reason,
    _message_to_azure,
    _parse_arguments,
    _response_from_azure,
    _stringify_arguments,
    _tool_spec_to_azure,
)
from app.services.llm.protocol import (
    ChatMessage,
    ToolResult,
    ToolSpec,
    ToolUse,
)


def test_tool_spec_to_azure_uses_function_tool_shape():
    ts = ToolSpec(
        name="bash",
        description="run a command",
        input_schema={"type": "object"},
    )
    assert _tool_spec_to_azure(ts) == {
        "type": "function",
        "function": {
            "name": "bash",
            "description": "run a command",
            "parameters": {"type": "object"},
        },
    }


def test_message_to_azure_user_text_only_emits_single_user_message():
    out = _message_to_azure(ChatMessage(role="user", content=["hi"]))
    assert out == [{"role": "user", "content": "hi"}]


def test_message_to_azure_assistant_tool_use_emits_tool_calls():
    msg = ChatMessage(
        role="assistant",
        content=[
            "calling",
            ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"}),
        ],
    )
    out = _message_to_azure(msg)
    assert len(out) == 1
    m = out[0]
    assert m["role"] == "assistant"
    assert m["content"] == "calling"
    assert m["tool_calls"][0]["id"] == "t1"
    assert m["tool_calls"][0]["function"]["name"] == "bash"
    assert '"command": "ls"' in m["tool_calls"][0]["function"]["arguments"]


def test_message_to_azure_user_with_tool_result_expands_to_tool_role():
    msg = ChatMessage(
        role="user",
        content=[ToolResult(tool_use_id="t1", content="output")],
    )
    out = _message_to_azure(msg)
    assert out == [{"role": "tool", "tool_call_id": "t1", "content": "output"}]


def test_message_to_azure_user_with_text_and_tool_result_keeps_order():
    msg = ChatMessage(
        role="user",
        content=[
            "please note",
            ToolResult(tool_use_id="t1", content="result-body"),
        ],
    )
    out = _message_to_azure(msg)
    # Text first, then the tool message.
    assert out[0] == {"role": "user", "content": "please note"}
    assert out[1] == {"role": "tool", "tool_call_id": "t1", "content": "result-body"}


def test_stringify_arguments_roundtrip():
    assert _stringify_arguments({"a": 1}) == '{"a": 1}'


def test_parse_arguments_accepts_json_string():
    assert _parse_arguments('{"a": 1}') == {"a": 1}


def test_parse_arguments_preserves_dict():
    assert _parse_arguments({"a": 1}) == {"a": 1}


def test_parse_arguments_returns_raw_on_invalid_json():
    result = _parse_arguments("not-json")
    assert result == {"_raw": "not-json"}


def test_map_finish_reason():
    assert _map_finish_reason("tool_calls") == "tool_use"
    assert _map_finish_reason("length") == "max_tokens"
    assert _map_finish_reason("stop") == "end_turn"
    assert _map_finish_reason("anything_else") == "other"


def test_response_from_azure_duck_types_sdk_object():
    fake = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content="pong",
                    tool_calls=[
                        SimpleNamespace(
                            id="t1",
                            function=SimpleNamespace(
                                name="bash",
                                arguments='{"command": "ls"}',
                            ),
                        )
                    ],
                ),
                finish_reason="tool_calls",
            )
        ],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5),
    )
    r = _response_from_azure(fake)
    assert r.text_blocks == ["pong"]
    assert len(r.tool_uses) == 1
    assert r.tool_uses[0].tool_use_id == "t1"
    assert r.tool_uses[0].input == {"command": "ls"}
    assert r.stop_reason == "tool_use"
    assert r.usage == {
        "input_tokens": 10,
        "output_tokens": 5,
        "cache_read_input_tokens": 0,
        "cache_write_input_tokens": 0,
        "total_input_tokens": 10,
        "provider": "azure",
    }


def test_response_from_azure_handles_end_turn_without_tools():
    fake = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content="done", tool_calls=None),
                finish_reason="stop",
            )
        ],
        usage=None,
    )
    r = _response_from_azure(fake)
    assert r.stop_reason == "end_turn"
    assert r.tool_uses == []
    # Azure adapter now normalizes a missing usage to a zeroed canonical shape.
    assert r.usage == {
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_write_input_tokens": 0,
        "total_input_tokens": 0,
        "provider": "azure",
    }


def _connection(azure_ai_endpoint="https://r.services.ai.azure.com/models", model_id="gpt-5.1"):
    return ConnectionData(
        connectionId="c-1",
        component="Studio",
        providerType="azure-ai-foundry",
        modelId=model_id,
        azureAiEndpoint=azure_ai_endpoint,
    )


def test_from_connection_uses_top_level_endpoint_and_model(monkeypatch):
    captured = {}

    def fake_init(self, *, endpoint, model_id, api_key=None):
        captured.update(endpoint=endpoint, model_id=model_id, api_key=api_key)

    monkeypatch.setattr(AzureAdapter, "__init__", fake_init)

    AzureAdapter.from_connection(
        _connection(
            azure_ai_endpoint="https://from-compass.azure.example/models",
            model_id="gpt-5.1",
        )
    )

    assert captured["endpoint"] == "https://from-compass.azure.example/models"
    assert captured["model_id"] == "gpt-5.1"
    assert captured["api_key"] is None


def test_from_connection_raises_when_endpoint_missing():
    with pytest.raises(ConfigurationError) as exc:
        AzureAdapter.from_connection(_connection(azure_ai_endpoint=None))
    assert "azureaiendpoint missing" in str(exc.value).lower()


def test_from_connection_raises_when_model_id_missing():
    with pytest.raises(ConfigurationError) as exc:
        AzureAdapter.from_connection(_connection(model_id=None))
    assert "modelid missing" in str(exc.value).lower()


def test_response_from_azure_maps_max_tokens():
    fake = SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content="partial", tool_calls=None),
                finish_reason="length",
            )
        ],
        usage=None,
    )
    r = _response_from_azure(fake)
    assert r.stop_reason == "max_tokens"
