"""OpenAICompatibleAdapter tests: init, from_connection, chat, streaming, errors, health, helpers."""
from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.clients.compass_client import ConnectionConfiguration, ConnectionData
from app.core.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.adapters import openai_compatible as oai_mod
from app.services.llm.adapters.openai_compatible import (
    OpenAICompatibleAdapter,
    _completions_url,
    _map_finish_reason,
    _maybe_decrypt,
    _message_to_openai,
    _normalize_usage,
    _parse_arguments,
    _response_from_openai,
    _tool_spec_to_openai,
)
from app.services.llm.protocol import ChatMessage, ToolResult, ToolSpec, ToolUse


def _adapter(**kw):
    # stream=False by default here so these cases exercise the blocking path;
    # the streaming path has its own section below and asks for it explicitly.
    defaults = dict(
        base_url="http://host:14000", model_id="gemma-4", api_key="sk-test", stream=False
    )
    defaults.update(kw)
    return OpenAICompatibleAdapter(**defaults)


# --------------------------------------------------------------- construction


def test_init_requires_base_url():
    with pytest.raises(ValueError):
        OpenAICompatibleAdapter(base_url="", model_id="gemma-4")


def test_init_requires_model_id():
    with pytest.raises(ValueError):
        OpenAICompatibleAdapter(base_url="http://host:14000", model_id="")


def test_init_sets_bearer_header_when_key_present():
    a = _adapter(api_key="sk-abc")
    assert a._headers["Authorization"] == "Bearer sk-abc"
    assert a._headers["Content-Type"] == "application/json"


def test_init_omits_auth_header_without_key():
    assert "Authorization" not in _adapter(api_key=None)._headers


def test_init_resolves_completions_url():
    assert _adapter()._url == "http://host:14000/v1/chat/completions"


def test_init_treats_nonpositive_max_tokens_as_no_override():
    assert _adapter(max_tokens=0).max_tokens_override is None
    assert _adapter(max_tokens=2048).max_tokens_override == 2048


# --------------------------------------------------------------- _completions_url


@pytest.mark.parametrize(
    "base, expected",
    [
        ("http://h:14000", "http://h:14000/v1/chat/completions"),
        ("http://h:14000/", "http://h:14000/v1/chat/completions"),
        ("http://h:14000/v1", "http://h:14000/v1/chat/completions"),
        ("http://h:14000/v1/chat/completions", "http://h:14000/v1/chat/completions"),
    ],
)
def test_completions_url_forms(base, expected):
    assert _completions_url(base) == expected


# --------------------------------------------------------------- _maybe_decrypt


def test_maybe_decrypt_none_returns_none():
    assert _maybe_decrypt(None, MagicMock()) is None


def test_maybe_decrypt_plaintext_passthrough():
    enc = MagicMock()
    enc.is_encrypted.return_value = False
    assert _maybe_decrypt("sk-plain", enc) == "sk-plain"
    enc.decrypt.assert_not_called()


def test_maybe_decrypt_encrypted_value_is_decrypted():
    enc = MagicMock()
    enc.is_encrypted.return_value = True
    enc.decrypt.return_value = "sk-secret"
    assert _maybe_decrypt("ZW5jcnlwdGVk", enc) == "sk-secret"


def test_maybe_decrypt_falls_back_to_raw_on_failure():
    enc = MagicMock()
    enc.is_encrypted.return_value = True
    enc.decrypt.side_effect = ValueError("bad")
    assert _maybe_decrypt("looks-b64", enc) == "looks-b64"


# --------------------------------------------------------------- from_connection


def _plaintext_encryption_utils():
    enc = MagicMock()
    enc.is_encrypted.return_value = False
    return enc


def _cei_connection(*, top_level=None, nested=None) -> ConnectionData:
    """Build a concierto-private-llm ConnectionData from cai* aliases."""
    return ConnectionData(
        connectionId="CON-CEI",
        component="Studio",
        providerType="concierto-private-llm",
        configuration=ConnectionConfiguration(**(nested or {})),
        status="enabled",
        **(top_level or {}),
    )


def test_from_connection_builds_from_cai_fields():
    conn = _cei_connection(top_level={
        "caiBaseUrl": "http://cei-host:14000",
        "caiModel": "gemma-4",
        "caiApiKey": "sk-dummy",
    })
    a = OpenAICompatibleAdapter.from_connection(
        conn, encryption_utils=_plaintext_encryption_utils()
    )
    assert a.base_url == "http://cei-host:14000"
    assert a.model_id == "gemma-4"
    assert a.api_key == "sk-dummy"
    assert a._url == "http://cei-host:14000/v1/chat/completions"
    assert a._headers["Authorization"] == "Bearer sk-dummy"
    # enable_thinking stays unset, so chat_template_kwargs is never sent.
    assert a.enable_thinking is None


def test_from_connection_missing_base_url_raises():
    conn = _cei_connection(top_level={"caiModel": "gemma-4"})
    with pytest.raises(ConfigurationError) as exc:
        OpenAICompatibleAdapter.from_connection(
            conn, encryption_utils=_plaintext_encryption_utils()
        )
    assert "caiBaseUrl" in str(exc.value)


def test_from_connection_missing_model_raises():
    conn = _cei_connection(top_level={"caiBaseUrl": "http://cei-host:14000"})
    with pytest.raises(ConfigurationError) as exc:
        OpenAICompatibleAdapter.from_connection(
            conn, encryption_utils=_plaintext_encryption_utils()
        )
    assert "caiModel" in str(exc.value)


def test_from_connection_falls_back_to_nested_configuration():
    # Upstream sends both shapes; only the nested one is populated here.
    conn = _cei_connection(nested={
        "caiBaseUrl": "http://nested-host:14000",
        "caiModel": "nested-model",
        "caiApiKey": "sk-nested-dummy",
    })
    a = OpenAICompatibleAdapter.from_connection(
        conn, encryption_utils=_plaintext_encryption_utils()
    )
    assert a.base_url == "http://nested-host:14000"
    assert a.model_id == "nested-model"
    assert a.api_key == "sk-nested-dummy"


def test_from_connection_prefers_top_level_over_nested():
    conn = _cei_connection(
        top_level={"caiBaseUrl": "http://top:14000", "caiModel": "top-model"},
        nested={"caiBaseUrl": "http://nested:14000", "caiModel": "nested-model"},
    )
    a = OpenAICompatibleAdapter.from_connection(
        conn, encryption_utils=_plaintext_encryption_utils()
    )
    assert a.base_url == "http://top:14000"
    assert a.model_id == "top-model"


def test_from_connection_decrypts_encrypted_api_key():
    enc = MagicMock()
    enc.is_encrypted.return_value = True
    enc.decrypt.return_value = "sk-decrypted-dummy"
    conn = _cei_connection(top_level={
        "caiBaseUrl": "http://cei-host:14000",
        "caiModel": "gemma-4",
        "caiApiKey": "Y2lwaGVydGV4dA==",
    })
    a = OpenAICompatibleAdapter.from_connection(conn, encryption_utils=enc)
    assert a.api_key == "sk-decrypted-dummy"
    enc.decrypt.assert_called_once_with("Y2lwaGVydGV4dA==")


def test_from_connection_without_api_key_omits_auth_header():
    conn = _cei_connection(top_level={
        "caiBaseUrl": "http://cei-host:14000",
        "caiModel": "gemma-4",
    })
    a = OpenAICompatibleAdapter.from_connection(
        conn, encryption_utils=_plaintext_encryption_utils()
    )
    assert a.api_key is None
    assert "Authorization" not in a._headers


def test_from_env_is_gone():
    assert not hasattr(OpenAICompatibleAdapter, "from_env")


# --------------------------------------------------------------- timeout


def test_timeout_comes_from_settings_when_not_passed():
    with patch.object(oai_mod, "_request_timeout", return_value=42.0):
        assert _adapter().timeout == 42.0


def test_timeout_argument_wins_over_settings():
    with patch.object(oai_mod, "_request_timeout", return_value=42.0):
        assert _adapter(timeout=7.0).timeout == 7.0


def _settings_with(openai_compatible):
    # _settings is a pydantic BaseSettings, which rejects attribute injection,
    # so swap the whole object for a stand-in.
    return SimpleNamespace(openai_compatible=openai_compatible)


@pytest.mark.parametrize(
    "oc",
    [
        SimpleNamespace(),           # timeout field not on the config yet
        SimpleNamespace(timeout=None),
        SimpleNamespace(timeout=0),
    ],
)
def test_request_timeout_falls_back_when_setting_absent_or_empty(oc):
    with patch.object(oai_mod, "_settings", _settings_with(oc)):
        assert oai_mod._request_timeout() == oai_mod._FALLBACK_TIMEOUT


def test_request_timeout_reads_setting_when_present():
    with patch.object(oai_mod, "_settings", _settings_with(SimpleNamespace(timeout=120))):
        assert oai_mod._request_timeout() == 120.0


def test_request_timeout_falls_back_on_unparseable_setting():
    with patch.object(oai_mod, "_settings", _settings_with(SimpleNamespace(timeout="abc"))):
        assert oai_mod._request_timeout() == oai_mod._FALLBACK_TIMEOUT


def test_request_timeout_default_is_still_3600():
    """The 3600s default predates this change; it is only overridable now."""
    assert oai_mod._FALLBACK_TIMEOUT == 3600.0


# --------------------------------------------------------------- generation_defaults


def test_generation_defaults_reads_settings():
    oc = SimpleNamespace(max_tokens=32000, temperature=0.3)
    with patch.object(oai_mod, "_settings", _settings_with(oc)):
        assert oai_mod.generation_defaults() == {"max_tokens": 32000, "temperature": 0.3}


def test_generation_defaults_keeps_explicit_zero_temperature():
    oc = SimpleNamespace(max_tokens=1000, temperature=0.0)
    with patch.object(oai_mod, "_settings", _settings_with(oc)):
        assert oai_mod.generation_defaults()["temperature"] == 0.0


@pytest.mark.parametrize(
    "oc",
    [
        SimpleNamespace(),                                  # fields not restored yet
        SimpleNamespace(max_tokens=None, temperature=None),
        SimpleNamespace(max_tokens=0, temperature=None),     # non-positive = unset
        SimpleNamespace(max_tokens="nope", temperature="nope"),
    ],
)
def test_generation_defaults_falls_back(oc):
    with patch.object(oai_mod, "_settings", _settings_with(oc)):
        assert oai_mod.generation_defaults() == {
            "max_tokens": oai_mod._FALLBACK_MAX_TOKENS,
            "temperature": oai_mod._FALLBACK_TEMPERATURE,
        }


def test_generation_default_fallbacks_match_documented_provider_defaults():
    assert oai_mod._FALLBACK_MAX_TOKENS == 64000
    assert oai_mod._FALLBACK_TEMPERATURE == 0.0


# --------------------------------------------------------------- chat


class _FakeResponse:
    def __init__(self, status_code=200, json_body=None, headers=None, text=""):
        self.status_code = status_code
        self._json = json_body
        self.headers = headers or {}
        self.text = text

    def json(self):
        if self._json is None:
            raise ValueError("no json")
        return self._json


def _patch_post(response=None, *, post_side_effect=None):
    client = MagicMock()
    if post_side_effect is not None:
        client.post = AsyncMock(side_effect=post_side_effect)
    else:
        client.post = AsyncMock(return_value=response)
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=client)
    cm.__aexit__ = AsyncMock(return_value=False)
    return patch.object(oai_mod.httpx, "AsyncClient", return_value=cm), client


def _ok_body(text="hi", finish="stop"):
    return {
        "choices": [{"message": {"role": "assistant", "content": text}, "finish_reason": finish}],
        "usage": {"prompt_tokens": 4, "completion_tokens": 1},
    }


@pytest.mark.asyncio
async def test_chat_builds_openai_body_with_system_and_tools():
    resp = _FakeResponse(json_body=_ok_body())
    p, client = _patch_post(resp)
    with p:
        out = await _adapter().chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system="be nice",
            tools=[ToolSpec(name="bash", description="run", input_schema={"type": "object"})],
            max_tokens=64,
            temperature=0.7,
        )
        assert out.text_blocks == ["hi"]
        assert out.stop_reason == "end_turn"

        body = client.post.call_args.kwargs["json"]
        assert client.post.call_args.args[0] == "http://host:14000/v1/chat/completions"
        assert body["model"] == "gemma-4"
        assert body["max_tokens"] == 64
        assert body["temperature"] == 0.7
        assert body["stream"] is False
        assert "stream_options" not in body
        assert body["messages"][0] == {"role": "system", "content": "be nice"}
        assert body["messages"][1] == {"role": "user", "content": "ping"}
        assert body["tools"][0]["function"]["name"] == "bash"
        assert body["tool_choice"] == "auto"
        assert client.post.call_args.kwargs["headers"]["Authorization"] == "Bearer sk-test"


@pytest.mark.asyncio
async def test_chat_applies_max_tokens_and_temperature_overrides():
    resp = _FakeResponse(json_body=_ok_body())
    p, client = _patch_post(resp)
    with p:
        a = _adapter(max_tokens=64000, temperature=0.1)
        await a.chat(
            messages=[ChatMessage(role="user", content=["x"])],
            system=None, tools=None, max_tokens=64, temperature=0.9,
        )
        body = client.post.call_args.kwargs["json"]
        assert body["max_tokens"] == 64000   # override, not caller's 64
        assert body["temperature"] == 0.1    # override, not caller's 0.9


@pytest.mark.asyncio
async def test_chat_without_overrides_uses_caller_values():
    resp = _FakeResponse(json_body=_ok_body())
    p, client = _patch_post(resp)
    with p:
        await _adapter().chat(
            messages=[ChatMessage(role="user", content=["x"])],
            system=None, tools=None, max_tokens=128, temperature=0.3,
        )
        body = client.post.call_args.kwargs["json"]
        assert body["max_tokens"] == 128
        assert body["temperature"] == 0.3


@pytest.mark.asyncio
async def test_chat_enable_thinking_sets_chat_template_kwargs():
    resp = _FakeResponse(json_body=_ok_body())
    p, client = _patch_post(resp)
    with p:
        await _adapter(enable_thinking=True).chat(
            messages=[ChatMessage(role="user", content=["x"])],
            system=None, tools=None, max_tokens=64, temperature=0.0,
        )
        assert client.post.call_args.kwargs["json"]["chat_template_kwargs"] == {"enable_thinking": True}


@pytest.mark.asyncio
async def test_chat_enable_thinking_none_sends_nothing():
    resp = _FakeResponse(json_body=_ok_body())
    p, client = _patch_post(resp)
    with p:
        await _adapter().chat(
            messages=[ChatMessage(role="user", content=["x"])],
            system=None, tools=None, max_tokens=64, temperature=0.0,
        )
        assert "chat_template_kwargs" not in client.post.call_args.kwargs["json"]


@pytest.mark.asyncio
async def test_chat_parses_tool_calls():
    body = {
        "choices": [{
            "message": {
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "bash", "arguments": '{"command": "ls"}'},
                }],
            },
            "finish_reason": "tool_calls",
        }],
        "usage": {"prompt_tokens": 10, "completion_tokens": 2},
    }
    p, _ = _patch_post(_FakeResponse(json_body=body))
    with p:
        out = await _adapter().chat(
            messages=[ChatMessage(role="user", content=["go"])],
            system=None, tools=None, max_tokens=8, temperature=0.0,
        )
        assert out.text_blocks == []
        assert out.stop_reason == "tool_use"
        assert out.tool_uses[0].tool_use_id == "call_1"
        assert out.tool_uses[0].name == "bash"
        assert out.tool_uses[0].input == {"command": "ls"}


@pytest.mark.asyncio
async def test_chat_rate_limit_raises():
    p, _ = _patch_post(_FakeResponse(status_code=429, headers={"Retry-After": "12"}))
    with p:
        with pytest.raises(RateLimitError) as exc:
            await _adapter().chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )
        assert exc.value.retry_after == 12


@pytest.mark.asyncio
async def test_chat_auth_error_raises():
    p, _ = _patch_post(_FakeResponse(status_code=401, text="unauthorized"))
    with p:
        with pytest.raises(AuthenticationError):
            await _adapter().chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_chat_generic_error_raises_provider_error():
    p, _ = _patch_post(_FakeResponse(status_code=500, text="boom"))
    with p:
        with pytest.raises(ProviderError):
            await _adapter().chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_chat_request_error_raises_provider_error():
    p, _ = _patch_post(post_side_effect=oai_mod.httpx.ConnectError("refused"))
    with p:
        with pytest.raises(ProviderError):
            await _adapter().chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_chat_invalid_json_raises_provider_error():
    p, _ = _patch_post(_FakeResponse(status_code=200, json_body=None, text="<html>"))
    with p:
        with pytest.raises(ProviderError):
            await _adapter().chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


# --------------------------------------------------------------- streaming


class _FakeStreamResponse:
    def __init__(self, lines, status_code=200, text="", headers=None):
        self.status_code = status_code
        self._lines = list(lines)
        self.text = text
        self.headers = headers or {}
        self.aread_called = False

    async def aread(self):
        self.aread_called = True
        return self.text.encode()

    async def aiter_lines(self):
        for line in self._lines:
            yield line


def _patch_stream(lines=(), *, status_code=200, text="", headers=None, side_effect=None):
    """Stand in for httpx.AsyncClient.stream, which returns an async CM."""
    response = _FakeStreamResponse(lines, status_code, text, headers)
    stream_cm = MagicMock()
    stream_cm.__aenter__ = AsyncMock(return_value=response)
    stream_cm.__aexit__ = AsyncMock(return_value=False)

    client = MagicMock()
    if side_effect is not None:
        client.stream = MagicMock(side_effect=side_effect)
    else:
        client.stream = MagicMock(return_value=stream_cm)

    client_cm = MagicMock()
    client_cm.__aenter__ = AsyncMock(return_value=client)
    client_cm.__aexit__ = AsyncMock(return_value=False)
    return patch.object(oai_mod.httpx, "AsyncClient", return_value=client_cm), client, response


def _sse(**chunk):
    return "data: " + json.dumps(chunk)


def _delta(**delta):
    """One choice-delta chunk, the shape vLLM emits per token."""
    return _sse(id="c1", model="laguna", created=7, choices=[{"index": 0, "delta": delta}])


def _finish(reason="stop"):
    return _sse(id="c1", choices=[{"index": 0, "delta": {}, "finish_reason": reason}])


def _usage_chunk(prompt=1173, completion=156):
    return _sse(
        id="c1",
        choices=[],
        usage={"prompt_tokens": prompt, "completion_tokens": completion},
    )


async def _stream_chat(lines, adapter=None, **chat_kw):
    p, client, _ = _patch_stream(lines)
    with p:
        a = adapter or _adapter(stream=True)
        kw = dict(
            messages=[ChatMessage(role="user", content=["go"])],
            system=None, tools=None, max_tokens=64, temperature=0.0,
        )
        kw.update(chat_kw)
        return await a.chat(**kw), client


@pytest.mark.asyncio
async def test_streaming_body_sets_stream_and_asks_for_usage():
    out, client = await _stream_chat([_delta(content="hi"), _usage_chunk(), _finish()])
    body = client.stream.call_args.kwargs["json"]
    assert client.stream.call_args.args == ("POST", "http://host:14000/v1/chat/completions")
    assert body["stream"] is True
    # Without include_usage the stream carries no usage block at all.
    assert body["stream_options"] == {"include_usage": True}
    assert out.text_blocks == ["hi"]
    assert out.stop_reason == "end_turn"


@pytest.mark.asyncio
async def test_streaming_usage_is_populated_not_zeros():
    """The silent failure mode: usage present and matching, not all zeros."""
    out, _ = await _stream_chat([
        _delta(content="hi"), _usage_chunk(prompt=1173, completion=156), _finish(),
    ])
    assert out.usage["total_input_tokens"] == 1173
    assert out.usage["input_tokens"] == 1173
    assert out.usage["output_tokens"] == 156
    assert out.usage["provider"] == "openai-compatible"


@pytest.mark.asyncio
async def test_streaming_without_usage_chunk_reports_zeros():
    """Documents why include_usage is always sent: no usage chunk, no numbers."""
    out, _ = await _stream_chat([_delta(content="hi"), _finish()])
    assert out.usage["total_input_tokens"] == 0
    assert out.usage["output_tokens"] == 0


@pytest.mark.asyncio
async def test_streaming_keeps_reasoning_content_out_of_text():
    """Reasoning models stream thinking on reasoning_content; it is not the answer."""
    out, _ = await _stream_chat([
        _delta(reasoning_content="let me think about "),
        _delta(reasoning_content="whether this is safe"),
        _delta(content="The answer "),
        _delta(content="is 42."),
        _finish(),
    ])
    assert out.text_blocks == ["The answer is 42."]
    assert "think" not in out.text_blocks[0]
    assert out.raw["choices"][0]["message"]["content"] == "The answer is 42."


@pytest.mark.asyncio
async def test_streaming_reassembles_fragmented_tool_call_arguments():
    """Argument JSON arrives split across deltas and must parse once rejoined."""
    out, _ = await _stream_chat([
        _delta(tool_calls=[{
            "index": 0, "id": "call_a", "type": "function",
            "function": {"name": "bash", "arguments": ""},
        }]),
        _delta(tool_calls=[{"index": 0, "function": {"arguments": '{"command": "fi'}}]),
        _delta(tool_calls=[{"index": 0, "function": {"arguments": 'nd /tmp", "work'}}]),
        _delta(tool_calls=[{"index": 0, "function": {"arguments": 'ing_directory": "/tmp"}'}}]),
        _finish("tool_calls"),
    ])
    assert out.stop_reason == "tool_use"
    assert len(out.tool_uses) == 1
    call = out.tool_uses[0]
    assert call.tool_use_id == "call_a"
    assert call.name == "bash"
    # Parsed to a real dict, not the {"_raw": ...} fallback.
    assert call.input == {"command": "find /tmp", "working_directory": "/tmp"}


@pytest.mark.asyncio
async def test_streaming_keys_multiple_tool_calls_by_index():
    out, _ = await _stream_chat([
        _delta(tool_calls=[{
            "index": 0, "id": "call_a", "function": {"name": "bash", "arguments": ""},
        }]),
        _delta(tool_calls=[{"index": 0, "function": {"arguments": '{"command": "ls"}'}}]),
        _delta(tool_calls=[{
            "index": 1, "id": "call_b", "function": {"name": "code_editor", "arguments": ""},
        }]),
        _delta(tool_calls=[{"index": 1, "function": {"arguments": '{"path": "a.java"}'}}]),
        _finish("tool_calls"),
    ])
    assert [(c.tool_use_id, c.name, c.input) for c in out.tool_uses] == [
        ("call_a", "bash", {"command": "ls"}),
        ("call_b", "code_editor", {"path": "a.java"}),
    ]


@pytest.mark.asyncio
async def test_streaming_truncated_stream_raises_instead_of_partial_text():
    """No finish_reason means the stream was cut; partial content is not an answer."""
    with pytest.raises(ProviderError) as exc:
        await _stream_chat([_delta(content="half an ans")])
    assert "finish_reason" in str(exc.value)


@pytest.mark.asyncio
async def test_streaming_empty_stream_raises():
    with pytest.raises(ProviderError):
        await _stream_chat([])


@pytest.mark.asyncio
async def test_streaming_ignores_done_sentinel_and_non_data_lines():
    out, _ = await _stream_chat([
        ": keep-alive comment",
        "",
        _delta(content="ok"),
        _finish(),
        "data: [DONE]",
    ])
    assert out.text_blocks == ["ok"]
    assert out.stop_reason == "end_turn"


@pytest.mark.asyncio
async def test_streaming_skips_unparseable_chunk():
    out, _ = await _stream_chat([
        "data: {not json",
        _delta(content="ok"),
        _finish(),
    ])
    assert out.text_blocks == ["ok"]


@pytest.mark.asyncio
async def test_streaming_gateway_timeout_still_raises_provider_error():
    """The 504 this change exists to avoid must still surface if it happens."""
    p, _, response = _patch_stream(status_code=504, text="<html>504 Gateway Time-out</html>")
    with p:
        with pytest.raises(ProviderError) as exc:
            await _adapter(stream=True).chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )
        assert "504" in str(exc.value)
        # The body has to be read before response.text carries anything.
        assert response.aread_called


@pytest.mark.asyncio
async def test_streaming_rate_limit_raises():
    p, _, _ = _patch_stream(status_code=429, headers={"Retry-After": "9"})
    with p:
        with pytest.raises(RateLimitError) as exc:
            await _adapter(stream=True).chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )
        assert exc.value.retry_after == 9


@pytest.mark.asyncio
async def test_streaming_auth_error_raises():
    p, _, _ = _patch_stream(status_code=403, text="forbidden")
    with p:
        with pytest.raises(AuthenticationError):
            await _adapter(stream=True).chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_streaming_request_error_raises_provider_error():
    p, _, _ = _patch_stream(side_effect=oai_mod.httpx.ConnectError("refused"))
    with p:
        with pytest.raises(ProviderError):
            await _adapter(stream=True).chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_streaming_raw_is_a_full_completion_payload():
    """orchestrator hands ChatResponse.raw straight to callers, so shape matters."""
    out, _ = await _stream_chat([_delta(content="hi"), _usage_chunk(), _finish()])
    assert out.raw["object"] == "chat.completion"
    assert out.raw["model"] == "laguna"
    assert out.raw["choices"][0]["finish_reason"] == "stop"
    assert out.raw["choices"][0]["message"]["role"] == "assistant"
    assert out.raw["usage"]["prompt_tokens"] == 1173


@pytest.mark.asyncio
async def test_streaming_falls_back_to_configured_model_when_absent():
    out, _ = await _stream_chat([
        _sse(choices=[{"index": 0, "delta": {"content": "hi"}}]),
        _sse(choices=[{"index": 0, "delta": {}, "finish_reason": "stop"}]),
    ])
    assert out.raw["model"] == "gemma-4"


# --------------------------------------------------------------- stream setting


def test_stream_argument_wins_over_settings():
    with patch.object(oai_mod, "_request_stream", return_value=True):
        assert OpenAICompatibleAdapter(
            base_url="http://h:1", model_id="m", stream=False
        ).stream is False


def test_stream_comes_from_settings_when_not_passed():
    with patch.object(oai_mod, "_request_stream", return_value=False):
        assert OpenAICompatibleAdapter(base_url="http://h:1", model_id="m").stream is False


def test_request_stream_defaults_to_on_when_field_absent():
    with patch.object(oai_mod, "_settings", _settings_with(SimpleNamespace())):
        assert oai_mod._request_stream() is True
    assert oai_mod._FALLBACK_STREAM is True


def test_request_stream_honours_explicit_false():
    """False is a real value here, not "unset" - it must not take the fallback."""
    with patch.object(oai_mod, "_settings", _settings_with(SimpleNamespace(stream=False))):
        assert oai_mod._request_stream() is False


@pytest.mark.parametrize("raw, expected", [
    ("false", False), ("0", False), ("no", False), ("off", False), ("", False),
    ("true", True), ("1", True), ("yes", True),
])
def test_request_stream_parses_string_settings(raw, expected):
    with patch.object(oai_mod, "_settings", _settings_with(SimpleNamespace(stream=raw))):
        assert oai_mod._request_stream() is expected


def test_streaming_is_the_configured_default():
    """The adapter ships streaming on; a 60s idle timeout upstream breaks otherwise."""
    from app.core.config import OpenAICompatibleConfig
    assert OpenAICompatibleConfig().stream is True


# --------------------------------------------------------------- accumulator


def test_accumulator_reasoning_kept_separate_from_content():
    acc = oai_mod._StreamAccumulator()
    acc.consume_line(_delta(reasoning_content="thinking"))
    acc.consume_line(_delta(content="answer"))
    acc.consume_line(_finish())
    assert acc.reasoning_content == "thinking"
    assert acc.to_payload(model="m")["choices"][0]["message"]["content"] == "answer"


def test_accumulator_incomplete_until_finish_reason():
    acc = oai_mod._StreamAccumulator()
    acc.consume_line(_delta(content="partial"))
    assert acc.completed is False
    assert acc.content_length == 7
    acc.consume_line(_finish())
    assert acc.completed is True


def test_accumulator_counts_only_json_chunks():
    acc = oai_mod._StreamAccumulator()
    acc.consume_line("data: [DONE]")
    acc.consume_line(": comment")
    acc.consume_line("")
    assert acc.chunks == 0
    acc.consume_line(_delta(content="x"))
    assert acc.chunks == 1


def test_accumulator_tolerates_non_integer_tool_index():
    acc = oai_mod._StreamAccumulator()
    acc.consume_line(_delta(tool_calls=[{
        "index": None, "id": "t", "function": {"name": "bash", "arguments": "{}"},
    }]))
    acc.consume_line(_finish("tool_calls"))
    calls = acc.to_payload(model="m")["choices"][0]["message"]["tool_calls"]
    assert calls[0]["function"]["name"] == "bash"


# --------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_check_healthy():
    p, _ = _patch_post(_FakeResponse(json_body=_ok_body(text="pong")))
    with p:
        out = await _adapter().health_check()
        assert out["status"] == "healthy"
        assert out["model"] == "gemma-4"


@pytest.mark.asyncio
async def test_health_check_unhealthy_on_error():
    p, _ = _patch_post(_FakeResponse(status_code=500, text="down"))
    with p:
        out = await _adapter().health_check()
        assert out["status"] == "unhealthy"
        assert "error" in out


# --------------------------------------------------------------- helpers


def test_tool_spec_to_openai_sanitizes_array_items():
    ts = ToolSpec(
        name="grep",
        description="search",
        input_schema={"type": "object", "properties": {"paths": {"type": "array"}}},
    )
    out = _tool_spec_to_openai(ts)
    assert out["type"] == "function"
    assert out["function"]["parameters"]["properties"]["paths"]["items"] == {}


def test_message_to_openai_plain_user_text():
    assert _message_to_openai(ChatMessage(role="user", content=["hello"])) == [
        {"role": "user", "content": "hello"}
    ]


def test_message_to_openai_assistant_with_text_and_tool_use():
    msg = ChatMessage(
        role="assistant",
        content=["let me run it", ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"})],
    )
    out = _message_to_openai(msg)
    assert out[0]["content"] == "let me run it"
    call = out[0]["tool_calls"][0]
    assert call["id"] == "t1"
    assert call["function"]["name"] == "bash"
    assert call["function"]["arguments"] == '{"command": "ls"}'


def test_message_to_openai_tool_results_become_tool_messages_first():
    msg = ChatMessage(
        role="user",
        content=[ToolResult(tool_use_id="t1", content="out", is_error=False), "more context"],
    )
    out = _message_to_openai(msg)
    assert out[0] == {"role": "tool", "tool_call_id": "t1", "content": "out"}
    assert out[1] == {"role": "user", "content": "more context"}


def test_response_from_openai_text_only():
    raw = {"choices": [{"message": {"content": "answer"}, "finish_reason": "stop"}]}
    r = _response_from_openai(raw, provider="openai-compatible")
    assert r.text_blocks == ["answer"]
    assert r.tool_uses == []
    assert r.stop_reason == "end_turn"


def test_response_from_openai_empty_choices():
    r = _response_from_openai({"choices": []}, provider="openai-compatible")
    assert r.text_blocks == []
    assert r.stop_reason == "other"


@pytest.mark.parametrize(
    "reason, expected",
    [("stop", "end_turn"), ("tool_calls", "tool_use"), ("length", "max_tokens"),
     ("content_filter", "other"), (None, "other")],
)
def test_map_finish_reason(reason, expected):
    assert _map_finish_reason(reason) == expected


def test_normalize_usage_with_cached_tokens():
    u = _normalize_usage(
        {"prompt_tokens": 100, "completion_tokens": 20, "prompt_tokens_details": {"cached_tokens": 30}},
        provider="openai-compatible",
    )
    assert u["total_input_tokens"] == 100
    assert u["cache_read_input_tokens"] == 30
    assert u["input_tokens"] == 70
    assert u["output_tokens"] == 20
    assert u["provider"] == "openai-compatible"


def test_normalize_usage_empty():
    u = _normalize_usage({}, provider="openai-compatible")
    assert u["total_input_tokens"] == 0
    assert u["provider"] == "openai-compatible"


def test_parse_arguments_dict_passthrough():
    assert _parse_arguments({"a": 1}) == {"a": 1}


def test_parse_arguments_json_string():
    assert _parse_arguments('{"a": 1}') == {"a": 1}


def test_parse_arguments_empty():
    assert _parse_arguments("") == {}


def test_parse_arguments_invalid_wrapped_in_raw():
    assert _parse_arguments("not json") == {"_raw": "not json"}
