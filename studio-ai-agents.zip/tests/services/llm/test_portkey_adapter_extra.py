"""Additional PortkeyAdapter coverage: init, from_connection, chat, errors, health."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.clients.compass_client import ConnectionConfiguration, ConnectionData
from app.core.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.adapters import portkey as portkey_mod
from app.services.llm.adapters.portkey import (
    PortkeyAdapter,
    _message_to_portkey,
    _normalize_usage,
    _response_from_portkey,
)
from app.services.llm.protocol import ChatMessage, ToolSpec, ToolUse


def _adapter(**kw):
    defaults = dict(api_key="k", virtual_key="v", model_id="m", base_url="https://pk.test")
    defaults.update(kw)
    return PortkeyAdapter(**defaults)


# --------------------------------------------------------------- construction


def test_init_requires_api_key():
    with pytest.raises(ValueError):
        PortkeyAdapter(api_key="", virtual_key="v", model_id="m")


def test_init_requires_virtual_key():
    with pytest.raises(ValueError):
        PortkeyAdapter(api_key="k", virtual_key="", model_id="m")


def test_init_requires_model_id():
    with pytest.raises(ValueError):
        PortkeyAdapter(api_key="k", virtual_key="v", model_id="")


def test_init_debug_adds_debug_header():
    a = _adapter(debug=True)
    assert a._headers["x-portkey-debug"] == "true"
    assert a._headers["x-portkey-api-key"] == "k"
    assert a._headers["x-portkey-virtual-key"] == "v"


def test_init_no_debug_omits_debug_header():
    a = _adapter(debug=False)
    assert "x-portkey-debug" not in a._headers


# --------------------------------------------------------------- from_connection


def _conn(slug="@vk/model-x", api_key="enc", base_url=None, debug=None, cfg_api_key=None):
    cfg = ConnectionConfiguration(portkeyApiKey=cfg_api_key, debugEnabled=False)
    return ConnectionData(
        connection_id="c1",
        component="Studio",
        provider_type="portkey",
        slug=slug,
        portkeyApiKey=api_key,
        portkeyBaseUrl=base_url,
        debugEnabled=debug,
        configuration=cfg,
    )


def test_from_connection_decrypts_and_parses_slug():
    enc = MagicMock()
    enc.decrypt.return_value = "decrypted-key"
    a = PortkeyAdapter.from_connection(_conn(debug=True), encryption_utils=enc)
    assert a.api_key == "decrypted-key"
    assert a.virtual_key == "vk"
    assert a.model_id == "model-x"
    assert a.debug is True
    enc.decrypt.assert_called_once_with("enc")


def test_from_connection_missing_api_key_raises():
    enc = MagicMock()
    conn = _conn(api_key=None)
    with pytest.raises(ConfigurationError) as exc:
        PortkeyAdapter.from_connection(conn, encryption_utils=enc)
    assert "api key is missing" in str(exc.value).lower()


def test_from_connection_missing_slug_raises():
    enc = MagicMock()
    with pytest.raises(ConfigurationError) as exc:
        PortkeyAdapter.from_connection(_conn(slug=None), encryption_utils=enc)
    assert "slug is missing" in str(exc.value).lower()


def test_from_connection_decrypt_failure_raises():
    enc = MagicMock()
    enc.decrypt.side_effect = RuntimeError("bad key")
    with pytest.raises(ConfigurationError) as exc:
        PortkeyAdapter.from_connection(_conn(), encryption_utils=enc)
    assert "decrypt" in str(exc.value).lower()


def test_from_connection_empty_decrypted_key_raises():
    enc = MagicMock()
    enc.decrypt.return_value = ""
    with pytest.raises(ConfigurationError) as exc:
        PortkeyAdapter.from_connection(_conn(), encryption_utils=enc)
    assert "empty" in str(exc.value).lower()


def test_from_connection_bad_slug_format_raises():
    enc = MagicMock()
    enc.decrypt.return_value = "key"
    with pytest.raises(ConfigurationError) as exc:
        PortkeyAdapter.from_connection(_conn(slug="just-one-part"), encryption_utils=enc)
    assert "slug format" in str(exc.value).lower()


def test_from_connection_empty_virtual_key_in_slug_raises():
    enc = MagicMock()
    enc.decrypt.return_value = "key"
    with pytest.raises(ConfigurationError):
        PortkeyAdapter.from_connection(_conn(slug="@/model"), encryption_utils=enc)


def test_from_connection_uses_default_encryption_when_none():
    with patch.object(portkey_mod, "get_encryption_utils") as get_enc:
        enc = MagicMock()
        enc.decrypt.return_value = "key"
        get_enc.return_value = enc
        a = PortkeyAdapter.from_connection(_conn())
        assert a.api_key == "key"
        get_enc.assert_called_once()


# --------------------------------------------------------------- chat


class _FakeResponse:
    def __init__(self, status_code=200, json_body=None, headers=None, text=""):
        self.status_code = status_code
        self._json = json_body or {}
        self.headers = headers or {}
        self.text = text

    def json(self):
        return self._json


def _patch_post(response):
    client = MagicMock()
    client.post = AsyncMock(return_value=response)
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=client)
    cm.__aexit__ = AsyncMock(return_value=False)
    return patch.object(portkey_mod.httpx, "AsyncClient", return_value=cm), client


@pytest.mark.asyncio
async def test_chat_success_with_system_and_tools():
    resp = _FakeResponse(
        json_body={
            "content": [{"type": "text", "text": "hi"}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 4, "output_tokens": 1},
        }
    )
    p, client = _patch_post(resp)
    with p:
        a = _adapter()
        out = await a.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system="be nice",
            tools=[ToolSpec(name="bash", description="run", input_schema={"type": "object"})],
            max_tokens=50,
            temperature=0.2,
        )
        assert out.text_blocks == ["hi"]
        body = client.post.call_args.kwargs["json"]
        assert body["system"][0]["cache_control"] == {"type": "ephemeral"}
        assert body["tools"][0]["name"] == "bash"
        # Last user content promoted to a list with cache_control.
        assert body["messages"][-1]["content"][-1]["cache_control"] == {"type": "ephemeral"}
        assert body["temperature"] == 0.2


@pytest.mark.asyncio
async def test_chat_sonnet_55_omits_temperature():
    resp = _FakeResponse(json_body={"content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, client = _patch_post(resp)
    with p:
        a = _adapter(model_id="us.anthropic.claude-sonnet-5-5")
        await a.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system=None,
            tools=None,
            max_tokens=32,
            temperature=0.0,
        )
        body = client.post.call_args.kwargs["json"]
        assert "temperature" not in body
        assert body["max_tokens"] == 32


@pytest.mark.asyncio
async def test_chat_list_content_attaches_cache_control_on_last_block():
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "end_turn"})
    p, client = _patch_post(resp)
    with p:
        a = _adapter()
        await a.chat(
            messages=[
                ChatMessage(
                    role="user",
                    content=["a", ToolUse(tool_use_id="t", name="bash", input={})],
                )
            ],
            system=None,
            tools=None,
            max_tokens=10,
            temperature=0.0,
        )
        body = client.post.call_args.kwargs["json"]
        assert "system" not in body
        assert body["messages"][-1]["content"][-1]["cache_control"] == {"type": "ephemeral"}


@pytest.mark.asyncio
async def test_chat_rate_limit_raises():
    resp = _FakeResponse(status_code=429, headers={"Retry-After": "12"})
    p, _ = _patch_post(resp)
    with p:
        a = _adapter()
        with pytest.raises(RateLimitError) as exc:
            await a.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )
        assert exc.value.retry_after == 12


@pytest.mark.asyncio
async def test_chat_auth_error_raises():
    resp = _FakeResponse(status_code=401, text="unauthorized")
    p, _ = _patch_post(resp)
    with p:
        a = _adapter()
        with pytest.raises(AuthenticationError):
            await a.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


@pytest.mark.asyncio
async def test_chat_generic_error_raises_provider_error():
    resp = _FakeResponse(status_code=500, text="server boom")
    p, _ = _patch_post(resp)
    with p:
        a = _adapter()
        with pytest.raises(ProviderError):
            await a.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None, tools=None, max_tokens=1, temperature=0.0,
            )


# --------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_check_healthy():
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "end_turn"})
    p, _ = _patch_post(resp)
    with p:
        a = _adapter()
        out = await a.health_check()
        assert out["status"] == "healthy"
        assert out["stop_reason"] == "end_turn"


@pytest.mark.asyncio
async def test_health_check_unhealthy_on_error():
    resp = _FakeResponse(status_code=500, text="down")
    p, _ = _patch_post(resp)
    with p:
        a = _adapter()
        out = await a.health_check()
        assert out["status"] == "unhealthy"
        assert "error" in out


# --------------------------------------------------------------- helpers


def test_message_to_portkey_rejects_unknown_block():
    with pytest.raises(TypeError):
        _message_to_portkey(ChatMessage(role="user", content=["a", 42]))  # type: ignore[list-item]


def test_normalize_usage_with_cache_fields():
    u = _normalize_usage(
        {
            "input_tokens": 10,
            "output_tokens": 3,
            "cache_read_input_tokens": 5,
            "cache_creation_input_tokens": 2,
        }
    )
    assert u["input_tokens"] == 10
    assert u["cache_read_input_tokens"] == 5
    assert u["cache_write_input_tokens"] == 2
    assert u["total_input_tokens"] == 17


def test_normalize_usage_empty():
    u = _normalize_usage({})
    assert u["total_input_tokens"] == 0
    assert u["provider"] == "portkey"


def test_response_from_portkey_max_tokens():
    r = _response_from_portkey({"content": [], "stop_reason": "max_tokens"})
    assert r.stop_reason == "max_tokens"
