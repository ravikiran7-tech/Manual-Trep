"""Additional BedrockAdapter coverage: init errors, from_connection, health, usage, cache points."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from app.core.exceptions import AuthenticationError, ProviderError
from app.services.llm.adapters import bedrock as bedrock_mod
from app.services.llm.adapters.bedrock import (
    BedrockAdapter,
    _normalize_usage,
    _response_from_bedrock,
)
from app.services.llm.protocol import ChatMessage, ToolResult


# --------------------------------------------------------------- construction


def test_init_credentials_error_raises_authentication_error():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        session_cls.return_value.client.side_effect = RuntimeError(
            "Unable to locate credentials"
        )
        with pytest.raises(AuthenticationError):
            BedrockAdapter(region="us-east-1", model_id="m", profile=None)


def test_init_other_error_raises_provider_error():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        session_cls.return_value.client.side_effect = RuntimeError("network down")
        with pytest.raises(ProviderError):
            BedrockAdapter(region="us-east-1", model_id="m", profile="someprofile")


# ----------------------------------------------------------------- factory


def test_from_connection_uses_config_then_settings(make_connection):
    conn = make_connection(provider_type="aws-bedrock", awsRegion="eu-west-1", modelId="m-cfg")
    captured = {}

    def fake_init(self, *, region, model_id, profile):
        captured.update(region=region, model_id=model_id, profile=profile)

    with patch.object(BedrockAdapter, "__init__", fake_init):
        BedrockAdapter.from_connection(conn)
    assert captured["region"] == "eu-west-1"
    assert captured["model_id"] == "m-cfg"


def test_from_connection_falls_back_to_settings_defaults(make_connection):
    conn = make_connection(provider_type="aws-bedrock")  # no region/model in cfg
    captured = {}

    def fake_init(self, *, region, model_id, profile):
        captured.update(region=region, model_id=model_id, profile=profile)

    with patch.object(BedrockAdapter, "__init__", fake_init):
        BedrockAdapter.from_connection(conn)
    # Falls back to settings.bedrock defaults (non-empty values).
    assert captured["region"]
    assert captured["model_id"]


# ----------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_check_healthy():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(region="us-east-1", model_id="m", profile=None)
        # health_check creates a second session/client; reset side effects.
        ctl = MagicMock()
        session_cls.return_value.client.return_value = ctl
        out = await adapter.health_check()
        assert out["status"] == "healthy"
        assert out["model"] == "m"
        ctl.list_foundation_models.assert_called_once()


@pytest.mark.asyncio
async def test_health_check_unhealthy_on_error():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(region="us-east-1", model_id="m", profile=None)
        ctl = MagicMock()
        ctl.list_foundation_models.side_effect = RuntimeError("denied")
        session_cls.return_value.client.return_value = ctl
        out = await adapter.health_check()
        assert out["status"] == "unhealthy"
        assert "denied" in out["error"]


# ----------------------------------------------------------------- chat / cache


@pytest.mark.asyncio
async def test_chat_no_system_no_tools_and_cachepoint_only_on_user_tail():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "stopReason": "end_turn",
        }
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(region="us-east-1", model_id="m", profile=None)

        # Last message is an assistant turn -> no cachePoint appended.
        await adapter.chat(
            messages=[
                ChatMessage(role="user", content=["hi"]),
                ChatMessage(role="assistant", content=["reply"]),
            ],
            system=None,
            tools=None,
            max_tokens=10,
            temperature=0.0,
        )
        kwargs = runtime.converse.call_args.kwargs
        assert "system" not in kwargs
        assert "toolConfig" not in kwargs
        # Assistant tail content has no cachePoint block.
        last_content = kwargs["messages"][-1]["content"]
        assert all("cachePoint" not in b for b in last_content)


@pytest.mark.asyncio
async def test_chat_appends_cachepoint_when_user_tail():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "stopReason": "end_turn",
        }
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(region="us-east-1", model_id="m", profile=None)
        await adapter.chat(
            messages=[ChatMessage(role="user", content=["hi"])],
            system=None,
            tools=None,
            max_tokens=10,
            temperature=0.0,
        )
        last_content = runtime.converse.call_args.kwargs["messages"][-1]["content"]
        assert last_content[-1] == {"cachePoint": {"type": "default"}}


# ----------------------------------------------------------------- usage


def test_normalize_usage_subtracts_cache_fields():
    usage = _normalize_usage(
        {
            "inputTokens": 100,
            "outputTokens": 20,
            "cacheReadInputTokens": 30,
            "cacheWriteInputTokens": 10,
        }
    )
    assert usage["input_tokens"] == 60  # 100 - 30 - 10
    assert usage["cache_read_input_tokens"] == 30
    assert usage["cache_write_input_tokens"] == 10
    assert usage["total_input_tokens"] == 100
    assert usage["provider"] == "aws-bedrock"


def test_response_from_bedrock_empty_output_defaults():
    r = _response_from_bedrock({})
    assert r.text_blocks == []
    assert r.tool_uses == []
    assert r.stop_reason == "end_turn"
    assert r.usage["total_input_tokens"] == 0


def test_response_from_bedrock_max_tokens_stop_reason():
    r = _response_from_bedrock(
        {"output": {"message": {"content": [{"text": "x"}]}}, "stopReason": "max_tokens"}
    )
    assert r.stop_reason == "max_tokens"