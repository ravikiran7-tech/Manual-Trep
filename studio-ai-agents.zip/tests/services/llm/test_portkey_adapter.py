"""PortkeyAdapter translation tests."""
from __future__ import annotations

import pytest

from app.services.llm.adapters.portkey import (
    _message_to_portkey,
    _response_from_portkey,
    _tool_spec_to_portkey,
)
from app.services.llm.protocol import (
    ChatMessage,
    ReasoningBlock,
    ToolResult,
    ToolSpec,
    ToolUse,
)


def test_tool_spec_to_portkey():
    ts = ToolSpec(
        name="bash",
        description="run a shell command",
        input_schema={"type": "object"},
    )
    assert _tool_spec_to_portkey(ts) == {
        "name": "bash",
        "description": "run a shell command",
        "input_schema": {"type": "object"},
    }


def test_message_to_portkey_plain_user_text_is_string():
    msg = ChatMessage(role="user", content=["hello"])
    assert _message_to_portkey(msg) == {"role": "user", "content": "hello"}


def test_message_to_portkey_assistant_with_tool_use_uses_content_blocks():
    msg = ChatMessage(
        role="assistant",
        content=[
            "Let me try this",
            ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"}),
        ],
    )
    out = _message_to_portkey(msg)
    assert out["role"] == "assistant"
    assert out["content"][0] == {"type": "text", "text": "Let me try this"}
    assert out["content"][1] == {
        "type": "tool_use",
        "id": "t1",
        "name": "bash",
        "input": {"command": "ls"},
    }


def test_message_to_portkey_user_with_tool_result():
    msg = ChatMessage(
        role="user",
        content=[ToolResult(tool_use_id="t1", content="output", is_error=False)],
    )
    out = _message_to_portkey(msg)
    assert out["role"] == "user"
    assert out["content"] == [
        {
            "type": "tool_result",
            "tool_use_id": "t1",
            "content": "output",
            "is_error": False,
        }
    ]


def test_response_from_portkey_text_and_tool_use():
    raw = {
        "content": [
            {"type": "text", "text": "hi"},
            {
                "type": "tool_use",
                "id": "t1",
                "name": "bash",
                "input": {"command": "ls"},
            },
        ],
        "stop_reason": "tool_use",
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }
    r = _response_from_portkey(raw)
    assert r.text_blocks == ["hi"]
    assert len(r.tool_uses) == 1
    assert r.tool_uses[0].tool_use_id == "t1"
    assert r.stop_reason == "tool_use"
    assert r.usage == {
        "input_tokens": 10,
        "output_tokens": 5,
        "cache_read_input_tokens": 0,
        "cache_write_input_tokens": 0,
        "total_input_tokens": 10,
        "provider": "portkey",
    }


def test_response_from_portkey_unknown_stop_reason():
    raw = {"content": [], "stop_reason": "something_else"}
    r = _response_from_portkey(raw)
    assert r.stop_reason == "other"


def test_response_from_portkey_defaults_stop_reason():
    raw = {"content": []}
    r = _response_from_portkey(raw)
    assert r.stop_reason == "end_turn"


def test_thinking_block_is_kept_and_echoed():
    thinking = {"type": "thinking", "thinking": "", "signature": "sig-1"}
    raw = {
        "content": [
            thinking,
            {"type": "text", "text": "hi"},
            {"type": "tool_use", "id": "t1", "name": "bash", "input": {"command": "ls"}},
        ],
        "stop_reason": "tool_use",
    }
    parsed = _response_from_portkey(raw)
    assert parsed.text_blocks == ["hi"]
    assert isinstance(parsed.ordered_content[0], ReasoningBlock)
    assert parsed.ordered_content[0].payload == thinking

    echoed = _message_to_portkey(
        ChatMessage(role="assistant", content=list(parsed.ordered_content))
    )
    assert echoed["content"][0] == thinking
    assert echoed["content"][1] == {"type": "text", "text": "hi"}
    assert echoed["content"][2]["type"] == "tool_use"
