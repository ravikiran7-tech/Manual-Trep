"""LLM_USE_ORCHESTRATOR gate tests.

The orchestrator/adapter stack is the default execution path; setting
LLM_USE_ORCHESTRATOR=false is the rollback switch. These tests pin that
default so the flip cannot silently regress.
"""
from __future__ import annotations

import pytest

from app.services.llm import _flag_is_enabled


def test_orchestrator_enabled_by_default(monkeypatch):
    monkeypatch.delenv("LLM_USE_ORCHESTRATOR", raising=False)
    assert _flag_is_enabled() is True


@pytest.mark.parametrize("value", ["true", "TRUE", " true ", "True"])
def test_orchestrator_enabled_when_flag_true(monkeypatch, value):
    monkeypatch.setenv("LLM_USE_ORCHESTRATOR", value)
    assert _flag_is_enabled() is True


@pytest.mark.parametrize("value", ["false", "FALSE", " false ", "0", ""])
def test_orchestrator_disabled_only_when_flag_not_true(monkeypatch, value):
    monkeypatch.setenv("LLM_USE_ORCHESTRATOR", value)
    assert _flag_is_enabled() is False
