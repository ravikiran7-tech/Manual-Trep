"""BedrockAdapter translation tests.

The adapter is the thin translation boundary: neutral types <-> Bedrock
Converse wire format. These tests exercise just that boundary; the tool loop
lives in the orchestrator and is tested separately.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError

from app.core.exceptions import AuthenticationError, ProviderError, RateLimitError
from app.services.llm.adapters import bedrock as bedrock_mod
from app.services.llm.adapters.bedrock import (
    BedrockAdapter,
    _message_to_bedrock,
    _response_from_bedrock,
    _tool_spec_to_bedrock,
)
from app.services.llm.protocol import (
    ChatMessage,
    ReasoningBlock,
    ToolResult,
    ToolSpec,
    ToolUse,
)


# ---------------------------------------------------------------- translators


def test_tool_spec_to_bedrock_wraps_in_toolspec():
    ts = ToolSpec(
        name="bash",
        description="run a command",
        input_schema={"type": "object", "properties": {"command": {"type": "string"}}},
    )
    result = _tool_spec_to_bedrock(ts)
    assert result == {
        "toolSpec": {
            "name": "bash",
            "description": "run a command",
            "inputSchema": {
                "json": {"type": "object", "properties": {"command": {"type": "string"}}}
            },
        }
    }


def test_message_to_bedrock_text_only():
    msg = ChatMessage(role="user", content=["hello"])
    out = _message_to_bedrock(msg)
    assert out == {"role": "user", "content": [{"text": "hello"}]}


def test_message_to_bedrock_assistant_with_tool_use():
    msg = ChatMessage(
        role="assistant",
        content=[
            "Calling a tool",
            ToolUse(tool_use_id="t1", name="bash", input={"command": "ls"}),
        ],
    )
    out = _message_to_bedrock(msg)
    assert out["role"] == "assistant"
    assert out["content"][0] == {"text": "Calling a tool"}
    assert out["content"][1] == {
        "toolUse": {"toolUseId": "t1", "name": "bash", "input": {"command": "ls"}}
    }


def test_message_to_bedrock_tool_result_error():
    msg = ChatMessage(
        role="user",
        content=[ToolResult(tool_use_id="t1", content="boom", is_error=True)],
    )
    out = _message_to_bedrock(msg)
    block = out["content"][0]
    assert block["toolResult"]["toolUseId"] == "t1"
    assert block["toolResult"]["content"] == [{"text": "boom"}]
    assert block["toolResult"]["status"] == "error"


def test_message_to_bedrock_rejects_unknown_block_type():
    with pytest.raises(TypeError):
        _message_to_bedrock(ChatMessage(role="user", content=[42]))  # type: ignore[list-item]


# ------------------------------------------------------------------ responses


def test_response_from_bedrock_text_only():
    raw = {
        "output": {
            "message": {"content": [{"text": "hi"}, {"text": " there"}]}
        },
        "stopReason": "end_turn",
        "usage": {"inputTokens": 5, "outputTokens": 2},
    }
    r = _response_from_bedrock(raw)
    assert r.text_blocks == ["hi", " there"]
    assert r.tool_uses == []
    assert r.stop_reason == "end_turn"
    assert r.usage == {
        "input_tokens": 5,
        "output_tokens": 2,
        "cache_read_input_tokens": 0,
        "cache_write_input_tokens": 0,
        "total_input_tokens": 5,
        "provider": "aws-bedrock",
    }


def test_response_from_bedrock_tool_use():
    raw = {
        "output": {
            "message": {
                "content": [
                    {"text": "I'll use a tool"},
                    {
                        "toolUse": {
                            "toolUseId": "t1",
                            "name": "code_editor",
                            "input": {"path": "a.txt", "operation": "read"},
                        }
                    },
                ]
            }
        },
        "stopReason": "tool_use",
    }
    r = _response_from_bedrock(raw)
    assert r.stop_reason == "tool_use"
    assert r.text_blocks == ["I'll use a tool"]
    assert len(r.tool_uses) == 1
    tu = r.tool_uses[0]
    assert tu.tool_use_id == "t1"
    assert tu.name == "code_editor"
    assert tu.input == {"path": "a.txt", "operation": "read"}


def test_response_from_bedrock_unknown_stop_reason_maps_to_other():
    raw = {"output": {"message": {"content": []}}, "stopReason": "weird"}
    r = _response_from_bedrock(raw)
    assert r.stop_reason == "other"


# ------------------------------------------------------------- error translation


def _client_error(code: str) -> ClientError:
    return ClientError(
        error_response={"Error": {"Code": code, "Message": f"msg-{code}"}},
        operation_name="Converse",
    )


def test_translate_rate_limit_errors():
    with pytest.raises(RateLimitError):
        bedrock_mod._raise_translated(_client_error("ThrottlingException"))
    with pytest.raises(RateLimitError):
        bedrock_mod._raise_translated(_client_error("TooManyRequestsException"))


def test_translate_auth_errors():
    with pytest.raises(AuthenticationError):
        bedrock_mod._raise_translated(_client_error("AccessDeniedException"))


def test_translate_generic_error():
    with pytest.raises(ProviderError):
        bedrock_mod._raise_translated(_client_error("InternalServerException"))


# ------------------------------------------------------------- adapter.chat


@pytest.mark.asyncio
async def test_adapter_chat_invokes_converse_with_request_body():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.return_value = {
            "output": {"message": {"content": [{"text": "pong"}]}},
            "stopReason": "end_turn",
        }
        session_cls.return_value.client.return_value = runtime

        adapter = BedrockAdapter(region="us-east-1", model_id="model-x", profile=None)
        out = await adapter.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system="be helpful",
            tools=[ToolSpec(name="bash", description="run", input_schema={"type": "object"})],
            max_tokens=100,
            temperature=0.1,
        )

        assert out.text_blocks == ["pong"]
        runtime.converse.assert_called_once()
        call_kwargs = runtime.converse.call_args.kwargs
        assert call_kwargs["modelId"] == "model-x"
        assert call_kwargs["messages"][0]["role"] == "user"
        # System now carries a cachePoint breakpoint after the static prompt.
        assert call_kwargs["system"] == [
            {"text": "be helpful"},
            {"cachePoint": {"type": "default"}},
        ]
        assert call_kwargs["toolConfig"]["tools"][0]["toolSpec"]["name"] == "bash"


@pytest.mark.asyncio
async def test_adapter_chat_translates_client_error_to_rate_limit():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.side_effect = _client_error("ThrottlingException")
        session_cls.return_value.client.return_value = runtime

        adapter = BedrockAdapter(region="us-east-1", model_id="m", profile=None)
        with pytest.raises(RateLimitError):
            await adapter.chat(
                messages=[ChatMessage(role="user", content=["x"])],
                system=None,
                tools=None,
                max_tokens=10,
                temperature=0.0,
            )


@pytest.mark.asyncio
async def test_sonnet_55_request_omits_temperature():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "stopReason": "end_turn",
        }
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(
            region="us-east-1",
            model_id="us.anthropic.claude-sonnet-5-5",
            profile=None,
        )
        await adapter.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system=None,
            tools=None,
            max_tokens=64,
            temperature=0.0,
        )
        inference = runtime.converse.call_args.kwargs["inferenceConfig"]
        assert inference == {"maxTokens": 64}
        assert "temperature" not in inference


@pytest.mark.asyncio
async def test_older_model_still_sends_temperature():
    with patch.object(bedrock_mod.boto3, "Session") as session_cls:
        runtime = MagicMock()
        runtime.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "stopReason": "end_turn",
        }
        session_cls.return_value.client.return_value = runtime
        adapter = BedrockAdapter(
            region="us-east-1",
            model_id="us.anthropic.claude-sonnet-4-6",
            profile=None,
        )
        await adapter.chat(
            messages=[ChatMessage(role="user", content=["ping"])],
            system=None,
            tools=None,
            max_tokens=64,
            temperature=0.0,
        )
        inference = runtime.converse.call_args.kwargs["inferenceConfig"]
        assert inference["temperature"] == 0.0


def test_reasoning_block_is_kept_and_echoed():
    signed = {
        "reasoningContent": {
            "reasoningText": {"text": "", "signature": "sig-1"}
        }
    }
    parsed = _response_from_bedrock(
        {
            "output": {
                "message": {
                    "content": [
                        signed,
                        {"text": "done"},
                        {
                            "toolUse": {
                                "toolUseId": "t1",
                                "name": "bash",
                                "input": {"command": "ls"},
                            }
                        },
                    ]
                }
            },
            "stopReason": "tool_use",
        }
    )
    assert parsed.text_blocks == ["done"]
    assert parsed.tool_uses[0].tool_use_id == "t1"
    assert isinstance(parsed.ordered_content[0], ReasoningBlock)
    assert parsed.ordered_content[0].payload == signed

    echoed = _message_to_bedrock(
        ChatMessage(role="assistant", content=list(parsed.ordered_content))
    )
    assert echoed["content"][0] == signed
    assert echoed["content"][1] == {"text": "done"}
    assert echoed["content"][2]["toolUse"]["toolUseId"] == "t1"
