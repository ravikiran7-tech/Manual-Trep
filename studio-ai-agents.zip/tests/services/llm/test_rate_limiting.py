"""Rate limiter / circuit breaker registry tests."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from app.core.llm_rate_limiter import LLMRateLimiter
from app.core.resilience import AsyncCircuitBreaker
from app.services.llm import rate_limiting as rl


def test_get_rate_limiter_known_providers():
    for name in ("aws-bedrock", "portkey", "azure", "openai-compatible"):
        limiter = rl.get_rate_limiter(name)
        assert isinstance(limiter, LLMRateLimiter)


def test_get_rate_limiter_unknown_raises_keyerror():
    with pytest.raises(KeyError) as exc:
        rl.get_rate_limiter("does-not-exist")
    assert "No rate limiter registered" in str(exc.value)
    assert "does-not-exist" in str(exc.value)


def test_get_circuit_breaker_known_providers():
    for name in ("aws-bedrock", "portkey", "azure", "openai-compatible"):
        cb = rl.get_circuit_breaker(name)
        assert isinstance(cb, AsyncCircuitBreaker)


def test_get_circuit_breaker_unknown_raises_keyerror():
    with pytest.raises(KeyError) as exc:
        rl.get_circuit_breaker("nope")
    assert "No circuit breaker registered" in str(exc.value)
    assert "nope" in str(exc.value)


def test_azure_limiter_and_breaker_are_distinct_instances():
    # Azure has its own locally-constructed singletons.
    assert rl.azure_llm_rate_limiter is rl.get_rate_limiter("azure")
    assert rl.azure_circuit_breaker is rl.get_circuit_breaker("azure")
    assert rl.azure_circuit_breaker.name == "azure_circuit_breaker"


def test_openai_compatible_limiter_and_breaker_are_registered():
    # The Concierto private LLM adapter reports name "openai-compatible".
    assert rl.openai_compatible_llm_rate_limiter is rl.get_rate_limiter("openai-compatible")
    assert rl.openai_compatible_circuit_breaker is rl.get_circuit_breaker("openai-compatible")
    assert rl.openai_compatible_circuit_breaker.name == "openai_compatible_circuit_breaker"


def test_openai_compatible_limiter_is_disabled():
    """No throttling for the self-hosted private LLM.

    It cannot be None (LLMOrchestrator calls rate_limiter.acquire()
    unconditionally), so it is a real limiter with every gate switched off.
    """
    limiter = rl.get_rate_limiter("openai-compatible")
    assert limiter.enabled is False
    assert limiter.enable_adaptive_delays is False
    assert limiter._rpm_bucket is None
    assert limiter._tpm_bucket is None


@pytest.mark.asyncio
async def test_openai_compatible_limiter_acquire_does_not_throttle():
    limiter = rl.get_rate_limiter("openai-compatible")
    # A disabled limiter yields straight through; 50 sequential acquires of a
    # huge token estimate must not sleep or consume a semaphore slot.
    for _ in range(50):
        async with limiter.acquire(estimated_tokens=10_000_000):
            pass
    assert limiter._total_calls == 0  # nothing was metered


def test_openai_compatible_limiter_is_off_by_construction_not_by_config():
    """The hosted providers' limiters come from _create_rate_limiter and follow
    LLM_RATE_LIMITER_* settings; this one is built disabled in-module, so no
    config change can start throttling the self-hosted private LLM.
    """
    limiter = rl.get_rate_limiter("openai-compatible")
    assert limiter is not rl.azure_llm_rate_limiter
    assert limiter.provider == "openai-compatible"
    with patch.object(rl._settings.llm_rate_limiter, "enabled", True):
        assert rl.get_rate_limiter("openai-compatible").enabled is False
