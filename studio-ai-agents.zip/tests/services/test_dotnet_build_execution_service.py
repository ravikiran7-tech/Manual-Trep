"""Tests for app.services.dotnet_build_execution_service.

All subprocess execution is mocked: no real `dotnet build` ever runs.
"""
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

import app.services.dotnet_build_execution_service as svc
from app.models.dotnet_build import BuildRequest, BuildResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _make_request(tmp_path: Path, **overrides) -> BuildRequest:
    proj = tmp_path / "proj"
    proj.mkdir(exist_ok=True)
    data = {
        "projectLocation": str(proj),
        "analysisId": "analysis-001",
        "claudeWorkspace": str(tmp_path / "ws"),
    }
    data.update(overrides)
    return BuildRequest(**data)


def _fake_proc(output: str, returncode: int = 0):
    """Return an AsyncMock standing in for an asyncio subprocess."""
    proc = AsyncMock()
    proc.communicate.return_value = (output.encode("utf-8"), b"")
    proc.returncode = returncode
    return proc


# ---------------------------------------------------------------------------
# _get_platform
# ---------------------------------------------------------------------------
class TestGetPlatform:
    def test_explicit_platform_returned(self):
        assert svc._get_platform("linux") == "linux"
        assert svc._get_platform("windows") == "windows"

    def test_none_autodetects_windows(self):
        with patch.object(svc.sys, "platform", "win32"):
            assert svc._get_platform(None) == "windows"

    def test_blank_autodetects_linux(self):
        with patch.object(svc.sys, "platform", "linux"):
            assert svc._get_platform("   ") == "linux"


# ---------------------------------------------------------------------------
# _create_directories_and_get_log_path
# ---------------------------------------------------------------------------
class TestCreateDirectories:
    def test_creates_logs_and_reports(self, tmp_path):
        log_file = svc._create_directories_and_get_log_path("aid", str(tmp_path))
        base = tmp_path / "validation" / "aid"
        assert (base / "logs").is_dir()
        assert (base / "reports").is_dir()
        assert log_file == base / "logs" / "build.log"


# ---------------------------------------------------------------------------
# _run_dotnet_build - command construction & subprocess handling
# ---------------------------------------------------------------------------
class TestRunDotnetBuild:
    async def test_command_with_sln_build_file(self, tmp_path):
        log_file = tmp_path / "build.log"
        proc = _fake_proc("Build succeeded\n", 0)
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          return_value=proc) as mock_exec:
            code, lines = await svc._run_dotnet_build(str(tmp_path), log_file, "App.sln")
        args = mock_exec.call_args[0]
        assert args == ("dotnet", "build", "App.sln")
        assert code == 0
        assert "Build succeeded" in lines[0]
        assert log_file.read_text(encoding="utf-8").startswith("Build succeeded")

    async def test_command_with_non_sln_build_file(self, tmp_path):
        log_file = tmp_path / "build.log"
        proc = _fake_proc("out", 0)
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          return_value=proc) as mock_exec:
            await svc._run_dotnet_build(str(tmp_path), log_file, "MyProj.csproj")
        assert mock_exec.call_args[0] == ("dotnet", "build", "MyProj.csproj")

    async def test_command_no_build_file(self, tmp_path):
        log_file = tmp_path / "build.log"
        proc = _fake_proc("out", 0)
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          return_value=proc) as mock_exec:
            await svc._run_dotnet_build(str(tmp_path), log_file, None)
        assert mock_exec.call_args[0] == ("dotnet", "build")

    async def test_command_blank_build_file(self, tmp_path):
        log_file = tmp_path / "build.log"
        proc = _fake_proc("out", 0)
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          return_value=proc) as mock_exec:
            await svc._run_dotnet_build(str(tmp_path), log_file, "   ")
        assert mock_exec.call_args[0] == ("dotnet", "build")

    async def test_dotnet_not_found(self, tmp_path):
        log_file = tmp_path / "build.log"
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          side_effect=FileNotFoundError()):
            code, lines = await svc._run_dotnet_build(str(tmp_path), log_file, None)
        assert code == 1
        assert "not found" in lines[0]
        assert "not found" in log_file.read_text(encoding="utf-8")

    async def test_generic_exception(self, tmp_path):
        log_file = tmp_path / "build.log"
        with patch.object(svc.asyncio, "create_subprocess_exec",
                          side_effect=RuntimeError("boom")):
            code, lines = await svc._run_dotnet_build(str(tmp_path), log_file, None)
        assert code == 1
        assert "Failed to run dotnet build" in lines[0]
        assert "boom" in log_file.read_text(encoding="utf-8")

    async def test_nonzero_returncode_passed_through(self, tmp_path):
        log_file = tmp_path / "build.log"
        proc = _fake_proc("Build FAILED\n", 1)
        with patch.object(svc.asyncio, "create_subprocess_exec", return_value=proc):
            code, lines = await svc._run_dotnet_build(str(tmp_path), log_file, None)
        assert code == 1
        assert "Build FAILED" in lines[0]


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------
class TestParsingHelpers:
    def test_determine_build_status_success(self):
        assert svc._determine_build_status(["x", "Build succeeded"]) == "SUCCESS"

    def test_determine_build_status_failure_upper(self):
        assert svc._determine_build_status(["Build FAILED"]) == "FAILURE"

    def test_determine_build_status_failure_lower(self):
        assert svc._determine_build_status(["Build failed"]) == "FAILURE"

    def test_determine_build_status_unknown(self):
        assert svc._determine_build_status(["nothing here"]) == "UNKNOWN"

    def test_extract_compilation_errors_dedup(self):
        lines = [
            "Program.cs(10,5): error CS1002: ; expected",
            "Program.cs(10,5): error CS1002: ; expected",  # dup
            "Other.cs(2,1): error CS0103: name not found",
            "not an error line",
        ]
        errors = svc._extract_compilation_errors(lines)
        assert len(errors) == 2
        assert errors[0].startswith("Program.cs(10,5)")
        assert errors[1].startswith("Other.cs(2,1)")

    def test_extract_compilation_errors_empty(self):
        assert svc._extract_compilation_errors(["no errors here"]) == []

    def test_extract_test_failures(self):
        lines = [
            "Failed!  - some test failed",
            "Failed!  - some test failed",  # dup
            "Passed test",
            "Failed (no keyword)",  # 'test' missing -> excluded
            "   ",  # blank stripped -> excluded
        ]
        failures = svc._extract_test_failures(lines)
        assert failures == ["Failed!  - some test failed"]

    def test_extract_errors_count_from_summary(self):
        assert svc._extract_errors_count(["    3 Error(s)"]) == 3

    def test_extract_errors_count_fallback(self):
        lines = ["something error CS1002 here", "plain error: oops", "ok"]
        # No "N Error(s)" summary -> fallback counts matching lines
        assert svc._extract_errors_count(lines) == 2

    def test_extract_warnings_count_from_summary(self):
        assert svc._extract_warnings_count(["    5 Warning(s)"]) == 5

    def test_extract_warnings_count_fallback(self):
        lines = ["x warning CS0168 y", "warning: deprecated"]
        assert svc._extract_warnings_count(lines) == 2

    def test_extract_total_time_found(self):
        assert svc._extract_total_time(["Time Elapsed 00:00:01.23"]) == "00:00:01.23"

    def test_extract_total_time_default(self):
        assert svc._extract_total_time(["no time"]) == "N/A"

    def test_parse_build_result_combines(self):
        lines = ["Build succeeded", "    2 Warning(s)", "Time Elapsed 00:00:02.0"]
        result = svc._parse_build_result(0, lines)
        assert isinstance(result, BuildResult)
        assert result.success is True
        assert result.build_status == "SUCCESS"
        assert result.warnings == 2
        assert result.total_time == "00:00:02.0"


# ---------------------------------------------------------------------------
# _save_build_result
# ---------------------------------------------------------------------------
class TestSaveBuildResult:
    def test_save_writes_json(self, tmp_path):
        result = BuildResult(exit_code=0, success=True, build_status="SUCCESS")
        svc._save_build_result(result, "aid", str(tmp_path))
        path = tmp_path / "validation" / "aid" / "reports" / "build-result.json"
        assert path.exists()
        data = json.loads(path.read_text(encoding="utf-8"))
        assert data["exitCode"] == 0
        assert data["buildStatus"] == "SUCCESS"

    def test_save_with_none_workspace_uses_tmp(self, tmp_path):
        # workspace None -> uses /tmp fallback; mkdir(parents, exist_ok) is safe
        result = BuildResult(exit_code=0, success=True, build_status="SUCCESS")
        with patch.object(svc, "Path") as mock_path:
            mock_path.side_effect = lambda p: Path(tmp_path) / str(p).lstrip("/\\")
            svc._save_build_result(result, "aid2", None)


# ---------------------------------------------------------------------------
# execute_dotnet_build - full flow
# ---------------------------------------------------------------------------
class TestExecuteDotnetBuild:
    async def test_success_flow(self, tmp_path):
        req = _make_request(tmp_path, platform="linux", buildFile="App.sln")
        proc = _fake_proc("Build succeeded\n    0 Warning(s)\n    0 Error(s)\n"
                          "Time Elapsed 00:00:03.5\n", 0)
        with patch.object(svc.asyncio, "create_subprocess_exec", return_value=proc):
            result = await svc.execute_dotnet_build(req)
        assert result.success is True
        assert result.build_status == "SUCCESS"
        assert result.total_time == "00:00:03.5"
        # build-result.json saved
        saved = Path(req.claude_workspace) / "validation" / "analysis-001" / \
            "reports" / "build-result.json"
        assert saved.exists()

    async def test_failure_raises_after_save(self, tmp_path):
        req = _make_request(tmp_path)
        proc = _fake_proc("Build FAILED\nProgram.cs(1,1): error CS1002: ; expected\n"
                          "    1 Error(s)\n", 1)
        with patch.object(svc.asyncio, "create_subprocess_exec", return_value=proc):
            with pytest.raises(RuntimeError, match="exit code: 1"):
                await svc.execute_dotnet_build(req)
        # result still saved despite raising
        saved = Path(req.claude_workspace) / "validation" / "analysis-001" / \
            "reports" / "build-result.json"
        assert saved.exists()
        data = json.loads(saved.read_text(encoding="utf-8"))
        assert data["success"] is False
        assert data["buildStatus"] == "FAILURE"
        assert data["errors"] == 1