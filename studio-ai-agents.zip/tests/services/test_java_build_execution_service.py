"""Tests for app.services.java_build_execution_service.

All subprocess execution and SDKMAN/filesystem checks are mocked: no real
Maven build, bash, or SDKMAN is ever invoked.
"""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.services.java_build_execution_service as svc
from app.models.dotnet_build import BuildRequest, BuildResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _make_request(tmp_path: Path, **overrides) -> BuildRequest:
    proj = tmp_path / "proj"
    proj.mkdir(exist_ok=True)
    data = {
        "projectLocation": str(proj),
        "analysisId": "analysis-001",
        "claudeWorkspace": str(tmp_path / "ws"),
        "technology": "java",
        "buildType": "maven",
        "version": "17",
    }
    data.update(overrides)
    return BuildRequest(**data)


# ---------------------------------------------------------------------------
# _verify_sdkman_installed
# ---------------------------------------------------------------------------
class TestVerifySdkman:
    def test_installed_ok(self):
        fake = MagicMock()
        fake.exists.return_value = True
        with patch.object(svc, "_SDKMAN_INIT_SCRIPT", fake):
            svc._verify_sdkman_installed()  # no raise

    def test_not_installed_raises(self):
        fake = MagicMock()
        fake.exists.return_value = False
        with patch.object(svc, "_SDKMAN_INIT_SCRIPT", fake):
            with pytest.raises(RuntimeError, match="SDKMAN is not installed"):
                svc._verify_sdkman_installed()


# ---------------------------------------------------------------------------
# _verify_project_structure
# ---------------------------------------------------------------------------
class TestVerifyProjectStructure:
    def test_valid_dir_no_build_file(self, tmp_path):
        req = _make_request(tmp_path)
        svc._verify_project_structure(req)  # no raise

    def test_missing_project(self, tmp_path):
        req = _make_request(tmp_path)
        req.project_location = str(tmp_path / "does-not-exist")
        with pytest.raises(ValueError, match="does not exist"):
            svc._verify_project_structure(req)

    def test_project_is_file_not_dir(self, tmp_path):
        f = tmp_path / "afile"
        f.write_text("x")
        req = _make_request(tmp_path)
        req.project_location = str(f)
        with pytest.raises(ValueError, match="not a directory"):
            svc._verify_project_structure(req)

    def test_build_file_present(self, tmp_path):
        req = _make_request(tmp_path, buildFile="pom.xml")
        (Path(req.project_location) / "pom.xml").write_text("<project/>")
        svc._verify_project_structure(req)  # no raise

    def test_build_file_missing(self, tmp_path):
        req = _make_request(tmp_path, buildFile="pom.xml")
        with pytest.raises(ValueError, match="Build file not found"):
            svc._verify_project_structure(req)


# ---------------------------------------------------------------------------
# _convert_to_sdkman_version
# ---------------------------------------------------------------------------
class TestConvertSdkmanVersion:
    @pytest.mark.parametrize("version,expected", [
        ("8", "8.0.422-tem"),
        ("1.8", "8.0.422-tem"),
        ("11", "11.0.25-tem"),
        ("17", "17.0.13-tem"),
        ("21", "21.0.5-tem"),
        ("25", "25.0.4-tem"),
        ("  17  ", "17.0.13-tem"),
    ])
    def test_known_versions(self, version, expected):
        assert svc._convert_to_sdkman_version(version) == expected

    def test_unknown_returns_default(self):
        assert svc._convert_to_sdkman_version("99") == svc._DEFAULT_SDKMAN_VERSION

    def test_none_raises(self):
        with pytest.raises(ValueError, match="cannot be null"):
            svc._convert_to_sdkman_version(None)

    def test_blank_raises(self):
        with pytest.raises(ValueError, match="cannot be null"):
            svc._convert_to_sdkman_version("   ")


# ---------------------------------------------------------------------------
# _verify_java_version_installed
# ---------------------------------------------------------------------------
class TestVerifyJavaVersionInstalled:
    def test_installed(self, tmp_path):
        with patch.object(svc.Path, "home", return_value=tmp_path):
            jpath = tmp_path / ".sdkman" / "candidates" / "java" / "17.0.13-tem"
            jpath.mkdir(parents=True)
            svc._verify_java_version_installed("17.0.13-tem")

    def test_not_installed(self, tmp_path):
        with patch.object(svc.Path, "home", return_value=tmp_path):
            with pytest.raises(RuntimeError, match="is not installed via SDKMAN"):
                svc._verify_java_version_installed("17.0.13-tem")


# ---------------------------------------------------------------------------
# _create_directories_and_get_log_path
# ---------------------------------------------------------------------------
class TestCreateDirectories:
    def test_creates_dirs(self, tmp_path):
        log_file = svc._create_directories_and_get_log_path("aid", str(tmp_path))
        base = tmp_path / "validation" / "aid"
        assert (base / "logs").is_dir()
        assert (base / "reports").is_dir()
        assert log_file == base / "logs" / "build.log"


# ---------------------------------------------------------------------------
# _create_maven_build_script
# ---------------------------------------------------------------------------
class TestCreateMavenBuildScript:
    def test_script_with_skip_tests(self, tmp_path):
        req = _make_request(tmp_path, skipTests=True)
        log = tmp_path / "build.log"
        script = svc._create_maven_build_script(req, log, "17.0.13-tem")
        assert "mvn clean install -DskipTests" in script
        assert "sdk use java 17.0.13-tem" in script
        assert str(log) in script

    def test_script_without_skip_tests(self, tmp_path):
        req = _make_request(tmp_path, skipTests=False)
        log = tmp_path / "build.log"
        script = svc._create_maven_build_script(req, log, "21.0.5-tem")
        assert "mvn clean install;" in script
        assert "-DskipTests" not in script

    def test_script_escapes_single_quotes_in_log_path(self, tmp_path):
        req = _make_request(tmp_path)
        log = Path("/tmp/it's/build.log")
        script = svc._create_maven_build_script(req, log, "17.0.13-tem")
        assert "'\\''" in script  # quote was escaped


# ---------------------------------------------------------------------------
# _execute_maven_build
# ---------------------------------------------------------------------------
class TestExecuteMavenBuild:
    async def test_success(self, tmp_path):
        req = _make_request(tmp_path)
        log = tmp_path / "build.log"
        proc = AsyncMock()
        proc.wait.return_value = 0
        with patch.object(svc, "_verify_java_version_installed"), \
             patch.object(svc.asyncio, "create_subprocess_exec",
                          return_value=proc) as mock_exec:
            code = await svc._execute_maven_build(req, log)
        assert code == 0
        # invoked /bin/bash -c <script>
        args = mock_exec.call_args[0]
        assert args[0] == "/bin/bash"
        assert args[1] == "-c"

    async def test_nonzero_exit(self, tmp_path):
        req = _make_request(tmp_path)
        log = tmp_path / "build.log"
        proc = AsyncMock()
        proc.wait.return_value = 1
        with patch.object(svc, "_verify_java_version_installed"), \
             patch.object(svc.asyncio, "create_subprocess_exec", return_value=proc):
            code = await svc._execute_maven_build(req, log)
        assert code == 1

    async def test_bash_not_found(self, tmp_path):
        req = _make_request(tmp_path)
        log = tmp_path / "build.log"
        with patch.object(svc, "_verify_java_version_installed"), \
             patch.object(svc.asyncio, "create_subprocess_exec",
                          side_effect=FileNotFoundError()):
            with pytest.raises(RuntimeError, match="/bin/bash not found"):
                await svc._execute_maven_build(req, log)

    async def test_generic_exception(self, tmp_path):
        req = _make_request(tmp_path)
        log = tmp_path / "build.log"
        with patch.object(svc, "_verify_java_version_installed"), \
             patch.object(svc.asyncio, "create_subprocess_exec",
                          side_effect=OSError("boom")):
            with pytest.raises(RuntimeError, match="Failed to run Maven build"):
                await svc._execute_maven_build(req, log)


# ---------------------------------------------------------------------------
# _read_log_file
# ---------------------------------------------------------------------------
class TestReadLogFile:
    def test_reads_lines(self, tmp_path):
        log = tmp_path / "build.log"
        log.write_text("line1\nline2\n", encoding="utf-8")
        assert svc._read_log_file(log) == ["line1", "line2"]

    def test_missing_returns_placeholder(self, tmp_path):
        assert svc._read_log_file(tmp_path / "nope.log") == ["Log file not found"]


# ---------------------------------------------------------------------------
# Maven parsing helpers
# ---------------------------------------------------------------------------
class TestParsingHelpers:
    def test_determine_build_status_success(self):
        assert svc._determine_build_status(["BUILD SUCCESS"]) == "SUCCESS"

    def test_determine_build_status_failure(self):
        assert svc._determine_build_status(["BUILD FAILURE"]) == "FAILURE"

    def test_determine_build_status_unknown(self):
        assert svc._determine_build_status(["nothing"]) == "UNKNOWN"

    def test_extract_errors_dedup(self):
        lines = [
            "[ERROR] compilation failure",
            "[ERROR] compilation failure",  # dup
            "[ERROR] another",
            "  [ERROR] indented",
            "INFO not error",
        ]
        errors = svc._extract_errors(lines)
        assert errors == [
            "[ERROR] compilation failure",
            "[ERROR] another",
            "[ERROR] indented",
        ]

    def test_extract_test_failures_tests_run(self):
        lines = ["Tests run: 5, Failures: 1, Errors: 0, Skipped: 0"]
        assert svc._extract_test_failures(lines) == [lines[0]]

    def test_extract_test_failures_failed_keyword(self):
        lines = ["FAILED com.example.MyTest.shouldWork"]
        assert svc._extract_test_failures(lines) == [lines[0]]

    def test_extract_test_failures_dedup_and_skip(self):
        lines = [
            "Tests run: 1, Failures: 1",
            "Tests run: 1, Failures: 1",  # dup
            "irrelevant",
        ]
        assert svc._extract_test_failures(lines) == ["Tests run: 1, Failures: 1"]

    def test_extract_error_count(self):
        assert svc._extract_error_count(["[ERROR] a", "[ERROR] b", "ok"]) == 2

    def test_extract_warning_count(self):
        assert svc._extract_warning_count(["[WARNING] a", " [WARNING] b", "x"]) == 2

    def test_extract_total_time_found(self):
        assert svc._extract_total_time(["Total time:  12.345 s"]) == "12.345 s"

    def test_extract_total_time_default(self):
        assert svc._extract_total_time(["no time here"]) == "N/A"

    def test_parse_build_result(self):
        lines = ["BUILD SUCCESS", "[WARNING] w", "Total time: 1.0 s"]
        result = svc._parse_build_result(0, lines)
        assert isinstance(result, BuildResult)
        assert result.build_status == "SUCCESS"
        assert result.warnings == 1
        assert result.total_time == "1.0 s"


# ---------------------------------------------------------------------------
# _save_build_result
# ---------------------------------------------------------------------------
class TestSaveBuildResult:
    def test_save_json(self, tmp_path):
        result = BuildResult(exit_code=0, success=True, build_status="SUCCESS")
        svc._save_build_result(result, "aid", str(tmp_path))
        path = tmp_path / "validation" / "aid" / "reports" / "build-result.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        assert data["buildStatus"] == "SUCCESS"


# ---------------------------------------------------------------------------
# execute_java_build - full flow
# ---------------------------------------------------------------------------
class TestExecuteJavaBuild:
    async def test_success_flow(self, tmp_path):
        req = _make_request(tmp_path)
        log_lines = "BUILD SUCCESS\n[WARNING] w1\nTotal time: 5.0 s\n"

        async def fake_exec_maven(request, log_file):
            log_file.write_text(log_lines, encoding="utf-8")
            return 0

        with patch.object(svc, "_verify_sdkman_installed"), \
             patch.object(svc, "_execute_maven_build", side_effect=fake_exec_maven):
            result = await svc.execute_java_build(req)
        assert result.success is True
        assert result.build_status == "SUCCESS"
        assert result.total_time == "5.0 s"
        saved = Path(req.claude_workspace) / "validation" / "analysis-001" / \
            "reports" / "build-result.json"
        assert saved.exists()

    async def test_failure_raises_after_save(self, tmp_path):
        req = _make_request(tmp_path)

        async def fake_exec_maven(request, log_file):
            log_file.write_text("BUILD FAILURE\n[ERROR] compile error\n", encoding="utf-8")
            return 1

        with patch.object(svc, "_verify_sdkman_installed"), \
             patch.object(svc, "_execute_maven_build", side_effect=fake_exec_maven):
            with pytest.raises(RuntimeError, match="exit code: 1"):
                await svc.execute_java_build(req)
        saved = Path(req.claude_workspace) / "validation" / "analysis-001" / \
            "reports" / "build-result.json"
        data = json.loads(saved.read_text(encoding="utf-8"))
        assert data["success"] is False
        assert data["buildStatus"] == "FAILURE"

    async def test_unsupported_build_type_raises(self, tmp_path):
        req = _make_request(tmp_path, buildType="gradle")
        with patch.object(svc, "_verify_sdkman_installed"):
            with pytest.raises(NotImplementedError, match="not yet supported"):
                await svc.execute_java_build(req)

    async def test_unsupported_technology_raises(self, tmp_path):
        req = _make_request(tmp_path, technology="dotnet")
        with patch.object(svc, "_verify_sdkman_installed"):
            with pytest.raises(NotImplementedError):
                await svc.execute_java_build(req)

    async def test_missing_technology_raises(self, tmp_path):
        req = _make_request(tmp_path, technology=None)
        with patch.object(svc, "_verify_sdkman_installed"):
            with pytest.raises(NotImplementedError):
                await svc.execute_java_build(req)