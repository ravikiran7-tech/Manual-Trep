"""Shared fixtures for service tests."""
import json

import httpx
import pytest

import app.services.studio_core_git_sync as git_sync_mod
from app.core.config import get_settings


class FakeStudioCore:
    """Stands in for studio-core's git step endpoints: records requests and answers with a scripted status or error."""

    def __init__(self):
        self.requests: list[httpx.Request] = []
        self.timeouts: list[httpx.Timeout] = []
        self.answers = {"sync": 200, "commit-and-push": 200}

    def bodies(self, endpoint):
        return [
            json.loads(request.content)
            for request in self.requests
            if request.url.path.endswith(f"/v1/git/step/{endpoint}")
        ]

    def handle(self, request):
        self.requests.append(request)
        answer = self.answers[request.url.path.rsplit("/", 1)[-1]]
        if isinstance(answer, Exception):
            raise answer
        return httpx.Response(answer, json={"message": "stub"})


@pytest.fixture
def studio_core(monkeypatch):
    """Route the git step calls to a FakeStudioCore with the switch on; no network is used."""
    fake = FakeStudioCore()
    real_client = httpx.AsyncClient

    def client_factory(**kwargs):
        fake.timeouts.append(kwargs["timeout"])
        return real_client(transport=httpx.MockTransport(fake.handle), **kwargs)

    monkeypatch.setattr(git_sync_mod.httpx, "AsyncClient", client_factory)
    monkeypatch.setattr(get_settings(), "git_step_sync_enabled", True)
    return fake
