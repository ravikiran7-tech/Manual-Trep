"""Tests for app.services.tool_executor.ToolExecutor."""
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from app.services.tool_executor import (
    ToolExecutor,
    ToolResult,
    format_tool_result_for_model,
)


@pytest.fixture
def executor(tmp_path):
    return ToolExecutor(project_path=str(tmp_path), timeout=5)


def _completed(returncode=0, stdout="", stderr=""):
    return MagicMock(returncode=returncode, stdout=stdout, stderr=stderr)


# ==========================================================================
# execute_tool dispatch
# ==========================================================================
def test_execute_tool_unknown(executor):
    res = executor.execute_tool("frobnicate", {}, "id1")
    assert res.success is False
    assert "Unknown tool" in res.error


def test_execute_tool_dispatches_bash(executor):
    with patch.object(executor, "_execute_bash", return_value=ToolResult(True, "ok")) as m:
        res = executor.execute_tool("bash", {"command": "ls"}, "id1")
    assert res.success is True
    m.assert_called_once()


def test_execute_tool_dispatches_code_editor(executor):
    with patch.object(executor, "_execute_file_operation", return_value=ToolResult(True, "ok")) as m:
        res = executor.execute_tool("code_editor", {"path": "x", "operation": "read"}, "id1")
    assert res.success is True
    m.assert_called_once()


def test_execute_tool_exception_handled(executor):
    with patch.object(executor, "_execute_bash", side_effect=RuntimeError("boom")):
        res = executor.execute_tool("bash", {"command": "ls"}, "id1")
    assert res.success is False
    assert "Tool execution failed" in res.error


def test_init_defaults_working_directory(tmp_path):
    ex = ToolExecutor(project_path=str(tmp_path))
    assert ex.working_directory == str(tmp_path)
    assert ex.timeout == 30


def test_init_custom_working_directory(tmp_path):
    ex = ToolExecutor(project_path=str(tmp_path), working_directory="/custom")
    assert ex.working_directory == "/custom"


# ==========================================================================
# _execute_bash
# ==========================================================================
def test_bash_no_command(executor):
    res = executor.execute_tool("bash", {"command": ""}, "id1")
    assert res.success is False
    assert "No command provided" in res.error


def test_bash_working_dir_missing(executor):
    res = executor.execute_tool(
        "bash", {"command": "ls", "working_directory": "/does/not/exist/xyz"}, "id1"
    )
    assert res.success is False
    assert "does not exist" in res.error


def test_bash_success(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(0, "hello", ""),
    ):
        res = executor.execute_tool("bash", {"command": "echo hi"}, "id1")
    assert res.success is True
    assert res.output == "hello"
    assert res.error is None


def test_bash_success_with_stderr_appended(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(0, "out", "warn"),
    ):
        res = executor.execute_tool("bash", {"command": "echo hi"}, "id1")
    assert res.success is True
    assert "[stderr]" in res.output
    assert "warn" in res.output


def test_bash_no_output(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(0, "", ""),
    ):
        res = executor.execute_tool("bash", {"command": "true"}, "id1")
    assert res.success is True
    assert res.output == "(no output)"


def test_bash_nonzero_exit_is_error(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(2, "", "err"),
    ):
        res = executor.execute_tool("bash", {"command": "false"}, "id1")
    assert res.success is False
    assert "exited with code 2" in res.error


def test_bash_grep_exit1_treated_as_success(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(1, "", ""),
    ):
        res = executor.execute_tool("bash", {"command": "grep foo file.txt"}, "id1")
    assert res.success is True
    assert res.error is None


def test_bash_rg_exit1_treated_as_success(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(1, "", ""),
    ):
        res = executor.execute_tool("bash", {"command": "rg pattern"}, "id1")
    assert res.success is True


def test_bash_piped_grep_exit1_success(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(1, "", ""),
    ):
        res = executor.execute_tool("bash", {"command": "cat x | grep foo"}, "id1")
    assert res.success is True


def test_bash_nongrep_exit1_is_error(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        return_value=_completed(1, "", ""),
    ):
        res = executor.execute_tool("bash", {"command": "ls /missing"}, "id1")
    assert res.success is False
    assert "exited with code 1" in res.error


def test_bash_timeout(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="sleep", timeout=5),
    ):
        res = executor.execute_tool("bash", {"command": "sleep 100"}, "id1")
    assert res.success is False
    assert "timed out" in res.error


def test_bash_generic_exception(executor):
    with patch(
        "app.services.tool_executor.subprocess.run",
        side_effect=OSError("spawn failure"),
    ):
        res = executor.execute_tool("bash", {"command": "echo hi"}, "id1")
    assert res.success is False
    assert "Command execution error" in res.error


# ==========================================================================
# _execute_file_operation
# ==========================================================================
def test_file_op_missing_path(executor):
    res = executor.execute_tool("code_editor", {"operation": "read"}, "id1")
    assert res.success is False
    assert "Missing path or operation" in res.error


def test_file_op_missing_operation(executor):
    res = executor.execute_tool("code_editor", {"path": "x.txt"}, "id1")
    assert res.success is False
    assert "Missing path or operation" in res.error


def test_file_op_unknown_operation(executor, tmp_path):
    f = tmp_path / "x.txt"
    f.write_text("hi")
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "explode"}, "id1"
    )
    assert res.success is False
    assert "Unknown operation" in res.error


def test_file_op_relative_path_joined(executor, tmp_path):
    (tmp_path / "rel.txt").write_text("content")
    res = executor.execute_tool(
        "code_editor", {"path": "rel.txt", "operation": "read"}, "id1"
    )
    assert res.success is True
    assert res.output == "content"


def test_file_op_exception_path(executor):
    # Force an exception inside the try block by making Path.resolve raise
    with patch(
        "app.services.tool_executor.Path.resolve", side_effect=RuntimeError("resolve boom")
    ):
        res = executor.execute_tool(
            "code_editor", {"path": "/abs/x.txt", "operation": "read"}, "id1"
        )
    assert res.success is False
    assert "File operation error" in res.error


def test_file_op_sets_execution_time(executor, tmp_path):
    f = tmp_path / "x.txt"
    f.write_text("hi")
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "read"}, "id1"
    )
    assert res.execution_time_ms >= 0


# ---- read ----
def test_read_file_success(executor, tmp_path):
    f = tmp_path / "r.txt"
    f.write_text("data here")
    res = executor.execute_tool("code_editor", {"path": str(f), "operation": "read"}, "id1")
    assert res.success is True
    assert res.output == "data here"


def test_read_file_not_found(executor, tmp_path):
    res = executor.execute_tool(
        "code_editor", {"path": str(tmp_path / "missing.txt"), "operation": "read"}, "id1"
    )
    assert res.success is False
    assert "File not found" in res.error


def test_read_path_is_dir(executor, tmp_path):
    d = tmp_path / "subdir"
    d.mkdir()
    res = executor.execute_tool("code_editor", {"path": str(d), "operation": "read"}, "id1")
    assert res.success is False
    assert "not a file" in res.error


def test_read_file_exception(executor, tmp_path):
    f = tmp_path / "r.txt"
    f.write_text("data")
    with patch("builtins.open", side_effect=OSError("read fail")):
        res = executor.execute_tool(
            "code_editor", {"path": str(f), "operation": "read"}, "id1"
        )
    assert res.success is False
    assert "Read error" in res.error


# ---- write ----
def test_write_file_success(executor, tmp_path):
    f = tmp_path / "w.txt"
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "write", "content": "written!"}, "id1"
    )
    assert res.success is True
    assert f.read_text() == "written!"
    assert "Successfully wrote" in res.output


def test_write_file_creates_parent_dir(executor, tmp_path):
    f = tmp_path / "nested" / "deep" / "w.txt"
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "write", "content": "x"}, "id1"
    )
    assert res.success is True
    assert f.exists()


def test_write_file_exception(executor, tmp_path):
    f = tmp_path / "w.txt"
    with patch("builtins.open", side_effect=OSError("write fail")):
        res = executor.execute_tool(
            "code_editor", {"path": str(f), "operation": "write", "content": "x"}, "id1"
        )
    assert res.success is False
    assert "Write error" in res.error


# ---- delete ----
def test_delete_file_success(executor, tmp_path):
    f = tmp_path / "d.txt"
    f.write_text("bye")
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "delete"}, "id1"
    )
    assert res.success is True
    assert not f.exists()


def test_delete_file_not_found(executor, tmp_path):
    res = executor.execute_tool(
        "code_editor", {"path": str(tmp_path / "missing.txt"), "operation": "delete"}, "id1"
    )
    assert res.success is False
    assert "File not found" in res.error


def test_delete_path_is_dir(executor, tmp_path):
    d = tmp_path / "adir"
    d.mkdir()
    res = executor.execute_tool(
        "code_editor", {"path": str(d), "operation": "delete"}, "id1"
    )
    assert res.success is False
    assert "not a file" in res.error


def test_delete_file_exception(executor, tmp_path):
    f = tmp_path / "d.txt"
    f.write_text("bye")
    with patch("app.services.tool_executor.os.remove", side_effect=OSError("del fail")):
        res = executor.execute_tool(
            "code_editor", {"path": str(f), "operation": "delete"}, "id1"
        )
    assert res.success is False
    assert "Delete error" in res.error


# ---- patch ----
def test_patch_missing_patch_data(executor, tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("a\nb\n")
    res = executor.execute_tool(
        "code_editor", {"path": str(f), "operation": "patch"}, "id1"
    )
    assert res.success is False
    assert "patch_data is required" in res.error


def test_patch_validation_failed(executor, tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("a\nb\n")
    res = executor.execute_tool(
        "code_editor",
        {
            "path": str(f),
            "operation": "patch",
            "patch_format": "unified_diff",
            "patch_data": "no hunks here",
        },
        "id1",
    )
    assert res.success is False
    assert "Patch validation failed" in res.error


def test_patch_success(executor, tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("alpha\nbeta\ngamma\n")
    res = executor.execute_tool(
        "code_editor",
        {
            "path": str(f),
            "operation": "patch",
            "patch_format": "unified_diff",
            "patch_data": "@@ -2,1 +2,1 @@\n-beta\n+BETA\n",
        },
        "id1",
    )
    assert res.success is True
    assert "Successfully applied patch" in res.output
    assert "BETA" in f.read_text()


def test_patch_apply_failure(executor, tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("a\nb\n")
    # Validation passes (has @@), but apply fails -> patch error surfaced
    from app.services.tool_executor import PatchManager as PM

    with patch.object(
        PM, "apply_patch",
        return_value=MagicMock(success=False, error="apply boom"),
    ):
        res = executor.execute_tool(
            "code_editor",
            {
                "path": str(f),
                "operation": "patch",
                "patch_format": "unified_diff",
                "patch_data": "@@ -1 +1 @@",
            },
            "id1",
        )
    assert res.success is False
    assert "apply boom" in res.error


def test_patch_apply_failure_default_message(executor, tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("a\nb\n")
    from app.services.tool_executor import PatchManager as PM

    with patch.object(
        PM, "apply_patch",
        return_value=MagicMock(success=False, error=None),
    ):
        res = executor.execute_tool(
            "code_editor",
            {
                "path": str(f),
                "operation": "patch",
                "patch_format": "unified_diff",
                "patch_data": "@@ -1 +1 @@",
            },
            "id1",
        )
    assert res.success is False
    assert "Patch application failed" in res.error


# ==========================================================================
# format_tool_result_for_model
# ==========================================================================
def test_format_success():
    res = ToolResult(success=True, output="all good")
    block = format_tool_result_for_model("id1", res)
    assert block["type"] == "tool_result"
    assert block["tool_use_id"] == "id1"
    assert block["content"] == "all good"
    assert block["is_error"] is False


def test_format_error_with_output():
    res = ToolResult(success=False, output="partial", error="bad thing")
    block = format_tool_result_for_model("id1", res)
    assert "Error: bad thing" in block["content"]
    assert "Output: partial" in block["content"]
    assert block["is_error"] is True


def test_format_error_without_output():
    res = ToolResult(success=False, output="", error="bad thing")
    block = format_tool_result_for_model("id1", res)
    assert block["content"] == "Error: bad thing"
    assert block["is_error"] is True