"""Tests for the studio-core git sync and commit-and-push calls around a step."""
import httpx
import pytest

from app.core.config import get_settings
from app.services.studio_core_git_sync import commit_and_push_after_step, sync_before_step


def _url(endpoint):
    return f"{get_settings().studio_core.base_url.rstrip('/')}/v1/git/step/{endpoint}"


async def test_sync_request_shape(studio_core):
    await sync_before_step("a1", "/w/project")

    [request] = studio_core.requests
    assert (request.method, str(request.url)) == ("POST", _url("sync"))
    assert studio_core.bodies("sync") == [{"analysisId": "a1", "projectPath": "/w/project"}]
    [timeout] = studio_core.timeouts
    assert (timeout.connect, timeout.read) == (15.0, 180)


async def test_commit_and_push_request_shape(studio_core):
    assert await commit_and_push_after_step("a1", "/w/project", "fix-upgrade") is False

    [request] = studio_core.requests
    assert (request.method, str(request.url)) == ("POST", _url("commit-and-push"))
    assert studio_core.bodies("commit-and-push") == [
        {"analysisId": "a1", "projectPath": "/w/project", "commitMessage": "studio: fix-upgrade analysisId=a1"}
    ]
    [timeout] = studio_core.timeouts
    assert (timeout.connect, timeout.read) == (15.0, 600)


async def test_409_means_push_rejected(studio_core):
    studio_core.answers["commit-and-push"] = 409
    assert await commit_and_push_after_step("a1", "/w/project", "analysis") is True


@pytest.mark.parametrize(
    "answer",
    [200, 400, 404, 500, 503, httpx.ConnectError("connection refused"), httpx.ReadTimeout("read")],
)
async def test_any_other_status_or_error_carries_on(studio_core, answer):
    studio_core.answers = {"sync": answer, "commit-and-push": answer}

    await sync_before_step("a1", "/w/project")
    assert await commit_and_push_after_step("a1", "/w/project", "analysis") is False
    assert len(studio_core.requests) == 2


@pytest.mark.parametrize("enabled, analysis_id", [(False, "a1"), (True, None), (True, "")])
async def test_no_calls_when_switch_off_or_no_analysis_id(studio_core, monkeypatch, enabled, analysis_id):
    monkeypatch.setattr(get_settings(), "git_step_sync_enabled", enabled)

    await sync_before_step(analysis_id, "/w/project")
    assert await commit_and_push_after_step(analysis_id, "/w/project", "analysis") is False

    assert studio_core.requests == []
