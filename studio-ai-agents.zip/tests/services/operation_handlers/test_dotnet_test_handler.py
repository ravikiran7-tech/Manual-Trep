"""Tests for DotnetTestHandler (dotnet-test-execution operation)."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.operation_handlers.dotnet_test_handler import DotnetTestHandler
from app.core.exceptions import ValidationError
from app.core import resilience as resilience_mod


def _result_event(is_error=False):
    return {"type": "result", "is_error": is_error, "input_tokens": 5, "output_tokens": 7}


def _assistant_json_event(payload):
    text = "```json\n" + json.dumps(payload) + "\n```"
    return {"type": "assistant", "subtype": "text_delta", "text": text}


def _reset_all_breakers():
    for b in (
        resilience_mod.bedrock_circuit_breaker,
        resilience_mod.portkey_circuit_breaker,
        resilience_mod.compass_circuit_breaker,
    ):
        try:
            b.close()
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _reset_breaker(monkeypatch):
    _reset_all_breakers()
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_min", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_max", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_multiplier", 0, raising=False)
    yield
    _reset_all_breakers()


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    from app.services.operation_handlers import dotnet_test_handler as mod
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path), raising=False)
    return tmp_path


@pytest.fixture
def prompt_file(tmp_path):
    p = tmp_path / "prompt.txt"
    p.write_text("Run the tests.", encoding="utf-8")
    return str(p).replace("\\", "/")


def _make_handler(events=None, provider_side_effect=None):
    provider = MagicMock()
    invoke = AsyncMock()
    if provider_side_effect is not None:
        invoke.side_effect = provider_side_effect
    else:
        invoke.return_value = events if events is not None else []
    provider.invoke_with_tools_agentic_graph = invoke
    provider.invoke_with_tools_agentic = invoke
    factory = MagicMock()
    factory.get_provider = AsyncMock(return_value=provider)
    return DotnetTestHandler(provider_factory=factory), provider, invoke


def _make_request(prompt, project_path="/projects/app", analysis_id="dt-123", dotnet_version=None):
    from app.models.requests import ClaudeCliRequest
    return ClaudeCliRequest(
        prompt=prompt,
        projectPath=project_path,
        analysisId=analysis_id,
        operation="dotnet-test-execution",
        dotnetVersion=dotnet_version,
    )


def test_get_timeout():
    handler, *_ = _make_handler()
    assert handler.get_timeout() == handler.settings.timeouts.build_validation


def test_get_output_directory():
    handler, *_ = _make_handler()
    assert handler.get_output_directory(_make_request("x")) == "validation"


def test_enhance_prompt_with_test_context():
    handler, *_ = _make_handler()
    out = handler._enhance_prompt_with_test_context("ORIG", "7.0")
    assert "7.0" in out and out.endswith("ORIG")


def test_validate_request_ok(prompt_file):
    handler, *_ = _make_handler()
    handler.validate_request(_make_request(prompt_file, dotnet_version="8.0"))


def test_validate_request_dotnet_10(prompt_file):
    handler, *_ = _make_handler()
    handler.validate_request(_make_request(prompt_file, dotnet_version="10.0"))


def test_validate_request_missing_prompt():
    handler, *_ = _make_handler()
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(None))


def test_validate_request_bad_version(prompt_file):
    handler, *_ = _make_handler()
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(prompt_file, dotnet_version="9.0"))


def test_create_validation_directories(workspace):
    handler, *_ = _make_handler()
    req = _make_request("x", analysis_id="abc")
    handler._create_validation_directories(req)
    base = workspace / "validation" / "abc"
    for sub in ("test-results", "_claude", "coverage"):
        assert (base / sub).is_dir()


async def test_execute_success(workspace, prompt_file):
    events = [_assistant_json_event({"passed": 5}), _result_event(False)]
    handler, _, invoke = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file, dotnet_version="8.0"))
    assert resp.status == "success"
    assert resp.exit_code == 0
    invoke.assert_awaited()
    # result file written under _claude
    result = Path(resp.output_file_path).parent / "test-execution-result.json"
    assert result.exists()


async def test_execute_success_no_json(workspace, prompt_file):
    events = [{"type": "assistant", "subtype": "text_delta", "text": "plain"}, _result_event(False)]
    handler, *_ = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file))  # default version
    assert resp.status == "success"


async def test_execute_failure(workspace, prompt_file):
    events = [{"type": "error", "error": "tests failed"}, _result_event(True)]
    handler, *_ = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file))
    assert resp.status == "error"
    assert "tests failed" in resp.message


async def test_execute_validation_raises(workspace):
    handler, *_ = _make_handler(events=[])
    with pytest.raises(ValidationError):
        await handler.execute(_make_request(None))


async def test_execute_provider_failure_propagates(workspace, prompt_file):
    handler, *_ = _make_handler(provider_side_effect=RuntimeError("down"))
    with pytest.raises(RuntimeError):
        await handler.execute(_make_request(prompt_file))