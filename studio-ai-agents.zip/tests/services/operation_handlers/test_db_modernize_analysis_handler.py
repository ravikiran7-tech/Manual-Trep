"""Tests for DbModernizeAnalysisHandler (no JSON-result extraction)."""
from unittest.mock import MagicMock, AsyncMock

import pytest

from app.services.operation_handlers.db_modernize_analysis_handler import (
    DbModernizeAnalysisHandler,
)
from app.models.requests import ClaudeCliRequest
from app.core.exceptions import ValidationError


def make_request(tmp_path, prompt_file, **overrides):
    data = {
        "projectPath": str(tmp_path).replace("\\", "/"),
        "analysisId": "dba-123",
        "operation": "db-code-modernize-analysis",
        "claudeWorkspace": str(tmp_path).replace("\\", "/"),
        "prompt": str(prompt_file).replace("\\", "/"),
    }
    data.update(overrides)
    return ClaudeCliRequest(**data)


@pytest.fixture
def prompt_file(tmp_path):
    pf = tmp_path / "prompt.txt"
    pf.write_text("analyze db", encoding="utf-8")
    return pf


def build_handler(events):
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    pf = MagicMock()
    pf.get_provider = AsyncMock(return_value=provider)
    return DbModernizeAnalysisHandler(provider_factory=pf), provider


SUCCESS_EVENTS = [
    {"type": "assistant", "subtype": "text_delta", "text": 'done'},
    {"type": "result", "is_error": False},
]


def test_get_timeout():
    h, _ = build_handler([])
    assert h.get_timeout() == 3000


def test_get_output_directory(tmp_path, prompt_file):
    h, _ = build_handler([])
    assert h.get_output_directory(make_request(tmp_path, prompt_file)) == "db-code-modernize"


def test_validate_request_ok(tmp_path, prompt_file):
    h, _ = build_handler([])
    h.validate_request(make_request(tmp_path, prompt_file))


def test_validate_request_missing_prompt(tmp_path, prompt_file):
    h, _ = build_handler([])
    req = make_request(tmp_path, prompt_file)
    object.__setattr__(req, "prompt", None)
    with pytest.raises(ValidationError) as ei:
        h.validate_request(req)
    assert ei.value.field == "prompt"


async def test_execute_success(tmp_path, prompt_file):
    h, provider = build_handler(SUCCESS_EVENTS)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "success"
    out = h.build_output_path(make_request(tmp_path, prompt_file),
                              "db-code-modernize-analysis-stream.json")
    assert out.exists()
    provider.invoke_with_tools_agentic_graph.assert_awaited()


async def test_execute_error_stream(tmp_path, prompt_file):
    events = [{"type": "result", "is_error": True, "error": "dba failed"}]
    h, _ = build_handler(events)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "error"
    assert resp.error == "dba failed"


async def test_execute_reraises_on_failure(tmp_path, prompt_file):
    h, _ = build_handler(SUCCESS_EVENTS)
    prompt_file.unlink()
    with pytest.raises(Exception):
        await h.execute(make_request(tmp_path, prompt_file))
