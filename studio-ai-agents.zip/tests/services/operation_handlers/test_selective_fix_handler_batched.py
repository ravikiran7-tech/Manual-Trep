"""Tests for SelectiveFixHandler batched-by-rule execution path.

Covers _execute_batched, prompt-section parsing, balanced-JSON extraction,
blocker grouping, and per-rule prompt building — the parts of
selective_fix_handler.py not exercised by test_selective_fix_handler.py
(which focuses on the single-call path and post-transformation fixing).
"""
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import FileOperationError
from app.models.requests import ClaudeCliRequest
import app.services.operation_handlers.selective_fix_handler as mod
from app.services.operation_handlers.selective_fix_handler import SelectiveFixHandler


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=[])
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    return SelectiveFixHandler(provider_factory=factory), provider


def _req(**kw):
    base = dict(projectPath="/projects/app", analysisId="sel-batch-1",
                operation="selective-fix", prompt="/tmp/p.txt")
    base.update(kw)
    return ClaudeCliRequest(**base)


SEPARATOR = "IMPORTANT: Fix ONLY these specific blockers:"

BLOCKERS = [
    {
        "id": "b1", "ruleId": "cr-java-0113", "ruleName": "Lack of Externalized Secrets",
        "ruleDesc": "desc1", "category": "security", "severity": "high",
        "remediationName": "Externalize", "remediationDesc": "Use env vars",
        "filePath": "src/A.java", "beginLine": 10, "endLine": 12,
    },
    {
        "id": "b2", "ruleId": "cr-java-0113", "ruleName": "Lack of Externalized Secrets",
        "ruleDesc": "desc1", "category": "security", "severity": "high",
        "remediationName": "Externalize", "remediationDesc": "Use env vars",
        "filePath": "src/B.java", "beginLine": 5, "endLine": 6,
    },
    {
        "id": "b3", "ruleId": "cr-java-0200", "ruleName": "Hardcoded Path",
        "ruleDesc": "desc2", "category": "portability", "severity": "medium",
        "remediationName": "Externalize path", "remediationDesc": "Use config",
        "filePath": "src/C.java", "beginLine": 1, "endLine": 2,
    },
]


def _write_prompt_file(tmp_path, blockers=BLOCKERS, pre="SYSTEM PROMPT\nUSER PROMPT", post="Task :\ndo it\nresponse format\n{}"):
    import json as _json
    content = f"{pre}\n{SEPARATOR}\n{_json.dumps(blockers, indent=2)}\n{post}"
    p = tmp_path / "prompt.txt"
    p.write_text(content, encoding="utf-8")
    return str(p)


# ---------------------------------------------------------------------------
# _read_raw_prompt_file
# ---------------------------------------------------------------------------
def test_read_raw_prompt_file_ok(tmp_path):
    handler, _ = _make_handler()
    path = _write_prompt_file(tmp_path)
    content = handler._read_raw_prompt_file(path)
    assert SEPARATOR in content


def test_read_raw_prompt_file_missing(tmp_path):
    handler, _ = _make_handler()
    with pytest.raises(FileOperationError):
        handler._read_raw_prompt_file(str(tmp_path / "nope.txt"))


def test_read_raw_prompt_file_is_directory(tmp_path):
    handler, _ = _make_handler()
    with pytest.raises(FileOperationError):
        handler._read_raw_prompt_file(str(tmp_path))


# ---------------------------------------------------------------------------
# _parse_prompt_sections
# ---------------------------------------------------------------------------
def test_parse_prompt_sections_extracts_blockers_and_reassembles_base(tmp_path):
    handler, _ = _make_handler()
    raw = _write_prompt_file(tmp_path)
    content = handler._read_raw_prompt_file(raw)

    base_prompt, blockers_json = handler._parse_prompt_sections(content)

    assert "SYSTEM PROMPT" in base_prompt
    assert "Task :" in base_prompt
    assert SEPARATOR not in base_prompt
    assert '"ruleId": "cr-java-0113"' in blockers_json


def test_parse_prompt_sections_no_separator_falls_back(tmp_path):
    handler, _ = _make_handler()
    raw_text = "just a plain prompt with no separator"
    base_prompt, blockers_json = handler._parse_prompt_sections(raw_text)
    assert base_prompt == raw_text
    assert blockers_json == ""


def test_parse_prompt_sections_no_bracket_after_separator():
    handler, _ = _make_handler()
    raw_text = f"pre\n{SEPARATOR}\nno array here at all"
    base_prompt, blockers_json = handler._parse_prompt_sections(raw_text)
    assert blockers_json == ""
    assert base_prompt == raw_text.strip()


def test_parse_prompt_sections_unbalanced_json_falls_back():
    handler, _ = _make_handler()
    raw_text = f"pre\n{SEPARATOR}\n[{{\"a\": 1}}"  # missing closing bracket
    base_prompt, blockers_json = handler._parse_prompt_sections(raw_text)
    assert blockers_json == ""
    assert base_prompt == raw_text.strip()


def test_parse_prompt_sections_no_post_json_content():
    handler, _ = _make_handler()
    raw_text = f"pre section\n{SEPARATOR}\n[{{\"ruleId\": \"r1\"}}]"
    base_prompt, blockers_json = handler._parse_prompt_sections(raw_text)
    assert base_prompt == "pre section"
    assert '"ruleId": "r1"' in blockers_json


# ---------------------------------------------------------------------------
# _extract_balanced_json_block / _advance_json_state
# ---------------------------------------------------------------------------
def test_extract_balanced_json_block_simple():
    handler, _ = _make_handler()
    text = '[{"a": 1}] trailing'
    json_str, end = handler._extract_balanced_json_block(text, 0, "[", "]")
    assert json_str == '[{"a": 1}]'
    assert text[end:] == " trailing"


def test_extract_balanced_json_block_handles_nested_brackets_in_strings():
    handler, _ = _make_handler()
    text = '[{"a": "value with ] bracket"}] tail'
    json_str, end = handler._extract_balanced_json_block(text, 0, "[", "]")
    assert json_str == '[{"a": "value with ] bracket"}]'


def test_extract_balanced_json_block_handles_escaped_quotes():
    handler, _ = _make_handler()
    text = r'[{"a": "esc \" quote"}] rest'
    json_str, end = handler._extract_balanced_json_block(text, 0, "[", "]")
    assert json_str == r'[{"a": "esc \" quote"}]'


def test_extract_balanced_json_block_no_close_returns_empty():
    handler, _ = _make_handler()
    text = '[{"a": 1}'
    json_str, end = handler._extract_balanced_json_block(text, 0, "[", "]")
    assert json_str == ""
    assert end == len(text)


# ---------------------------------------------------------------------------
# _extract_blockers_json
# ---------------------------------------------------------------------------
def test_extract_blockers_json_empty_string_returns_empty_list():
    handler, _ = _make_handler()
    assert handler._extract_blockers_json("", "/tmp/p.txt") == []


def test_extract_blockers_json_valid_array():
    handler, _ = _make_handler()
    result = handler._extract_blockers_json('[{"ruleId": "r1"}]', "/tmp/p.txt")
    assert result == [{"ruleId": "r1"}]


def test_extract_blockers_json_non_array_returns_empty():
    handler, _ = _make_handler()
    result = handler._extract_blockers_json('{"ruleId": "r1"}', "/tmp/p.txt")
    assert result == []


def test_extract_blockers_json_invalid_json_raises():
    handler, _ = _make_handler()
    with pytest.raises(FileOperationError):
        handler._extract_blockers_json('[{invalid}]', "/tmp/p.txt")


# ---------------------------------------------------------------------------
# _group_blockers_by_rule
# ---------------------------------------------------------------------------
def test_group_blockers_by_rule():
    handler, _ = _make_handler()
    groups = handler._group_blockers_by_rule(BLOCKERS)

    assert set(groups.keys()) == {"cr-java-0113", "cr-java-0200"}
    assert len(groups["cr-java-0113"]["occurrences"]) == 2
    assert groups["cr-java-0113"]["occurrences"][0]["filePath"] == "src/A.java"
    assert groups["cr-java-0200"]["ruleName"] == "Hardcoded Path"


def test_group_blockers_by_rule_missing_rule_id_defaults_unknown():
    handler, _ = _make_handler()
    blockers = [{"id": "x", "filePath": "f.java"}]
    groups = handler._group_blockers_by_rule(blockers)
    assert "unknown" in groups
    assert groups["unknown"]["occurrences"][0]["filePath"] == "f.java"


# ---------------------------------------------------------------------------
# _build_rule_prompt
# ---------------------------------------------------------------------------
def test_build_rule_prompt_includes_rule_details_and_occurrences():
    handler, _ = _make_handler()
    groups = handler._group_blockers_by_rule(BLOCKERS)
    rule_data = groups["cr-java-0113"]
    request = _req()

    prompt = handler._build_rule_prompt("BASE PROMPT", "cr-java-0113", rule_data, request)

    assert "cr-java-0113" in prompt
    assert "Lack of Externalized Secrets" in prompt
    assert "src/A.java" in prompt
    assert "src/B.java" in prompt
    assert "BASE PROMPT" in prompt


# ---------------------------------------------------------------------------
# _execute_batched — full flow
# ---------------------------------------------------------------------------
async def _setup_batched(monkeypatch, tmp_path, per_rule_events=None):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.selective_fix, "batch_by_rule", True)
    handler, provider = _make_handler()

    prompt_path = _write_prompt_file(tmp_path)

    def fake_invoke_with_provider(**kwargs):
        prompt = kwargs["prompt"]
        if "cr-java-0113" in prompt:
            return per_rule_events.get("cr-java-0113", [{"type": "result", "is_error": False}])
        if "cr-java-0200" in prompt:
            return per_rule_events.get("cr-java-0200", [{"type": "result", "is_error": False}])
        return [{"type": "result", "is_error": False}]

    async def invoke_side_effect(**kwargs):
        return fake_invoke_with_provider(**kwargs)

    monkeypatch.setattr(handler, "invoke_with_provider", AsyncMock(side_effect=invoke_side_effect))
    monkeypatch.setattr(handler, "_run_post_transformation_fixes",
                        AsyncMock(side_effect=lambda req, prov, ev: ev + [
                            {"type": "final_build_status", "success": True, "remaining_errors": 0}
                        ]))
    return handler, provider, prompt_path


async def test_execute_batched_success_all_rules(monkeypatch, tmp_path):
    handler, provider, prompt_path = await _setup_batched(monkeypatch, tmp_path)
    resp = await handler.execute(_req(prompt=prompt_path))

    assert resp.status == "success"
    assert "2 rule" in resp.message or "rule(s) processed" in resp.message


async def test_execute_batched_partial_failure(monkeypatch, tmp_path):
    handler, provider, prompt_path = await _setup_batched(
        monkeypatch, tmp_path,
        per_rule_events={"cr-java-0200": None},
    )

    async def invoke_side_effect(**kwargs):
        prompt = kwargs["prompt"]
        if "cr-java-0200" in prompt:
            raise RuntimeError("rule call boom")
        return [{"type": "result", "is_error": False}]

    monkeypatch.setattr(handler, "invoke_with_provider", AsyncMock(side_effect=invoke_side_effect))

    resp = await handler.execute(_req(prompt=prompt_path))

    assert resp.status == "success"
    assert "partial success" in resp.message
    assert "cr-java-0200" in resp.message


async def test_execute_batched_all_rules_fail(monkeypatch, tmp_path):
    handler, provider, prompt_path = await _setup_batched(monkeypatch, tmp_path)

    async def invoke_side_effect(**kwargs):
        raise RuntimeError("all fail")

    monkeypatch.setattr(handler, "invoke_with_provider", AsyncMock(side_effect=invoke_side_effect))

    resp = await handler.execute(_req(prompt=prompt_path))

    assert resp.status == "error"
    assert "failed" in resp.error.lower()


async def test_execute_batched_no_blockers_falls_back_to_single(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.selective_fix, "batch_by_rule", True)
    handler, provider = _make_handler()

    prompt_path = tmp_path / "no_blockers.txt"
    prompt_path.write_text(f"pre\n{SEPARATOR}\nno array", encoding="utf-8")

    monkeypatch.setattr(handler, "read_prompt_file", lambda p, r=None: "PROMPT")
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=[
        {"type": "assistant", "subtype": "text_delta", "text": '```json\n{"fixed": true}\n```'},
        {"type": "result", "is_error": False},
    ])
    monkeypatch.setattr(handler, "_run_post_transformation_fixes",
                        AsyncMock(side_effect=lambda req, prov, ev: ev))

    resp = await handler.execute(_req(prompt=str(prompt_path)))

    assert resp.status == "success"


async def test_execute_batched_exception_reraised(monkeypatch, tmp_path):
    handler, provider, prompt_path = await _setup_batched(monkeypatch, tmp_path)
    monkeypatch.setattr(handler, "_group_blockers_by_rule",
                        MagicMock(side_effect=RuntimeError("grouping exploded")))

    with pytest.raises(RuntimeError, match="grouping exploded"):
        await handler.execute(_req(prompt=prompt_path))


async def test_execute_routes_to_batched_when_flag_enabled(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.selective_fix, "batch_by_rule", True)
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_execute_batched", AsyncMock(return_value="batched-result"))
    monkeypatch.setattr(handler, "_execute_single", AsyncMock(return_value="single-result"))

    result = await handler.execute(_req())

    assert result == "batched-result"
    handler._execute_batched.assert_awaited_once()
    handler._execute_single.assert_not_awaited()


async def test_execute_routes_to_single_when_flag_disabled(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.selective_fix, "batch_by_rule", False)
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_execute_batched", AsyncMock(return_value="batched-result"))
    monkeypatch.setattr(handler, "_execute_single", AsyncMock(return_value="single-result"))

    result = await handler.execute(_req())

    assert result == "single-result"
    handler._execute_single.assert_awaited_once()
    handler._execute_batched.assert_not_awaited()
