"""Tests for DotnetBuildHandler (dotnet-build-compilation operation)."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.operation_handlers.dotnet_build_handler import DotnetBuildHandler
from app.core.exceptions import ValidationError
from app.core import resilience as resilience_mod


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------
def _result_event(is_error=False, input_tokens=10, output_tokens=20):
    return {
        "type": "result",
        "is_error": is_error,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
    }


def _assistant_json_event(payload):
    text = "Here is the result:\n```json\n" + json.dumps(payload) + "\n```\n"
    return {"type": "assistant", "subtype": "text_delta", "text": text}


def _reset_all_breakers():
    for b in (
        resilience_mod.bedrock_circuit_breaker,
        resilience_mod.portkey_circuit_breaker,
        resilience_mod.compass_circuit_breaker,
    ):
        try:
            b.close()
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _reset_breaker(monkeypatch):
    _reset_all_breakers()
    # Zero out retry backoff so retried/failed operations don't really sleep.
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_min", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_max", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_multiplier", 0, raising=False)
    yield
    _reset_all_breakers()


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    """Point the shared settings workspace at tmp_path for all handler modules."""
    from app.services.operation_handlers import dotnet_build_handler as mod
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path), raising=False)
    return tmp_path


@pytest.fixture
def prompt_file(tmp_path):
    p = tmp_path / "prompt.txt"
    p.write_text("Build the project.", encoding="utf-8")
    # validate_path requires a recognised path format; use posix-style under tmp
    return str(p).replace("\\", "/")


def _make_handler(events=None, provider_side_effect=None):
    provider = MagicMock()
    invoke = AsyncMock()
    if provider_side_effect is not None:
        invoke.side_effect = provider_side_effect
    else:
        invoke.return_value = events if events is not None else []
    provider.invoke_with_tools_agentic_graph = invoke
    provider.invoke_with_tools_agentic = invoke

    factory = MagicMock()
    factory.get_provider = AsyncMock(return_value=provider)

    handler = DotnetBuildHandler(provider_factory=factory)
    return handler, provider, invoke


def _make_request(prompt, project_path="/projects/app", analysis_id="build-123",
                  dotnet_version=None):
    from app.models.requests import ClaudeCliRequest
    return ClaudeCliRequest(
        prompt=prompt,
        projectPath=project_path,
        analysisId=analysis_id,
        operation="dotnet-build-compilation",
        dotnetVersion=dotnet_version,
    )


# ---------------------------------------------------------------------------
# Simple unit-level methods
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, *_ = _make_handler()
    assert handler.get_timeout() == handler.settings.timeouts.build_validation


def test_get_output_directory():
    handler, *_ = _make_handler()
    req = _make_request("x")
    assert handler.get_output_directory(req) == "validation"


def test_enhance_prompt_with_dotnet_context():
    handler, *_ = _make_handler()
    out = handler._enhance_prompt_with_dotnet_context("ORIGINAL", "7.0")
    assert "7.0" in out
    assert out.endswith("ORIGINAL")


# ---------------------------------------------------------------------------
# validate_request branches
# ---------------------------------------------------------------------------
def test_validate_request_ok(prompt_file):
    handler, *_ = _make_handler()
    req = _make_request(prompt_file, dotnet_version="8.0")
    handler.validate_request(req)  # no raise


def test_validate_request_dotnet_10(prompt_file):
    handler, *_ = _make_handler()
    req = _make_request(prompt_file, dotnet_version="10.0")
    handler.validate_request(req)  # no raise


def test_validate_request_missing_prompt():
    handler, *_ = _make_handler()
    req = _make_request(None)
    with pytest.raises(ValidationError):
        handler.validate_request(req)


def test_validate_request_bad_dotnet_version(prompt_file):
    handler, *_ = _make_handler()
    req = _make_request(prompt_file, dotnet_version="5.0")
    with pytest.raises(ValidationError):
        handler.validate_request(req)


def test_validate_common_fields_missing_project(prompt_file):
    handler, *_ = _make_handler()
    from app.models.requests import ClaudeCliRequest
    req = ClaudeCliRequest(prompt=prompt_file, projectPath="/x", operation="dotnet-build-compilation")
    # Force empty project path post-construction to exercise the branch
    object.__setattr__(req, "project_path", "")
    with pytest.raises(ValidationError):
        handler.validate_request(req)


# ---------------------------------------------------------------------------
# _write_build_result_json
# ---------------------------------------------------------------------------
async def test_write_build_result_success(workspace):
    handler, *_ = _make_handler()
    reports = workspace / "reports"
    reports.mkdir(parents=True)
    comp = reports / "build-compilation.json"
    comp.write_text(json.dumps({
        "summary": {"buildStatus": "success", "issuesFailed": 2, "issuesSkipped": 1},
        "issues": [{"errorMessage": "err1"}, {"noMessage": True}],
        "failedIssues": [{"errorDetails": "detail"}, {"title": "t"}, None],
        "metadata": {"executionTimeMs": 125000},
    }), encoding="utf-8")

    path, status = await handler._write_build_result_json(comp, reports)
    assert status == "SUCCESS"
    data = json.loads(Path(path).read_text())
    assert data["success"] is True
    assert data["exitCode"] == 0
    assert "err1" in data["compilationErrors"]
    assert data["totalTime"] == "2m 5s"
    assert data["errors"] == 2
    assert data["warnings"] == 1


async def test_write_build_result_failed_seconds(workspace):
    handler, *_ = _make_handler()
    reports = workspace / "reports"
    reports.mkdir(parents=True)
    comp = reports / "build-compilation.json"
    comp.write_text(json.dumps({
        "summary": {"buildStatus": "failed"},
        "metadata": {"executionTimeMs": 5000},
    }), encoding="utf-8")
    path, status = await handler._write_build_result_json(comp, reports)
    assert status == "FAILED"
    data = json.loads(Path(path).read_text())
    assert data["success"] is False
    assert data["exitCode"] == 1
    assert data["totalTime"] == "5s"


async def test_write_build_result_zero_time(workspace):
    handler, *_ = _make_handler()
    reports = workspace / "reports"
    reports.mkdir(parents=True)
    comp = reports / "build-compilation.json"
    comp.write_text(json.dumps({"summary": {}, "metadata": {}}), encoding="utf-8")
    path, status = await handler._write_build_result_json(comp, reports)
    data = json.loads(Path(path).read_text())
    assert data["totalTime"] == "0s"
    assert status == "SUCCESS"


async def test_write_build_result_read_error(workspace):
    handler, *_ = _make_handler()
    reports = workspace / "reports"
    reports.mkdir(parents=True)
    missing = reports / "nope.json"
    path, status = await handler._write_build_result_json(missing, reports)
    assert path is None
    assert status == "SUCCESS"


# ---------------------------------------------------------------------------
# execute() happy path
# ---------------------------------------------------------------------------
async def test_execute_success(workspace, prompt_file):
    events = [
        _assistant_json_event({"summary": {"buildStatus": "success"}, "metadata": {"executionTimeMs": 1000}}),
        _result_event(is_error=False),
    ]
    handler, provider, invoke = _make_handler(events=events)
    req = _make_request(prompt_file, dotnet_version="8.0")

    resp = await handler.execute(req)

    assert resp.status == "success"
    assert resp.exit_code == 0
    assert resp.summary["buildStatus"] == "SUCCESS"
    invoke.assert_awaited()
    # build-result.json should exist
    assert Path(resp.output_file_path).name == "build-result.json"


async def test_execute_partial_status(workspace, prompt_file):
    events = [
        _assistant_json_event({"summary": {"buildStatus": "partial"}, "metadata": {}}),
        _result_event(is_error=False),
    ]
    handler, *_ = _make_handler(events=events)
    req = _make_request(prompt_file)
    resp = await handler.execute(req)
    assert resp.status == "partial"
    assert resp.summary["buildStatus"] == "PARTIAL"


async def test_execute_default_version_no_json(workspace, prompt_file):
    """No JSON block -> compilation_path None -> falls back to output_path."""
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "no json here"},
        _result_event(is_error=False),
    ]
    handler, *_ = _make_handler(events=events)
    req = _make_request(prompt_file)  # dotnet_version None -> defaults 8.0
    resp = await handler.execute(req)
    assert resp.status == "success"
    assert resp.output_file_path.endswith("build-compilation-stream.json")


async def test_execute_stream_error(workspace, prompt_file):
    events = [
        _assistant_json_event({"summary": {"buildStatus": "failed"}, "metadata": {}}),
        {"type": "error", "error": "boom"},
        _result_event(is_error=True),
    ]
    handler, *_ = _make_handler(events=events)
    req = _make_request(prompt_file)
    resp = await handler.execute(req)
    assert resp.status == "error"
    assert resp.summary["buildStatus"] == "FAILED"
    assert "boom" in resp.message


async def test_execute_validation_raises(workspace):
    handler, *_ = _make_handler(events=[])
    req = _make_request(None)  # missing prompt
    with pytest.raises(ValidationError):
        await handler.execute(req)


async def test_execute_provider_failure_propagates(workspace, prompt_file):
    handler, provider, invoke = _make_handler(
        provider_side_effect=RuntimeError("provider down")
    )
    req = _make_request(prompt_file)
    with pytest.raises(RuntimeError):
        await handler.execute(req)