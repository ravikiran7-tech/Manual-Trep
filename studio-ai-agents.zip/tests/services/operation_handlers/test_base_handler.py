"""
Tests for BaseOperationHandler.

Covers: output-dir mapping, output-path building, stream writing,
streaming context manager, prompt reading/enhancement, result extraction,
success/error responses, invoke_with_provider (graph + legacy + streaming),
common-field validation and extract_and_write_json_result.
"""
import json
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock

import pytest

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.exceptions import ValidationError, FileOperationError
import app.services.operation_handlers.base_handler as base_mod


# ---------------------------------------------------------------------------
# A concrete subclass so we can instantiate the abstract base.
# ---------------------------------------------------------------------------
class _ConcreteHandler(BaseOperationHandler):
    async def execute(self, request):  # pragma: no cover - not exercised
        return ClaudeCliResponse(status="success", message="ok")

    def get_timeout(self) -> int:
        return 123

    def validate_request(self, request):
        self.validate_common_fields(request)


def make_request(tmp_path, **overrides):
    data = {
        "projectPath": str(tmp_path).replace("\\", "/"),
        "analysisId": "analysis-123",
        "operation": "analysis",
        "prompt": "some-prompt",
    }
    data.update(overrides)
    return ClaudeCliRequest(**data)


@pytest.fixture
def handler():
    return _ConcreteHandler(provider_factory=MagicMock())


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------
def test_init_uses_provided_factory():
    pf = MagicMock()
    h = _ConcreteHandler(provider_factory=pf)
    assert h.provider_factory is pf
    assert h.settings is not None


def test_init_defaults_to_global_factory(monkeypatch):
    sentinel = MagicMock()
    monkeypatch.setattr(base_mod, "get_provider_factory", lambda: sentinel)
    h = _ConcreteHandler()
    assert h.provider_factory is sentinel


# ---------------------------------------------------------------------------
# get_output_directory - every branch
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("operation,expected", [
    ("analysis", "versionUpgrade"),
    ("fix-upgrade", "versionUpgrade"),
    ("build-compilation", "validation"),
    ("test-execution", "validation"),
    ("test-creation", "validation"),
    ("cloudreadiness-analysis", "cloudreadiness"),
    ("cloudreadiness-fix", "cloudreadiness"),
    ("db-code-modernize-analysis", "db-code-modernize"),
    ("db-code-modernize-fix", "db-code-modernize"),
    ("schema-modernization", "schema-modernization"),
    ("dotnet-build-compilation", "dotnet-validation"),
    ("dotnet-test-execution", "dotnet-validation"),
    ("test-executionBuild", "containerization"),
    ("containerization-analysis", "containerization"),
    ("selective-fix", "containerization"),
    ("generation", "containerization"),
    ("summary", "containerization"),
])
def test_get_output_directory(handler, tmp_path, operation, expected):
    req = make_request(tmp_path, operation=operation)
    assert handler.get_output_directory(req) == expected


def test_get_output_directory_unknown_default(handler, tmp_path, monkeypatch):
    # Bypass pydantic validation by faking a request-like object.
    fake = MagicMock()
    fake.operation = "totally-unknown-op"
    assert handler.get_output_directory(fake) == "containerization"


def test_get_output_directory_lowercase_test_executionbuild(handler):
    # The literal lowercase "test-executionbuild" branch (not a valid enum value,
    # so must be exercised via a request-like stub).
    fake = MagicMock()
    fake.operation = "test-executionbuild"
    assert handler.get_output_directory(fake) == "validation"


# ---------------------------------------------------------------------------
# build_output_path
# ---------------------------------------------------------------------------
def test_build_output_path_with_claude_workspace(handler, tmp_path):
    ws = tmp_path / "ws"
    req = make_request(tmp_path, claudeWorkspace=str(ws).replace("\\", "/"))
    p = handler.build_output_path(req, "stream.json")
    assert p.name == "stream.json"
    assert "versionUpgrade" in str(p)
    assert "analysis-123" in str(p)
    assert p.parent.exists()


def test_build_output_path_default_workspace(handler, tmp_path, monkeypatch):
    monkeypatch.setattr(base_mod.settings.workspace, "base_path", str(tmp_path))
    req = make_request(tmp_path, claudeWorkspace=None)
    p = handler.build_output_path(req)
    assert p.name == "stream.json"
    assert str(tmp_path) in str(p)


def test_build_output_path_default_analysis_id(handler, tmp_path):
    req = make_request(tmp_path, analysisId=None,
                       claudeWorkspace=str(tmp_path).replace("\\", "/"))
    p = handler.build_output_path(req)
    assert "default" in str(p)


# ---------------------------------------------------------------------------
# write_stream_output
# ---------------------------------------------------------------------------
async def test_write_stream_output_success(handler, tmp_path):
    out = tmp_path / "sub" / "stream.json"
    events = [{"type": "result", "is_error": False}]
    await handler.write_stream_output(out, events)
    assert json.loads(out.read_text()) == events


async def test_write_stream_output_failure_raises(handler, tmp_path, monkeypatch):
    out = tmp_path / "stream.json"

    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(base_mod.json, "dump", boom)
    with pytest.raises(FileOperationError):
        await handler.write_stream_output(out, [{"a": 1}])


# ---------------------------------------------------------------------------
# stream_output_streaming context manager
# ---------------------------------------------------------------------------
async def test_stream_output_streaming_with_events(handler, tmp_path):
    out = tmp_path / "live.json"
    async with handler.stream_output_streaming(out) as on_event:
        on_event({"a": 1})
        on_event({"b": 2})
    text = out.read_text(encoding="utf-8")
    assert text.startswith("[")
    assert text.rstrip().endswith("]")
    # Parseable as JSON array of two events
    assert json.loads(text) == [{"a": 1}, {"b": 2}]


async def test_stream_output_streaming_no_events(handler, tmp_path):
    out = tmp_path / "empty.json"
    async with handler.stream_output_streaming(out) as on_event:
        pass
    assert out.read_text(encoding="utf-8").strip() == "[]"


async def test_stream_output_streaming_event_write_failure_swallowed(handler, tmp_path, monkeypatch):
    out = tmp_path / "live.json"

    real_open = open
    calls = {"n": 0}

    def flaky_open(path, mode="r", *a, **k):
        # Allow the truncate write; fail the append inside on_event.
        if mode == "a":
            calls["n"] += 1
            if calls["n"] == 1:
                raise OSError("locked")
        return real_open(path, mode, *a, **k)

    monkeypatch.setattr("builtins.open", flaky_open)
    async with handler.stream_output_streaming(out) as on_event:
        on_event({"a": 1})  # first append fails -> warning swallowed, first stays True
    # Since first append failed, 'first' stayed True -> file gets "[]"
    assert "[]" in out.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# collect_stream
# ---------------------------------------------------------------------------
async def test_collect_stream_returns_input(handler):
    events = [{"x": 1}]
    assert await handler.collect_stream(events) is events


# ---------------------------------------------------------------------------
# validate_common_fields
# ---------------------------------------------------------------------------
def test_validate_common_fields_ok(handler, tmp_path):
    handler.validate_common_fields(make_request(tmp_path))


def test_validate_common_fields_no_analysis_id(handler, tmp_path):
    # analysis_id is None -> skips the alphanumeric validation branch (317->exit).
    req = make_request(tmp_path, analysisId=None)
    handler.validate_common_fields(req)


def test_validate_common_fields_missing_project_path(handler, tmp_path):
    req = make_request(tmp_path)
    # Force empty project_path post-construction.
    object.__setattr__(req, "project_path", "")
    with pytest.raises(ValidationError) as ei:
        handler.validate_common_fields(req)
    assert ei.value.field == "projectPath"


def test_validate_common_fields_bad_project_path(handler, tmp_path):
    req = make_request(tmp_path)
    object.__setattr__(req, "project_path", "/bad;path")
    with pytest.raises(ValidationError) as ei:
        handler.validate_common_fields(req)
    assert ei.value.field == "projectPath"


def test_validate_common_fields_bad_analysis_id(handler, tmp_path):
    req = make_request(tmp_path)
    object.__setattr__(req, "analysis_id", "bad id!")
    with pytest.raises(ValidationError) as ei:
        handler.validate_common_fields(req)
    assert ei.value.field == "analysisId"


# ---------------------------------------------------------------------------
# _enhance_prompt_with_json_output_requirement
# ---------------------------------------------------------------------------
def test_enhance_prompt(handler):
    out = handler._enhance_prompt_with_json_output_requirement("hello", "analysis")
    assert "CRITICAL SYSTEM REQUIREMENTS" in out
    assert out.endswith("hello")


# ---------------------------------------------------------------------------
# read_prompt_file
# ---------------------------------------------------------------------------
def test_read_prompt_file_success(handler, tmp_path):
    pf = tmp_path / "prompt.txt"
    pf.write_text("do the thing", encoding="utf-8")
    req = make_request(tmp_path)
    out = handler.read_prompt_file(str(pf).replace("\\", "/"), req)
    assert "do the thing" in out
    assert "CRITICAL SYSTEM REQUIREMENTS" in out


def test_read_prompt_file_no_request(handler, tmp_path):
    pf = tmp_path / "prompt.txt"
    pf.write_text("content", encoding="utf-8")
    out = handler.read_prompt_file(str(pf).replace("\\", "/"))
    assert "content" in out


def test_read_prompt_file_not_found(handler, tmp_path):
    missing = str(tmp_path / "nope.txt").replace("\\", "/")
    with pytest.raises(FileOperationError):
        handler.read_prompt_file(missing)


def test_read_prompt_file_dangerous_path(handler):
    with pytest.raises(ValidationError) as ei:
        handler.read_prompt_file("/bad;path.txt")
    assert ei.value.field == "prompt"


def test_read_prompt_file_directory_is_not_file(handler, tmp_path):
    d = tmp_path / "adir"
    d.mkdir()
    with pytest.raises(ValidationError) as ei:
        handler.read_prompt_file(str(d).replace("\\", "/"))
    assert ei.value.field == "prompt"


def test_read_prompt_file_generic_exception(handler, tmp_path, monkeypatch):
    pf = tmp_path / "prompt.txt"
    pf.write_text("x", encoding="utf-8")

    def boom(*a, **k):
        raise RuntimeError("kaboom")

    monkeypatch.setattr("builtins.open", boom)
    with pytest.raises(FileOperationError):
        handler.read_prompt_file(str(pf).replace("\\", "/"))


# ---------------------------------------------------------------------------
# extract_result_from_stream / is_stream_successful / get_error_from_stream
# ---------------------------------------------------------------------------
def test_extract_result_from_stream_found(handler):
    events = [{"type": "assistant"}, {"type": "result", "is_error": False}]
    assert handler.extract_result_from_stream(events)["type"] == "result"


def test_extract_result_from_stream_none(handler):
    assert handler.extract_result_from_stream([{"type": "assistant"}]) is None


def test_is_stream_successful_true(handler):
    assert handler.is_stream_successful([{"type": "result", "is_error": False}]) is True


def test_is_stream_successful_false_on_error(handler):
    assert handler.is_stream_successful([{"type": "result", "is_error": True}]) is False


def test_is_stream_successful_false_no_result(handler):
    assert handler.is_stream_successful([{"type": "assistant"}]) is False


def test_get_error_from_stream_error_event(handler):
    assert handler.get_error_from_stream([{"type": "error", "error": "boom"}]) == "boom"


def test_get_error_from_stream_error_event_default(handler):
    assert handler.get_error_from_stream([{"type": "error"}]) == "Unknown error"


def test_get_error_from_stream_result_is_error(handler):
    events = [{"type": "result", "is_error": True, "error": "failed-here"}]
    assert handler.get_error_from_stream(events) == "failed-here"


def test_get_error_from_stream_result_is_error_default(handler):
    events = [{"type": "result", "is_error": True}]
    assert handler.get_error_from_stream(events) == "Operation failed"


def test_get_error_from_stream_none(handler):
    assert handler.get_error_from_stream([{"type": "result", "is_error": False}]) is None


# ---------------------------------------------------------------------------
# build_success_response / build_error_response
# ---------------------------------------------------------------------------
def test_build_success_response_with_tokens(handler, tmp_path):
    out = tmp_path / "s.json"
    events = [{"type": "result", "is_error": False, "input_tokens": 5, "output_tokens": 9}]
    resp = handler.build_success_response(out, events, "done")
    assert resp.status == "success"
    assert resp.message == "done"
    assert resp.exit_code == 0
    assert resp.output_file_path == str(out)


def test_build_success_response_no_result(handler, tmp_path):
    out = tmp_path / "s.json"
    resp = handler.build_success_response(out, [{"type": "assistant"}])
    assert resp.status == "success"
    assert resp.output == str(out)


def test_build_error_response_with_path(handler, tmp_path):
    out = tmp_path / "s.json"
    resp = handler.build_error_response("oops", [{"type": "error"}], out)
    assert resp.status == "error"
    assert resp.exit_code == 1
    assert resp.error == "oops"
    assert resp.output_file_path == str(out)


def test_build_error_response_no_path(handler):
    resp = handler.build_error_response("oops")
    assert resp.output_file_path == ""


# ---------------------------------------------------------------------------
# invoke_with_provider
# ---------------------------------------------------------------------------
def _async_returning(events):
    m = AsyncMock(return_value=events)
    return m


async def test_invoke_with_provider_graph_no_stream(handler, monkeypatch):
    monkeypatch.setattr(base_mod.settings.agentic, "graph_orchestration_enabled", True)
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = _async_returning([{"type": "result"}])
    out = await handler.invoke_with_provider(
        provider, "p", "/proj", max_tokens=10, temperature=0.0, enable_tools=True
    )
    assert out == [{"type": "result"}]
    provider.invoke_with_tools_agentic_graph.assert_awaited_once()


async def test_invoke_with_provider_legacy_no_stream(handler, monkeypatch):
    monkeypatch.setattr(base_mod.settings.agentic, "graph_orchestration_enabled", False)
    provider = MagicMock()
    provider.invoke_with_tools_agentic = _async_returning([{"type": "result"}])
    out = await handler.invoke_with_provider(provider, "p", "/proj")
    assert out == [{"type": "result"}]
    provider.invoke_with_tools_agentic.assert_awaited_once()


async def test_invoke_with_provider_graph_streaming(handler, tmp_path, monkeypatch):
    monkeypatch.setattr(base_mod.settings.agentic, "graph_orchestration_enabled", True)
    out_path = tmp_path / "stream.json"
    provider = MagicMock()

    async def fake(**kwargs):
        kwargs["on_event"]({"type": "assistant"})
        return [{"type": "result"}]

    provider.invoke_with_tools_agentic_graph = AsyncMock(side_effect=fake)
    out = await handler.invoke_with_provider(
        provider, "p", "/proj", stream_output_path=out_path
    )
    assert out == [{"type": "result"}]
    assert out_path.exists()


async def test_invoke_with_provider_legacy_streaming(handler, tmp_path, monkeypatch):
    monkeypatch.setattr(base_mod.settings.agentic, "graph_orchestration_enabled", False)
    out_path = tmp_path / "stream.json"
    provider = MagicMock()

    async def fake(**kwargs):
        kwargs["on_event"]({"type": "assistant"})
        return [{"type": "result"}]

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=fake)
    out = await handler.invoke_with_provider(
        provider, "p", "/proj", stream_output_path=out_path
    )
    assert out == [{"type": "result"}]
    assert out_path.exists()


# ---------------------------------------------------------------------------
# extract_and_write_json_result
# ---------------------------------------------------------------------------
def _assistant_text(text):
    return {"type": "assistant", "subtype": "text_delta", "text": text}


async def test_extract_and_write_json_result_success(handler, tmp_path):
    events = [_assistant_text('Here is the result:\n```json\n{"a": 1}\n```')]
    p = await handler.extract_and_write_json_result(events, tmp_path, "result.json")
    assert p is not None
    assert json.loads(p.read_text()) == {"a": 1}


async def test_extract_and_write_json_result_no_response(handler, tmp_path):
    p = await handler.extract_and_write_json_result([{"type": "result"}], tmp_path)
    assert p is None


async def test_extract_and_write_json_result_no_json_blocks(handler, tmp_path):
    events = [_assistant_text("just plain text, no json blocks")]
    p = await handler.extract_and_write_json_result(events, tmp_path)
    assert p is None


async def test_extract_and_write_json_result_invalid_json(handler, tmp_path, monkeypatch):
    # Force extract_json_blocks to yield an unparseable block.
    from app.utils import stream_utils
    monkeypatch.setattr(
        stream_utils.StreamParser, "extract_json_blocks",
        staticmethod(lambda text: ["{not valid json}"]),
    )
    events = [_assistant_text("```json\n{bad}\n```")]
    p = await handler.extract_and_write_json_result(events, tmp_path)
    assert p is None


async def test_extract_and_write_json_result_exception(handler, tmp_path, monkeypatch):
    from app.utils import stream_utils

    def boom(events):
        raise RuntimeError("parse fail")

    monkeypatch.setattr(
        stream_utils.StreamParser, "extract_full_assistant_response",
        staticmethod(boom),
    )
    p = await handler.extract_and_write_json_result([_assistant_text("x")], tmp_path)
    assert p is None
