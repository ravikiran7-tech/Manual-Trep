"""Tests for BuildCompilationHandler."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import ValidationError
from app.models.requests import ClaudeCliRequest
import app.services.operation_handlers.build_compilation_handler as mod
from app.services.operation_handlers.build_compilation_handler import BuildCompilationHandler


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=[])
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    return BuildCompilationHandler(provider_factory=factory), provider


def _req(**kw):
    base = dict(
        projectPath="/projects/app", analysisId="build-1",
        operation="build-compilation", javaVersion="17", prompt="/tmp/p.txt",
    )
    base.update(kw)
    return ClaudeCliRequest(**base)


# ---------------------------------------------------------------------------
# basic
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, _ = _make_handler()
    assert handler.get_timeout() == mod.settings.timeouts.build_validation


def test_get_output_directory():
    handler, _ = _make_handler()
    assert handler.get_output_directory(_req()) == "validation"


def test_init_sets_sdkman_script():
    handler, _ = _make_handler()
    assert handler.sdkman_init_script.name == "sdkman-init.sh"


# ---------------------------------------------------------------------------
# validate_request
# ---------------------------------------------------------------------------
def test_validate_request_missing_prompt():
    handler, _ = _make_handler()
    req = _req(prompt=None)
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "prompt"


def test_validate_request_missing_java_version():
    handler, _ = _make_handler()
    req = _req(javaVersion=None)
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "javaVersion"


def test_validate_request_unsupported_java_version():
    handler, _ = _make_handler()
    req = _req(javaVersion="99")
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert "Unsupported" in ei.value.message


def test_validate_request_ok():
    handler, _ = _make_handler()
    handler.validate_request(_req())


# ---------------------------------------------------------------------------
# _verify_java_version_installed
# ---------------------------------------------------------------------------
def test_verify_java_version_not_installed(monkeypatch):
    handler, _ = _make_handler()
    monkeypatch.setattr(mod.Path, "exists", lambda self: False)
    with pytest.raises(ValidationError):
        handler._verify_java_version_installed("17.0.13-tem")


def test_verify_java_version_installed(monkeypatch):
    handler, _ = _make_handler()
    monkeypatch.setattr(mod.Path, "exists", lambda self: True)
    handler._verify_java_version_installed("17.0.13-tem")  # no raise


# ---------------------------------------------------------------------------
# _enhance_prompt_with_java_context
# ---------------------------------------------------------------------------
def test_enhance_prompt():
    handler, _ = _make_handler()
    out = handler._enhance_prompt_with_java_context("BODY", "17", "17.0.13-tem")
    assert "sdk use java 17.0.13-tem" in out
    assert out.endswith("BODY")


# ---------------------------------------------------------------------------
# _write_build_result_json
# ---------------------------------------------------------------------------
async def test_write_build_result_success(tmp_path):
    handler, _ = _make_handler()
    comp = tmp_path / "build-compilation.json"
    comp.write_text(json.dumps({
        "summary": {"buildStatus": "success", "issuesFailed": 2, "issuesSkipped": 1},
        "issues": [{"errorMessage": "E1"}, {"title": "no errmsg"}],
        "failedIssues": [{"errorDetails": "FD"}, {"title": "T"}, None],
        "metadata": {"executionTimeMs": 125000},
    }))
    path, status = await handler._write_build_result_json(comp, tmp_path)
    assert status == "SUCCESS"
    data = json.loads(path.read_text())
    assert data["success"] is True
    assert data["exitCode"] == 0
    assert "E1" in data["compilationErrors"]
    assert "FD" in data["compilationErrors"]
    assert data["totalTime"] == "2m 5s"


async def test_write_build_result_failed_status_seconds(tmp_path):
    handler, _ = _make_handler()
    comp = tmp_path / "c.json"
    comp.write_text(json.dumps({
        "summary": {"buildStatus": "failed"},
        "metadata": {"executionTimeMs": 5000},
    }))
    path, status = await handler._write_build_result_json(comp, tmp_path)
    assert status == "FAILED"
    data = json.loads(path.read_text())
    assert data["success"] is False
    assert data["exitCode"] == 1
    assert data["totalTime"] == "5s"


async def test_write_build_result_zero_time(tmp_path):
    handler, _ = _make_handler()
    comp = tmp_path / "c.json"
    comp.write_text(json.dumps({"summary": {"buildStatus": "SUCCESS"}, "metadata": {}}))
    path, status = await handler._write_build_result_json(comp, tmp_path)
    data = json.loads(path.read_text())
    assert data["totalTime"] == "0s"


async def test_write_build_result_read_error(tmp_path):
    handler, _ = _make_handler()
    missing = tmp_path / "does-not-exist.json"
    path, status = await handler._write_build_result_json(missing, tmp_path)
    assert path is None
    assert status == "SUCCESS"


# ---------------------------------------------------------------------------
# execute
# ---------------------------------------------------------------------------
def _ok_events(text='```json\n{"summary": {"buildStatus": "SUCCESS"}}\n```'):
    return [
        {"type": "assistant", "subtype": "text_delta", "text": text},
        {"type": "result", "is_error": False, "input_tokens": 5, "output_tokens": 6},
    ]


async def _setup_execute(monkeypatch, tmp_path, events, graph=True):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.agentic, "graph_orchestration_enabled", graph)
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_verify_java_version_installed", lambda v: None)
    monkeypatch.setattr(handler, "read_prompt_file", lambda p, r=None: "PROMPT BODY")
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    return handler, provider


async def test_execute_success_graph(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events(), graph=True)
    resp = await handler.execute(_req())
    assert resp.status == "success"
    assert resp.summary["buildStatus"] == "SUCCESS"
    provider.invoke_with_tools_agentic_graph.assert_awaited()


async def test_execute_success_legacy_path(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events(), graph=False)
    resp = await handler.execute(_req())
    assert resp.status == "success"
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_execute_partial_status(monkeypatch, tmp_path):
    events = _ok_events('```json\n{"summary": {"buildStatus": "PARTIAL"}}\n```')
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "partial"
    assert resp.summary["buildStatus"] == "PARTIAL"


async def test_execute_no_json_extracted(monkeypatch, tmp_path):
    # assistant text has no json block -> compilation_path None
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "no json here"},
        {"type": "result", "is_error": False, "input_tokens": 1, "output_tokens": 1},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "success"
    # build_result_path None -> falls back to output_path (stream)
    assert resp.output_file_path.endswith("build-compilation-stream.json")


async def test_execute_stream_error(monkeypatch, tmp_path):
    events = [
        {"type": "assistant", "subtype": "text_delta",
         "text": '```json\n{"summary": {"buildStatus": "SUCCESS"}}\n```'},
        {"type": "result", "is_error": True, "error": "build broke"},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.summary["buildStatus"] == "FAILED"
    assert resp.message == "build broke"


async def test_execute_stream_error_default_message(monkeypatch, tmp_path):
    # is_error True but no error message and no error event
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "x"},
        {"type": "result", "is_error": True},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.message == "Operation failed"


async def test_execute_reraises_validation(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    with pytest.raises(ValidationError):
        await handler.execute(_req(javaVersion=None))


async def test_execute_reraises_inner_exception(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events())
    provider.invoke_with_tools_agentic_graph = AsyncMock(side_effect=RuntimeError("kaboom"))
    with pytest.raises(RuntimeError):
        await handler.execute(_req())
