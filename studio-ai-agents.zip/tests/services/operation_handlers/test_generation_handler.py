"""Tests for GenerationHandler."""
import json
from unittest.mock import MagicMock, AsyncMock

import pytest

from app.services.operation_handlers.generation_handler import GenerationHandler
from app.models.requests import ClaudeCliRequest
from app.core.exceptions import ValidationError


def make_request(tmp_path, prompt_file, **overrides):
    data = {
        "projectPath": str(tmp_path).replace("\\", "/"),
        "analysisId": "gen-123",
        "operation": "generation",
        "claudeWorkspace": str(tmp_path).replace("\\", "/"),
        "prompt": str(prompt_file).replace("\\", "/"),
    }
    data.update(overrides)
    return ClaudeCliRequest(**data)


@pytest.fixture
def prompt_file(tmp_path):
    pf = tmp_path / "prompt.txt"
    pf.write_text("generate artifacts", encoding="utf-8")
    return pf


def build_handler(events):
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    pf = MagicMock()
    pf.get_provider = AsyncMock(return_value=provider)
    return GenerationHandler(provider_factory=pf), provider


SUCCESS_EVENTS = [
    {"type": "assistant", "subtype": "text_delta",
     "text": '```json\n{"files": []}\n```'},
    {"type": "result", "is_error": False},
]


def test_get_timeout():
    h, _ = build_handler([])
    assert h.get_timeout() == 3000


def test_get_output_directory(tmp_path, prompt_file):
    h, _ = build_handler([])
    assert h.get_output_directory(make_request(tmp_path, prompt_file)) == "containerization"


def test_validate_request_ok(tmp_path, prompt_file):
    h, _ = build_handler([])
    h.validate_request(make_request(tmp_path, prompt_file))


def test_validate_request_missing_prompt(tmp_path, prompt_file):
    h, _ = build_handler([])
    req = make_request(tmp_path, prompt_file)
    object.__setattr__(req, "prompt", None)
    with pytest.raises(ValidationError) as ei:
        h.validate_request(req)
    assert ei.value.field == "prompt"


async def test_execute_success(tmp_path, prompt_file):
    h, provider = build_handler(SUCCESS_EVENTS)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "success"
    out = h.build_output_path(make_request(tmp_path, prompt_file), "generation-stream.json")
    assert out.exists()
    assert (out.parent / "generation-result.json").exists()
    provider.invoke_with_tools_agentic_graph.assert_awaited()


async def test_execute_error_stream(tmp_path, prompt_file):
    events = [{"type": "result", "is_error": True, "error": "gen failed"}]
    h, _ = build_handler(events)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "error"
    assert resp.error == "gen failed"


async def test_execute_no_json_result(tmp_path, prompt_file):
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "plain"},
        {"type": "result", "is_error": False},
    ]
    h, _ = build_handler(events)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "success"


async def test_execute_reraises_on_failure(tmp_path, prompt_file):
    h, _ = build_handler(SUCCESS_EVENTS)
    prompt_file.unlink()
    with pytest.raises(Exception):
        await h.execute(make_request(tmp_path, prompt_file))