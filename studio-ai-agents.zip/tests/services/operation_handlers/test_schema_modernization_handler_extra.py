"""Additional tests for SchemaModernizationHandler (complements existing SQL-extract test)."""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import FileOperationError, ValidationError
from app.models.requests import SchemaModernizationRequest
import app.services.operation_handlers.schema_modernization_handler as mod
from app.services.operation_handlers.schema_modernization_handler import (
    SchemaModernizationHandler,
)


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    return SchemaModernizationHandler(provider_factory=factory), provider


def _req(**kw):
    base = dict(analysisId="schema-1", sourceDbType="Oracle", targetDbType="PostgreSQL")
    base.update(kw)
    return SchemaModernizationRequest(**base)


def _events(text='```sql\nCREATE TABLE t(id int);\n```'):
    return [
        {"type": "assistant", "subtype": "text_delta", "text": text},
        {"type": "result", "is_error": False, "input_tokens": 1, "output_tokens": 2},
    ]


# ---------------------------------------------------------------------------
# get_timeout
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, _ = _make_handler()
    assert handler.get_timeout() == mod.settings.timeouts.schema_modernization


# ---------------------------------------------------------------------------
# validate_request
# ---------------------------------------------------------------------------
def test_validate_missing_analysis_id():
    handler, _ = _make_handler()
    req = _req(prompt="x")
    req.analysis_id = ""
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "analysisId"


def test_validate_bad_analysis_id():
    handler, _ = _make_handler()
    req = _req(prompt="x")
    req.analysis_id = "bad;id"
    with pytest.raises(ValueError):
        handler.validate_request(req)


def test_validate_missing_source_db():
    handler, _ = _make_handler()
    req = _req(prompt="x")
    req.source_db_type = ""
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "sourceDbType"


def test_validate_missing_target_db():
    handler, _ = _make_handler()
    req = _req(prompt="x")
    req.target_db_type = ""
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "targetDbType"


def test_validate_missing_both_source_and_prompt():
    handler, _ = _make_handler()
    req = _req()  # no prompt, no source_schema_path
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(req)
    assert ei.value.field == "sourceSchemaPath"


def test_validate_with_source_schema_path():
    handler, _ = _make_handler()
    req = _req(sourceSchemaPath="/data/schema.sql")
    handler.validate_request(req)  # no raise


def test_validate_with_prompt_ok():
    handler, _ = _make_handler()
    handler.validate_request(_req(prompt="schema content"))


# ---------------------------------------------------------------------------
# _build_file_access_prompt
# ---------------------------------------------------------------------------
def test_build_file_access_prompt(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    req = _req(sourceSchemaPath="/data/oracle_schema.sql")
    prompt = handler._build_file_access_prompt(req)
    assert "oracle_schema.sql" in prompt
    assert "Oracle to PostgreSQL" in prompt
    assert "schema-modernization-sql.sql" in prompt


# ---------------------------------------------------------------------------
# _write_sql_output
# ---------------------------------------------------------------------------
def test_write_sql_output(tmp_path):
    handler, _ = _make_handler()
    out = tmp_path / "sub" / "out.sql"
    handler._write_sql_output(out, "SELECT 1;")
    assert out.read_text() == "SELECT 1;"


def test_write_sql_output_error(monkeypatch, tmp_path):
    handler, _ = _make_handler()
    out = tmp_path / "out.sql"

    def boom(*a, **k):
        raise OSError("disk full")
    monkeypatch.setattr("builtins.open", boom)
    with pytest.raises(FileOperationError):
        handler._write_sql_output(out, "x")


# ---------------------------------------------------------------------------
# _extract_sql_from_stream extra branches
# ---------------------------------------------------------------------------
def test_extract_sql_no_response_returns_none(tmp_path):
    handler, _ = _make_handler()
    out = handler._extract_sql_from_stream([], sql_output_file=tmp_path / "x.sql")
    assert out is None


def test_extract_sql_no_matches_returns_none(tmp_path):
    handler, _ = _make_handler()
    stream = [{"type": "assistant", "subtype": "text_delta", "text": "no sql here"}]
    out = handler._extract_sql_from_stream(stream, sql_output_file=tmp_path / "x.sql")
    assert out is None


def test_extract_sql_file_read_oserror(monkeypatch, tmp_path):
    handler, _ = _make_handler()
    sql_file = tmp_path / "out.sql"
    sql_file.write_text("CONTENT")

    orig_read = Path.read_text

    def fake_read(self, *a, **k):
        if self == sql_file:
            raise OSError("locked")
        return orig_read(self, *a, **k)
    monkeypatch.setattr(Path, "read_text", fake_read)
    # falls through to assistant text sql fence
    stream = [{"type": "assistant", "subtype": "text_delta",
               "text": "```sql\nSELECT 2;\n```"}]
    out = handler._extract_sql_from_stream(stream, sql_output_file=sql_file)
    assert out == "SELECT 2;"


def test_extract_sql_empty_file_skipped(tmp_path):
    handler, _ = _make_handler()
    sql_file = tmp_path / "out.sql"
    sql_file.write_text("   \n")  # whitespace only -> skip
    stream = [{"type": "tool_use", "tool": {"name": "bash", "input": {
        "command": "cat > 'p/schema-modernization-sql.sql' << EOFSQL\nCREATE X;\nEOFSQL\n"}}}]
    out = handler._extract_sql_from_stream(stream, sql_output_file=sql_file)
    assert "CREATE X" in out


def test_extract_sql_non_bash_tool_ignored(tmp_path):
    handler, _ = _make_handler()
    stream = [
        {"type": "tool_use", "tool": {"name": "code_editor", "input": {"command": "x"}}},
        {"type": "other"},
    ]
    out = handler._extract_sql_from_stream(stream, sql_output_file=tmp_path / "n.sql")
    assert out is None


# ---------------------------------------------------------------------------
# execute
# ---------------------------------------------------------------------------
async def test_execute_content_in_prompt_success(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(return_value=_events())
    resp = await handler.execute(_req(prompt="CREATE TABLE x;"))
    assert resp.status == "success"
    assert "CREATE TABLE t" in resp.content
    assert resp.output_file_path.endswith("schema-modernization-sql.sql")


async def test_execute_file_access_success(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    schema = tmp_path / "schema.sql"
    schema.write_text("CREATE TABLE src(id NUMBER);")
    provider.invoke_with_tools_agentic = AsyncMock(return_value=_events())
    resp = await handler.execute(_req(sourceSchemaPath=str(schema)))
    assert resp.status == "success"


async def test_execute_no_sql_found(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=[{"type": "assistant", "subtype": "text_delta", "text": "no ddl"},
                      {"type": "result", "is_error": False}]
    )
    resp = await handler.execute(_req(prompt="x"))
    assert resp.status == "error"
    assert "No SQL content" in resp.message


async def test_execute_stream_error(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=[{"type": "assistant", "subtype": "text_delta",
                       "text": "```sql\nSELECT 1;\n```"},
                      {"type": "result", "is_error": True, "error": "model error"}]
    )
    resp = await handler.execute(_req(prompt="x"))
    assert resp.status == "error"
    assert resp.error_details == "model error"


async def test_execute_success_with_migration_files(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    claude_dir = tmp_path / "schema-modernization" / "schema-1" / "_claude"
    claude_dir.mkdir(parents=True, exist_ok=True)
    (claude_dir / "migration-notes.md").write_text("notes")
    (claude_dir / "Migration_Change_Report.json").write_text("{}")
    provider.invoke_with_tools_agentic = AsyncMock(return_value=_events())
    resp = await handler.execute(_req(prompt="x"))
    assert resp.status == "success"


async def test_execute_provider_exception(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(side_effect=RuntimeError("kaboom"))
    resp = await handler.execute(_req(prompt="x"))
    assert resp.status == "error"
    assert "kaboom" in resp.error_details


async def test_execute_validation_error_propagates(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    req = _req()  # missing prompt + source -> validate raises before try block
    with pytest.raises(ValidationError):
        await handler.execute(req)