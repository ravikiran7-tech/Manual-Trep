"""
Tests for CloudReadinessFixHandler — 100% line coverage.

Coverage map:
  get_timeout / get_output_directory / validate_request
  execute()            — single-mode and batched-mode routing
  _execute_single()    — success, error stream, no JSON result, re-raise
  _execute_batched()   — all succeed, partial fail, all fail,
                         empty blockers fallback, no JSON result warning,
                         outer exception re-raise
  _read_raw_prompt_file()         — success, missing file, is-a-directory
  _parse_prompt_sections()        — no separator, no brace, unbalanced,
                                    no post-json, with post-json, nested
  _extract_balanced_json_block()  — simple, nested, text-after, brace-in-string,
                                    escaped backslash, escaped quote,
                                    unterminated, start-offset, escape_next flag
  _extract_analysis_json()        — empty, valid, invalid JSON
  _group_blockers_by_rule()       — empty, single, same-rule merge,
                                    multiple rules, missing ruleId,
                                    occurrence field preservation
  _build_rule_prompt()            — rule_id, name, severity, remediation,
                                    single/multiple occurrences, base prompt,
                                    system enhancement header, empty occurrences
"""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.services.operation_handlers.cloudreadiness_fix_handler as handler_mod
from app.core.exceptions import FileOperationError, ValidationError
from app.models.requests import ClaudeCliRequest
from app.services.operation_handlers.cloudreadiness_fix_handler import (
    CloudReadinessFixHandler,
)

# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

BLOCKERS = [
    {
        "id": "blocker-1",
        "ruleId": "cz-java-0057",
        "ruleName": "Absolute File Paths",
        "ruleDesc": "Detects hardcoded absolute paths",
        "category": "file-system",
        "severity": "critical",
        "filePath": "/project/src/MiniApp.java",
        "beginLine": 18,
        "endLine": 18,
        "remediationName": "Replace with S3",
        "remediationDesc": "Use AWS SDK for S3",
    },
    {
        "id": "blocker-2",
        "ruleId": "cz-java-0057",
        "ruleName": "Absolute File Paths",
        "ruleDesc": "Detects hardcoded absolute paths",
        "category": "file-system",
        "severity": "critical",
        "filePath": "/project/src/MiniApp.java",
        "beginLine": 19,
        "endLine": 19,
        "remediationName": "Replace with S3",
        "remediationDesc": "Use AWS SDK for S3",
    },
    {
        "id": "blocker-3",
        "ruleId": "cz-java-0058",
        "ruleName": "Local FS Deps",
        "ruleDesc": "FS dependencies",
        "category": "file-system",
        "severity": "high",
        "filePath": "/project/src/MiniApp.java",
        "beginLine": 60,
        "endLine": 60,
        "remediationName": "Migrate to S3",
        "remediationDesc": "Use Spring Cloud AWS",
    },
]

ANALYSIS_DATA = {
    "analysisId": "test-analysis-123",
    "summary": {"totalBlockers": 3},
    "blockers": BLOCKERS,
}

# Prompt that contains all sections: pre-sep, JSON, post-sep
PROMPT_WITH_ANALYSIS = (
    "system prompt\n\nuser prompt\n\nproject details\n\n"
    "ANALYSIS REPORT:\n"
    + json.dumps(ANALYSIS_DATA, indent=2)
    + "\n\nTask :\nApply fixes.\n\nResponse format:\nJSON."
)

SUCCESS_EVENTS = [
    {
        "type": "assistant",
        "subtype": "text_delta",
        "text": '```json\n{"ruleId": "cz-java-0057", "status": "fixed"}\n```',
    },
    {"type": "result", "is_error": False, "input_tokens": 10, "output_tokens": 20},
]

# Events with no JSON block → extract_and_write_json_result returns None
PLAIN_EVENTS = [{"type": "result", "is_error": False}]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def prompt_file(tmp_path):
    pf = tmp_path / "prompt.txt"
    pf.write_text("apply cloud fixes", encoding="utf-8")
    return pf


@pytest.fixture
def batched_prompt_file(tmp_path):
    pf = tmp_path / "batched_prompt.txt"
    pf.write_text(PROMPT_WITH_ANALYSIS, encoding="utf-8")
    return pf


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_request(tmp_path, prompt_file, **overrides):
    data = {
        "projectPath": str(tmp_path).replace("\\", "/"),
        "analysisId": "crf-123",
        "operation": "cloudreadiness-fix",
        "claudeWorkspace": str(tmp_path).replace("\\", "/"),
        "prompt": str(prompt_file).replace("\\", "/"),
    }
    data.update(overrides)
    return ClaudeCliRequest(**data)


def build_handler(events=None):
    """Build a handler with a mocked provider factory returning *events*."""
    events = events if events is not None else SUCCESS_EVENTS
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    pf = MagicMock()
    pf.get_provider = AsyncMock(return_value=provider)
    return CloudReadinessFixHandler(provider_factory=pf), provider


def _h():
    """Shorthand: bare handler for pure-logic / unit tests."""
    h, _ = build_handler()
    return h


# ---------------------------------------------------------------------------
# Helper: temporarily flip batch_by_rule on the module-level settings singleton
# ---------------------------------------------------------------------------

class _BatchMode:
    """Context manager that sets batch_by_rule=True for the duration of a block."""

    def __enter__(self):
        self._orig = handler_mod.settings.cloudreadiness.batch_by_rule
        object.__setattr__(handler_mod.settings.cloudreadiness, "batch_by_rule", True)
        return self

    def __exit__(self, *_):
        object.__setattr__(
            handler_mod.settings.cloudreadiness, "batch_by_rule", self._orig
        )


# ===========================================================================
# 1. get_timeout / get_output_directory
# ===========================================================================

def test_get_timeout():
    assert _h().get_timeout() == 3600


def test_get_output_directory(tmp_path, prompt_file):
    assert _h().get_output_directory(make_request(tmp_path, prompt_file)) == "cloudreadiness"


# ===========================================================================
# 2. validate_request
# ===========================================================================

def test_validate_request_ok(tmp_path, prompt_file):
    _h().validate_request(make_request(tmp_path, prompt_file))


def test_validate_request_missing_prompt(tmp_path, prompt_file):
    h = _h()
    req = make_request(tmp_path, prompt_file)
    object.__setattr__(req, "prompt", None)
    with pytest.raises(ValidationError) as ei:
        h.validate_request(req)
    assert ei.value.field == "prompt"


def test_validate_request_missing_project_path(tmp_path, prompt_file):
    h = _h()
    req = make_request(tmp_path, prompt_file)
    object.__setattr__(req, "project_path", "")
    with pytest.raises(ValidationError) as ei:
        h.validate_request(req)
    assert ei.value.field == "projectPath"


# ===========================================================================
# 3. execute() — routing between single and batched modes
# ===========================================================================

async def test_execute_routes_to_single_when_flag_false(tmp_path, prompt_file):
    h, _ = build_handler()
    with patch.object(
        h, "_execute_single", new=AsyncMock(return_value=MagicMock(status="success"))
    ) as mock_single, patch.object(h, "_execute_batched", new=AsyncMock()) as mock_batched:
        # Ensure flag is False (default)
        object.__setattr__(handler_mod.settings.cloudreadiness, "batch_by_rule", False)
        await h.execute(make_request(tmp_path, prompt_file))
    mock_single.assert_awaited_once()
    mock_batched.assert_not_awaited()


async def test_execute_routes_to_batched_when_flag_true(tmp_path, batched_prompt_file):
    h, _ = build_handler()
    with _BatchMode(), patch.object(
        h, "_execute_batched", new=AsyncMock(return_value=MagicMock(status="success"))
    ) as mock_batched:
        await h.execute(make_request(tmp_path, batched_prompt_file))
    mock_batched.assert_awaited_once()


async def test_execute_validation_error_raised_before_routing(tmp_path, prompt_file):
    h = _h()
    req = make_request(tmp_path, prompt_file)
    object.__setattr__(req, "prompt", None)
    with pytest.raises(ValidationError):
        await h.execute(req)


# ===========================================================================
# 4. _execute_single()
# ===========================================================================

async def test_single_success_writes_files(tmp_path, prompt_file):
    h, provider = build_handler(SUCCESS_EVENTS)
    resp = await h._execute_single(make_request(tmp_path, prompt_file))
    assert resp.status == "success"
    out = h.build_output_path(make_request(tmp_path, prompt_file), "cloudreadiness-fix-stream.json")
    assert out.exists()
    # JSON result file extracted (SUCCESS_EVENTS contains a ```json block)
    assert (out.parent / "cloudreadiness-fix-result.json").exists()


async def test_single_result_path_none_logs_warning(tmp_path, prompt_file):
    """Events with no JSON block → result_path is None → warning branch (line 162-163)."""
    h, _ = build_handler(PLAIN_EVENTS)
    resp = await h._execute_single(make_request(tmp_path, prompt_file))
    assert resp.status == "success"


async def test_single_error_stream_returns_error_response(tmp_path, prompt_file):
    events = [{"type": "result", "is_error": True, "error": "model blew up"}]
    h, _ = build_handler(events)
    resp = await h._execute_single(make_request(tmp_path, prompt_file))
    assert resp.status == "error"
    assert resp.error == "model blew up"


async def test_single_reraises_on_exception(tmp_path, prompt_file):
    h, _ = build_handler()
    prompt_file.unlink()  # make the prompt file disappear
    with pytest.raises(Exception):
        await h._execute_single(make_request(tmp_path, prompt_file))


# ===========================================================================
# 5. _execute_batched()
# ===========================================================================

async def test_batched_all_rules_succeed(tmp_path, batched_prompt_file):
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    with patch.object(h, "invoke_with_provider", new=AsyncMock(return_value=SUCCESS_EVENTS)):
        resp = await h._execute_batched(req)
    assert resp.status == "success"
    assert "2 rule(s) processed" in resp.message
    merged = h.build_output_path(req, "cloudreadiness-fix-stream.json")
    assert merged.exists()


async def test_batched_writes_single_merged_stream_file_only(tmp_path, batched_prompt_file):
    """Per-rule stream files are no longer created; only the merged stream file is written."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    with patch.object(h, "invoke_with_provider", new=AsyncMock(return_value=SUCCESS_EVENTS)):
        await h._execute_batched(req)
    out_dir = h.build_output_path(req, "cloudreadiness-fix-stream.json").parent
    assert not (out_dir / "rule-cz-java-0057-stream.json").exists()
    assert not (out_dir / "rule-cz-java-0058-stream.json").exists()

    merged = h.build_output_path(req, "cloudreadiness-fix-stream.json")
    assert merged.exists()
    merged_events = json.loads(merged.read_text(encoding="utf-8"))
    assert len(merged_events) == len(SUCCESS_EVENTS) * 2
    assert {e.get("rule_id") for e in merged_events} == {"cz-java-0057", "cz-java-0058"}


async def test_batched_events_stamped_with_rule_id(tmp_path, batched_prompt_file):
    """Every event returned by invoke_with_provider gets a 'rule_id' key stamped."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    captured_events = []

    async def capture_events(*args, **kwargs):
        events = [{"type": "result", "is_error": False}]
        captured_events.extend(events)
        return events

    with patch.object(h, "invoke_with_provider", side_effect=capture_events):
        resp = await h._execute_batched(req)

    merged_path = h.build_output_path(req, "cloudreadiness-fix-stream.json")
    merged = json.loads(merged_path.read_text())
    # All merged events should have rule_id stamped
    for ev in merged:
        assert "rule_id" in ev


async def test_batched_partial_failure_returns_partial_success(tmp_path, batched_prompt_file):
    """First rule call fails; second succeeds → partial success response."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    call_count = 0

    async def alternating(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("first rule failed")
        return SUCCESS_EVENTS

    with patch.object(h, "invoke_with_provider", side_effect=alternating):
        resp = await h._execute_batched(req)

    assert resp.status == "success"
    assert "partial success" in resp.message.lower()
    assert "cz-java-0057" in resp.message


async def test_batched_all_rules_fail_returns_error(tmp_path, batched_prompt_file):
    """All rule calls raise → error response."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    with patch.object(h, "invoke_with_provider", side_effect=RuntimeError("boom")):
        resp = await h._execute_batched(req)
    assert resp.status == "error"
    assert "failed" in resp.message.lower()


async def test_batched_empty_blockers_falls_back_to_single(tmp_path):
    """Analysis JSON with no blockers → _execute_single called."""
    empty_analysis = {"analysisId": "a1", "summary": {}, "blockers": []}
    prompt_text = (
        "base\n\nANALYSIS REPORT:\n"
        + json.dumps(empty_analysis)
        + "\n\nTask: do it."
    )
    pf = tmp_path / "prompt.txt"
    pf.write_text(prompt_text, encoding="utf-8")
    h, _ = build_handler(SUCCESS_EVENTS)
    req = make_request(tmp_path, pf)
    with patch.object(
        h, "_execute_single", new=AsyncMock(return_value=MagicMock(status="success"))
    ) as mock_single:
        await h._execute_batched(req)
    mock_single.assert_awaited_once()


async def test_batched_no_json_result_logs_warning(tmp_path, batched_prompt_file):
    """Events contain no JSON block → extract_and_write_json_result None → warning logged."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    with patch.object(h, "invoke_with_provider", new=AsyncMock(return_value=PLAIN_EVENTS)):
        resp = await h._execute_batched(req)
    assert resp.status == "success"


async def test_batched_result_json_written_when_events_have_json(tmp_path, batched_prompt_file):
    """SUCCESS_EVENTS contains JSON block → cloudreadiness-fix-result.json created."""
    h, _ = build_handler()
    req = make_request(tmp_path, batched_prompt_file)
    with patch.object(h, "invoke_with_provider", new=AsyncMock(return_value=SUCCESS_EVENTS)):
        await h._execute_batched(req)
    out_dir = h.build_output_path(req, "cloudreadiness-fix-stream.json").parent
    assert (out_dir / "cloudreadiness-fix-result.json").exists()


async def test_batched_outer_exception_reraises(tmp_path, prompt_file):
    """If _read_raw_prompt_file fails, outer except re-raises."""
    h, _ = build_handler()
    req = make_request(tmp_path, prompt_file)
    prompt_file.unlink()
    with pytest.raises(Exception):
        await h._execute_batched(req)


# ===========================================================================
# 6. _read_raw_prompt_file()
# ===========================================================================

def test_read_raw_prompt_file_success(tmp_path):
    pf = tmp_path / "p.txt"
    pf.write_text("hello world", encoding="utf-8")
    result = _h()._read_raw_prompt_file(str(pf).replace("\\", "/"))
    assert result == "hello world"


def test_read_raw_prompt_file_not_found(tmp_path):
    missing = str(tmp_path / "missing.txt").replace("\\", "/")
    with pytest.raises(FileOperationError) as ei:
        _h()._read_raw_prompt_file(missing)
    assert "does not exist" in ei.value.details


def test_read_raw_prompt_file_is_directory(tmp_path):
    """Path exists but is a directory → ValueError → outer except → FileOperationError."""
    subdir = tmp_path / "adir"
    subdir.mkdir()
    # Patch validate_path to pass (avoids any OS-path rejection)
    with patch(
        "app.core.security.SecurityValidator.validate_path"
    ):
        with pytest.raises(FileOperationError) as ei:
            _h()._read_raw_prompt_file(str(subdir).replace("\\", "/"))
    assert "Failed to read prompt file" in ei.value.message


# ===========================================================================
# 7. _parse_prompt_sections()
# ===========================================================================

def test_parse_no_separator_returns_raw_and_empty():
    base, jstr = _h()._parse_prompt_sections("no separator here")
    assert base == "no separator here"
    assert jstr == ""


def test_parse_separator_present_but_no_brace():
    raw = "base text\n\nANALYSIS REPORT:\nno json here"
    base, jstr = _h()._parse_prompt_sections(raw)
    assert base == raw.strip()
    assert jstr == ""


def test_parse_separator_present_brace_opens_but_never_closes():
    raw = 'base\n\nANALYSIS REPORT:\n{"key": "unclosed'
    base, jstr = _h()._parse_prompt_sections(raw)
    assert base == raw.strip()
    assert jstr == ""


def test_parse_json_only_no_post_sections():
    """JSON is the last content — no post-json text. base_prompt = pre_sep only."""
    raw = 'instructions\n\nANALYSIS REPORT:\n{"analysisId": "x", "blockers": []}'
    base, jstr = _h()._parse_prompt_sections(raw)
    assert "instructions" in base
    assert "ANALYSIS REPORT:" not in base
    assert json.loads(jstr) == {"analysisId": "x", "blockers": []}
    # No post-json text → base has no Task / Response section
    assert "Task" not in base


def test_parse_json_with_post_sections_both_preserved():
    """Sections before AND after JSON both end up in base_prompt."""
    raw = (
        "system prompt\n\n"
        "ANALYSIS REPORT:\n"
        '{"analysisId": "y", "blockers": []}\n\n'
        "Task :\nFix all.\n\n"
        "Response format:\nJSON."
    )
    base, jstr = _h()._parse_prompt_sections(raw)
    assert "system prompt" in base
    assert "Task :" in base
    assert "Response format:" in base
    assert "ANALYSIS REPORT:" not in base
    assert json.loads(jstr) == {"analysisId": "y", "blockers": []}


def test_parse_nested_json_extracted_correctly():
    nested = '{"outer": {"inner": {"deep": true}}}'
    raw = f"base\n\nANALYSIS REPORT:\n{nested}\nTask: done."
    _, jstr = _h()._parse_prompt_sections(raw)
    assert json.loads(jstr) == {"outer": {"inner": {"deep": True}}}


def test_parse_json_with_braces_in_string_value():
    """Braces inside a JSON string value must not confuse the brace counter."""
    tricky = '{"key": "value with { braces }"}'
    raw = f"base\n\nANALYSIS REPORT:\n{tricky}\nTask: done."
    _, jstr = _h()._parse_prompt_sections(raw)
    assert json.loads(jstr) == {"key": "value with { braces }"}


# ===========================================================================
# 8. _extract_balanced_json_block()
# ===========================================================================

def test_balanced_simple_object():
    text = '{"a": 1}'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert result == '{"a": 1}'
    assert end == len(text)


def test_balanced_nested_objects():
    text = '{"a": {"b": {"c": 3}}}'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert json.loads(result) == {"a": {"b": {"c": 3}}}
    assert end == len(text)


def test_balanced_text_after_json():
    text = '{"a": 1}  extra text after'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert result == '{"a": 1}'
    assert text[end:].strip() == "extra text after"


def test_balanced_brace_inside_string_ignored():
    text = '{"key": "has { and } braces"}'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert json.loads(result) == {"key": "has { and } braces"}
    assert end == len(text)


def test_balanced_escaped_backslash_in_string():
    """{"path": "C:\\\\"} — escaped backslash, then string closes on the next quote."""
    text = '{"path": "C:\\\\"}'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert json.loads(result)["path"] == "C:\\"


def test_balanced_escaped_quote_in_string():
    """Escaped double-quote inside string must not prematurely close the string."""
    text = '{"msg": "say \\"hi\\""}'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert json.loads(result)["msg"] == 'say "hi"'


def test_balanced_escape_next_flag_consume_next_char():
    r"""Backslash followed by another char (not a quote) still sets escape_next."""
    # {"x": "a\"b"} — escaped quote mid-string
    text = '{"x": "a\\"b"}'
    result, _ = _h()._extract_balanced_json_block(text, 0)
    assert json.loads(result)["x"] == 'a"b'


def test_balanced_unterminated_returns_empty():
    text = '{"key": "unclosed'
    result, end = _h()._extract_balanced_json_block(text, 0)
    assert result == ""
    assert end == len(text)


def test_balanced_start_offset_skips_prefix():
    text = 'prefix {"a": 1} suffix'
    start = text.index("{")
    result, end = _h()._extract_balanced_json_block(text, start)
    assert result == '{"a": 1}'
    assert text[end:].strip() == "suffix"


# ===========================================================================
# 9. _extract_analysis_json()
# ===========================================================================

def test_extract_analysis_empty_string_raises():
    with pytest.raises(FileOperationError) as ei:
        _h()._extract_analysis_json("", "/some/prompt.txt")
    assert "empty" in ei.value.message.lower()


def test_extract_analysis_valid_json():
    data = json.dumps({"analysisId": "a1", "blockers": [{"ruleId": "r1"}]})
    result = _h()._extract_analysis_json(data, "/prompt.txt")
    assert result["analysisId"] == "a1"
    assert len(result["blockers"]) == 1


def test_extract_analysis_invalid_json_raises():
    with pytest.raises(FileOperationError) as ei:
        _h()._extract_analysis_json("{not valid json", "/prompt.txt")
    assert "JSON decode error" in ei.value.details


# ===========================================================================
# 10. _group_blockers_by_rule()
# ===========================================================================

def test_group_empty_list():
    assert _h()._group_blockers_by_rule([]) == {}


def test_group_single_blocker():
    blockers = [{
        "id": "b1", "ruleId": "r1", "ruleName": "Rule One",
        "ruleDesc": "desc", "category": "cat", "severity": "critical",
        "filePath": "/a.java", "beginLine": 1, "endLine": 1,
        "remediationName": "Fix it", "remediationDesc": "How to fix",
    }]
    result = _h()._group_blockers_by_rule(blockers)
    assert list(result.keys()) == ["r1"]
    assert result["r1"]["ruleName"] == "Rule One"
    assert len(result["r1"]["occurrences"]) == 1


def test_group_multiple_blockers_same_rule_merged():
    blockers = [
        {
            "id": "b1", "ruleId": "r1", "ruleName": "R1",
            "ruleDesc": "d", "category": "c", "severity": "critical",
            "filePath": "/a.java", "beginLine": 10, "endLine": 10,
            "remediationName": "F", "remediationDesc": "H",
        },
        {
            "id": "b2", "ruleId": "r1", "ruleName": "R1",
            "ruleDesc": "d", "category": "c", "severity": "critical",
            "filePath": "/b.java", "beginLine": 20, "endLine": 20,
            "remediationName": "F", "remediationDesc": "H",
        },
    ]
    result = _h()._group_blockers_by_rule(blockers)
    assert len(result) == 1
    assert len(result["r1"]["occurrences"]) == 2


def test_group_multiple_different_rules():
    blockers = [
        {"id": "b1", "ruleId": "r1", "ruleName": "R1", "ruleDesc": "d",
         "category": "c", "severity": "high", "filePath": "/a.java",
         "beginLine": 1, "endLine": 1, "remediationName": "F1", "remediationDesc": "H1"},
        {"id": "b2", "ruleId": "r2", "ruleName": "R2", "ruleDesc": "d",
         "category": "c", "severity": "medium", "filePath": "/b.java",
         "beginLine": 5, "endLine": 5, "remediationName": "F2", "remediationDesc": "H2"},
    ]
    result = _h()._group_blockers_by_rule(blockers)
    assert set(result.keys()) == {"r1", "r2"}


def test_group_blocker_missing_rule_id_uses_unknown():
    """A blocker without 'ruleId' is grouped under 'unknown'."""
    blockers = [{"id": "b1", "filePath": "/x.java", "beginLine": 1, "endLine": 1}]
    result = _h()._group_blockers_by_rule(blockers)
    assert "unknown" in result


def test_group_occurrence_fields_all_preserved():
    blockers = [{
        "id": "bid", "ruleId": "rx", "ruleName": "RX",
        "ruleDesc": "d", "category": "c", "severity": "low",
        "filePath": "/x.java", "beginLine": 42, "endLine": 43,
        "remediationName": "F", "remediationDesc": "H",
    }]
    occ = _h()._group_blockers_by_rule(blockers)["rx"]["occurrences"][0]
    assert occ == {"id": "bid", "filePath": "/x.java", "beginLine": 42, "endLine": 43}


def test_group_metadata_taken_from_first_blocker():
    """When two blockers share a ruleId, metadata from the first one is kept."""
    blockers = [
        {"id": "b1", "ruleId": "r1", "ruleName": "First Name",
         "ruleDesc": "d", "category": "c", "severity": "critical",
         "filePath": "/a.java", "beginLine": 1, "endLine": 1,
         "remediationName": "F", "remediationDesc": "H"},
        {"id": "b2", "ruleId": "r1", "ruleName": "Second Name",   # different name
         "ruleDesc": "d2", "category": "c2", "severity": "high",
         "filePath": "/b.java", "beginLine": 2, "endLine": 2,
         "remediationName": "F2", "remediationDesc": "H2"},
    ]
    result = _h()._group_blockers_by_rule(blockers)
    assert result["r1"]["ruleName"] == "First Name"


# ===========================================================================
# 11. _build_rule_prompt()
# ===========================================================================

def _rule_data(n=1):
    return {
        "ruleName": "Absolute File Paths",
        "ruleDesc": "Hardcoded paths break containers",
        "category": "file-system",
        "severity": "critical",
        "remediationName": "Use S3",
        "remediationDesc": "Migrate to AWS SDK S3",
        "occurrences": [
            {"filePath": f"/src/File{i}.java", "beginLine": i * 10, "endLine": i * 10}
            for i in range(1, n + 1)
        ],
    }


def test_build_prompt_contains_rule_id():
    assert "cz-java-0057" in _h()._build_rule_prompt("base", "cz-java-0057", _rule_data())


def test_build_prompt_contains_rule_name():
    assert "Absolute File Paths" in _h()._build_rule_prompt("base", "rid", _rule_data())


def test_build_prompt_severity_is_uppercased():
    assert "CRITICAL" in _h()._build_rule_prompt("base", "rid", _rule_data())


def test_build_prompt_contains_remediation_name_and_desc():
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data())
    assert "Use S3" in prompt
    assert "Migrate to AWS SDK S3" in prompt


def test_build_prompt_single_occurrence_listed():
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data(1))
    assert "/src/File1.java" in prompt
    assert "Lines: 10–10" in prompt


def test_build_prompt_all_multiple_occurrences_listed():
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data(3))
    for i in range(1, 4):
        assert f"/src/File{i}.java" in prompt


def test_build_prompt_preserves_base_prompt():
    marker = "UNIQUE_BASE_INSTRUCTION_XYZ_9876"
    assert marker in _h()._build_rule_prompt(marker, "rid", _rule_data())


def test_build_prompt_contains_system_enhancement_header():
    """_enhance_prompt_with_json_output_requirement injects CRITICAL SYSTEM REQUIREMENTS."""
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data())
    assert "CRITICAL SYSTEM REQUIREMENTS" in prompt


def test_build_prompt_empty_occurrences_no_crash():
    """Zero occurrences → occurrence_lines is empty string, no IndexError."""
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data(0))
    assert "rid" in prompt


def test_build_prompt_occurrence_numbering():
    """Occurrences are numbered 1, 2, 3 …"""
    prompt = _h()._build_rule_prompt("base", "rid", _rule_data(3))
    assert "  1. " in prompt
    assert "  2. " in prompt
    assert "  3. " in prompt


# ===========================================================================
# 12. Full execute() integration (single mode — re-confirms end-to-end wiring)
# ===========================================================================

async def test_full_execute_success(tmp_path, prompt_file):
    h, provider = build_handler(SUCCESS_EVENTS)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "success"
    out = h.build_output_path(make_request(tmp_path, prompt_file),
                              "cloudreadiness-fix-stream.json")
    assert out.exists()
    assert (out.parent / "cloudreadiness-fix-result.json").exists()
    provider.invoke_with_tools_agentic_graph.assert_awaited()


async def test_full_execute_error_stream(tmp_path, prompt_file):
    events = [{"type": "result", "is_error": True, "error": "crf failed"}]
    h, _ = build_handler(events)
    resp = await h.execute(make_request(tmp_path, prompt_file))
    assert resp.status == "error"
    assert resp.error == "crf failed"


async def test_full_execute_reraises_on_failure(tmp_path, prompt_file):
    h, _ = build_handler()
    prompt_file.unlink()
    with pytest.raises(Exception):
        await h.execute(make_request(tmp_path, prompt_file))