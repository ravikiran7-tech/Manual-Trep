"""Tests for TestExecutionHandler (test-execution / Java operation)."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.operation_handlers.test_execution_handler import TestExecutionHandler
from app.core.exceptions import ValidationError
from app.core import resilience as resilience_mod


def _result_event(is_error=False):
    return {"type": "result", "is_error": is_error, "input_tokens": 5, "output_tokens": 7}


def _assistant_json_event(payload):
    return {"type": "assistant", "subtype": "text_delta",
            "text": "```json\n" + json.dumps(payload) + "\n```"}


def _reset_all_breakers():
    for b in (
        resilience_mod.bedrock_circuit_breaker,
        resilience_mod.portkey_circuit_breaker,
        resilience_mod.compass_circuit_breaker,
    ):
        try:
            b.close()
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _reset_breaker(monkeypatch):
    _reset_all_breakers()
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_min", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_max", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_multiplier", 0, raising=False)
    yield
    _reset_all_breakers()


@pytest.fixture
def home(tmp_path, monkeypatch):
    """Fake HOME with SDKMAN java candidates so verification passes."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: fake_home))
    return fake_home


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    from app.services.operation_handlers import test_execution_handler as mod
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path), raising=False)
    return tmp_path


@pytest.fixture
def prompt_file(tmp_path):
    p = tmp_path / "prompt.txt"
    p.write_text("Run java tests.", encoding="utf-8")
    return str(p).replace("\\", "/")


def _install_java(home, sdkman_version="17.0.13-tem"):
    jh = home / ".sdkman" / "candidates" / "java" / sdkman_version
    jh.mkdir(parents=True)
    return jh


def _make_handler(home, events=None, provider_side_effect=None):
    provider = MagicMock()
    invoke = AsyncMock()
    if provider_side_effect is not None:
        invoke.side_effect = provider_side_effect
    else:
        invoke.return_value = events if events is not None else []
    provider.invoke_with_tools_agentic_graph = invoke
    provider.invoke_with_tools_agentic = invoke
    factory = MagicMock()
    factory.get_provider = AsyncMock(return_value=provider)
    return TestExecutionHandler(provider_factory=factory), provider, invoke


def _make_request(prompt, project_path="/projects/app", analysis_id="te-123", java_version="17"):
    from app.models.requests import ClaudeCliRequest
    return ClaudeCliRequest(
        prompt=prompt,
        projectPath=project_path,
        analysisId=analysis_id,
        operation="test-execution",
        javaVersion=java_version,
    )


# --------------------------- unit methods ---------------------------
def test_init_sets_sdkman_script(home):
    handler, *_ = _make_handler(home)
    assert handler.sdkman_init_script.name == "sdkman-init.sh"


def test_get_timeout(home):
    handler, *_ = _make_handler(home)
    assert handler.get_timeout() == handler.settings.timeouts.build_validation


def test_get_output_directory(home):
    handler, *_ = _make_handler(home)
    assert handler.get_output_directory(_make_request("x")) == "validation"


def test_enhance_prompt_with_test_context(home):
    handler, *_ = _make_handler(home)
    out = handler._enhance_prompt_with_test_context("ORIG", "17", "17.0.13-tem")
    assert "17" in out and out.endswith("ORIG")


def test_validate_request_ok(home, prompt_file):
    handler, *_ = _make_handler(home)
    handler.validate_request(_make_request(prompt_file))


def test_validate_request_missing_prompt(home):
    handler, *_ = _make_handler(home)
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(None))


def test_validate_request_missing_java_version(home, prompt_file):
    handler, *_ = _make_handler(home)
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(prompt_file, java_version=None))


def test_validate_request_bad_java_version(home, prompt_file):
    handler, *_ = _make_handler(home)
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(prompt_file, java_version="99"))


def test_verify_java_version_not_installed(home):
    handler, *_ = _make_handler(home)
    with pytest.raises(ValidationError):
        handler._verify_java_version_installed("17.0.13-tem")


def test_verify_java_version_installed_ok(home):
    _install_java(home)
    handler, *_ = _make_handler(home)
    handler._verify_java_version_installed("17.0.13-tem")  # no raise


def test_create_validation_directories(home, workspace):
    handler, *_ = _make_handler(home)
    handler._create_validation_directories(_make_request("x", analysis_id="abc"))
    base = workspace / "validation" / "abc"
    for sub in ("test-reports", "_claude", "coverage"):
        assert (base / sub).is_dir()


# --------------------------- execute ---------------------------
async def test_execute_success(home, workspace, prompt_file):
    _install_java(home)
    events = [_assistant_json_event({"passed": 1}), _result_event(False)]
    handler, _, invoke = _make_handler(home, events=events)
    resp = await handler.execute(_make_request(prompt_file))
    assert resp.status == "success"
    invoke.assert_awaited()
    result = Path(resp.output_file_path).parent / "test-execution-result.json"
    assert result.exists()


async def test_execute_success_no_json(home, workspace, prompt_file):
    _install_java(home)
    events = [{"type": "assistant", "subtype": "text_delta", "text": "plain"}, _result_event(False)]
    handler, *_ = _make_handler(home, events=events)
    resp = await handler.execute(_make_request(prompt_file))
    assert resp.status == "success"


async def test_execute_failure(home, workspace, prompt_file):
    _install_java(home)
    events = [{"type": "error", "error": "test failure"}, _result_event(True)]
    handler, *_ = _make_handler(home, events=events)
    resp = await handler.execute(_make_request(prompt_file))
    assert resp.status == "error"
    assert "test failure" in resp.message


async def test_execute_validation_raises(home, workspace):
    handler, *_ = _make_handler(home, events=[])
    with pytest.raises(ValidationError):
        await handler.execute(_make_request(None))


async def test_execute_java_not_installed_raises(home, workspace, prompt_file):
    """Valid request but Java not installed -> ValidationError surfaces via execute."""
    handler, *_ = _make_handler(home, events=[])
    with pytest.raises(ValidationError):
        await handler.execute(_make_request(prompt_file))


async def test_execute_provider_failure_propagates(home, workspace, prompt_file):
    _install_java(home)
    handler, *_ = _make_handler(home, provider_side_effect=RuntimeError("down"))
    with pytest.raises(RuntimeError):
        await handler.execute(_make_request(prompt_file))