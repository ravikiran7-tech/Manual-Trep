"""Tests for AssessmentRulesBatchHandler and its module-level helpers."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import RateLimitError, ValidationError
from app.models.requests import AssessmentRuleInputItem, AssessmentRulesBatchRequest
import app.services.operation_handlers.assessment_rules_batch_handler as mod
from app.services.operation_handlers.assessment_rules_batch_handler import (
    AssessmentRulesBatchHandler,
    _apply_input_assessment_fields,
    _default_file_types_for_language,
    _finalize_new_detection_schema,
    _is_new_detection_shape,
    _language_name_for_detection,
    _legacy_detection_to_new_schema,
    _normalize_batch_rule_item_for_client,
    _normalize_batch_rules_for_client,
    _parse_json_array_from_assistant_text,
    _reset_batch_request_semaphore_for_tests,
    _split_rules_into_chunks,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _rule(
    rid="R1",
    domain="code-quality",
    language="java",
    name="N",
    desc="D",
    example=None,
    category="Code Quality",
    issue_type="NEUTRAL",
    severity="MEDIUM",
):
    return AssessmentRuleInputItem(
        ruleId=rid, domain=domain, language=language, name=name,
        description=desc, example=example, category=category,
        issueType=issue_type, severity=severity,
    )


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    handler = AssessmentRulesBatchHandler(provider_factory=factory)
    return handler, provider


def _assistant_events(text):
    return [
        {"type": "assistant", "subtype": "text_delta", "text": text},
        {"type": "result", "is_error": False, "input_tokens": 1, "output_tokens": 2},
    ]


# ---------------------------------------------------------------------------
# language / file-type helpers
# ---------------------------------------------------------------------------
def test_language_name_from_det_dict():
    assert _language_name_for_detection({}, {"language": {"name": " Java "}}) == "java"


def test_language_name_from_det_string():
    assert _language_name_for_detection({}, {"language": "Python"}) == "python"


def test_language_name_from_body_dict():
    assert _language_name_for_detection({"language": {"name": "CSharp"}}, {}) == "csharp"


def test_language_name_from_body_string():
    assert _language_name_for_detection({"language": "PHP"}, {}) == "php"


def test_language_name_empty():
    assert _language_name_for_detection({}, {}) == ""


def test_default_file_types_known():
    assert _default_file_types_for_language("java") == ["java"]


def test_default_file_types_unknown_returns_self():
    assert _default_file_types_for_language("rust") == ["rust"]


def test_default_file_types_empty():
    assert _default_file_types_for_language("") == []


def test_is_new_detection_shape():
    assert _is_new_detection_shape({"detectionCriteria": {}}) is True
    assert _is_new_detection_shape({"detectionCriteria": "x"}) is False
    assert _is_new_detection_shape({}) is False


# ---------------------------------------------------------------------------
# _finalize_new_detection_schema
# ---------------------------------------------------------------------------
def test_finalize_new_detection_with_string_language_and_empty_filetype():
    det = {
        "language": "Java",
        "detectionCriteria": {"fileType": [], "searchPattern": ["x"]},
    }
    out = _finalize_new_detection_schema(det, {"name": "RuleName"}, "R1")
    assert out["status"] == "active"
    assert out["parser"] == "REGEX"
    assert out["ruleId"] == "R1"
    assert out["ruleName"] == "RuleName"
    assert out["version"] == "1.0"
    assert out["language"] == {"name": "java", "versions": []}
    # empty fileType is filled from language default
    assert out["detectionCriteria"]["fileType"] == ["java"]
    assert out["scope"] == ["function"]


def test_finalize_new_detection_with_dict_language_and_existing_filetype():
    det = {
        "ruleName": "Keep",
        "language": {"name": "PYTHON", "versions": ["3"]},
        "detectionCriteria": {"fileType": ["py"], "searchPattern": []},
        "scope": ["file"],
    }
    out = _finalize_new_detection_schema(det, {}, None)
    assert out["language"] == {"name": "python", "versions": ["3"]}
    assert out["detectionCriteria"]["fileType"] == ["py"]
    assert out["scope"] == ["file"]
    assert "ruleId" not in out  # rid None -> not set


def test_finalize_new_detection_missing_language_and_criteria():
    det = {}
    out = _finalize_new_detection_schema(det, {"language": "go"}, "R2")
    assert out["language"] == {"name": "go", "versions": []}
    # detectionCriteria absent -> rebuilt from language default
    assert out["detectionCriteria"]["fileType"] == ["go"]
    assert out["detectionCriteria"]["searchPattern"] == []


def test_finalize_new_detection_language_dict_no_name():
    det = {"language": {"versions": ["1"]}, "detectionCriteria": {"fileType": ["x"]}}
    out = _finalize_new_detection_schema(det, {}, "R3")
    assert out["language"]["versions"] == ["1"]


# ---------------------------------------------------------------------------
# _legacy_detection_to_new_schema
# ---------------------------------------------------------------------------
def test_legacy_with_dict_language_and_match_hints():
    det = {
        "language": {"name": "Java", "versions": ["17"]},
        "matchHints": ["pat1", 123, "pat2"],
        "scope": ["class"],
        "version": "2.0",
        "ruleName": "Old",
    }
    out = _legacy_detection_to_new_schema(det, {"name": "BodyName"}, "R1")
    assert out["status"] == "active"
    assert out["parser"] == "REGEX"
    assert out["language"]["name"] == "java"
    assert out["scope"] == ["class"]
    assert out["version"] == "2.0"
    assert out["ruleName"] == "BodyName"
    assert out["detectionCriteria"]["searchPattern"] == ["pat1", "pat2"]


def test_legacy_with_string_language():
    out = _legacy_detection_to_new_schema({"language": "Python"}, {}, "R1")
    assert out["language"] == {"name": "python", "versions": []}
    assert out["scope"] == ["function"]
    assert out["version"] == "1.0"


def test_legacy_with_body_dict_language():
    out = _legacy_detection_to_new_schema({}, {"language": {"name": "CS"}}, "R1")
    assert out["language"]["name"] == "cs"


def test_legacy_with_body_string_language():
    out = _legacy_detection_to_new_schema({}, {"language": "ruby"}, "R1")
    assert out["language"] == {"name": "ruby", "versions": []}


def test_legacy_with_no_language_anywhere():
    out = _legacy_detection_to_new_schema({}, {}, "R1")
    assert out["language"] == {"name": "", "versions": []}


def test_legacy_language_dict_no_name():
    out = _legacy_detection_to_new_schema({"language": {"versions": ["x"]}}, {}, "R1")
    assert out["language"]["versions"] == ["x"]


def test_legacy_body_language_dict_no_name():
    out = _legacy_detection_to_new_schema({}, {"language": {"versions": ["y"]}}, "R1")
    assert out["language"]["versions"] == ["y"]


# ---------------------------------------------------------------------------
# _parse_json_array_from_assistant_text
# ---------------------------------------------------------------------------
def test_parse_json_array_plain():
    assert _parse_json_array_from_assistant_text('[{"a": 1}]') == [{"a": 1}]


def test_parse_json_array_in_fence():
    text = "Here:\n```json\n[{\"a\": 1}]\n```"
    assert _parse_json_array_from_assistant_text(text) == [{"a": 1}]


def test_parse_json_array_surrounding_text_bracket_scan():
    text = "blah blah [\n  {\"a\": 1}\n] trailing"
    assert _parse_json_array_from_assistant_text(text) == [{"a": 1}]


def test_parse_json_array_invalid_raises():
    with pytest.raises(ValueError):
        _parse_json_array_from_assistant_text("not json at all")


def test_parse_json_array_object_not_array_raises():
    with pytest.raises(ValueError):
        _parse_json_array_from_assistant_text('{"a": 1}')


def test_parse_json_array_bracket_scan_invalid():
    with pytest.raises(ValueError):
        _parse_json_array_from_assistant_text("[ this is not valid json ]")


# ---------------------------------------------------------------------------
# _normalize_batch_rule_item_for_client
# ---------------------------------------------------------------------------
def test_normalize_item_not_dict():
    out = _normalize_batch_rule_item_for_client("garbage")
    assert out["ruleId"] is None
    assert out["assessmentSchema"] == {}
    assert out["detectionSchema"]["parser"] == "REGEX"


def test_normalize_item_new_detection_shape_with_assessment():
    item = {
        "ruleId": "R1",
        "detectionSchema": {"detectionCriteria": {"fileType": ["java"]}, "language": "java"},
        "assessmentSchema": {"description": "d"},
    }
    out = _normalize_batch_rule_item_for_client(item)
    assert out["ruleId"] == "R1"
    assert out["assessmentSchema"]["description"] == "d"
    assert out["assessmentSchema"]["ruleId"] == "R1"
    assert out["detectionSchema"]["detectionCriteria"]["fileType"] == ["java"]


def test_normalize_item_legacy_detection_and_no_assessment():
    item = {
        "ruleId": "R2",
        "name": "n",
        "language": "java",
        "detectionSchema": {"matchHints": ["p"]},
    }
    out = _normalize_batch_rule_item_for_client(item)
    # assessment built from body
    assert out["assessmentSchema"]["name"] == "n"
    assert out["assessmentSchema"]["ruleId"] == "R2"
    assert out["detectionSchema"]["detectionCriteria"]["searchPattern"] == ["p"]


def test_normalize_item_detection_not_dict():
    item = {"ruleId": "R3", "language": "python", "detectionSchema": "nope"}
    out = _normalize_batch_rule_item_for_client(item)
    assert out["detectionSchema"]["language"]["name"] == "python"
    assert out["detectionSchema"]["ruleId"] == "R3"


def test_normalize_rules_for_client_returns_models():
    items = _normalize_batch_rules_for_client([{"ruleId": "R1"}])
    assert items[0].rule_id == "R1"


def test_apply_input_assessment_fields_overwrites_model_values():
    items = _normalize_batch_rules_for_client([
        {
            "ruleId": "cq-001",
            "assessmentSchema": {
                "category": "Invented",
                "issueType": "BLOCKER",
                "severity": "LOW",
                "remediation": {"remediations": []},
            },
        },
        {
            "ruleId": "cq-002",
            "assessmentSchema": {
                "category": "Invented",
                "issueType": "NEUTRAL",
                "severity": "LOW",
                "remediation": {"remediations": [{"name": "drop me"}]},
            },
        },
    ])
    _apply_input_assessment_fields(
        items,
        [
            _rule(rid="cq-001", category="Code Quality", issue_type="NEUTRAL", severity="MEDIUM"),
            _rule(rid="cq-002", category="Code Quality", issue_type="booster", severity="INFO"),
        ],
    )
    assert items[0].assessment_schema["category"] == "Code Quality"
    assert items[0].assessment_schema["issueType"] == "NEUTRAL"
    assert items[0].assessment_schema["severity"] == "MEDIUM"
    assert "remediation" in items[0].assessment_schema
    assert items[1].assessment_schema["issueType"] == "booster"
    assert items[1].assessment_schema["remediation"] == {}


# ---------------------------------------------------------------------------
# validate_batch_request
# ---------------------------------------------------------------------------
def test_validate_batch_missing_analysis_id():
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(analysisId="x", rules=[_rule()])
    req.analysis_id = ""  # bypass model to hit branch
    with pytest.raises(ValidationError) as ei:
        handler.validate_batch_request(req)
    assert ei.value.field == "analysisId"


def test_validate_batch_bad_analysis_id():
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(analysisId="ok", rules=[_rule()])
    req.analysis_id = "bad;id"
    with pytest.raises(ValidationError):
        handler.validate_batch_request(req)


def test_validate_batch_too_many_rules():
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(analysisId="ok", rules=[_rule()])
    req.rules = [_rule(rid=f"R{i}") for i in range(handler.max_rules + 1)]
    with pytest.raises(ValidationError) as ei:
        handler.validate_batch_request(req)
    assert ei.value.field == "rules"


@pytest.mark.parametrize("field,kwargs", [
    ("ruleId", {"rid": "  "}),
    ("name", {"name": " "}),
    ("description", {"desc": " "}),
    ("domain", {"domain": " "}),
    ("language", {"language": " "}),
    ("category", {"category": " "}),
    ("issueType", {"issue_type": " "}),
    ("severity", {"severity": " "}),
])
def test_validate_batch_missing_rule_fields(field, kwargs):
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(analysisId="ok", rules=[_rule()])
    # Build a rule that bypasses model validation by mutating attribute
    bad = _rule()
    setattr(bad, {
        "ruleId": "rule_id", "name": "name", "description": "description",
        "domain": "domain", "language": "language", "category": "category",
        "issueType": "issue_type", "severity": "severity",
    }[field], list(kwargs.values())[0])
    req.rules = [bad]
    with pytest.raises(ValidationError) as ei:
        handler.validate_batch_request(req)
    assert field in ei.value.field


def test_validate_batch_bad_project_path():
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(
        analysisId="ok", rules=[_rule()], projectPath="/bad;path"
    )
    with pytest.raises(ValidationError) as ei:
        handler.validate_batch_request(req)
    assert ei.value.field == "projectPath"


def test_validate_batch_ok():
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(
        analysisId="ok-1", rules=[_rule()], projectPath="/tmp/work"
    )
    handler.validate_batch_request(req)  # no raise


# ---------------------------------------------------------------------------
# get_timeout / validate_request / execute
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, _ = _make_handler()
    assert handler.get_timeout() == mod.settings.timeouts.assessment_rules_batch


def test_validate_request_noop():
    handler, _ = _make_handler()
    assert handler.validate_request(MagicMock()) is None


async def test_execute_raises():
    handler, _ = _make_handler()
    with pytest.raises(ValidationError):
        await handler.execute(MagicMock())


# ---------------------------------------------------------------------------
# execute_batch
# ---------------------------------------------------------------------------
async def test_execute_batch_success(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    obj = {
        "ruleId": "R1",
        "detectionSchema": {"detectionCriteria": {"fileType": ["java"]}, "language": "java"},
        "assessmentSchema": {"description": "d"},
    }
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=_assistant_events(json.dumps([obj]))
    )
    req = AssessmentRulesBatchRequest(analysisId="batch1", rules=[_rule()])
    resp = await handler.execute_batch(req)
    assert resp.status == "success"
    assert resp.is_final is True
    assert resp.chunk_count == 1
    assert resp.rule_count_returned == 1
    assert resp.rules[0].rule_id == "R1"
    provider.invoke_with_tools_agentic.assert_awaited_once()
    call_kw = provider.invoke_with_tools_agentic.await_args.kwargs
    assert call_kw["enable_tools"] is False
    assert call_kw["prepend_project_context"] is False
    # stream artifact is written only on failure paths
    stream = tmp_path / "assessment-rules-batch" / "batch1" / "_claude" / "assessment-rules-batch-stream.json"
    assert not stream.exists()


async def test_execute_batch_parse_error(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=_assistant_events("totally not json")
    )
    req = AssessmentRulesBatchRequest(analysisId="batch2", rules=[_rule()])
    resp = await handler.execute_batch(req)
    assert resp.status == "error"
    assert "valid JSON array" in resp.message
    assert resp.raw_response is not None
    stream = (
        tmp_path
        / "assessment-rules-batch"
        / "batch2"
        / "_claude"
        / "assessment-rules-batch-stream-chunk-1.json"
    )
    assert stream.exists()


async def test_execute_batch_count_mismatch(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    # 2 objects returned but only 1 rule expected
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=_assistant_events(json.dumps([{"ruleId": "R1"}, {"ruleId": "R2"}]))
    )
    req = AssessmentRulesBatchRequest(analysisId="batch3", rules=[_rule()])
    resp = await handler.execute_batch(req)
    assert resp.status == "error"
    assert "mismatch" in resp.message
    assert resp.rule_count_returned == 2
    stream = (
        tmp_path
        / "assessment-rules-batch"
        / "batch3"
        / "_claude"
        / "assessment-rules-batch-stream-chunk-1.json"
    )
    assert stream.exists()


async def test_execute_batch_long_raw_response_truncated(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    long_text = "x" * 25000  # not a valid json array
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=_assistant_events(long_text)
    )
    req = AssessmentRulesBatchRequest(analysisId="batch4", rules=[_rule()])
    resp = await handler.execute_batch(req)
    assert resp.status == "error"
    assert len(resp.raw_response) == 20000


async def test_execute_batch_provider_exception(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(side_effect=RuntimeError("boom"))
    req = AssessmentRulesBatchRequest(analysisId="batch5", rules=[_rule()])
    resp = await handler.execute_batch(req)
    assert resp.status == "error"
    assert "boom" in resp.error_details


async def test_execute_batch_uses_secure_workspace_without_project_path(
    monkeypatch, tmp_path
):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, provider = _make_handler()
    obj = {
        "ruleId": "R1",
        "detectionSchema": {
            "detectionCriteria": {"fileType": ["java"]},
            "language": "java",
        },
        "assessmentSchema": {"description": "d"},
    }
    provider.invoke_with_tools_agentic = AsyncMock(
        return_value=_assistant_events(json.dumps([obj]))
    )
    req = AssessmentRulesBatchRequest(analysisId="secure-batch", rules=[_rule()])
    await handler.execute_batch(req)
    project_path = provider.invoke_with_tools_agentic.await_args.kwargs["project_path"]
    assert "/tmp" not in project_path
    assert str(tmp_path) in project_path


async def test_execute_batch_validation_error_propagates(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    req = AssessmentRulesBatchRequest(analysisId="ok", rules=[_rule()])
    req.analysis_id = "bad;id"
    with pytest.raises(ValidationError):
        await handler.execute_batch(req)


def test_split_rules_into_chunks():
    rules = [_rule(rid=f"R{i}") for i in range(12)]
    chunks = _split_rules_into_chunks(rules, 5)
    assert len(chunks) == 3
    assert [len(c) for c in chunks] == [5, 5, 2]


def test_split_rules_single_chunk():
    rules = [_rule(rid="R1"), _rule(rid="R2")]
    chunks = _split_rules_into_chunks(rules, 5)
    assert chunks == [rules]


async def test_execute_batch_multi_chunk(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 2)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 1)
    handler, provider = _make_handler()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {"description": rid},
        }

    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=[
            _assistant_events(json.dumps([_obj("R1"), _obj("R2")])),
            _assistant_events(json.dumps([_obj("R3")])),
        ]
    )
    req = AssessmentRulesBatchRequest(
        analysisId="multi",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    resp = await handler.execute_batch(req)
    assert resp.status == "success"
    assert resp.is_final is True
    assert resp.chunk_count == 2
    assert resp.rule_count_returned == 3
    assert len(resp.rules) == 3
    assert provider.invoke_with_tools_agentic.await_count == 2


async def test_execute_batch_progress_callback(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 2)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 1)
    handler, provider = _make_handler()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {},
        }

    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=[
            _assistant_events(json.dumps([_obj("R1"), _obj("R2")])),
            _assistant_events(json.dumps([_obj("R3")])),
        ]
    )
    published = []

    async def on_progress(response):
        published.append(response)

    req = AssessmentRulesBatchRequest(
        analysisId="progress",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    await handler.execute_batch(req, on_progress=on_progress)
    assert len(published) == 2
    assert published[0].status == "partial"
    assert published[0].is_final is False
    assert published[0].rule_count_returned == 2
    assert published[0].rules_completed_so_far == 2
    assert published[1].status == "success"
    assert published[1].is_final is True
    assert published[1].rule_count_returned == 1
    assert published[1].rules_completed_so_far == 3


async def test_execute_batch_chunk_failure_publishes_error(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 2)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 1)
    handler, provider = _make_handler()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {},
        }

    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=[
            _assistant_events(json.dumps([_obj("R1"), _obj("R2")])),
            RuntimeError("chunk2 boom"),
        ]
    )
    published = []

    async def on_progress(response):
        published.append(response)

    req = AssessmentRulesBatchRequest(
        analysisId="fail-mid",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    resp = await handler.execute_batch(req, on_progress=on_progress)
    assert resp.status == "error"
    assert resp.is_final is True
    assert resp.rules_completed_so_far == 2
    assert len(published) == 2
    assert published[0].status == "partial"
    assert published[1].status == "error"


async def test_execute_batch_parallel_merges_in_chunk_order(monkeypatch, tmp_path):
    """Chunks may finish out of order; final rules stay in input order."""
    import asyncio

    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 1)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 3)
    handler, provider = _make_handler()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {"description": rid},
        }

    async def invoke(**kwargs):
        prompt = kwargs["prompt"]
        if "ruleId: R1" in prompt:
            await asyncio.sleep(0.05)
            return _assistant_events(json.dumps([_obj("R1")]))
        if "ruleId: R2" in prompt:
            await asyncio.sleep(0.01)
            return _assistant_events(json.dumps([_obj("R2")]))
        return _assistant_events(json.dumps([_obj("R3")]))

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=invoke)
    req = AssessmentRulesBatchRequest(
        analysisId="parallel-order",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    resp = await handler.execute_batch(req)
    assert resp.status == "success"
    assert resp.chunk_count == 3
    assert [r.rule_id for r in resp.rules] == ["R1", "R2", "R3"]
    assert provider.invoke_with_tools_agentic.await_count == 3


async def test_execute_batch_parallel_chunks_overlap(monkeypatch, tmp_path):
    """With max_parallel_chunks > 1, multiple chunk LLM calls run concurrently."""
    import asyncio

    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 1)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 3)
    handler, provider = _make_handler()

    active = 0
    max_active = 0
    lock = asyncio.Lock()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {"description": rid},
        }

    async def invoke(**kwargs):
        nonlocal active, max_active
        async with lock:
            active += 1
            max_active = max(max_active, active)
        await asyncio.sleep(0.04)
        prompt = kwargs["prompt"]
        rid = "R1"
        if "ruleId: R2" in prompt:
            rid = "R2"
        elif "ruleId: R3" in prompt:
            rid = "R3"
        async with lock:
            active -= 1
        return _assistant_events(json.dumps([_obj(rid)]))

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=invoke)
    req = AssessmentRulesBatchRequest(
        analysisId="parallel-overlap",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    resp = await handler.execute_batch(req)
    assert resp.status == "success"
    assert max_active >= 2


async def test_execute_batch_sequential_when_max_parallel_one(monkeypatch, tmp_path):
    """With max_parallel_chunks=1, chunk LLM calls stay non-overlapping."""
    import asyncio

    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 1)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 1)
    handler, provider = _make_handler()

    active = 0
    max_active = 0
    lock = asyncio.Lock()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {"description": rid},
        }

    async def invoke(**kwargs):
        nonlocal active, max_active
        async with lock:
            active += 1
            max_active = max(max_active, active)
        await asyncio.sleep(0.02)
        prompt = kwargs["prompt"]
        rid = "R2" if "ruleId: R2" in prompt else "R1"
        async with lock:
            active -= 1
        return _assistant_events(json.dumps([_obj(rid)]))

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=invoke)
    req = AssessmentRulesBatchRequest(
        analysisId="sequential",
        rules=[_rule(rid="R1"), _rule(rid="R2")],
    )
    resp = await handler.execute_batch(req)
    assert resp.status == "success"
    assert max_active == 1
    assert [r.rule_id for r in resp.rules] == ["R1", "R2"]


async def test_execute_batch_parallel_fail_fast_cancels_pending(monkeypatch, tmp_path):
    """On chunk error, remaining in-flight chunks are cancelled (fail-fast)."""
    import asyncio
    import time

    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 1)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 3)
    # Avoid retry/timeout stack delaying cancel under test.
    monkeypatch.setattr(
        mod,
        "with_resilience",
        lambda **_kwargs: (lambda fn: fn),
    )
    handler, provider = _make_handler()

    started = asyncio.Event()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {},
        }

    async def invoke(**kwargs):
        prompt = kwargs["prompt"]
        if "ruleId: R1" in prompt:
            started.set()
            await asyncio.sleep(5.0)
            return _assistant_events(json.dumps([_obj("R1")]))
        if "ruleId: R2" in prompt:
            await started.wait()
            raise RuntimeError("chunk2 boom")
        return _assistant_events(json.dumps([_obj("R3")]))

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=invoke)
    published = []

    async def on_progress(response):
        published.append(response)

    req = AssessmentRulesBatchRequest(
        analysisId="parallel-fail",
        rules=[_rule(rid="R1"), _rule(rid="R2"), _rule(rid="R3")],
    )
    t0 = time.monotonic()
    resp = await handler.execute_batch(req, on_progress=on_progress)
    elapsed = time.monotonic() - t0
    assert resp.status == "error"
    assert "boom" in (resp.error_details or "")
    assert any(p.status == "error" for p in published)
    # Fail-fast must not wait for the slow cancelled chunk (5s sleep).
    assert elapsed < 2.0
    assert resp.rules_completed_so_far is not None
    assert resp.rules_completed_so_far < 3


async def test_execute_batch_queues_concurrent_requests(monkeypatch, tmp_path):
    """With max_concurrent_requests=1, the second batch waits for the first."""
    import asyncio

    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_concurrent_requests", 1)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "chunk_size", 5)
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "max_parallel_chunks", 1)
    _reset_batch_request_semaphore_for_tests()

    handler, provider = _make_handler()
    order = []
    first_started = asyncio.Event()
    release_first = asyncio.Event()

    def _obj(rid):
        return {
            "ruleId": rid,
            "detectionSchema": {
                "detectionCriteria": {"fileType": ["java"]},
                "language": "java",
            },
            "assessmentSchema": {"description": rid},
        }

    async def invoke(**kwargs):
        analysis_marker = kwargs["prompt"]
        if "ruleId: A1" in analysis_marker:
            order.append("A_start")
            first_started.set()
            await release_first.wait()
            order.append("A_end")
            return _assistant_events(json.dumps([_obj("A1")]))
        order.append("B_start")
        return _assistant_events(json.dumps([_obj("B1")]))

    provider.invoke_with_tools_agentic = AsyncMock(side_effect=invoke)

    # Bypass resilience stack so sleeps/events are deterministic.
    monkeypatch.setattr(mod, "with_resilience", lambda **_kwargs: (lambda fn: fn))

    async def run_a():
        return await handler.execute_batch(
            AssessmentRulesBatchRequest(
                analysisId="batch-a",
                rules=[_rule(rid="A1")],
            )
        )

    async def run_b():
        await first_started.wait()
        return await handler.execute_batch(
            AssessmentRulesBatchRequest(
                analysisId="batch-b",
                rules=[_rule(rid="B1")],
            )
        )

    task_a = asyncio.create_task(run_a())
    task_b = asyncio.create_task(run_b())
    await first_started.wait()
    await asyncio.sleep(0.05)
    # B must still be waiting for the request slot; only A has started LLM.
    assert order == ["A_start"]
    release_first.set()
    resp_a, resp_b = await asyncio.gather(task_a, task_b)
    assert resp_a.status == "success"
    assert resp_b.status == "success"
    assert order == ["A_start", "A_end", "B_start"]


async def test_execute_batch_retries_rate_limit_then_succeeds(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "rate_limit_max_retries", 5)
    monkeypatch.setattr(mod.settings.llm_rate_limiter, "throttle_recovery", 0.01)
    monkeypatch.setattr(mod, "with_resilience", lambda **_kwargs: (lambda fn: fn))
    _reset_batch_request_semaphore_for_tests()

    handler, provider = _make_handler()
    obj = {
        "ruleId": "R1",
        "detectionSchema": {
            "detectionCriteria": {"fileType": ["java"]},
            "language": "java",
        },
        "assessmentSchema": {"description": "d"},
    }
    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=[
            RateLimitError(message="throttled", retry_after=0),
            RateLimitError(message="throttled", retry_after=0),
            _assistant_events(json.dumps([obj])),
        ]
    )
    resp = await handler.execute_batch(
        AssessmentRulesBatchRequest(analysisId="rl-ok", rules=[_rule()])
    )
    assert resp.status == "success"
    assert resp.rule_count_returned == 1
    assert provider.invoke_with_tools_agentic.await_count == 3


async def test_execute_batch_rate_limit_retries_exhausted(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.assessment_rules_batch, "rate_limit_max_retries", 2)
    monkeypatch.setattr(mod.settings.llm_rate_limiter, "throttle_recovery", 0.01)
    monkeypatch.setattr(mod, "with_resilience", lambda **_kwargs: (lambda fn: fn))
    _reset_batch_request_semaphore_for_tests()

    handler, provider = _make_handler()
    provider.invoke_with_tools_agentic = AsyncMock(
        side_effect=RateLimitError(message="throttled", retry_after=0)
    )
    resp = await handler.execute_batch(
        AssessmentRulesBatchRequest(analysisId="rl-fail", rules=[_rule()])
    )
    assert resp.status == "error"
    assert "RateLimitError" in resp.message
    assert "after 2 retries" in resp.message
    # Initial attempt + 2 slept retries = 3 calls, then fail on 3rd RateLimitError.
    assert provider.invoke_with_tools_agentic.await_count == 3
