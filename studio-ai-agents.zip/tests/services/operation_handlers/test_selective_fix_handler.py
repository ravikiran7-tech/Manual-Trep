"""Tests for SelectiveFixHandler."""
import subprocess
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import ValidationError
from app.models.requests import ClaudeCliRequest
import app.services.operation_handlers.selective_fix_handler as mod
from app.services.operation_handlers.selective_fix_handler import SelectiveFixHandler


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=[])
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    return SelectiveFixHandler(provider_factory=factory), provider


def _req(**kw):
    base = dict(projectPath="/projects/app", analysisId="sel-1",
                operation="selective-fix", prompt="/tmp/p.txt")
    base.update(kw)
    return ClaudeCliRequest(**base)


def _ok_events():
    return [
        {"type": "assistant", "subtype": "text_delta",
         "text": '```json\n{"fixed": true}\n```'},
        {"type": "result", "is_error": False, "input_tokens": 1, "output_tokens": 2},
    ]


# ---------------------------------------------------------------------------
# basics / validation
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, _ = _make_handler()
    assert handler.get_timeout() == mod.settings.timeouts.upgrade_operations


def test_validate_request_missing_prompt():
    handler, _ = _make_handler()
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(_req(prompt=None))
    assert ei.value.field == "prompt"


def test_validate_request_ok():
    handler, _ = _make_handler()
    handler.validate_request(_req())


def test_get_output_directory_containerization():
    handler, _ = _make_handler()
    assert handler.get_output_directory(_req()) == "containerization"


# ---------------------------------------------------------------------------
# _detect_project_type
# ---------------------------------------------------------------------------
def test_detect_project_type_explicit():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(projectType="DotNet")) == "dotnet"


def test_detect_project_type_dotnet_version():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(dotnetVersion="8.0")) == "dotnet"


def test_detect_project_type_java_version():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(javaVersion="17")) == "java"


def test_detect_project_type_sln(tmp_path):
    handler, _ = _make_handler()
    (tmp_path / "app.sln").write_text("")
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "dotnet"


def test_detect_project_type_pom(tmp_path):
    handler, _ = _make_handler()
    (tmp_path / "pom.xml").write_text("<project/>")
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "java"


def test_detect_project_type_default(tmp_path):
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "java"


# ---------------------------------------------------------------------------
# _run_build
# ---------------------------------------------------------------------------
async def test_run_build_dotnet_success(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=0, stdout="ok", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "dotnet")
    assert out["success"] is True


async def test_run_build_java_with_errors(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=1, stdout="[ERROR] cannot find symbol", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "java")
    assert out["error_count"] == 1


async def test_run_build_unknown(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "weird")
    assert out["success"] is True


async def test_run_build_timeout(monkeypatch):
    handler, _ = _make_handler()
    def boom(*a, **k):
        raise subprocess.TimeoutExpired(cmd="mvn", timeout=600)
    monkeypatch.setattr(mod.subprocess, "run", boom)
    out = await handler._run_build("/p", "java")
    assert "timeout" in out["errors"][0].lower()


async def test_run_build_exception(monkeypatch):
    handler, _ = _make_handler()
    def boom(*a, **k):
        raise OSError("nope")
    monkeypatch.setattr(mod.subprocess, "run", boom)
    out = await handler._run_build("/p", "java")
    assert "Build error" in out["errors"][0]


# ---------------------------------------------------------------------------
# _extract_error_lines / _categorize_errors / _sanitize
# ---------------------------------------------------------------------------
def test_extract_error_lines_dotnet():
    handler, _ = _make_handler()
    output = "\n".join([
        "Foo.cs(10,5): error CS0246: type not found",
        "App.csproj(1,1): error MSB4068: bad",
        "error MSB3644: ref",
        "error : mismatched tag",
        "noise",
    ])
    errors = handler._extract_error_lines(output, "dotnet")
    assert len(errors) == 4


def test_extract_error_lines_java():
    handler, _ = _make_handler()
    output = "[ERROR] compilation failure\nerror: cannot find symbol"
    errors = handler._extract_error_lines(output, "java")
    assert len(errors) == 2


def test_extract_error_lines_dedup():
    handler, _ = _make_handler()
    output = "\n".join([
        "Foo.cs(1,1): error CS0246: x",
        "Foo.cs(1,1): error CS0246: x",  # duplicate -> hits dedup skip branch
        "Bar.cs(2,2): error CS0103: y",
    ])
    errors = handler._extract_error_lines(output, "dotnet")
    assert len(errors) == 2


def test_categorize_dotnet():
    handler, _ = _make_handler()
    errors = [
        "Foo.cs(1,1): error CS0246: msg [x.csproj]",
        "Bar.csproj(1,1): error MSB4068: bad [y]",
        "error MSB9999:",
        "error CS1111:",
        "xml mismatched tag parse",
        "other",
    ]
    cats = handler._categorize_errors(errors, "dotnet")
    assert "XML_PARSE_ERROR" in cats
    assert "DOTNET_OTHER" in cats
    assert "MSB9999" in cats
    assert "CS1111" in cats


def test_categorize_java():
    handler, _ = _make_handler()
    errors = [
        "cannot find symbol",
        "package does not exist",
        "incompatible types",
        "method foo cannot be applied",
        "class Foo is public",
        "other",
    ]
    cats = handler._categorize_errors(errors, "java")
    assert set(cats) == {
        "SYMBOL_NOT_FOUND", "PACKAGE_MISSING", "TYPE_MISMATCH",
        "METHOD_SIGNATURE", "CLASS_FILE_MISMATCH", "JAVA_OTHER",
    }


def test_sanitize_category_name():
    handler, _ = _make_handler()
    assert handler._sanitize_category_name("a b!c") == "A_B_C"


def test_generate_fix_prompt_dotnet():
    handler, _ = _make_handler()
    p = handler._generate_fix_prompt({"CS0246_X": ["e"]}, "dotnet", 1, 1)
    assert "C# Compilation Errors" in p


def test_generate_fix_prompt_java():
    handler, _ = _make_handler()
    p = handler._generate_fix_prompt({"X": ["e"]}, "java", 1, 1)
    assert "Symbol not found" in p


# ---------------------------------------------------------------------------
# _run_post_transformation_fixes
# ---------------------------------------------------------------------------
async def test_post_transform_build_success(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": True, "errors": [], "error_count": 0}))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    assert any(e["type"] == "build_success" for e in events)


async def test_post_transform_fix_complete(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    builds = [
        {"success": False, "errors": ["[ERROR] cannot find symbol"], "error_count": 1},
        {"success": True, "errors": [], "error_count": 0},
        {"success": True, "errors": [], "error_count": 0},
    ]
    monkeypatch.setattr(handler, "_run_build", AsyncMock(side_effect=builds))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": False}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    assert any(e["type"] == "fix_iteration_complete" for e in events)


async def test_post_transform_fix_failed(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": True}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    assert any(e["type"] == "fix_iteration_failed" for e in events)


async def test_post_transform_fix_error(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(side_effect=RuntimeError("boom")))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    assert any(e["type"] == "fix_iteration_error" for e in events)


# ---------------------------------------------------------------------------
# execute
# ---------------------------------------------------------------------------
async def _setup_execute(monkeypatch, tmp_path, events, graph=True):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.agentic, "graph_orchestration_enabled", graph)
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "read_prompt_file", lambda p, r=None: "PROMPT")
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    monkeypatch.setattr(handler, "_run_post_transformation_fixes",
                        AsyncMock(side_effect=lambda req, prov, ev: ev + [{"type": "final_build_status", "success": True, "remaining_errors": 0}]))
    return handler, provider


async def test_execute_success(monkeypatch, tmp_path):
    handler, _ = await _setup_execute(monkeypatch, tmp_path, _ok_events())
    resp = await handler.execute(_req())
    assert resp.status == "success"
    assert "automatic error fixing" in resp.message


async def test_execute_success_legacy(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events(), graph=False)
    resp = await handler.execute(_req())
    assert resp.status == "success"
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_execute_transformation_failed(monkeypatch, tmp_path):
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "x"},
        {"type": "result", "is_error": True, "error": "sel failed"},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.error == "sel failed"


async def test_execute_transformation_failed_default_msg(monkeypatch, tmp_path):
    events = [{"type": "assistant", "subtype": "text_delta", "text": "x"}]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.error == "Selective fix failed"


async def test_execute_validation_error_propagates(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    with pytest.raises(ValidationError):
        await handler.execute(_req(prompt=None))


async def test_execute_inner_exception_reraised(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events())
    provider.invoke_with_tools_agentic_graph = AsyncMock(side_effect=RuntimeError("boom"))
    with pytest.raises(RuntimeError):
        await handler.execute(_req())


async def test_execute_no_json_result(monkeypatch, tmp_path):
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "no json"},
        {"type": "result", "is_error": False},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "success"


async def test_post_transform_all_iterations_no_break(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": False}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    completes = [e for e in events if e["type"] == "fix_iteration_complete"]
    assert len(completes) == handler.MAX_FIX_ITERATIONS