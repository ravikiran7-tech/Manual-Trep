"""Tests for TestCreationHandler (test-creation operation)."""
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.operation_handlers.test_creation_handler import TestCreationHandler
from app.core.exceptions import ValidationError
from app.core import resilience as resilience_mod


def _result_event(is_error=False):
    return {"type": "result", "is_error": is_error, "input_tokens": 5, "output_tokens": 7}


def _assistant_json_event(payload):
    return {"type": "assistant", "subtype": "text_delta",
            "text": "```json\n" + json.dumps(payload) + "\n```"}


def _reset_all_breakers():
    for b in (
        resilience_mod.bedrock_circuit_breaker,
        resilience_mod.portkey_circuit_breaker,
        resilience_mod.compass_circuit_breaker,
    ):
        try:
            b.close()
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _reset_breaker(monkeypatch):
    _reset_all_breakers()
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_min", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_wait_max", 0, raising=False)
    monkeypatch.setattr(resilience_mod.settings.resilience, "retry_multiplier", 0, raising=False)
    yield
    _reset_all_breakers()


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    from app.services.operation_handlers import test_creation_handler as mod
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path), raising=False)
    return tmp_path


@pytest.fixture
def prompt_file(tmp_path):
    p = tmp_path / "prompt.txt"
    p.write_text("Generate tests.", encoding="utf-8")
    return str(p).replace("\\", "/")


def _make_handler(events=None, provider_side_effect=None):
    provider = MagicMock()
    invoke = AsyncMock()
    if provider_side_effect is not None:
        invoke.side_effect = provider_side_effect
    else:
        invoke.return_value = events if events is not None else []
    provider.invoke_with_tools_agentic_graph = invoke
    provider.invoke_with_tools_agentic = invoke
    factory = MagicMock()
    factory.get_provider = AsyncMock(return_value=provider)
    return TestCreationHandler(provider_factory=factory), provider, invoke


def _make_request(prompt, project_path="/projects/app", analysis_id="tc-123",
                  project_type=None, dotnet_version=None, java_version=None):
    from app.models.requests import ClaudeCliRequest
    return ClaudeCliRequest(
        prompt=prompt,
        projectPath=project_path,
        analysisId=analysis_id,
        operation="test-creation",
        projectType=project_type,
        dotnetVersion=dotnet_version,
        javaVersion=java_version,
    )


# --------------------------- unit methods ---------------------------
def test_get_timeout():
    handler, *_ = _make_handler()
    assert handler.get_timeout() == handler.settings.timeouts.upgrade_operations


def test_validate_request_ok(prompt_file):
    handler, *_ = _make_handler()
    handler.validate_request(_make_request(prompt_file))


def test_validate_request_missing_prompt():
    handler, *_ = _make_handler()
    with pytest.raises(ValidationError):
        handler.validate_request(_make_request(None))


def test_detect_project_type_explicit():
    handler, *_ = _make_handler()
    assert handler._detect_project_type(_make_request("x", project_type="DotNet")) == "dotnet"


def test_detect_project_type_from_dotnet_version():
    handler, *_ = _make_handler()
    assert handler._detect_project_type(_make_request("x", dotnet_version="8.0")) == "dotnet"


def test_detect_project_type_from_java_version():
    handler, *_ = _make_handler()
    assert handler._detect_project_type(_make_request("x", java_version="17")) == "java"


def test_detect_project_type_csproj(tmp_path):
    handler, *_ = _make_handler()
    (tmp_path / "proj.csproj").write_text("<Project/>", encoding="utf-8")
    req = _make_request("x", project_path=str(tmp_path).replace("\\", "/"))
    assert handler._detect_project_type(req) == "dotnet"


def test_detect_project_type_maven(tmp_path):
    handler, *_ = _make_handler()
    (tmp_path / "pom.xml").write_text("<project/>", encoding="utf-8")
    req = _make_request("x", project_path=str(tmp_path).replace("\\", "/"))
    assert handler._detect_project_type(req) == "java"


def test_detect_project_type_python(tmp_path):
    handler, *_ = _make_handler()
    (tmp_path / "setup.py").write_text("setup()", encoding="utf-8")
    req = _make_request("x", project_path=str(tmp_path).replace("\\", "/"))
    assert handler._detect_project_type(req) == "python"


def test_detect_project_type_default_java(tmp_path):
    handler, *_ = _make_handler()
    empty = tmp_path / "empty"
    empty.mkdir()
    req = _make_request("x", project_path=str(empty).replace("\\", "/"))
    assert handler._detect_project_type(req) == "java"


def test_framework_guidance_branches():
    handler, *_ = _make_handler()
    assert ".NET 8.0" in handler._get_framework_guidance("dotnet", _make_request("x"))
    assert "Java 17" in handler._get_framework_guidance("java", _make_request("x"))
    assert "pytest" in handler._get_framework_guidance("python", _make_request("x"))
    assert "General" in handler._get_framework_guidance("ruby", _make_request("x"))


def test_enhance_prompt_with_framework_guidance():
    handler, *_ = _make_handler()
    out = handler._enhance_prompt_with_framework_guidance("ORIG", "python", _make_request("x"))
    assert "ORIG" in out and "PYTHON" in out


# --------------------------- execute ---------------------------
async def test_execute_success(workspace, prompt_file):
    events = [_assistant_json_event({"tests": []}), _result_event(False)]
    handler, _, invoke = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file, project_type="python"))
    assert resp.status == "success"
    invoke.assert_awaited()
    result = Path(resp.output_file_path).parent / "test-creation-result.json"
    assert result.exists()


async def test_execute_success_no_json(workspace, prompt_file):
    events = [{"type": "assistant", "subtype": "text_delta", "text": "plain"}, _result_event(False)]
    handler, *_ = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file, project_type="java"))
    assert resp.status == "success"


async def test_execute_failure(workspace, prompt_file):
    events = [{"type": "error", "error": "gen failed"}, _result_event(True)]
    handler, *_ = _make_handler(events=events)
    resp = await handler.execute(_make_request(prompt_file, project_type="dotnet"))
    assert resp.status == "error"
    assert "gen failed" in resp.message


async def test_execute_validation_raises(workspace):
    handler, *_ = _make_handler(events=[])
    with pytest.raises(ValidationError):
        await handler.execute(_make_request(None))


async def test_execute_provider_failure_propagates(workspace, prompt_file):
    handler, *_ = _make_handler(provider_side_effect=RuntimeError("down"))
    with pytest.raises(RuntimeError):
        await handler.execute(_make_request(prompt_file, project_type="python"))