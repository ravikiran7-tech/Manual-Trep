"""Tests for FixUpgradeHandler."""
import subprocess
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.exceptions import ValidationError
from app.models.requests import ClaudeCliRequest
import app.services.operation_handlers.fix_upgrade_handler as mod
from app.services.operation_handlers.fix_upgrade_handler import FixUpgradeHandler


def _make_handler():
    factory = MagicMock()
    provider = MagicMock()
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=[])
    provider.invoke_with_tools_agentic = AsyncMock(return_value=[])
    factory.get_provider = AsyncMock(return_value=provider)
    return FixUpgradeHandler(provider_factory=factory), provider


def _req(**kw):
    base = dict(projectPath="/projects/app", analysisId="fix-1",
                operation="fix-upgrade", prompt="/tmp/p.txt")
    base.update(kw)
    return ClaudeCliRequest(**base)


def _ok_events():
    return [
        {"type": "assistant", "subtype": "text_delta",
         "text": '```json\n{"fixed": true}\n```'},
        {"type": "result", "is_error": False, "input_tokens": 1, "output_tokens": 2},
    ]


# ---------------------------------------------------------------------------
# basics / validation
# ---------------------------------------------------------------------------
def test_get_timeout():
    handler, _ = _make_handler()
    assert handler.get_timeout() == mod.settings.timeouts.upgrade_operations


def test_validate_request_missing_prompt():
    handler, _ = _make_handler()
    with pytest.raises(ValidationError) as ei:
        handler.validate_request(_req(prompt=None))
    assert ei.value.field == "prompt"


def test_validate_request_ok():
    handler, _ = _make_handler()
    handler.validate_request(_req())


# ---------------------------------------------------------------------------
# _detect_project_type
# ---------------------------------------------------------------------------
def test_detect_project_type_explicit():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(projectType="DotNet")) == "dotnet"


def test_detect_project_type_dotnet_version():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(dotnetVersion="8.0")) == "dotnet"


def test_detect_project_type_java_version():
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(javaVersion="17")) == "java"


def test_detect_project_type_csproj(tmp_path):
    handler, _ = _make_handler()
    (tmp_path / "app.csproj").write_text("<Project/>")
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "dotnet"


def test_detect_project_type_pom(tmp_path):
    handler, _ = _make_handler()
    (tmp_path / "pom.xml").write_text("<project/>")
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "java"


def test_detect_project_type_gradle(tmp_path):
    handler, _ = _make_handler()
    (tmp_path / "build.gradle").write_text("")
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "java"


def test_detect_project_type_default(tmp_path):
    handler, _ = _make_handler()
    assert handler._detect_project_type(_req(projectPath=str(tmp_path))) == "java"


# ---------------------------------------------------------------------------
# _run_build
# ---------------------------------------------------------------------------
async def test_run_build_dotnet_success(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=0, stdout="ok", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "dotnet")
    assert out["success"] is True
    assert out["error_count"] == 0


async def test_run_build_java_with_errors(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=1,
                    stdout="[ERROR] cannot find symbol foo", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "java")
    assert out["success"] is False
    assert out["error_count"] == 1


async def test_run_build_unknown_type(monkeypatch):
    handler, _ = _make_handler()
    res = MagicMock(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(mod.subprocess, "run", lambda *a, **k: res)
    out = await handler._run_build("/p", "weird")
    assert out["success"] is True


async def test_run_build_timeout(monkeypatch):
    handler, _ = _make_handler()
    def boom(*a, **k):
        raise subprocess.TimeoutExpired(cmd="mvn", timeout=600)
    monkeypatch.setattr(mod.subprocess, "run", boom)
    out = await handler._run_build("/p", "java")
    assert out["success"] is False
    assert "timeout" in out["errors"][0].lower()


async def test_run_build_generic_exception(monkeypatch):
    handler, _ = _make_handler()
    def boom(*a, **k):
        raise OSError("no mvn")
    monkeypatch.setattr(mod.subprocess, "run", boom)
    out = await handler._run_build("/p", "java")
    assert out["success"] is False
    assert "Build error" in out["errors"][0]


# ---------------------------------------------------------------------------
# _extract_error_lines
# ---------------------------------------------------------------------------
def test_extract_error_lines_dotnet_patterns():
    handler, _ = _make_handler()
    output = "\n".join([
        "Foo.cs(10,5): error CS0246: type not found",
        "App.csproj(1,1): error MSB4068: bad xml",
        "error MSB3644: ref not found",
        "error : mismatched tag here",
        "irrelevant line",
        "Foo.cs(10,5): error CS0246: type not found",  # duplicate
    ])
    errors = handler._extract_error_lines(output, "dotnet")
    assert len(errors) == 4  # dedup removes the duplicate


def test_extract_error_lines_java():
    handler, _ = _make_handler()
    output = "\n".join([
        "[ERROR] compilation failure: stuff",
        "error: cannot find symbol",
        "[ERROR] something unrelated",
    ])
    errors = handler._extract_error_lines(output, "java")
    assert any("compilation failure" in e for e in errors)
    assert any("cannot find symbol" in e for e in errors)


def test_extract_error_lines_limit():
    handler, _ = _make_handler()
    lines = [f"File{i}.cs(1,1): error CS0246: msg{i}" for i in range(150)]
    errors = handler._extract_error_lines("\n".join(lines), "dotnet")
    assert len(errors) == 100


# ---------------------------------------------------------------------------
# _categorize_errors
# ---------------------------------------------------------------------------
def test_categorize_dotnet():
    handler, _ = _make_handler()
    errors = [
        "Foo.cs(1,1): error CS0246: The type or namespace [Foo.csproj]",
        "Bar.csproj(1,1): error MSB4068: malformed [Bar.csproj]",
        "error MSB9999:",  # msb without message match -> bare code
        "error CS1111:",   # cs without message match -> bare code
        "some xml parse mismatched tag error",
        "totally unrelated text",
    ]
    cats = handler._categorize_errors(errors, "dotnet")
    assert any(k.startswith("CS0246") for k in cats)
    assert any(k.startswith("MSB4068") for k in cats)
    assert "MSB9999" in cats
    assert "CS1111" in cats
    assert "XML_PARSE_ERROR" in cats
    assert "DOTNET_OTHER" in cats


def test_categorize_java():
    handler, _ = _make_handler()
    errors = [
        "cannot find symbol x",
        "package does not exist",
        "incompatible types",
        "method foo cannot be applied",
        "class Foo is public, should be declared in file",
        "random other error",
    ]
    cats = handler._categorize_errors(errors, "java")
    assert "SYMBOL_NOT_FOUND" in cats
    assert "PACKAGE_MISSING" in cats
    assert "TYPE_MISMATCH" in cats
    assert "METHOD_SIGNATURE" in cats
    assert "CLASS_FILE_MISMATCH" in cats
    assert "JAVA_OTHER" in cats


def test_sanitize_category_name():
    handler, _ = _make_handler()
    assert handler._sanitize_category_name("hello world! foo") == "HELLO_WORLD_FOO"


# ---------------------------------------------------------------------------
# _generate_fix_prompt
# ---------------------------------------------------------------------------
def test_generate_fix_prompt_dotnet():
    handler, _ = _make_handler()
    p = handler._generate_fix_prompt({"CS0246_X": ["e1", "e2"]}, "dotnet", 1, 2)
    assert "C# Compilation Errors" in p
    assert "Iteration 1" in p


def test_generate_fix_prompt_java():
    handler, _ = _make_handler()
    p = handler._generate_fix_prompt({"SYMBOL_NOT_FOUND": ["e1"]}, "java", 2, 1)
    assert "Symbol not found" in p


# ---------------------------------------------------------------------------
# _run_post_transformation_fixes
# ---------------------------------------------------------------------------
async def test_post_transform_build_success_first(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": True, "errors": [], "error_count": 0}))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    types = [e["type"] for e in events]
    assert "build_success" in types
    assert "final_build_status" in types


async def test_post_transform_fix_then_success(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    builds = [
        {"success": False, "errors": ["[ERROR] cannot find symbol"], "error_count": 1},
        {"success": True, "errors": [], "error_count": 0},
        {"success": True, "errors": [], "error_count": 0},  # final
    ]
    monkeypatch.setattr(handler, "_run_build", AsyncMock(side_effect=builds))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": False}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    types = [e["type"] for e in events]
    assert "fix_iteration_complete" in types


async def test_post_transform_fix_iteration_failed(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    # fixes return an error stream -> is_stream_successful False -> break
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": True}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    types = [e["type"] for e in events]
    assert "fix_iteration_failed" in types


async def test_post_transform_fix_iteration_error(monkeypatch):
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(side_effect=RuntimeError("apply fail")))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    types = [e["type"] for e in events]
    assert "fix_iteration_error" in types


# ---------------------------------------------------------------------------
# execute
# ---------------------------------------------------------------------------
async def _setup_execute(monkeypatch, tmp_path, events, graph=True):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    monkeypatch.setattr(mod.settings.agentic, "graph_orchestration_enabled", graph)
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "read_prompt_file", lambda p, r=None: "PROMPT")
    provider.invoke_with_tools_agentic_graph = AsyncMock(return_value=events)
    provider.invoke_with_tools_agentic = AsyncMock(return_value=events)
    # short-circuit post-transformation to avoid subprocess
    monkeypatch.setattr(handler, "_run_post_transformation_fixes",
                        AsyncMock(side_effect=lambda req, prov, ev: ev + [{"type": "final_build_status", "success": True, "remaining_errors": 0}]))
    return handler, provider


async def test_execute_success(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events())
    resp = await handler.execute(_req())
    assert resp.status == "success"
    assert "automatic error fixing" in resp.message


async def test_execute_success_legacy(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events(), graph=False)
    resp = await handler.execute(_req())
    assert resp.status == "success"
    provider.invoke_with_tools_agentic.assert_awaited()


async def test_execute_transformation_failed(monkeypatch, tmp_path):
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "x"},
        {"type": "result", "is_error": True, "error": "transform failed"},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.error == "transform failed"


async def test_execute_transformation_failed_default_msg(monkeypatch, tmp_path):
    events = [{"type": "result", "is_error": False}]  # no result error but success
    # Force is_stream_successful False by having no result -> actually no result -> False
    events = [{"type": "assistant", "subtype": "text_delta", "text": "x"}]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "error"
    assert resp.error == "Fix-upgrade failed"


async def test_execute_validation_error_propagates(monkeypatch, tmp_path):
    monkeypatch.setattr(mod.settings.workspace, "base_path", str(tmp_path))
    handler, _ = _make_handler()
    with pytest.raises(ValidationError):
        await handler.execute(_req(prompt=None))


async def test_execute_inner_exception_reraised(monkeypatch, tmp_path):
    handler, provider = await _setup_execute(monkeypatch, tmp_path, _ok_events())
    provider.invoke_with_tools_agentic_graph = AsyncMock(side_effect=RuntimeError("boom"))
    with pytest.raises(RuntimeError):
        await handler.execute(_req())


async def test_execute_no_json_result(monkeypatch, tmp_path):
    # success events with no json block -> result_path None -> warning branch (line 171)
    events = [
        {"type": "assistant", "subtype": "text_delta", "text": "no json"},
        {"type": "result", "is_error": False},
    ]
    handler, _ = await _setup_execute(monkeypatch, tmp_path, events)
    resp = await handler.execute(_req())
    assert resp.status == "success"


async def test_post_transform_all_iterations_no_break(monkeypatch):
    # build keeps failing, fixes keep applying successfully -> loop runs all 3 iters
    handler, provider = _make_handler()
    monkeypatch.setattr(handler, "_detect_project_type", lambda r: "java")
    monkeypatch.setattr(handler, "_run_build",
                        AsyncMock(return_value={"success": False, "errors": ["e"], "error_count": 1}))
    monkeypatch.setattr(handler, "invoke_with_provider",
                        AsyncMock(return_value=[{"type": "result", "is_error": False}]))
    events = await handler._run_post_transformation_fixes(_req(), provider, [])
    completes = [e for e in events if e["type"] == "fix_iteration_complete"]
    assert len(completes) == handler.MAX_FIX_ITERATIONS