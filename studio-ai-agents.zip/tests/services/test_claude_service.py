"""
Tests for app.services.claude_service.

ClaudeService routes requests to operation handlers. We mock the handler
classes (patched at the claude_service module level where they are imported)
so no real handler logic runs. studio-core's git step calls go to the
FakeStudioCore from tests/services/conftest.py, so no network is used.
"""
import httpx
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import app.services.claude_service as cs
from app.services.claude_service import (
    ClaudeService,
    get_claude_service,
)
from app.core.exceptions import ValidationError

pytestmark = pytest.mark.usefixtures("studio_core")


def _make_handler_class(return_value=None, side_effect=None, method="execute"):
    """Build a handler *class* whose instance has an async `method`."""
    instance = MagicMock()
    async_method = AsyncMock(return_value=return_value, side_effect=side_effect)
    setattr(instance, method, async_method)
    handler_class = MagicMock(return_value=instance)
    return handler_class, instance, async_method


def _resp(status="success"):
    r = MagicMock()
    r.status = status
    return r


@pytest.fixture
def provider_factory():
    return MagicMock(name="provider_factory")


# ---------------------------------------------------------------------------
# __init__ / construction
# ---------------------------------------------------------------------------
def test_init_with_explicit_provider_factory(provider_factory):
    svc = ClaudeService(provider_factory=provider_factory)
    assert svc.provider_factory is provider_factory
    # All registered ops present
    ops = svc.get_supported_operations()
    assert "analysis" in ops
    assert "generation" in ops
    assert "summary" in ops


def test_init_defaults_to_get_provider_factory():
    sentinel = MagicMock(name="default_factory")
    with patch.object(cs, "get_provider_factory", return_value=sentinel) as gpf:
        svc = ClaudeService()
    gpf.assert_called_once()
    assert svc.provider_factory is sentinel


# ---------------------------------------------------------------------------
# execute_non_interactive_command
# ---------------------------------------------------------------------------
def _step_request(operation="analysis", analysis_id="aid-1"):
    req = MagicMock()
    req.operation = operation
    req.java_version = None
    req.analysis_id = analysis_id
    req.project_path = "/w/project"
    return req


async def test_execute_non_interactive_success(provider_factory, studio_core):
    handler_response = _resp("success")

    async def execute(request):
        # The branch is synced before the AI step and committed only after it.
        assert studio_core.bodies("sync") == [{"analysisId": "aid-1", "projectPath": "/w/project"}]
        assert studio_core.bodies("commit-and-push") == []
        return handler_response

    handler_class, instance, exec_mock = _make_handler_class(side_effect=execute)
    svc = ClaudeService(provider_factory=provider_factory)
    svc._handler_registry["analysis"] = handler_class

    req = _step_request(operation="ANALYSIS")  # tests .lower()
    resp = await svc.execute_non_interactive_command(req)

    handler_class.assert_called_once_with(provider_factory=provider_factory)
    exec_mock.assert_awaited_once_with(req)
    assert studio_core.bodies("commit-and-push") == [
        {"analysisId": "aid-1", "projectPath": "/w/project", "commitMessage": "studio: analysis analysisId=aid-1"}
    ]
    assert resp is handler_response


async def test_execute_non_interactive_push_rejected_fails_step(provider_factory, studio_core):
    studio_core.answers["commit-and-push"] = 409
    handler_class, instance, exec_mock = _make_handler_class(return_value=_resp("success"))
    svc = ClaudeService(provider_factory=provider_factory)
    svc._handler_registry["analysis"] = handler_class

    resp = await svc.execute_non_interactive_command(_step_request())

    fixed = (
        "Git push was rejected for this step; the changes are kept on the server copy. "
        "Pull the latest branch, fix the conflict on the server copy, and re-run the step."
    )
    assert (resp.status, resp.message, resp.error, resp.exit_code) == ("error", fixed, fixed, 1)


@pytest.mark.parametrize("answer", [200, 500, httpx.ConnectError("connection refused")])
async def test_execute_non_interactive_other_answers_carry_on(provider_factory, studio_core, answer):
    studio_core.answers = {"sync": answer, "commit-and-push": answer}
    handler_response = _resp("success")
    handler_class, instance, exec_mock = _make_handler_class(return_value=handler_response)
    svc = ClaudeService(provider_factory=provider_factory)
    svc._handler_registry["analysis"] = handler_class

    resp = await svc.execute_non_interactive_command(_step_request())

    assert len(studio_core.requests) == 2
    assert resp is handler_response


async def test_execute_non_interactive_unsupported_operation(provider_factory):
    svc = ClaudeService(provider_factory=provider_factory)
    req = MagicMock()
    req.operation = "does-not-exist"
    req.java_version = None

    with pytest.raises(ValidationError) as exc:
        await svc.execute_non_interactive_command(req)
    assert exc.value.field == "operation"


async def test_execute_non_interactive_build_with_java_version(provider_factory):
    """build-compilation + java_version routes to BuildCompilationHandler."""
    handler_class, instance, exec_mock = _make_handler_class(return_value=_resp("done"))
    svc = ClaudeService(provider_factory=provider_factory)

    req = MagicMock()
    req.operation = "build-compilation"
    req.java_version = "17"

    with patch.object(cs, "BuildCompilationHandler", handler_class):
        resp = await svc.execute_non_interactive_command(req)

    handler_class.assert_called_once_with(provider_factory=provider_factory)
    exec_mock.assert_awaited_once_with(req)
    assert resp.status == "done"


async def test_execute_non_interactive_build_without_java_version_uses_dotnet(provider_factory):
    """build-compilation without java_version routes through the registry (DotnetBuildHandler)."""
    handler_class, instance, exec_mock = _make_handler_class(return_value=_resp("ok"))
    svc = ClaudeService(provider_factory=provider_factory)
    svc._handler_registry["build-compilation"] = handler_class

    req = MagicMock()
    req.operation = "build-compilation"
    req.java_version = None

    resp = await svc.execute_non_interactive_command(req)
    exec_mock.assert_awaited_once_with(req)
    assert resp.status == "ok"


async def test_execute_non_interactive_handler_raises(provider_factory):
    handler_class, instance, exec_mock = _make_handler_class(side_effect=RuntimeError("boom"))
    svc = ClaudeService(provider_factory=provider_factory)
    svc._handler_registry["analysis"] = handler_class

    req = MagicMock()
    req.operation = "analysis"
    req.java_version = None

    with pytest.raises(RuntimeError, match="boom"):
        await svc.execute_non_interactive_command(req)


# ---------------------------------------------------------------------------
# execute_schema_modernization
# ---------------------------------------------------------------------------
async def test_execute_schema_modernization_success(provider_factory):
    handler_class, instance, exec_mock = _make_handler_class(return_value=_resp("success"))
    svc = ClaudeService(provider_factory=provider_factory)

    req = MagicMock()
    req.source_db_type = "oracle"
    req.target_db_type = "postgres"

    with patch.object(cs, "SchemaModernizationHandler", handler_class):
        resp = await svc.execute_schema_modernization(req)

    handler_class.assert_called_once_with(provider_factory=provider_factory)
    exec_mock.assert_awaited_once_with(req)
    assert resp.status == "success"


async def test_execute_schema_modernization_raises(provider_factory):
    handler_class, instance, exec_mock = _make_handler_class(side_effect=ValueError("bad"))
    svc = ClaudeService(provider_factory=provider_factory)

    req = MagicMock()
    req.source_db_type = "oracle"
    req.target_db_type = "postgres"

    with patch.object(cs, "SchemaModernizationHandler", handler_class):
        with pytest.raises(ValueError, match="bad"):
            await svc.execute_schema_modernization(req)


# ---------------------------------------------------------------------------
# execute_assessment_rules_batch
# ---------------------------------------------------------------------------
async def test_execute_assessment_rules_batch_success(provider_factory):
    handler_class, instance, exec_mock = _make_handler_class(
        return_value=_resp("success"), method="execute_batch"
    )
    svc = ClaudeService(provider_factory=provider_factory)

    req = MagicMock()
    req.analysis_id = "A-1"
    req.rules = [1, 2, 3]

    with patch.object(cs, "AssessmentRulesBatchHandler", handler_class):
        resp = await svc.execute_assessment_rules_batch(req)

    handler_class.assert_called_once_with(provider_factory=provider_factory)
    exec_mock.assert_awaited_once_with(req)
    assert resp.status == "success"


async def test_execute_assessment_rules_batch_raises(provider_factory):
    handler_class, instance, exec_mock = _make_handler_class(
        side_effect=RuntimeError("batch-fail"), method="execute_batch"
    )
    svc = ClaudeService(provider_factory=provider_factory)

    req = MagicMock()
    req.analysis_id = "A-1"
    req.rules = []

    with patch.object(cs, "AssessmentRulesBatchHandler", handler_class):
        with pytest.raises(RuntimeError, match="batch-fail"):
            await svc.execute_assessment_rules_batch(req)


# ---------------------------------------------------------------------------
# register_handler / get_supported_operations
# ---------------------------------------------------------------------------
def test_register_handler(provider_factory):
    svc = ClaudeService(provider_factory=provider_factory)
    new_handler = MagicMock()
    svc.register_handler("My-Custom-Op", new_handler)
    assert svc._handler_registry["my-custom-op"] is new_handler
    assert "my-custom-op" in svc.get_supported_operations()


# ---------------------------------------------------------------------------
# get_claude_service singleton
# ---------------------------------------------------------------------------
def test_get_claude_service_singleton():
    # Reset module-level singleton so we control both branches.
    cs._default_service = None
    with patch.object(cs, "get_provider_factory", return_value=MagicMock()):
        first = get_claude_service()
        second = get_claude_service()
    assert first is second
    cs._default_service = None