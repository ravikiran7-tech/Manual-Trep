"""
Tests for app/services/provider_factory.py.

Covers ProviderFactory.get_provider dispatch (bedrock / portkey / unknown /
no-connection), the Bedrock and Portkey client builders (success + error +
credential-decryption paths + slug parsing branches), get_provider_type,
health_check, and the module-level singleton helper.

No real network: the CompassClient is an AsyncMock and the BedrockClient
constructor is patched so no AWS session is built. Credential decryption uses
the real EncryptionUtils with the test key (so we encrypt a value and feed it
back through the factory).
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import app.services.provider_factory as pf_mod
from app.services.provider_factory import (
    ProviderFactory,
    ProviderType,
    get_provider_factory,
)
from app.services.portkey_client import PortkeyClient
from app.core.exceptions import ConfigurationError, ProviderError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _encrypted_api_key() -> str:
    """Encrypt a known plaintext with the test key for round-trip decryption."""
    from app.utils.encryption import EncryptionUtils

    enc = EncryptionUtils("P3qcGy5Nj2oMXh17iisPDg==")
    return enc.encrypt("real-portkey-api-key")


def _factory(connection):
    """Build a ProviderFactory whose compass client returns `connection`."""
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(return_value=connection)
    compass.health_check = AsyncMock(return_value=True)
    return ProviderFactory(compass_client=compass), compass


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------
def test_init_defaults_create_compass_and_encryption():
    with patch.object(pf_mod, "CompassClient") as MockCompass, \
         patch.object(pf_mod, "get_encryption_utils") as mock_get_enc:
        MockCompass.return_value = "compass-instance"
        mock_get_enc.return_value = "enc-instance"
        f = ProviderFactory()
        assert f.compass_client == "compass-instance"
        assert f.encryption_utils == "enc-instance"


def test_init_with_injected_dependencies(encryption_utils):
    compass = MagicMock()
    f = ProviderFactory(compass_client=compass, encryption_utils=encryption_utils)
    assert f.compass_client is compass
    assert f.encryption_utils is encryption_utils


# ---------------------------------------------------------------------------
# get_provider — no connection / unknown type
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_get_provider_no_connection_raises():
    f, _ = _factory(None)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider("claude-code")
    assert "No active connection" in ei.value.message


@pytest.mark.asyncio
async def test_get_provider_unknown_type_raises(make_connection):
    conn = make_connection(provider_type="some-other-provider")
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "Unsupported provider type" in ei.value.message
    assert "concierto-private-llm" in ei.value.details


@pytest.mark.asyncio
async def test_get_provider_delegates_concierto_private_llm(make_connection):
    """Legacy factory has no private-LLM client; schema generation still needs it."""
    conn = make_connection(
        provider_type="concierto-private-llm",
        cai_base_url="http://cei-host:14000",
        cai_model="gemma-4",
        cai_api_key="plain-key",
    )
    f, _ = _factory(conn)
    provider = await f.get_provider("Platform Model")
    assert provider.provider_name == "openai-compatible"
    assert provider.provider.model_id == "gemma-4"


@pytest.mark.asyncio
async def test_get_provider_uses_default_component(make_connection):
    """When component omitted, falls back to settings.studio_core.compass_component."""
    conn = make_connection(provider_type="some-other-provider")
    f, compass = _factory(conn)
    with pytest.raises(ConfigurationError):
        await f.get_provider()  # component=None path
    # default component was passed through (Studio from test env)
    assert compass.get_active_connection.call_args.args[0] == "Studio"


# ---------------------------------------------------------------------------
# get_provider — bedrock dispatch
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_get_provider_bedrock_success(make_connection):
    conn = make_connection(provider_type="aws-bedrock", awsRegion="us-west-2",
                           modelId="custom-model")
    f, _ = _factory(conn)
    with patch.object(pf_mod, "BedrockClient") as MockBedrock:
        MockBedrock.return_value = "bedrock-client"
        result = await f.get_provider("claude-code")
        assert result == "bedrock-client"
        kwargs = MockBedrock.call_args.kwargs
        assert kwargs["region"] == "us-west-2"
        assert kwargs["model_id"] == "custom-model"


@pytest.mark.asyncio
async def test_get_provider_bedrock_uppercase_type(make_connection):
    """provider_type is lowercased before dispatch."""
    conn = make_connection(provider_type="AWS-BEDROCK")
    f, _ = _factory(conn)
    with patch.object(pf_mod, "BedrockClient") as MockBedrock:
        MockBedrock.return_value = "bedrock-client"
        result = await f.get_provider()
        assert result == "bedrock-client"


@pytest.mark.asyncio
async def test_get_provider_bedrock_fallback_region_model(make_connection):
    """No awsRegion/modelId in config -> uses settings defaults."""
    conn = make_connection(provider_type="aws-bedrock")
    f, _ = _factory(conn)
    with patch.object(pf_mod, "BedrockClient") as MockBedrock:
        MockBedrock.return_value = "bedrock-client"
        await f.get_provider()
        kwargs = MockBedrock.call_args.kwargs
        assert kwargs["region"]  # falls back to settings.bedrock.region
        assert kwargs["model_id"]


@pytest.mark.asyncio
async def test_get_provider_bedrock_construction_error(make_connection):
    conn = make_connection(provider_type="aws-bedrock")
    f, _ = _factory(conn)
    with patch.object(pf_mod, "BedrockClient", side_effect=RuntimeError("boom")):
        with pytest.raises(ProviderError) as ei:
            await f.get_provider()
        assert ei.value.provider == "bedrock"


# ---------------------------------------------------------------------------
# get_provider — portkey dispatch
# ---------------------------------------------------------------------------
def _portkey_conn(make_connection, **overrides):
    """A portkey connection with a valid encrypted key + slug."""
    fields = dict(
        provider_type="portkey",
        portkeyApiKey=_encrypted_api_key(),
    )
    fields.update(overrides)
    conn = make_connection(**fields)
    # slug is a ConnectionData top-level field, not a configuration field
    conn.slug = overrides.get("slug", "@my-virtual-key/claude-3-sonnet")
    return conn


@pytest.mark.asyncio
async def test_get_provider_portkey_success(make_connection):
    conn = _portkey_conn(make_connection)
    conn.portkey_api_key = _encrypted_api_key()
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert isinstance(result, PortkeyClient)
    assert result.api_key == "real-portkey-api-key"
    assert result.virtual_key == "my-virtual-key"
    assert result.model_id == "claude-3-sonnet"


@pytest.mark.asyncio
async def test_get_provider_portkey_key_from_configuration(make_connection):
    """API key only present on configuration block, not connection level."""
    conn = make_connection(provider_type="portkey",
                           portkeyApiKey=_encrypted_api_key())
    conn.slug = "@vk/model-x"
    # connection-level portkey_api_key is None -> falls back to configuration
    conn.portkey_api_key = None
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert isinstance(result, PortkeyClient)
    assert result.model_id == "model-x"


@pytest.mark.asyncio
async def test_get_provider_portkey_missing_api_key(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.slug = "@vk/model"
    conn.portkey_api_key = None
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "API key is missing" in ei.value.message


@pytest.mark.asyncio
async def test_get_provider_portkey_missing_slug(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = None
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "slug is missing" in ei.value.message


@pytest.mark.asyncio
async def test_get_provider_portkey_decrypt_failure(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = "not-valid-encrypted-data!!!"
    conn.slug = "@vk/model"
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "decrypt" in ei.value.message.lower()


@pytest.mark.asyncio
async def test_get_provider_portkey_empty_decrypted_key(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "@vk/model"
    f, _ = _factory(conn)
    # Force decrypt to return empty -> ConfigurationError("empty")
    f.encryption_utils = MagicMock()
    f.encryption_utils.decrypt.return_value = ""
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "empty" in ei.value.message.lower()


@pytest.mark.asyncio
async def test_get_provider_portkey_bad_slug_format(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "no-slash-here"  # split('/') -> 1 part
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "parse Portkey slug" in ei.value.message


@pytest.mark.asyncio
async def test_get_provider_portkey_slug_without_at_prefix(make_connection):
    """Virtual key without leading @ is taken verbatim."""
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "plainvk/themodel"
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert result.virtual_key == "plainvk"
    assert result.model_id == "themodel"


@pytest.mark.asyncio
async def test_get_provider_portkey_empty_virtual_key(make_connection):
    """@/model -> empty virtual key -> ValueError -> ConfigurationError."""
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "@/model"
    f, _ = _factory(conn)
    with pytest.raises(ConfigurationError) as ei:
        await f.get_provider()
    assert "parse Portkey slug" in ei.value.message


@pytest.mark.asyncio
async def test_get_provider_portkey_debug_enabled_connection_level(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "@vk/model"
    conn.debug_enabled = True
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert result.debug is True


@pytest.mark.asyncio
async def test_get_provider_portkey_debug_from_configuration(make_connection):
    """connection.debug_enabled None -> falls back to configuration.debug_enabled."""
    conn = make_connection(provider_type="portkey", debugEnabled=True)
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "@vk/model"
    conn.debug_enabled = None
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert result.debug is True


@pytest.mark.asyncio
async def test_get_provider_portkey_base_url_override(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.portkey_base_url = "https://custom.portkey.example/v1"
    conn.slug = "@vk/model"
    f, _ = _factory(conn)
    result = await f.get_provider()
    assert result.base_url == "https://custom.portkey.example/v1"


@pytest.mark.asyncio
async def test_get_provider_portkey_construction_error(make_connection):
    conn = make_connection(provider_type="portkey")
    conn.portkey_api_key = _encrypted_api_key()
    conn.slug = "@vk/model"
    f, _ = _factory(conn)
    with patch.object(pf_mod, "PortkeyClient", side_effect=RuntimeError("nope")):
        with pytest.raises(ProviderError) as ei:
            await f.get_provider()
        assert ei.value.provider == "portkey"


# ---------------------------------------------------------------------------
# get_provider_type
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_get_provider_type_returns_type(make_connection):
    conn = make_connection(provider_type="portkey")
    f, _ = _factory(conn)
    assert await f.get_provider_type("c") == "portkey"


@pytest.mark.asyncio
async def test_get_provider_type_none_when_no_connection():
    f, _ = _factory(None)
    assert await f.get_provider_type() is None


@pytest.mark.asyncio
async def test_get_provider_type_handles_exception():
    compass = MagicMock()
    compass.get_active_connection = AsyncMock(side_effect=RuntimeError("down"))
    f = ProviderFactory(compass_client=compass)
    assert await f.get_provider_type() is None


# ---------------------------------------------------------------------------
# health_check
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_health_check_ok():
    f, _ = _factory(None)
    health = await f.health_check()
    assert health["compass"] is True
    assert health["providers"] == {}


@pytest.mark.asyncio
async def test_health_check_compass_failure():
    compass = MagicMock()
    compass.health_check = AsyncMock(side_effect=RuntimeError("unreachable"))
    f = ProviderFactory(compass_client=compass)
    health = await f.health_check()
    assert health["compass"] is False


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
def test_get_provider_factory_singleton():
    pf_mod._default_factory = None
    with patch.object(pf_mod, "CompassClient"), \
         patch.object(pf_mod, "get_encryption_utils"):
        a = get_provider_factory()
        b = get_provider_factory()
        assert a is b
    pf_mod._default_factory = None


def test_provider_type_enum_values():
    assert ProviderType.AWS_BEDROCK == "aws-bedrock"
    assert ProviderType.PORTKEY == "portkey"