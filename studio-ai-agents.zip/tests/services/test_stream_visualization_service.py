"""Tests for app.services.stream_visualization_service."""
import json

import pytest

import app.services.stream_visualization_service as svc_mod
from app.services.stream_visualization_service import (
    StreamVisualizationService,
    get_stream_visualization_service,
)
from app.core.exceptions import ValidationError


@pytest.fixture
def service(tmp_path, monkeypatch):
    """Service whose output base dir is an isolated tmp_path."""
    s = StreamVisualizationService()
    s.output_base_dir = tmp_path
    return s


def _write_stream(tmp_path, operation_dir, analysis_id, operation, events):
    d = tmp_path / operation_dir / analysis_id
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{operation}-stream.json"
    f.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
    return f


def _result_event(input_tokens=10, output_tokens=5, stop_reason="end_turn", is_error=False):
    return {
        "type": "result",
        "is_error": is_error,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "stop_reason": stop_reason,
    }


# ---------------------------------------------------------------------------
# get_stream_data
# ---------------------------------------------------------------------------
async def test_get_stream_data_success(service, tmp_path):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])

    resp = await service.get_stream_data("abc123", "analysis")

    assert resp.status == "success"
    assert resp.stream_data is not None
    data = json.loads(resp.stream_data)
    assert data["total_events"] == 1
    assert data["metadata"]["input_tokens"] == 10


async def test_get_stream_data_not_found(service):
    resp = await service.get_stream_data("missing", "analysis")
    assert resp.status == "not_found"
    assert resp.stream_data is None


async def test_get_stream_data_parse_error(service, tmp_path, monkeypatch):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])

    def boom(*_a, **_k):
        raise RuntimeError("parse blew up")

    monkeypatch.setattr(svc_mod.StreamParser, "parse_stream_file", staticmethod(boom))

    resp = await service.get_stream_data("abc123", "analysis")
    assert resp.status == "error"
    assert "parse blew up" in resp.message
    assert resp.stream_data is None


async def test_get_stream_data_invalid_analysis_id(service):
    # SecurityValidator.validate_alphanumeric raises ValueError for bad chars
    with pytest.raises(ValueError):
        await service.get_stream_data("bad;id", "analysis")


# ---------------------------------------------------------------------------
# _validate_inputs
# ---------------------------------------------------------------------------
def test_validate_inputs_missing_analysis_id(service):
    with pytest.raises(ValidationError):
        service._validate_inputs("", "analysis")


def test_validate_inputs_missing_operation(service):
    with pytest.raises(ValidationError):
        service._validate_inputs("abc123", "")


def test_validate_inputs_invalid_operation(service):
    with pytest.raises(ValidationError):
        service._validate_inputs("abc123", "no-such-op")


def test_validate_inputs_valid_uppercase(service):
    # operation lookup is case-insensitive
    service._validate_inputs("abc123", "ANALYSIS")


# ---------------------------------------------------------------------------
# _build_stream_file_path
# ---------------------------------------------------------------------------
def test_build_path_known_operation(service, tmp_path):
    p = service._build_stream_file_path("abc123", "analysis")
    assert p == tmp_path / "versionUpgrade" / "abc123" / "analysis-stream.json"


def test_build_path_unknown_operation_default(service, tmp_path):
    # default branch -> "containerization"
    p = service._build_stream_file_path("abc123", "unknown-op")
    assert p.parent.parent.name == "containerization"


# ---------------------------------------------------------------------------
# get_stream_summary
# ---------------------------------------------------------------------------
async def test_get_stream_summary_success(service, tmp_path):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])
    summary = await service.get_stream_summary("abc123", "analysis")
    assert summary["status"] == "success"
    assert summary["exists"] is True
    assert summary["total_events"] == 1
    assert summary["total_tokens"] == 15


async def test_get_stream_summary_not_found(service):
    summary = await service.get_stream_summary("missing", "analysis")
    assert summary["status"] == "not_found"
    assert summary["exists"] is False


async def test_get_stream_summary_error(service, tmp_path, monkeypatch):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])
    monkeypatch.setattr(
        svc_mod.StreamParser, "parse_stream_file",
        staticmethod(lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("x"))),
    )
    summary = await service.get_stream_summary("abc123", "analysis")
    assert summary["status"] == "error"
    assert summary["exists"] is True


# ---------------------------------------------------------------------------
# list_available_streams
# ---------------------------------------------------------------------------
async def test_list_available_streams_some(service, tmp_path):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])
    _write_stream(tmp_path, "cloudreadiness", "abc123", "cloudreadiness-analysis", [_result_event()])

    streams = await service.list_available_streams("abc123")
    ops = {s["operation"] for s in streams}
    assert "analysis" in ops
    assert "cloudreadiness-analysis" in ops


async def test_list_available_streams_none(service):
    streams = await service.list_available_streams("nostreams")
    assert streams == []


async def test_list_available_streams_parse_failure_skipped(service, tmp_path, monkeypatch):
    _write_stream(tmp_path, "versionUpgrade", "abc123", "analysis", [_result_event()])

    monkeypatch.setattr(
        svc_mod.StreamParser, "parse_stream_file",
        staticmethod(lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("bad"))),
    )
    streams = await service.list_available_streams("abc123")
    assert streams == []  # parse failure -> skipped via continue


async def test_list_available_streams_invalid_id(service):
    with pytest.raises(ValueError):
        await service.list_available_streams("bad;id")


# ---------------------------------------------------------------------------
# singleton
# ---------------------------------------------------------------------------
def test_get_stream_visualization_service_singleton():
    svc_mod._default_service = None
    a = get_stream_visualization_service()
    b = get_stream_visualization_service()
    assert a is b
    assert isinstance(a, StreamVisualizationService)