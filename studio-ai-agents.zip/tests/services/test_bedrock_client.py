"""
Tests for app.services.bedrock_client.BedrockClient.

The boto3 boundary is fully mocked: we patch `boto3.Session` so that
`session.client(...)` returns a MagicMock whose `.converse(...)` returns canned
dicts. The LLM rate limiter is disabled in the test env (LLM_RATE_LIMITER_ENABLED
=false) so `acquire()` is a no-op async context manager.

Collaborators imported *inside* the methods (ToolExecutor,
format_tool_result_for_model, GraphOrchestrator) are patched at their source
module path so no real tools/orchestration run.
"""
import time
import pytest
from unittest.mock import MagicMock, patch

import app.services.bedrock_client as bc
from app.services.bedrock_client import BedrockClient
from app.core.exceptions import (
    ProviderError,
    AuthenticationError,
    RateLimitError,
)
from botocore.exceptions import ClientError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _client_error(code, message="boom"):
    return ClientError(
        error_response={"Error": {"Code": code, "Message": message}},
        operation_name="Converse",
    )


def _resp(content_blocks, stop_reason="end_turn", input_tokens=10, output_tokens=20):
    return {
        "output": {"message": {"content": content_blocks}},
        "stopReason": stop_reason,
        "usage": {"inputTokens": input_tokens, "outputTokens": output_tokens},
    }


def _text_block(text="hello"):
    return {"text": text}


def _tool_block(name="bash", tool_id="tu-1", inp=None):
    return {"toolUse": {"toolUseId": tool_id, "name": name, "input": inp or {"command": "ls"}}}


@pytest.fixture
def mock_session():
    """Patch boto3.Session; returns (session_mock, runtime_mock)."""
    runtime = MagicMock(name="bedrock_runtime")
    session = MagicMock(name="session")
    session.client.return_value = runtime
    with patch.object(bc.boto3, "Session", return_value=session) as session_factory:
        yield session_factory, session, runtime


@pytest.fixture
def client(mock_session):
    """A BedrockClient with a mocked boto3 runtime."""
    _, _, runtime = mock_session
    c = BedrockClient(region="us-east-1", model_id="test-model", profile="default")
    # expose the runtime for convenience
    c._test_runtime = runtime
    return c


def _result(success=True, output="out", error=None, ms=5):
    r = MagicMock()
    r.success = success
    r.output = output
    r.error = error
    r.execution_time_ms = ms
    return r


def _patch_tool_executor(result):
    """Patch ToolExecutor + format_tool_result_for_model in tool_executor module."""
    executor_instance = MagicMock()
    executor_instance.execute_tool.return_value = result
    executor_cls = MagicMock(return_value=executor_instance)
    fmt = MagicMock(return_value={"content": "formatted-result"})
    return executor_cls, executor_instance, fmt


# ===========================================================================
# __init__
# ===========================================================================
def test_init_success(mock_session):
    session_factory, session, runtime = mock_session
    c = BedrockClient(region="eu-west-1", model_id="m1", profile="prof",
                      max_tokens=123, temperature=0.5)
    assert c.region == "eu-west-1"
    assert c.model_id == "m1"
    assert c.profile == "prof"
    assert c.max_tokens == 123
    assert c.temperature == 0.5
    assert c.bedrock_runtime is runtime
    session_factory.assert_called_once_with(profile_name="prof", region_name="eu-west-1")


def test_init_defaults_from_settings(mock_session):
    c = BedrockClient()
    # from conftest env
    assert c.region == "us-east-1"
    assert c.model_id == "anthropic.claude-3-sonnet-20240229-v1:0"
    assert c.max_tokens > 0


def test_init_empty_profile_becomes_none(mock_session):
    session_factory, _, _ = mock_session
    c = BedrockClient(profile="")  # falsy -> None
    assert c.profile is None
    session_factory.assert_called_once_with(profile_name=None, region_name="us-east-1")


def test_init_credentials_error_raises_auth():
    session = MagicMock()
    session.client.side_effect = Exception("Missing credentials in chain")
    with patch.object(bc.boto3, "Session", return_value=session):
        with pytest.raises(AuthenticationError):
            BedrockClient()


def test_init_other_error_raises_provider():
    session = MagicMock()
    session.client.side_effect = Exception("network down")
    with patch.object(bc.boto3, "Session", return_value=session):
        with pytest.raises(ProviderError):
            BedrockClient()


# ===========================================================================
# invoke_with_tools — basic / end_turn
# ===========================================================================
async def test_invoke_with_tools_text_end_turn(client):
    client.bedrock_runtime.converse.return_value = _resp([_text_block("hi")], stop_reason="end_turn")
    events = await client.invoke_with_tools("do x", "/proj", system_prompt="sys")
    types = [e["type"] for e in events]
    assert "system" in types and "message_stop" in types and "result" in types
    # request included system + toolConfig
    kwargs = client.bedrock_runtime.converse.call_args.kwargs
    assert kwargs["system"] == [{"text": "sys"}]
    assert "toolConfig" in kwargs


async def test_invoke_with_tools_no_tools_no_system(client):
    client.bedrock_runtime.converse.return_value = _resp([_text_block()], stop_reason="end_turn")
    events = await client.invoke_with_tools("p", "/proj", enable_tools=False)
    kwargs = client.bedrock_runtime.converse.call_args.kwargs
    assert "toolConfig" not in kwargs
    assert "system" not in kwargs
    assert any(e["type"] == "result" for e in events)


async def test_invoke_with_tools_process_response_false(client):
    raw = _resp([_text_block()], stop_reason="end_turn")
    client.bedrock_runtime.converse.return_value = raw
    events = await client.invoke_with_tools("p", "/proj", process_response=False)
    assert events[0] is raw


async def test_invoke_with_tools_stop_reason_not_tool_use_breaks(client):
    # stop_reason something other than end_turn/tool_use -> first-turn break
    client.bedrock_runtime.converse.return_value = _resp([_text_block()], stop_reason="max_tokens")
    events = await client.invoke_with_tools("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 1
    assert any(e["type"] == "result" for e in events)


# ===========================================================================
# invoke_with_tools — tool_use loop
# ===========================================================================
async def test_invoke_with_tools_tool_use_then_end_turn(client):
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    second = _resp([_text_block("all done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj", system_prompt="sys")

    assert client.bedrock_runtime.converse.call_count == 2
    executor_instance.execute_tool.assert_called_once()
    assert any(e["type"] == "tool_use" for e in events)
    assert any(e["type"] == "tool_result" for e in events)


async def test_invoke_with_tools_tool_use_no_tool_events_breaks(client):
    # stop_reason tool_use but content has no toolUse blocks -> current_tool_use_events empty
    first = _resp([_text_block("just text")], stop_reason="tool_use")
    client.bedrock_runtime.converse.return_value = first
    events = await client.invoke_with_tools("p", "/proj")
    # only the first converse call (loop breaks on empty tool events)
    assert client.bedrock_runtime.converse.call_count == 1


async def test_invoke_with_tools_file_write_retry_success(client):
    """code_editor write succeeds and file verification passes."""
    tool_in = {"operation": "write", "path": "rel/file.txt", "content": "x"}
    first = _resp([_tool_block(name="code_editor", tool_id="t1", inp=tool_in)], stop_reason="tool_use")
    second = _resp([_text_block("complete")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt), \
         patch("os.path.exists", return_value=True), \
         patch("os.stat") as stat_mock, \
         patch("builtins.open", create=True) as open_mock:
        stat_mock.return_value = MagicMock(st_size=10, st_mtime=1.0)
        open_mock.return_value.__enter__.return_value.read.return_value = "preview"
        events = await client.invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" and e["success"] for e in events)


async def test_invoke_with_tools_file_write_verification_fails_then_retries(client):
    """File write 'succeeds' but file doesn't exist -> retry loop -> exhausts retries."""
    tool_in = {"operation": "write", "path": "/abs/file.txt", "content": "x"}
    first = _resp([_tool_block(name="code_editor", tool_id="t1", inp=tool_in)], stop_reason="tool_use")
    # follow-up text response without completion words so it would loop, end_turn to stop
    second = _resp([_text_block("retrying")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt), \
         patch("os.path.exists", return_value=False), \
         patch.object(bc.time, "sleep") as sleep_mock:
        events = await client.invoke_with_tools("p", "/proj")
    # retried 3 times -> execute_tool called 3 times, slept twice
    assert executor_instance.execute_tool.call_count == 3
    assert sleep_mock.call_count == 2


async def test_invoke_with_tools_file_write_verify_read_raises(client):
    """File exists but reading preview throws -> warning branch covered."""
    tool_in = {"operation": "write", "path": "rel/file.txt"}
    first = _resp([_tool_block(name="code_editor", tool_id="t1", inp=tool_in)], stop_reason="tool_use")
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt), \
         patch("os.path.exists", return_value=True), \
         patch("os.stat", return_value=MagicMock(st_size=1, st_mtime=1.0)), \
         patch("builtins.open", side_effect=OSError("locked")):
        events = await client.invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" for e in events)


async def test_invoke_with_tools_consecutive_failures_breaks(client):
    """3 failing tools in one turn -> max consecutive failures -> error event + break."""
    tools = [
        _tool_block(name="bash", tool_id="t1", inp={"command": "a"}),
        _tool_block(name="code_editor", tool_id="t2", inp={"operation": "read", "path": "p"}),
        _tool_block(name="bash", tool_id="t3", inp={"command": "c"}),
    ]
    first = _resp(tools, stop_reason="tool_use")
    client.bedrock_runtime.converse.return_value = first

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=False, error="fail"))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    # error event present from max consecutive failures
    assert any(e["type"] == "error" for e in events)


async def test_invoke_with_tools_completion_indicator_breaks(client):
    """Follow-up text contains a completion indicator -> smart termination."""
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    # stop_reason tool_use again but text says 'finished' -> break before next iter
    second = _resp([_text_block("Task finished successfully")], stop_reason="tool_use")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 2


async def test_invoke_with_tools_throttling_raises_ratelimit(client):
    client.bedrock_runtime.converse.side_effect = _client_error("ThrottlingException")
    with pytest.raises(RateLimitError):
        await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_access_denied_raises_auth(client):
    client.bedrock_runtime.converse.side_effect = _client_error("AccessDeniedException")
    with pytest.raises(AuthenticationError):
        await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_other_client_error_raises_provider(client):
    client.bedrock_runtime.converse.side_effect = _client_error("ValidationException")
    with pytest.raises(ProviderError):
        await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_unexpected_error_raises_provider(client):
    client.bedrock_runtime.converse.side_effect = RuntimeError("weird")
    with pytest.raises(ProviderError):
        await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_followup_throttling(client):
    """Throttling on the follow-up converse call -> RateLimitError."""
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    client.bedrock_runtime.converse.side_effect = [first, _client_error("TooManyRequestsException")]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        with pytest.raises(RateLimitError):
            await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_followup_other_clienterror(client):
    """Non-throttle ClientError on follow-up -> re-raised -> ProviderError handler."""
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    client.bedrock_runtime.converse.side_effect = [first, _client_error("ValidationException")]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        with pytest.raises(ProviderError):
            await client.invoke_with_tools("p", "/proj")


async def test_invoke_with_tools_failed_non_write_enhances_error(client):
    """A failing bash tool (single) -> enhanced error message branch, then end_turn."""
    first = _resp([_tool_block(name="bash", tool_id="t1", inp={"command": "x" * 200})], stop_reason="tool_use")
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=False, error="oops"))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" and not e["success"] for e in events)


async def test_invoke_with_tools_failed_code_editor_enhances_error(client):
    """A failing code_editor read -> enhanced error includes operation/path."""
    first = _resp(
        [_tool_block(name="code_editor", tool_id="t1", inp={"operation": "read", "path": "f.py"})],
        stop_reason="tool_use",
    )
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=False, error="oops"))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" for e in events)


async def test_invoke_with_tools_followup_no_tool_turn_breaks(client):
    """tool_use -> follow-up turn with a non-tool stop reason -> break.

    Note: the `consecutive_no_tool_turns >= 2` branch (lines 294-295) is dead
    code — after a tool_use turn the counter resets to 0, and the unconditional
    `break` on the first non-tool turn means it can never reach 2.
    """
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    second = _resp([_text_block("working on it")], stop_reason="max_tokens")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    # first(tool_use) + second(no-tool turn -> break)
    assert client.bedrock_runtime.converse.call_count == 2


async def test_invoke_with_tools_followup_assistant_text_block(client):
    """Follow-up response carries both a text block and tool block in assistant content."""
    first = _resp(
        [_text_block("let me run this"), _tool_block(name="bash", tool_id="t1")],
        stop_reason="tool_use",
    )
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        events = await client.invoke_with_tools("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 2


# ===========================================================================
# _process_response
# ===========================================================================
async def test_process_response_text_and_toolresult(client):
    resp = _resp([_text_block("hi"), _tool_block(name="bash", tool_id="t1", inp={"command": "ls"})],
                 stop_reason="tool_use")
    events = await client._process_response(resp, "/proj")
    types = [e["type"] for e in events]
    assert types[0] == "system"
    assert any(e["type"] == "assistant" and e.get("subtype") == "text_delta" for e in events)
    assert any(e["type"] == "tool_use" for e in events)
    assert events[-1]["type"] == "result"
    assert events[-1]["input_tokens"] == 10


async def test_process_response_bash_security_rejected(client):
    """Bash command rejected by validator -> error event + continue."""
    resp = _resp([_tool_block(name="bash", tool_id="t1", inp={"command": "rm -rf /"})],
                 stop_reason="tool_use")
    with patch("app.core.security.SecurityValidator.validate_bash_command",
               side_effect=ValueError("unsafe")):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "error" and "Security validation failed" in e["error"] for e in events)
    # tool_use event NOT added
    assert not any(e["type"] == "tool_use" for e in events)


async def test_process_response_bash_validation_disabled(client, reset_settings_singleton, monkeypatch):
    """bash validation disabled -> command allowed without validation."""
    resp = _resp([_tool_block(name="bash", tool_id="t1", inp={"command": "ls"})], stop_reason="tool_use")

    fake_settings = MagicMock()
    fake_settings.security.bash_command_validation_enabled = False
    with patch("app.core.config.get_settings", return_value=fake_settings):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


async def test_process_response_bash_valid(client):
    resp = _resp([_tool_block(name="bash", tool_id="t1", inp={"command": "ls"})], stop_reason="tool_use")
    with patch("app.core.security.SecurityValidator.validate_bash_command", return_value="ls"):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


async def test_process_response_code_editor_path_traversal(client):
    resp = _resp([_tool_block(name="code_editor", tool_id="t1",
                              inp={"operation": "write", "path": "../etc/passwd"})],
                 stop_reason="tool_use")
    events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "error" for e in events)
    assert not any(e["type"] == "tool_use" for e in events)


async def test_process_response_code_editor_absolute_path_rejected(client):
    resp = _resp([_tool_block(name="code_editor", tool_id="t1",
                              inp={"operation": "write", "path": "/etc/passwd"})],
                 stop_reason="tool_use")
    with patch("app.core.security.SecurityValidator.is_safe_absolute_path", return_value=False):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "error" for e in events)


async def test_process_response_code_editor_absolute_path_allowed(client):
    resp = _resp([_tool_block(name="code_editor", tool_id="t1",
                              inp={"operation": "write", "path": "/test-code/f.py"})],
                 stop_reason="tool_use")
    with patch("app.core.security.SecurityValidator.is_safe_absolute_path", return_value=True):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


async def test_process_response_code_editor_path_validation_disabled(client):
    resp = _resp([_tool_block(name="code_editor", tool_id="t1",
                              inp={"operation": "write", "path": "/anything"})],
                 stop_reason="tool_use")
    fake_settings = MagicMock()
    fake_settings.security.path_traversal_protection_enabled = False
    with patch("app.core.config.get_settings", return_value=fake_settings):
        events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


async def test_process_response_code_editor_relative_path_valid(client):
    resp = _resp([_tool_block(name="code_editor", tool_id="t1",
                              inp={"operation": "write", "path": "src/f.py"})],
                 stop_reason="tool_use")
    events = await client._process_response(resp, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


async def test_process_response_exception_handled(client):
    """Force an exception during processing -> error event appended."""
    # response.get('output') will raise because response is not a dict-like
    bad = MagicMock()
    bad.get.side_effect = RuntimeError("kaboom")
    events = await client._process_response(bad, "/proj")
    assert events[-1]["type"] == "error"


# ===========================================================================
# _get_completion_instructions
# ===========================================================================
def test_get_completion_instructions(client):
    out = client._get_completion_instructions(1, max_iterations=5, unlimited=False)
    assert "MANDATORY FINAL OUTPUT FORMAT" in out


# ===========================================================================
# invoke_with_tools_agentic
# ===========================================================================
async def test_agentic_disabled_falls_back(client):
    fake_settings = MagicMock()
    fake_settings.agentic.enabled = False
    with patch("app.core.config.get_settings", return_value=fake_settings), \
         patch.object(client, "invoke_with_tools") as fallback:
        fallback.return_value = [{"type": "result"}]
        # make it awaitable
        async def _aw(*a, **k):
            return [{"type": "result"}]
        fallback.side_effect = _aw
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert out == [{"type": "result"}]


def _agentic_settings(max_iterations=10, unlimited=False, max_consecutive_errors=3,
                      timeout=30):
    s = MagicMock()
    s.agentic.enabled = True
    s.agentic.unlimited_iterations = unlimited
    s.agentic.max_iterations = max_iterations
    s.agentic.tool_execution_timeout = timeout
    s.agentic.max_consecutive_errors = max_consecutive_errors
    return s


async def test_agentic_end_turn_first_iteration(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("hi")], stop_reason="end_turn")

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    events = []
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        out = await client.invoke_with_tools_agentic("p", "/proj", system_prompt="sys",
                                                      on_event=events.append)
    assert any(e["type"] == "result" for e in out)
    assert events  # on_event called
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_tool_use_then_end_turn(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    first = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    executor_instance.execute_tool.assert_called_once()
    assert client.bedrock_runtime.converse.call_count == 2


async def test_agentic_tool_use_with_code_editor_write_and_patch(client):
    """Cover write + patch file modification tracking branches."""
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    tools = [
        _tool_block(name="code_editor", tool_id="t1", inp={"operation": "write", "path": "a"}),
        _tool_block(name="code_editor", tool_id="t2", inp={"operation": "patch", "path": "b"}),
    ]
    first = _resp(tools, stop_reason="tool_use")
    second = _resp([_text_block("done")], stop_reason="end_turn")
    client.bedrock_runtime.converse.side_effect = [first, second]

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert executor_instance.execute_tool.call_count == 2


async def test_agentic_tool_use_no_tool_events_breaks(client):
    """stop_reason tool_use but _process_response yields no tool_use events."""
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    # text-only content but stop_reason tool_use
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="tool_use")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_max_tokens_stop(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="max_tokens")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_unexpected_stop(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="weird_reason")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_no_result_event_unknown_stop(client):
    """process_response True but no result event -> stop_reason unknown -> break."""
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="end_turn")
    with patch("app.core.config.get_settings", return_value=settings), \
         patch.object(client, "_process_response", return_value=[{"type": "system"}]):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    # no result event -> stop_reason "unknown" -> else branch -> break
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_process_response_false_raw(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    raw = _resp([_text_block("x")], stop_reason="end_turn")
    client.bedrock_runtime.converse.return_value = raw
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj", process_response=False)
    assert out[0] is raw


async def test_agentic_process_response_false_unknown_stop(client):
    settings = _agentic_settings(max_iterations=5, unlimited=False)
    raw = {"output": {"message": {"content": []}}, "usage": {}}  # no stopReason
    client.bedrock_runtime.converse.return_value = raw
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj", process_response=False)
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_unlimited_mode(client):
    settings = _agentic_settings(unlimited=True)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="end_turn")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_max_iterations_reached(client):
    """Loop hits max_iterations -> max_iterations_reached event appended."""
    settings = _agentic_settings(max_iterations=1, unlimited=False)
    # tool_use forever; iteration limit caps at 1
    tool_resp = _resp([_tool_block(name="bash", tool_id="t1")], stop_reason="tool_use")
    client.bedrock_runtime.converse.return_value = tool_resp

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=True))
    events = []
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        out = await client.invoke_with_tools_agentic("p", "/proj", on_event=events.append)
    assert any(e.get("subtype") == "max_iterations_reached" for e in out)


async def test_agentic_consecutive_errors_break(client):
    """Tool failures accumulate to max_consecutive_errors -> break before iteration limit."""
    settings = _agentic_settings(max_iterations=10, unlimited=False, max_consecutive_errors=2)
    tool_resp = _resp([
        _tool_block(name="bash", tool_id="t1"),
        _tool_block(name="bash", tool_id="t2"),
    ], stop_reason="tool_use")
    client.bedrock_runtime.converse.return_value = tool_resp

    executor_cls, executor_instance, fmt = _patch_tool_executor(_result(success=False, error="x"))
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.services.tool_executor.ToolExecutor", executor_cls), \
         patch("app.services.tool_executor.format_tool_result_for_model", fmt):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    # 2 failures in first iter -> consecutive_errors=2 -> break
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_client_error_auth(client):
    settings = _agentic_settings(unlimited=True)
    client.bedrock_runtime.converse.side_effect = _client_error("AccessDeniedException")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    # AuthenticationError raised inside loop -> caught by generic except -> error event + break
    assert any(e["type"] == "error" for e in out)


async def test_agentic_client_error_throttle(client):
    settings = _agentic_settings(unlimited=True)
    client.bedrock_runtime.converse.side_effect = _client_error("ThrottlingException")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "error" for e in out)


async def test_agentic_client_error_other_provider(client):
    settings = _agentic_settings(unlimited=True)
    client.bedrock_runtime.converse.side_effect = _client_error("ValidationException")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "error" for e in out)


async def test_agentic_exception_max_errors_break(client):
    """Generic exception with on_event; consecutive_errors reaches max -> break w/o error event."""
    settings = _agentic_settings(unlimited=True, max_consecutive_errors=1)
    client.bedrock_runtime.converse.side_effect = RuntimeError("explode")
    events = []
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj", on_event=events.append)
    # max_consecutive_errors=1 reached immediately -> break before appending error event
    assert client.bedrock_runtime.converse.call_count == 1


async def test_agentic_exception_appends_error_event_with_on_event(client):
    """Generic exception, consecutive_errors below max -> error event appended + on_event."""
    settings = _agentic_settings(unlimited=True, max_consecutive_errors=5)
    client.bedrock_runtime.converse.side_effect = RuntimeError("explode")
    events = []
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj", on_event=events.append)
    # error event appended and forwarded to on_event before break
    assert any(e["type"] == "error" for e in out)
    assert any(e["type"] == "error" for e in events)


async def test_agentic_enable_tools_false(client):
    settings = _agentic_settings(unlimited=True)
    client.bedrock_runtime.converse.return_value = _resp([_text_block("x")], stop_reason="end_turn")
    with patch("app.core.config.get_settings", return_value=settings):
        out = await client.invoke_with_tools_agentic("p", "/proj", enable_tools=False)
    kwargs = client.bedrock_runtime.converse.call_args.kwargs
    assert "toolConfig" not in kwargs


# ===========================================================================
# invoke_with_tools_agentic_graph
# ===========================================================================
def _make_state(total_modules=1, progress=None):
    state = MagicMock()
    state.total_modules = total_modules
    state.current_iteration = 2
    module = MagicMock()
    module.name = "mod1"
    module.path = "/p/mod1"
    module.status.value = "locked"
    module.retries = 0
    module.files_changed = ["a.py"]
    module.last_error = None
    module.events = [{"type": "tool_use", "tool": {"name": "bash"}}]
    state.graph = {"mod1": module}
    state.get_progress.return_value = progress or {
        "locked": 1, "failed": 0, "skipped": 0
    }
    return state, module


async def test_agentic_graph_success(client):
    settings = MagicMock()
    state, module = _make_state()

    orchestrator = MagicMock()
    async def _orch(prompt, on_event=None):
        return state
    orchestrator.orchestrate.side_effect = _orch
    orch_cls = MagicMock(return_value=orchestrator)

    events_seen = []
    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.orchestrator.graph_orchestrator.GraphOrchestrator", orch_cls):
        out = await client.invoke_with_tools_agentic_graph(
            "p", "/proj", provider_factory=MagicMock(), on_event=events_seen.append
        )
    subtypes = [e.get("subtype") for e in out]
    assert "graph_start" in subtypes
    assert "graph_complete" in subtypes
    assert any(e["type"] == "module_completed" for e in out)
    # module events copied in with module context
    assert any(e.get("module") == "mod1" and e["type"] == "tool_use" for e in out)
    assert events_seen  # on_event invoked


async def test_agentic_graph_module_no_events(client):
    settings = MagicMock()
    state, module = _make_state()
    module.events = []  # cover the falsy branch

    orchestrator = MagicMock()
    async def _orch(prompt, on_event=None):
        return state
    orchestrator.orchestrate.side_effect = _orch
    orch_cls = MagicMock(return_value=orchestrator)

    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.orchestrator.graph_orchestrator.GraphOrchestrator", orch_cls):
        out = await client.invoke_with_tools_agentic_graph("p", "/proj", provider_factory=MagicMock())
    # No tool_use events copied (module had no events), only the module_completed summary
    assert not any(e["type"] == "tool_use" for e in out)


async def test_agentic_graph_orchestrate_raises(client):
    settings = MagicMock()
    orchestrator = MagicMock()
    async def _orch(prompt, on_event=None):
        raise RuntimeError("graph boom")
    orchestrator.orchestrate.side_effect = _orch
    orch_cls = MagicMock(return_value=orchestrator)

    with patch("app.core.config.get_settings", return_value=settings), \
         patch("app.orchestrator.graph_orchestrator.GraphOrchestrator", orch_cls):
        with pytest.raises(RuntimeError, match="graph boom"):
            await client.invoke_with_tools_agentic_graph("p", "/proj", provider_factory=MagicMock())


# ===========================================================================
# invoke_simple
# ===========================================================================
async def test_invoke_simple_success(client):
    raw = _resp([_text_block("x")], stop_reason="end_turn")
    client.bedrock_runtime.converse.return_value = raw
    out = await client.invoke_simple("p")
    assert out is raw
    kwargs = client.bedrock_runtime.converse.call_args.kwargs
    assert "toolConfig" not in kwargs


async def test_invoke_simple_throttling(client):
    client.bedrock_runtime.converse.side_effect = _client_error("ServiceQuotaExceededException")
    with pytest.raises(RateLimitError):
        await client.invoke_simple("p")


async def test_invoke_simple_other_client_error(client):
    client.bedrock_runtime.converse.side_effect = _client_error("ValidationException")
    with pytest.raises(ProviderError):
        await client.invoke_simple("p", max_tokens=100, temperature=0.1)


# ===========================================================================
# health_check
# ===========================================================================
async def test_health_check_ok(client):
    # bedrock_runtime._endpoint._endpoint_prefix attribute access
    client.bedrock_runtime._endpoint._endpoint_prefix = "bedrock-runtime"
    session = MagicMock()
    bedrock_client = MagicMock()
    session.client.return_value = bedrock_client
    with patch.object(bc.boto3, "Session", return_value=session):
        ok = await client.health_check()
    assert ok is True
    bedrock_client.list_foundation_models.assert_called_once()


async def test_health_check_failure(client):
    client.bedrock_runtime._endpoint._endpoint_prefix = "bedrock-runtime"
    session = MagicMock()
    session.client.return_value.list_foundation_models.side_effect = Exception("down")
    with patch.object(bc.boto3, "Session", return_value=session):
        ok = await client.health_check()
    assert ok is False