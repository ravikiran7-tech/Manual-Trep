"""
Tests for app/services/portkey_client.py.

Covers PortkeyClient: __init__ validation, invoke_with_tools (success, system
prompt, tool_use single & multi-turn loops, 429, HTTP error -> auth/provider,
max-follow-up safety, smart termination, consecutive-failure cap, file-write
retry/verify), _process_response (text/tool_use/security validation branches,
error handling), the agentic loop (disabled fallback, end_turn, tool_use,
max_tokens, unexpected stop, max iterations, http/exception error handling,
on_event callback, process_response=False raw path), the graph variant,
invoke_simple, and health_check.

The httpx boundary is mocked: ``httpx.AsyncClient`` is replaced with a
MagicMock context-manager whose ``post``/``get`` are AsyncMocks. ToolExecutor
is patched so no real subprocess/file work happens. ``time.sleep`` is patched
so retry backoff never waits.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

import app.services.portkey_client as pk_mod
from app.services.portkey_client import PortkeyClient
from app.core.exceptions import (
    AuthenticationError,
    ProviderError,
    RateLimitError,
)


# ---------------------------------------------------------------------------
# Fake httpx response + post/get patchers
# ---------------------------------------------------------------------------
class _FakeResponse:
    def __init__(self, status_code=200, json_body=None, headers=None, text=""):
        self.status_code = status_code
        self._json = json_body if json_body is not None else {}
        self.headers = headers or {}
        self.text = text

    def json(self):
        return self._json

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError(
                "err", request=MagicMock(), response=self
            )


def _patch_post(responses):
    """Patch httpx.AsyncClient.post to return the given response(s) in order."""
    if not isinstance(responses, (list, tuple)):
        responses = [responses]
    client = MagicMock()
    client.post = AsyncMock(side_effect=list(responses))
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=client)
    cm.__aexit__ = AsyncMock(return_value=False)
    return patch.object(pk_mod.httpx, "AsyncClient", return_value=cm), client


def _patch_get(response):
    client = MagicMock()
    client.get = AsyncMock(return_value=response)
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=client)
    cm.__aexit__ = AsyncMock(return_value=False)
    return patch.object(pk_mod.httpx, "AsyncClient", return_value=cm), client


def _client(**overrides):
    kwargs = dict(api_key="ak", virtual_key="vk-123456789", model_id="m")
    kwargs.update(overrides)
    return PortkeyClient(**kwargs)


def _fake_tool_result(success=True, output="ok", error=None):
    r = MagicMock()
    r.success = success
    r.output = output
    r.error = error
    r.execution_time_ms = 5
    return r


def _patch_tool_executor(results):
    """Patch ToolExecutor + format_tool_result_for_model in tool_executor module."""
    if not isinstance(results, (list, tuple)):
        results = [results]
    import app.services.tool_executor as te_mod
    executor = MagicMock()
    executor.execute_tool = MagicMock(side_effect=list(results))
    p_exec = patch.object(te_mod, "ToolExecutor", return_value=executor)
    p_fmt = patch.object(
        te_mod, "format_tool_result_for_model",
        side_effect=lambda tid, res: {"type": "tool_result", "tool_use_id": tid,
                                      "content": res.output, "is_error": not res.success},
    )
    return p_exec, p_fmt, executor


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------
def test_init_requires_api_key():
    with pytest.raises(ValueError, match="API key"):
        PortkeyClient(api_key="", virtual_key="vk", model_id="m")


def test_init_requires_virtual_key():
    with pytest.raises(ValueError, match="virtual key"):
        PortkeyClient(api_key="ak", virtual_key="", model_id="m")


def test_init_requires_model_id():
    with pytest.raises(ValueError, match="Model ID"):
        PortkeyClient(api_key="ak", virtual_key="vk", model_id="")


def test_init_defaults_and_headers():
    c = _client()
    assert c.base_url  # from settings.portkey.base_url
    assert c.max_tokens  # settings.bedrock.max_tokens
    assert c.headers["x-portkey-api-key"] == "ak"
    assert c.headers["x-portkey-virtual-key"] == "vk-123456789"
    assert "x-portkey-debug" not in c.headers


def test_init_debug_adds_header_and_explicit_values():
    c = _client(debug=True, base_url="https://x/v1", max_tokens=123, temperature=0.9)
    assert c.headers["x-portkey-debug"] == "true"
    assert c.base_url == "https://x/v1"
    assert c.max_tokens == 123
    assert c.temperature == 0.9


# ---------------------------------------------------------------------------
# invoke_with_tools — basic success / end_turn
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_invoke_with_tools_end_turn_no_tools():
    resp = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "hello"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 3, "output_tokens": 2},
    })
    p, client = _patch_post(resp)
    with p:
        events = await _client().invoke_with_tools("do it", "/proj", system_prompt="sys")
    assert any(e["type"] == "result" for e in events)
    body = client.post.call_args.kwargs["json"]
    assert body["system"] == "sys"
    assert "tools" in body  # enable_tools default True


@pytest.mark.asyncio
async def test_invoke_with_tools_disabled_tools_no_system():
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "end_turn"})
    p, client = _patch_post(resp)
    with p:
        events = await _client().invoke_with_tools(
            "p", "/proj", enable_tools=False)
    body = client.post.call_args.kwargs["json"]
    assert "tools" not in body
    assert "system" not in body
    # while loop is gated on enable_tools -> immediately skipped
    assert any(e["type"] == "message_stop" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_process_response_false():
    raw = {"content": [], "stop_reason": "end_turn"}
    resp = _FakeResponse(json_body=raw)
    p, _ = _patch_post(resp)
    with p:
        events = await _client().invoke_with_tools(
            "p", "/proj", process_response=False)
    assert events[0] == raw


# ---------------------------------------------------------------------------
# invoke_with_tools — tool_use single turn then end_turn
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_invoke_with_tools_tool_use_then_end_turn():
    first = _FakeResponse(json_body={
        "content": [
            {"type": "text", "text": "let me run"},
            {"type": "tool_use", "id": "t1", "name": "bash",
             "input": {"command": "echo hi"}},
        ],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "all done"}],
        "stop_reason": "end_turn",
    })
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", "/proj")
    assert client.post.call_count == 2
    assert any(e["type"] == "tool_use" for e in events)
    assert any(e["type"] == "tool_result" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_two_tool_use_turns():
    """tool_use -> follow-up also tool_use -> follow-up end_turn (hits follow_up>0 log)."""
    tu = lambda i: _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": f"t{i}", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use",
    })
    end = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, client = _patch_post([tu(1), tu(2), end])
    p_exec, p_fmt, _ = _patch_tool_executor(
        [_fake_tool_result(), _fake_tool_result()])
    with p, p_exec, p_fmt:
        await _client().invoke_with_tools("p", "/proj")
    assert client.post.call_count == 3


@pytest.mark.asyncio
async def test_invoke_with_tools_tool_use_no_tool_blocks_breaks():
    """stop_reason tool_use but content has no tool_use blocks -> break."""
    resp = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "hmm"}],
        "stop_reason": "tool_use",
    })
    p, client = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", "/proj")
    assert client.post.call_count == 1  # no follow-up made


@pytest.mark.asyncio
async def test_invoke_with_tools_non_tool_use_non_end_turn_breaks():
    """stop_reason e.g. max_tokens -> first-turn break."""
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "max_tokens"})
    p, client = _patch_post(resp)
    with p:
        await _client().invoke_with_tools("p", "/proj")
    assert client.post.call_count == 1


@pytest.mark.asyncio
async def test_invoke_with_tools_completion_indicator_terminates():
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use",
    })
    # follow-up says "done" in text -> smart termination
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "All done now"}],
        "stop_reason": "tool_use",  # still tool_use but text triggers break
    })
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with p, p_exec, p_fmt:
        await _client().invoke_with_tools("p", "/proj")
    assert client.post.call_count == 2


@pytest.mark.asyncio
async def test_invoke_with_tools_file_write_retry_and_verify(tmp_path):
    """code_editor write success + file exists -> verification path."""
    target = tmp_path / "out.txt"
    target.write_text("hello world content")
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": str(target),
                               "content": "x"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result(output="written"))
    with p, p_exec, p_fmt, patch.object(pk_mod.time, "sleep"):
        events = await _client().invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_tool_use_then_text_only_turns():
    """Follow-up returns non-tool / non-end_turn twice -> smart termination."""
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use",
    })
    # follow-up 1: stop_reason "pause" (not end_turn/tool_use) -> consecutive=1, break
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "thinking"}],
        "stop_reason": "pause",
    })
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with p, p_exec, p_fmt:
        await _client().invoke_with_tools("p", "/proj", system_prompt="sys")
    assert client.post.call_count == 2


@pytest.mark.asyncio
async def test_invoke_with_tools_file_write_success_verified(tmp_path):
    """Relative-path write that succeeds & file present -> readable verify path."""
    # project_path = tmp_path so relative path resolves under it
    rel = "sub/created.txt"
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "created.txt").write_text("content here for preview")
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": rel,
                               "content": "x"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", str(tmp_path))
    assert any(e["type"] == "tool_result" and e["success"] for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_code_editor_failure_enhanced_error():
    """code_editor read failure -> enhanced error message branch (operation/path)."""
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "read", "path": "x.txt"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(
        _fake_tool_result(success=False, error="not found"))
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" and e["success"] is False for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_file_write_verify_fails_then_retry(tmp_path):
    """Write reports success but file missing -> retry with backoff, then give up."""
    missing = str(tmp_path / "never_created.txt")
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": missing,
                               "content": "x"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, client = _patch_post([first, second])
    # 3 attempts each return success=True but file doesn't exist -> verification fails
    p_exec, p_fmt, _ = _patch_tool_executor(
        [_fake_tool_result() for _ in range(3)])
    with p, p_exec, p_fmt, patch.object(pk_mod.time, "sleep") as msleep:
        events = await _client().invoke_with_tools("p", "/proj")
    assert msleep.called  # backoff exercised
    # Enhanced error message produced for failed code_editor write
    assert any(e["type"] == "tool_result" and e["success"] is False for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_bash_failure_enhanced_error():
    """A single failing bash tool -> bash branch of enhanced error (424-429)."""
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls -la /some/dir"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(
        _fake_tool_result(success=False, error="cmd failed"))
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", "/proj")
    assert any(e["type"] == "tool_result" and e["success"] is False for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_file_write_retry_then_success(tmp_path):
    """First write attempt fails (file missing), 2nd succeeds (covers retry 334-377)."""
    target = tmp_path / "f.txt"
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": str(target),
                               "content": "x"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, _ = _patch_post([first, second])

    def _exec_side_effect(name, inp, tid):
        # First call: report success but file does not exist yet -> verify fails
        # Second call: create the file then report success -> verify passes
        if not target.exists():
            return _fake_tool_result(success=True)
        return _fake_tool_result(success=True, output="done")

    import app.services.tool_executor as te_mod
    executor = MagicMock()
    call = {"n": 0}

    def _exec(name, inp, tid):
        call["n"] += 1
        if call["n"] == 1:
            return _fake_tool_result(success=True)  # file still missing -> retry
        target.write_text("created")
        return _fake_tool_result(success=True)

    executor.execute_tool = MagicMock(side_effect=_exec)
    with p, patch.object(te_mod, "ToolExecutor", return_value=executor), \
         patch.object(te_mod, "format_tool_result_for_model",
                      side_effect=lambda tid, r: {"type": "tool_result",
                                                  "tool_use_id": tid, "content": r.output,
                                                  "is_error": not r.success}), \
         patch.object(pk_mod.time, "sleep") as msleep:
        events = await _client().invoke_with_tools("p", str(tmp_path))
    assert msleep.called
    assert any(e["type"] == "tool_result" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_consecutive_failures_cap():
    """3 consecutive bash failures -> max consecutive failures break + error event."""
    blocks = [{"type": "tool_use", "id": f"t{i}", "name": "bash",
               "input": {"command": "false"}} for i in range(3)]
    first = _FakeResponse(json_body={"content": blocks, "stop_reason": "tool_use"})
    # After the inner tool loop breaks, a follow-up POST still fires (end_turn).
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(
        [_fake_tool_result(success=False, error="fail") for _ in range(3)])
    with p, p_exec, p_fmt:
        events = await _client().invoke_with_tools("p", "/proj")
    assert any(e["type"] == "error" and "Max consecutive failures" in e["error"]
               for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_rate_limit_429():
    resp = _FakeResponse(status_code=429, headers={"Retry-After": "30"})
    p, _ = _patch_post(resp)
    with p:
        with pytest.raises(RateLimitError) as ei:
            await _client().invoke_with_tools("p", "/proj")
    assert ei.value.retry_after == 30


@pytest.mark.asyncio
async def test_invoke_with_tools_auth_error_401():
    resp = _FakeResponse(status_code=401, text="nope")
    p, _ = _patch_post(resp)
    with p:
        with pytest.raises(AuthenticationError):
            await _client().invoke_with_tools("p", "/proj")


@pytest.mark.asyncio
async def test_invoke_with_tools_provider_error_500():
    resp = _FakeResponse(status_code=500, text="boom")
    p, _ = _patch_post(resp)
    with p:
        with pytest.raises(ProviderError):
            await _client().invoke_with_tools("p", "/proj")


@pytest.mark.asyncio
async def test_invoke_with_tools_generic_exception_wrapped():
    p, client = _patch_post(_FakeResponse())
    client.post = AsyncMock(side_effect=ValueError("weird"))
    with p:
        with pytest.raises(ProviderError) as ei:
            await _client().invoke_with_tools("p", "/proj")
    assert "Unexpected error" in ei.value.message


@pytest.mark.asyncio
async def test_invoke_with_tools_follow_up_429():
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(status_code=429, headers={"Retry-After": "12"})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with p, p_exec, p_fmt:
        with pytest.raises(RateLimitError) as ei:
            await _client().invoke_with_tools("p", "/proj")
    assert ei.value.retry_after == 12


# ---------------------------------------------------------------------------
# _process_response branches
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_process_response_text_and_tooluse():
    c = _client()
    data = {
        "content": [
            {"type": "text", "text": "hi"},
            {"type": "tool_use", "id": "t1", "name": "code_editor",
             "input": {"operation": "read", "path": "rel/path.txt"}},
        ],
        "stop_reason": "tool_use",
        "usage": {"input_tokens": 5, "output_tokens": 6},
    }
    events = await c._process_response(data, "/proj")
    types = [e.get("subtype") or e["type"] for e in events]
    assert "init" in types
    assert any(e["type"] == "tool_use" for e in events)
    result = [e for e in events if e["type"] == "result"][0]
    assert result["input_tokens"] == 5 and result["output_tokens"] == 6


@pytest.mark.asyncio
async def test_process_response_unknown_block_type():
    """A content block that is neither text nor tool_use still emits start/stop."""
    c = _client()
    data = {"content": [{"type": "image", "source": "x"}],
            "stop_reason": "end_turn", "usage": {}}
    events = await c._process_response(data, "/proj")
    assert any(e.get("subtype") == "content_start" for e in events)
    assert any(e.get("subtype") == "content_stop" for e in events)
    assert not any(e["type"] == "tool_use" for e in events)


@pytest.mark.asyncio
async def test_invoke_with_tools_write_verify_unreadable(tmp_path):
    """File exists but open() raises during preview -> warning branch (362-363)."""
    target = tmp_path / "f.txt"
    target.write_text("data")
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": str(target),
                               "content": "x"}}],
        "stop_reason": "tool_use",
    })
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "ok"}], "stop_reason": "end_turn"})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    real_open = open

    def _boom_open(path, *a, **k):
        if str(path) == str(target) and "r" in (a[0] if a else k.get("mode", "r")):
            raise OSError("cannot read")
        return real_open(path, *a, **k)

    with p, p_exec, p_fmt, patch("builtins.open", side_effect=_boom_open):
        events = await _client().invoke_with_tools("p", str(tmp_path))
    assert any(e["type"] == "tool_result" for e in events)


@pytest.mark.asyncio
async def test_process_response_bash_validation_rejects():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "bash",
                         "input": {"command": "rm -rf /"}}],
            "stop_reason": "tool_use"}
    with patch.object(pk_mod, "settings"):  # not used; real settings via get_settings
        with patch("app.core.security.SecurityValidator.validate_bash_command",
                   side_effect=ValueError("unsafe")):
            events = await c._process_response(data, "/proj")
    assert any(e["type"] == "error" and "Security validation failed" in e["error"]
               for e in events)


@pytest.mark.asyncio
async def test_process_response_bash_validation_passes():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "bash",
                         "input": {"command": "ls"}}],
            "stop_reason": "tool_use"}
    with patch("app.core.security.SecurityValidator.validate_bash_command",
               return_value="ls"):
        events = await c._process_response(data, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


@pytest.mark.asyncio
async def test_process_response_bash_validation_disabled():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "bash",
                         "input": {"command": "ls"}}],
            "stop_reason": "tool_use"}
    fake_settings = MagicMock()
    fake_settings.security.bash_command_validation_enabled = False
    with patch("app.core.config.get_settings", return_value=fake_settings):
        events = await c._process_response(data, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


@pytest.mark.asyncio
async def test_process_response_path_traversal_rejected():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                         "input": {"operation": "write", "path": "../etc/passwd"}}],
            "stop_reason": "tool_use"}
    events = await c._process_response(data, "/proj")
    assert any(e["type"] == "error" and "Security validation failed" in e["error"]
               for e in events)


@pytest.mark.asyncio
async def test_process_response_absolute_path_outside_allowed():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                         "input": {"operation": "write", "path": "/secret/x"}}],
            "stop_reason": "tool_use"}
    with patch("app.core.security.SecurityValidator.is_safe_absolute_path",
               return_value=False):
        events = await c._process_response(data, "/proj")
    assert any(e["type"] == "error" for e in events)


@pytest.mark.asyncio
async def test_process_response_absolute_path_allowed():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                         "input": {"operation": "write", "path": "/test-code/x"}}],
            "stop_reason": "tool_use"}
    with patch("app.core.security.SecurityValidator.is_safe_absolute_path",
               return_value=True):
        events = await c._process_response(data, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


@pytest.mark.asyncio
async def test_process_response_path_validation_disabled():
    c = _client()
    data = {"content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                         "input": {"operation": "write", "path": "../x"}}],
            "stop_reason": "tool_use"}
    fake_settings = MagicMock()
    fake_settings.security.path_traversal_protection_enabled = False
    with patch("app.core.config.get_settings", return_value=fake_settings):
        events = await c._process_response(data, "/proj")
    assert any(e["type"] == "tool_use" for e in events)


@pytest.mark.asyncio
async def test_process_response_exception_handled():
    c = _client()
    # response_data.get raises -> outer except adds error event
    bad = MagicMock()
    bad.get.side_effect = RuntimeError("kaboom")
    events = await c._process_response(bad, "/proj")
    assert events[-1]["type"] == "error"


# ---------------------------------------------------------------------------
# _get_completion_instructions
# ---------------------------------------------------------------------------
def test_get_completion_instructions_returns_text():
    c = _client()
    out = c._get_completion_instructions(1, 5, False)
    assert "MANDATORY FINAL OUTPUT FORMAT" in out


# ---------------------------------------------------------------------------
# invoke_with_tools_agentic
# ---------------------------------------------------------------------------
def _agentic_settings(**over):
    s = MagicMock()
    s.agentic.enabled = over.get("enabled", True)
    s.agentic.unlimited_iterations = over.get("unlimited_iterations", False)
    s.agentic.max_iterations = over.get("max_iterations", 3)
    s.agentic.tool_execution_timeout = 30
    s.agentic.max_consecutive_errors = over.get("max_consecutive_errors", 3)
    return s


@pytest.mark.asyncio
async def test_agentic_disabled_falls_back(monkeypatch):
    s = _agentic_settings(enabled=False)
    with patch("app.core.config.get_settings", return_value=s):
        c = _client()
        with patch.object(c, "invoke_with_tools",
                          AsyncMock(return_value=["fallback"])) as m:
            out = await c.invoke_with_tools_agentic("p", "/proj")
    assert out == ["fallback"]
    m.assert_awaited_once()


@pytest.mark.asyncio
async def test_agentic_end_turn_first_iteration():
    s = _agentic_settings()
    resp = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "hi"}],
        "stop_reason": "end_turn", "usage": {}})
    p, client = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    events_seen = []
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic(
            "p", "/proj", system_prompt="sys", on_event=events_seen.append)
    assert client.post.call_count == 1
    assert events_seen  # on_event fired
    assert any(e["type"] == "result" for e in out)


@pytest.mark.asyncio
async def test_agentic_tool_use_then_end_turn():
    s = _agentic_settings()
    first = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "run"},
                    {"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use", "usage": {}})
    second = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "done"}],
        "stop_reason": "end_turn", "usage": {}})
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 2
    assert any(e["type"] == "tool_use" for e in out)


@pytest.mark.asyncio
async def test_agentic_tool_use_no_events_breaks():
    """stop_reason tool_use but processed events have no tool_use -> break."""
    s = _agentic_settings()
    # content has no tool_use block but stop_reason says tool_use
    resp = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "x"}],
        "stop_reason": "tool_use", "usage": {}})
    p, client = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 1


@pytest.mark.asyncio
async def test_agentic_tool_failure_consecutive_errors_break():
    s = _agentic_settings(max_consecutive_errors=1)
    resp = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "false"}}],
        "stop_reason": "tool_use", "usage": {}})
    p, client = _patch_post([resp])
    p_exec, p_fmt, _ = _patch_tool_executor(
        _fake_tool_result(success=False, error="x"))
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    # broke after first iteration due to consecutive error cap
    assert client.post.call_count == 1


@pytest.mark.asyncio
async def test_agentic_write_operation_success_tracked():
    s = _agentic_settings()
    first = _FakeResponse(json_body={
        "content": [{"type": "text", "text": "writing"},
                    {"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "write", "path": "a.txt"}}],
        "stop_reason": "tool_use", "usage": {}})
    second = _FakeResponse(json_body={
        "content": [], "stop_reason": "end_turn", "usage": {}})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "tool_use" for e in out)


@pytest.mark.asyncio
async def test_agentic_tool_failure_logged_then_continue():
    """One failing tool (cap not reached) -> failure logged, loop continues."""
    s = _agentic_settings(max_consecutive_errors=5)
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "read", "path": "x.txt"}}],
        "stop_reason": "tool_use", "usage": {}})
    second = _FakeResponse(json_body={
        "content": [], "stop_reason": "end_turn", "usage": {}})
    p, client = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(
        _fake_tool_result(success=False, error="boom"))
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 2  # continued past the failure


@pytest.mark.asyncio
async def test_agentic_consecutive_errors_break_mid_loop():
    """Two failing tools in one turn, cap=2 -> break after the second (1102-1105)."""
    s = _agentic_settings(max_consecutive_errors=2)
    resp = _FakeResponse(json_body={
        "content": [
            {"type": "tool_use", "id": "t1", "name": "code_editor",
             "input": {"operation": "read", "path": "a"}},
            {"type": "tool_use", "id": "t2", "name": "code_editor",
             "input": {"operation": "read", "path": "b"}},
        ],
        "stop_reason": "tool_use", "usage": {}})
    p, client = _patch_post([resp])
    p_exec, p_fmt, _ = _patch_tool_executor(
        [_fake_tool_result(success=False, error="e1"),
         _fake_tool_result(success=False, error="e2")])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 1  # broke before follow-up


@pytest.mark.asyncio
async def test_agentic_patch_operation_tracked():
    s = _agentic_settings()
    first = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "code_editor",
                     "input": {"operation": "patch", "path": "a"}}],
        "stop_reason": "tool_use", "usage": {}})
    second = _FakeResponse(json_body={
        "content": [], "stop_reason": "end_turn", "usage": {}})
    p, _ = _patch_post([first, second])
    p_exec, p_fmt, _ = _patch_tool_executor(_fake_tool_result())
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "tool_use" for e in out)


@pytest.mark.asyncio
async def test_agentic_max_tokens_stop():
    s = _agentic_settings()
    resp = _FakeResponse(json_body={
        "content": [], "stop_reason": "max_tokens", "usage": {}})
    p, client = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 1


@pytest.mark.asyncio
async def test_agentic_unexpected_stop_reason():
    s = _agentic_settings()
    resp = _FakeResponse(json_body={
        "content": [], "stop_reason": "weird", "usage": {}})
    p, client = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj")
    assert client.post.call_count == 1


@pytest.mark.asyncio
async def test_agentic_no_result_event_unknown_stop():
    """process_response True but no 'result' event -> stop_reason unknown -> break."""
    s = _agentic_settings()
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "end_turn", "usage": {}})
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        # Patch _process_response to return events without a result event
        c = _client()
        with patch.object(c, "_process_response",
                          AsyncMock(return_value=[{"type": "system"}])):
            await c.invoke_with_tools_agentic("p", "/proj")


@pytest.mark.asyncio
async def test_agentic_raw_response_path():
    """process_response=False -> stop_reason from raw response top-level."""
    s = _agentic_settings()
    resp = _FakeResponse(json_body={"content": [], "stop_reason": "end_turn"})
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic(
            "p", "/proj", process_response=False)
    assert out and out[0]["stop_reason"] == "end_turn"


@pytest.mark.asyncio
async def test_agentic_raw_response_missing_stop_reason():
    s = _agentic_settings()
    resp = _FakeResponse(json_body={"content": []})  # no stop_reason
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic(
            "p", "/proj", process_response=False)


@pytest.mark.asyncio
async def test_agentic_unlimited_mode_then_end_turn():
    s = _agentic_settings(unlimited_iterations=True, max_iterations=0)
    resp = _FakeResponse(json_body={
        "content": [], "stop_reason": "end_turn", "usage": {}})
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        await _client().invoke_with_tools_agentic("p", "/proj", enable_tools=False)


@pytest.mark.asyncio
async def test_agentic_max_iterations_reached():
    """max_iterations small + always tool_use -> loop hits cap, emits max event."""
    s = _agentic_settings(max_iterations=1)
    # tool_use response keeps requesting tools; loop should stop at iteration cap
    resp = _FakeResponse(json_body={
        "content": [{"type": "tool_use", "id": "t1", "name": "bash",
                     "input": {"command": "ls"}}],
        "stop_reason": "tool_use", "usage": {}})
    p, _ = _patch_post([resp, resp, resp])
    p_exec, p_fmt, _ = _patch_tool_executor(
        [_fake_tool_result() for _ in range(5)])
    seen = []
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic(
            "p", "/proj", on_event=seen.append)
    assert any(e.get("subtype") == "max_iterations_reached" for e in out)


@pytest.mark.asyncio
async def test_agentic_provider_error_emits_event():
    """500 inside acquire -> ProviderError -> caught by generic except ->
    consecutive_errors=1 (<2) -> emits error event then breaks."""
    s = _agentic_settings(max_consecutive_errors=2)
    resp = _FakeResponse(status_code=500, text="bad")
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    seen = []
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic(
            "p", "/proj", on_event=seen.append)
    assert any(e["type"] == "error" for e in out)
    assert seen


@pytest.mark.asyncio
async def test_agentic_provider_error_max_errors_break_no_event():
    """cap=1 -> first ProviderError hits >= cap branch and breaks w/o event."""
    s = _agentic_settings(max_consecutive_errors=1)
    resp = _FakeResponse(status_code=500, text="bad")
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert not any(e["type"] == "error" for e in out)


@pytest.mark.asyncio
async def test_agentic_auth_error_emits_event():
    """401 -> AuthenticationError -> caught by generic except -> error event."""
    s = _agentic_settings(max_consecutive_errors=2)
    resp = _FakeResponse(status_code=401, text="no")
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "error" for e in out)


@pytest.mark.asyncio
async def test_agentic_rate_limit_emits_event():
    """429 -> RateLimitError -> inner re-raise -> caught by generic except ->
    error event (RateLimitError is an Exception subclass, not propagated)."""
    s = _agentic_settings(max_consecutive_errors=2)
    resp = _FakeResponse(status_code=429, headers={"Retry-After": "5"})
    p, _ = _patch_post(resp)
    p_exec, p_fmt, _ = _patch_tool_executor([])
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic("p", "/proj")
    assert any(e["type"] == "error" for e in out)


@pytest.mark.asyncio
async def test_agentic_generic_exception_emits_event():
    s = _agentic_settings(max_consecutive_errors=2)
    p, client = _patch_post(_FakeResponse())
    client.post = AsyncMock(side_effect=ValueError("weird"))
    p_exec, p_fmt, _ = _patch_tool_executor([])
    seen = []
    with patch("app.core.config.get_settings", return_value=s), p, p_exec, p_fmt:
        out = await _client().invoke_with_tools_agentic(
            "p", "/proj", on_event=seen.append)
    assert any(e["type"] == "error" for e in out)


# ---------------------------------------------------------------------------
# invoke_with_tools_agentic_graph
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_agentic_graph_success():
    c = _client()

    module = MagicMock()
    module.name = "mod1"
    module.path = "p1"
    module.status.value = "locked"
    module.retries = 0
    module.files_changed = ["a"]
    module.last_error = None
    module.events = [{"type": "tool_use"}]

    state = MagicMock()
    state.total_modules = 1
    state.graph = {"mod1": module}
    state.current_iteration = 2
    state.get_progress.return_value = {"locked": 1, "failed": 0, "skipped": 0}

    orchestrator = MagicMock()
    orchestrator.orchestrate = AsyncMock(return_value=state)

    import app.orchestrator.graph_orchestrator as go_mod
    seen = []
    with patch.object(go_mod, "GraphOrchestrator", return_value=orchestrator):
        out = await c.invoke_with_tools_agentic_graph(
            "p", "/proj", provider_factory=MagicMock(), on_event=seen.append)
    assert any(e.get("subtype") == "graph_start" for e in out)
    assert any(e["type"] == "module_completed" for e in out)
    assert any(e.get("subtype") == "graph_complete" for e in out)
    assert seen  # on_event fired


@pytest.mark.asyncio
async def test_agentic_graph_orchestrate_raises():
    c = _client()
    orchestrator = MagicMock()
    orchestrator.orchestrate = AsyncMock(side_effect=RuntimeError("graph boom"))
    import app.orchestrator.graph_orchestrator as go_mod
    with patch.object(go_mod, "GraphOrchestrator", return_value=orchestrator):
        with pytest.raises(RuntimeError):
            await c.invoke_with_tools_agentic_graph(
                "p", "/proj", provider_factory=MagicMock())


@pytest.mark.asyncio
async def test_agentic_graph_module_no_events():
    c = _client()
    module = MagicMock()
    module.name = "m"
    module.path = "p"
    module.status.value = "failed"
    module.retries = 1
    module.files_changed = []
    module.last_error = "err"
    module.events = []  # falsy -> skip event loop

    state = MagicMock()
    state.total_modules = 1
    state.graph = {"m": module}
    state.current_iteration = 1
    state.get_progress.return_value = {"locked": 0, "failed": 1, "skipped": 0}

    orchestrator = MagicMock()
    orchestrator.orchestrate = AsyncMock(return_value=state)
    import app.orchestrator.graph_orchestrator as go_mod
    with patch.object(go_mod, "GraphOrchestrator", return_value=orchestrator):
        out = await c.invoke_with_tools_agentic_graph(
            "p", "/proj", provider_factory=MagicMock())
    assert any(e["type"] == "module_completed" for e in out)


# ---------------------------------------------------------------------------
# invoke_simple
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_invoke_simple_success():
    resp = _FakeResponse(json_body={"choices": [{"text": "ok"}]})
    p, client = _patch_post(resp)
    with p:
        out = await _client().invoke_simple("hi", max_tokens=10, temperature=0.1)
    assert out == {"choices": [{"text": "ok"}]}
    assert client.post.call_args.args[0].endswith("/chat/completions")


@pytest.mark.asyncio
async def test_invoke_simple_rate_limit():
    resp = _FakeResponse(status_code=429, headers={"Retry-After": "7"})
    p, _ = _patch_post(resp)
    with p:
        with pytest.raises(RateLimitError) as ei:
            await _client().invoke_simple("hi")
    assert ei.value.retry_after == 7


@pytest.mark.asyncio
async def test_invoke_simple_http_error():
    resp = _FakeResponse(status_code=500, text="bad")
    p, _ = _patch_post(resp)
    with p:
        with pytest.raises(ProviderError):
            await _client().invoke_simple("hi")


# ---------------------------------------------------------------------------
# health_check
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_health_check_ok():
    p, _ = _patch_get(_FakeResponse(status_code=200))
    with p:
        assert await _client().health_check() is True


@pytest.mark.asyncio
async def test_health_check_non_200():
    p, _ = _patch_get(_FakeResponse(status_code=503))
    with p:
        assert await _client().health_check() is False


@pytest.mark.asyncio
async def test_health_check_exception():
    client = MagicMock()
    client.get = AsyncMock(side_effect=httpx.ConnectError("down"))
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=client)
    cm.__aexit__ = AsyncMock(return_value=False)
    with patch.object(pk_mod.httpx, "AsyncClient", return_value=cm):
        assert await _client().health_check() is False