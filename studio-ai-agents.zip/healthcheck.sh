#!/bin/bash
# ============================================================================
# Studio AI Engine - Docker Health Check Script
# ============================================================================
# This script is used by Docker to check if the container is healthy.
# It performs checks on the application's health endpoint.
# ============================================================================

set -e

# Health check endpoint
HEALTH_URL="http://localhost:8000/health"

# Timeout for health check
TIMEOUT=5

# Perform health check
response=$(curl -f -s -m $TIMEOUT "$HEALTH_URL" 2>&1)
exit_code=$?

if [ $exit_code -eq 0 ]; then
    # Check if response contains "healthy" status
    if echo "$response" | grep -q '"status":"healthy"' || echo "$response" | grep -q 'status.*healthy'; then
        echo "✓ Health check passed"
        exit 0
    else
        echo "✗ Health check failed: Invalid response"
        echo "Response: $response"
        exit 1
    fi
else
    echo "✗ Health check failed: Connection error (exit code: $exit_code)"
    exit 1
fi
