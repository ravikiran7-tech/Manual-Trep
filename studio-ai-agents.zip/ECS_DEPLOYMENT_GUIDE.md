# 🚀 ECS Deployment Guide for Studio AI Engine

**Version:** 1.0.0  
**Date:** February 11, 2026  
**Status:** Production Ready

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Environment Variables](#environment-variables)
4. [Volume Mounts](#volume-mounts)
5. [IAM Permissions](#iam-permissions)
6. [Port Configuration](#port-configuration)
7. [Health Check](#health-check)
8. [Resource Requirements](#resource-requirements)
9. [Container Startup](#container-startup)
10. [ECS Task Definition Example](#ecs-task-definition-example)
11. [Validation Checklist](#validation-checklist)
12. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

This application is a Python FastAPI service that provides AI-powered code analysis and modernization capabilities using AWS Bedrock (Claude models). It has been tested successfully with `docker-compose.yml` locally and is ready for ECS deployment.

**Key Components Built into Docker Image:**
- ✅ Python 3.11 with all dependencies (see `requirements.txt`)
- ✅ Java SDK (versions 8, 11, 17, 21) via SDKMAN
- ✅ .NET SDK 8.0
- ✅ Maven for Java builds
- ✅ Git, curl, wget, and other utilities
- ✅ Entrypoint script for initialization
- ✅ Health check script

---

## 📦 Prerequisites

### 1. Container Registry
- Push the built Docker image to ECR or your container registry
- Tag format: `studio-ai-engine:1.0.0` or `studio-ai-engine:latest`

### 2. Network Requirements
- VPC with subnets (public or private with NAT)
- Security group allowing:
  - **Inbound:** Port 8000 from ALB/service consumers
  - **Outbound:** 
    - Port 443 for AWS Bedrock API calls
    - Port 443 for Studio Core API calls
    - DNS (port 53) for name resolution

### 3. Storage (EFS Recommended)
- EFS volume for persistent storage at `/studio-app/`
- Or ephemeral storage if persistence is not required

---

## 🔐 Environment Variables

### ✅ **MANDATORY** (Application will NOT start without these)

```bash
# Studio Core Integration (REQUIRED)
STUDIO_CORE_URL=https://dev.cmodernize.com/studio-core

# Encryption Key (REQUIRED)
# Generate with: python -c "import base64, os; print(base64.b64encode(os.urandom(32)).decode())"
ENCRYPTION_KEY=P3qcGy5Nj2oMXh17iisPDg==
```

### ⚙️ **REQUIRED** (With Defaults - Override for Production)

```bash
# Application Settings
APP_NAME=studio-ai-engine-python
APP_VERSION=1.0.0
DEBUG=false

# AWS Configuration (Region required, credentials via IAM Task Role)
AWS_REGION=us-east-1

# Bedrock Models
BEDROCK_MODEL_ID_SONNET=us.anthropic.claude-sonnet-4-5-20250929-v1:0
BEDROCK_DEFAULT_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0
BEDROCK_MAX_TOKENS=64000
BEDROCK_TEMPERATURE=0.0

# Workspace Directory (all outputs go here)
CLAUDE_WORKSPACE=/studio-app/claude-workspace

# Compass Component
COMPASS_COMPONENT=Studio
```

### 🎛️ **OPTIONAL** (Have Sensible Defaults)

```bash
# Timeouts (seconds) - Adjust based on workload
TIMEOUT_DEFAULT=36000                    # 10 hours (for long-running operations)
TIMEOUT_UPGRADE=36000                    # 10 hours
TIMEOUT_SCHEMA_MODERNIZATION=30000       # 8.3 hours
TIMEOUT_BUILD_VALIDATION=18000           # 5 hours

# Resilience Patterns
RESILIENCE_RETRY_MAX_ATTEMPTS=3
RESILIENCE_RETRY_WAIT_MIN=1
RESILIENCE_RETRY_WAIT_MAX=60
RESILIENCE_RETRY_MULTIPLIER=2
RESILIENCE_CIRCUIT_BREAKER_FAIL_THRESHOLD=5
RESILIENCE_CIRCUIT_BREAKER_TIMEOUT=60
RESILIENCE_RATE_LIMIT_PER_MINUTE=60
RESILIENCE_RATE_LIMIT_PER_HOUR=1000

# CORS Configuration (⚠️ Set to specific domains in production)
CORS_ALLOW_ORIGINS=*                     # ⚠️ CHANGE THIS IN PRODUCTION
CORS_ALLOW_CREDENTIALS=true
CORS_ALLOW_METHODS=GET,POST,PUT,DELETE,OPTIONS
CORS_ALLOW_HEADERS=Content-Type,Authorization,X-Requested-With

# Security Settings
SECURITY_VALIDATION_ENABLED=false
SECURITY_BASH_COMMAND_VALIDATION_ENABLED=false
SECURITY_PATH_TRAVERSAL_PROTECTION_ENABLED=false
SECURITY_BYPASS_VALIDATION_FOR_ALLOWED_DIRECTORIES=true
SECURITY_ALLOW_SAFE_PIPES=true
SECURITY_ALLOW_SAFE_COMMAND_CHAINS=true
SECURITY_ALLOWED_DIRECTORIES=/test-code,/studio-app

# Agentic Tool Execution
AGENTIC_ENABLED=true
AGENTIC_MAX_ITERATIONS=50
AGENTIC_MAX_TOTAL_TOKENS=500000
AGENTIC_TOOL_EXECUTION_TIMEOUT=30
AGENTIC_MAX_CONSECUTIVE_ERRORS=10
AGENTIC_GRAPH_ORCHESTRATION_ENABLED=true
AGENTIC_MAX_MODULE_RETRIES=3
AGENTIC_VALIDATION_TIMEOUT=300
AGENTIC_SKIP_VALIDATION=true

# Portkey Configuration (Optional - only if using Portkey)
PORTKEY_BASE_URL=https://api.portkey.ai/v1
```

### ❌ **DO NOT SET** (ECS Will Handle via IAM Task Role)

```bash
# These should NOT be in environment variables for ECS
AWS_ACCESS_KEY_ID        # ❌ Use IAM Task Role instead
AWS_SECRET_ACCESS_KEY    # ❌ Use IAM Task Role instead
AWS_PROFILE              # ❌ Not needed in ECS
```

---

## 💾 Volume Mounts

### **Option 1: EFS Mount (Recommended for Production)**

Mount an EFS volume to persist workspace and outputs across container restarts.

**EFS Mount Point:** `/studio-app/`

**Why EFS?**
- ✅ Persistent storage across container restarts
- ✅ Shared between multiple tasks (if scaling)
- ✅ Automatic backups available
- ✅ No data loss on task termination

**ECS Task Definition Configuration:**
```json
{
  "volumes": [
    {
      "name": "studio-app-storage",
      "efsVolumeConfiguration": {
        "fileSystemId": "fs-xxxxxxxxx",
        "rootDirectory": "/",
        "transitEncryption": "ENABLED",
        "authorizationConfig": {
          "iam": "ENABLED"
        }
      }
    }
  ],
  "mountPoints": [
    {
      "sourceVolume": "studio-app-storage",
      "containerPath": "/studio-app",
      "readOnly": false
    }
  ]
}
```

### **Option 2: Ephemeral Storage (Testing/Development)**

If persistence is not required, the Dockerfile creates the directory automatically:
- `/studio-app/claude-workspace` (all outputs go here)

**Note:** Data will be lost when container stops. Application logs go to stdout/stderr (CloudWatch Logs in ECS).

---

## 🔑 IAM Permissions

### **ECS Task Role** (REQUIRED)

Create an IAM role for the ECS task with the following permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": [
        "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-sonnet-20240229-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/us.anthropic.claude-sonnet-4-5-20250929-v1:0"
      ]
    }
  ]
}
```

### **EFS Access** (If using EFS)

Add to the same task role:

```json
{
  "Effect": "Allow",
  "Action": [
    "elasticfilesystem:ClientMount",
    "elasticfilesystem:ClientWrite",
    "elasticfilesystem:ClientRootAccess"
  ],
  "Resource": "arn:aws:elasticfilesystem:us-east-1:ACCOUNT_ID:file-system/fs-xxxxxxxxx"
}
```

### **ECS Task Execution Role** (For ECR and CloudWatch)

Standard AWS managed role: `arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy`

---

## 🌐 Port Configuration

**Container Port:** `8000`

**Protocol:** TCP

**Context Path:** `/studio-ai-agents`

**Health Check Endpoint:** `http://localhost:8000/health` (without context path for Docker/ALB)

**API Endpoints (with context path):**
- Main API: `http://localhost:8000/studio-ai-agents/api/claude/executeCommandWithPrompt`
- Health: `http://localhost:8000/studio-ai-agents/health`
- Swagger UI: `http://localhost:8000/studio-ai-agents/docs`
- ReDoc: `http://localhost:8000/studio-ai-agents/redoc`
- OpenAPI Schema: `http://localhost:8000/studio-ai-agents/openapi.json`

**Target Group Configuration:**
- Protocol: HTTP
- Port: 8000
- Health Check Path: `/health`
- Health Check Interval: 30 seconds
- Health Check Timeout: 10 seconds
- Healthy Threshold: 2
- Unhealthy Threshold: 3

---

## 🏥 Health Check

### **Docker Health Check** (Built into Image)

```bash
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3
```

**Health Check Script:** `/app/healthcheck.sh`
- Checks `http://localhost:8000/health`
- Expects response containing `"status":"healthy"`

### **ECS Health Check** (Configure in Task Definition)

```json
{
  "healthCheck": {
    "command": [
      "CMD-SHELL",
      "/app/healthcheck.sh || exit 1"
    ],
    "interval": 30,
    "timeout": 10,
    "retries": 3,
    "startPeriod": 40
  }
}
```

### **Health Check Response Example**

```json
{
  "status": "healthy",
  "service": "studio-ai-engine-python",
  "version": "1.0.0",
  "resilience": {
    "circuit_breakers": {},
    "rate_limits": {}
  }
}
```

---

## 💻 Resource Requirements

### **Minimum Requirements** (Development/Testing)

```json
{
  "cpu": "1024",        # 1 vCPU
  "memory": "2048"      # 2 GB
}
```

### **Recommended for Production**

```json
{
  "cpu": "2048",        # 2 vCPU
  "memory": "4096"      # 4 GB
}
```

### **High-Performance Configuration**

```json
{
  "cpu": "4096",        # 4 vCPU
  "memory": "8192"      # 8 GB
}
```

**Why More Resources?**
- AI model responses can be large (up to 64K tokens)
- Long-running operations (up to 10 hours)
- Java/Maven/DotNet builds require memory
- Concurrent API requests

---

## 🎬 Container Startup

### **Entrypoint:** `/app/entrypoint.sh`

The entrypoint script performs:
1. ✅ Environment variable validation (`STUDIO_CORE_URL`, `ENCRYPTION_KEY`)
2. ✅ Workspace directory creation
3. ✅ Configuration logging
4. ✅ AWS credentials check (IAM role or explicit)

### **Default CMD:** 

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

**Workers:** 4 (adjust based on CPU cores)

### **Override CMD** (If Needed)

For single-worker mode (debugging):
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1 --log-level debug
```

---

## 📝 ECS Task Definition Example

Here's a complete ECS task definition JSON:

```json
{
  "family": "studio-ai-engine",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "2048",
  "memory": "4096",
  "executionRoleArn": "arn:aws:iam::ACCOUNT_ID:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::ACCOUNT_ID:role/studio-ai-engine-task-role",
  "containerDefinitions": [
    {
      "name": "studio-ai-engine",
      "image": "ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/studio-ai-engine:latest",
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "APP_NAME",
          "value": "studio-ai-engine-python"
        },
        {
          "name": "APP_VERSION",
          "value": "1.0.0"
        },
        {
          "name": "DEBUG",
          "value": "false"
        },
        {
          "name": "AWS_REGION",
          "value": "us-east-1"
        },
        {
          "name": "BEDROCK_MODEL_ID_SONNET",
          "value": "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        },
        {
          "name": "BEDROCK_DEFAULT_MODEL",
          "value": "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        },
        {
          "name": "BEDROCK_MAX_TOKENS",
          "value": "64000"
        },
        {
          "name": "BEDROCK_TEMPERATURE",
          "value": "0.0"
        },
        {
          "name": "STUDIO_CORE_URL",
          "value": "https://dev.cmodernize.com/studio-core"
        },
        {
          "name": "COMPASS_COMPONENT",
          "value": "Studio"
        },
        {
          "name": "CLAUDE_WORKSPACE",
          "value": "/studio-app/claude-workspace"
        },
        {
          "name": "TIMEOUT_DEFAULT",
          "value": "36000"
        },
        {
          "name": "TIMEOUT_UPGRADE",
          "value": "36000"
        },
        {
          "name": "TIMEOUT_SCHEMA_MODERNIZATION",
          "value": "30000"
        },
        {
          "name": "TIMEOUT_BUILD_VALIDATION",
          "value": "18000"
        },
        {
          "name": "RESILIENCE_RETRY_MAX_ATTEMPTS",
          "value": "3"
        },
        {
          "name": "RESILIENCE_CIRCUIT_BREAKER_FAIL_THRESHOLD",
          "value": "5"
        },
        {
          "name": "RESILIENCE_RATE_LIMIT_PER_MINUTE",
          "value": "60"
        },
        {
          "name": "RESILIENCE_RATE_LIMIT_PER_HOUR",
          "value": "1000"
        },
        {
          "name": "CORS_ALLOW_ORIGINS",
          "value": "*"
        },
        {
          "name": "CORS_ALLOW_CREDENTIALS",
          "value": "true"
        },
        {
          "name": "CORS_ALLOW_METHODS",
          "value": "GET,POST,PUT,DELETE,OPTIONS"
        },
        {
          "name": "CORS_ALLOW_HEADERS",
          "value": "Content-Type,Authorization,X-Requested-With"
        },
        {
          "name": "SECURITY_VALIDATION_ENABLED",
          "value": "false"
        },
        {
          "name": "SECURITY_BASH_COMMAND_VALIDATION_ENABLED",
          "value": "false"
        },
        {
          "name": "SECURITY_PATH_TRAVERSAL_PROTECTION_ENABLED",
          "value": "false"
        },
        {
          "name": "SECURITY_BYPASS_VALIDATION_FOR_ALLOWED_DIRECTORIES",
          "value": "true"
        },
        {
          "name": "SECURITY_ALLOW_SAFE_PIPES",
          "value": "true"
        },
        {
          "name": "SECURITY_ALLOW_SAFE_COMMAND_CHAINS",
          "value": "true"
        },
        {
          "name": "SECURITY_ALLOWED_DIRECTORIES",
          "value": "/test-code,/studio-app"
        },
        {
          "name": "AGENTIC_ENABLED",
          "value": "true"
        },
        {
          "name": "AGENTIC_MAX_ITERATIONS",
          "value": "50"
        },
        {
          "name": "AGENTIC_MAX_TOTAL_TOKENS",
          "value": "500000"
        },
        {
          "name": "AGENTIC_GRAPH_ORCHESTRATION_ENABLED",
          "value": "true"
        },
        {
          "name": "AGENTIC_SKIP_VALIDATION",
          "value": "true"
        }
      ],
      "secrets": [
        {
          "name": "ENCRYPTION_KEY",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:ACCOUNT_ID:secret:studio-ai-engine/encryption-key"
        }
      ],
      "mountPoints": [
        {
          "sourceVolume": "studio-app-storage",
          "containerPath": "/studio-app",
          "readOnly": false
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/studio-ai-engine",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      },
      "healthCheck": {
        "command": [
          "CMD-SHELL",
          "/app/healthcheck.sh || exit 1"
        ],
        "interval": 30,
        "timeout": 10,
        "retries": 3,
        "startPeriod": 40
      }
    }
  ],
  "volumes": [
    {
      "name": "studio-app-storage",
      "efsVolumeConfiguration": {
        "fileSystemId": "fs-xxxxxxxxx",
        "rootDirectory": "/",
        "transitEncryption": "ENABLED",
        "authorizationConfig": {
          "iam": "ENABLED"
        }
      }
    }
  ]
}
```

---

## ✅ Validation Checklist

Use this checklist after deployment to verify everything is working:

### **Pre-Deployment**
- [ ] Docker image built successfully
- [ ] Image pushed to ECR with correct tag
- [ ] EFS file system created (if using persistent storage)
- [ ] IAM Task Role created with Bedrock permissions
- [ ] IAM Task Execution Role has ECR/CloudWatch permissions
- [ ] Security group allows port 8000 inbound
- [ ] Security group allows port 443 outbound (Bedrock, Studio Core)
- [ ] `ENCRYPTION_KEY` stored in AWS Secrets Manager
- [ ] `STUDIO_CORE_URL` configured correctly

### **Post-Deployment**
- [ ] ECS task starts successfully
- [ ] Health check passes (`/health` returns `"status":"healthy"`)
- [ ] Container logs show "✓ Application startup complete"
- [ ] Can access Swagger UI at `/docs`
- [ ] Test API call: `GET /api/claude/health` returns 200
- [ ] Bedrock API calls work (check IAM permissions)
- [ ] Studio Core connectivity works
- [ ] Files are being written to `/studio-app/` (if using EFS)

### **Functional Testing**
- [ ] Execute a simple analysis operation
- [ ] Verify output files are created in correct locations
- [ ] Check stream visualization endpoint works
- [ ] Test timeout handling for long operations
- [ ] Verify resilience patterns (retry, circuit breaker)

---

## 🔧 Troubleshooting

### **Issue: Container won't start**

**Check:**
1. **Logs:** `aws ecs describe-tasks` and check CloudWatch logs
2. **Environment Variables:** Ensure `STUDIO_CORE_URL` and `ENCRYPTION_KEY` are set
3. **IAM Permissions:** Verify Task Role has Bedrock access
4. **Network:** Check security group allows outbound HTTPS

**Common Errors:**
```
ERROR: Required environment variable STUDIO_CORE_URL is not set
→ Set STUDIO_CORE_URL in task definition

ERROR: Required environment variable ENCRYPTION_KEY is not set
→ Add ENCRYPTION_KEY to Secrets Manager and reference in task definition
```

### **Issue: Health check failing**

**Check:**
1. Application is listening on port 8000
2. Security group allows traffic on port 8000
3. Health check endpoint is accessible: `curl http://localhost:8000/health`

**Debug:**
```bash
# SSH into container or use ECS Exec
curl http://localhost:8000/health
# Should return: {"status":"healthy",...}
```

### **Issue: Bedrock API calls failing**

**Check:**
1. **IAM Task Role** has `bedrock:InvokeModel` permission
2. **Region** matches where Bedrock model is available (`us-east-1`)
3. **Model ID** is correct and accessible in your account

**Test IAM:**
```bash
aws bedrock invoke-model \
  --model-id anthropic.claude-3-sonnet-20240229-v1:0 \
  --region us-east-1 \
  --body '{"messages":[{"role":"user","content":"test"}],"max_tokens":100}' \
  output.json
```

### **Issue: Files not persisting**

**Check:**
1. EFS volume is mounted correctly
2. Mount point is `/studio-app/`
3. EFS security group allows NFS traffic (port 2049)
4. IAM Task Role has EFS permissions

**Verify Mount:**
```bash
df -h | grep studio-app
# Should show EFS mount
```

### **Issue: Out of memory errors**

**Solution:**
- Increase task memory (try 8 GB)
- Reduce `BEDROCK_MAX_TOKENS` to 32000
- Reduce `AGENTIC_MAX_TOTAL_TOKENS` to 250000
- Use single worker: `--workers 1`

### **Issue: Timeout errors**

**Solution:**
- Increase ALB target timeout (match `TIMEOUT_DEFAULT`)
- Increase ECS task deregistration delay
- For long operations, consider async processing

---

## 📞 Support

**Application Logs:** CloudWatch Logs Group `/ecs/studio-ai-engine`

**Debug Mode:** Set `DEBUG=true` for verbose logging

**API Documentation:** Access `/docs` endpoint for Swagger UI

**Health Check:** Monitor `/health` endpoint for application status

---

## 🔒 Security Recommendations for Production

1. **CORS:** Change `CORS_ALLOW_ORIGINS=*` to specific domains
2. **Secrets:** Store `ENCRYPTION_KEY` in AWS Secrets Manager (not environment variables)
3. **IAM:** Use least-privilege permissions for Task Role
4. **Network:** Deploy in private subnets with NAT Gateway
5. **EFS:** Enable encryption at rest and in transit
6. **Logs:** Enable CloudWatch Logs for audit trail
7. **Updates:** Regularly update base image for security patches

---

**Document Version:** 1.0.0  
**Last Updated:** February 11, 2026  
**Maintained By:** Studio AI Engine Team
