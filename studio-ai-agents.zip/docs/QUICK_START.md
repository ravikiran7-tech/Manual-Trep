# Quick Start Guide - Studio AI Engine (Python/MVP)

Get the Python-based Studio AI Engine running in 5 minutes.

---

## Prerequisites

- Python 3.10 or higher
- AWS credentials configured (for Bedrock)
- Studio Core instance running (for Compass integration)

---

## Installation Steps

### 1. Navigate to Python Directory

```bash
cd /Users/Gaurav/studio-ai-engine/src/main/python
```

### 2. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

**Expected output:**
```
Successfully installed fastapi-0.109.0 uvicorn-0.27.0 boto3-1.34.34 ...
```

### 4. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your settings:

```bash
# AWS Configuration
AWS_REGION=us-east-1
AWS_PROFILE=default

# Bedrock Models
BEDROCK_MODEL_ID=anthropic.claude-3-sonnet-20240229-v1:0
BEDROCK_MODEL_ID_HAIKU=anthropic.claude-3-haiku-20240307-v1:0

# Studio Core Integration
STUDIO_CORE_URL=https://your-studio-instance/studio-core
COMPASS_COMPONENT=claude-code

# Workspace
CLAUDE_WORKSPACE=/studio-app/claude-workspace
OUTPUT_DIR=/tmp/claude-outputs

# Encryption (for Portkey API keys)
ENCRYPTION_KEY=your-base64-encryption-key

# Application
APP_NAME=studio-ai-engine-python
APP_VERSION=1.0.0
DEBUG=true

# CORS
CORS_ALLOW_ORIGINS=*
CORS_ALLOW_CREDENTIALS=true

# Timeouts (seconds)
TIMEOUT_DEFAULT=3000
TIMEOUT_UPGRADE=3600
TIMEOUT_SCHEMA_MODERNIZATION=3000
TIMEOUT_BUILD_VALIDATION=1800
TIMEOUT_SLEEP_TEST_MINUTES=15
```

### 5. Create Required Directories

```bash
mkdir -p /tmp/claude-outputs
mkdir -p /studio-app/claude-workspace  # Or your configured workspace
```

### 6. Verify AWS Credentials

```bash
aws sts get-caller-identity --profile default
```

**Expected output:**
```json
{
    "UserId": "...",
    "Account": "...",
    "Arn": "..."
}
```

---

## Running the Application

### Development Mode (with auto-reload)

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Expected output:**
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process [12345] using StatReload
INFO:     Started server process [12346]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     ClaudeService initialized with provider factory
INFO:     StreamVisualizationService initialized
INFO:     Claude API router registered successfully
INFO:     Stream visualization router registered successfully
```

### Production Mode (with workers)

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## Verify Installation

### 1. Health Checks

```bash
# Application health
curl http://localhost:8000/health

# Claude API health
curl http://localhost:8000/api/claude/health

# Stream API health
curl http://localhost:8000/api/stream/health
```

**Expected responses:**
```json
{"status":"healthy","service":"studio-ai-engine-python","version":"1.0.0","resilience":{...}}
"Claude CLI API is running"
{"status":"healthy","service":"StreamVisualizationService","timestamp":"..."}
```

### 2. API Documentation

Open in browser:
```
http://localhost:8000/swagger-ui.html
```

Or get OpenAPI schema:
```bash
curl http://localhost:8000/openapi.json
```

### 3. Test Analysis Operation

Create a test prompt file:
```bash
cat > /tmp/test-prompt.txt << 'EOF'
Analyze this codebase for Java version upgrade opportunities.
Identify deprecated APIs and suggest modern alternatives.
EOF
```

Execute analysis:
```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "/tmp/test-prompt.txt",
    "project_path": "/path/to/your/java/project",
    "analysis_id": "test-001",
    "operation": "analysis",
    "platform": "linux"
  }'
```

**Expected response:**
```json
{
  "status": "success",
  "message": "Operation completed successfully",
  "exitCode": 0,
  "output": "/tmp/claude-outputs/versionUpgrade/test-001/analysis-stream.json",
  "outputFilePath": "/tmp/claude-outputs/versionUpgrade/test-001/analysis-stream.json"
}
```

### 4. Get Stream Data

```bash
curl http://localhost:8000/api/stream/test-001/analysis
```

**Expected response:**
```json
{
  "analysisId": "test-001",
  "operation": "analysis",
  "status": "success",
  "message": "Stream data retrieved successfully",
  "streamData": "{\"events\": [...], \"metadata\": {...}}"
}
```

---

## Testing Operations

### Analysis Operation

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "/path/to/prompt.txt",
    "project_path": "/projects/my-app",
    "analysis_id": "analysis-001",
    "operation": "analysis"
  }'
```

### Fix Upgrade Operation

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "/path/to/fix-prompt.txt",
    "project_path": "/projects/my-app",
    "analysis_id": "fix-001",
    "operation": "fix-upgrade"
  }'
```

### Schema Modernization

```bash
curl -X POST http://localhost:8000/api/claude/schema-modernization \
  -H "Content-Type: application/json" \
  -d '{
    "analysis_id": "schema-001",
    "source_db_type": "Oracle",
    "target_db_type": "PostgreSQL",
    "source_schema_path": "/schemas/oracle.sql",
    "project_path": "/projects/db-migration"
  }'
```

---

## Troubleshooting

### Issue: Module not found errors

**Solution:**
```bash
# Ensure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: AWS credentials error

**Solution:**
```bash
# Verify AWS credentials
aws configure list --profile default

# Or set environment variables
export AWS_ACCESS_KEY_ID=your-key
export AWS_SECRET_ACCESS_KEY=your-secret
export AWS_REGION=us-east-1
```

### Issue: Port 8000 already in use

**Solution:**
```bash
# Use a different port
uvicorn app.main:app --reload --port 8080

# Or kill the process using port 8000
lsof -ti:8000 | xargs kill -9
```

### Issue: Workspace directory not found

**Solution:**
```bash
# Create workspace directory
mkdir -p /studio-app/claude-workspace
mkdir -p /tmp/claude-outputs

# Or update .env to use different paths
OUTPUT_DIR=/Users/Gaurav/claude-outputs
CLAUDE_WORKSPACE=/Users/Gaurav/claude-workspace
```

### Issue: Compass connection fails

**Solution:**
```bash
# Verify Studio Core is running
curl https://your-studio-instance/studio-core/health

# Check .env configuration
cat .env | grep STUDIO_CORE_URL

# Verify network connectivity
ping your-studio-instance
```

---

## Logs and Debugging

### Enable Debug Logging

Edit `.env`:
```bash
DEBUG=true
LOG_LEVEL=DEBUG
```

### View Logs

Application logs will be output to console. For production, redirect to file:

```bash
uvicorn app.main:app --log-config logging.conf > app.log 2>&1 &
```

### Check Stream Files

```bash
# List all stream files
find /tmp/claude-outputs -name "*-stream.json"

# View stream file
cat /tmp/claude-outputs/versionUpgrade/test-001/analysis-stream.json | jq
```

---

## Production Deployment

### Using systemd (Linux)

Create `/etc/systemd/system/studio-ai-engine.service`:

```ini
[Unit]
Description=Studio AI Engine Python
After=network.target

[Service]
Type=simple
User=studio
WorkingDirectory=/opt/studio-ai-engine/src/main/python
Environment="PATH=/opt/studio-ai-engine/src/main/python/venv/bin"
ExecStart=/opt/studio-ai-engine/src/main/python/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable studio-ai-engine
sudo systemctl start studio-ai-engine
sudo systemctl status studio-ai-engine
```

### Using Docker (Future)

```bash
# Will be available after Dockerfile is created
docker build -t studio-ai-engine:latest .
docker run -p 8000:8000 studio-ai-engine:latest
```

---

## Next Steps

1. **Test with real workloads**: Use actual Java projects for analysis
2. **Monitor performance**: Check token usage and operation duration
3. **Review stream outputs**: Verify AI responses are correct
4. **Integrate with frontend**: Connect Studio Core UI to new endpoints
5. **Implement remaining handlers**: Build compilation, cloud readiness, etc.

---

## Support

For issues or questions:
- Check `MVP_STATUS.md` for feature availability
- Review `IMPLEMENTATION_STATUS.md` for detailed architecture
- Check logs in console or `app.log`
- Verify all prerequisites are met

---

**Status**: MVP Ready for Testing ✅
