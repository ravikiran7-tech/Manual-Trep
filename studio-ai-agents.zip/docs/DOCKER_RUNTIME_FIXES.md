# Docker Runtime Fixes

## Summary

This document details all the fixes applied to resolve Docker container startup issues.

**Status**: ✅ **RESOLVED** - Application is now running successfully

**Container Status**: `Up (healthy)` on port 8000

---

## Issues Fixed

### 1. Circuit Breaker Parameter Errors

**Issue**: `TypeError: CircuitBreaker.__init__() got an unexpected keyword argument 'timeout_duration'`

**Root Cause**: The `pybreaker` library uses different parameter names than expected.

**Fix Applied** (`app/core/resilience.py`):
- Changed `timeout_duration` → `reset_timeout`
- Removed `expected_exception` parameter (not supported by pybreaker)

```python
# Before (incorrect)
bedrock_circuit_breaker = AsyncCircuitBreaker(
    fail_max=settings.resilience.circuit_breaker_fail_threshold,
    timeout_duration=settings.resilience.circuit_breaker_timeout,
    expected_exception=Exception,
    name="bedrock_circuit_breaker"
)

# After (correct)
bedrock_circuit_breaker = AsyncCircuitBreaker(
    fail_max=settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=settings.resilience.circuit_breaker_timeout,
    name="bedrock_circuit_breaker"
)
```

### 2. Invalid Exception Handler in Router

**Issue**: `AttributeError: 'APIRouter' object has no attribute 'exception_handler'`

**Root Cause**: Exception handlers can only be registered with the main FastAPI app, not with routers.

**Fix Applied** (`app/api/v1/claude.py`):
- Removed `@router.exception_handler` decorator
- Exception handlers are already defined in `app/main.py`

```python
# Removed from claude.py
@router.exception_handler(ValidationError)
async def validation_error_handler(request, exc: ValidationError):
    # ...
```

### 3. Configuration Attribute Error

**Issue**: `AttributeError: 'StudioCoreConfig' object has no attribute 'url'`

**Root Cause**: The configuration field name was `base_url`, not `url`.

**Fix Applied** (`app/main.py`):
```python
# Before
if not settings.studio_core.url:

# After
if not settings.studio_core or not settings.studio_core.base_url:
```

### 4. AWS Credentials Validation Too Strict

**Issue**: `ConfigurationError: AWS configuration error Details: Check AWS profile 'default': The config profile (default) could not be found`

**Root Cause**: Container environment uses IAM roles, not AWS profiles.

**Fix Applied** (`app/main.py`):
- Made AWS credential validation non-blocking
- Allow fallback to IAM roles or environment variables
- Changed from hard error to warning

```python
# Before (strict validation)
session = boto3.Session(
    profile_name=settings.bedrock.profile,
    region_name=settings.bedrock.region
)
credentials = session.get_credentials()
if credentials is None:
    raise ConfigurationError(...)

# After (flexible validation)
session = boto3.Session(
    profile_name=settings.bedrock.profile if settings.bedrock.profile != "default" else None,
    region_name=settings.bedrock.region
)
credentials = session.get_credentials()
if credentials is None:
    logger.warning("⚠ No AWS credentials found - will rely on IAM role")
else:
    logger.info("✓ AWS credentials validated")
```

### 5. Circuit Breaker Status Attributes

**Issue**: `AttributeError: 'AsyncCircuitBreaker' object has no attribute 'opened'`

**Root Cause**: The `pybreaker` library doesn't expose `opened` or `_timeout_duration` attributes.

**Fix Applied** (`app/core/resilience.py`):
```python
# Before
return {
    "name": breaker.name,
    "state": breaker.current_state,
    "fail_counter": breaker.fail_counter,
    "fail_max": breaker.fail_max,
    "opened": breaker.opened,  # ❌ Not available
    "timeout_duration": breaker._timeout_duration  # ❌ Not available
}

# After
return {
    "name": breaker.name,
    "state": breaker.current_state,
    "fail_counter": breaker.fail_counter,
    "fail_max": breaker.fail_max
}
```

### 6. CORS Configuration Parsing

**Issue**: Pydantic was attempting to parse `CORS_ALLOW_ORIGINS` as JSON array instead of comma-separated string.

**Fix Applied** (`app/core/config.py`):
- Added `@field_validator` to parse comma-separated strings
- Changed field type to `Union[list[str], str]`

```python
@field_validator('cors_allow_origins', 'cors_allow_methods', 'cors_allow_headers', mode='before')
@classmethod
def parse_cors_list(cls, v):
    """Parse CORS settings from string or list."""
    if isinstance(v, str):
        return [item.strip() for item in v.split(',') if item.strip()]
    return v
```

### 7. Pydantic Protected Namespace Warning

**Issue**: `UserWarning: Field "model_id_sonnet" in BedrockConfig has conflict with protected namespace "model_"`

**Fix Applied** (`app/core/config.py`):
```python
model_config = SettingsConfigDict(
    env_prefix="",
    case_sensitive=False,
    protected_namespaces=('settings_',)  # Changed from default 'model_'
)
```

---

## Verification

### Health Check
```bash
curl http://localhost:8000/health
```

**Response**:
```json
{
  "status": "healthy",
  "service": "studio-ai-engine-python",
  "version": "1.0.0",
  "resilience": {
    "circuit_breakers": {
      "bedrock": {
        "name": "bedrock_circuit_breaker",
        "state": "closed",
        "fail_counter": 0,
        "fail_max": 5
      },
      "portkey": {
        "name": "portkey_circuit_breaker",
        "state": "closed",
        "fail_counter": 0,
        "fail_max": 5
      },
      "compass": {
        "name": "compass_circuit_breaker",
        "state": "closed",
        "fail_counter": 0,
        "fail_max": 5
      }
    },
    "rate_limiting": {
      "enabled": true,
      "per_minute": 60,
      "per_hour": 1000
    },
    "retry_config": {
      "max_attempts": 3,
      "wait_min": 1,
      "wait_max": 60,
      "multiplier": 2
    }
  }
}
```

### Container Status
```bash
docker-compose ps
```

**Output**:
```
         Name                        Command                  State                        Ports                  
------------------------------------------------------------------------------------------------------------------
studio-ai-engine-python   /app/entrypoint.sh uvicorn ...   Up (healthy)   0.0.0.0:8000->8000/tcp,:::8000->8000/tcp
```

---

## CORS Configuration Recommendation

For production deployment with `dev.cmodernize.com`, update `.env`:

```bash
# Secure CORS configuration
CORS_ALLOW_ORIGINS=https://dev.cmodernize.com,https://app.cmodernize.com
CORS_ALLOW_CREDENTIALS=true
CORS_ALLOW_METHODS=GET,POST,PUT,DELETE,OPTIONS
CORS_ALLOW_HEADERS=Content-Type,Authorization,X-Requested-With
```

**Security Notes**:
- ✅ Use specific domain names (not `*`)
- ✅ Include protocol (`https://`)
- ✅ Comma-separated for multiple origins
- ❌ Don't use `*` with `CORS_ALLOW_CREDENTIALS=true`

---

## Files Modified

1. **`app/core/resilience.py`**
   - Fixed circuit breaker initialization parameters
   - Simplified circuit breaker status function

2. **`app/api/v1/claude.py`**
   - Removed invalid exception handler decorator

3. **`app/main.py`**
   - Fixed configuration attribute reference
   - Made AWS credential validation flexible

4. **`app/core/config.py`**
   - Added CORS field validators
   - Updated protected namespaces

---

## Next Steps

1. **Update CORS Configuration**: Add your production domain to `CORS_ALLOW_ORIGINS`
2. **Configure AWS Credentials**: Ensure IAM role or environment variables are set
3. **Test API Endpoints**: Verify all endpoints are working correctly
4. **Monitor Logs**: Check for any runtime warnings or errors

---

## Testing Commands

```bash
# Check container status
docker-compose ps

# View logs
docker-compose logs -f

# Test health endpoint
curl http://localhost:8000/health

# Test API documentation
curl http://localhost:8000/docs

# Restart container
docker-compose restart

# Rebuild and restart
docker-compose down && docker-compose up -d --build
```

---

**Date**: 2026-01-19  
**Status**: ✅ All issues resolved - Application running successfully
