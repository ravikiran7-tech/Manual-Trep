# API Testing Guide

Complete guide for testing the Studio AI Engine endpoints.

**Base URL**: `http://localhost:8000`

---

## Table of Contents

1. [Interactive API Documentation (Swagger UI)](#interactive-api-documentation)
2. [Available Endpoints](#available-endpoints)
3. [Testing with cURL](#testing-with-curl)
4. [Testing with Python](#testing-with-python)
5. [Testing with Postman](#testing-with-postman)
6. [Testing with HTTPie](#testing-with-httpie)
7. [Common Operations Examples](#common-operations-examples)

---

## Interactive API Documentation

The **easiest way** to test the endpoints is using the built-in Swagger UI:

### Access Swagger UI

```bash
# Open in browser
http://localhost:8000/docs
```

**Features**:
- ✅ Interactive testing interface
- ✅ Automatic request/response validation
- ✅ Try it out directly in browser
- ✅ See all available endpoints and parameters
- ✅ View request/response schemas

### Alternative: ReDoc Documentation

```bash
# Open in browser
http://localhost:8000/redoc
```

---

## Available Endpoints

### 1. Health Checks

#### Application Health
```
GET /health
```

#### Claude API Health
```
GET /api/claude/health
```

### 2. Main Operations

#### Execute Claude Command
```
POST /api/claude/executeCommandWithPrompt
```

#### Schema Modernization
```
POST /api/claude/schema-modernization
```

#### Sleep Test (for timeout testing)
```
GET /api/claude/sleep-test
```

---

## Testing with cURL

### 1. Health Check

```bash
# Application health
curl -X GET http://localhost:8000/health | jq .

# Claude API health
curl -X GET http://localhost:8000/api/claude/health
```

**Expected Response** (Application Health):
```json
{
  "status": "healthy",
  "service": "studio-ai-engine-python",
  "version": "1.0.0",
  "resilience": {
    "circuit_breakers": {
      "bedrock": {
        "name": "bedrock_circuit_breaker",
        "state": "closed",
        "fail_counter": 0,
        "fail_max": 5
      }
    }
  }
}
```

### 2. Execute Command - Code Analysis

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/your/project",
    "operation": "analysis",
    "analysisId": "test-001",
    "platform": "linux"
  }' | jq .
```

### 3. Execute Command - Fix & Upgrade

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/your/project",
    "operation": "fix-upgrade",
    "analysisId": "test-002",
    "prompt": "Upgrade to Java 21 and fix deprecated APIs",
    "platform": "linux"
  }' | jq .
```

### 4. Schema Modernization (Oracle to PostgreSQL)

```bash
curl -X POST http://localhost:8000/api/claude/schema-modernization \
  -H "Content-Type: application/json" \
  -d '{
    "schemaFilePath": "/path/to/oracle-schema.sql",
    "sourceDatabase": "oracle",
    "targetDatabase": "postgresql",
    "projectPath": "/path/to/project",
    "analysisId": "schema-001"
  }' | jq .
```

### 5. Build & Compilation

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/java/project",
    "operation": "build-compilation",
    "analysisId": "build-001",
    "javaVersion": "21",
    "platform": "linux"
  }' | jq .
```

### 6. Containerization Analysis

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/path/to/project",
    "operation": "containerization",
    "analysisId": "container-001",
    "prompt": "Create Dockerfile and docker-compose.yml for this application"
  }' | jq .
```

---

## Testing with Python

### Setup

```bash
pip install requests
```

### Example Test Script

Create `test_api.py`:

```python
import requests
import json
from pprint import pprint

BASE_URL = "http://localhost:8000"

def test_health():
    """Test application health."""
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status Code: {response.status_code}")
    pprint(response.json())
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_claude_health():
    """Test Claude API health."""
    response = requests.get(f"{BASE_URL}/api/claude/health")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.text}")
    assert response.status_code == 200

def test_execute_command():
    """Test command execution endpoint."""
    payload = {
        "projectPath": "/path/to/project",
        "operation": "analysis",
        "analysisId": "test-python-001",
        "platform": "linux"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/claude/executeCommandWithPrompt",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status Code: {response.status_code}")
    pprint(response.json())
    
    assert response.status_code == 200
    result = response.json()
    assert "outputFilePath" in result or "error" in result

def test_schema_modernization():
    """Test schema modernization endpoint."""
    payload = {
        "schemaFilePath": "/path/to/schema.sql",
        "sourceDatabase": "oracle",
        "targetDatabase": "postgresql",
        "projectPath": "/path/to/project",
        "analysisId": "schema-test-001"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/claude/schema-modernization",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status Code: {response.status_code}")
    pprint(response.json())

if __name__ == "__main__":
    print("=" * 60)
    print("Testing Studio AI Engine API")
    print("=" * 60)
    
    print("\n1. Testing Application Health...")
    test_health()
    
    print("\n2. Testing Claude API Health...")
    test_claude_health()
    
    print("\n3. Testing Execute Command...")
    # test_execute_command()  # Uncomment when you have a real project path
    
    print("\n4. Testing Schema Modernization...")
    # test_schema_modernization()  # Uncomment when you have a real schema file
    
    print("\n✅ All tests completed!")
```

### Run Tests

```bash
python test_api.py
```

---

## Testing with Postman

### Import Collection

1. Open Postman
2. Click **Import**
3. Create new collection: **Studio AI Engine**

### Configure Environment

Create environment variables:
- `base_url`: `http://localhost:8000`
- `project_path`: Your actual project path
- `analysis_id`: Generate unique IDs

### Example Requests

#### Health Check
```
GET {{base_url}}/health
```

#### Execute Command
```
POST {{base_url}}/api/claude/executeCommandWithPrompt

Body (raw JSON):
{
  "projectPath": "{{project_path}}",
  "operation": "analysis",
  "analysisId": "{{analysis_id}}",
  "platform": "linux"
}
```

---

## Testing with HTTPie

HTTPie provides a cleaner syntax than cURL:

### Install HTTPie

```bash
pip install httpx[cli]
# or
brew install httpie  # macOS
```

### Examples

```bash
# Health check
http GET :8000/health

# Claude health
http GET :8000/api/claude/health

# Execute command
http POST :8000/api/claude/executeCommandWithPrompt \
  projectPath="/path/to/project" \
  operation="analysis" \
  analysisId="test-001" \
  platform="linux"

# Schema modernization
http POST :8000/api/claude/schema-modernization \
  schemaFilePath="/path/to/schema.sql" \
  sourceDatabase="oracle" \
  targetDatabase="postgresql" \
  projectPath="/path/to/project" \
  analysisId="schema-001"
```

---

## Common Operations Examples

### 1. Code Validation

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/app/projects/my-java-app",
    "operation": "validation",
    "analysisId": "validate-001",
    "javaVersion": "21",
    "platform": "linux"
  }'
```

### 2. Cloud Readiness Analysis

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/app/projects/legacy-app",
    "operation": "cloudreadiness",
    "analysisId": "cloud-001",
    "prompt": "Analyze cloud migration readiness for AWS"
  }'
```

### 3. Database Code Modernization

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/app/projects/db-app",
    "operation": "db-code-modernize",
    "analysisId": "db-mod-001",
    "operationSuffix": "oracle-to-postgres"
  }'
```

### 4. .NET Validation

```bash
curl -X POST http://localhost:8000/api/claude/executeCommandWithPrompt \
  -H "Content-Type: application/json" \
  -d '{
    "projectPath": "/app/projects/dotnet-app",
    "operation": "dotnet-validation",
    "analysisId": "dotnet-001",
    "dotnetVersion": "8.0",
    "platform": "linux"
  }'
```

---

## Request/Response Examples

### Successful Response

```json
{
  "success": true,
  "outputFilePath": "/tmp/claude-outputs/analysis/output_test-001.txt",
  "executionTime": "45.3 seconds",
  "operation": "analysis",
  "analysisId": "test-001"
}
```

### Error Response

```json
{
  "success": false,
  "error": "Project path does not exist: /invalid/path",
  "operation": "analysis",
  "analysisId": "test-001"
}
```

### Schema Modernization Response

```json
{
  "success": true,
  "convertedSchemaPath": "/tmp/claude-outputs/schema-modernization/converted_schema_001.sql",
  "sourceDatabase": "oracle",
  "targetDatabase": "postgresql",
  "executionTime": "32.1 seconds"
}
```

---

## Quick Test Script

Save as `quick_test.sh`:

```bash
#!/bin/bash

BASE_URL="http://localhost:8000"

echo "Testing Studio AI Engine API"
echo "=============================="

# Health check
echo -e "\n1. Application Health:"
curl -s $BASE_URL/health | jq .status

# Claude API health
echo -e "\n2. Claude API Health:"
curl -s $BASE_URL/api/claude/health

# Check if running
echo -e "\n3. Container Status:"
docker-compose ps | grep studio-ai-engine

echo -e "\n✅ Quick test complete!"
```

Run:
```bash
chmod +x quick_test.sh
./quick_test.sh
```

---

## Monitoring & Debugging

### View Logs in Real-Time

```bash
# Follow logs
docker-compose logs -f studio-ai-engine

# Last 100 lines
docker-compose logs --tail=100 studio-ai-engine

# Filter for errors
docker-compose logs studio-ai-engine | grep ERROR
```

### Check Container Health

```bash
# Container status
docker-compose ps

# Health check details
docker inspect studio-ai-engine-python | jq '.[0].State.Health'
```

### API Metrics

```bash
# Response time test
time curl -s http://localhost:8000/health > /dev/null

# Load testing with ab (Apache Bench)
ab -n 100 -c 10 http://localhost:8000/health
```

---

## CORS Testing from Frontend

If testing from `dev.cmodernize.com`:

```javascript
// JavaScript fetch example
fetch('http://localhost:8000/api/claude/health', {
  method: 'GET',
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json'
  }
})
.then(response => response.text())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));

// POST example
fetch('http://localhost:8000/api/claude/executeCommandWithPrompt', {
  method: 'POST',
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    projectPath: '/path/to/project',
    operation: 'analysis',
    analysisId: 'web-001',
    platform: 'linux'
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));
```

---

## Troubleshooting

### Connection Refused

```bash
# Check if container is running
docker-compose ps

# Check if port is bound
netstat -an | grep 8000

# Restart container
docker-compose restart
```

### Timeout Errors

```bash
# Increase timeout in your client
curl -X POST --max-time 300 http://localhost:8000/api/claude/executeCommandWithPrompt ...
```

### CORS Errors

Update `.env`:
```bash
CORS_ALLOW_ORIGINS=https://dev.cmodernize.com
```

Then restart:
```bash
docker-compose restart
```

---

## Next Steps

1. ✅ Test health endpoints
2. ✅ Try interactive Swagger UI at `/docs`
3. ✅ Test with sample project paths
4. ✅ Configure CORS for your domain
5. ✅ Set up monitoring/logging
6. ✅ Create integration tests

---

**Happy Testing! 🚀**

For more information, see:
- [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)
- [README.md](./README.md)
- [DOCKER_RUNTIME_FIXES.md](./DOCKER_RUNTIME_FIXES.md)
