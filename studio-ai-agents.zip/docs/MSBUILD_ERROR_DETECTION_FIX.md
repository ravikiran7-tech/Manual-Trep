# MSBuild Error Detection Fix

## Issue Summary

**Problem:** Build failures in .NET projects with MSBuild/project file errors were not being detected, causing the system to report "Build failed with 0 errors" and running in infinite loops without fixing the actual issues.

**Root Cause:** The error extraction regex pattern only matched C# compilation errors (`.cs` files with `CS####` error codes) and completely missed MSBuild project errors (`.csproj` files with `MSB####` error codes or XML parsing errors).

**Impact:** 
- AI agents couldn't fix project file issues (malformed .csproj XML, missing dependencies, etc.)
- Fix iterations would run indefinitely without progress
- Build exit code 1 but 0 errors detected, creating contradiction in logs

## Technical Analysis

### The Bug Location

**Files Affected:**
- `app/services/operation_handlers/fix_upgrade_handler.py`
- `app/services/operation_handlers/selective_fix_handler.py`

**Method:** `_extract_error_lines()`

### Original Broken Code

```python
if project_type == "dotnet":
    # Pattern: file.cs(line,col): error CS####: message
    for line in lines:
        if re.search(r'\.cs\(\d+,\d+\): error CS\d+:', line):
            errors.append(line.strip())
```

**Problems:**
1. ✅ Matches: `Program.cs(10,5): error CS0246: Type not found`
2. ❌ **Doesn't match**: `FilmsWeb8.csproj(14,4): error MSB4068: Missing closing tag`
3. ❌ **Doesn't match**: `error MSB3644: Reference assemblies not found`
4. ❌ **Doesn't match**: `error : mismatched tag: line 14, column 4`

### Real-World Example from Logs

```log
Line 183: WARNING - Failed to parse .csproj: mismatched tag: line 14, column 4
Line 172: Build exit code: 1, Errors found: 0  ← CONTRADICTION!
Line 173: Build failed with 0 errors              ← CAN'T FIX WHAT YOU CAN'T SEE!
```

## The Fix

### Updated Error Extraction (Both Handlers)

```python
if project_type == "dotnet":
    # Capture multiple .NET error patterns:
    # 1. C# compilation errors: file.cs(line,col): error CS####: message
    # 2. MSBuild project errors: file.csproj(line,col): error MSB####: message
    # 3. General MSBuild errors: error MSB####: message
    # 4. XML parsing errors: error : message
    for line in lines:
        # Match C# compilation errors (CS####)
        if re.search(r'\.cs\(\d+,\d+\): error CS\d+:', line):
            errors.append(line.strip())
        # Match MSBuild project file errors (MSB####)
        elif re.search(r'\.(csproj|props|targets)\(\d+,\d+\): error MSB\d+:', line):
            errors.append(line.strip())
        # Match general MSBuild errors without file reference
        elif re.search(r'\berror MSB\d+:', line):
            errors.append(line.strip())
        # Match generic error patterns (for XML/parsing errors)
        elif re.search(r'\berror\s*:\s*.+?(mismatched tag|expected|parse|xml)', line, re.IGNORECASE):
            errors.append(line.strip())
```

### Updated Error Categorization

**Original:** Only handled `CS####` codes
```python
match = re.search(r'error (CS\d+):', error)
```

**Fixed:** Handles both `CS####` and `MSB####` codes
```python
cs_match = re.search(r'error (CS\d+):', error)
msb_match = re.search(r'error (MSB\d+):', error)

if cs_match:
    # C# compilation error
    error_code = cs_match.group(1)
    # ... categorize CS error
elif msb_match:
    # MSBuild project error
    error_code = msb_match.group(1)
    # ... categorize MSB error
elif 'xml' in error.lower() or 'parse' in error.lower() or 'mismatched tag' in error.lower():
    # XML/parsing errors (like malformed .csproj)
    categories["XML_PARSE_ERROR"].append(error)
```

### Updated Fix Prompts

Added guidance for MSBuild errors to help AI fix them:

```markdown
**MSBuild Project Errors (MSB####):**
- **MSB4068/MSB3231** (XML parsing): Fix malformed XML in .csproj file (mismatched tags, unclosed elements)
- **MSB3644** (Reference assemblies not found): Add missing package references or update TargetFramework
- **MSB4019** (Imported project not found): Fix project reference paths in .csproj
- **XML_PARSE_ERROR**: Check .csproj file for syntax errors (missing closing tags, invalid XML)
```

## Error Types Now Captured

### 1. C# Compilation Errors (Already Working)
- Format: `File.cs(line,col): error CS####: message`
- Example: `Program.cs(10,5): error CS0246: The type or namespace name 'Foo' could not be found`

### 2. MSBuild Project File Errors (NOW FIXED)
- Format: `File.csproj(line,col): error MSB####: message`
- Example: `FilmsWeb8.csproj(14,4): error MSB4068: The element 'PropertyGroup' is missing a closing tag`

### 3. General MSBuild Errors (NOW FIXED)
- Format: `error MSB####: message`
- Example: `error MSB3644: The reference assemblies for .NETFramework,Version=v6.0 were not found`

### 4. XML Parsing Errors (NOW FIXED)
- Format: `error : description`
- Example: `error : mismatched tag: line 14, column 4`

## Testing Recommendations

### Test Case 1: Malformed .csproj File
```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  <!-- Missing closing tag! -->
</Project>
```

**Expected Result:**
- ✅ Error detected: `FilmsWeb8.csproj(14,4): error MSB4068: ...` or `XML_PARSE_ERROR`
- ✅ AI agent receives error details in prompt
- ✅ AI fixes the XML syntax issue

### Test Case 2: Missing Package Reference
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <!-- No package references, but code uses Entity Framework -->
</Project>
```

**Expected Result:**
- ✅ Error detected: `error MSB3644: Reference assemblies not found`
- ✅ AI adds required `<PackageReference>` elements

### Test Case 3: Invalid Project Reference Path
```xml
<ItemGroup>
  <ProjectReference Include="../NonExistentProject/Project.csproj" />
</ItemGroup>
```

**Expected Result:**
- ✅ Error detected: `error MSB4019: The imported project ... was not found`
- ✅ AI corrects the path or removes invalid reference

## Files Modified

1. `/app/services/operation_handlers/fix_upgrade_handler.py`
   - Updated `_extract_error_lines()` method (lines 408-435)
   - Updated `_categorize_errors()` method (lines 436-505)
   - Updated `_generate_fix_prompt()` method (lines 577-590)

2. `/app/services/operation_handlers/selective_fix_handler.py`
   - Updated `_extract_error_lines()` method (lines 409-436)
   - Updated `_categorize_errors()` method (lines 437-504)
   - Updated `_generate_fix_prompt()` method (lines 578-591)

## Benefits

1. **Complete Error Detection**: Now captures all .NET build errors (C#, MSBuild, XML)
2. **Better AI Guidance**: AI receives specific error codes and actionable fix suggestions
3. **Faster Fixes**: No more infinite loops; AI can actually see and fix project file issues
4. **Accurate Reporting**: Build failures now properly report error counts
5. **Categorized Errors**: MSBuild errors grouped separately for systematic fixing

## Verification

After deployment, verify the fix by:

1. Check logs for "Build failed with N errors" where N > 0 for actual failures
2. Confirm MSBuild errors appear in error categorization logs
3. Verify AI agents successfully fix .csproj XML issues
4. Monitor fix iteration counts (should be lower, not infinite loops)

## Related Issues

This fix resolves the contradiction seen in logs:
```
Build exit code: 1, Errors found: 0  ← SHOULD NEVER HAPPEN NOW
Build failed with 0 errors             ← SHOULD NEVER HAPPEN NOW
```

Now properly reports:
```
Build exit code: 1, Errors found: 3
Categorized into 2 error types: ['MSB4068_MISSING_CLOSING_TAG', 'CS0246_TYPE_NOT_FOUND']
```

## Date
February 3, 2026

## Status
✅ **Fixed** - Both handlers updated with comprehensive .NET error detection
