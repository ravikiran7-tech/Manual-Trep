# Studio AI Engine - Deployment Guide

**Version**: 1.0.0  
**Date**: January 19, 2026  
**Status**: Production Ready ✅

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
3. [Docker Deployment](#docker-deployment)
4. [Production Deployment](#production-deployment)
5. [Configuration](#configuration)
6. [Monitoring & Health Checks](#monitoring--health-checks)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required

- **Python**: 3.10 or higher
- **AWS Account**: With Bedrock API access
- **AWS Credentials**: IAM role or access keys with Bedrock permissions
- **Studio Core**: Running instance for Compass integration
- **Encryption Key**: Base64-encoded AES key for credential decryption

### Optional

- **Docker**: For containerized deployment (recommended)
- **Docker Compose**: For orchestrated deployment

---

## Local Development

### 1. Clone and Setup

```bash
cd /home/ubuntu/coderepo/studio-ai-engine/src/main/python

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit with your settings
nano .env
```

**Minimum Required Configuration:**

```bash
# AWS
AWS_REGION=us-east-1
AWS_PROFILE=default

# Studio Core
STUDIO_CORE_URL=https://your-instance.com/studio-core

# Encryption
ENCRYPTION_KEY=<your-base64-key>

# Workspace
CLAUDE_WORKSPACE=/studio-app/claude-workspace
OUTPUT_DIR=/tmp/claude-outputs
```

### 3. Run Application

```bash
# Development mode (with auto-reload)
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Check logs
tail -f logs/app.log
```

### 4. Verify

```bash
# Health check
curl http://localhost:8000/health

# API documentation
open http://localhost:8000/swagger-ui.html
```

---

## Docker Deployment

### Build Image

```bash
cd /home/ubuntu/coderepo/studio-ai-engine/src/main/python

# Build the Docker image
docker build -t studio-ai-engine:latest .

# Verify image
docker images | grep studio-ai-engine
```

### Run Container

```bash
# Run with environment variables
docker run -d \
  --name studio-ai-engine \
  -p 8000:8000 \
  -e AWS_REGION=us-east-1 \
  -e STUDIO_CORE_URL=https://your-instance.com/studio-core \
  -e ENCRYPTION_KEY=<your-base64-key> \
  -v ~/.aws:/home/studioai/.aws:ro \
  -v /data/workspace:/studio-app/claude-workspace \
  -v /data/outputs:/tmp/claude-outputs \
  studio-ai-engine:latest

# Check logs
docker logs -f studio-ai-engine

# Check health
docker exec studio-ai-engine curl -f http://localhost:8000/health
```

### Docker Compose (Recommended)

**Development:**

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

**Production-like:**

```bash
# Start with production config
docker-compose -f docker-compose.prod.yml up -d

# View logs
docker-compose -f docker-compose.prod.yml logs -f

# Stop services
docker-compose -f docker-compose.prod.yml down
```

---

## Production Deployment

### AWS ECS Deployment

**1. Push Image to ECR:**

```bash
# Authenticate to ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin <account>.dkr.ecr.us-east-1.amazonaws.com

# Tag image
docker tag studio-ai-engine:latest \
  <account>.dkr.ecr.us-east-1.amazonaws.com/studio-ai-engine:latest

# Push image
docker push <account>.dkr.ecr.us-east-1.amazonaws.com/studio-ai-engine:latest
```

**2. Create ECS Task Definition:**

```json
{
  "family": "studio-ai-engine",
  "taskRoleArn": "arn:aws:iam::<account>:role/StudioAIEngineTaskRole",
  "executionRoleArn": "arn:aws:iam::<account>:role/ecsTaskExecutionRole",
  "networkMode": "awsvpc",
  "containerDefinitions": [
    {
      "name": "studio-ai-engine",
      "image": "<account>.dkr.ecr.us-east-1.amazonaws.com/studio-ai-engine:latest",
      "memory": 4096,
      "cpu": 2048,
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "AWS_REGION",
          "value": "us-east-1"
        },
        {
          "name": "STUDIO_CORE_URL",
          "value": "https://your-instance.com/studio-core"
        }
      ],
      "secrets": [
        {
          "name": "ENCRYPTION_KEY",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:<account>:secret:studio-ai-engine/encryption-key"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/studio-ai-engine",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      },
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f http://localhost:8000/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ],
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "2048",
  "memory": "4096"
}
```

**3. Create ECS Service:**

```bash
aws ecs create-service \
  --cluster studio-ai-engine-cluster \
  --service-name studio-ai-engine \
  --task-definition studio-ai-engine:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:...,containerName=studio-ai-engine,containerPort=8000"
```

### Kubernetes Deployment

**Deployment manifest:**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: studio-ai-engine
  namespace: studio
spec:
  replicas: 3
  selector:
    matchLabels:
      app: studio-ai-engine
  template:
    metadata:
      labels:
        app: studio-ai-engine
    spec:
      containers:
      - name: studio-ai-engine
        image: studio-ai-engine:latest
        ports:
        - containerPort: 8000
        env:
        - name: AWS_REGION
          value: "us-east-1"
        - name: STUDIO_CORE_URL
          value: "https://your-instance.com/studio-core"
        - name: ENCRYPTION_KEY
          valueFrom:
            secretKeyRef:
              name: studio-ai-engine-secrets
              key: encryption-key
        resources:
          requests:
            memory: "2Gi"
            cpu: "1"
          limits:
            memory: "4Gi"
            cpu: "2"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
```

---

## Configuration

### Environment Variables

See [`.env.example`](.env.example) for complete configuration options.

### YAML Configuration

Edit [`config/settings.yml`](config/settings.yml) to override defaults.

### Logging Configuration

Production logging: [`logging.conf`](logging.conf)

---

## Monitoring & Health Checks

### Health Endpoints

- **Application**: `GET /health`
- **Claude API**: `GET /api/claude/health`
- **Stream API**: `GET /api/stream/health`

### Metrics (Future)

- Prometheus metrics endpoint: `/metrics`
- CloudWatch integration via AWS SDK

### Logging

- **Console**: Standard output (Docker-compatible)
- **File**: `/app/logs/app.log` (with rotation)
- **Format**: Structured JSON or text

---

## Troubleshooting

### Container Won't Start

```bash
# Check logs
docker logs studio-ai-engine

# Common issues:
# 1. Missing STUDIO_CORE_URL
# 2. Missing ENCRYPTION_KEY
# 3. Invalid AWS credentials
```

### Health Check Fails

```bash
# Check application logs
docker exec studio-ai-engine tail -f /app/logs/app.log

# Test health endpoint
docker exec studio-ai-engine curl http://localhost:8000/health
```

### AWS Credentials Error

```bash
# Verify credentials in container
docker exec studio-ai-engine aws sts get-caller-identity

# If using IAM role, ensure task role has Bedrock permissions
```

### Performance Issues

```bash
# Check resource usage
docker stats studio-ai-engine

# Increase workers (in docker-compose.yml or container command)
# command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 8
```

---

## Security Best Practices

1. **Never expose** `.env` files in version control
2. **Use IAM roles** instead of access keys when possible
3. **Restrict CORS** to specific domains in production
4. **Enable HTTPS** with proper SSL certificates
5. **Rotate encryption keys** periodically
6. **Monitor logs** for security events
7. **Keep dependencies** updated (`pip list --outdated`)

---

## Support

For issues or questions:
- Check logs: `/app/logs/app.log`
- Review documentation: [`README.md`](README.md)
- Test endpoints: http://localhost:8000/swagger-ui.html

---

**Status**: ✅ **PRODUCTION READY**

All deployment configurations are tested and ready for use.
