# Rules detection and assessment schema generation — complete flow

This document describes the **assessment-rules-batch** pipeline in `studio-ai-agents`: how catalog rule metadata is turned into two JSON documents per rule (`detectionSchema` and `assessmentSchema`), end to end, for **HTTP** and **NATS**.

It is written from the current implementation (handler, NATS service, FastAPI route, prompts, models, config). It does **not** invent catalog rules. Upstream already owns `ruleId`, `name`, `description`, `domain`, and `language`.

---

## 1. What the flow produces

For each input catalog rule, the service returns one `AssessmentRuleBatchItem`:

| Field | Role |
|---|---|
| `ruleId` | Catalog identifier, copied through. Must not be invented. |
| `detectionSchema` | Scanner contract: **REGEX** patterns + file extensions. |
| `assessmentSchema` | Assessment document: category, severity, and domain-specific `remediation` (no `pathwayImpacts`). |

Java stores those two schema objects as **separate documents**. The Python service therefore **splits** them at the top level and never leaves assessment fields inside detection (or the reverse) after normalization.

**Default detection contract after post-processing:**

- `status` = `"active"` (forced)
- `parser` = `"REGEX"` (forced)
- `language` = `{ "name": "<lowercase>", "versions": [] }` (name lowercased; versions default empty)
- `scope` = `["function"]` if missing or empty
- `detectionCriteria.fileType` = list of **extensions without a leading dot**
- `detectionCriteria.searchPattern` = list of PCRE-compatible regex strings

---

## 2. Components and files

```
Rules Management / HTTP client
        │
        ├─ HTTP POST  /studio-ai-agents/api/claude/assessment-rules-batch
        │                    │
        │                    ▼
        │            FastAPI (app/api/v1/claude.py)
        │                    │
        └─ NATS  schema.generate.request
                             │
                             ▼
               NatsSchemaGenerateService (app/services/nats_schema_generate_service.py)
                             │
                             ▼
               ClaudeService.execute_assessment_rules_batch
                             │
                             ▼
               AssessmentRulesBatchHandler.execute_batch
                             │
                             ├─ Compass → LLM adapter (Bedrock / Portkey / Azure / private LLM)
                             ├─ Prompt (app/prompts/assessment_rules_batch.py)
                             ├─ Parse JSON array
                             └─ Normalize to Java shape
                             │
                             ├─ HTTP: single JSON response
                             └─ NATS: schema.generate.result (one message per chunk + error)
```

| File | Responsibility |
|---|---|
| `app/main.py` | Lifespan: start/stop NATS subscriber; mount router at `/studio-ai-agents` |
| `app/api/v1/claude.py` | HTTP POST `/api/claude/assessment-rules-batch` |
| `app/services/nats_schema_generate_service.py` | NATS connect, map payload, subscribe, publish |
| `app/services/claude_service.py` | `execute_assessment_rules_batch` → handler |
| `app/services/operation_handlers/assessment_rules_batch_handler.py` | Validate, chunk, LLM, parse, normalize, fail-fast |
| `app/prompts/assessment_rules_batch.py` | System prompt, user template, schema example |
| `app/models/requests.py` | `AssessmentRuleInputItem`, `AssessmentRulesBatchRequest` |
| `app/models/responses.py` | `AssessmentRuleBatchItem`, `AssessmentRulesBatchResponse` |
| `app/core/config.py` | `ASSESSMENT_RULES_BATCH_*`, `NATS_*`, `TIMEOUT_ASSESSMENT_RULES_BATCH` |
| `app/services/llm/factory.py` | Compass active connection → adapter → `LLMOrchestrator` |
| `app/utils/path_utils.py` | `resolve_secure_work_directory` |
| `app/utils/stream_utils.py` | Assistant text extract + fenced JSON extract |
| `app/core/security.py` | `analysisId` alphanumeric; optional `projectPath` injection checks |
| `tests/services/operation_handlers/test_assessment_rules_batch_handler.py` | Handler coverage |
| `tests/services/test_nats_schema_generate_service.py` | NATS mapping/publish coverage |

The Claude **CLI** operation path cannot run this flow. `AssessmentRulesBatchHandler.execute()` raises `ValidationError`: it is **only** available via HTTP POST or NATS.

---

## 3. Process startup (shared)

On FastAPI lifespan (`app/main.py`):

1. Validate configuration.
2. Create workspace directories (`WORKSPACE_BASE_PATH`, default `/studio-app/claude-workspace`). Assessment-rules-batch dirs are created **lazily** when a job runs, not at startup.
3. Initialize HTTP/Compass resources.
4. **`initialize_nats_subscriber()`**
   - If `NATS_ENABLED` is false → log and skip. HTTP still works.
   - Else construct `NatsSchemaGenerateService()` and `await start()`.
5. On shutdown: `stop()` unsubscribes, `drain()`, `close()`.

If NATS is enabled but `nats-py` is not installed in **this** interpreter, startup **fails** with a message to `python -m pip install nats-py` or set `NATS_ENABLED=false`.

---

## 4. NATS connection details

Connection is **not** taken from `NATS_SERVERS` in settings for credentials/URL. The service loads:

1. SQLite table `env_config` at `NATS_SQLITE_CONFIG_DB_PATH` (default `/etc/app-config/config.db`, JDBC prefix `jdbc:sqlite:` stripped).
2. Path must resolve **inside** `NATS_SQLITE_CONFIG_ALLOWED_DIR` (default `/etc/app-config`) — path traversal is rejected.
3. Overlay process environment for: `NATS_URL`, `NATS_USERNAME`, `NATS_PASSWORD`, `NATS_AUTH_ENABLED`.
4. Decrypt username/password if they look like Base64 GCM:
   - Prefer `ENC_PASSPHRASE` (`decrypt_gcm_values`).
   - Else `ENCRYPTION_KEY` if ciphertext matches `EncryptionUtils.is_encrypted`.
   - Else treat as plaintext.
5. Parse `NATS_URL`: comma/semicolon separated; missing scheme → `nats://`; `nats`/`tls` default port **4222**.
6. Reject mixing websocket (`ws`/`wss`) and TCP (`nats`/`tls`) URLs.
7. Connect with:
   - `name` = `NATS_CLIENT_NAME` (default `studio-ai-agents`)
   - `connect_timeout` = `NATS_CONNECT_TIMEOUT_SECONDS` (default 10)
   - `reconnect_time_wait` = `NATS_RECONNECT_WAIT_SECONDS` (default 2)
   - `max_reconnect_attempts` = `NATS_MAX_RECONNECTS` (default 60)
   - user/password **only if** `NATS_AUTH_ENABLED` is truthy (`true` / `1` / `yes`, case-insensitive — Java `Boolean.parseBoolean` plus extras)
8. Subscribe **`schema.generate.request`** (`NATS_SCHEMA_GENERATE_REQUEST_SUBJECT`).
9. Publish to **`schema.generate.result`** (`NATS_SCHEMA_GENERATE_RESULT_SUBJECT`).

**Operational notes:**

- There is **no queue group**. NATS core pub/sub: every replica that is subscribed receives **a copy** of each request. Scale-out without a queue group duplicates work.
- Logs never print NATS userinfo; endpoint logs are `scheme://host:port` only.
- If `NATS_URL` is empty after SQLite + env merge, `start()` raises (startup fails).

---

## 5. HTTP end-to-end flow

### 5.1 Ingress

- **Method / path:** `POST /studio-ai-agents/api/claude/assessment-rules-batch`
- Router prefix: `/api/claude` on the app prefix `/studio-ai-agents`.
- CORS as configured on the app.
- OpenAPI: `/studio-ai-agents/docs`.

### 5.2 FastAPI / Pydantic bind (before handler)

Body must be JSON matching `AssessmentRulesBatchRequest` (aliases `analysisId`, `projectPath`, `ruleId`).

| Field | Required | Rules |
|---|---|---|
| `analysisId` | Yes | String; handler later requires alphanumeric, hyphen, underscore only |
| `rules` | Yes | Non-empty list (`min_length=1`) |
| `rules[].ruleId` | Yes | String |
| `rules[].name` | Yes | String |
| `rules[].description` | Yes | String |
| `rules[].domain` | Yes | String |
| `rules[].category` | Yes | String. Copied onto `assessmentSchema.category`. Not chosen by the model. |
| `rules[].issueType` | Yes | String. Copied onto `assessmentSchema.issueType`. `BOOSTER` (any case) sets `remediation` to `{}`. |
| `rules[].severity` | Yes | String. Copied onto `assessmentSchema.severity`. Not chosen by the model. |
| `rules[].language` | Yes | String |
| `rules[].example` | No | String or omitted |
| `projectPath` | No | String |
| `platform` | No | Default `"linux"`; must be `linux` or `windows` |

Pydantic failures are handled in `main.py` as **HTTP 400** with `status: error`, `message: Request validation failed`, `details: exc.errors()` (not FastAPI’s default 422).

### 5.3 Route body (`execute_assessment_rules_batch`)

1. Log `analysisId` and rule count.
2. `Depends(get_claude_service)` — process singleton `ClaudeService`.
3. `await claude_service.execute_assessment_rules_batch(request)` — **no** `on_progress` callback. HTTP **does not** stream chunk results.
4. Dump response with camelCase aliases, `mode=json`.
5. **Print and log the entire JSON body** (`[assessment-rules-batch] response before HTTP return:`). `%` in regex JSON is safe because logging uses a single `%s`.
6. If `response.status == "error"` → **HTTP 500** with `detail` = full response payload (including `rules` on count mismatch, `rawResponse`, `outputFilePath`, etc.).
7. If `status` is `success` (or theoretically `partial`) → **HTTP 200** with the response model. In practice HTTP never sees `partial` because progress is not emitted over HTTP and the final return is `success` or `error`.
8. `ValidationError` from handler → **HTTP 400** `{ status, message, field, analysisId }`.
9. Any other exception → **HTTP 200** body with `status=error` (the route **returns** `AssessmentRulesBatchResponse` instead of raising). This is different from the handler’s own `status=error` path, which is 500.

### 5.4 HTTP does not wait per chunk for the client

The handler still processes chunks internally (and may run two LLM calls in parallel). The HTTP client only sees the **final** assembled list or a 500/400/200-error body.

---

## 6. NATS end-to-end flow

### 6.1 Message callback `_on_message`

1. Decode UTF-8 JSON object. Non-object → error publish.
2. `_parse_request_payload` (see below).
3. `AssessmentRulesBatchRequest.model_validate(...)`.
4. `on_progress` = `self._publish_result` (every chunk success/error).
5. `await claude_service.execute_assessment_rules_batch(request, on_progress=on_progress)`.
6. Any exception (JSON, validation, LLM, NATS publish) → build `AssessmentRulesBatchResponse(status=error, isFinal=true, chunkIndex=1, chunkCount=1, analysisId=…)` and publish. If `analysisId` was never parsed, generate `schema-gen-` + 12 hex chars.

The handler’s **final** `success` response is **also** returned from `execute_batch`. Because `on_progress` already published the last chunk as `isFinal=true` / `status=success`, the HTTP-style “return value” is unused by NATS (the callback already published). Duplicate final publish does **not** happen from the NATS service itself: NATS only publishes via `on_progress`, not a second dump of the return value.

Progress emissions:

| Event | `status` | `isFinal` | `rules` |
|---|---|---|---|
| Non-last successful chunk | `partial` | `false` | That chunk’s rules only |
| Last successful chunk | `success` | `true` | That chunk’s rules only (not the full concatenated list) |
| Handler final return | `success` | `true` | **Full concatenated list** — **not published again** by NATS |
| Chunk / batch error | `error` | `true` | `null` except count-mismatch, which includes the parsed `rules` |

**NATS consumer implication:** progressive messages carry **per-chunk** `rules`, not the growing full array. `rulesCompletedSoFar` is the running total. To assemble the full catalog, the consumer must concatenate `rules` from all `partial`/`success` messages for the same `analysisId` in `chunkIndex` order. The handler’s in-memory final object has the full list, but that object is not published as a second NATS message.

### 6.2 Payload mapping `_parse_request_payload`

Required on **each** rule (must be non-blank strings): `domain`, `name`, `description`, `ruleId`, `language`, `category`, `issueType`, `severity`.

Optional: `example` — included only if not `null`. If present and not a string → error.

Mapped request:

```json
{
  "analysisId": "<payload.analysisId or schema-gen-{12 hex}>",
  "platform": "<settings.nats.platform, default linux>",
  "rules": [ { "domain", "name", "description", "ruleId", "language", "category", "issueType", "severity", "example?" } ],
  "projectPath": "<only if NATS_PROJECT_PATH is set and non-blank>"
}
```

**Not taken from the NATS JSON:**

- `platform` from the message (always service config)
- `projectPath` from the message (always `NATS_PROJECT_PATH` or omitted)
- Extra catalog fields (ignored)

Empty or missing `rules` → `ValueError`.

### 6.3 Publish `_publish_result`

- `response.model_dump(by_alias=True, exclude_none=True, mode="json")`
- UTF-8 JSON, `ensure_ascii=False` (regex and Unicode preserved)
- `publish` + `flush`
- Log subject, status, isFinal, chunk, analysisId

If `_nc` is missing → `RuntimeError`.

---

## 7. Shared handler pipeline (every job)

Both transports converge here: `AssessmentRulesBatchHandler.execute_batch`.

### 7.1 Process-wide job semaphore

`ASSESSMENT_RULES_BATCH_MAX_CONCURRENT_REQUESTS` (default **1**).

A second HTTP or NATS job **waits** until the first releases the slot. The semaphore is recreated if the configured `n` changes (tests). Logs:

- `waiting for batch request slot`
- `acquired batch request slot`

### 7.2 Validation `validate_batch_request`

| Check | Error field |
|---|---|
| `analysisId` missing | `analysisId` |
| Not `^[a-zA-Z0-9\-_]+$` | `analysisId` |
| `len(rules) > max_rules` (default 50) | `rules` |
| Each rule: blank `ruleId` / `name` / `description` / `domain` / `language` / `category` / `issueType` / `severity` | `rules[i].…` |
| If `projectPath` set: `SecurityValidator.validate_path` (no `; & | \` $` etc.; Linux `/…` or Windows `C:…`) | `projectPath` |

HTTP: these become 400. NATS: exception → error result message.

### 7.3 Work directory

`resolve_secure_work_directory(analysis_id, project_path)`:

- If `projectPath` provided (HTTP body or NATS env): use stripped path.
- Else: create `{workspace}/assessment-rules-batch/{analysisId}/work-XXXXXX` via `tempfile.mkdtemp` (not world-writable `/tmp`).

This path is passed to the LLM as `project_path` but **`prepend_project_context=False`**, so it is **not** prepended as `"Project directory: …"` in the user message. Tools are disabled, so the directory is unused for file/shell tools.

### 7.4 Chunking

- `chunk_size` default **5** (`ASSESSMENT_RULES_BATCH_CHUNK_SIZE`).
- Contiguous slices: `[0:5]`, `[5:10]`, … last chunk may be smaller.
- `chunk_index` is **1-based**.
- LLM call count = `ceil(rule_count / chunk_size)`.

Example: 12 rules → chunks of 5, 5, 2.

### 7.5 Parallel execution

- `ASSESSMENT_RULES_BATCH_MAX_PARALLEL_CHUNKS` default **2**.
- Each chunk is `asyncio.create_task`.
- Inner `asyncio.Semaphore(max_parallel)` limits concurrent `_invoke_rules_chunk`.
- `asyncio.wait(..., FIRST_COMPLETED)` loop.
- Global LLM rate limiter on the orchestrator **still** serializes/throttles actual provider calls.

When several chunks finish in the same wait wave:

1. Collect successes and errors.
2. Apply **successes first**, sorted by `chunk_index`, so fail-fast reports accurate `rulesCompletedSoFar`.
3. Emit progress (NATS) per success.
4. If any error: take **first** error, set `rule_count_expected` to **full batch** size, set `rules_completed_so_far`, **cancel** remaining tasks, `gather(..., return_exceptions=True)`, emit error, return.

### 7.6 One chunk: `_invoke_rules_chunk`

**Prompt**

1. `format_rules_batch_for_prompt`: numbered blocks:

   ```
   1. ruleId: …
      domain: …
      language: …
      name: …
      description: …
      example: …          # only if non-blank
   ```

2. `build_assessment_rules_batch_prompt`: injects `rule_count`, `rules_batch`, and `ASSESSMENT_RULES_SCHEMA_EXAMPLE`.
3. System prompt: `ASSESSMENT_RULES_BATCH_SYSTEM_PROMPT`.

**LLM call**

```
provider.invoke_with_tools_agentic(
    prompt=prompt_content,
    project_path=project_path,
    system_prompt=ASSESSMENT_RULES_BATCH_SYSTEM_PROMPT,
    max_tokens=settings.bedrock.max_tokens,      # default 64000
    temperature=settings.bedrock.temperature,    # default 0.0
    enable_tools=False,
    prepend_project_context=False,
)
```

Provider comes from `provider_factory.get_provider()` **once per batch** (Compass active connection). Supported adapter keys: `aws-bedrock`, `portkey`, `azure`, `azure-ai-foundry`, `concierto-private-llm`.

Because `enable_tools=False`, `LLMOrchestrator._invoke_tool_loop` makes **one** chat call, then returns (no tool follow-ups). The orchestrator still **appends global JSON completion instructions** to the system prompt (require a ` ```json ` fence). The assessment user prompt says “no fences”; the parser accepts both raw arrays and fenced blocks.

**Resilience around the call**

- `with_resilience`: timeout `TIMEOUT_ASSESSMENT_RULES_BATCH` (default **3000s**), **3** retries, retry only `ProviderError`, `ConnectionError`, `TimeoutError`. **Not** `RateLimitError` (handled outside).
- Stack order: timeout → circuit breaker (default Bedrock breaker) → retry.
- Outer loop: on `RateLimitError`, sleep `max(retry_after, llm_rate_limiter.throttle_recovery)` or 30s if neither; retry up to `ASSESSMENT_RULES_BATCH_RATE_LIMIT_MAX_RETRIES` (default **12**). Exhausted → chunk error response.

**Parse**

1. `StreamParser.extract_full_assistant_response`: concatenate events with `type=="assistant"` and `subtype=="text_delta"`.
2. `_parse_json_array_from_assistant_text`:
   - Try `json.loads` on full stripped text.
   - Try robust extract of ` ```json ` block (bracket/quote aware; backticks inside strings ignored).
   - Try slice from first `[` to last `]`.
   - Must be a **JSON array**. Otherwise `ValueError`.
3. `raw_response` truncated to **20_000** characters on parse failure.

**Count check**

Normalized list length must equal **this chunk’s** rule count. Mismatch → error (includes parsed `rules` for debugging).

**Normalize**

`_normalize_batch_rules_for_client` → `_normalize_batch_rule_item_for_client` (see §9).

**Artifacts**

Stream file is written **only on parse failure or count mismatch**:

`{workspace}/assessment-rules-batch/{analysisId}/_claude/assessment-rules-batch-stream-chunk-{N}.json`

Pretty-printed JSON array of stream events. Path returned as `outputFilePath`. Successful chunks do **not** persist the stream.

### 7.7 Successful batch completion

Concatenate `rules_by_chunk[1] … [chunk_count]` (input order). Return:

- `status=success`, `isFinal=true`
- `chunkIndex=chunkCount`, `chunkCount=…`
- `ruleCountExpected` / `ruleCountReturned` / `rulesCompletedSoFar` = total
- `rules` = full list
- `rawResponse` / `outputFilePath` / `errorDetails` = null

NATS: this object is the function return; the last `on_progress` already published **only the last chunk’s rules** with `isFinal=true`.

---

## 8. Prompt logic (what the model is told)

### 8.1 System prompt (compact)

- Return **only** a JSON array (prose outside JSON forbidden).
- Each element: `ruleId`, `detectionSchema`, `assessmentSchema`.
- `parser`: `"REGEX"`; patterns in `detectionCriteria.searchPattern`.
- `fileType` must include **every** extension any pattern targets (including xml/yml/properties/json for config).
- If `example` is present: at least one pattern derived from it, plus structural variations.
- Case-sensitive by default; inline `(?i)` where keys/tags/annotations commonly vary.
- JSON escaping of regex:
  - Regex `\d` → JSON `"\\d"` (two backslashes in JSON text).
  - Literal `\` in source (Windows paths) → regex `\\` → JSON `"\\\\"` (four backslashes).
- `fileType` is extensions, not language names (`csharp` → `cs`, `vb.net` → `vb`).
- No tools, files, or shell.
- Fences **allowed**.

### 8.2 User prompt

- Exact object count = chunk size.
- Output order = input order; copy `ruleId` / name / description / domain / language / `category` / `issueType` / `severity`.
- Full instructional `ASSESSMENT_RULES_SCHEMA_EXAMPLE` plus **REMEDIATION RULES**, which replace `pathwayImpacts`. `category`, `issueType`, and `severity` are copied from the input rule.
- **Pattern coverage:** walk categories that **apply** (direct usage, wrapped, framework, FQCN, imports, annotations, config formats, fluent/builder, naming). Skip others. Prefer several targeted patterns over one giant regex. Design smells without a keyword → **lexical proxy** from the rule’s own wording only.

### 8.3 Assessment schema (model-generated; not post-validated field-by-field)

The handler does **not** schema-validate assessment enums. It copies `assessmentSchema` as a dict (or uses leftover top-level keys if the model flattened the body). It ensures `ruleId` is set if missing, then overwrites `category`, `issueType`, and `severity` with the values from the matching input rule. If that `issueType` is `BOOSTER` (case-insensitive), it sets `remediation` to `{}`.

Expected assessment fields (prompt): `description`, `name`, `domain`, `category`, `tags`, `businessImpact`, `version`, `source`, `issueType`, `language`, `severity`, `technicalDebt`, `scope`, `remediation` (the four domains below, or `{}` when `issueType` is `BOOSTER`), `relationships`, `status`, `schemaVersion`, `lastUpdated`.

`pathwayImpacts` is not part of the contract. The model must not emit it.

Remediation is chosen from the input `domain` (trim, then case-insensitive match of the whole string). Any other domain omits the `remediation` key. The input `issueType` decides booster handling: `BOOSTER` sets `remediation` to `{}` even when the domain matches, and the handler replaces any model-emitted remediation with that empty object. Omit, for a non-booster rule outside the four domains, means the key is absent.

| Domain | Shape | Lists |
|---|---|---|
| Cloud Compatibility | `remediation.aws` / `.azure` / `.gcp`, each with `remediations` | 1–3 per cloud; exactly one `isDefault` `"True"` per cloud |
| Software Portability | `remediation.<cloud>.containerServices` for `EKS`, `ECS Fargate` (AWS), `AKS` (Azure), `GKE` (GCP) | 1–3 per container service; exactly one `isDefault` `"True"` per service |
| Code Sustainability, Security Health | `remediation.remediations` only (no cloud or container keys) | 1–3; exactly one `isDefault` `"True"` |

Each remediation object has `remediationId`, `name`, `description`, `detailed_description`, `effort`, `isDefault`, and `rule_id`. Software Portability objects also have `containerService` equal to the container key (`EKS`, `ECS Fargate`, `AKS`, `GKE`).

`description` is a complete explanation of that remediation (what is wrong, what to change, and why). It must stand on its own. `detailed_description` is an additional deeper string (root cause, steps, before/after, pitfalls) and does not replace `description`. Both are strings.

- `effort`: `Simple`, `Trivial`, `Major`, `Moderate`, or `Complex`.
- `isDefault`: the string `"True"` or `"False"`, never a boolean.
- `rule_id`: exact input `ruleId`.
- `remediationId`: `rem-<ruleId>-<aws|azure|gcp>-<001–003>` (Cloud Compatibility); `rem-<ruleId>-<cloud>-<eks|ecs-fargate|aks|gke>-<001–003>` (Software Portability); `rem-<ruleId>-<001–003>` (Code Sustainability and Security Health). Cloud and container segments in the id are lowercase. `ECS Fargate` uses `ecs-fargate`.

---

## 9. Detection normalization (every rule)

### 9.1 Split

- `detectionSchema` / `assessmentSchema` pulled off the object.
- Remaining keys treated as a “body” (legacy flattened assessment).
- If `assessmentSchema` is a dict, use it; else use body.
- Copy top-level `ruleId` into assessment if assessment `ruleId` is null.

### 9.2 New shape (`detectionCriteria` is a dict)

`_finalize_new_detection_schema`:

- Force `status=active`, `parser=REGEX`.
- `setdefault` `ruleId`, `ruleName` from body `name`, `version="1.0"`.
- Coerce `language` string → `{name, versions:[]}`.
- If `detectionCriteria` missing: default `fileType` from language map + empty `searchPattern`.
- If `fileType` empty: fill from language map.
- Empty/non-list `scope` → `["function"]`.

### 9.3 Legacy shape (no `detectionCriteria`)

`_legacy_detection_to_new_schema`:

- `matchHints` strings become `searchPattern`.
- Language from detection or body.
- Same forced `status`/`parser`/`fileType` defaults.

### 9.4 Language → default `fileType`

| Language id (lowercased) | Extensions |
|---|---|
| java | java |
| typescript, ts | ts, tsx |
| jsp | jsp, jspx |
| html, htm | html, htm |
| css | css |
| python, py | py |
| c++, cpp, cplusplus | cpp, cc, cxx, hpp, hh, hxx, h, inl, ipp |
| csharp, c#, cs | cs |
| javascript, js | js, jsx, mjs, cjs |
| php | php |
| vb.net, vbnet, vb, visual basic, visualbasic | vb, vbhtml |
| anything else | `[language]` if non-empty, else `[]` |

Defaults **only** fill empty `fileType`. Config extensions must still come from the model.

### 9.5 Non-object model item

Produces empty REGEX shell: empty language name, empty patterns, empty assessment.

---

## 10. Response contract (camelCase on the wire)

| Field | Meaning |
|---|---|
| `status` | `partial` \| `success` \| `error` |
| `message` | Human summary |
| `isFinal` | More NATS messages may follow if false |
| `chunkIndex` | 1-based |
| `chunkCount` | Total chunks |
| `rulesCompletedSoFar` | Running total of successfully normalized rules |
| `analysisId` | Echo |
| `ruleCountExpected` | Request size (full batch on fail-fast errors) |
| `ruleCountReturned` | Objects in **this** message’s `rules` (chunk size on progress) |
| `rules` | List of `{ ruleId, detectionSchema, assessmentSchema }` |
| `rawResponse` | Assistant text on parse failure (capped) |
| `outputFilePath` | Stream dump on parse/count failure |
| `errorDetails` | Exception / mismatch text |

NATS omits nulls (`exclude_none=True`). HTTP includes model defaults.

---

## 11. Configuration reference

Prefix `ASSESSMENT_RULES_BATCH_`:

| Env | Default | Meaning |
|---|---|---|
| `ASSESSMENT_RULES_BATCH_MAX_RULES` | 50 | Reject whole request if larger |
| `ASSESSMENT_RULES_BATCH_CHUNK_SIZE` | 5 | Rules per LLM call |
| `ASSESSMENT_RULES_BATCH_MAX_PARALLEL_CHUNKS` | 2 | Concurrent chunk calls in one job |
| `ASSESSMENT_RULES_BATCH_MAX_CONCURRENT_REQUESTS` | 1 | Concurrent jobs process-wide |
| `ASSESSMENT_RULES_BATCH_RATE_LIMIT_MAX_RETRIES` | 12 | Dedicated 429 retries per chunk |

Other:

| Env | Default | Meaning |
|---|---|---|
| `TIMEOUT_ASSESSMENT_RULES_BATCH` | 3000 | Seconds per chunk (timeout wrapper) |
| `BEDROCK_MAX_TOKENS` | 64000 | Passed into invoke |
| `BEDROCK_TEMPERATURE` | 0.0 | Passed into invoke |
| `WORKSPACE_BASE_PATH` | `/studio-app/claude-workspace` | Stream + work dirs |
| `NATS_ENABLED` | true | Start subscriber |
| `NATS_SCHEMA_GENERATE_REQUEST_SUBJECT` | `schema.generate.request` | Subscribe |
| `NATS_SCHEMA_GENERATE_RESULT_SUBJECT` | `schema.generate.result` | Publish |
| `NATS_PROJECT_PATH` | unset | Work dir for NATS jobs |
| `NATS_PLATFORM` | linux | Forced on NATS-mapped requests |
| `LLM_RATE_LIMITER_THROTTLE_RECOVERY` | 60 | Extra sleep after 429 (also used in chunk backoff) |

`AssessmentRulesBatchConfig` is declared twice in `config.py` with the same env prefix; the later class wins. Defaults match the table above.

---

## 12. Observability

Log prefix **`[detection-schema]`** with UTC start/complete and monotonic `duration_sec` for phases:

- `BATCH` — whole job
- `CHUNK` — one chunk including LLM + parse + normalize
- `LLM` — provider call
- `PARSE` — JSON array extract
- `NORMALIZE` — contract coerce

Per-rule after normalize: `ruleId`, `parser`, `status`, `language`, `fileTypes`, `searchPattern_count`.

NATS: `[nats-schema-gen]` for connect plan (no secrets).

HTTP: full response JSON printed to stdout before return.

---

## 13. Failure matrix

| Failure | HTTP | NATS |
|---|---|---|
| Invalid JSON body / missing `rules` | 400 (Pydantic) | Publish `error` `isFinal=true` |
| Blank rule fields / bad `analysisId` | 400 `ValidationError` | Publish `error` |
| `> max_rules` | 400 | Publish `error` |
| Bad `projectPath` characters | 400 | Publish `error` |
| Compass / unsupported provider | 200 `status=error` **or** 500 if handler returns error | Publish `error` |
| LLM `ProviderError` after 3 retries | Handler error → HTTP **500** | Publish `error`; cancel other chunks |
| 429 after 12 dedicated retries | HTTP 500 | Same |
| Invalid JSON array | HTTP 500 + `rawResponse` + stream file | Publish same |
| Array length ≠ chunk size | HTTP 500 + `rules` (parsed) + stream file | Publish same |
| NATS connect/config at startup | Process fails to start if `NATS_ENABLED` | n/a |
| NATS publish without connection | n/a | `RuntimeError` logged; error path may fail |

Fail-fast: later chunks never complete after the first error; in-flight tasks are cancelled.

---

## 14. HTTP vs NATS (differences that matter)

| Topic | HTTP | NATS |
|---|---|---|
| Path / subject | `POST …/assessment-rules-batch` | `schema.generate.request` → `.result` |
| Progress | Hidden; one response | One message per completed chunk |
| Final `rules` on the wire | **Full list** | Last success message is **last chunk only**; client must concatenate |
| `analysisId` | Required | Optional; generated `schema-gen-…` |
| `platform` | Client (`linux`/`windows`) | Always `NATS_PLATFORM` |
| `projectPath` | Optional in body | Optional env `NATS_PROJECT_PATH` only |
| `example` | Pydantic optional | Omitted when null |
| Auth | App/CORS as usual | SQLite + env + optional GCM |
| Duplicate workers | Each HTTP call is one job | No queue group → every replica handles every message |
| Error HTTP status | 400 validation; 500 handler `status=error`; some exceptions return 200 + `status=error` | Always a result message |

---

## 15. Example payloads

### 15.1 Request (HTTP body or logical NATS JSON)

```json
{
  "analysisId": "schema-001",
  "platform": "linux",
  "rules": [
    {
      "ruleId": "R-JAVA-001",
      "domain": "code-quality",
      "category": "Code Quality",
      "issueType": "NEUTRAL",
      "severity": "MEDIUM",
      "language": "java",
      "name": "Avoid java.util.Date",
      "description": "Use java.time instead of java.util.Date.",
      "example": "new java.util.Date()"
    }
  ]
}
```

### 15.2 Normalized item (shape)

```json
{
  "ruleId": "R-JAVA-001",
  "detectionSchema": {
    "ruleId": "R-JAVA-001",
    "ruleName": "Avoid java.util.Date",
    "version": "1.0",
    "status": "active",
    "parser": "REGEX",
    "language": { "name": "java", "versions": [] },
    "scope": ["function"],
    "detectionCriteria": {
      "fileType": ["java"],
      "searchPattern": ["java\\.util\\.Date", "new\\s+Date\\s*\\("]
    }
  },
  "assessmentSchema": {
    "ruleId": "R-JAVA-001",
    "name": "Avoid java.util.Date",
    "domain": "code-quality",
    "category": "Code Quality"
  }
}
```

`domain` here is `code-quality`, which is not Cloud Compatibility, Software Portability, Code Sustainability, or Security Health, so `remediation` is omitted. `assessmentSchema` in production is much larger (prompt example). The handler does not strip extra keys and does not rewrite `remediation`.

### 15.3 NATS progress (12 rules, chunk size 5)

1. `status=partial`, `isFinal=false`, `chunkIndex=1`, `chunkCount=3`, `ruleCountReturned=5`, `rulesCompletedSoFar=5`
2. `status=partial`, `isFinal=false`, `chunkIndex=2`, … `rulesCompletedSoFar=10`
3. `status=success`, `isFinal=true`, `chunkIndex=3`, `ruleCountReturned=2`, `rulesCompletedSoFar=12`

Chunks 1 and 2 may complete in either wall-clock order; the handler **emits sorted by `chunkIndex` within a wait wave**, but across waves order follows completion. Consumers should key on `analysisId` + `chunkIndex`.

---

## 16. Sequence (NATS)

```mermaid
sequenceDiagram
    participant RM as Rules Management
    participant NATS as NATS
    participant Svc as studio-ai-agents
    participant LLM as Compass LLM

    Svc->>NATS: subscribe schema.generate.request
    RM->>NATS: publish request JSON
    NATS->>Svc: _on_message
    Svc->>Svc: map payload, validate, acquire job slot
    par up to 2 chunks
        Svc->>LLM: invoke tools off
        LLM-->>Svc: assistant text JSON array
        Svc->>Svc: parse + normalize
        Svc->>NATS: publish schema.generate.result (partial/success)
    end
    Note over Svc,NATS: On first chunk error: cancel rest, publish error isFinal=true
```

## 17. Sequence (HTTP)

```mermaid
sequenceDiagram
    participant Client
    participant API as FastAPI
    participant H as AssessmentRulesBatchHandler
    participant LLM as Compass LLM

    Client->>API: POST /assessment-rules-batch
    API->>API: Pydantic bind
    API->>H: execute_batch (no on_progress)
    H->>H: job semaphore + validate + chunk
    par up to 2 chunks
        H->>LLM: invoke tools off
        LLM-->>H: JSON array
        H->>H: parse + normalize
    end
    H-->>API: full AssessmentRulesBatchResponse
    alt status error
        API-->>Client: 500 detail=payload
    else success
        API-->>Client: 200 full rules list
    end
```

---

## 18. Demo talking points

1. Catalog text in; two stored documents out.
2. Detection is REGEX-only and post-enforced even if the model drifts.
3. HTTP is synchronous full-batch; NATS is chunked progress (concatenate `rules`).
4. `csharp` → `fileType: ["cs"]`, not `"csharp"`.
5. Jobs are gated (1 at a time by default); chunks fan out to 2 LLM calls; 429s have a dedicated retry loop.
6. Logs `[detection-schema]` give BATCH/CHUNK/LLM/PARSE/NORMALIZE timings live.

This is the complete flow as implemented in this repository.
