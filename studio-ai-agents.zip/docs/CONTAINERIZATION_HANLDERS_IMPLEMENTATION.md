---
name: Containerization Handlers Implementation
overview: Add 4 new containerization operation handlers (containerization-analysis, selective-fix, generation, summary) to the Python application following existing handler patterns, using the same /executeCommandWithPrompt API with operation-based routing.
todos:
  - id: update-enums
    content: Add 4 new operation types to OperationType enum in app/models/enums.py
    status: completed
  - id: update-base-handler
    content: Update get_output_directory() in base_handler.py to explicitly map containerization operations
    status: completed
  - id: create-analysis-handler
    content: Create containerization_analysis_handler.py following analysis_handler.py pattern
    status: completed
  - id: create-selective-fix-handler
    content: Create selective_fix_handler.py - COMPLETE copy of fix_upgrade_handler.py implementation including post-transformation build validation
    status: completed
  - id: create-generation-handler
    content: Create generation_handler.py for Docker/Kubernetes artifact generation
    status: completed
  - id: create-summary-handler
    content: Create summary_handler.py for creating comprehensive summary reports
    status: completed
  - id: register-handlers
    content: Register all 4 new handlers in claude_service.py _handler_registry
    status: completed
  - id: test-handlers
    content: Test each handler independently and verify output file creation
    status: completed
isProject: false
---

# Containerization Handlers Implementation Plan

## Overview

Implement 4 new operation handlers for containerization feature in the Python application, following the established agentic architecture pattern used for existing handlers like `[analysis_handler.py](src/main/python/app/services/operation_handlers/analysis_handler.py)`.

## Architecture Understanding

The application uses an **operation handler pattern** where:

- Requests come through `/api/claude/executeCommandWithPrompt` endpoint
- `[claude_service.py](src/main/python/app/services/claude_service.py)` routes to specific handlers based on `operation` field
- Each handler extends `[BaseOperationHandler](src/main/python/app/services/operation_handlers/base_handler.py)` (491 lines)
- Handlers interact with LLM via BedrockClient/PortkeyClient with tool support (code_editor, bash)
- Output files are written to `claude-workspace/{operation_dir}/{analysisId}/` structure

## Required Changes

### 1. Update Enums (`app/models/enums.py`)

Add 4 new operation types to `OperationType` enum:

```python
CONTAINERIZATION_ANALYSIS = "containerization-analysis"
SELECTIVE_FIX = "selective-fix"
GENERATION = "generation"
SUMMARY = "summary"
```

### 2. Update BaseHandler Output Directory Mapping

The `[get_output_directory()](src/main/python/app/services/operation_handlers/base_handler.py#L113-L149)` method already has a fallback to "containerization" (line 148), but should explicitly map the new operations:

```python
elif operation in ["containerization-analysis", "selective-fix", "generation", "summary"]:
    return "containerization"
```

### 3. Create 4 New Handler Files

#### A. `containerization_analysis_handler.py`

**Pattern**: Similar to `[analysis_handler.py](src/main/python/app/services/operation_handlers/analysis_handler.py)` (143 lines)

**Key Features**:

- Timeout: 3000s (default)
- Output file: `containerization/{analysisId}/containerization-analysis-stream.json`
- Reads prompt file (expects path to analysis prompt with containerization rules)
- Uses AI provider to analyze application for containerization blockers
- Returns JSON response with blockers, severity levels, remediation steps

**Implementation approach**:

```python
class ContainerizationAnalysisHandler(BaseOperationHandler):
    def get_timeout(self) -> int:
        return settings.timeouts.default  # 3000s
    
    def validate_request(self, request: ClaudeCliRequest):
        # Validate common fields + prompt required
    
    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        # 1. Get AI provider
        # 2. Read prompt file
        # 3. Build output path: "containerization-analysis-stream.json"
        # 4. Invoke with resilience wrapper
        # 5. Write stream output
        # 6. Return success/error response
```

#### B. `selective_fix_handler.py`

**Pattern**: **COMPLETE implementation following `[fix_upgrade_handler.py](src/main/python/app/services/operation_handlers/fix_upgrade_handler.py)**` (581 lines)

**Key Features**:

- Timeout: 3600s (extended for fixes)
- Output file: `containerization/{analysisId}/selective-fix-stream.json`
- Reads prompt with specific blocker IDs to fix (from `[selective-fix-system-prompt.txt](src/main/resources/prompts/selective-fix-system-prompt.txt)`)
- Makes targeted code changes to fix containerization blockers
- **Includes post-transformation build validation** (same as fix_upgrade_handler)
- **Auto-fixes compilation errors** (up to 10 iterations)
- Returns JSON with files modified, changes made, and final build status

**CRITICAL: Same Implementation as FixUpgradeHandler**:

1. **Phase 1**: Apply fixes for specified blockers using AI
2. **Phase 2**: Automatic post-transformation error fixing (10 iterations max)
  - Run build (`mvn compile` or `dotnet build`)
  - Extract and categorize errors
  - Generate fix prompt for AI
  - Apply fixes using code_editor tool
  - Repeat until build succeeds or max iterations reached
3. **All logic from FixUpgradeHandler applies**:
  - Project type detection (Java/DotNet)
  - Build execution and error extraction
  - Error categorization by type/pattern
  - Fix prompt generation
  - Iteration tracking in stream events

**Implementation approach**:

```python
class SelectiveFixHandler(BaseOperationHandler):
    MAX_FIX_ITERATIONS = 10  # Same as FixUpgradeHandler
    
    def get_timeout(self) -> int:
        return settings.timeouts.upgrade_operations  # 3600s
    
    def validate_request(self, request: ClaudeCliRequest):
        # Validate common fields + prompt required
    
    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        # EXACTLY like FixUpgradeHandler:
        # 1. Get AI provider
        # 2. Read prompt with blocker IDs (selective-fix prompt)
        # 3. Build output path: "selective-fix-stream.json"
        # 4. Phase 1: Invoke AI with code_editor/bash tools to fix blockers
        # 5. Phase 2: Run _run_post_transformation_fixes() - SAME method
        # 6. Write combined stream output (blocker fixes + build iterations)
        # 7. Return success/error response
    
    # Copy these methods from FixUpgradeHandler:
    async def _run_post_transformation_fixes(...)
    def _detect_project_type(...)
    async def _run_build(...)
    def _extract_error_lines(...)
    def _categorize_errors(...)
    def _sanitize_category_name(...)
    def _generate_fix_prompt(...)
```

**Difference from FixUpgradeHandler**: ONLY the initial prompt content differs

- **FixUpgradeHandler**: Uses upgrade prompts for version migration fixes
- **SelectiveFixHandler**: Uses selective-fix prompts for specific containerization blockers
- **Everything else**: Identical implementation (build validation, error fixing, iteration logic)

#### C. `generation_handler.py`

**Pattern**: Similar to `[analysis_handler.py](src/main/python/app/services/operation_handlers/analysis_handler.py)` structure

**Key Features**:

- Timeout: 3000s (default)
- Output file: `containerization/{analysisId}/generation-stream.json`
- Reads prompt (expects generation instructions from `[generation-system-prompt.txt](src/main/resources/prompts/generation-system-prompt.txt)`)
- **CRITICAL**: AI generates JSON with complete file content embedded - does NOT write files directly
- Returns JSON with artifacts structure containing file names as keys and complete content as values
- **Java calling service** extracts files from JSON and writes them to project directory

**How it differs from selective-fix**:

- **NO code_editor tool** - AI only generates JSON response
- Files are NOT created in the project during this operation
- JSON response includes complete file content for Dockerfile, docker-compose.yml, K8s manifests, scripts
- The calling service (Java ContainerizationService) reads the JSON and creates the actual files

**Implementation approach**:

```python
class GenerationHandler(BaseOperationHandler):
    def get_timeout(self) -> int:
        return settings.timeouts.default  # 3000s
    
    def validate_request(self, request: ClaudeCliRequest):
        # Validate common fields + prompt required
    
    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        # 1. Get AI provider
        # 2. Read prompt file (generation-system-prompt.txt + user prompt)
        # 3. Build output path: "generation-stream.json"
        # 4. Invoke AI with code_editor ENABLED for project analysis only
        # 5. AI returns JSON with complete file content embedded
        # 6. Write stream output containing the JSON
        # 7. Return success/error response
```

**Example JSON structure returned by AI** (embedded in stream):

```json
{
  "analysisId": "container-001",
  "dockerFiles": {
    "dockerfile": {
      "path": "Dockerfile",
      "content": "FROM maven:3.9.4-eclipse-temurin-17 AS builder\n..."
    },
    "dockerCompose": {
      "path": "docker-compose.yml", 
      "content": "version: '3.8'\nservices:\n..."
    }
  },
  "kubernetesFiles": {
    "deployment": {
      "path": "kubernetes/deployment.yaml",
      "content": "apiVersion: apps/v1\nkind: Deployment\n..."
    }
  },
  "deploymentScripts": [
    {
      "name": "build-push.sh",
      "path": "scripts/build-push.sh",
      "content": "#!/bin/bash\n..."
    }
  ]
}
```

#### D. `summary_handler.py`

**Pattern**: Similar to `[analysis_handler.py](src/main/python/app/services/operation_handlers/analysis_handler.py)`

**Key Features**:

- Timeout: 1800s (shorter, just summarizing)
- Output file: `containerization/{analysisId}/summary-stream.json`
- Reads prompt with references to previous reports
- Creates executive summary of containerization process
- Returns comprehensive summary report

**Implementation approach**:

```python
class SummaryHandler(BaseOperationHandler):
    def get_timeout(self) -> int:
        return settings.timeouts.default  # 3000s
    
    def validate_request(self, request: ClaudeCliRequest):
        # Validate common fields + prompt required
    
    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        # 1. Get AI provider
        # 2. Read prompt file (references analysis/fix/generation reports)
        # 3. Build output path: "summary-stream.json"
        # 4. Invoke AI to generate summary
        # 5. Write stream output
        # 6. Return success/error response
```

### 4. Register Handlers in ClaudeService

Update `[claude_service.py](src/main/python/app/services/claude_service.py)` `_handler_registry` (lines 57-68):

```python
from app.services.operation_handlers.containerization_analysis_handler import ContainerizationAnalysisHandler
from app.services.operation_handlers.selective_fix_handler import SelectiveFixHandler
from app.services.operation_handlers.generation_handler import GenerationHandler
from app.services.operation_handlers.summary_handler import SummaryHandler

self._handler_registry: Dict[str, Type[BaseOperationHandler]] = {
    # ... existing handlers ...
    "containerization-analysis": ContainerizationAnalysisHandler,
    "selective-fix": SelectiveFixHandler,
    "generation": GenerationHandler,
    "summary": SummaryHandler,
}
```

### 5. Update Handler Package Exports

Update `[__init__.py](src/main/python/app/services/operation_handlers/__init__.py)` to export new handlers (optional, currently minimal).

## File Output Structure

Following the pattern from `[base_handler.py](src/main/python/app/services/operation_handlers/base_handler.py#L113-L149)`:

```
claude-workspace/
└── containerization/
    └── {analysisId}/
        ├── containerization-analysis-stream.json  # Contains blocker analysis JSON
        ├── selective-fix-stream.json              # Contains fix results JSON
        ├── generation-stream.json                 # Contains artifact definitions with embedded file content
        └── summary-stream.json                    # Contains executive summary JSON

# NOTE: Actual artifact files (Dockerfile, K8s manifests, etc.) are NOT created here
# They are created in the project directory by the Java calling service after 
# extracting file content from generation-stream.json
```

**Workflow**:

1. **Analysis**: Writes blocker report to `containerization-analysis-stream.json`
2. **Selective-fix**: Modifies project files directly, writes fix report to `selective-fix-stream.json`
3. **Generation**: Writes JSON with complete file content to `generation-stream.json`
4. **Java Service**: Reads `generation-stream.json`, extracts files, writes to project directory:
  ```
   {projectPath}/
   ├── Dockerfile
   ├── docker-compose.yml
   ├── .dockerignore
   ├── kubernetes/
   │   ├── deployment.yaml
   │   ├── service.yaml
   │   └── ...
   └── scripts/
       ├── build-push.sh
       └── ...
  ```
5. **Summary**: Reads all previous reports, writes summary to `summary-stream.json`

## API Usage Pattern

All operations use the **same API endpoint** with different `operation` values:

```json
POST /api/claude/executeCommandWithPrompt

{
  "prompt": "/path/to/containerization-analysis-prompt.txt",
  "projectPath": "/projects/my-app",
  "analysisId": "container-001",
  "operation": "containerization-analysis",  // or "selective-fix", "generation", "summary"
  "platform": "linux"
}
```

**Response** (unchanged):

```json
{
  "status": "success",
  "message": "Operation completed successfully",
  "exitCode": 0,
  "outputFilePath": "/tmp/claude-outputs/containerization/container-001/containerization-analysis-stream.json",
  "inputTokens": 5000,
  "outputTokens": 15000
}
```

## Key Implementation Notes

1. **No Payload Changes**: Uses existing `[ClaudeCliRequest](src/main/python/app/models/requests.py)` model (lines 10-174)
2. **No Response Changes**: Uses existing `[ClaudeCliResponse](src/main/python/app/models/responses.py)` model
3. **Prompt-Driven**: Each operation reads a prompt file that contains:
  - System instructions (from Java prompts like `analysis-system-prompt.txt`)
  - User instructions with project context
  - Expected output format (JSON)
4. **Tool Usage**: Handlers enable AI tools strategically:
  - **containerization-analysis**: `code_editor` (read-only for analysis), `bash` (optional)
  - **selective-fix**: `code_editor` (read/write to fix blockers), `bash` (optional)
  - **generation**: `code_editor` (read-only for project analysis), NO file creation - returns JSON only
  - **summary**: `code_editor` (read previous reports), NO modifications
5. **Agentic Pattern**: AI determines actions autonomously based on prompt instructions
6. **Resilience**: All handlers use `@with_resilience` decorator (retry, timeout, circuit breaker)
7. **Logging**: Comprehensive logging at each step using structured logging

## Testing Approach

1. Create test prompts in appropriate locations (Java side has prompts in `src/main/resources/prompts/`)
2. Test each operation independently:
  - `containerization-analysis`: Analyzes project for containerization blockers (read-only)
  - `selective-fix`: Fixes specific blockers + auto-fixes build errors (modifies code, 10 iterations)
  - `generation`: Analyzes project and returns JSON with artifact definitions (read-only, JSON output)
  - `summary`: Summarizes all phases (read-only)
3. Test full workflow: analysis → selective-fix → generation → summary
4. Verify output files are created in correct locations
5. Validate JSON responses match expected structure

## Comparison with Java Implementation

### Java Architecture (Claude CLI subprocess)

```
Java Controller 
  → ClaudeCliService 
    → ClaudeCliLinuxService 
      → Executes: `claude --stream-json --prompt {prompt} --project {project}`
        → Claude CLI processes operation type
        → Returns stream.json with results
  → Java service reads stream.json
  → For generation: extracts file content and creates files in project
```

### Python Architecture (Agentic with direct Bedrock/Portkey API)

```
Java Controller
  → Python FastAPI (/executeCommandWithPrompt)
    → ClaudeService routes by operation
      → ContainerizationAnalysisHandler / SelectiveFixHandler / GenerationHandler / SummaryHandler
        → BedrockClient/PortkeyClient with tools (code_editor, bash)
        → AI processes operation autonomously
        → Returns stream events
      → Handler writes stream.json
  → Java service reads stream.json (same format)
  → For generation: extracts file content and creates files in project (same process)
```

### Key Equivalence Points

1. **Same API**: `/executeCommandWithPrompt` with same request/response models
2. **Same Output Format**: stream.json files with operation results
3. **Same File Extraction**: Java service handles file creation from generation JSON
4. **Same Workflow**: Analysis → Fix → Generation → Summary
5. **Different Execution**: Python uses agentic AI with tools vs subprocess CLI

## Benefits of This Approach

- ✅ **Zero Breaking Changes**: Uses existing API, models, and infrastructure
- ✅ **Consistent Pattern**: Follows established handler architecture (analysis_handler.py, fix_upgrade_handler.py)
- ✅ **Maintainable**: Each handler is ~100-150 lines, focused responsibility
- ✅ **Extensible**: Easy to add more containerization operations
- ✅ **Resilient**: Inherits retry, timeout, circuit breaker patterns
- ✅ **Observable**: Built-in logging and error handling
- ✅ **Java Compatible**: Output format matches Java's expectations for file extraction

## Implementation Summary

### Handler Complexity Overview

1. **ContainerizationAnalysisHandler**: ~150 lines (simple - analyze and return JSON)
2. **SelectiveFixHandler**: ~580 lines (complex - complete copy of FixUpgradeHandler with build validation)
3. **GenerationHandler**: ~150 lines (simple - analyze and return JSON with embedded file content)
4. **SummaryHandler**: ~150 lines (simple - read reports and generate summary)

### Code Reuse Strategy

- **SelectiveFixHandler**: Copy entire implementation from FixUpgradeHandler
  - All helper methods: `_run_post_transformation_fixes()`, `_detect_project_type()`, `_run_build()`, `_extract_error_lines()`, `_categorize_errors()`, etc.
  - Only change: Initial prompt file path and operation-specific output filename
  - Maintains consistency and proven error-fixing logic

### Total LOC Estimate: ~1030 lines across 4 handlers + registry updates

