# LLM Rate Limiting

## Overview

This document describes the proactive rate limiting system for outbound LLM API calls made by `portkey_client.py` and `bedrock_client.py`. Profiles are calibrated for **Claude Sonnet 4.5 V1 via AWS Bedrock cross-region inference**.

The system gates every outbound LLM call through four coordinated mechanisms before the call fires. If any mechanism determines a call must wait, the calling coroutine is suspended (`await asyncio.sleep(...)`) — it does not block the thread, does not fail, and does not affect other concurrent operations.

---

## AWS Bedrock Quotas — Claude Sonnet 4.5 V1

**Model ID (cross-region):** `us.anthropic.claude-sonnet-4-5-20250929-v1:0`

| Quota | Value | Notes |
|---|---|---|
| RPM (cross-region, per region) | **10,000** | Adjustable via AWS Support |
| TPM (cross-region, per region) | **5,000,000** | Adjustable via AWS Support |
| TPD (cross-region, per region) | 3,600,000,000 | = TPM × 60 × 12 |
| Output token burndown rate | **5× (Claude 3.7+)** | Critical — see below |
| RPM (1M context length variant) | 1,000 | Separate quota |
| TPM (1M context length variant) | 1,000,000 | Separate quota |

*Source: AWS Service Quotas, March 2026.*

### 5× Output Token Burndown Rate

For Claude Sonnet 4.5 (all Claude 3.7+ models), **every 1 output token consumes 5 tokens from your TPM quota**:

```
Effective quota cost = input_tokens + (output_tokens × 5)
```

**Upfront reservation at request start:**
```
Reserved at start = input_tokens + max_tokens   (current default: max_tokens=64,000)
```
The full `max_tokens` reservation is held for the duration of the call and refunded at completion. Only actual output tokens are billed.

**Why this matters for `DEFAULT_ESTIMATED_TOKENS`:**

| Call type | Input | Output | Effective cost |
|---|---|---|---|
| Early agentic iteration | ~5,000 | ~1,500 | 5,000 + 1,500×5 = **12,500** |
| Typical agentic iteration | ~10,000 | ~2,000 | 10,000 + 2,000×5 = **20,000** |
| Late agentic iteration (large ctx) | ~50,000 | ~2,000 | 50,000 + 2,000×5 = **60,000** |
| invoke_simple | ~3,000 | ~1,000 | 3,000 + 1,000×5 = **8,000** |

`DEFAULT_ESTIMATED_TOKENS=20000` reflects the typical agentic call effective cost. This is set conservatively — late-iteration calls are capped at TPM bucket capacity, so they wait for refill rather than being blocked.

### Actual Utilisation at Profile 2 (Balanced)

With 5 concurrent agentic operations on Sonnet 4.5 cross-region:

```
~7 LLM calls/min × 20,000 effective tokens = 140,000 TPM  →  2.8% of 5,000,000 quota
~7 LLM calls/min                           =       7 RPM  →  0.07% of 10,000 quota
```

The AWS quotas are extremely generous for typical production workloads. The rate limiter primarily provides application-level orderly queuing and adaptive backoff as a safety net.

---

## Problem Statement

Before this implementation, rate limiting was entirely reactive:

1. A 429 (or Bedrock `ThrottlingException`) occurred.
2. The exception was caught and re-raised as `RateLimitError`.
3. The `tenacity` retry decorator caught `RateLimitError` and retried with exponential backoff (2s, 4s, 8s...).
4. Under concurrent load, multiple operations would throttle simultaneously, cascading into longer retry chains and potential circuit-breaker trips.

No coordination existed between concurrent operations — each fired LLM calls independently regardless of quota consumption by others.

---

## Architecture

```
invoke_with_tools_agentic() / invoke_with_tools() / invoke_simple()
        │
        │  (per agentic iteration — NOT the entire loop)
        ▼
┌──────────────────────────────────────────────────────┐
│  LLMRateLimiter.acquire(estimated_tokens)            │
│                                                      │
│  Step 1: asyncio.Semaphore.acquire()                 │
│          Wait if MAX_CONCURRENT slots are occupied   │
│                                                      │
│  Step 2: Throttle-recovery sleep (if pending)        │
│          Applied once after any 429 event            │
│                                                      │
│  Step 3: RPM TokenBucket.acquire(1)                  │
│          Sleep until request token available         │
│                                                      │
│  Step 4: TPM TokenBucket.acquire(estimated_tokens)   │
│          Sleep until token budget available          │
│          (estimated_tokens uses 5× burndown cost)    │
│                                                      │
│  Step 5: asyncio.sleep(adaptive_delay)               │
│          Inter-call spacing (self-tuning)            │
│                                                      │
│  ── yield ── LLM HTTP/boto3 call happens here ──    │
│                                                      │
│  On RateLimitError: _record_throttle()               │
│  On clean exit:     _record_success()                │
│  Always:            Semaphore.release()              │
└──────────────────────────────────────────────────────┘
        │
        ▼
   Tool execution (file read/write/bash) — UNAFFECTED
   Semaphore is already released before tools run.
```

### Key Design Decisions

**Rate limiter wraps the LLM call only, not the agentic loop.**
In `invoke_with_tools_agentic()`, each iteration calls the LLM once, then executes tools. The rate limiter is applied only to the LLM call. Tool execution (file read/write/bash) runs freely and never waits on the rate limiter.

**Semaphore is released immediately after the LLM response arrives.**
A 5-minute agentic operation holds a semaphore slot for ~3–8 seconds per iteration (just the LLM call), not for the full 5 minutes. This allows maximum concurrency while preventing over-subscription.

**Recovery sleep is deferred, not immediate.**
When a 429 is detected, `_record_throttle()` sets a `_recovery_until` timestamp. The actual sleep happens at the START of the NEXT `acquire()` call. This lets tenacity retry reschedule first, then the rate limiter applies the cool-down before the next attempt.

**No failures, only queuing.**
`asyncio.Semaphore.acquire()` and `asyncio.sleep()` suspend the coroutine without blocking the event loop. The call will eventually proceed — there is no timeout or failure path through the rate limiter itself.

**TPM estimation uses effective token cost (5× burndown).**
`DEFAULT_ESTIMATED_TOKENS=20000` reflects the effective Bedrock quota cost, not raw token counts. This prevents the TPM bucket from under-counting usage and hitting the real AWS quota unexpectedly.

---

## Implementation Files

| File | Purpose |
|---|---|
| `app/core/llm_rate_limiter.py` | `TokenBucket`, `LLMRateLimiter` class, module-level singletons |
| `app/core/config.py` | `LLMRateLimiterConfig`, `BedrockRateLimiterConfig`, `PortkeyRateLimiterConfig` |
| `config/settings.yml` | Default values — Profile 2 (Balanced), Sonnet 4.5 calibrated |
| `env.rate_limiting_profiles` | 4 profiles with Bedrock-specific overrides; uncomment the desired one |
| `.env.example` | Documents all `LLM_RATE_LIMITER_*` variables |
| `app/services/portkey_client.py` | `invoke_with_tools`, `invoke_with_tools_agentic`, `invoke_simple` wrapped |
| `app/services/bedrock_client.py` | Same for Bedrock |

---

## Configuration Reference

All variables use the `LLM_RATE_LIMITER_` prefix. Per-provider overrides use `BEDROCK_RATE_LIMITER_` / `PORTKEY_RATE_LIMITER_`.

### Global Settings

| Variable | Default (Profile 2) | Description |
|---|---|---|
| `LLM_RATE_LIMITER_ENABLED` | `true` | Master toggle. `false` disables all limiting. |
| `LLM_RATE_LIMITER_MAX_CONCURRENT` | `5` | Max simultaneous in-flight LLM calls. |
| `LLM_RATE_LIMITER_REQUESTS_PER_MINUTE` | `50` | Global RPM bucket. `0` = unlimited. |
| `LLM_RATE_LIMITER_TOKENS_PER_MINUTE` | `150000` | Global TPM bucket (effective tokens with 5× burndown). |
| `LLM_RATE_LIMITER_INITIAL_DELAY` | `0.5` | Starting inter-call delay (seconds). |
| `LLM_RATE_LIMITER_MIN_DELAY` | `0.1` | Adaptive delay floor (seconds). |
| `LLM_RATE_LIMITER_MAX_DELAY` | `30.0` | Adaptive delay ceiling (seconds). |
| `LLM_RATE_LIMITER_SUCCESS_THRESHOLD` | `3` | Consecutive successes before reducing delay. |
| `LLM_RATE_LIMITER_DECREASE_FACTOR` | `0.8` | Multiply delay by this on success streak. |
| `LLM_RATE_LIMITER_INCREASE_FACTOR` | `1.5` | Multiply delay by this on throttle. |
| `LLM_RATE_LIMITER_THROTTLE_RECOVERY` | `30.0` | Recovery sleep after 429 (seconds). |
| `LLM_RATE_LIMITER_DEFAULT_ESTIMATED_TOKENS` | `20000` | Effective token cost estimate (input + output×5). |
| `LLM_RATE_LIMITER_ENABLE_ADAPTIVE_DELAYS` | `true` | Toggle adaptive delay sub-system. |
| `LLM_RATE_LIMITER_ENABLE_TOKEN_TRACKING` | `true` | Toggle TPM bucket. |
| `LLM_RATE_LIMITER_ENABLE_METRICS` | `false` | Emit metrics to logs. |

### Bedrock-Specific Overrides (Profile 2 — Sonnet 4.5 Active)

| Variable | Profile 2 Value | AWS Quota | Utilisation |
|---|---|---|---|
| `BEDROCK_RATE_LIMITER_REQUESTS_PER_MINUTE` | `250` | 10,000 | 2.5% |
| `BEDROCK_RATE_LIMITER_TOKENS_PER_MINUTE` | `1,000,000` | 5,000,000 | 20% |
| `BEDROCK_RATE_LIMITER_MAX_CONCURRENT` | `5` | — | — |

### Portkey Overrides

| Variable | Default | Description |
|---|---|---|
| `PORTKEY_RATE_LIMITER_REQUESTS_PER_MINUTE` | `0` | `0` = use global LLM_RATE_LIMITER value. |
| `PORTKEY_RATE_LIMITER_TOKENS_PER_MINUTE` | `0` | `0` = use global LLM_RATE_LIMITER value. |
| `PORTKEY_RATE_LIMITER_MAX_CONCURRENT` | `0` | `0` = use global LLM_RATE_LIMITER value. |

---

## Rate Limiting Profiles (Sonnet 4.5 Calibrated)

Four profiles are defined in `env.rate_limiting_profiles`. Activate one by uncommenting its block (only one active at a time).

| Profile | Global RPM | Bedrock RPM | Global TPM | Bedrock TPM | Concurrent | Initial Delay | AWS RPM % | AWS TPM % |
|---|---|---|---|---|---|---|---|---|
| 1 — Conservative | 30 | 60 | 100,000 | 400,000 | 2 | 2.0s | 0.6% | 8% |
| **2 — Balanced** *(default)* | **50** | **250** | **150,000** | **1,000,000** | **5** | **0.5s** | **2.5%** | **20%** |
| 3 — Aggressive | 100 | 1,000 | 300,000 | 2,500,000 | 10 | 0.2s | 10% | 50% |
| 4 — Maximum Speed | 0 (unlimited) | 8,000 | 500,000 | 4,000,000 | 20 | 0.0s | 80% | 80% |

TPM values reflect the **effective quota cost** after 5× burndown, not raw token counts.

---

## How It Works in Practice

### Single Agentic Operation — Sonnet 4.5 Profile 2

```
Iteration 1:  acquire() → RPM OK (250) → TPM OK → sleep(0.5s) → LLM call (4s) → release
              Tools execute (35s, no rate limiting)
Iteration 2:  acquire() → RPM OK → TPM OK → sleep(0.4s) → LLM call (4s) → release
              Tools execute (40s)
Iteration 3+: adaptive delay continues reducing toward 0.1s minimum
...
Iteration 8:  Large context (~60k tokens → 70k effective).
              acquire() → TPM bucket has 900k available → still OK, no wait.
              Bedrock TPM quota: 1,000,000 → 60k used = 6%. Fine.
```

Added overhead vs. no rate limiting: ~0.5s per iteration (reducing to ~0.2s).
Total overhead for 10 iterations: ~3–4 seconds on a ~7 minute operation.

### 6 Concurrent Operations (MAX_CONCURRENT=5)

```
Ops 1–5 acquire semaphore slots simultaneously → LLM calls fire
Op-6 awaits semaphore (suspends only its next LLM call — current tools run fine)
Op-3 finishes its LLM call (~4s) → releases slot → Op-6 wakes up → LLM call fires

Op-6 extra delay: ~4 seconds on first contention only.
All 6 operations complete normally, no throttle.
```

### Throttle Event Recovery (Sonnet 4.5 Profile 2)

```
Iteration N:  LLM call returns 429 / ThrottlingException
              Rate limiter records throttle:
                - delay: 0.5s → 0.75s (× 1.5 increase_factor)
                - recovery_until = now + 30s

              RateLimitError re-raised → tenacity retry catches it
              tenacity waits 2s (exponential backoff) → retries

Iteration N (retry):
              acquire() called again
              recovery_until check: ~28s remaining → sleep(28s)
              During 28s sleep: Bedrock TPM quota fully refills
              (5,000,000 tokens / 60s × 28s = 2,333,333 tokens refilled)
              LLM call fires → success
              adaptive delay reduces again toward minimum
```

---

## Interaction with Existing Resilience Patterns

```
Request
  │
  ▼
with_timeout() ─────────────────── outermost: kills runaway operations
  │
  ▼
AsyncCircuitBreaker ─────────────── trips on 5+ consecutive hard failures
  │
  ▼
tenacity retry ──────────────────── retries on RateLimitError, ProviderError
  │
  ▼
LLMRateLimiter.acquire() ────────── proactive queuing before each call
  │                                  (Sonnet 4.5: Bedrock override active)
  ▼
boto3.converse() / httpx.post() ─── actual LLM API call
```

---

## Agentic Loop — What Is and Is Not Rate Limited

```python
# invoke_with_tools_agentic() — full picture:

while True:                                       # ← loop: NOT rate limited
    # Build request...

    async with rate_limiter.acquire(tokens):      # ← rate limiter applied HERE
        response = bedrock.converse(...)          # ← LLM call: rate limited
    # semaphore released here ─────────────────── ← slot freed BEFORE tools run

    for tool in response.tool_calls:              # ← tool execution: NOT rate limited
        result = execute_tool(tool)               # file read/write/bash: runs freely
        conversation.append(result)

    if response.stop_reason == "end_turn":
        break
```

---

## Q&A

**Q: Will an operation fail if it hits the rate limit?**
No. The operation suspends and waits until capacity is available. The only failure paths are the existing circuit breaker (5 consecutive hard failures) and the operation timeout (`TIMEOUT_DEFAULT`).

**Q: Why is `DEFAULT_ESTIMATED_TOKENS=20000` rather than actual token count?**
Because Sonnet 4.5 uses a 5× output token burndown rate. A call with 10,000 input tokens and 2,000 output tokens costs 10,000 + 2,000×5 = 20,000 tokens from your TPM quota. Using raw token counts would cause the TPM bucket to undercount and allow the real AWS quota to be exceeded.

**Q: What about the large upfront `max_tokens=64000` reservation?**
AWS reserves `input_tokens + max_tokens` at request start and refunds the unused portion at the end. This is temporary and does not represent sustained quota consumption. The rate limiter does not model this reservation — it tracks the effective final cost instead. With 5,000,000 TPM and only 5 concurrent calls at ~74,000 tokens each, the upfront reservation is never a bottleneck.

**Q: Does the rate limiter affect inbound API requests?**
No. The existing `slowapi` rate limiter in `resilience.py` handles inbound throttling. This rate limiter is exclusively for outbound LLM calls.

**Q: How do I disable rate limiting for development?**
Set `LLM_RATE_LIMITER_ENABLED=false` in your `.env` file.

**Q: How do I switch from Sonnet 4.5 to a different model?**
Update the `BEDROCK_RATE_LIMITER_*` overrides to match the new model's quotas. Check the new model's burndown rate — models older than 3.7 use 1× (not 5×), which would lower `DEFAULT_ESTIMATED_TOKENS` back toward raw token counts.

**Q: What if Bedrock and Portkey have different quota tiers?**
Use per-provider overrides. The Bedrock overrides (`BEDROCK_RATE_LIMITER_*`) are already enabled in each profile. Set `PORTKEY_RATE_LIMITER_*` separately if Portkey has different limits.
