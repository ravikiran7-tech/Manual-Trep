# Docker Compose Usage Guide

## Environment Variable Configuration

The `docker-compose.yml` file now dynamically loads all configuration values from the `.env` file.

### Setup Steps

1. **Copy the example environment file:**
   ```bash
   cp .env.example .env
   ```

2. **Edit `.env` with your actual values:**
   ```bash
   nano .env  # or use your preferred editor
   ```

3. **Start the services:**
   ```bash
   docker-compose up -d
   ```

### How It Works

- All environment variables use the `${VAR_NAME:-default}` syntax
- Values in `.env` override the defaults in `docker-compose.yml`
- If a variable is not set in `.env`, the default value is used

### Environment Variables

The following categories of variables are now configurable via `.env`:

#### Application Settings
- `APP_NAME` - Application name (default: studio-ai-engine-python)
- `APP_VERSION` - Application version (default: 1.0.0)
- `DEBUG` - Debug mode (default: false)
- `LOG_LEVEL` - Logging level (default: INFO)

#### AWS Configuration
- `AWS_REGION` - AWS region (default: us-east-1)
- `AWS_PROFILE` - AWS profile (default: default)
- `AWS_ACCESS_KEY_ID` - AWS access key (no default)
- `AWS_SECRET_ACCESS_KEY` - AWS secret key (no default)

#### Bedrock Models
- `BEDROCK_MODEL_ID_SONNET` - Sonnet model ID
- `BEDROCK_MODEL_ID_HAIKU` - Haiku model ID
- `BEDROCK_DEFAULT_MODEL` - Default model to use
- `BEDROCK_MAX_TOKENS` - Maximum tokens (default: 64000)
- `BEDROCK_TEMPERATURE` - Temperature setting (default: 0.7)

#### Studio Core
- `STUDIO_CORE_URL` - Studio Core URL
- `COMPASS_COMPONENT` - Compass component name

#### Portkey
- `PORTKEY_BASE_URL` - Portkey API base URL

#### Workspace & Directories
- `CLAUDE_WORKSPACE` - Workspace directory
- `OUTPUT_DIR` - Output directory

#### Security
- `ENCRYPTION_KEY` - Encryption key (required)
- `SECURITY_VALIDATION_ENABLED` - Enable security validation
- `BASH_COMMAND_VALIDATION_ENABLED` - Enable bash command validation
- `PATH_TRAVERSAL_PROTECTION_ENABLED` - Enable path traversal protection

#### Timeouts
- `TIMEOUT_DEFAULT` - Default timeout in seconds
- `TIMEOUT_UPGRADE` - Upgrade timeout in seconds
- `TIMEOUT_SCHEMA_MODERNIZATION` - Schema modernization timeout
- `TIMEOUT_BUILD_VALIDATION` - Build validation timeout
- `TIMEOUT_SLEEP_TEST_MINUTES` - Sleep test timeout in minutes

#### Resilience
- `RESILIENCE_RETRY_MAX_ATTEMPTS` - Max retry attempts
- `RESILIENCE_RETRY_WAIT_MIN` - Min wait between retries
- `RESILIENCE_RETRY_WAIT_MAX` - Max wait between retries
- `RESILIENCE_RETRY_MULTIPLIER` - Retry wait multiplier
- `RESILIENCE_CIRCUIT_BREAKER_FAIL_THRESHOLD` - Circuit breaker threshold
- `RESILIENCE_CIRCUIT_BREAKER_TIMEOUT` - Circuit breaker timeout
- `RESILIENCE_RATE_LIMIT_PER_MINUTE` - Rate limit per minute
- `RESILIENCE_RATE_LIMIT_PER_HOUR` - Rate limit per hour

#### CORS
- `CORS_ALLOW_ORIGINS` - Allowed origins
- `CORS_ALLOW_CREDENTIALS` - Allow credentials
- `CORS_ALLOW_METHODS` - Allowed HTTP methods
- `CORS_ALLOW_HEADERS` - Allowed headers

### Validation

To validate your docker-compose configuration:

```bash
docker-compose config
```

This will show the resolved configuration with all environment variables substituted.

### Troubleshooting

**Issue: Variables not being loaded**
- Make sure `.env` file exists in the same directory as `docker-compose.yml`
- Check for syntax errors in `.env` (no spaces around `=`)
- Restart Docker Compose: `docker-compose down && docker-compose up -d`

**Issue: Default values being used instead of .env values**
- Verify variable names match exactly (case-sensitive)
- Remove quotes around values in `.env` unless they contain spaces
- Check for trailing spaces in variable names or values

### Security Notes

⚠️ **Important:**
- Never commit `.env` to version control (it's in `.gitignore`)
- Use `.env.example` as a template for documentation
- Rotate sensitive credentials regularly
- Use proper secrets management in production
