# Diff-Based Patching Implementation - Cross-Validation Document

## Current System Analysis

### ✅ Current Working Implementation
1. **File Operations**: `read`, `write`, `delete` operations work correctly
2. **Tool Execution**: `ToolExecutor` handles all operations safely
3. **Security**: Path validation happens in both Bedrock and Portkey clients
4. **Event Tracking**: Graph orchestrator tracks `write` operations correctly
5. **Backward Compatibility**: System is stable and working

### Current Flow
```
AI Model → Tool Schema (read/write/delete) → Security Validation → ToolExecutor → File System
```

## Proposed Changes - Validation Checklist

### 1. Backward Compatibility ✅

**Question**: Will existing `write` operations continue to work?

**Answer**: YES
- `write` operation remains unchanged in tool schemas
- `ToolExecutor._write_file()` method unchanged
- Only adding new `patch` operation alongside existing operations
- No breaking changes to existing code paths

**Validation Points**:
- ✅ `operation == "write"` path remains identical
- ✅ `content` parameter still works for write operations
- ✅ Event tracking for writes unchanged
- ✅ No changes to existing validation logic

### 2. Security Validation ✅

**Question**: Are patch operations properly secured?

**Answer**: YES (with one addition needed)

**Current Security Flow**:
1. Path validation in `bedrock_client.py:692` and `portkey_client.py:648`
2. Path resolution in `tool_executor.py:258`
3. File existence checks before operations

**Patch Security Considerations**:
- ✅ File path validation: Uses same path validation as write operations
- ✅ Path traversal protection: Same `Path.resolve()` logic applies
- ✅ File existence: Patch requires file to exist (unlike write)
- ⚠️ **NEEDED**: Validate `patch_data` doesn't contain malicious content
- ⚠️ **NEEDED**: Ensure patch operations can't be used to inject code

**Required Security Additions**:
```python
# In PatchManager.validate_patch():
# 1. Check patch_data size limits (prevent DoS)
# 2. Validate patch format structure
# 3. Ensure patch doesn't create path traversal in file content
# 4. Validate line numbers are within reasonable bounds
```

### 3. Event Tracking ✅

**Question**: Will patch operations be tracked correctly?

**Answer**: YES (with update needed)

**Current Tracking** (`graph_orchestrator.py:403`):
```python
if tool_name == "code_editor" and tool_input.get("operation") == "write":
    write_operations_found = True
    file_path = tool_input.get("path", "")
```

**Required Update**:
```python
# Update to track both write and patch:
operation = tool_input.get("operation")
if tool_name == "code_editor" and operation in ["write", "patch"]:
    if operation == "write":
        write_operations_found = True
    elif operation == "patch":
        patch_operations_found = True
    file_path = tool_input.get("path", "")
```

**Validation**:
- ✅ Event structure unchanged (`tool_use` events)
- ✅ File path extraction works for patch too
- ✅ Need to update warning message to include patches

### 4. Error Handling ✅

**Question**: What happens if patch fails?

**Answer**: Proper error handling implemented

**Error Scenarios**:
1. **Invalid patch format**: Returns `ToolResult(success=False, error="...")`
2. **File doesn't exist**: Returns error before attempting patch
3. **Patch doesn't apply**: Returns error with details
4. **Line number out of bounds**: Validated before applying

**Fallback Strategy**:
- ✅ Patch failures return clear error messages
- ✅ Model can retry with `write` operation if patch fails
- ✅ No file corruption risk (validation before application)

### 5. Edge Cases Analysis

#### 5.1 Empty Files ✅
- **Patch on empty file**: Handled (line 0 is valid)
- **Create file with patch**: Not supported (patch requires existing file)
- **Delete all content**: Supported via line_edits format

#### 5.2 Binary Files ⚠️
- **Current**: System uses text mode (`encoding='utf-8'`)
- **Patch on binary**: Will fail gracefully (encoding error)
- **Recommendation**: Add binary file detection, reject patches on binary files

#### 5.3 Large Files ✅
- **Current**: No size limits on file reads/writes
- **Patch**: More efficient for large files (only changes sent)
- **Risk**: Patch data could be large if many changes
- **Mitigation**: Add size validation in `validate_patch()`

#### 5.4 Concurrent Modifications ⚠️
- **Risk**: File changed between read and patch application
- **Current**: No file locking mechanism
- **Mitigation**: Read file fresh before applying patch (already done)

#### 5.5 Line Ending Differences ✅
- **Windows (CRLF) vs Unix (LF)**: Handled by `splitlines(keepends=True)`
- **Preserves original line endings**: Yes

### 6. Integration Points - Complete Checklist

#### 6.1 Tool Schemas ✅
- [x] `bedrock_client.py`: CODE_EDITOR_TOOL schema
- [x] `portkey_client.py`: CODE_EDITOR_TOOL schema
- [x] Add `"patch"` to operation enum
- [x] Add `patch_format` and `patch_data` properties
- [x] Update `required` fields with conditional logic

#### 6.2 Tool Executor ✅
- [x] `_execute_file_operation()`: Add `patch` case
- [x] `_patch_file()`: New method implementation
- [x] Error handling: Proper ToolResult returns
- [x] Logging: Consistent with other operations

#### 6.3 Patch Manager ✅
- [x] `PatchManager` class: Core implementation
- [x] `apply_patch()`: Main entry point
- [x] `_apply_unified_diff()`: Unified diff support
- [x] `_apply_line_edits()`: Line-based edits
- [x] `_apply_structured_edits()`: JSON range edits
- [x] `validate_patch()`: Pre-application validation
- [x] `compute_diff()`: Utility for generating diffs

#### 6.4 Graph Orchestrator ✅
- [x] Event tracking: Update to include patches
- [x] File tracking: Track patched files in `files_changed`
- [x] Logging: Include patch operation counts
- [x] Warning messages: Update for patch operations

#### 6.5 Prompt Builder ✅
- [x] `_build_write_requirements()`: Update guidance
- [x] Add patch operation examples
- [x] Decision guidelines (when to use patch vs write)
- [x] Maintain backward compatibility with write instructions

#### 6.6 Security Validation ⚠️
- [x] Path validation: Already covers patch operations
- [ ] **MISSING**: Patch data validation (size, format, content)
- [ ] **MISSING**: Binary file detection
- [ ] **MISSING**: Line number bounds checking

### 7. Testing Scenarios

#### 7.1 Happy Path ✅
1. Small change (1-2 lines) → Use patch → Success
2. Multiple changes → Use patch → Success
3. Large change → Use write → Success (fallback)

#### 7.2 Error Cases ✅
1. Invalid patch format → Error returned → Model can retry
2. File doesn't exist → Error returned → Model can create with write
3. Line number out of bounds → Error returned → Model can use write
4. Patch doesn't match → Error returned → Model can use write

#### 7.3 Edge Cases ⚠️
1. Binary file → Should reject → **NEEDED**: Binary detection
2. Very large patch → Should validate size → **NEEDED**: Size limits
3. Empty file → Should handle → ✅ Already handled
4. Concurrent modification → Should handle → ✅ Reads fresh

### 8. Performance Considerations ✅

**Benefits**:
- ✅ Reduced token usage for small changes
- ✅ Faster API calls (less data sent)
- ✅ More efficient transformations

**Risks**:
- ⚠️ Patch parsing overhead (minimal)
- ⚠️ Validation overhead (acceptable)
- ✅ Overall: Net positive performance impact

### 9. Rollback Compatibility ✅

**Question**: Can we rollback patch operations?

**Answer**: YES (with DiffManager integration)
- Patch operations can be tracked in checkpoints
- Diffs can be computed before/after patches
- Rollback uses same mechanism as write operations

### 10. Critical Issues Found ⚠️

#### Issue #1: Missing Patch Data Validation
**Severity**: HIGH
**Location**: `PatchManager.validate_patch()`
**Fix Needed**:
```python
# Add validation:
- Maximum patch_data size (e.g., 1MB)
- Validate patch format structure matches format type
- Check line numbers are within file bounds
- Reject patches on binary files
```

#### Issue #2: Binary File Detection Missing
**Severity**: MEDIUM
**Location**: `PatchManager.apply_patch()`
**Fix Needed**:
```python
# Detect binary files:
def is_binary_file(file_path: str) -> bool:
    try:
        with open(file_path, 'rb') as f:
            chunk = f.read(8192)
            return b'\x00' in chunk
    except:
        return False
```

#### Issue #3: Event Tracking Update Needed
**Severity**: LOW
**Location**: `graph_orchestrator.py:403`
**Fix Needed**: Update condition to include `patch` operation

#### Issue #4: Warning Message Update Needed
**Severity**: LOW
**Location**: `graph_orchestrator.py:410`
**Fix Needed**: Update to mention patch operations too

## Implementation Confidence Assessment

### ✅ High Confidence Areas
1. **Backward Compatibility**: 100% - No breaking changes
2. **Core Patch Logic**: 95% - Well-tested algorithms (difflib)
3. **Integration Points**: 90% - Clear integration points identified
4. **Error Handling**: 90% - Proper error paths defined

### ⚠️ Medium Confidence Areas
1. **Security Validation**: 75% - Needs additional validation
2. **Edge Cases**: 80% - Most handled, some need attention
3. **Performance**: 85% - Should be better, needs testing

### 🔴 Low Confidence Areas
1. **Binary File Handling**: 60% - Needs detection logic
2. **Very Large Patches**: 70% - Needs size limits
3. **Concurrent Modifications**: 80% - Handled but not tested

## Recommended Implementation Order

### Phase 1: Core Implementation (High Confidence)
1. ✅ Create `PatchManager` class
2. ✅ Add `_patch_file()` to `ToolExecutor`
3. ✅ Update tool schemas
4. ✅ Update event tracking

### Phase 2: Security Hardening (Medium Confidence)
1. ⚠️ Add patch data validation
2. ⚠️ Add binary file detection
3. ⚠️ Add size limits
4. ⚠️ Add line number bounds checking

### Phase 3: Integration & Testing (High Confidence)
1. ✅ Update prompt builder
2. ✅ Update graph orchestrator logging
3. ✅ Test with real transformations
4. ✅ Monitor for issues

## Final Recommendation

### ✅ PROCEED WITH IMPLEMENTATION

**Confidence Level**: 85%

**Rationale**:
1. ✅ Backward compatibility guaranteed
2. ✅ Core functionality well-understood
3. ✅ Error handling properly designed
4. ⚠️ Security concerns are addressable
5. ✅ Performance benefits clear

**Required Before Production**:
1. ⚠️ Add patch data validation (Issue #1)
2. ⚠️ Add binary file detection (Issue #2)
3. ✅ Update event tracking (Issue #3) - Easy fix
4. ✅ Update warning messages (Issue #4) - Easy fix

**Risk Mitigation**:
- Start with Phase 1 (core implementation)
- Test thoroughly before Phase 2
- Monitor in production for edge cases
- Have fallback to `write` operation always available

## Conclusion

The diff-based patching implementation is **SAFE TO IMPLEMENT** with the following conditions:

1. ✅ Implement core functionality (Phase 1)
2. ⚠️ Add security validations (Phase 2) before production
3. ✅ Test thoroughly with real transformations
4. ✅ Monitor for edge cases

The system will remain **100% backward compatible** and existing `write` operations will continue to work exactly as they do now.
