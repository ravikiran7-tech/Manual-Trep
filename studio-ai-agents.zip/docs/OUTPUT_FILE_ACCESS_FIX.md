# Output File Access - Issue and Resolution

## Date: 2026-01-19

## Problem

Output files from API calls were not accessible on the host machine. They only existed inside the Docker container at `/tmp/claude-outputs/`, making it difficult for users to access the analysis results.

### Example
```bash
# API returns this path:
"outputFilePath": "/tmp/claude-outputs/versionUpgrade/1234/analysis-stream.json"

# But trying to access it on host:
$ cat /tmp/claude-outputs/versionUpgrade/1234/analysis-stream.json
# Result: File not found (it's inside the container!)
```

## Root Cause

The `/tmp/claude-outputs/` directory was only inside the Docker container's filesystem, not mounted to the host.

## Solution

### 1. Added Volume Mount

**File**: `docker-compose.yml`

Added volume mount to map container output directory to host:
```yaml
volumes:
  # Output directory - mount to host for easy access
  - ./outputs:/tmp/claude-outputs
```

### 2. Fixed Permissions

The mounted directory needed write permissions for the container user `studioai`:
```bash
chmod -R 777 outputs/
```

### 3. Restarted Container

```bash
docker-compose down
docker-compose up -d
```

## Verification

### Test Command
```bash
curl --location 'http://localhost:8000/api/claude/executeCommandWithPrompt' \
  --header 'Content-Type: application/json' \
  --data '{
    "analysisId": "test-001",
    "projectPath": "/test-code/mini-java-app",
    "operation": "analysis",
    "prompt": "/test-code/_claude/upgrade-analysis-prompt.txt"
  }'
```

### Response
```json
{
  "status": "success",
  "message": "Analysis completed successfully",
  "exitCode": 0,
  "output": "/tmp/claude-outputs/versionUpgrade/test-001/analysis-stream.json",
  "error": null,
  "outputFilePath": "/tmp/claude-outputs/versionUpgrade/test-001/analysis-stream.json"
}
```

### File Access on Host
```bash
# File now exists on host!
$ ls -lh outputs/versionUpgrade/test-001/
-rw-r--r-- 1 nats systemd-journal 2.0K Jan 19 13:57 analysis-stream.json

# View content
$ cat outputs/versionUpgrade/test-001/analysis-stream.json | jq . | head -20
```

## Usage

### Accessing Output Files

#### 1. Direct Read
```bash
cat outputs/versionUpgrade/YOUR_ANALYSIS_ID/analysis-stream.json
```

#### 2. Pretty Print with jq
```bash
cat outputs/versionUpgrade/YOUR_ANALYSIS_ID/analysis-stream.json | jq .
```

#### 3. Open in Editor
```bash
code outputs/versionUpgrade/YOUR_ANALYSIS_ID/analysis-stream.json
# or
vim outputs/versionUpgrade/YOUR_ANALYSIS_ID/analysis-stream.json
```

#### 4. List All Outputs
```bash
ls -R outputs/
```

### File Structure

```
outputs/
├── versionUpgrade/
│   ├── analysis-001/
│   │   └── analysis-stream.json
│   ├── fix-upgrade-002/
│   │   └── fix-stream.json
├── validation/
│   ├── build-001/
│   │   └── build-stream.json
├── cloudreadiness/
│   └── ...
└── ...
```

## For Old Files (Created Before Mount)

Files created before the volume mount was added are still inside the container. To access them:

```bash
# Copy from container to host
docker cp studio-ai-engine-python:/tmp/claude-outputs/versionUpgrade/1234/analysis-stream.json ./1234-output.json

# View the copied file
cat ./1234-output.json | jq .
```

## Path Mapping

| Location | Path |
|----------|------|
| **Container** | `/tmp/claude-outputs/versionUpgrade/...` |
| **Host** | `./outputs/versionUpgrade/...` |
| **API Response** | `/tmp/claude-outputs/versionUpgrade/...` (container path) |

## Important Notes

1. **All new outputs** are automatically saved to `./outputs/` on the host
2. **Permissions**: The `outputs/` directory has `777` permissions for container write access
3. **Old files**: Files created before the mount still need to be copied from the container
4. **Cleanup**: You can safely delete files from `./outputs/` - they won't affect the container
5. **Backup**: Consider backing up `./outputs/` directory if you need to preserve analysis results

## Files Modified

1. `docker-compose.yml`
   - Added volume mount: `- ./outputs:/tmp/claude-outputs`

2. Host filesystem
   - Created `outputs/` directory
   - Set permissions: `chmod 777 outputs/`

## Status

✅ **RESOLVED** - All output files are now accessible on the host machine at `./outputs/`
