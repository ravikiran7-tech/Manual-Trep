#!/bin/bash
# ============================================================================
# Studio AI Engine - Docker Entrypoint Script
# ============================================================================
# This script is executed when the Docker container starts.
# It performs initialization and validation before starting the application.
# ============================================================================

set -e  # Exit on error

echo "============================================"
echo "Studio AI Engine - Python Implementation"
echo "Version: ${APP_VERSION:-1.0.0}"
echo "============================================"
echo ""

# ============================================================================
# Environment Validation
# ============================================================================
echo "Validating environment..."

# Check required environment variables
REQUIRED_VARS=(
    "STUDIO_CORE_URL"
    "ENCRYPTION_KEY"
)

for var in "${REQUIRED_VARS[@]}"; do
    if [ -z "${!var}" ]; then
        echo "ERROR: Required environment variable $var is not set"
        echo "Please set $var in your environment or .env file"
        exit 1
    fi
done

echo "✓ Required environment variables validated"

# ============================================================================
# Workspace Initialization
# ============================================================================
echo ""
echo "Initializing workspace..."

# Create workspace directories if they don't exist (all outputs go to workspace)
WORKSPACE_DIRS=(
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/versionUpgrade"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/validation"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/cloudreadiness"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/db-code-modernize"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/schema-modernization"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/containerization"
    "${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}/dotnet-validation"
)

for dir in "${WORKSPACE_DIRS[@]}"; do
    mkdir -p "$dir" 2>/dev/null || true
done

echo "✓ Workspace directories created"

# ============================================================================
# Configuration Display
# ============================================================================
echo ""
echo "Configuration:"
echo "  Environment: ${DEBUG:-false}"
echo "  Log Level: ${LOG_LEVEL:-INFO}"
echo "  AWS Region: ${AWS_REGION:-us-east-1}"
echo "  Bedrock Model: ${BEDROCK_DEFAULT_MODEL:-anthropic.claude-3-sonnet-20240229-v1:0}"
echo "  Studio Core: ${STUDIO_CORE_URL}"
echo "  Workspace: ${CLAUDE_WORKSPACE:-/studio-app/claude-workspace}"
echo ""

# ============================================================================
# AWS Credentials Check (Optional)
# ============================================================================
if [ -n "$AWS_ACCESS_KEY_ID" ]; then
    echo "✓ Using explicit AWS credentials"
elif [ -d "$HOME/.aws" ]; then
    echo "✓ Using AWS profile: ${AWS_PROFILE:-default}"
else
    echo "⚠ No AWS credentials found - relying on IAM role"
fi

# ============================================================================
# Health Check
# ============================================================================
echo ""
echo "Application health check available at:"
echo "  http://localhost:8000/health (Docker/ALB health checks)"
echo "  http://localhost:8000/studio-ai-agents/health (With context path)"
echo ""
echo "API Documentation available at:"
echo "  http://localhost:8000/studio-ai-agents/docs (Swagger UI)"
echo ""

# ============================================================================
# Execute Main Command
# ============================================================================
echo "Starting Studio AI Engine..."
echo "============================================"
echo ""

# Execute the command passed to the container
exec "$@"
