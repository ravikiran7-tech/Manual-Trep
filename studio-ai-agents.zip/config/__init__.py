"""
Configuration package for Studio AI Engine.

This package contains configuration files and utilities for application setup.
"""
