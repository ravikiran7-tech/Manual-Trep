"""
FastAPI dependency injection.

Provides reusable dependencies for API endpoints including:
- Service instances
- Provider factories
- Authentication
- Rate limiting
"""
from typing import Optional

from fastapi import Request

from app.services.provider_factory import ProviderFactory, get_provider_factory
from app.clients.compass_client import CompassClient, get_compass_client
from app.core.config import get_settings


settings = get_settings()


# ============================================================================
# SERVICE DEPENDENCIES
# ============================================================================

def get_provider_factory_dependency() -> ProviderFactory:
    """
    Get ProviderFactory instance for dependency injection.

    Returns:
        ProviderFactory instance
    """
    return get_provider_factory()


def get_compass_client_dependency() -> CompassClient:
    """
    Get CompassClient instance for dependency injection.

    Returns:
        CompassClient instance
    """
    return get_compass_client()


async def get_claude_service():
    """
    Get ClaudeService instance (will be implemented).

    Returns:
        ClaudeService instance
    """
    # Will be implemented when ClaudeService is created
    from app.services.claude_service import get_claude_service as get_svc
    return get_svc()


async def get_build_compilation_service():
    """
    Get BuildCompilationService instance (will be implemented).

    Returns:
        BuildCompilationService instance
    """
    # Will be implemented when BuildCompilationService is created
    from app.services.build_compilation_service import get_build_compilation_service as get_svc
    return get_svc()


async def get_stream_visualization_service():
    """
    Get StreamVisualizationService instance (will be implemented).

    Returns:
        StreamVisualizationService instance
    """
    # Will be implemented when StreamVisualizationService is created
    from app.services.stream_visualization_service import get_stream_visualization_service as get_svc
    return get_svc()


# ============================================================================
# RATE LIMITING
# ============================================================================

def get_request_identifier(request: Request) -> str:
    """
    Get unique identifier for rate limiting.

    Uses client IP address as identifier.

    Args:
        request: FastAPI request

    Returns:
        Client IP address
    """
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0]
    return request.client.host if request.client else "unknown"
