"""
Claude API endpoints.

REST endpoints for Claude CLI operations including command execution,
schema modernization, assessment-rules batch generation, and health checks.

Equivalent to Java's ClaudeCliController.
"""
import asyncio
import json
import logging
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.responses import JSONResponse

from app.models.requests import (
    ClaudeCliRequest,
    SchemaModernizationRequest,
    AssessmentRulesBatchRequest,
)
from app.models.responses import (
    ClaudeCliResponse,
    SchemaModernizationResponse,
    AssessmentRulesBatchResponse,
)
from app.services.claude_service import ClaudeService, get_claude_service
from app.core.exceptions import ValidationError
from app.core.config import get_settings


logger = logging.getLogger(__name__)
settings = get_settings()

# Create router with prefix and tags
router = APIRouter(
    prefix="/api/claude",
    tags=["claude"],
    responses={
        500: {"description": "Internal server error"},
        400: {"description": "Bad request"}
    }
)


@router.get(
    "/health",
    summary="Health Check",
    description="Check if Claude API service is running",
    response_description="Service status message",
    status_code=status.HTTP_200_OK
)
async def health_check() -> str:
    """
    Health check endpoint.

    Returns:
        Simple status message confirming service is running

    Example:
        GET /api/claude/health
        Response: "Claude CLI API is running"
    """
    logger.info("Health check endpoint called")
    return "Claude CLI API is running"


@router.get(
    "/sleep-test",
    summary="Sleep Test",
    description="Test endpoint that sleeps for configured duration (for testing timeouts)",
    response_description="Sleep completion message or error",
    status_code=status.HTTP_200_OK
)
async def sleep_test() -> str:
    """
    Sleep test endpoint for testing timeout behavior.

    Sleeps for duration configured in settings.timeouts.sleep_test_minutes.
    Useful for testing long-running operations and timeout handling.

    Returns:
        Completion message after sleep

    Raises:
        HTTPException: 500 if sleep is interrupted or fails

    Example:
        GET /api/claude/sleep-test
        Response: "Sleep test completed successfully after 15 minutes"
    """
    try:
        sleep_minutes = settings.timeouts.sleep_test_minutes
        sleep_seconds = sleep_minutes * 60

        logger.info(f"Sleep test started: will sleep for {sleep_minutes} minutes ({sleep_seconds}s)")

        # Async sleep
        await asyncio.sleep(sleep_seconds)

        message = f"Sleep test completed successfully after {sleep_minutes} minutes"
        logger.info(message)

        return message

    except asyncio.CancelledError:
        error_msg = "Sleep test was cancelled/interrupted"
        logger.error(error_msg)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_msg
        )
    except Exception as e:
        error_msg = f"Sleep test failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_msg
        )


@router.post(
    "/executeCommandWithPrompt",
    summary="Execute Claude Command",
    description="Execute Claude CLI command with prompt for various operations (analysis, fix-upgrade, build-compilation, etc.)",
    response_description="Execution result with output file path",
    status_code=status.HTTP_200_OK,
    response_model=ClaudeCliResponse
)
async def execute_command_with_prompt(
    request: ClaudeCliRequest,
    claude_service: ClaudeService = Depends(get_claude_service)
) -> ClaudeCliResponse:
    """
    Execute Claude command with prompt.

    Supports all 11 operation types:
    - analysis: Version upgrade analysis
    - fix-upgrade: Apply upgrade fixes
    - build-compilation: Java build validation
    - test-execution: Run tests
    - cloudreadiness-analysis: Cloud readiness assessment
    - cloudreadiness-fix: Cloud migration fixes
    - db-code-modernize-analysis: Database code analysis
    - db-code-modernize-fix: Database code fixes
    - schema-modernization: Database schema conversion
    - dotnet-build-compilation: .NET build validation
    - dotnet-test-execution: .NET test execution

    Args:
        request: ClaudeCliRequest with operation parameters
        claude_service: Injected ClaudeService instance

    Returns:
        ClaudeCliResponse with execution results and output file path

    Raises:
        HTTPException: 400 for validation errors, 500 for execution failures

    Example:
        POST /api/claude/executeCommandWithPrompt
        {
          "prompt": "/path/to/prompt.txt",
          "project_path": "/projects/my-app",
          "analysis_id": "analysis-001",
          "operation": "analysis",
          "platform": "linux"
        }

        Response:
        {
          "status": "success",
          "message": "Operation completed successfully",
          "exitCode": 0,
          "output": "/studio-app/claude-workspace/versionUpgrade/analysis-001/_claude/analysis-stream.json",
          "error": null,
          "outputFilePath": "/studio-app/claude-workspace/versionUpgrade/analysis-001/_claude/analysis-stream.json"
        }
    """
    logger.info(
        f"Execute command endpoint called: operation={request.operation}, "
        f"analysisId={request.analysis_id}, platform={request.platform}"
    )

    try:
        # Execute command via service
        response = await claude_service.execute_non_interactive_command(request)

        # Log result
        if response.status == "success":
            logger.info(
                f"Command executed successfully: operation={request.operation}, "
                f"outputFile={response.output_file_path}"
            )
        else:
            logger.warning(
                f"Command execution failed: operation={request.operation}, "
                f"error={response.error}"
            )

        return response

    except ValidationError as e:
        # Validation errors return 400 Bad Request
        error_msg = f"Validation error: {e.message}"
        logger.error(error_msg)

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": error_msg,
                "field": e.field
            }
        )

    except TimeoutError as e:
        # Timeout errors return 504 Gateway Timeout
        error_msg = f"Operation timed out: {str(e)}"
        logger.error(error_msg)

        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail={
                "status": "error",
                "message": error_msg
            }
        )

    except Exception as e:
        # All other errors return 500 Internal Server Error
        error_msg = f"Command execution failed: {str(e)}"
        logger.error(error_msg, exc_info=True)

        # Return error response matching Java's error format
        return ClaudeCliResponse(
            status="error",
            message=error_msg,
            exit_code=-1,
            output="",
            error=str(e),
            output_file_path=""
        )


@router.post(
    "/schema-modernization",
    summary="Schema Modernization",
    description="Execute database schema modernization (e.g., Oracle to PostgreSQL conversion)",
    response_description="Schema modernization result with converted DDL",
    status_code=status.HTTP_200_OK,
    response_model=SchemaModernizationResponse
)
async def execute_schema_modernization(
    request: SchemaModernizationRequest,
    claude_service: ClaudeService = Depends(get_claude_service)
) -> SchemaModernizationResponse:
    """
    Execute database schema modernization.

    Converts database schemas between different database types (Oracle, PostgreSQL,
    MySQL, SQL Server, etc.).

    Supports two execution modes:
    1. File-access mode: AI reads schema file directly (sourceSchemaPath provided)
    2. Content-in-prompt mode: Schema content in prompt (prompt provided)

    Args:
        request: SchemaModernizationRequest with conversion parameters
        claude_service: Injected ClaudeService instance

    Returns:
        SchemaModernizationResponse with converted schema DDL

    Raises:
        HTTPException: 400 for validation errors, 500 for execution failures

    Example:
        POST /api/claude/schema-modernization
        {
          "analysis_id": "schema-001",
          "source_db_type": "Oracle",
          "target_db_type": "PostgreSQL",
          "source_schema_path": "/schemas/oracle_schema.sql",
          "project_path": "/projects/db-migration"
        }

        Response:
        {
          "status": "success",
          "message": "Schema converted from Oracle to PostgreSQL",
          "outputFilePath": "/studio-app/claude-workspace/schema-modernization/schema-001/schema-modernization-output.sql",
          "content": "CREATE TABLE users (...)",
          "analysisId": "schema-001",
          "sourceDbType": "Oracle",
          "targetDbType": "PostgreSQL"
        }
    """
    logger.info(
        f"Schema modernization endpoint called: analysisId={request.analysis_id}, "
        f"{request.source_db_type} → {request.target_db_type}"
    )

    try:
        # Execute schema modernization via service
        response = await claude_service.execute_schema_modernization(request)

        # Log result
        if response.status == "success":
            logger.info(
                f"Schema modernization completed: analysisId={request.analysis_id}, "
                f"outputFile={response.output_file_path}"
            )
        else:
            logger.warning(
                f"Schema modernization failed: analysisId={request.analysis_id}, "
                f"error={response.error_details}"
            )

        # Return error response with 500 status if operation failed
        if response.status == "error":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=response.model_dump(by_alias=True)
            )

        return response

    except ValidationError as e:
        # Validation errors return 400 Bad Request
        error_msg = f"Validation error: {e.message}"
        logger.error(error_msg)

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": error_msg,
                "field": e.field,
                "analysisId": request.analysis_id
            }
        )

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        # All other errors return 500 Internal Server Error
        error_msg = f"Schema modernization failed: {str(e)}"
        logger.error(error_msg, exc_info=True)

        # Return error response
        return SchemaModernizationResponse(
            status="error",
            message=error_msg,
            error_details=error_msg,
            analysis_id=request.analysis_id
        )


@router.post(
    "/assessment-rules-batch",
    summary="Assessment rules batch",
    description=(
        "Generate full assessment-rule JSON objects for a batch of catalog rules. "
        "Each rule includes ruleId, domain, language, name, and description."
    ),
    response_description="Parsed assessment rules array or error details",
    status_code=status.HTTP_200_OK,
    response_model=AssessmentRulesBatchResponse,
)
async def execute_assessment_rules_batch(
    request: AssessmentRulesBatchRequest,
    claude_service: ClaudeService = Depends(get_claude_service),
) -> AssessmentRulesBatchResponse:
    """
    Expand catalog rules into assessment-rule schema objects via agentic AI invocation.

    Input: analysisId and a list of rules; each rule has ruleId, domain, language,
    name, and description (JSON key ``language``).

    Output: JSON array of assessment objects in ``rules`` when successful; stream
    artifact path in ``outputFilePath``.
    """
    logger.info(
        "Assessment rules batch endpoint: analysisId=%s, rules=%s",
        request.analysis_id,
        len(request.rules),
    )
    try:
        response = await claude_service.execute_assessment_rules_batch(request)
        response_payload = response.model_dump(by_alias=True, mode="json")
        # Single %s avoids LogRecord %-format issues when JSON contains "%" sequences.
        response_body = json.dumps(response_payload, ensure_ascii=False)
        prefix = "[assessment-rules-batch] response before HTTP return:\n"
        print(prefix + response_body, flush=True)
        logger.info("%s", prefix.strip() + " " + response_body)
        if response.status == "error":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=response_payload,
            )
        return response
    except ValidationError as e:
        error_msg = f"Validation error: {e.message}"
        logger.error(error_msg)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": error_msg,
                "field": e.field,
                "analysisId": request.analysis_id,
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        error_msg = f"Assessment rules batch failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return AssessmentRulesBatchResponse(
            status="error",
            message=error_msg,
            analysis_id=request.analysis_id,
            rule_count_expected=len(request.rules),
            error_details=str(e),
        )


# ============================================================================
# ERROR HANDLERS
# ============================================================================
# Note: Exception handlers are defined in app/main.py at the application level
# Routers cannot have exception handlers - they must be registered with the app
