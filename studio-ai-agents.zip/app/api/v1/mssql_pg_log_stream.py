"""SSE tail for MSSQL → PostgreSQL schema jobs (``mssql_pg.hooks``).

The UI reads logs from ``/api/oracle-pg-transformation/jobs/{jobId}/logs/stream``
for every schema job. Oracle writes notify ``oracle_pg.hooks``; MSSQL writes
notify ``mssql_pg.hooks``. Reuse the same on-disk ``logs.jsonl`` path but
subscribe with the MSSQL hook registry when ``job_config.json`` marks
``engine: mssql``.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator

from app.services.mssql_pg import hooks as mssql_pg_hooks
from app.services.mssql_pg.progress import is_job_terminal
from app.services.mssql_pg.workspace import logs_path


async def tail_mssql_pg_logs(folder_key: str) -> AsyncIterator[str]:
    """Same behavior as ``oracle_pg_transformation._tail_logs`` but MSSQL hooks + terminal check."""
    path = logs_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_log(entry: dict) -> None:
        await queue.put(json.dumps(entry))

    mssql_pg_hooks.subscribe_logs(folder_key, on_log)

    offset = 0
    try:
        while True:
            if path.exists():
                lines = path.read_text(encoding="utf-8").splitlines()
                while offset < len(lines):
                    line = lines[offset]
                    offset += 1
                    yield f"data: {line}\n\n"

            if is_job_terminal(folder_key):
                return

            try:
                entry_json = await asyncio.wait_for(queue.get(), timeout=2.0)
                yield f"data: {entry_json}\n\n"
            except asyncio.TimeoutError:
                if is_job_terminal(folder_key):
                    return
                yield ": keepalive\n\n"
    finally:
        mssql_pg_hooks.unsubscribe_logs(folder_key)
