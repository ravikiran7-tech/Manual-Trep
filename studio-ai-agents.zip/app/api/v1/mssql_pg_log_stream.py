"""SSE tails for MSSQL → PostgreSQL schema jobs (``mssql_pg.hooks``).

The UI reads both streams from the Oracle URLs:

* ``/api/oracle-pg-transformation/jobs/{jobId}/logs/stream``
* ``/api/oracle-pg-transformation/jobs/{jobId}/stream`` (progressPercent)

Oracle writes notify ``oracle_pg.hooks``. MSSQL writes notify ``mssql_pg.hooks``.
The files are the same shape, but a tail subscribed to the Oracle registry never
wakes when MSSQL publishes, so the progress bar stays at 0% until the finished
``events.jsonl`` is read in one burst. These tails subscribe to the MSSQL registry.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator

from app.services.mssql_pg import hooks as mssql_pg_hooks
from app.services.mssql_pg.progress import is_job_terminal, is_terminal_progress_event
from app.services.mssql_pg.workspace import events_path, logs_path

# Workers do not share the in-process hook registry, so the file is what the
# other worker can see. Poll it often, and when several phases are already
# on disk, pause between them so the checklist can paint each step.
_POLL_SECONDS = 0.25
_PHASE_GAP_SECONDS = 0.35


def _new_lines(path, offset: int) -> tuple[list[str], int]:
    if not path.exists():
        return [], offset
    lines = path.read_text(encoding="utf-8").splitlines()
    return lines[offset:], len(lines)


async def tail_mssql_pg_logs(folder_key: str) -> AsyncIterator[str]:
    """Same behavior as ``oracle_pg_transformation._tail_logs`` but MSSQL hooks + terminal check."""
    path = logs_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_log(entry: dict) -> None:
        await queue.put(json.dumps(entry))

    mssql_pg_hooks.subscribe_logs(folder_key, on_log)

    offset = 0
    try:
        while True:
            fresh, offset = _new_lines(path, offset)
            for line in fresh:
                yield f"data: {line}\n\n"

            if _job_finished(folder_key):
                # The completion line is often written in the same moment the
                # status flips. Read once more so a refresh is not required.
                fresh, offset = _new_lines(path, offset)
                for line in fresh:
                    yield f"data: {line}\n\n"
                return

            try:
                await asyncio.wait_for(queue.get(), timeout=_POLL_SECONDS)
            except asyncio.TimeoutError:
                if _job_finished(folder_key):
                    continue
                yield ": keepalive\n\n"
    finally:
        mssql_pg_hooks.unsubscribe_logs(folder_key)


def _job_finished(folder_key: str) -> bool:
    """Never let a bad progress.json kill the SSE response."""
    try:
        return is_job_terminal(folder_key)
    except Exception:
        return False


def _parse_stream_event(payload: str) -> dict | None:
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return None
    return event if isinstance(event, dict) else None


async def tail_mssql_pg_events(folder_key: str, *, verbose: bool = False) -> AsyncIterator[str]:
    """Push each ``progress_updated`` event as MSSQL publishes it.

    Same loop as Oracle ``_tail_events``, but the queue is the MSSQL hook
    registry. That is what moves ``progressPercent`` on each phase instead of
    delivering every percent at completion.
    """
    path = events_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_event(event: dict) -> None:
        if not mssql_pg_hooks.is_ui_stream_event(event, verbose=verbose):
            return
        await queue.put(json.dumps(event))

    mssql_pg_hooks.subscribe(folder_key, on_event)

    offset = 0
    last_phase: str | None = None
    try:
        while True:
            fresh, offset = _new_lines(path, offset)
            for index, line in enumerate(fresh):
                event: dict | None
                if not verbose:
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(event, dict) or not mssql_pg_hooks.is_ui_stream_event(event, verbose=False):
                        continue
                else:
                    event = _parse_stream_event(line)

                phase = str((event or {}).get("phase") or "")
                if phase and phase != last_phase and index > 0:
                    await asyncio.sleep(_PHASE_GAP_SECONDS)
                if phase:
                    last_phase = phase

                yield f"data: {line}\n\n"
                if event and is_terminal_progress_event(event):
                    return

            if _job_finished(folder_key):
                fresh, offset = _new_lines(path, offset)
                for line in fresh:
                    yield f"data: {line}\n\n"
                return

            try:
                await asyncio.wait_for(queue.get(), timeout=_POLL_SECONDS)
            except asyncio.TimeoutError:
                if _job_finished(folder_key):
                    continue
                yield ": keepalive\n\n"
    finally:
        mssql_pg_hooks.unsubscribe_all(folder_key)
