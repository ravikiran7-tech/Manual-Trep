"""Independent API for Oracle → PostgreSQL agentic schema transformation."""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import AsyncIterator

from fastapi import APIRouter, HTTPException, Path as PathParam, Query, status
from fastapi.responses import FileResponse, StreamingResponse

from app.core.config import get_settings
from app.models.oracle_pg_transformation import (
    LaunchOraclePgTransformationRequest,
    LaunchOraclePgTransformationResponse,
    OraclePgArtifactsResponse,
    OraclePgJobStatusResponse,
    OraclePgObjectsResponse,
    OraclePgTransformationSummaryResponse,
)
from app.services.oracle_pg.artifact_packager import TRANSFORMATION_SUMMARY_JSON, list_artifacts
from app.services.oracle_pg.progress import (
    STATUS_COMPLETED,
    is_job_terminal,
    is_terminal_progress_event,
    load_conversion_plan,
)
from app.services.oracle_pg.report_metrics import (
    build_executive_summary,
    load_transformation_summary_file,
)
from app.services.oracle_pg.hooks import (
    is_ui_stream_event,
    subscribe,
    subscribe_logs,
    unsubscribe_all,
    unsubscribe_logs,
)
from app.services.oracle_pg.job_manager import get_job_manager
from app.services.oracle_pg.workspace import events_path, logs_path, output_dir, resolve_folder_key

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(
    prefix="/api/oracle-pg-transformation",
    tags=["oracle-pg-transformation"],
    responses={
        400: {"description": "Bad request"},
        404: {"description": "Job not found"},
        500: {"description": "Internal server error"},
    },
)


@router.post(
    "/launch",
    response_model=LaunchOraclePgTransformationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Launch Oracle PG transformation",
    description="Freeze configuration and start autonomous multi-session transformation job.",
)
async def launch_transformation(
    request: LaunchOraclePgTransformationRequest,
) -> LaunchOraclePgTransformationResponse:
    if not settings.oracle_pg_agent.enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"status": "error", "message": "Oracle PG transformation is disabled"},
        )

    manager = get_job_manager()
    payload = request.model_dump(by_alias=True)

    try:
        result = await manager.launch(payload)
        return LaunchOraclePgTransformationResponse(
            jobId=result["jobId"],
            status=result["status"],
            workspacePath=result["workspacePath"],
            dbName=result["dbName"],
        )
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(exc)},
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(exc)},
        )
    except Exception as exc:
        logger.error("Launch failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"status": "error", "message": "Failed to launch transformation job"},
        )


@router.get(
    "/jobs/{jobId}",
    response_model=OraclePgJobStatusResponse,
    summary="Get transformation job status",
)
async def get_job_status(
    job_id: str = PathParam(..., alias="jobId"),
) -> OraclePgJobStatusResponse:
    manager = get_job_manager()
    try:
        progress = manager.get_status(job_id)
        executive_summary = None
        if progress.get("status") == STATUS_COMPLETED:
            folder_key = resolve_folder_key(job_id, settings.claude_workspace) or job_id
            on_disk = load_transformation_summary_file(folder_key)
            if on_disk and on_disk.get("executiveSummary"):
                executive_summary = on_disk["executiveSummary"]
            else:
                plan = load_conversion_plan(folder_key)
                if plan:
                    executive_summary = build_executive_summary(plan)
        return OraclePgJobStatusResponse.from_progress(
            progress,
            executive_summary=executive_summary,
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


@router.get(
    "/jobs/{jobId}/transformation-summary",
    response_model=OraclePgTransformationSummaryResponse,
    summary="Get post-transformation report data",
    description="Returns transformation_summary.json for a completed job.",
)
async def get_transformation_summary(
    job_id: str = PathParam(..., alias="jobId"),
) -> OraclePgTransformationSummaryResponse:
    manager = get_job_manager()
    try:
        progress = manager.get_status(job_id)
        if progress.get("status") != STATUS_COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "status": "error",
                    "message": f"Transformation summary not available for job: {job_id}",
                },
            )
        folder_key = resolve_folder_key(job_id, settings.claude_workspace) or job_id
        summary = load_transformation_summary_file(folder_key)
        if summary is None:
            artifact_path = output_dir(folder_key) / TRANSFORMATION_SUMMARY_JSON
            if not artifact_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "status": "error",
                        "message": f"Transformation summary not found for job: {job_id}",
                    },
                )
            with artifact_path.open(encoding="utf-8") as fh:
                summary = json.load(fh)
        return OraclePgTransformationSummaryResponse(jobId=job_id, summary=summary)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


@router.get(
    "/jobs/{jobId}/artifacts",
    response_model=OraclePgArtifactsResponse,
    summary="List job output artifacts",
)
async def get_job_artifacts(
    job_id: str = PathParam(..., alias="jobId"),
) -> OraclePgArtifactsResponse:
    manager = get_job_manager()
    try:
        manager.get_status(job_id)
        config = manager.get_job_config(job_id)
        db_name = config.get("dbName", "database")
        folder_key = resolve_folder_key(job_id, settings.claude_workspace) or db_name
        return OraclePgArtifactsResponse(
            jobId=job_id,
            dbName=db_name,
            artifacts=list_artifacts(folder_key, db_name),
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


def _resolve_artifact_path(job_id: str, file_name: str) -> Path:
    if not file_name or ".." in file_name or "/" in file_name or "\\" in file_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": "Invalid file name"},
        )
    manager = get_job_manager()
    config = manager.get_job_config(job_id)
    db_name = config.get("dbName", "database")
    folder_key = resolve_folder_key(job_id, settings.claude_workspace) or db_name
    allowed = {a["name"] for a in list_artifacts(folder_key, db_name)}
    if file_name not in allowed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Artifact not found: {file_name}"},
        )
    return output_dir(folder_key) / file_name


@router.get(
    "/jobs/{jobId}/artifacts/download",
    summary="Download all job artifacts as ZIP",
)
async def download_artifacts_zip(
    job_id: str = PathParam(..., alias="jobId"),
) -> FileResponse:
    try:
        config = get_job_manager().get_job_config(job_id)
        db_name = config.get("dbName", "database")
        zip_name = f"{db_name}_postgresql_scripts.zip"
        path = _resolve_artifact_path(job_id, zip_name)
        return FileResponse(path, filename=zip_name, media_type="application/zip")
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


@router.get(
    "/jobs/{jobId}/artifacts/{fileName}",
    summary="Download a single artifact file",
)
async def download_artifact_file(
    job_id: str = PathParam(..., alias="jobId"),
    file_name: str = PathParam(..., alias="fileName"),
) -> FileResponse:
    try:
        path = _resolve_artifact_path(job_id, file_name)
        return FileResponse(path, filename=file_name)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


@router.get(
    "/jobs/{jobId}/objects",
    response_model=OraclePgObjectsResponse,
    summary="List per-object conversion status",
)
async def list_job_objects(
    job_id: str = PathParam(..., alias="jobId"),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
) -> OraclePgObjectsResponse:
    manager = get_job_manager()
    try:
        payload = manager.list_objects(job_id, offset=offset, limit=limit)
        return OraclePgObjectsResponse(**payload)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )


def _parse_stream_event(payload: str) -> dict | None:
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return None
    return event if isinstance(event, dict) else None


async def _tail_events(folder_key: str, *, verbose: bool = False) -> AsyncIterator[str]:
    path = events_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_event(event: dict) -> None:
        if not is_ui_stream_event(event, verbose=verbose):
            return
        await queue.put(json.dumps(event))

    subscribe(folder_key, on_event)

    offset = 0
    try:
        while True:
            if path.exists():
                lines = path.read_text(encoding="utf-8").splitlines()
                while offset < len(lines):
                    line = lines[offset]
                    offset += 1
                    event: dict | None
                    if not verbose:
                        try:
                            event = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if not is_ui_stream_event(event, verbose=False):
                            continue
                    else:
                        event = _parse_stream_event(line)

                    yield f"data: {line}\n\n"
                    if event and is_terminal_progress_event(event):
                        return

            if is_job_terminal(folder_key):
                return

            try:
                event_json = await asyncio.wait_for(queue.get(), timeout=2.0)
                yield f"data: {event_json}\n\n"
                event = _parse_stream_event(event_json)
                if event and is_terminal_progress_event(event):
                    return
            except asyncio.TimeoutError:
                if is_job_terminal(folder_key):
                    return
                yield ": keepalive\n\n"
    finally:
        unsubscribe_all(folder_key)


@router.get(
    "/jobs/{jobId}/stream",
    summary="SSE stream of transformation events",
    description=(
        "Streams UI-relevant job events (progress_updated, sql_written, plan_updated, "
        "file_written, file_read, file_search, session ResultMessage). "
        "Set verbose=true to include all SDK messages."
    ),
)
async def stream_job_events(
    job_id: str = PathParam(..., alias="jobId"),
    verbose: bool = Query(
        default=False,
        description="Include all SDK debug messages (thinking_tokens, etc.) when true.",
    ),
) -> StreamingResponse:
    manager = get_job_manager()
    try:
        manager.get_status(job_id)
        folder_key = resolve_folder_key(job_id, settings.claude_workspace)
        if not folder_key:
            raise FileNotFoundError(f"Job not found: {job_id}")
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )

    return StreamingResponse(
        _tail_events(folder_key, verbose=verbose),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


async def _tail_logs(folder_key: str) -> AsyncIterator[str]:
    path = logs_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_log(entry: dict) -> None:
        await queue.put(json.dumps(entry))

    subscribe_logs(folder_key, on_log)

    offset = 0
    try:
        while True:
            if path.exists():
                lines = path.read_text(encoding="utf-8").splitlines()
                while offset < len(lines):
                    line = lines[offset]
                    offset += 1
                    yield f"data: {line}\n\n"

            if is_job_terminal(folder_key):
                return

            try:
                entry_json = await asyncio.wait_for(queue.get(), timeout=2.0)
                yield f"data: {entry_json}\n\n"
            except asyncio.TimeoutError:
                if is_job_terminal(folder_key):
                    return
                yield ": keepalive\n\n"
    finally:
        unsubscribe_logs(folder_key)


@router.get(
    "/jobs/{jobId}/logs/stream",
    summary="SSE stream of human-readable transformation logs",
    description=(
        "Streams UI-friendly log entries (timestamp, phase, icon, message, color) "
        "derived from Claude Agent SDK activity and orchestrator progress."
    ),
)
async def stream_job_logs(
    job_id: str = PathParam(..., alias="jobId"),
) -> StreamingResponse:
    manager = get_job_manager()
    try:
        manager.get_status(job_id)
        folder_key = resolve_folder_key(job_id, settings.claude_workspace)
        if not folder_key:
            raise FileNotFoundError(f"Job not found: {job_id}")
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )

    return StreamingResponse(
        _tail_logs(folder_key),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
