"""
Stream Visualization API endpoints.

REST endpoints for retrieving and visualizing Claude stream data.

Equivalent to Java's StreamVisualizationController.
"""
import logging
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, Depends, Path, Query, status
from fastapi.responses import JSONResponse

from app.models.responses import StreamVisualizationResponse
from app.services.stream_visualization_service import (
    StreamVisualizationService,
    get_stream_visualization_service
)
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)

# Create router with prefix and tags
router = APIRouter(
    prefix="/api/stream",
    tags=["stream"],
    responses={
        404: {"description": "Stream not found"},
        500: {"description": "Internal server error"},
        400: {"description": "Bad request"}
    }
)


@router.get(
    "/{analysisId}/{operation}",
    summary="Get Stream Visualization",
    description="Retrieve and parse stream data for a specific analysis and operation",
    response_description="Stream visualization data with events and metadata",
    status_code=status.HTTP_200_OK,
    response_model=StreamVisualizationResponse
)
async def get_stream_visualization(
    analysis_id: str = Path(
        ...,
        alias="analysisId",
        description="Unique identifier for the analysis",
        example="analysis-001"
    ),
    operation: str = Path(
        ...,
        description="Operation type (analysis, fix-upgrade, build-compilation, etc.)",
        example="analysis"
    ),
    format: str = Query(
        default="json",
        description="Response format (json or html)",
        regex="^(json|html)$"
    ),
    stream_service: StreamVisualizationService = Depends(get_stream_visualization_service)
) -> StreamVisualizationResponse:
    """
    Get stream visualization data for a specific analysis and operation.

    Retrieves the stream-json file generated during Claude CLI execution,
    parses it, and returns structured event data with metadata.

    Args:
        analysis_id: Unique identifier for the analysis
        operation: Operation type (e.g., "analysis", "fix-upgrade", "build-compilation")
        format: Response format (json or html, defaults to json)
        stream_service: Injected StreamVisualizationService instance

    Returns:
        StreamVisualizationResponse with stream events and metadata

    Raises:
        HTTPException: 400 for validation errors, 404 if stream not found, 500 for errors

    Example:
        GET /api/stream/analysis-001/analysis?format=json

        Response:
        {
          "analysisId": "analysis-001",
          "operation": "analysis",
          "status": "success",
          "message": "Stream data retrieved successfully",
          "streamData": "{\"events\": [...], \"metadata\": {...}}"
        }
    """
    logger.info(
        f"Stream visualization request: analysisId={analysis_id}, "
        f"operation={operation}, format={format}"
    )

    try:
        # Get stream data from service
        response = await stream_service.get_stream_data(analysis_id, operation)

        # Return appropriate status based on response
        if response.status == "success":
            logger.info(f"Stream data retrieved successfully for {analysis_id}/{operation}")
            return response

        elif response.status == "not_found":
            logger.warning(f"Stream file not found for {analysis_id}/{operation}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "status": "not_found",
                    "message": response.message,
                    "analysisId": analysis_id,
                    "operation": operation
                }
            )

        else:  # status == "error"
            logger.error(f"Stream visualization failed for {analysis_id}/{operation}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": response.message,
                    "analysisId": analysis_id,
                    "operation": operation
                }
            )

    except ValidationError as e:
        # Validation errors return 400 Bad Request
        error_msg = f"Validation error: {e.message}"
        logger.error(error_msg)

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": error_msg,
                "field": e.field
            }
        )

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        # All other errors return 500 Internal Server Error
        error_msg = f"Stream visualization request failed: {str(e)}"
        logger.error(error_msg, exc_info=True)

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "status": "error",
                "message": error_msg
            }
        )


@router.get(
    "/health",
    summary="Stream Service Health Check",
    description="Check if stream visualization service is running",
    response_description="Service health status",
    status_code=status.HTTP_200_OK
)
async def health_check() -> Dict[str, Any]:
    """
    Health check endpoint for stream visualization service.

    Returns:
        Health status with service name and timestamp

    Example:
        GET /api/stream/health

        Response:
        {
          "status": "healthy",
          "service": "StreamVisualizationService",
          "timestamp": "1705234567890"
        }
    """
    import time

    logger.debug("Stream visualization health check requested")

    return {
        "status": "healthy",
        "service": "StreamVisualizationService",
        "timestamp": str(int(time.time() * 1000))
    }


@router.get(
    "/summary/{analysisId}/{operation}",
    summary="Get Stream Summary",
    description="Get summary information about a stream without full event data",
    response_description="Stream summary with metadata only",
    status_code=status.HTTP_200_OK
)
async def get_stream_summary(
    analysis_id: str = Path(
        ...,
        alias="analysisId",
        description="Unique identifier for the analysis"
    ),
    operation: str = Path(
        ...,
        description="Operation type"
    ),
    stream_service: StreamVisualizationService = Depends(get_stream_visualization_service)
) -> Dict[str, Any]:
    """
    Get summary information about a stream.

    Returns metadata and statistics without full event data.
    Useful for quick status checks.

    Args:
        analysis_id: Analysis ID
        operation: Operation type
        stream_service: Injected service

    Returns:
        Summary dictionary with metadata

    Example:
        GET /api/stream/summary/analysis-001/analysis

        Response:
        {
          "status": "success",
          "exists": true,
          "total_events": 150,
          "input_tokens": 1234,
          "output_tokens": 5678,
          "is_error": false
        }
    """
    logger.info(f"Stream summary request: analysisId={analysis_id}, operation={operation}")

    try:
        summary = await stream_service.get_stream_summary(analysis_id, operation)
        return summary

    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": e.message,
                "field": e.field
            }
        )

    except Exception as e:
        error_msg = f"Failed to get stream summary: {str(e)}"
        logger.error(error_msg, exc_info=True)

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "status": "error",
                "message": error_msg
            }
        )


@router.get(
    "/list/{analysisId}",
    summary="List Available Streams",
    description="List all available stream files for an analysis",
    response_description="List of available streams",
    status_code=status.HTTP_200_OK
)
async def list_available_streams(
    analysis_id: str = Path(
        ...,
        alias="analysisId",
        description="Unique identifier for the analysis"
    ),
    stream_service: StreamVisualizationService = Depends(get_stream_visualization_service)
) -> Dict[str, Any]:
    """
    List all available stream files for an analysis.

    Returns information about all stream files found for the given analysisId.

    Args:
        analysis_id: Analysis ID
        stream_service: Injected service

    Returns:
        Dictionary with list of available streams

    Example:
        GET /api/stream/list/analysis-001

        Response:
        {
          "analysisId": "analysis-001",
          "streams": [
            {
              "operation": "analysis",
              "file_path": "/path/to/analysis-stream.json",
              "total_events": 150,
              "is_error": false
            }
          ],
          "total_streams": 1
        }
    """
    logger.info(f"List streams request: analysisId={analysis_id}")

    try:
        streams = await stream_service.list_available_streams(analysis_id)

        return {
            "analysisId": analysis_id,
            "streams": streams,
            "total_streams": len(streams)
        }

    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": e.message,
                "field": e.field
            }
        )

    except Exception as e:
        error_msg = f"Failed to list streams: {str(e)}"
        logger.error(error_msg, exc_info=True)

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "status": "error",
                "message": error_msg
            }
        )
