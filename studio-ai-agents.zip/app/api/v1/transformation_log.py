"""
Transformation summary log API endpoint.

Processes stream events via LLM to produce user-readable
transformation progress log entries.
"""
import logging

from fastapi import APIRouter, HTTPException, status

from app.models.transformation_log import (
    ProcessTransformationLogRequest,
    ProcessTransformationLogResponse,
)
from app.services.transformation_log_service import get_transformation_log_service

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/transformation-log",
    tags=["transformation-log"],
    responses={
        400: {"description": "Bad request"},
        500: {"description": "Internal server error"},
    },
)


@router.post(
    "/process",
    response_model=ProcessTransformationLogResponse,
    summary="Process Transformation Log",
    description="Process next chunk of stream events and update the transformation summary log file.",
)
async def process_transformation_log(
    request: ProcessTransformationLogRequest,
) -> ProcessTransformationLogResponse:
    logger.info(
        f"Transformation log request: analysisId={request.analysis_id}, "
        f"operation={request.operation}"
    )

    try:
        service = get_transformation_log_service()
        return await service.process_new_events(request)

    except ValueError as e:
        logger.warning(f"Path validation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(e)},
        )

    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(e)},
        )

    except Exception as e:
        logger.error(f"Transformation log processing failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"status": "error", "message": "Internal processing error. Check server logs for details."},
        )
