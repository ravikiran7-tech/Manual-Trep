"""Launch-only API for MSSQL → PostgreSQL agentic schema transformation.

After launch, status, progress SSE, objects, summary, artifacts and logs
are served by the existing Oracle URLs. Those handlers look up the folder
from jobId (Oracle workspace first, then MSSQL) and read the files inside it.

MSSQL jobs use shared Oracle URLs for reads. ``oracle_path_logs_router`` is mounted
before the Oracle router and dispatches ``.../logs/stream`` to ``tail_mssql_pg_logs``
and ``.../stream`` to ``tail_mssql_pg_events`` when ``engine`` is ``mssql``. Oracle
jobs on those same URLs are passed through to the existing Oracle tails. The Oracle
module itself is not modified.
``oracle_path_artifacts_router`` dispatches ``.../artifacts``, ``.../artifacts/download``,
and ``.../artifacts/{fileName}`` to ``mssql_pg.artifact_packager`` so all 16 phase scripts
appear (Oracle's default list is 13 files). Both routers mount under the same base prefix
as other routers, before the Oracle schema router.
"""

from __future__ import annotations

import json
import logging
from typing import AsyncIterator

from pathlib import Path

from fastapi import APIRouter, HTTPException, Path as PathParam, Query, status
from fastapi.responses import FileResponse, StreamingResponse

from app.api.v1.mssql_pg_log_stream import tail_mssql_pg_events, tail_mssql_pg_logs
from app.api.v1 import oracle_pg_transformation as oracle_pg_schema
from app.core.config import get_settings
from app.models.mssql_pg_transformation import (
    LaunchMssqlPgTransformationRequest,
    LaunchMssqlPgTransformationResponse,
)
from app.models.oracle_pg_transformation import (
    OraclePgArtifactsResponse,
    OraclePgJobStatusResponse,
)
from app.services.db_transformation.sources import JOB_ENGINE_FIELD, JOB_ENGINE_MSSQL
from app.services.mssql_pg.artifact_packager import list_artifacts as mssql_list_artifacts
from app.services.mssql_pg.job_manager import get_job_manager
from app.services.oracle_pg.artifact_packager import list_artifacts as oracle_list_artifacts
from app.services.oracle_pg.job_manager import get_job_manager as get_oracle_job_manager
from app.services.oracle_pg.workspace import job_config_path, output_dir, resolve_folder_key

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(
    prefix="/api/mssql-pg-transformation",
    tags=["mssql-pg-transformation"],
    responses={
        400: {"description": "Bad request"},
        404: {"description": "Job not found"},
        500: {"description": "Internal server error"},
    },
)

oracle_path_logs_router = APIRouter(
    tags=["mssql-pg-transformation"],
    responses={
        404: {"description": "Job not found"},
    },
)

oracle_path_artifacts_router = APIRouter(
    tags=["mssql-pg-transformation"],
    responses={
        400: {"description": "Bad request"},
        404: {"description": "Job not found"},
    },
)

# main.py mounts this before the Oracle router. The running image already
# includes it; the attribute has to exist or every worker dies at import.
oracle_path_status_router = APIRouter(
    tags=["mssql-pg-transformation"],
    responses={
        404: {"description": "Job not found"},
    },
)


def _is_mssql_schema_job(folder_key: str) -> bool:
    path = job_config_path(folder_key, settings.claude_workspace)
    if not path.exists():
        return False
    try:
        with path.open(encoding="utf-8") as fh:
            config = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return False
    return isinstance(config, dict) and config.get(JOB_ENGINE_FIELD) == JOB_ENGINE_MSSQL


def _folder_key_for_stream(job_id: str) -> str:
    """Locate the job folder without failing the SSE request on a bad progress file."""
    try:
        folder_key = resolve_folder_key(job_id, settings.claude_workspace)
    except Exception:
        logger.exception("Folder lookup failed for job %s", job_id)
        folder_key = None
    if not folder_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    return folder_key


def _resolve_schema_artifact_path(job_id: str, file_name: str, *, folder_key: str, mssql_job: bool) -> Path:
    if not file_name or ".." in file_name or "/" in file_name or "\\" in file_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": "Invalid file name"},
        )
    list_fn = mssql_list_artifacts if mssql_job else oracle_list_artifacts
    manager = get_job_manager() if mssql_job else get_oracle_job_manager()
    config = manager.get_job_config(job_id)
    db_name = config.get("dbName", "database")
    allowed = {a["name"] for a in list_fn(folder_key, db_name)}
    if file_name not in allowed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Artifact not found: {file_name}"},
        )
    return output_dir(folder_key) / file_name


@oracle_path_artifacts_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}/artifacts",
    response_model=OraclePgArtifactsResponse,
    summary="List job output artifacts (MSSQL 16-phase vs Oracle)",
)
async def list_schema_job_artifacts_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
) -> OraclePgArtifactsResponse:
    folder_key = resolve_folder_key(job_id, settings.claude_workspace)
    if not folder_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    mssql_job = _is_mssql_schema_job(folder_key)
    manager = get_job_manager() if mssql_job else get_oracle_job_manager()
    try:
        manager.get_status(job_id)
        config = manager.get_job_config(job_id)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    db_name = config.get("dbName", "database")
    list_fn = mssql_list_artifacts if mssql_job else oracle_list_artifacts
    return OraclePgArtifactsResponse(
        jobId=job_id,
        dbName=db_name,
        artifacts=list_fn(folder_key, db_name),
    )


@oracle_path_artifacts_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}/artifacts/download",
    summary="Download all job artifacts as ZIP (MSSQL vs Oracle)",
)
async def download_schema_artifacts_zip_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
) -> FileResponse:
    folder_key = resolve_folder_key(job_id, settings.claude_workspace)
    if not folder_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    mssql_job = _is_mssql_schema_job(folder_key)
    manager = get_job_manager() if mssql_job else get_oracle_job_manager()
    try:
        config = manager.get_job_config(job_id)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    db_name = config.get("dbName", "database")
    zip_name = f"{db_name}_postgresql_scripts.zip"
    try:
        path = _resolve_schema_artifact_path(job_id, zip_name, folder_key=folder_key, mssql_job=mssql_job)
    except HTTPException:
        raise
    return FileResponse(path, filename=zip_name, media_type="application/zip")


@oracle_path_artifacts_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}/artifacts/{fileName}",
    summary="Download a single artifact file (MSSQL vs Oracle)",
)
async def download_schema_artifact_file_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
    file_name: str = PathParam(..., alias="fileName"),
) -> FileResponse:
    folder_key = resolve_folder_key(job_id, settings.claude_workspace)
    if not folder_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    mssql_job = _is_mssql_schema_job(folder_key)
    try:
        path = _resolve_schema_artifact_path(job_id, file_name, folder_key=folder_key, mssql_job=mssql_job)
    except HTTPException:
        raise
    return FileResponse(path, filename=file_name)


@oracle_path_status_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}",
    response_model=OraclePgJobStatusResponse,
    summary="Job status and progress percent on the shared URL",
)
async def get_schema_job_status_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
) -> OraclePgJobStatusResponse:
    """MSSQL jobs report their own progress. Other jobs use the Oracle handler."""
    folder_key = _folder_key_for_stream(job_id)
    if not _is_mssql_schema_job(folder_key):
        return await oracle_pg_schema.get_job_status(job_id)
    try:
        progress = get_job_manager().get_status(job_id)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )
    return OraclePgJobStatusResponse.from_progress(progress)


@oracle_path_status_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}/stream",
    summary="SSE stream of transformation progress (MSSQL jobs)",
    description=(
        "Same URL the UI already calls. MSSQL jobs are tailed from mssql_pg.hooks "
        "so progressPercent climbs during the run. Any other job is passed through "
        "to the existing Oracle tail."
    ),
)
async def stream_schema_job_events_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
    verbose: bool = Query(
        default=False,
        description="Include all SDK debug messages when true.",
    ),
) -> StreamingResponse:
    folder_key = _folder_key_for_stream(job_id)
    event_iter: AsyncIterator[str] = (
        tail_mssql_pg_events(folder_key, verbose=verbose)
        if _is_mssql_schema_job(folder_key)
        else oracle_pg_schema._tail_events(folder_key, verbose=verbose)
    )
    return StreamingResponse(
        event_iter,
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@oracle_path_logs_router.get(
    "/api/oracle-pg-transformation/jobs/{jobId}/logs/stream",
    summary="SSE stream of transformation logs (MSSQL vs Oracle dispatch)",
    description=(
        "Same path as Oracle schema jobs. When ``engine`` in job_config.json is "
        "``mssql``, streams using MSSQL hook subscriptions; otherwise defers to "
        "Oracle ``_tail_logs`` behavior."
    ),
)
async def stream_schema_job_logs_oracle_url(
    job_id: str = PathParam(..., alias="jobId"),
) -> StreamingResponse:
    manager = get_job_manager()
    try:
        try:
            manager.get_status(job_id)
        except FileNotFoundError:
            raise
        except Exception:
            # A bad progress.json must not turn the log SSE into a 500.
            logger.exception("Status read failed for job %s; opening logs anyway", job_id)
        try:
            folder_key = resolve_folder_key(job_id, settings.claude_workspace)
        except Exception:
            logger.exception("Folder lookup failed for job %s", job_id)
            folder_key = None
        if not folder_key:
            raise FileNotFoundError(f"Job not found: {job_id}")
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Job not found: {job_id}"},
        )

    log_iter: AsyncIterator[str] = (
        tail_mssql_pg_logs(folder_key) if _is_mssql_schema_job(folder_key) else oracle_pg_schema._tail_logs(folder_key)
    )
    return StreamingResponse(
        log_iter,
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post(
    "/launch",
    response_model=LaunchMssqlPgTransformationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Launch MSSQL PG transformation",
    description="Freeze configuration and start the autonomous four-pass transformation job.",
)
async def launch_transformation(request: LaunchMssqlPgTransformationRequest) -> LaunchMssqlPgTransformationResponse:
    if not settings.mssql_pg_agent.enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"status": "error", "message": "MSSQL PG transformation is disabled"},
        )

    manager = get_job_manager()
    payload = request.model_dump(by_alias=True)

    try:
        result = await manager.launch(payload)
        return LaunchMssqlPgTransformationResponse(
            jobId=result["jobId"],
            status=result["status"],
            workspacePath=result["workspacePath"],
            dbName=result["dbName"],
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail={"status": "error", "message": str(exc)})
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail={"status": "error", "message": str(exc)})
    except Exception:
        logger.exception("Launch failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"status": "error", "message": "Failed to launch transformation job"},
        )
