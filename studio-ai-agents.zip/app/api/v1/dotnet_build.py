"""
Build API endpoints.

- POST /api/validation/dotnet-executeBuild  — Direct .NET build (no LLM)
- POST /api/validation/executeBuild         — Direct Java Maven build (no LLM)

Equivalent to Java's BuildCompilationController + ClaudeCliController.
"""
import logging

from fastapi import APIRouter, HTTPException, status

from app.models.dotnet_build import BuildRequest, BuildResult
from app.services.dotnet_build_execution_service import execute_dotnet_build
from app.services.java_build_execution_service import execute_java_build


logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/validation",
    tags=["dotnet-build"],
    responses={
        500: {"description": "Internal server error"},
        400: {"description": "Bad request"},
    },
)


@router.post(
    "/dotnet-executeBuild",
    summary="Execute .NET Build",
    description="Execute .NET build directly without LLM for fast compilation checks",
    response_description="Build result with status, errors, warnings and timing",
    response_model=BuildResult,
    status_code=status.HTTP_200_OK,
)
async def dotnet_execute_build(request: BuildRequest) -> BuildResult:
    """
    Execute .NET build without LLM.

    Runs 'dotnet build' as a subprocess, parses the output, saves
    build-result.json to the reports folder, and returns the result.

    Mirrors Java's ClaudeCliController.dotnetExecuteBuild() exactly.

    Args:
        request: BuildRequest with project location, analysisId, platform, etc.

    Returns:
        BuildResult with exitCode, buildStatus, compilationErrors, warnings, etc.

    Raises:
        HTTPException: 500 if the build fails or dotnet is not available

    Example:
        POST /api/validation/dotnet-executeBuild
        {
          "projectLocation": "/projects/my-dotnet-app",
          "analysisId": "analysis-001",
          "platform": "linux",
          "claudeWorkspace": "/studio-app/claude-workspace",
          "applicationName": "MyDotNetApp"
        }

        Response:
        {
          "exitCode": 0,
          "success": true,
          "buildStatus": "SUCCESS",
          "compilationErrors": [],
          "testFailures": [],
          "errors": 0,
          "warnings": 2,
          "totalTime": "0:00:45"
        }
    """
    logger.info(
        ".NET build requested, project: %s, platform: %s",
        request.application_name,
        request.platform,
    )

    try:
        logger.info("Routing to .NET build execution")
        result = await execute_dotnet_build(request)
        return result
    except Exception as e:
        logger.error(
            ".NET build execution failed for analysisId: %s",
            request.analysis_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )


@router.post(
    "/executeBuild",
    summary="Execute Java Build",
    description="Execute Java Maven build directly without LLM using SDKMAN-managed Java versions",
    response_description="Build result with status, errors, warnings and timing",
    response_model=BuildResult,
    status_code=status.HTTP_200_OK,
)
async def execute_build(request: BuildRequest) -> BuildResult:
    """
    Execute Java build without LLM.

    Mirrors Java's BuildCompilationController.executeBuild() exactly:
      1. Verifies SDKMAN is installed
      2. Validates project structure and build file existence
      3. Resolves Java version via SDKMAN (8 → 8.0.422-tem, 17 → 17.0.13-tem, etc.)
      4. Runs 'mvn clean install' via bash script
      5. Parses Maven output and saves build-result.json to reports folder

    Currently supports: technology=java, buildType=maven only.

    Args:
        request: BuildRequest with projectLocation, analysisId, technology,
                 buildType, version, buildFile, skipTests, etc.

    Returns:
        BuildResult with exitCode, buildStatus, compilationErrors, warnings, etc.

    Raises:
        HTTPException: 400 for validation errors, 500 for build/execution failures

    Example:
        POST /api/validation/executeBuild
        {
          "projectLocation": "/projects/my-java-app",
          "analysisId": "analysis-001",
          "platform": "linux",
          "claudeWorkspace": "/studio-app/claude-workspace",
          "applicationName": "MyJavaApp",
          "buildFile": "pom.xml",
          "technology": "java",
          "buildType": "maven",
          "version": "17",
          "skipTests": false
        }

        Response:
        {
          "exitCode": 0,
          "success": true,
          "buildStatus": "SUCCESS",
          "compilationErrors": [],
          "testFailures": [],
          "errors": 0,
          "warnings": 3,
          "totalTime": "12.345 s"
        }
    """
    logger.info(
        "Java build requested, project: %s, technology: %s, platform: %s",
        request.application_name,
        request.technology,
        request.platform,
    )

    try:
        logger.info("Routing to Java build execution")
        result = await execute_java_build(request)
        return result
    except (ValueError, NotImplementedError) as e:
        # Bad request — validation errors or unsupported build type
        logger.error(
            "Java build validation error for analysisId: %s — %s",
            request.analysis_id, str(e),
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            "Java build execution failed for analysisId: %s",
            request.analysis_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
