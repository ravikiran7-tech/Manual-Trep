"""App+DB Oracle → PostgreSQL application transformation APIs.

Endpoint groups:

* ``/launch`` — start the transformation;
* ``/jobs/{jobId}`` and ``/jobs/{jobId}/stream`` — status + SSE progress, in
  the same shape the DB job exposes so studio-database-code-modernize's
  poller and progress relay work against either job type. Public ``jobId`` is
  the application id (one app, one database). Routes still accept a database
  id or the internal APPDB-… transformation id;
* ``/{transformationId}/...`` — progress, logs, report and artifacts for a
  specific transformation.

GitHub commit is not part of Job 3; legacy commit routes return HTTP 410.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from typing import Any, AsyncIterator, Dict, Optional

from fastapi import APIRouter, Header, HTTPException, Path as PathParam, Query, Request, status
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse

from app.core.config import get_settings
from app.models.app_db_transformation import (
    AppDbArtifactsResponse,
    AppDbCommitResultRequest,
    AppDbCommitRetryRequest,
    AppDbJobStatusResponse,
    AppDbLaunchRequest,
    AppDbLaunchResponse,
    AppDbLogsResponse,
    AppDbProgressResponse,
    AppDbReportPathResponse,
    AppDbReportRequest,
    AppDbReportStatusResponse,
)
from app.services.oracle_pg.app_db_change import artifacts as artifact_ops
from app.services.oracle_pg.app_db_change import events as event_bus
from app.services.oracle_pg.app_db_change import workspace as app_db_ws
from app.services.oracle_pg.app_db_change.job_manager import get_app_db_job_manager
from app.services.oracle_pg.app_db_change.progress_tracker import (
    db_id_for_job,
    get_progress_tracker,
    is_job_terminal_on_disk,
    job_dir,
)
from app.services.oracle_pg.app_db_change.report_packager import (
    load_report,
    resolve_report,
    resolve_report_location,
)

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(
    prefix="/api/app-db-transformation",
    tags=["app-db-transformation"],
    responses={
        400: {"description": "Bad request"},
        404: {"description": "Transformation not found"},
        410: {"description": "GitHub commit is not part of App+DB Job 3"},
        500: {"description": "Internal server error"},
    },
)

_SSE_HEADERS = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


def _commit_gone() -> None:
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail={
            "status": "error",
            "message": "GitHub commit is not part of App+DB Job 3",
        },
    )


def _report_etag(report: Dict[str, Any]) -> str:
    """Weak-free ETag over the report's identity + generation stamp.

    The report is a point-in-time snapshot, so its transformationId plus the
    generation timestamp fully identify a version — hashing the whole body on
    every request would be wasteful.
    """
    seed = "|".join(
        [
            str(report.get("transformationId") or ""),
            str((report.get("metadata") or {}).get("generatedAt") or ""),
        ]
    )
    return '"' + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:32] + '"'


def _filter_report(report: Dict[str, Any], filter_mode: str) -> Dict[str, Any]:
    """Optional server-side narrowing of a large report.

    ``failed`` keeps only the rules and files that need attention, which is what
    the "needs review" view of the modal shows; the display blocks are rewritten
    so the counts in the headings still match the rows returned.
    """
    mode = (filter_mode or "").strip().lower()
    if mode in ("", "all"):
        return report
    if mode not in ("failed", "manual-review"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "status": "error",
                "message": "filter must be one of: all, failed, manual-review",
            },
        )

    narrowed = dict(report)
    if mode == "failed":
        rules = [r for r in report.get("rulesResults") or [] if r.get("failed")]
        files = [f for f in report.get("fileModifications") or [] if f.get("failed")]
    else:
        rules = [r for r in report.get("rulesResults") or [] if r.get("manualReview")]
        files = [f for f in report.get("fileModifications") or [] if f.get("manualReview")]

    narrowed["rulesResults"] = rules
    narrowed["fileModifications"] = files
    narrowed["rulesTable"] = {
        **(report.get("rulesTable") or {}),
        "title": f"Rules ({len(rules)})",
        "rows": rules,
    }
    narrowed["filesSection"] = {
        **(report.get("filesSection") or {}),
        "title": f"Modified Files ({len(files)})",
        "files": files,
    }
    narrowed["filter"] = mode
    return narrowed


def _require_job(transformation_id: str) -> str:
    """Resolve a path id to a known job or raise 404."""
    tracker = get_progress_tracker()
    resolved = tracker.resolve_job_id(transformation_id)
    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"status": "error", "message": f"Transformation not found: {transformation_id}"},
        )
    return resolved


@router.post(
    "/launch",
    response_model=AppDbLaunchResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Launch App+DB transformation",
    description="Accept transformation request and start background remediations on the project checkout.",
)
async def launch_transformation(
    request: AppDbLaunchRequest,
    force: bool = Query(
        False,
        description=(
            "Start a new transformation even when one is already running for this "
            "appId+dbId. Off by default because concurrent runs share one checkout."
        ),
    ),
    idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
) -> AppDbLaunchResponse:
    if not settings.oracle_pg_agent.enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"status": "error", "message": "Oracle PG transformation is disabled"},
        )

    limits = settings.app_db_job3
    tracker = get_progress_tracker()

    # Idempotency: Job 3 rewrites one shared checkout and one report path, so a
    # duplicate launch for the same app/db returns the run already in flight
    # rather than racing it. `force=true` opts out.
    if limits.reuse_in_flight_launch and not force:
        in_flight = tracker.find_active_job(app_id=request.appId, db_id=request.dbId)
        if in_flight:
            logger.info(
                "App+DB launch for appId=%s dbId=%s reused in-flight %s (idempotencyKey=%s)",
                request.appId,
                request.dbId,
                in_flight,
                idempotency_key,
            )
            return AppDbLaunchResponse(
                transformationId=in_flight,
                jobId=tracker.public_job_id(in_flight) or request.appId,
                status="IN_PROGRESS",
                message="Transformation already in progress for this application and database",
                reused=True,
            )

    if tracker.count_active() >= limits.max_concurrent_jobs:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "status": "error",
                "message": (
                    f"Too many App+DB transformations in progress "
                    f"(limit {limits.max_concurrent_jobs}); retry shortly"
                ),
            },
            headers={"Retry-After": "60"},
        )

    try:
        manager = get_app_db_job_manager()
        started = await manager.launch(request.model_dump(exclude_none=True))
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"status": "error", "message": str(exc)},
        ) from exc
    except Exception as exc:
        logger.error("App+DB launch failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"status": "error", "message": "Failed to launch App+DB transformation"},
        ) from exc

    return AppDbLaunchResponse(
        transformationId=started["transformationId"],
        jobId=started["jobId"],
        status=started["status"],
        message=started.get("message") or "Transformation queued",
        workspacePath=started.get("workspacePath"),
    )


# --------------------------------------------------------------------------
# DB-job-compatible job routes. Declared before the /{transformationId} routes
# so "/jobs/..." is never captured as a transformation id.
# --------------------------------------------------------------------------


@router.get(
    "/jobs/{jobId}",
    response_model=AppDbJobStatusResponse,
    summary="Get App+DB job status (DB-job compatible)",
    description=(
        "Current job state in the same shape as the DB job's "
        "/oracle-pg-transformation/jobs/{jobId}: lowercase status, phase, "
        "progressPercent, objectsTotal/objectsConverted. Public jobId is the "
        "application id; the APPDB-… transformation id and database id still "
        "resolve. "
        "Terminal responses additionally carry startedAt/completedAt/"
        "durationSeconds/duration and filesModified."
    ),
)
async def get_job_status(
    job_id: str = PathParam(..., alias="jobId", min_length=1),
) -> AppDbJobStatusResponse:
    resolved = _require_job(job_id)
    payload = get_progress_tracker().get_status_payload(resolved)
    return AppDbJobStatusResponse(**payload)


async def _tail_progress_events(transformation_id: str) -> AsyncIterator[str]:
    """Replay persisted events, then poll for new ones until the job ends.

    Emits the same ``progress_updated`` envelope as the DB job's stream, so the
    Java relay (TransformProgressService) and the MFE parse one shape for both
    job types. The stream closes on the terminal event, which is the one that
    carries duration and the finished-work counters.
    """
    tracker = get_progress_tracker()
    folder = job_dir(transformation_id)
    cursor = 0
    idle_ticks = 0
    while True:
        entries = event_bus.read_events(folder)
        if cursor < len(entries):
            for event in entries[cursor:]:
                cursor += 1
                yield f"data: {json.dumps(event)}\n\n"
                if event_bus.is_terminal_event(event):
                    return
            idle_ticks = 0
            continue
        if tracker.is_terminal(transformation_id):
            # Terminal state reached without a terminal event on disk (e.g. the
            # process restarted mid-job) — emit the final status once.
            tracker.refresh_state_from_disk(transformation_id)
            payload = dict(tracker.get_status_payload(transformation_id))
            payload["type"] = event_bus.EVENT_PROGRESS_UPDATED
            yield f"data: {json.dumps(payload)}\n\n"
            return
        await asyncio.sleep(0.4)
        idle_ticks += 1
        if idle_ticks >= 5:
            idle_ticks = 0
            yield ": keepalive\n\n"


@router.get(
    "/jobs/{jobId}/stream",
    summary="SSE stream of App+DB progress events",
    description=(
        "Streams progress_updated events carrying progressPercent on every "
        "state change; the terminal (100%) event also carries startedAt, "
        "completedAt, durationSeconds, duration, filesModified and the report "
        "location."
    ),
)
async def stream_job_progress(
    job_id: str = PathParam(..., alias="jobId", min_length=1),
) -> StreamingResponse:
    resolved = _require_job(job_id)
    return StreamingResponse(
        _tail_progress_events(resolved),
        media_type="text/event-stream",
        headers=_SSE_HEADERS,
    )


@router.get(
    "/jobs/{jobId}/logs/stream",
    summary="SSE stream of App+DB logs (DB-job compatible path)",
)
async def stream_job_logs(
    job_id: str = PathParam(..., alias="jobId", min_length=1),
) -> StreamingResponse:
    resolved = _require_job(job_id)
    return StreamingResponse(
        _tail_sse_logs(resolved),
        media_type="text/event-stream",
        headers=_SSE_HEADERS,
    )


@router.get(
    "/jobs/{jobId}/logs",
    response_model=AppDbLogsResponse,
    summary="Get App+DB logs (DB-job compatible path)",
    description=(
        "Paged log entries for a job addressed the same way as every other "
        "/jobs/{jobId} route (application id, database id or transformation id)."
    ),
)
async def get_job_logs(
    job_id: str = PathParam(..., alias="jobId", min_length=1),
    from_index: int = Query(0, ge=0, alias="fromIndex"),
) -> AppDbLogsResponse:
    resolved = _require_job(job_id)
    payload = get_progress_tracker().get_logs(resolved, from_index=from_index)
    return AppDbLogsResponse(logs=payload["logs"], hasMore=payload["has_more"])


@router.get(
    "/jobs/{jobId}/artifacts",
    response_model=AppDbArtifactsResponse,
    summary="List App+DB job artifacts (DB-job compatible path)",
)
async def list_job_artifacts(
    job_id: str = PathParam(..., alias="jobId", min_length=1),
) -> AppDbArtifactsResponse:
    resolved = _require_job(job_id)
    return AppDbArtifactsResponse(
        transformationId=resolved,
        jobId=get_progress_tracker().public_job_id(resolved),
        artifacts=artifact_ops.list_artifacts(resolved, load_report(resolved)),
    )


# --------------------------------------------------------------------------
# Internal report reads (database service)
# --------------------------------------------------------------------------


@router.post(
    "/internal/report",
    include_in_schema=False,
    summary="Get post_transformation_report.json (internal)",
    description="Internal only (database service). Body: appId + dbId. Returns saved report as-is.",
)
async def get_post_transformation_report(request: AppDbReportRequest) -> Dict[str, Any]:
    report = resolve_report(
        app_id=request.appId,
        db_id=request.dbId,
        transformation_id=request.transformationId,
    )
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "status": "error",
                "message": (
                    f"post_transformation_report.json not found for appId={request.appId}, "
                    f"dbId={request.dbId}"
                ),
            },
        )
    return report


@router.post(
    "/internal/report/path",
    response_model=AppDbReportPathResponse,
    include_in_schema=False,
    summary="Get post_transformation_report.json name and path (internal)",
    description=(
        "Internal only (database service). Body: appId + dbId (optional transformationId). "
        "Returns just the report file name and its path on the shared mount so the caller "
        "can read the file directly instead of fetching the full report body from here. "
        "The newest transformation for the app/db pair is used unless transformationId is given."
    ),
)
async def get_post_transformation_report_path(
    request: AppDbReportRequest,
) -> AppDbReportPathResponse:
    location = resolve_report_location(
        app_id=request.appId,
        db_id=request.dbId,
        transformation_id=request.transformationId,
    )
    if not location:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "status": "error",
                "message": (
                    f"post_transformation_report.json not found for appId={request.appId}, "
                    f"dbId={request.dbId}"
                ),
            },
        )
    return AppDbReportPathResponse(**location)


@router.get(
    "/internal/{transformationId}/report",
    include_in_schema=False,
    summary="Get post_transformation_report.json by transformationId (internal)",
)
async def get_post_transformation_report_by_id(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> Dict[str, Any]:
    report = load_report(transformation_id)
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "status": "error",
                "message": f"post_transformation_report.json not found: {transformation_id}",
            },
        )
    return report


@router.post(
    "/internal/commit-result",
    include_in_schema=False,
    summary="GitHub commit is not part of App+DB Job 3",
)
async def record_commit_result_by_app_db(
    request: AppDbCommitResultRequest,
    app_id: str = Query(..., alias="appId", min_length=1),
    db_id: str = Query(..., alias="dbId", min_length=1),
    transformation_id: Optional[str] = Query(None, alias="transformationId"),
) -> None:
    _commit_gone()


# --------------------------------------------------------------------------
# Per-transformation routes
# --------------------------------------------------------------------------


@router.get(
    "/{transformationId}/progress",
    response_model=AppDbProgressResponse,
    summary="Get App+DB transformation progress",
)
async def get_transformation_progress(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> AppDbProgressResponse:
    resolved = _require_job(transformation_id)
    progress = get_progress_tracker().get_progress(resolved)
    return AppDbProgressResponse(
        transformationId=progress["transformation_id"],
        overallStatus=progress["overall_status"],
        bannerMessage=progress["banner_message"],
        currentMilestone=progress["current_milestone"],
        progressPercent=progress["progress_percent"],
        milestones=progress["milestones"],
        metrics=progress["metrics"],
        report=progress["report"],
    )


@router.get(
    "/{transformationId}/progress/stream",
    summary="SSE stream of App+DB progress events",
)
async def stream_transformation_progress(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> StreamingResponse:
    resolved = _require_job(transformation_id)
    return StreamingResponse(
        _tail_progress_events(resolved),
        media_type="text/event-stream",
        headers=_SSE_HEADERS,
    )


@router.get(
    "/{transformationId}/logs",
    response_model=AppDbLogsResponse,
    summary="Get App+DB transformation logs",
)
async def get_transformation_logs(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
    from_index: int = Query(0, ge=0, alias="fromIndex"),
) -> AppDbLogsResponse:
    resolved = _require_job(transformation_id)
    payload = get_progress_tracker().get_logs(resolved, from_index=from_index)
    return AppDbLogsResponse(logs=payload["logs"], hasMore=payload["has_more"])


async def _tail_sse_logs(transformation_id: str) -> AsyncIterator[str]:
    """Tail ``reports/logs.jsonl`` until the job reaches a terminal disk state.

    Same delivery model as the schema (DB) job log stream: the mount is the
    source of truth so SSE works across workers and after reconnect.
    """
    db_id = db_id_for_job(transformation_id)
    path = app_db_ws.logs_path(db_id) if db_id else None
    offset = 0
    while True:
        if path is not None and path.is_file():
            lines = path.read_text(encoding="utf-8").splitlines()
            while offset < len(lines):
                line = lines[offset].strip()
                offset += 1
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(entry, dict):
                    yield f"data: {json.dumps(entry)}\n\n"

        if is_job_terminal_on_disk(transformation_id):
            return

        await asyncio.sleep(0.4)
        yield ": keepalive\n\n"


@router.get(
    "/{transformationId}/logs/stream",
    summary="SSE stream of human-readable transformation logs",
    description=(
        "Streams UI-friendly log entries (timestamp, phase, icon, message, color, "
        "seq, jobId) — same shape as the DB job's logs/stream endpoint."
    ),
)
async def stream_transformation_logs(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> StreamingResponse:
    resolved = _require_job(transformation_id)
    return StreamingResponse(
        _tail_sse_logs(resolved),
        media_type="text/event-stream",
        headers=_SSE_HEADERS,
    )


@router.get(
    "/{transformationId}/report",
    summary="Get the post-transformation report",
    description=(
        "Point-in-time post_transformation_report.json for the Studio report "
        "modal — headers, metadata row, summary cards, rule-by-rule table, "
        "file modification details, manual-review items and footer. "
        "Never regenerated on re-open (FR8)."
    ),
)
async def get_transformation_report(
    request: Request,
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
    report_filter: str = Query(
        "all",
        alias="filter",
        description="all (default) | failed | manual-review — narrows rules and files",
    ),
) -> Any:
    resolved = _require_job(transformation_id)
    report = load_report(resolved)
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "status": "error",
                "message": f"post_transformation_report.json not found: {resolved}",
            },
        )

    # The saved report never changes for a given generation, so a conditional
    # GET lets the modal re-open without re-transferring the body. Responses are
    # gzip-compressed by the app-wide GZip middleware.
    etag = _report_etag(report)
    cache_control = f"private, max-age={settings.app_db_job3.report_cache_max_age_seconds}"
    if request.headers.get("if-none-match") == etag:
        return JSONResponse(
            status_code=status.HTTP_304_NOT_MODIFIED,
            content=None,
            headers={"ETag": etag, "Cache-Control": cache_control},
        )

    payload = _filter_report(report, report_filter)
    return JSONResponse(
        content=payload,
        headers={"ETag": etag, "Cache-Control": cache_control},
    )


@router.get(
    "/{transformationId}/report/status",
    response_model=AppDbReportStatusResponse,
    summary="Post-Transformation Report artifact-step status",
    description=(
        "Status of the report artifact alone, with the per-step trace "
        "(GENERATE_JSON, PACKAGE_ZIP) and durations. Poll this only when the "
        "SSE stream is unavailable — the recommended cadence is 2s, and the "
        "step is normally done within one poll."
    ),
)
async def get_report_status(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> AppDbReportStatusResponse:
    resolved = _require_job(transformation_id)
    progress = get_progress_tracker().get_progress(resolved)
    report_state = progress.get("report") or {}
    available = bool(report_state.get("available"))
    return AppDbReportStatusResponse(
        transformationId=resolved,
        status=str(report_state.get("status") or "PENDING"),
        available=available,
        path=report_state.get("path"),
        generatedAt=report_state.get("generatedAt"),
        fileSizeBytes=report_state.get("fileSizeBytes"),
        progressPercent=100 if available else 0,
        error=report_state.get("error"),
        steps=list(report_state.get("steps") or []),
    )


@router.get(
    "/{transformationId}/commit",
    summary="GitHub commit is not part of App+DB Job 3",
)
async def get_commit_status(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> None:
    _require_job(transformation_id)
    _commit_gone()


@router.post(
    "/{transformationId}/commit/retry",
    summary="GitHub commit is not part of App+DB Job 3",
)
async def retry_commit(
    request: AppDbCommitRetryRequest,
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> None:
    _require_job(transformation_id)
    _commit_gone()


@router.get(
    "/{transformationId}/artifacts",
    response_model=AppDbArtifactsResponse,
    summary="List Job 3 artifacts (report, transformed-code ZIP)",
)
async def list_transformation_artifacts(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> AppDbArtifactsResponse:
    resolved = _require_job(transformation_id)
    return AppDbArtifactsResponse(
        transformationId=resolved,
        jobId=get_progress_tracker().public_job_id(resolved),
        artifacts=artifact_ops.list_artifacts(resolved, load_report(resolved)),
    )


@router.get(
    "/{transformationId}/artifacts/download",
    summary="Download transformed code (ZIP of Job 3 modified files)",
    description="ZIP of every file Job 3 modified, plus the post-transformation report.",
)
async def download_transformed_code(
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> FileResponse:
    resolved = _require_job(transformation_id)
    archive = artifact_ops.zip_path(resolved)
    if not archive.is_file():
        report = load_report(resolved)
        if report:
            archive = artifact_ops.build_modified_files_zip(resolved, report) or archive
    if not archive.is_file():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "status": "error",
                "message": f"Transformed-code archive not available for {resolved}",
            },
        )
    max_bytes = settings.app_db_job3.zip_max_size_mb * 1024 * 1024
    size = archive.stat().st_size
    if size > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail={
                "status": "error",
                "message": (
                    f"Transformed-code archive is {size // (1024 * 1024)} MB, over the "
                    f"{settings.app_db_job3.zip_max_size_mb} MB download limit; "
                    "fetch it from the shared mount instead"
                ),
            },
        )
    # FileResponse streams the archive rather than buffering it in memory.
    return FileResponse(archive, filename=archive.name, media_type="application/zip")


@router.post(
    "/{transformationId}/commit-result",
    summary="GitHub commit is not part of App+DB Job 3",
)
async def record_commit_result(
    request: AppDbCommitResultRequest,
    transformation_id: str = PathParam(..., alias="transformationId", min_length=1),
) -> None:
    _require_job(transformation_id)
    _commit_gone()
