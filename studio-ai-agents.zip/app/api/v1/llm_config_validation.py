"""
LLM Configuration Validation API endpoints.

REST endpoints for validating LLM credentials before saving to database.
Supports validation for AWS Bedrock, IAM Roles, Portkey, Azure AI, and CAI.
"""
import logging
from typing import Dict, Any, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.services.llm_validator_service import LlmValidatorService, get_llm_validator_service
from app.core.exceptions import ValidationError

logger = logging.getLogger(__name__)

# Create router with prefix and tags
router = APIRouter(
    prefix="/api/v1/llm",
    tags=["llm-validation"],
    responses={
        500: {"description": "Internal server error"},
        400: {"description": "Bad request"}
    }
)


class LlmCredentialValidationRequest(BaseModel):
    """Request model for LLM credential validation."""
    tenant_id: str = Field(..., description="Tenant ID", example="TNT1001")

    # AWS Authentication Fields
    aws_access_key: Optional[str] = Field(None, description="AWS Access Key ID")
    aws_secret_key: Optional[str] = Field(None, description="AWS Secret Access Key")
    aws_region: Optional[str] = Field(None, description="AWS Region", example="us-east-1")
    llm_arn: Optional[str] = Field(None, description="LLM ARN for IAM role authentication")
    assumed_role_arn: Optional[str] = Field(None, description="Assumed role ARN")

    # Bedrock Configuration
    bedrock_api_key: Optional[str] = Field(None, description="Bedrock API Key")

    # Portkey Configuration
    portkey_api_key: Optional[str] = Field(None, description="Portkey API Key")
    portkey_base_url: Optional[str] = Field(None, description="Portkey Base URL")

    # Azure AI Configuration
    azure_ai_endpoint: Optional[str] = Field(None, description="Azure AI Endpoint URL")

    # Concierto Private LLM (CAI)
    cai_base_url: Optional[str] = Field(None, description="CAI Base URL")
    cai_api_key: Optional[str] = Field(None, description="CAI API Key")
    cai_model: Optional[str] = Field(None, description="CAI Model")

    # Model Configuration
    model_id: Optional[str] = Field(None, description="Model ID")
    provider_type: Optional[str] = Field(None, description="Provider type (aws-bedrock, portkey, azure, cai)")

    class Config:
        json_schema_extra = {
            "example": {
                "tenant_id": "TNT1001",
                "aws_access_key": "AKIA...",
                "aws_secret_key": "wJalr...",
                "aws_region": "us-east-1",
                "provider_type": "aws-bedrock"
            }
        }


class LlmCredentialValidationResponse(BaseModel):
    """Response model for LLM credential validation."""
    valid: bool = Field(..., description="Whether credentials are valid")
    auth_method: str = Field(..., description="Detected authentication method")
    message: str = Field(..., description="Validation message")
    tenant_id: str = Field(..., description="Tenant ID")
    error_details: Optional[str] = Field(None, description="Error details if validation failed")

    class Config:
        json_schema_extra = {
            "example": {
                "valid": True,
                "auth_method": "AWS Access Key + Secret",
                "message": "Credentials validated successfully",
                "tenant_id": "TNT1001",
                "error_details": None
            }
        }


@router.post(
    "/validate-credentials",
    summary="Validate LLM Credentials",
    description="Validates LLM credentials by testing connection to the configured service",
    response_model=LlmCredentialValidationResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"description": "Invalid credentials or validation failed"},
        500: {"description": "Internal server error"}
    }
)
async def validate_llm_credentials(
    request: LlmCredentialValidationRequest,
    validator_service: LlmValidatorService = Depends(get_llm_validator_service)
) -> LlmCredentialValidationResponse:
    """
    Validate LLM credentials before saving.

    Tests connection to the appropriate LLM service based on provided credentials.
    Supports AWS Bedrock, IAM Roles, Portkey, Azure AI, and Concierto Private LLM.

    Args:
        request: LLM credential validation request containing credentials
        validator_service: Service for credential validation

    Returns:
        LlmCredentialValidationResponse with validation result

    Raises:
        HTTPException: 400 if credentials are invalid, 500 for server errors

    Example:
        POST /api/v1/llm/validate-credentials
        {
            "tenant_id": "TNT1001",
            "aws_access_key": "AKIA...",
            "aws_secret_key": "wJalr...",
            "aws_region": "us-east-1"
        }
        Response:
        {
            "valid": true,
            "auth_method": "AWS Access Key + Secret",
            "message": "Credentials validated successfully",
            "tenant_id": "TNT1001"
        }
    """
    try:
        logger.info(f"Starting LLM credential validation for tenant: {request.tenant_id}")

        # Convert request to dict for service
        credentials_dict = request.model_dump(exclude_none=True)

        # Call validation service
        is_valid, auth_method, error_message = await validator_service.validate_credentials(
            credentials_dict,
            request.tenant_id
        )

        if is_valid:
            logger.info(f"Credential validation successful for tenant: {request.tenant_id}, "
                       f"auth_method: {auth_method}")
            return LlmCredentialValidationResponse(
                valid=True,
                auth_method=auth_method,
                message="Credentials validated successfully",
                tenant_id=request.tenant_id,
                error_details=None
            )
        else:
            logger.warning(f"Credential validation failed for tenant: {request.tenant_id}, "
                          f"error: {error_message}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "valid": False,
                    "auth_method": auth_method,
                    "message": f"Credential validation failed: {error_message}",
                    "tenant_id": request.tenant_id,
                    "error_details": error_message
                }
            )

    except ValidationError as e:
        logger.error(f"Validation error for tenant {request.tenant_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "valid": False,
                "auth_method": "Unknown",
                "message": f"Validation error: {str(e)}",
                "tenant_id": request.tenant_id,
                "error_details": str(e)
            }
        )
    except Exception as e:
        logger.error(f"Unexpected error validating credentials for tenant {request.tenant_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "valid": False,
                "auth_method": "Unknown",
                "message": "Internal server error during credential validation",
                "tenant_id": request.tenant_id,
                "error_details": str(e)
            }
        )


@router.get(
    "/health",
    summary="LLM Validation Health Check",
    description="Check if LLM validation service is running",
    response_description="Service status message",
    status_code=status.HTTP_200_OK
)
async def health_check() -> Dict[str, str]:
    """
    Health check endpoint for LLM validation service.

    Returns:
        Service status confirmation

    Example:
        GET /api/v1/llm/health
        Response: {"status": "LLM validation service is running"}
    """
    logger.info("LLM validation health check called")
    return {"status": "LLM validation service is running"}
