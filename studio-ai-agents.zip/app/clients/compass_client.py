"""
Compass client for Studio Core API integration.

Fetches connection configurations from Studio Core's Compass service
to determine AI provider settings (Bedrock vs Portkey).
"""
import logging
import threading
from typing import Optional, List, Dict, Any
from urllib.parse import urljoin

import httpx
from pydantic import BaseModel, Field

from app.core.config import get_settings
from app.core.exceptions import ConfigurationError, AuthenticationError
from app.core.resilience import with_resilience, compass_circuit_breaker


logger = logging.getLogger(__name__)
settings = get_settings()


# ============================================================================
# RESPONSE MODELS
# ============================================================================

class ConnectionConfiguration(BaseModel):
    """
    Connection configuration from Compass.

    Maps to Java's ConnectionConfiguration DTOs.
    """
    aws_region: Optional[str] = Field(default=None, alias="awsRegion")
    model_id: Optional[str] = Field(default=None, alias="modelId")
    portkey_api_key: Optional[str] = Field(default=None, alias="portkeyApiKey")
    portkey_base_url: Optional[str] = Field(default=None, alias="portkeyBaseUrl")
    debug_enabled: Optional[bool] = Field(default=False, alias="debugEnabled")
    cai_base_url: Optional[str] = Field(default=None, alias="caiBaseUrl")
    cai_api_key: Optional[str] = Field(default=None, alias="caiApiKey")
    cai_model: Optional[str] = Field(default=None, alias="caiModel")

    class Config:
        populate_by_name = True


class ConnectionData(BaseModel):
    """
    Connection data from Compass API response.
    """
    connection_id: Optional[str] = Field(None, alias="connectionId")
    component: Optional[str] = None
    provider_type: str = Field(..., alias="providerType")
    slug: Optional[str] = None  # Format: @virtual-key/model-id for Portkey, not present for Bedrock
    configuration: ConnectionConfiguration = Field(default_factory=ConnectionConfiguration)
    status: str = "enabled"  # "enabled" or "disabled"

    # Top-level fields (Azure AI Foundry response carries these alongside an
    # empty configuration{} block, so we accept them here too).
    model_id: Optional[str] = Field(None, alias="modelId")
    azure_ai_endpoint: Optional[str] = Field(None, alias="azureAiEndpoint")
    auth_method: Optional[str] = Field(None, alias="authMethod")

    # Portkey-specific fields
    portkey_api_key: Optional[str] = Field(None, alias="portkeyApiKey")
    portkey_base_url: Optional[str] = Field(None, alias="portkeyBaseUrl")
    debug_enabled: Optional[bool] = Field(None, alias="debugEnabled")
    model_parameters: Optional[dict] = Field(None, alias="modelParameters")

    # Concierto private LLM fields (providerType: concierto-private-llm). Upstream
    # sends these both here and inside configuration{}.
    cai_base_url: Optional[str] = Field(None, alias="caiBaseUrl")
    cai_api_key: Optional[str] = Field(None, alias="caiApiKey")
    cai_model: Optional[str] = Field(None, alias="caiModel")
    
    # Helper method for backward compatibility
    def is_active(self) -> bool:
        """Check if connection is active based on status field."""
        return self.status.lower() == "enabled"

    model_config = {
        "populate_by_name": True,
        # Exclude methods from serialization
        "ignored_types": (type(lambda: None),)
    }


class ApplicationStatusTask(BaseModel):
    """A single task entry in the applicationStatus response."""
    task: str
    percentage: int = 0
    subtask: str = ""


class ApplicationOverallStatus(BaseModel):
    """Overall status block in the applicationStatus response."""
    status: str = ""
    percentage: int = 0


class ApplicationStatusResponse(BaseModel):
    """Response body for POST /v1/app-studio/applicationStatus."""
    overall_status: ApplicationOverallStatus = Field(
        default_factory=ApplicationOverallStatus, alias="overallStatus"
    )
    tasks: List[ApplicationStatusTask] = Field(default_factory=list)

    class Config:
        populate_by_name = True


class ConnectionResponse(BaseModel):
    """
    Compass API response for connection queries.
    """
    status: str = "SUCCESS"  # "SUCCESS" or "ERROR"
    status_code: int = Field(200, alias="statusCode")
    message: Optional[str] = None
    data: Optional[List[ConnectionData]] = None
    errors: Optional[Any] = None
    timestamp: Optional[str] = None
    
    def is_success(self) -> bool:
        """Check if response was successful."""
        return self.status == "SUCCESS" and self.status_code == 200

    model_config = {
        "populate_by_name": True,
        "ignored_types": (type(lambda: None),)
    }


# ============================================================================
# COMPASS CLIENT
# ============================================================================

class CompassClient:
    """
    Client for Studio Core Compass API.

    Fetches AI provider connection configurations to enable dynamic
    provider selection (Bedrock vs Portkey) and credential management.

    Equivalent to Java's ConnectionRepository/ConnectionService integration.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        api_token: Optional[str] = None
    ):
        """
        Initialize Compass client.

        Args:
            base_url: Studio Core base URL (default from config)
            timeout: Request timeout in seconds (default from config)
            api_token: Optional API token for authentication

        Raises:
            ConfigurationError: If base_url is not configured
        """
        self.base_url = base_url or settings.studio_core.base_url
        self.timeout = timeout or settings.studio_core.timeout
        self.api_token = api_token

        if not self.base_url:
            raise ConfigurationError(
                message="Studio Core URL is not configured",
                details="Set STUDIO_CORE_URL environment variable"
            )

        # Ensure base_url ends with /
        if not self.base_url.endswith('/'):
            self.base_url += '/'

        logger.info(f"Compass client initialized: base_url={self.base_url}")

        # Create HTTP client with default headers
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        if self.api_token:
            self.headers["Authorization"] = f"Bearer {self.api_token}"

        # HTTP client with connection pooling (created on first use)
        self._http_client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_client()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - cleanup HTTP client."""
        await self.close()

    async def _ensure_client(self):
        """Ensure HTTP client is initialized with connection pooling."""
        if self._http_client is None:
            # Configure timeout with granular settings
            timeout_config = httpx.Timeout(
                connect=10.0,   # 10 seconds to establish connection
                read=float(self.timeout),  # Read timeout from config
                write=10.0,     # 10 seconds to write request
                pool=30.0       # 30 seconds for pool operations
            )

            # Configure connection limits for pooling
            limits = httpx.Limits(
                max_keepalive_connections=20,  # Reuse up to 20 connections
                max_connections=100,           # Maximum 100 total connections
                keepalive_expiry=30.0          # Keep connections alive for 30s
            )

            self._http_client = httpx.AsyncClient(
                timeout=timeout_config,
                limits=limits,
                headers=self.headers,
                follow_redirects=True
            )
            logger.debug("HTTP client initialized with connection pooling")

    async def close(self):
        """Close HTTP client and cleanup resources."""
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
            logger.debug("HTTP client closed")

    @with_resilience(
        retry_attempts=3,
        use_circuit_breaker=True,
        circuit_breaker=compass_circuit_breaker,
        timeout_seconds=settings.studio_core.timeout,  # Use Studio Core timeout (60s default)
        operation_name="compass_get_connections"
    )
    async def get_connections_by_component(
        self,
        component: str
    ) -> ConnectionResponse:
        """
        Fetch connection configurations by component name.

        This retrieves AI provider settings from Compass, allowing the
        application to dynamically select between Bedrock and Portkey
        based on the configured component.

        Args:
            component: Component name (e.g., "claude-code", "bedrock-primary")

        Returns:
            ConnectionResponse with provider configurations

        Raises:
            ConfigurationError: If request fails or response is invalid
            AuthenticationError: If authentication fails

        Example:
            >>> client = CompassClient()
            >>> response = await client.get_connections_by_component("claude-code")
            >>> if response.data:
            >>>     config = response.data[0]
            >>>     print(f"Provider: {config.provider_type}")
        """
        # url = urljoin(self.base_url, f"api/connections/component/{component}")
        url = urljoin(self.base_url, f"v1/compass/connections/by-component/{component}")
        logger.info(f"Fetching connections for component: {component}")
        logger.debug(f"Request URL: {url}")

        # Ensure HTTP client is initialized
        await self._ensure_client()

        try:
            response = await self._http_client.get(url)

            # Check HTTP status
            if response.status_code == 401:
                raise AuthenticationError(
                    message="Authentication failed for Studio Core API",
                    details=f"Status: {response.status_code}, URL: {url}"
                )
            elif response.status_code == 404:
                logger.warning(f"No connections found for component: {component}")
                return ConnectionResponse(
                    success=False,
                    message=f"No connections found for component: {component}",
                    data=[]
                )
            elif response.status_code >= 400:
                raise ConfigurationError(
                    message=f"Compass API request failed with status {response.status_code}",
                    details=f"URL: {url}, Response: {response.text}"
                )

            # Parse response
            response_data = response.json()
            connection_response = ConnectionResponse(**response_data)

            if connection_response.data:
                logger.info(
                    f"Retrieved {len(connection_response.data)} connection(s) "
                    f"for component: {component}"
                )
            else:
                logger.warning(f"No connection data for component: {component}")

            return connection_response

        except httpx.TimeoutException as e:
            error_msg = f"Timeout fetching connections for component: {component}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"Timeout: {self.timeout}s, URL: {url}"
            )
        except httpx.RequestError as e:
            error_msg = f"Request error fetching connections: {str(e)}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"URL: {url}, Error: {type(e).__name__}"
            )
        except Exception as e:
            error_msg = f"Unexpected error fetching connections: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ConfigurationError(
                message=error_msg,
                details=f"Component: {component}, Error type: {type(e).__name__}"
            )

    async def get_active_connection(
        self,
        component: str
    ) -> Optional[ConnectionData]:
        """
        Get the first active connection for a component.

        Convenience method that returns the first active connection
        from the list of connections for a component.

        Args:
            component: Component name

        Returns:
            First active ConnectionData, or None if no active connections found

        Raises:
            ConfigurationError: If request fails

        Example:
            >>> client = CompassClient()
            >>> connection = await client.get_active_connection("claude-code")
            >>> if connection:
            >>>     print(f"Using provider: {connection.provider_type}")
        """
        response = await self.get_connections_by_component(component)

        if not response.data:
            logger.warning(f"No connections found for component: {component}")
            return None

        # Find first active connection
        for connection in response.data:
            if connection.is_active():
                logger.info(
                    f"Found active connection: component={component}, "
                    f"provider={connection.provider_type}"
                )
                return connection

        logger.warning(f"No active connections for component: {component}")
        return None

    @with_resilience(
        retry_attempts=3,
        use_circuit_breaker=True,
        circuit_breaker=compass_circuit_breaker,
        timeout_seconds=settings.studio_core.timeout,
        operation_name="studio_core_get_application_status"
    )
    async def get_application_status(
        self,
        tenant_id: str,
        plan_id: int,
        step_id: str,
    ) -> ApplicationStatusResponse:
        """
        Fetch application transformation status from Studio Core.

        Args:
            tenant_id: Tenant identifier
            plan_id: Transformation plan id
            step_id: Transformation step id

        Returns:
            ApplicationStatusResponse with overall status and per-task breakdown

        Raises:
            ConfigurationError: If request fails or response is invalid
            AuthenticationError: If authentication fails
        """
        url = urljoin(self.base_url, "v1/app-studio/applicationStatus")
        payload = {"tenantId": tenant_id, "planId": plan_id, "stepId": step_id}
        logger.debug(f"Request URL: {url}, payload: {payload}")

        await self._ensure_client()

        try:
            response = await self._http_client.post(url, json=payload)

            if response.status_code == 401:
                raise AuthenticationError(
                    message="Authentication failed for Studio Core API",
                    details=f"Status: {response.status_code}, URL: {url}"
                )
            elif response.status_code >= 400:
                raise ConfigurationError(
                    message=f"Studio Core applicationStatus request failed with status {response.status_code}",
                    details=f"URL: {url}, Response: {response.text}"
                )

            return ApplicationStatusResponse(**response.json())

        except httpx.TimeoutException as e:
            error_msg = f"Timeout fetching application status: planId={plan_id}, stepId={step_id}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"Timeout: {self.timeout}s, URL: {url}"
            )
        except httpx.RequestError as e:
            error_msg = f"Request error fetching application status: {str(e)}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"URL: {url}, Error: {type(e).__name__}"
            )

    async def health_check(self) -> bool:
        """
        Check if Studio Core API is reachable.

        Returns:
            True if API is healthy, False otherwise

        Example:
            >>> client = CompassClient()
            >>> is_healthy = await client.health_check()
            >>> print(f"Studio Core healthy: {is_healthy}")
        """
        url = urljoin(self.base_url, "actuator/health")

        # Ensure HTTP client is initialized
        await self._ensure_client()

        try:
            response = await self._http_client.get(url)

            if response.status_code == 200:
                logger.info("Studio Core health check: OK")
                return True
            else:
                logger.warning(
                    f"Studio Core health check failed: status={response.status_code}"
                )
                return False

        except Exception as e:
            logger.error(f"Studio Core health check error: {str(e)}")
            return False


# ============================================================================
# MODULE-LEVEL INSTANCE WITH THREAD-SAFE SINGLETON
# ============================================================================

_default_client: Optional[CompassClient] = None
_client_lock = threading.Lock()


def get_compass_client() -> CompassClient:
    """
    Get or create default CompassClient instance (thread-safe singleton).

    Returns:
        CompassClient instance with default configuration

    Example:
        >>> client = get_compass_client()
        >>> connection = await client.get_active_connection("claude-code")
    """
    global _default_client

    # Fast path without locking for performance
    if _default_client is not None:
        return _default_client

    # Slow path with locking for thread safety
    with _client_lock:
        # Double-check pattern to avoid race conditions
        if _default_client is None:
            _default_client = CompassClient()

    return _default_client


async def cleanup_compass_client():
    """
    Cleanup default CompassClient instance.
    Should be called on application shutdown.
    """
    global _default_client

    if _default_client is not None:
        await _default_client.close()
        _default_client = None
