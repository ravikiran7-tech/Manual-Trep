"""
Path utilities for cross-platform path handling.

Includes Windows/WSL path conversion matching Java's SecureCommandExecutor.
"""
import platform
import re
import tempfile
from pathlib import Path, PureWindowsPath, PurePosixPath
from typing import Optional

from app.core.config import get_settings
from app.core.security import SecurityValidator


class PathUtils:
    """
    Path manipulation utilities for cross-platform support.

    Handles:
    - Windows to WSL path conversion (C:\\path -> /mnt/c/path)
    - WSL to Windows path conversion (/mnt/c/path -> C:\\path)
    - Path normalization
    - Platform detection
    """

    @staticmethod
    def is_windows_path(path: str) -> bool:
        """
        Check if path is a Windows path.

        Args:
            path: Path string

        Returns:
            True if Windows path (contains drive letter), False otherwise

        Example:
            >>> PathUtils.is_windows_path("C:\\Users\\test")
            True
            >>> PathUtils.is_windows_path("/home/user/test")
            False
        """
        # Check for drive letter pattern (C:, D:, etc.)
        return bool(re.match(r'^[A-Za-z]:', path))

    @staticmethod
    def is_wsl_path(path: str) -> bool:
        """
        Check if path is a WSL mount path.

        Args:
            path: Path string

        Returns:
            True if WSL mount path (/mnt/c/...), False otherwise

        Example:
            >>> PathUtils.is_wsl_path("/mnt/c/Users/test")
            True
            >>> PathUtils.is_wsl_path("/home/user/test")
            False
        """
        return path.startswith("/mnt/") and len(path) > 6

    @staticmethod
    def convert_to_wsl_path(windows_path: str) -> str:
        """
        Convert Windows path to WSL format.

        Converts: C:\\Users\\test -> /mnt/c/Users/test

        Args:
            windows_path: Windows path with drive letter

        Returns:
            WSL-formatted path

        Raises:
            ValueError: If path is not a valid Windows path

        Example:
            >>> PathUtils.convert_to_wsl_path("C:\\Users\\test\\file.txt")
            '/mnt/c/Users/test/file.txt'
        """
        if not PathUtils.is_windows_path(windows_path):
            raise ValueError(f"Not a Windows path: {windows_path}")

        # Extract drive letter
        drive_letter = windows_path[0].lower()

        # Remove drive letter and colon
        path_without_drive = windows_path[2:]

        # Convert backslashes to forward slashes
        unix_path = path_without_drive.replace('\\', '/')

        # Build WSL path
        wsl_path = f"/mnt/{drive_letter}{unix_path}"

        return wsl_path

    @staticmethod
    def convert_to_windows_path(wsl_path: str) -> str:
        """
        Convert WSL path to Windows format.

        Converts: /mnt/c/Users/test -> C:\\Users\\test

        Args:
            wsl_path: WSL mount path

        Returns:
            Windows-formatted path

        Raises:
            ValueError: If path is not a valid WSL mount path

        Example:
            >>> PathUtils.convert_to_windows_path("/mnt/c/Users/test")
            'C:\\Users\\test'
        """
        if not PathUtils.is_wsl_path(wsl_path):
            raise ValueError(f"Not a WSL mount path: {wsl_path}")

        # Extract drive letter (position 5: /mnt/c/)
        drive_letter = wsl_path[5].upper()

        # Extract path after /mnt/c
        path_part = wsl_path[6:]

        # Convert forward slashes to backslashes
        windows_path_part = path_part.replace('/', '\\')

        # Build Windows path
        windows_path = f"{drive_letter}:{windows_path_part}"

        return windows_path

    @staticmethod
    def normalize_path(path: str, target_platform: Optional[str] = None) -> str:
        """
        Normalize path for target platform.

        Args:
            path: Input path
            target_platform: Target platform ("windows", "linux", "wsl", or None for current)

        Returns:
            Normalized path for target platform

        Example:
            >>> PathUtils.normalize_path("C:\\Users\\test", "wsl")
            '/mnt/c/Users/test'
        """
        if target_platform is None:
            target_platform = "windows" if platform.system() == "Windows" else "linux"

        target_platform = target_platform.lower()

        # If already in correct format, return as-is
        if target_platform == "wsl":
            if PathUtils.is_wsl_path(path):
                return path
            elif PathUtils.is_windows_path(path):
                return PathUtils.convert_to_wsl_path(path)
            else:
                # Already a Linux path, return as-is
                return path

        elif target_platform == "windows":
            if PathUtils.is_windows_path(path):
                return path.replace('/', '\\')
            elif PathUtils.is_wsl_path(path):
                return PathUtils.convert_to_windows_path(path)
            else:
                # Linux path, cannot convert without drive info
                return path

        else:  # linux
            if PathUtils.is_windows_path(path):
                return PathUtils.convert_to_wsl_path(path)
            elif PathUtils.is_wsl_path(path):
                return path
            else:
                # Already a Linux path
                return path.replace('\\', '/')

    @staticmethod
    def get_current_platform() -> str:
        """
        Get current platform name.

        Returns:
            Platform name: "windows", "linux", or "macos"
        """
        system = platform.system()

        if system == "Windows":
            return "windows"
        elif system == "Linux":
            return "linux"
        elif system == "Darwin":
            return "macos"
        else:
            return system.lower()

    @staticmethod
    def is_absolute_path(path: str) -> bool:
        """
        Check if path is absolute.

        Works for both Windows and Linux paths.

        Args:
            path: Path string

        Returns:
            True if absolute path, False otherwise
        """
        # Windows path
        if PathUtils.is_windows_path(path):
            return True

        # Linux/WSL path
        return path.startswith('/')

    @staticmethod
    def join_paths(*paths: str) -> str:
        """
        Join path components safely.

        Args:
            *paths: Path components to join

        Returns:
            Joined path

        Example:
            >>> PathUtils.join_paths("/home", "user", "file.txt")
            '/home/user/file.txt'
        """
        if not paths:
            return ""

        # Use pathlib for safe joining
        result = Path(paths[0])
        for p in paths[1:]:
            result = result / p

        return str(result)

    @staticmethod
    def ensure_directory_exists(path: str) -> Path:
        """
        Ensure directory exists, create if necessary.

        Args:
            path: Directory path

        Returns:
            Path object for the directory

        Raises:
            OSError: If directory cannot be created
        """
        dir_path = Path(path)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @staticmethod
    def get_file_extension(path: str) -> str:
        """
        Get file extension from path.

        Args:
            path: File path

        Returns:
            File extension (including dot), or empty string if no extension

        Example:
            >>> PathUtils.get_file_extension("/path/to/file.txt")
            '.txt'
        """
        return Path(path).suffix

    @staticmethod
    def get_filename(path: str, with_extension: bool = True) -> str:
        """
        Get filename from path.

        Args:
            path: File path
            with_extension: Include extension (default True)

        Returns:
            Filename

        Example:
            >>> PathUtils.get_filename("/path/to/file.txt", with_extension=True)
            'file.txt'
            >>> PathUtils.get_filename("/path/to/file.txt", with_extension=False)
            'file'
        """
        p = Path(path)
        if with_extension:
            return p.name
        else:
            return p.stem

    @staticmethod
    def get_parent_directory(path: str) -> str:
        """
        Get parent directory of path.

        Args:
            path: File or directory path

        Returns:
            Parent directory path

        Example:
            >>> PathUtils.get_parent_directory("/path/to/file.txt")
            '/path/to'
        """
        return str(Path(path).parent)


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def to_wsl_path(windows_path: str) -> str:
    """
    Convenience function to convert Windows path to WSL.

    Args:
        windows_path: Windows path

    Returns:
        WSL path
    """
    return PathUtils.convert_to_wsl_path(windows_path)


def to_windows_path(wsl_path: str) -> str:
    """
    Convenience function to convert WSL path to Windows.

    Args:
        wsl_path: WSL path

    Returns:
        Windows path
    """
    return PathUtils.convert_to_windows_path(wsl_path)


def normalize_for_platform(path: str, platform_name: str) -> str:
    """
    Convenience function to normalize path for platform.

    Args:
        path: Input path
        platform_name: Target platform ("windows", "linux", "wsl")

    Returns:
        Normalized path
    """
    return PathUtils.normalize_path(path, platform_name)


def resolve_secure_work_directory(
    analysis_id: str,
    project_path: Optional[str] = None,
    *,
    category: str = "assessment-rules-batch",
) -> str:
    """
    Return a validated project path or a private per-analysis work directory.

    Avoids world-writable fallbacks such as ``/tmp`` (Sonar python:S5443).
    When no path is supplied, ``tempfile.mkdtemp`` creates an unpredictable
    directory name under the application workspace (not a public temp dir).
    """
    if project_path and project_path.strip():
        return project_path.strip()

    settings = get_settings()
    parent = Path(settings.workspace.base_path) / category / analysis_id
    parent.mkdir(parents=True, exist_ok=True)
    return tempfile.mkdtemp(prefix="work-", dir=str(parent))


def resolve_path_within_directory(
    file_path: str | Path,
    allowed_directory: str | Path,
    *,
    path_type: str = "file",
) -> Path:
    """
    Resolve ``file_path`` and ensure it lies under ``allowed_directory``.

    Prevents filesystem oracle / path traversal (Sonar python:S6549). Call this
    before ``exists()``, ``is_file()``, or ``open()`` on config-derived paths.
    """
    validated = SecurityValidator.validate_file_path_within_directory(
        str(file_path),
        str(allowed_directory),
        path_type,
    )
    return Path(validated)
