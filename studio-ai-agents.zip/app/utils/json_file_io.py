"""
Secure JSON file reads (Sonar S2083 / S6549).

Uses a secure-by-design API: callers pass a **filename only** plus a trusted
``allowed_directory``. Paths are never built from untrusted path strings.
"""
import json
import re
from pathlib import Path
from typing import Any, Optional

_SAFE_FILENAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def _validated_filename(filename: str) -> str:
    """Accept a plain filename; reject directories, separators, and traversal."""
    name = (filename or "").strip()
    if not name or not _SAFE_FILENAME.match(name):
        raise ValueError(
            f"Invalid filename {filename!r}; only a single file name is allowed"
        )
    return name


def _read_json_file(
    filename: str,
    *,
    allowed_directory: str | Path,
) -> Optional[dict[str, Any]]:
    """
    Read a JSON object from ``filename`` inside ``allowed_directory``.

    ``filename`` must be a single name (e.g. ``settings.json``), not a path.
    """
    allowed_root = Path(allowed_directory).resolve()
    safe_name = _validated_filename(filename)
    safe_path = (allowed_root / safe_name).resolve()

    try:
        safe_path.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(
            f"Path traversal detected: filename {filename!r} "
            f"is outside allowed directory '{allowed_root}'"
        ) from exc

    if not safe_path.is_file():
        return None

    try:
        with safe_path.open(encoding="utf-8") as fh:
            data = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return None

    return data if isinstance(data, dict) else None


def read_json_file(
    filename: str,
    *,
    allowed_directory: str | Path,
) -> Optional[dict[str, Any]]:
    """Public alias for :func:`_read_json_file`."""
    return _read_json_file(filename, allowed_directory=allowed_directory)
