"""
Encryption utilities for credential decryption.
Compatible with Java's EncryptionUtils class.

Uses AES-GCM encryption with Base64 encoding.
"""
import base64
import hashlib
import logging
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.backends import default_backend

from app.core.config import get_settings
from app.core.exceptions import ConfigurationError


logger = logging.getLogger(__name__)
settings = get_settings()


class EncryptionUtils:
    """
    Encryption/decryption utilities compatible with Java's EncryptionUtils.

    Supports:
    - AES-GCM encryption/decryption with 128-bit authentication tag
    - Base64 encoding for encrypted data
    - IV prepended to encrypted data (12 bytes for GCM)
    """

    # GCM IV length (96 bits / 12 bytes)
    IV_LENGTH = 12

    # GCM tag length (128 bits / 16 bytes)
    TAG_LENGTH = 16

    # Minimum encrypted data length (IV + tag + at least 1 byte data)
    MIN_ENCRYPTED_LENGTH = IV_LENGTH + TAG_LENGTH

    def __init__(self, encryption_key: Optional[str] = None):
        """
        Initialize encryption utils with AES key.

        Args:
            encryption_key: Base64-encoded AES key (16, 24, or 32 bytes)
                           If not provided, uses key from settings

        Raises:
            ConfigurationError: If key is missing or invalid
        """
        key = encryption_key or settings.encryption_key

        if not key:
            raise ConfigurationError(
                message="AES encryption key is missing",
                details="Set ENCRYPTION_KEY environment variable"
            )

        try:
            # Decode Base64 key
            self.key = base64.b64decode(key)

            # Validate key length (128, 192, or 256 bits)
            if len(self.key) not in [16, 24, 32]:
                raise ConfigurationError(
                    message=f"Invalid AES key length: {len(self.key)} bytes",
                    details="Key must be 16, 24, or 32 bytes (128, 192, or 256 bits)"
                )

            logger.info(f"Encryption initialized with {len(self.key) * 8}-bit key")

        except base64.binascii.Error as e:
            raise ConfigurationError(
                message="Invalid AES key format",
                details=f"Key must be valid Base64: {str(e)}"
            )

    def decrypt(self, encrypted_data: str) -> Optional[str]:
        """
        Decrypt data encrypted with Java's EncryptionUtils.encrypt().

        The encrypted data format is: [12-byte IV][encrypted data with GCM tag]
        All Base64-encoded.

        Args:
            encrypted_data: Base64-encoded encrypted string

        Returns:
            Decrypted plaintext string, or None if input is None

        Raises:
            ValueError: If decryption fails

        Example:
            >>> utils = EncryptionUtils()
            >>> encrypted = "base64_encrypted_data_here"
            >>> plaintext = utils.decrypt(encrypted)
        """
        if encrypted_data is None:
            return None

        if not encrypted_data:
            return ""

        try:
            # Decode Base64
            encrypted_with_iv = base64.b64decode(encrypted_data)

            if len(encrypted_with_iv) < self.MIN_ENCRYPTED_LENGTH:
                raise ValueError(
                    f"Encrypted data too short: {len(encrypted_with_iv)} bytes. "
                    f"Minimum is {self.MIN_ENCRYPTED_LENGTH} bytes (IV + tag + data)"
                )

            # Extract IV (first 12 bytes)
            iv = encrypted_with_iv[:self.IV_LENGTH]

            # Extract encrypted data (remaining bytes, includes GCM tag)
            ciphertext = encrypted_with_iv[self.IV_LENGTH:]

            # Decrypt using AES-GCM
            aesgcm = AESGCM(self.key)
            plaintext_bytes = aesgcm.decrypt(iv, ciphertext, None)

            # Convert bytes to string
            plaintext = plaintext_bytes.decode('utf-8')

            logger.debug(f"Successfully decrypted {len(encrypted_data)} bytes")
            return plaintext

        except base64.binascii.Error as e:
            raise ValueError(f"Invalid Base64 encoding: {str(e)}")
        except Exception as e:
            logger.error(f"Decryption failed: {str(e)}")
            raise ValueError(f"Failed to decrypt data: {str(e)}")

    def encrypt(self, plaintext: str) -> Optional[str]:
        """
        Encrypt data compatible with Java's EncryptionUtils.decrypt().

        Generates random IV, encrypts with AES-GCM, prepends IV to output.

        Args:
            plaintext: String to encrypt

        Returns:
            Base64-encoded encrypted string (IV + ciphertext), or None if input is None

        Raises:
            ValueError: If encryption fails

        Example:
            >>> utils = EncryptionUtils()
            >>> encrypted = utils.encrypt("my secret data")
        """
        if plaintext is None:
            return None

        if not plaintext:
            return ""

        try:
            # Generate random IV
            import os
            iv = os.urandom(self.IV_LENGTH)

            # Encrypt using AES-GCM
            aesgcm = AESGCM(self.key)
            ciphertext = aesgcm.encrypt(iv, plaintext.encode('utf-8'), None)

            # Prepend IV to ciphertext
            encrypted_with_iv = iv + ciphertext

            # Encode as Base64
            encrypted_b64 = base64.b64encode(encrypted_with_iv).decode('ascii')

            logger.debug(f"Successfully encrypted {len(plaintext)} bytes")
            return encrypted_b64

        except Exception as e:
            logger.error(f"Encryption failed: {str(e)}")
            raise ValueError(f"Failed to encrypt data: {str(e)}")

    def is_encrypted(self, data: str) -> bool:
        """
        Check if data appears to be encrypted.

        Tests if data is valid Base64 and has minimum length for encrypted data.

        Args:
            data: String to check

        Returns:
            True if data appears encrypted, False otherwise

        Example:
            >>> utils = EncryptionUtils()
            >>> utils.is_encrypted("plaintext")
            False
            >>> utils.is_encrypted("base64_encrypted_data_with_iv_and_tag")
            True
        """
        if not data:
            return False

        try:
            # Try to decode as Base64
            decoded = base64.b64decode(data)

            # Check minimum length (IV + tag + at least 1 byte)
            return len(decoded) >= self.MIN_ENCRYPTED_LENGTH

        except Exception:
            # If it's not valid Base64, it's not encrypted
            return False


def decrypt_portkey_credentials(encrypted_api_key: str, encryption_key: Optional[str] = None) -> str:
    """
    Decrypt Portkey API key from Compass connection configuration.

    Convenience function for decrypting Portkey credentials.

    Args:
        encrypted_api_key: Base64-encoded encrypted API key
        encryption_key: Optional encryption key (uses settings if not provided)

    Returns:
        Decrypted API key

    Raises:
        ValueError: If decryption fails

    Example:
        >>> api_key = decrypt_portkey_credentials(encrypted_key_from_compass)
    """
    utils = EncryptionUtils(encryption_key)
    return utils.decrypt(encrypted_api_key)


# Module-level instance for convenience
_default_utils: Optional[EncryptionUtils] = None


def get_encryption_utils() -> EncryptionUtils:
    """
    Get or create default EncryptionUtils instance.

    Returns:
        EncryptionUtils instance with default encryption key
    """
    global _default_utils
    if _default_utils is None:
        _default_utils = EncryptionUtils()
    return _default_utils


def is_base64_string(value: str) -> bool:
    """Java-style Base64 check (IllegalArgumentException equivalent)."""
    if not value or not value.strip():
        return False
    try:
        s = value.strip()
        try:
            base64.b64decode(s, validate=True)
        except TypeError:
            base64.b64decode(s)
        return True
    except (base64.binascii.Error, ValueError):
        return False


def decrypt_gcm_values(encrypted_b64: str, passphrase: str) -> str:
    """
    Decrypt values encrypted like Rules Management ``EncryptionUtils.decryptGCMValues``.

    Uses SHA-256(UTF-8 passphrase) as a 32-byte AES-256 key, then the same
    wire format as :class:`EncryptionUtils`: Base64( IV_12_bytes || ciphertext+tag ).

    If your Java stack uses a different KDF, align it here or use plaintext credentials /
    :func:`get_encryption_utils` (``ENCRYPTION_KEY``) for encryption instead.
    """
    if encrypted_b64 is None:
        return ""
    if not (passphrase or "").strip():
        raise ValueError("passphrase is required for decrypt_gcm_values")
    key_bytes = hashlib.sha256(passphrase.encode("utf-8")).digest()
    key_b64 = base64.b64encode(key_bytes).decode("ascii")
    utils = EncryptionUtils(encryption_key=key_b64)
    out = utils.decrypt(encrypted_b64.strip())
    return out if out is not None else ""


def decrypt_secret_if_base64_gcm(
    value: str,
    *,
    passphrase: Optional[str] = None,
) -> str:
    """
    Match Rules Management ``decryptAndSet``: valid Base64 may be decrypted.

    1. If ``passphrase`` is set, try ``decrypt_gcm_values`` (SHA-256-derived AES key).
    2. If ciphertext matches :meth:`EncryptionUtils.is_encrypted`, try ``ENCRYPTION_KEY``.
    3. Otherwise return the original string (plaintext or unrelated Base64).
    """
    if value is None:
        return ""
    s = str(value).strip()
    if not s:
        return value
    if not is_base64_string(s):
        return value
    util = get_encryption_utils()
    if passphrase and passphrase.strip():
        try:
            return decrypt_gcm_values(s, passphrase)
        except Exception:
            pass
    if util.is_encrypted(s):
        return util.decrypt(s) or ""
    return value
