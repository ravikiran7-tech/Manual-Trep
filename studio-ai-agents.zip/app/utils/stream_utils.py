"""
Stream utilities for parsing Claude CLI stream-json output files.

Handles JSONL (JSON Lines) format parsing and event extraction.
"""
import json
import logging
import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple


logger = logging.getLogger(__name__)


def _extract_single_json_block_robust(text: str, start: Optional[int] = 0) -> Optional[Tuple[str, int]]:
    """
    Extract the next ```json ... ``` block at or after `start`, using
    bracket/quote-aware scanning.

    Does not treat triple backticks inside JSON string values as the block end,
    so embedded content (e.g. file bodies with backticks) is handled correctly.

    Args:
        text: Markdown text that may contain a ```json code block
        start: Offset to begin searching from

    Returns:
        Tuple of (JSON substring, offset to resume searching from), or None
        if no fenced block is found from `start` onward.
    """
    match = re.search(r'```json\s*', text[start:], re.IGNORECASE)
    if not match:
        return None
    i = start + match.end()
    n = len(text)
    while i < n and text[i] in ' \t\n\r':
        i += 1
    if i >= n or text[i] not in '{[':
        return None
    content_start = i
    depth = 0
    in_string = False
    escape_next = False
    while i < n:
        c = text[i]
        if escape_next:
            escape_next = False
            i += 1
            continue
        if in_string:
            if c == '\\':
                escape_next = True
            elif c == '"':
                in_string = False
            i += 1
            continue
        if c == '"':
            in_string = True
            i += 1
            continue
        if c in '{[':
            depth += 1
            i += 1
            continue
        if c in '}]':
            depth -= 1
            if depth == 0:
                return text[content_start : i + 1], i + 1
            i += 1
            continue
        i += 1
    return None


class StreamParser:
    """
    Parser for Claude CLI stream-json files.

    Handles:
    - JSONL format parsing (one JSON object per line)
    - Event extraction and filtering
    - Metadata extraction
    - Error handling for malformed JSON
    """

    @staticmethod
    def parse_stream_file(file_path: Path) -> List[Dict[str, Any]]:
        """
        Parse stream-json file into list of events.

        Args:
            file_path: Path to stream-json file

        Returns:
            List of event dictionaries

        Raises:
            FileNotFoundError: If file doesn't exist
            json.JSONDecodeError: If JSON is malformed
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Stream file not found: {file_path}")

        events = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()

                    # Skip empty lines
                    if not line:
                        continue

                    try:
                        event = json.loads(line)
                        events.append(event)
                    except json.JSONDecodeError as e:
                        logger.warning(
                            f"Failed to parse JSON at line {line_num} in {file_path}: {e}"
                        )
                        # Continue parsing other lines
                        continue

            logger.info(f"Parsed {len(events)} events from {file_path}")
            return events

        except Exception as e:
            logger.error(f"Error reading stream file {file_path}: {e}")
            raise

    @staticmethod
    def extract_final_result(events: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Extract final result event from stream.

        Args:
            events: List of stream events

        Returns:
            Result event dict, or None if not found
        """
        for event in reversed(events):
            if event.get("type") == "result":
                return event

        return None

    @staticmethod
    def extract_assistant_messages(events: List[Dict[str, Any]]) -> List[str]:
        """
        Extract all assistant text messages from stream.

        Args:
            events: List of stream events

        Returns:
            List of assistant message texts
        """
        messages = []

        for event in events:
            if event.get("type") == "assistant" and event.get("subtype") == "text_delta":
                text = event.get("text", "")
                if text:
                    messages.append(text)
                    logger.info(f"Events Text: {text} \n\n")

        return messages

    @staticmethod
    def extract_full_assistant_response(events: List[Dict[str, Any]]) -> str:
        """
        Extract complete assistant response by concatenating text deltas.

        Args:
            events: List of stream events

        Returns:
            Complete assistant response text
        """
        messages = StreamParser.extract_assistant_messages(events)
        return "".join(messages)

    @staticmethod
    def extract_tool_use_events(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract tool use events from stream.

        Args:
            events: List of stream events

        Returns:
            List of tool use events
        """
        tool_events = []

        for event in events:
            if event.get("type") == "tool_use":
                tool_events.append(event)

        return tool_events

    @staticmethod
    def extract_metadata(events: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract metadata from stream events.

        Includes:
        - Token usage (input/output tokens)
        - Stop reason
        - Duration
        - Costs (if available)

        Args:
            events: List of stream events

        Returns:
            Metadata dictionary
        """
        metadata = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
            "stop_reason": None,
            "is_error": False,
            "error_message": None
        }

        # Extract from result event
        result = StreamParser.extract_final_result(events)
        if result:
            metadata["input_tokens"] = result.get("input_tokens", 0)
            metadata["output_tokens"] = result.get("output_tokens", 0)
            metadata["total_tokens"] = metadata["input_tokens"] + metadata["output_tokens"]
            metadata["stop_reason"] = result.get("stop_reason")
            metadata["is_error"] = result.get("is_error", False)

        # Check for error events
        for event in events:
            if event.get("type") == "error":
                metadata["is_error"] = True
                metadata["error_message"] = event.get("error", "Unknown error")
                break

        return metadata

    @staticmethod
    def is_stream_successful(events: List[Dict[str, Any]]) -> bool:
        """
        Check if stream completed successfully.

        Args:
            events: List of stream events

        Returns:
            True if successful, False if error occurred
        """
        metadata = StreamParser.extract_metadata(events)
        return not metadata["is_error"]

    @staticmethod
    def extract_json_blocks(text: str) -> List[str]:
        """
        Extract JSON code blocks from markdown text.

        Uses bracket/quote-aware extraction first so that triple backticks
        inside JSON string values (e.g. embedded file content) do not truncate
        the block. Falls back to regex-based extraction if the robust path
        does not yield valid JSON.

        Note: only the first fenced JSON block is extracted via the robust
        path. Use `extract_all_json_blocks` to extract every block in text
        containing multiple ```json fences.

        Args:
            text: Markdown text containing JSON blocks

        Returns:
            List of JSON block contents
        """
        result = _extract_single_json_block_robust(text, 0)
        if result is not None:
            robust_block, _ = result
            try:
                json.loads(robust_block)
                return [robust_block]
            except json.JSONDecodeError:
                pass
        pattern = r'```json\s*(.*?)\s*```'
        matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
        return matches

    @staticmethod
    def extract_all_json_blocks(text: str) -> List[str]:
        """
        Extract every JSON code block from markdown text.

        Repeatedly applies bracket/quote-aware extraction so that triple
        backticks inside JSON string values (e.g. embedded file content) do
        not truncate a block or get mistaken for another block's fence.
        Falls back to regex-based extraction only if no valid blocks are
        found via the robust scan.

        Args:
            text: Markdown text containing one or more JSON blocks

        Returns:
            List of JSON block contents, in order of appearance
        """
        blocks = []
        offset = 0
        while True:
            result = _extract_single_json_block_robust(text, offset)
            if result is None:
                break
            block, offset = result
            try:
                json.loads(block)
                blocks.append(block)
                logger.info(f"Block: {block}, Blocks: {len(blocks)}")
            except json.JSONDecodeError:
                pass

        if blocks:
            return blocks

        pattern = r'```json\s*(.*?)\s*```'
        logger.info("Parsing JSON blocks using pattern...")
        return re.findall(pattern, text, re.DOTALL | re.IGNORECASE)

    @staticmethod
    def parse_json_block(text: str) -> Optional[Dict[str, Any]]:
        """
        Parse first JSON block from markdown text.

        Args:
            text: Markdown text containing JSON block

        Returns:
            Parsed JSON dict, or None if no valid JSON found
        """
        json_blocks = StreamParser.extract_json_blocks(text)

        if not json_blocks:
            logger.warning("No JSON blocks found in text")
            return None

        for block in json_blocks:
            try:
                return json.loads(block)
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse JSON block: {e}")
                continue

        return None

    @staticmethod
    def filter_events_by_type(
        events: List[Dict[str, Any]],
        event_type: str,
        subtype: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Filter events by type and optional subtype.

        Args:
            events: List of stream events
            event_type: Event type to filter (e.g., "assistant", "user", "system")
            subtype: Optional subtype to filter (e.g., "text_delta")

        Returns:
            Filtered list of events
        """
        filtered = []

        for event in events:
            if event.get("type") == event_type:
                if subtype is None or event.get("subtype") == subtype:
                    filtered.append(event)

        return filtered

    @staticmethod
    def extract_costs(events: List[Dict[str, Any]]) -> Optional[Dict[str, float]]:
        """
        Extract cost information from stream events.

        Args:
            events: List of stream events

        Returns:
            Cost dictionary with input_cost, output_cost, total_cost, or None
        """
        result = StreamParser.extract_final_result(events)

        if not result:
            return None

        costs = {}
        if "input_cost" in result:
            costs["input_cost"] = result["input_cost"]
        if "output_cost" in result:
            costs["output_cost"] = result["output_cost"]
        if "total_cost" in result:
            costs["total_cost"] = result["total_cost"]

        return costs if costs else None


# ============================================================================
# STREAM EVENT BUILDERS
# ============================================================================

class StreamEventBuilder:
    """
    Builder for creating stream events.

    Useful for testing and stream file generation.
    """

    @staticmethod
    def create_system_event(subtype: str = "init") -> Dict[str, Any]:
        """Create system event."""
        import time
        return {
            "type": "system",
            "subtype": subtype,
            "timestamp": int(time.time() * 1000)
        }

    @staticmethod
    def create_assistant_text_delta(text: str) -> Dict[str, Any]:
        """Create assistant text delta event."""
        import time
        return {
            "type": "assistant",
            "subtype": "text_delta",
            "text": text,
            "timestamp": int(time.time() * 1000)
        }

    @staticmethod
    def create_result_event(
        input_tokens: int,
        output_tokens: int,
        stop_reason: str = "end_turn",
        is_error: bool = False
    ) -> Dict[str, Any]:
        """Create result event."""
        import time
        return {
            "type": "result",
            "is_error": is_error,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "stop_reason": stop_reason,
            "timestamp": int(time.time() * 1000)
        }

    @staticmethod
    def create_error_event(error_message: str) -> Dict[str, Any]:
        """Create error event."""
        import time
        return {
            "type": "error",
            "error": error_message,
            "timestamp": int(time.time() * 1000)
        }


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def parse_stream_file(file_path: Path) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Parse stream file and extract events + metadata.

    Convenience function combining parsing and metadata extraction.

    Args:
        file_path: Path to stream-json file

    Returns:
        Tuple of (events list, metadata dict)
    """
    parser = StreamParser()
    events = parser.parse_stream_file(file_path)
    metadata = parser.extract_metadata(events)

    return events, metadata


def extract_response_from_stream(file_path: Path) -> str:
    """
    Extract complete assistant response from stream file.

    Args:
        file_path: Path to stream-json file

    Returns:
        Complete assistant response text
    """
    parser = StreamParser()
    events = parser.parse_stream_file(file_path)
    return parser.extract_full_assistant_response(events)
