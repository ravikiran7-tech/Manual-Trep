"""
Utilities for merging cloud-readiness fix JSON results.

Each entry in the input array is a JSON string produced by a single rule-fix
run. `merge_fix_result` combines all of them into a single consolidated JSON
object.
"""
import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class FixResultMerger:
    """
    Merges a list of cloud-readiness fix result JSON strings into one object.

    Merge rules:
    - application.duration: durations (e.g. "2m 15s") are summed together.
      Other application fields are taken from the first block.
    - executiveSummary: all numeric fields are summed across blocks;
      successRate is recomputed from the summed violation counts.
    - systemRulesResult / customRulesResult: entries with the same ruleName
      are combined (their numeric fields summed); new ruleNames are appended
      as new entries. Rules whose ruleId starts with "custom" go into
      customRulesResult; all others go into systemRulesResult.
    - fileModifications: entries with the same filePath are merged into one
      (numeric fields summed, list fields concatenated); entries with a new
      filePath are appended as new entries.
    - metadata: compared across blocks; if identical, kept once. If blocks
      differ, the first block's metadata is used and a warning is recorded.
    """

    _DURATION_PATTERN = re.compile(
        r'(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:(\d+)s)?', re.IGNORECASE
    )

    @classmethod
    def merge(cls, json_array: List[str]) -> Dict[str, Any]:
        """
        Merge a list of fix-result JSON strings into a single JSON object.

        Args:
            json_array: List of JSON strings, each a cloud-readiness fix result.

        Returns:
            A single merged dict combining all blocks.

        Raises:
            ValueError: If json_array is empty or contains no valid JSON.
        """
        parsed_blocks = []
        for block in json_array:
            try:
                parsed_blocks.append(json.loads(block))
            except json.JSONDecodeError:
                continue

        if not parsed_blocks:
            raise ValueError("No valid JSON blocks found to merge")

        system_rules, custom_rules = cls._merge_rules_results(parsed_blocks)
        return {
            "application": cls._merge_application(parsed_blocks),
            "executiveSummary": cls._merge_executive_summary(parsed_blocks),
            "systemRulesResult": system_rules,
            "customRulesResult": custom_rules,
            "fileModifications": cls._merge_file_modifications(parsed_blocks),
            "metadata": cls._merge_metadata(parsed_blocks),
        }

    @classmethod
    def _parse_duration_to_seconds(cls, duration: str) -> int:
        match = cls._DURATION_PATTERN.match(duration.strip())
        if not match:
            return 0
        hours, minutes, seconds = (int(g) if g else 0 for g in match.groups())
        return hours * 3600 + minutes * 60 + seconds

    @staticmethod
    def _format_seconds_to_duration(total_seconds: int) -> str:
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        parts = []
        if hours:
            parts.append(f"{hours}h")
        if minutes:
            parts.append(f"{minutes}m")
        parts.append(f"{seconds}s")
        return " ".join(parts)

    @classmethod
    def _merge_application(cls, blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
        first_application = blocks[0].get("application", {}) or {}
        merged_application = dict(first_application)

        total_seconds = 0
        for block in blocks:
            duration = (block.get("application") or {}).get("duration")
            if duration:
                total_seconds += cls._parse_duration_to_seconds(duration)

        merged_application["duration"] = cls._format_seconds_to_duration(total_seconds)
        merged_application["completedOn"] = datetime.now(timezone.utc).isoformat()
        return merged_application

    @staticmethod
    def _merge_executive_summary(blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
        summed_fields = [
            "blockerTypes",
            "totalRulesProcessed",
            "totalViolations",
            "violationsResolved",
            "violationsFailed",
            "filesModified",
        ]

        merged_summary = {field: 0 for field in summed_fields}
        for block in blocks:
            summary = block.get("executiveSummary", {}) or {}
            for field in summed_fields:
                merged_summary[field] += summary.get(field, 0) or 0

        total_violations = merged_summary["totalViolations"]
        violations_resolved = merged_summary["violationsResolved"]
        merged_summary["successRate"] = (
            round((violations_resolved / total_violations) * 100, 2)
            if total_violations else 0
        )

        return merged_summary

    @staticmethod
    def _merge_rules_results(
        blocks: List[Dict[str, Any]]
    ) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        merged_by_rule_name: Dict[str, Dict[str, Any]] = {}
        rule_name_order: List[str] = []

        for block in blocks:
            for rule_result in block.get("rulesResults", []) or []:
                rule_name = rule_result.get("ruleName")

                if rule_name not in merged_by_rule_name:
                    merged_by_rule_name[rule_name] = dict(rule_result)
                    rule_name_order.append(rule_name)
                    continue

                existing = merged_by_rule_name[rule_name]
                for field in ("filesImpacted", "violations", "success", "failed"):
                    existing[field] = existing.get(field, 0) + rule_result.get(field, 0)

        all_results = [merged_by_rule_name[rule_name] for rule_name in rule_name_order]
        system_rules = [r for r in all_results if not (r.get("ruleId") or "").lower().startswith("custom")]
        custom_rules = [r for r in all_results if (r.get("ruleId") or "").lower().startswith("custom")]
        return system_rules, custom_rules

    @staticmethod
    def _merge_file_modifications(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        merged_by_file_path: Dict[str, Dict[str, Any]] = {}
        file_path_order: List[str] = []

        for block in blocks:
            for modification in block.get("fileModifications", []) or []:
                file_path = modification.get("filePath")

                if file_path not in merged_by_file_path:
                    merged_by_file_path[file_path] = dict(modification)
                    file_path_order.append(file_path)
                    continue

                existing = merged_by_file_path[file_path]
                for key, value in modification.items():
                    if key == "filePath":
                        continue
                    if isinstance(value, (int, float)) and not isinstance(value, bool):
                        existing[key] = existing.get(key, 0) + value
                    elif isinstance(value, list):
                        existing[key] = (existing.get(key) or []) + value

        return [merged_by_file_path[file_path] for file_path in file_path_order]

    @staticmethod
    def _merge_metadata(blocks: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        first_metadata = blocks[0].get("metadata")
        if first_metadata is None:
            return None

        all_identical = all(
            block.get("metadata") == first_metadata for block in blocks
        )
        if not all_identical:
            merged_metadata = dict(first_metadata)
            merged_metadata["_mergeWarning"] = (
                "metadata differed across merged blocks; showing first block's metadata"
            )
            return merged_metadata

        return first_metadata


def merge_fix_result(json_array: List[str]) -> Dict[str, Any]:
    """
    Merge a list of cloud-readiness fix result JSON strings into one object.

    Args:
        json_array: List of JSON strings, each a cloud-readiness fix result.

    Returns:
        A single merged dict combining application, executiveSummary,
        systemRulesResult, customRulesResult, fileModifications, and metadata
        across all blocks.
    """
    return FixResultMerger.merge(json_array)
