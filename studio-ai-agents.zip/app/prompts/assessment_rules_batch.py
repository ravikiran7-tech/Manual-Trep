"""
Prompts for batch assessment-rule schema generation.

Each input rule may use a different domain and language; the model must align
each output object with the corresponding numbered input rule.
"""
from typing import List

# Compact system prompt for single-turn schema generation (no tools / no agentic loop).
ASSESSMENT_RULES_BATCH_SYSTEM_PROMPT = r"""
You generate assessment and detection rule schemas from catalog metadata.

Rules:
- Return ONLY a valid JSON array matching the user message (no prose outside JSON).
- Each element must have ruleId, detectionSchema, and assessmentSchema.
- detectionSchema must use "parser": "REGEX" and put regex strings in detectionCriteria.searchPattern.
- detectionCriteria.fileType must list EVERY extension that any searchPattern targets — if a pattern
  targets an XML/YAML/properties/JSON config construct, fileType must include those extensions too,
  not just the primary language extension. A pattern whose file type is missing will never be scanned.
- If a rule includes an example snippet, derive at least one searchPattern directly from it, then add
  patterns for its structural variations (not just a copy of the literal example).
- Assume case-sensitive matching by default; add inline "(?i)" where the target (config keys,
  annotations, XML tags) commonly varies in case across codebases.
- Every searchPattern is a JSON string, so every backslash needs JSON escaping — but first decide
  what the backslash means AT THE REGEX LEVEL, then JSON-escape that result:
  - Regex metacharacter/escape (e.g. \d, \s, \w, \.): one backslash at the regex level, so the JSON
    text contains two ("\\d").
  - Literal backslash matched as DATA (Windows path separators like C:\Logs\, a connection-string
    fragment like \SQLEXPRESS, a UNC path \\server\share): at the regex level a literal backslash
    must itself be escaped as "\\", and that string then needs JSON escaping too — so the JSON text
    must contain FOUR backslashes for each single literal backslash you intend to match. Two
    backslashes in the JSON text under-escapes it and the pattern will fail to match real source.
  - Also escape literal double quotes so the array stays valid JSON.
- detectionCriteria.fileType values are file EXTENSIONS, not language names — they will not always
  match the language.name string. Use the extension actually used by that language's source files
  (e.g. language "csharp"/"c#" -> fileType "cs", not "csharp"; "vb.net" -> "vb"; "c++" -> "cpp"/"h";
  "python" -> "py"). Never invent an extension that just repeats the language name unless that IS the
  real extension (e.g. "java" -> "java").
- Do not emit pathwayImpacts. Remediation, when present, is assessmentSchema.remediation only, using the domain shapes in the user message.
- Do not use tools, file operations, or shell commands.
- You may wrap JSON in ```json ... ``` fences.
""".strip()

# JSON structure example shown to the model (instructional placeholders in angle brackets).
# Top-level shape matches Java AssessmentRuleBatchItem: ruleId + detectionSchema + assessmentSchema.
ASSESSMENT_RULES_SCHEMA_EXAMPLE = r"""
{
  "ruleId": "<must equal ruleId from the corresponding input rule — DO NOT INVENT>",
  "detectionSchema": {
    "ruleId": "<same as top-level ruleId>",
    "ruleName": "<must align with that rule's name from input — DO NOT INVENT>",
    "version": "1.0",
    "status": "active",
    "parser": "REGEX",
    "language": {
      "name": "<lowercase language id from input, e.g. php, jsp, typescript>",
      "versions": ["<typical runtime versions for that language>"],
      "frameworks": ["<optional: e.g. servlet:3.1, spring:5.0 — omit key or use [] if none>"]
    },
    "scope": ["<one or more: function, file, project, scriptblock — match how the rule applies>"],
    "detectionCriteria": {
      "fileType": ["<extensions without dot, covering every file kind targeted by searchPattern below — e.g. php, jsp, jspx, ts, plus xml/yml/properties/json if any pattern targets config-based declarations>"],
      "searchPattern": ["<PCRE-compatible regex patterns; see PATTERN COVERAGE REQUIREMENTS below for what to include>"]
    }
  },
  "assessmentSchema": {
    "ruleId": "<must equal ruleId from the corresponding input rule — DO NOT INVENT>",
    "description": "<expand from that rule's description — DO NOT INVENT A NEW RULE>",
    "name": "<must align with that rule's name from input — DO NOT INVENT>",
    "domain": "<must equal the domain field from the corresponding input rule>",
    "category": "<must equal the category field from the corresponding input rule — DO NOT INVENT>",
    "tags": ["<3-5 tags related to the rule, e.g. Complexity, Code_Structure, Readability>"],
    "businessImpact": "<explain business impact>",
    "version": "<catalog or rule version>",
    "source": ["<names of standards from which the rule is derived>"],
    "issueType": "<must equal the issueType field from the corresponding input rule — DO NOT INVENT>",
    "language": {
      "name": "<must equal the language field from the corresponding input rule>",
      "versions": "<possible language versions>",
      "frameworks": "<present frameworks if any>"
    },
    "severity": "<must equal the severity field from the corresponding input rule — DO NOT INVENT>",
    "technicalDebt": "<float, person-hours>",
    "scope": ["METHOD", "CLASS", "FILE", "PACKAGE", "PROJECT"],
    "remediation": "<see REMEDIATION RULES. For the four domains, use that shape. When issueType is BOOSTER, set this to {}. Omit the key for any other domain. Never emit pathwayImpacts.>",
    "relationships": {
      "dependencies": ["<rule ids>"],
      "conflicts": ["<rule ids>"],
      "related": ["<rule ids>"]
    },
    "status": "ACTIVE | INACTIVE | EXPERIMENTAL",
    "schemaVersion": "<schema version for rule + remediation>",
    "lastUpdated": "<UTC timestamp>"
  }
}
"""


ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE = """
Your task is to analyze multiple rules provided below and generate assessment rule schemas for ALL of them.

Rules to analyze (total %(rule_count)d rules):
%(rules_batch)s

Generate assessment rule schemas for ALL %(rule_count)d rules provided above.

IMPORTANT:
- Return a JSON array containing exactly %(rule_count)d objects
- Each object MUST have three top-level keys: "ruleId", "detectionSchema", "assessmentSchema" — both schemas MUST be JSON objects (never null). API clients store them as separate documents.
- Put the full assessment rule document (category, remediation, etc.) inside "assessmentSchema" only. Do not emit pathwayImpacts.
- detectionSchema MUST follow the REGEX detection contract: fixed "status": "active" and "parser": "REGEX" (use these exact literals). Include ruleId, ruleName, version, language (object with name and versions array; add frameworks only when relevant), scope, and detectionCriteria with fileType and searchPattern arrays.
- Put machine-executable detection only inside detectionCriteria.searchPattern (regex strings). Do not use the old matchHints/summary/schemaVersion shape.
- The order of objects must match input rules (output[i] corresponds to input rule number i+1)
- For each index i: copy ruleId, name, description, domain, category, issueType, and severity from input rule i. Do not invent category, issueType, or severity. Align detectionSchema.ruleName and assessmentSchema with that rule; keep assessmentSchema.language consistent with detectionSchema.language.name
- Return STRICTLY valid JSON array only. Do not include any extra text, comments, or markdown code fences

PATTERN COVERAGE REQUIREMENTS (applies to every rule's detectionCriteria.searchPattern):
- Do not target any specific number of patterns, in total or per category. Walk through this category
  list and, for each category that genuinely applies to the rule, add as many patterns as that category
  actually needs to cover its real, distinct variations for this rule — one is enough if the category has
  only one real variation; several if it has several (e.g. configuration-based declarations may need a
  separate pattern per config format actually relevant to the rule's language/framework). Skip categories
  that don't apply. Every pattern must catch a genuinely distinct case — never add one just to raise the
  count:
  direct usage, indirect/wrapped usage, framework-specific implementations, namespace-qualified
  references, fully-qualified class names, import-based usage, annotations, configuration-based
  declarations (XML/YAML/JSON/properties), fluent APIs, builder patterns, and common naming/coding
  variations.
- If the input rule includes an example, generate at least one pattern derived directly from it plus
  patterns for its structural variations.
- Support whitespace variation, multiline code, optional modifiers, generic type declarations, method
  chaining, and case variation (via inline "(?i)" where casing is not guaranteed by the language).
- Prefer several targeted patterns over one overly broad or one overly strict pattern. Prefer high
  recall while keeping false positives reasonable (e.g. avoid patterns that would also match inside
  comments or unrelated identifiers when a small adjustment prevents it).
- For every rule, first decide whether it has a direct lexical target (an API, keyword, annotation,
  config key) or is a design-level concern (e.g. "monolithic X", "without Y pattern", "tight coupling",
  "missing Z") with no fixed keyword to match. In the latter case, write patterns for the closest lexical
  PROXY signal that correlates with the smell instead of trying to match the abstract concept directly
  — e.g. a long if/else-if or switch chain on a type/enum field as a proxy for "missing Strategy/Factory
  pattern", a single method issuing many sequential distinct service/I-O calls as a proxy for "monolithic
  retrieval", or direct "new ConcreteClass(...)" construction of a service/repository type as a proxy for
  "not decoupled". Base the proxy only on the rule's own name/description/example — never invent one
  unrelated to its wording, and never add a pattern that isn't backed by a genuinely distinct case.
- Every extension implied by these patterns (including config file types) must appear in
  detectionCriteria.fileType.

REMEDIATION RULES (assessmentSchema.remediation replaces pathwayImpacts):
- Never emit pathwayImpacts, strategyId, blockerLevel, or remediationPriority.
- Choose the shape from the input domain only. Trim the domain, then compare case-insensitively to the whole string (not a substring):
  - "Cloud Compatibility" -> one remediation list per cloud provider
  - "Software Portability" -> one remediation list per container service
  - "Code Sustainability" -> one cloud-agnostic list
  - "Security Health" -> one cloud-agnostic list (same shape as Code Sustainability)
  - any other domain -> omit the remediation key
- issueType is given on the input rule. If that value is BOOSTER, ignoring case, set remediation to exactly {} even when the domain matches. Booster rules are detection only. Do not put remediations inside that object.
- For any other case that has no remediation, omit the key. Do not emit null or an empty remediations array. {} is only for BOOSTER.
- Every list has at least 1 and at most 3 remediation objects. Exactly one object in that list has isDefault "True"; every other object in the same list has isDefault "False".
- isDefault is the string "True" or "False", never a JSON boolean.
- effort is exactly one of: Simple, Trivial, Major, Moderate, Complex.
- rule_id equals the input ruleId character for character.
- remediationId starts with "rem-" plus that same ruleId. Cloud and container segments inside the id are lowercase.
- Every remediation object has: remediationId, name, description, detailed_description, effort, isDefault, rule_id. Software Portability objects also have containerService. Do not add other fields.
- description is a complete explanation of the remediation on its own: what is wrong, what to change, and why that change fixes it. Do not shorten or thin it out because detailed_description exists. A reader who sees only description must still understand the remediation.
- detailed_description is an additional deeper string: root cause, step-by-step changes, before/after when useful, and pitfalls. It expands description. It does not replace it. It is always a string, never an object, array, or null.
- Do not copy the same name, description, or detailed_description across clouds or container services. Each list must be specific to that target.

Cloud Compatibility — keys are exactly aws, azure, and gcp. Each cloud has its own list and its own single isDefault "True".
remediationId: rem-<ruleId>-<aws|azure|gcp>-<001|002|003>
Example: ruleId cr-dotnet-1000 -> rem-cr-dotnet-1000-aws-001
{
  "remediation": {
    "aws": {
      "remediations": [
        {
          "remediationId": "rem-<ruleId>-aws-001",
          "name": "<short name specific to AWS>",
          "description": "<full description of the AWS remediation; stands alone without detailed_description>",
          "detailed_description": "<longer string: root cause, steps, before/after, pitfalls for AWS>",
          "effort": "Moderate",
          "isDefault": "True",
          "rule_id": "<exact input ruleId>"
        }
      ]
    },
    "azure": { "remediations": [ "<1-3 objects, one isDefault True, ids rem-<ruleId>-azure-001 onward>" ] },
    "gcp": { "remediations": [ "<1-3 objects, one isDefault True, ids rem-<ruleId>-gcp-001 onward>" ] }
  }
}

Software Portability — container JSON keys are exactly "EKS", "ECS Fargate", "AKS", and "GKE". containerService equals that key. Each container service has its own list and its own single isDefault "True".
remediationId: rem-<ruleId>-<aws|azure|gcp>-<eks|ecs-fargate|aks|gke>-<001|002|003>
ECS Fargate's id segment is ecs-fargate. Examples: rem-cz-dotnet-0001-aws-ecs-fargate-001 and rem-cz-dotnet-0001-gcp-gke-001.
{
  "remediation": {
    "aws": {
      "containerServices": {
        "EKS": {
          "remediations": [
            {
              "remediationId": "rem-<ruleId>-aws-eks-001",
              "containerService": "EKS",
              "name": "<short name specific to EKS>",
              "description": "<full description of the EKS remediation; stands alone without detailed_description>",
              "detailed_description": "<longer string: root cause, steps, before/after, pitfalls for EKS>",
              "effort": "Moderate",
              "isDefault": "True",
              "rule_id": "<exact input ruleId>"
            }
          ]
        },
        "ECS Fargate": {
          "remediations": [
            {
              "remediationId": "rem-<ruleId>-aws-ecs-fargate-001",
              "containerService": "ECS Fargate",
              "name": "<short name specific to ECS Fargate>",
              "description": "<full description of the ECS Fargate remediation; stands alone without detailed_description>",
              "detailed_description": "<longer string: root cause, steps, before/after, pitfalls for ECS Fargate>",
              "effort": "Simple",
              "isDefault": "True",
              "rule_id": "<exact input ruleId>"
            }
          ]
        }
      }
    },
    "azure": {
      "containerServices": {
        "AKS": {
          "remediations": [
            {
              "remediationId": "rem-<ruleId>-azure-aks-001",
              "containerService": "AKS",
              "name": "<short name specific to AKS>",
              "description": "<full description of the AKS remediation; stands alone without detailed_description>",
              "detailed_description": "<longer string: root cause, steps, before/after, pitfalls for AKS>",
              "effort": "Moderate",
              "isDefault": "True",
              "rule_id": "<exact input ruleId>"
            }
          ]
        }
      }
    },
    "gcp": {
      "containerServices": {
        "GKE": {
          "remediations": [
            {
              "remediationId": "rem-<ruleId>-gcp-gke-001",
              "containerService": "GKE",
              "name": "<short name specific to GKE>",
              "description": "<full description of the GKE remediation; stands alone without detailed_description>",
              "detailed_description": "<longer string: root cause, steps, before/after, pitfalls for GKE>",
              "effort": "Moderate",
              "isDefault": "True",
              "rule_id": "<exact input ruleId>"
            }
          ]
        }
      }
    }
  }
}

Code Sustainability and Security Health — one list, no cloud or container keys. 1-3 objects, exactly one isDefault "True".
remediationId: rem-<ruleId>-<001|002|003>
Examples: ruleId cq-dotnet-1000 -> rem-cq-dotnet-1000-001; ruleId security-dotnet-1000 -> rem-security-dotnet-1000-001.
{
  "remediation": {
    "remediations": [
      {
        "remediationId": "rem-<ruleId>-001",
        "name": "<short name>",
        "description": "<full cloud-agnostic description; stands alone without detailed_description>",
        "detailed_description": "<longer string: root cause, steps, before/after, pitfalls>",
        "effort": "Moderate",
        "isDefault": "True",
        "rule_id": "<exact input ruleId>"
      }
    ]
  }
}

Each assessment rule in the array must strictly follow this JSON structure (example for one object; produce one such object per input rule). The remediation value in the example is a placeholder — replace it with exactly one shape from REMEDIATION RULES, set it to {} when issueType is BOOSTER, or omit the key for any other domain:
%(schema)s

Return format: a JSON array with %(rule_count)d assessment rule objects, nothing else.
"""


def build_assessment_rules_batch_prompt(*, rules_batch: str, rule_count: int) -> str:
    """Build the full user prompt for the model."""
    return ASSESSMENT_RULES_BATCH_PROMPT_TEMPLATE % {
        "rule_count": rule_count,
        "rules_batch": rules_batch,
        "schema": ASSESSMENT_RULES_SCHEMA_EXAMPLE,
    }


def format_rules_batch_for_prompt(rules: List) -> str:
    """Format rules for the batch prompt (includes per-rule domain and language)."""
    blocks = []
    for i, r in enumerate(rules, start=1):
        ex = getattr(r, "example", None)
        ex_line = ""
        if isinstance(ex, str) and ex.strip():
            ex_line = f"\n   example: {ex.strip()}"
        blocks.append(
            f"{i}. ruleId: {r.rule_id}\n"
            f"   domain: {r.domain}\n"
            f"   category: {r.category}\n"
            f"   issueType: {r.issue_type}\n"
            f"   severity: {r.severity}\n"
            f"   language: {r.language}\n"
            f"   name: {r.name}\n"
            f"   description: {r.description}{ex_line}"
        )
    return "\n\n".join(blocks)
