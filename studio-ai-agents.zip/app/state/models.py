"""
Core data models for dependency graph orchestration.

Replaces max_iterations with deterministic graph-based execution.
"""
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict
from pathlib import Path


class ModuleStatus(Enum):
    """
    Module execution status in the dependency graph.
    
    PENDING: Module is waiting for dependencies to complete
    IN_PROGRESS: Module is currently being transformed
    LOCKED: Module successfully transformed and validated
    FAILED: Module transformation failed after max retries
    SKIPPED: Module skipped (no changes needed or no progress detected)
    """
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    LOCKED = "locked"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ModuleNode:
    """
    Represents a module in the dependency graph.
    
    A module can be:
    - A Maven module (subdirectory with pom.xml)
    - A .NET project (directory with .csproj file)
    """
    name: str
    path: str
    dependencies: List[str] = field(default_factory=list)
    status: ModuleStatus = ModuleStatus.PENDING
    retries: int = 0
    artifacts_hash: Optional[str] = None
    last_error: Optional[str] = None
    transformation_plan: Optional[Dict] = None
    files_changed: List[str] = field(default_factory=list)
    events: List[Dict] = field(default_factory=list)  # Store all tool execution events
    
    def __hash__(self):
        """Make ModuleNode hashable for use in sets/dicts."""
        return hash(self.name)
    
    def __eq__(self, other):
        """Equality based on module name."""
        return isinstance(other, ModuleNode) and self.name == other.name
    
    def __repr__(self):
        """String representation for debugging."""
        return (
            f"ModuleNode(name={self.name}, status={self.status.value}, "
            f"retries={self.retries}, deps={len(self.dependencies)})"
        )


@dataclass
class GraphState:
    """
    Overall state of the dependency graph execution.
    
    Tracks progress across all modules and provides completion status.
    """
    graph: Dict[str, ModuleNode]
    project_path: str
    project_type: str  # "maven" or "dotnet"
    total_modules: int
    completed_modules: int = 0
    failed_modules: int = 0
    current_iteration: int = 0
    max_retries: int = 3
    
    def is_complete(self) -> bool:
        """
        Check if all modules are processed.
        
        Returns:
            True if all modules are LOCKED, FAILED, or SKIPPED
        """
        return all(
            node.status in (ModuleStatus.LOCKED, ModuleStatus.FAILED, ModuleStatus.SKIPPED)
            for node in self.graph.values()
        )
    
    def has_failures(self) -> bool:
        """
        Check if any modules failed.
        
        Returns:
            True if any module has FAILED status
        """
        return any(node.status == ModuleStatus.FAILED for node in self.graph.values())
    
    def get_progress(self) -> Dict[str, int]:
        """
        Get progress statistics.
        
        Returns:
            Dictionary with progress metrics
        """
        locked = sum(1 for m in self.graph.values() if m.status == ModuleStatus.LOCKED)
        failed = sum(1 for m in self.graph.values() if m.status == ModuleStatus.FAILED)
        pending = sum(1 for m in self.graph.values() if m.status == ModuleStatus.PENDING)
        in_progress = sum(1 for m in self.graph.values() if m.status == ModuleStatus.IN_PROGRESS)
        skipped = sum(1 for m in self.graph.values() if m.status == ModuleStatus.SKIPPED)
        
        return {
            "total": self.total_modules,
            "locked": locked,
            "failed": failed,
            "pending": pending,
            "in_progress": in_progress,
            "skipped": skipped,
            "completed": locked + failed + skipped,
            "iteration": self.current_iteration
        }
