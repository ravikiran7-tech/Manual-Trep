"""
Artifact hashing and change detection.

Prevents infinite loops by detecting when no progress is made.
Uses SHA-256 hashing of directory contents to detect changes.
"""
import hashlib
import logging
from pathlib import Path
from typing import List, Optional
from app.state.models import ModuleNode

logger = logging.getLogger(__name__)


class ArtifactManager:
    """
    Manages artifact hashing for progress detection.
    
    Compares directory hashes before and after transformation
    to detect if any changes were made.
    """
    
    # Default patterns to exclude from hashing
    DEFAULT_EXCLUDE_PATTERNS = [
        '*.log',
        'target/',
        'bin/',
        'obj/',
        '.git/',
        '.idea/',
        '.vs/',
        'node_modules/',
        '.gradle/',
        '.mvn/',
        '*.class',
        '*.dll',
        '*.exe',
        '*.pdb'
    ]
    
    @staticmethod
    def hash_directory(
        path: str,
        exclude_patterns: Optional[List[str]] = None
    ) -> str:
        """
        Generate SHA-256 hash of directory contents.
        
        Hashes file paths and contents for all files in directory.
        Excludes build artifacts and temporary files.
        
        Args:
            path: Directory path to hash
            exclude_patterns: Patterns to exclude (default: build artifacts)
            
        Returns:
            Hexadecimal hash string (empty if directory doesn't exist)
        """
        exclude_patterns = exclude_patterns or ArtifactManager.DEFAULT_EXCLUDE_PATTERNS
        
        hasher = hashlib.sha256()
        path_obj = Path(path)
        
        if not path_obj.exists():
            logger.warning(f"Directory does not exist for hashing: {path}")
            return ""
        
        if not path_obj.is_dir():
            logger.warning(f"Path is not a directory: {path}")
            return ""
        
        # Sort files for deterministic hashing
        all_files = sorted(path_obj.rglob("*"))
        
        files_hashed = 0
        files_excluded = 0
        
        for file_path in all_files:
            # Skip directories
            if file_path.is_dir():
                continue
            
            # Check if file should be excluded
            should_exclude = False
            file_str = str(file_path)
            
            for pattern in exclude_patterns:
                # Simple pattern matching
                if pattern.endswith('/'):
                    # Directory pattern
                    if pattern.rstrip('/') in file_str:
                        should_exclude = True
                        break
                elif '*' in pattern:
                    # Wildcard pattern
                    import fnmatch
                    if fnmatch.fnmatch(file_path.name, pattern):
                        should_exclude = True
                        break
                else:
                    # Exact match
                    if pattern in file_str:
                        should_exclude = True
                        break
            
            if should_exclude:
                files_excluded += 1
                continue
            
            try:
                # Hash file path (relative to root) and content
                rel_path = str(file_path.relative_to(path_obj))
                hasher.update(rel_path.encode('utf-8'))
                
                # Read and hash file content
                file_bytes = file_path.read_bytes()
                hasher.update(file_bytes)
                
                files_hashed += 1
            except PermissionError:
                logger.warning(f"Permission denied reading {file_path}")
            except Exception as e:
                logger.warning(f"Failed to hash {file_path}: {e}")
        
        hash_value = hasher.hexdigest()
        
        logger.debug(
            f"Hashed directory {path}: {files_hashed} files, "
            f"{files_excluded} excluded, hash={hash_value[:16]}..."
        )
        
        return hash_value
    
    @staticmethod
    def has_progress(module: ModuleNode) -> bool:
        """
        Check if module has made progress since last hash.
        
        Compares current directory hash with stored hash.
        Updates stored hash if progress detected.
        
        Args:
            module: ModuleNode to check
            
        Returns:
            True if artifacts changed (progress detected), False otherwise
        """
        current_hash = ArtifactManager.hash_directory(module.path)
        
        if not current_hash:
            # Directory doesn't exist or is empty
            logger.warning(f"Cannot hash module {module.name}: directory issue")
            return False
        
        if module.artifacts_hash is None:
            # First time hashing - initialize
            module.artifacts_hash = current_hash
            logger.debug(f"Initial hash for module {module.name}: {current_hash[:16]}...")
            return True
        
        if current_hash == module.artifacts_hash:
            # No change detected
            logger.warning(
                f"Module {module.name} has no progress - "
                f"hash unchanged: {current_hash[:16]}..."
            )
            return False
        
        # Hash changed - progress detected
        logger.info(
            f"Module {module.name} progress detected: "
            f"{module.artifacts_hash[:16]}... -> {current_hash[:16]}..."
        )
        module.artifacts_hash = current_hash
        return True
    
    @staticmethod
    def update_hash(module: ModuleNode):
        """
        Update artifact hash for module.
        
        Useful after successful transformation to mark current state.
        
        Args:
            module: ModuleNode to update
        """
        new_hash = ArtifactManager.hash_directory(module.path)
        if new_hash:
            old_hash = module.artifacts_hash
            module.artifacts_hash = new_hash
            logger.debug(
                f"Updated hash for module {module.name}: "
                f"{old_hash[:16] if old_hash else 'None'}... -> {new_hash[:16]}..."
            )
        else:
            logger.warning(f"Failed to update hash for module {module.name}")
