"""
Diff-based patching system for efficient file modifications.

Supports multiple patch formats:
- Unified diff format
- Line-based edits (replace/insert/delete)
- Structured edits (JSON format)
"""
import difflib
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)


@dataclass
class PatchResult:
    """Result of applying a patch."""
    success: bool
    output: str
    error: Optional[str] = None
    lines_changed: int = 0
    original_line_count: int = 0
    new_line_count: int = 0


class PatchManager:
    """
    Manages diff-based patching operations.
    
    Supports multiple patch formats and validates before applying.
    """
    
    # Maximum patch data size (1MB)
    MAX_PATCH_SIZE = 1024 * 1024
    
    # Maximum file size for patching (10MB)
    MAX_FILE_SIZE = 10 * 1024 * 1024
    
    @staticmethod
    def apply_patch(
        file_path: str,
        patch_format: str,
        patch_data: Any
    ) -> PatchResult:
        """
        Apply a patch to a file.
        
        Args:
            file_path: Path to file to patch
            patch_format: Format of patch ("unified_diff", "line_edits", "structured")
            patch_data: Patch data (format depends on patch_format)
            
        Returns:
            PatchResult with success status and details
        """
        path_obj = Path(file_path)
        
        # Read current file content
        if not path_obj.exists():
            return PatchResult(
                success=False,
                output="",
                error=f"File does not exist: {file_path}"
            )
        
        try:
            # Check file size
            file_size = path_obj.stat().st_size
            if file_size > PatchManager.MAX_FILE_SIZE:
                return PatchResult(
                    success=False,
                    output="",
                    error=f"File too large for patching: {file_size} bytes (max: {PatchManager.MAX_FILE_SIZE})"
                )
            
            # Check if binary file
            if PatchManager._is_binary_file(file_path):
                return PatchResult(
                    success=False,
                    output="",
                    error=f"Binary files cannot be patched: {file_path}"
                )
            
            original_content = path_obj.read_text(encoding='utf-8')
            original_lines = original_content.splitlines(keepends=True)
            original_line_count = len(original_lines)
        except UnicodeDecodeError:
            return PatchResult(
                success=False,
                output="",
                error=f"File appears to be binary or has invalid encoding: {file_path}"
            )
        except Exception as e:
            return PatchResult(
                success=False,
                output="",
                error=f"Failed to read file: {e}"
            )
        
        # Apply patch based on format
        try:
            if patch_format == "unified_diff":
                result = PatchManager._apply_unified_diff(
                    original_lines, patch_data
                )
            elif patch_format == "line_edits":
                result = PatchManager._apply_line_edits(
                    original_lines, patch_data
                )
            elif patch_format == "structured":
                result = PatchManager._apply_structured_edits(
                    original_lines, patch_data
                )
            else:
                return PatchResult(
                    success=False,
                    output="",
                    error=f"Unknown patch format: {patch_format}"
                )
            
            if not result["success"]:
                return PatchResult(
                    success=False,
                    output="",
                    error=result["error"],
                    original_line_count=original_line_count
                )
            
            # Write patched content
            new_content = "".join(result["lines"])
            path_obj.write_text(new_content, encoding='utf-8')
            
            new_line_count = len(result["lines"])
            lines_changed = abs(new_line_count - original_line_count)
            
            logger.info(
                f"Applied patch to {file_path}: "
                f"{original_line_count} -> {new_line_count} lines "
                f"({lines_changed} changed)"
            )
            
            return PatchResult(
                success=True,
                output=f"Successfully applied patch: {lines_changed} lines changed",
                lines_changed=lines_changed,
                original_line_count=original_line_count,
                new_line_count=new_line_count
            )
            
        except Exception as e:
            logger.error(f"Failed to apply patch to {file_path}: {e}", exc_info=True)
            return PatchResult(
                success=False,
                output="",
                error=f"Patch application failed: {e}",
                original_line_count=original_line_count
            )
    
    @staticmethod
    def _is_binary_file(file_path: str) -> bool:
        """
        Detect if file is binary by checking for null bytes.
        
        Args:
            file_path: Path to file
            
        Returns:
            True if file appears to be binary
        """
        try:
            with open(file_path, 'rb') as f:
                chunk = f.read(8192)
                return b'\x00' in chunk
        except Exception:
            return False
    
    @staticmethod
    def _locate(
        lines: List[str],
        block: List[str],
        hint: Optional[int],
        cursor: int
    ) -> Optional[int]:
        """Find where `block` sits in `lines`, or None.

        Standard patch semantics: hunks are applied in file order and each one
        is searched for FORWARD from the end of the previous hunk. That is what
        lets a diff legitimately change several identical occurrences - it sends
        one hunk per occurrence and each consumes the next one.

        A numbered header, when present and landing on a real match, overrides
        the search. Matching is exact first, then indentation-insensitive.
        """
        n = len(block)
        if n == 0 or n > len(lines):
            return None

        for normalize in (False, True):
            if normalize:
                hay = [x.strip() for x in lines]
                needle = [x.strip() for x in block]
            else:
                hay, needle = lines, block
            matches = [i for i in range(len(hay) - n + 1) if hay[i:i + n] == needle]
            if not matches:
                continue
            if hint is not None and hint in matches:
                return hint
            ahead = [i for i in matches if i >= cursor]
            if ahead:
                if hint is not None:
                    return min(ahead, key=lambda i: abs(i - hint))
                return ahead[0]
            if hint is not None:
                return min(matches, key=lambda i: abs(i - hint))
            return matches[-1]
        return None

    @staticmethod
    def _resolve_line(
        lines: List[str],
        line_num: int,
        old_text: Optional[str]
    ) -> Optional[int]:
        """Map a model-supplied line number onto a real 0-based index.

        Models number lines from 1. When `old_text` is supplied it is the
        authority: try 1-based, then 0-based, then the nearest unique match
        elsewhere in the file, so a slightly stale number still lands
        correctly. Without `old_text` (insert / delete) honour the 1-based
        contract.
        """
        if old_text is None:
            index = line_num - 1
            return index if 0 <= index < len(lines) else None

        want = old_text.rstrip()
        for index in (line_num - 1, line_num):
            if 0 <= index < len(lines) and lines[index].rstrip() == want:
                return index

        hits = [i for i, l in enumerate(lines) if l.rstrip() == want]
        if len(hits) == 1:
            return hits[0]
        if hits:
            return min(hits, key=lambda i: abs(i - (line_num - 1)))
        return None

    @staticmethod
    def _apply_unified_diff(
        original_lines: List[str],
        diff_text: str
    ) -> Dict[str, Any]:
        """Apply a unified diff, locating each hunk by CONTENT, not line number.

        Accepts both hunk-header dialects produced by current models:
            numbered   @@ -31,3 +31,2 @@     classic unified diff
            anchored   @@                    apply-patch style, no ranges

        Context lines are preserved verbatim from the file, removals are
        verified against the file before anything is written, and a hunk that
        matches nothing is refused with a message the model can act on.
        """
        try:
            hunks: List[Dict[str, Any]] = []
            current: Optional[Dict[str, Any]] = None
            # Blank lines inside a hunk body are blank CONTEXT lines whose
            # single leading space was stripped in transit - very common, since
            # most tooling trims trailing whitespace. They are held back until a
            # real body line follows, so a blank line trailing the diff is never
            # mistaken for content.
            pending_blank: List[str] = []

            for line in diff_text.splitlines(keepends=True):
                if line.startswith("---") or line.startswith("+++"):
                    continue
                if line.startswith("@@"):
                    if current is not None:
                        hunks.append(current)
                    pending_blank = []
                    match = re.match(
                        r'@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@', line
                    )
                    current = {
                        "hint": int(match.group(1)) - 1 if match else None,
                        "lines": []
                    }
                elif current is not None:
                    if line[:1] in (" ", "-", "+"):
                        current["lines"].extend(pending_blank)
                        pending_blank = []
                        current["lines"].append(line)
                    elif line.strip() == "":
                        pending_blank.append(" " + line)

            if current is not None:
                hunks.append(current)

            hunks = [h for h in hunks if h["lines"]]
            if not hunks:
                return {
                    "success": False,
                    "error": (
                        "No valid hunks found in diff. Each hunk must start with '@@' "
                        "and its body must use ' ' for context, '-' for removed and "
                        "'+' for added lines."
                    )
                }

            def _nl(text: str) -> str:
                return text if text.endswith("\n") else text + "\n"

            result_lines = list(original_lines)
            cursor = 0

            for position, hunk in enumerate(hunks, 1):
                body = hunk["lines"]
                old_block = [
                    _nl(l[1:]) for l in body if l[:1] in (" ", "-")
                ]

                if not old_block:
                    # Pure insertion carries no anchor of its own.
                    if hunk["hint"] is None:
                        return {
                            "success": False,
                            "error": (
                                f"Hunk {position} only adds lines and has no anchor. "
                                f"Add at least one context line (' ' prefix) showing "
                                f"where it belongs, or use a numbered header like "
                                f"'@@ -12,0 +13,3 @@'."
                            )
                        }
                    at = min(max(hunk["hint"], 0), len(result_lines))
                    added = [_nl(l[1:]) for l in body]
                    result_lines[at:at] = added
                    cursor = at + len(added)
                    continue

                index = PatchManager._locate(
                    result_lines, old_block, hunk["hint"], cursor
                )

                if index is None:
                    # Retry ignoring blank context lines, for a model that
                    # invented one the file does not have. Dropping them can
                    # only match where the file has no blank line there, so
                    # this never turns a correct placement into a wrong one -
                    # it only recovers cases that would otherwise be refused.
                    trimmed = [l for l in body if l.strip() != ""]
                    if len(trimmed) != len(body):
                        candidate = [
                            _nl(l[1:]) for l in trimmed if l[:1] in (" ", "-")
                        ]
                        if candidate:
                            index = PatchManager._locate(
                                result_lines, candidate, hunk["hint"], cursor
                            )
                            if index is not None:
                                body, old_block = trimmed, candidate

                if index is None:
                    anchor = old_block[0].strip()[:80]
                    return {
                        "success": False,
                        "error": (
                            f"Hunk {position} does not match the file. Searched for "
                            f"{anchor!r} and it is not present as written. Re-read the "
                            f"file and rebuild this hunk from its current contents; "
                            f"context and '-' lines must be copied exactly."
                        )
                    }

                # Rebuild from the FILE's own lines so context keeps its exact
                # original whitespace even when the anchor matched loosely.
                rebuilt: List[str] = []
                offset = index
                for line in body:
                    tag, text = line[:1], line[1:]
                    if tag == " ":
                        rebuilt.append(result_lines[offset])
                        offset += 1
                    elif tag == "-":
                        offset += 1
                    else:
                        rebuilt.append(_nl(text))

                result_lines[index:index + len(old_block)] = rebuilt
                cursor = index + len(rebuilt)

            return {"success": True, "lines": result_lines}

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to parse unified diff: {e}"
            }

    @staticmethod
    def _apply_line_edits(
        original_lines: List[str],
        edits: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply line-based edits.
        
        Format (line numbers are 1-BASED, as models emit them):
        [
            {"type": "replace", "line": 10, "old_text": "...", "new_text": "..."},
            {"type": "insert", "line": 15, "text": "..."},
            {"type": "delete", "line": 20}
        ]
        """
        try:
            result_lines = original_lines.copy()
            
            # Sort edits by line number (descending) to maintain indices
            sorted_edits = sorted(edits, key=lambda e: e.get("line", 0), reverse=True)
            
            for edit in sorted_edits:
                edit_type = edit.get("type")
                line_num = edit.get("line")

                if edit_type not in ("replace", "insert", "delete"):
                    return {
                        "success": False,
                        "error": f"Unknown edit type: {edit_type}"
                    }

                if line_num is None or line_num < 0:
                    return {
                        "success": False,
                        "error": f"Invalid line number: {line_num}"
                    }

                # Models emit 1-BASED line numbers; this list is 0-based.
                if edit_type == "insert" and edit.get("old_text") is None:
                    # An insert names the line it goes BEFORE, so it has one
                    # more legal position than the file has lines: 0 and
                    # len+1 are the boundary spellings of "at the top" and
                    # "append", and every dialect agrees on those two.
                    # Anything further out is a mistake, not a dialect.
                    index = (
                        max(line_num - 1, 0)
                        if line_num <= len(result_lines) + 1
                        else None
                    )
                else:
                    index = PatchManager._resolve_line(
                        result_lines, line_num, edit.get("old_text")
                    )

                limit = (
                    len(result_lines) + 1 if edit_type == "insert"
                    else len(result_lines)
                )
                if index is None or not 0 <= index < limit:
                    if line_num > limit:
                        return {
                            "success": False,
                            "error": f"Line number {line_num} out of bounds (file has {len(result_lines)} lines)"
                        }
                    return {
                        "success": False,
                        "error": f"Line {line_num} doesn't match expected content. Re-read the file and use its current 1-based line numbers."
                    }

                if edit_type == "replace":
                    new_text = edit.get("new_text", "")

                    result_lines[index] = new_text + ("\n" if not new_text.endswith("\n") else "")

                elif edit_type == "insert":
                    text = edit.get("text", "")
                    result_lines.insert(index, text + ("\n" if not text.endswith("\n") else ""))

                else:  # delete
                    result_lines.pop(index)
            
            return {
                "success": True,
                "lines": result_lines
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to apply line edits: {e}"
            }
    
    @staticmethod
    def _apply_structured_edits(
        original_lines: List[str],
        edits: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Apply structured edits (JSON format with ranges).
        
        Format:
        {
            "edits": [
                {
                    "range": {"start": {"line": 10, "character": 0}, "end": {"line": 12, "character": 0}},
                    "new_text": "..."
                }
            ]
        }
        """
        try:
            result_lines = original_lines.copy()
            edits_list = edits.get("edits", [])
            
            # Sort edits by start line (descending) to maintain indices
            sorted_edits = sorted(
                edits_list,
                key=lambda e: e.get("range", {}).get("start", {}).get("line", 0),
                reverse=True
            )
            
            for edit in sorted_edits:
                range_obj = edit.get("range", {})
                start = range_obj.get("start", {})
                end = range_obj.get("end", {})
                new_text = edit.get("new_text", "")
                
                start_line = start.get("line", 0)
                end_line = end.get("line", 0)
                
                if start_line < 0 or end_line >= len(result_lines):
                    return {
                        "success": False,
                        "error": f"Invalid line range: {start_line}-{end_line} (file has {len(result_lines)} lines)"
                    }
                
                # Replace lines in range
                new_lines = new_text.splitlines(keepends=True)
                if not new_text.endswith("\n") and new_lines:
                    new_lines[-1] = new_lines[-1].rstrip("\n") + "\n"
                
                result_lines[start_line:end_line + 1] = new_lines
            
            return {
                "success": True,
                "lines": result_lines
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to apply structured edits: {e}"
            }
    
    @staticmethod
    def compute_diff(
        old_content: str,
        new_content: str,
        file_path: str = "file"
    ) -> str:
        """
        Compute unified diff between old and new content.
        
        Useful for generating patches or showing changes.
        """
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{file_path}",
            tofile=f"b/{file_path}",
            lineterm=""
        )
        
        return "".join(diff)
    
    @staticmethod
    def validate_patch(
        file_path: str,
        patch_format: str,
        patch_data: Any
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate patch before applying.
        
        Returns:
            (is_valid, error_message)
        """
        path_obj = Path(file_path)
        
        if not path_obj.exists():
            return False, f"File does not exist: {file_path}"
        
        # Validate patch data size
        if isinstance(patch_data, str):
            if len(patch_data.encode('utf-8')) > PatchManager.MAX_PATCH_SIZE:
                return False, f"Patch data too large: {len(patch_data)} bytes (max: {PatchManager.MAX_PATCH_SIZE})"
        elif isinstance(patch_data, (dict, list)):
            import json
            patch_json = json.dumps(patch_data)
            if len(patch_json.encode('utf-8')) > PatchManager.MAX_PATCH_SIZE:
                return False, f"Patch data too large (max: {PatchManager.MAX_PATCH_SIZE} bytes)"
        
        try:
            original_content = path_obj.read_text(encoding='utf-8')
            original_lines = original_content.splitlines(keepends=True)
        except UnicodeDecodeError:
            return False, f"File appears to be binary or has invalid encoding: {file_path}"
        except Exception as e:
            return False, f"Failed to read file: {e}"
        
        # Basic validation based on format
        if patch_format == "unified_diff":
            if not isinstance(patch_data, str):
                return False, "Unified diff must be a string"
            if "@@" not in patch_data:
                return False, "Invalid unified diff format: missing hunk headers"
                
        elif patch_format == "line_edits":
            if not isinstance(patch_data, list):
                return False, "Line edits must be a list"
            for edit in patch_data:
                if not isinstance(edit, dict):
                    return False, "Each edit must be a dictionary"
                if "type" not in edit or "line" not in edit:
                    return False, "Each edit must have 'type' and 'line' fields"
                # Validate line number is within bounds. Line numbers are
                # 1-BASED (see _apply_line_edits), so the last line of the file
                # is len(original_lines) and an insert may name len+1 to append.
                # This gate stays deliberately permissive - _apply_line_edits
                # verifies the edit against the file's actual content - so that
                # a well-formed edit is never rejected before it is tried.
                line_num = edit.get("line")
                if line_num is not None and (line_num < 0 or line_num > len(original_lines) + 1):
                    return False, f"Line number {line_num} out of bounds (file has {len(original_lines)} lines)"
                    
        elif patch_format == "structured":
            if not isinstance(patch_data, dict):
                return False, "Structured edits must be a dictionary"
            if "edits" not in patch_data:
                return False, "Structured edits must have 'edits' field"
            # Validate line ranges
            edits_list = patch_data.get("edits", [])
            for edit in edits_list:
                range_obj = edit.get("range", {})
                start_line = range_obj.get("start", {}).get("line", 0)
                end_line = range_obj.get("end", {}).get("line", 0)
                if start_line < 0 or end_line >= len(original_lines):
                    return False, f"Line range {start_line}-{end_line} out of bounds (file has {len(original_lines)} lines)"
        
        return True, None
