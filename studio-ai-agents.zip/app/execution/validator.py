"""
Compiler-based validation (not LLM-based).

Provides binary truth for determining if transformation succeeded.
Uses actual compiler/build tools to validate changes.
"""
import os
import subprocess
import logging
from pathlib import Path
from typing import Tuple
from app.state.models import ModuleNode

logger = logging.getLogger(__name__)


class CompilerValidator:
    """
    Validates module transformations using compiler checks.
    
    Runs actual build commands to verify that transformed code
    compiles successfully. This provides objective validation
    rather than relying on LLM judgment.
    """
    
    @staticmethod
    def validate_maven(module: ModuleNode, timeout: int = 300) -> Tuple[bool, str]:
        """
        Validate Maven module by running build.
        
        Args:
            module: ModuleNode to validate
            timeout: Build timeout in seconds (default: 5 minutes)
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            logger.info(f"Validating Maven module {module.name} at {module.path}")
            
            # Set MAVEN_OPTS to handle Java 9+ module system compatibility
            # This fixes issues with older maven-compiler-plugin versions (3.7.0, etc.)
            # that don't work well with Java 9+ module system
            env = os.environ.copy()
            maven_opts = env.get("MAVEN_OPTS", "")
            
            # Add JVM arguments to open and export required modules for Java 9+
            # This fixes compatibility issues with older maven-compiler-plugin versions
            # and Lombok that don't work well with Java 9+ module system
            add_opens = [
                "--add-opens=jdk.compiler/com.sun.tools.javac.processing=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.util=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.file=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.main=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.jvm=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.tree=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.code=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.api=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.comp=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.parser=ALL-UNNAMED"
            ]
            
            # Add exports for Lombok compatibility (Lombok needs to access these packages)
            add_exports = [
                "--add-exports=jdk.compiler/com.sun.tools.javac.file=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.processing=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.util=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.main=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.jvm=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.tree=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.code=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.api=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.comp=ALL-UNNAMED",
                "--add-exports=jdk.compiler/com.sun.tools.javac.parser=ALL-UNNAMED"
            ]
            
            # Combine all JVM arguments
            all_jvm_args = add_opens + add_exports
            
            if maven_opts:
                maven_opts = f"{maven_opts} {' '.join(all_jvm_args)}"
            else:
                maven_opts = " ".join(all_jvm_args)
            
            env["MAVEN_OPTS"] = maven_opts
            logger.debug(f"Using MAVEN_OPTS: {maven_opts[:200]}...")
            
            # Also pass JVM args directly to compiler plugin via Maven properties
            # This ensures the compiler fork process gets the flags
            # maven.compiler.fork.jvmArgs expects a single string with all args separated by spaces
            jvm_args_string = " ".join(all_jvm_args)
            maven_args = [
                "mvn", "clean", "compile", "-q",
                "-Dmaven.compiler.fork=true",
                f"-Dmaven.compiler.fork.jvmArgs={jvm_args_string}"
            ]
            
            result = subprocess.run(
                maven_args,
                cwd=module.path,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=env
            )
            
            if result.returncode == 0:
                logger.info(f"Maven module {module.name} validation successful")
                return True, "Build successful"
            else:
                error_output = result.stderr or result.stdout
                logger.error(
                    f"Maven module {module.name} validation failed: "
                    f"{error_output[:500]}"
                )
                return False, error_output[:1000]  # Limit error message length
            
        except subprocess.TimeoutExpired:
            logger.error(f"Maven module {module.name} validation timeout after {timeout}s")
            return False, f"Build timeout after {timeout} seconds"
        except FileNotFoundError:
            logger.error("Maven command not found")
            return False, "Maven command not found. Is Maven installed?"
        except Exception as e:
            logger.error(f"Error validating Maven module {module.name}: {e}")
            return False, str(e)
    
    @staticmethod
    def validate_dotnet(module: ModuleNode, timeout: int = 300) -> Tuple[bool, str]:
        """
        Validate .NET module by running build.
        
        Args:
            module: ModuleNode to validate
            timeout: Build timeout in seconds (default: 5 minutes)
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            logger.info(f"Validating .NET project {module.name} at {module.path}")
            
            # Find .csproj file in module directory
            csproj_files = list(Path(module.path).glob("*.csproj"))
            if not csproj_files:
                return False, f"No .csproj file found in {module.path}"
            
            result = subprocess.run(
                ["dotnet", "build", "--no-restore", "--verbosity", "quiet"],
                cwd=module.path,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            if result.returncode == 0:
                logger.info(f".NET project {module.name} validation successful")
                return True, "Build successful"
            else:
                error_output = result.stderr or result.stdout
                logger.error(
                    f".NET project {module.name} validation failed: "
                    f"{error_output[:500]}"
                )
                return False, error_output[:1000]  # Limit error message length
            
        except subprocess.TimeoutExpired:
            logger.error(f".NET project {module.name} validation timeout after {timeout}s")
            return False, f"Build timeout after {timeout} seconds"
        except FileNotFoundError:
            logger.error("dotnet command not found")
            return False, "dotnet command not found. Is .NET SDK installed?"
        except Exception as e:
            logger.error(f"Error validating .NET project {module.name}: {e}")
            return False, str(e)
    
    @staticmethod
    def validate(module: ModuleNode, project_type: str, timeout: int = 300) -> Tuple[bool, str]:
        """
        Validate module transformation based on project type.
        
        Args:
            module: ModuleNode to validate
            project_type: Project type ("maven" or "dotnet")
            timeout: Build timeout in seconds
            
        Returns:
            Tuple of (success: bool, message: str)
            
        Raises:
            ValueError: If project_type is unsupported
        """
        if project_type == "maven":
            return CompilerValidator.validate_maven(module, timeout)
        elif project_type == "dotnet":
            return CompilerValidator.validate_dotnet(module, timeout)
        else:
            error_msg = f"Unknown project type: {project_type}. Supported: maven, dotnet"
            logger.error(error_msg)
            raise ValueError(error_msg)
