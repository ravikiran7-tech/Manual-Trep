"""
Transformation summary log models.

Pydantic models for the transformation log API — request, response,
and the on-disk log file structure.
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class ProcessTransformationLogRequest(BaseModel):
    """Request body for POST /api/transformation-log/process."""

    analysis_id: str = Field(..., alias="analysisId")
    tenant_id: Optional[str] = Field(default=None, alias="tenantId")
    plan_id: int = Field(..., alias="planId")
    step_id: int = Field(..., alias="stepId")
    operation: str  # "cloudreadiness-analysis", "cloudreadiness-fix", etc.
    stream_file_path: str = Field(..., alias="streamFilePath")
    output_log_path: str = Field(..., alias="outputLogPath")
    transformation_type: str = Field(default="cloudreadiness", alias="transformationType")

    class Config:
        populate_by_name = True


class ProcessTransformationLogResponse(BaseModel):
    """Response body for POST /api/transformation-log/process."""

    status: str  # "success", "error", "no_new_events"
    message: str
    new_entries_count: int = Field(default=0, alias="newEntriesCount")
    total_entries_count: int = Field(default=0, alias="totalEntriesCount")
    last_processed_event_index: int = Field(default=0, alias="lastProcessedEventIndex")
    total_stream_events: int = Field(default=0, alias="totalStreamEvents")
    has_more_events: bool = Field(default=False, alias="hasMoreEvents")
    log_file_status: str = Field(default="in_progress", alias="logFileStatus")

    class Config:
        populate_by_name = True


class TransformationLogEntry(BaseModel):
    """A single entry in the transformation summary log."""

    timestamp: str       # "HH:MM:SS"
    phase: str           # "initialization", "code_analysis", "refactoring"
    icon: str            # "play", "code", "lightning"
    message: str         # user-readable message
    color: str           # hex color e.g. "#4CAF50"


class TransformationLogFile(BaseModel):
    """On-disk JSON structure for the transformation log file."""

    analysis_id: str = Field(..., alias="analysisId")
    operation: str
    status: str = "in_progress"  # "in_progress", "completed", "error"
    last_processed_event_index: int = Field(default=0, alias="lastProcessedEventIndex")
    last_updated_at: str = Field(default="", alias="lastUpdatedAt")
    logs: List[TransformationLogEntry] = []

    class Config:
        populate_by_name = True
