"""
Request models using Pydantic.
Equivalent to Java DTOs in the dto package.
"""
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from app.models.enums import OperationType, Platform, JavaVersion, DotnetVersion


class ClaudeCliRequest(BaseModel):
    """
    Request model for Claude CLI command execution.
    Equivalent to Java's ClaudeCliRequest DTO.

    Attributes:
        prompt: Path to prompt file or prompt content (optional for some operations)
        project_path: Absolute path to project directory (required)
        analysis_id: Unique identifier for the analysis (optional)
        operation: Type of operation to perform (default: "analysis")
        operation_suffix: Additional suffix for operation-specific naming (optional)
        platform: Target platform (default: "linux")
        claude_workspace: Custom Claude workspace path (optional)
        java_version: Java version for build/test operations (optional)
        dotnet_version: .NET version for build/test operations (optional)
        project_type: Project type - java or dotnet (optional, auto-detected if not provided)
    """

    prompt: Optional[str] = Field(
        default=None,
        description="Path to prompt file or prompt content"
    )

    project_path: str = Field(
        ...,
        description="Absolute path to project directory",
        alias="projectPath"
    )

    analysis_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the analysis",
        alias="analysisId"
    )

    operation: str = Field(
        default="analysis",
        description="Type of operation to perform"
    )

    operation_suffix: Optional[str] = Field(
        default=None,
        description="Additional suffix for operation-specific naming",
        alias="operationSuffix"
    )

    platform: str = Field(
        default="linux",
        description="Target platform (linux or windows)"
    )

    claude_workspace: Optional[str] = Field(
        default=None,
        description="Custom Claude workspace path",
        alias="claudeWorkspace"
    )

    java_version: Optional[str] = Field(
        default=None,
        description="Java version for validation operations (17, 21, 25)",
        alias="javaVersion"
    )

    dotnet_version: Optional[str] = Field(
        default=None,
        description=".NET version for validation operations (6.0, 7.0, 8.0, 10.0)",
        alias="dotnetVersion"
    )

    project_type: Optional[str] = Field(
        default=None,
        description="Project type (java, dotnet). Auto-detected if not provided.",
        alias="projectType"
    )

    class Config:
        # Allow field population by both alias and field name
        populate_by_name = True
        # JSON schema configuration
        json_schema_extra = {
            "example": {
                "prompt": "/path/to/prompt.txt",
                "projectPath": "/projects/my-app",
                "analysisId": "analysis-123",
                "operation": "analysis",
                "platform": "linux",
                "projectType": "dotnet"
            }
        }

    @field_validator('java_version')
    @classmethod
    def validate_java_version(cls, v: Optional[str]) -> Optional[str]:
        """
        Validate Java version (lenient mode for backward compatibility).
        Accepts versions like "8", "8.0", "17", "21" etc.
        No strict validation - allows any string to support legacy clients.
        """
        if v is None:
            return v
        # Accept any string value for backward compatibility
        # Handlers will validate specific versions as needed
        return v

    @field_validator('dotnet_version')
    @classmethod
    def validate_dotnet_version(cls, v: Optional[str]) -> Optional[str]:
        """
        Validate .NET version (lenient mode for backward compatibility).
        Accepts versions like "6.0", "7.0", "8.0", "10.0" etc.
        No strict validation - allows any string to support legacy clients.
        """
        if v is None:
            return v
        # Accept any string value for backward compatibility
        # Handlers will validate specific versions as needed
        return v

    @field_validator('operation')
    @classmethod
    def validate_operation(cls, v: str) -> str:
        """Validate operation is one of the supported types."""
        try:
            OperationType(v)
            return v
        except ValueError:
            valid_operations = [op.value for op in OperationType]
            raise ValueError(
                f"Invalid operation: {v}. Must be one of: {', '.join(valid_operations)}"
            )

    @field_validator('platform')
    @classmethod
    def validate_platform(cls, v: str) -> str:
        """Validate platform is one of the supported types."""
        try:
            Platform(v)
            return v
        except ValueError:
            valid_platforms = [p.value for p in Platform]
            raise ValueError(
                f"Invalid platform: {v}. Must be one of: {', '.join(valid_platforms)}"
            )

    def is_prompt_required(self) -> bool:
        """
        Check if prompt is required for this operation.
        Matches Java's isPromptRequired() method.

        Returns:
            True if prompt is required and missing, False otherwise
        """
        # For certain operations, prompt is not required as it's read from file
        if self.operation in ["upgrade", "fix-upgrade", "build-compilation"]:
            return False

        # For analysis operations with MON pattern analysisId, prompt is not required
        if self.operation == "analysis" and self.analysis_id and self.analysis_id.startswith("MON"):
            return False

        # For other operations, check if prompt is missing
        return self.prompt is None or not self.prompt.strip()


class SchemaModernizationRequest(BaseModel):
    """
    Request model for database schema modernization operations.
    Equivalent to Java's ClaudeSchemaModernizationRequest DTO.

    Attributes:
        analysis_id: Unique identifier for the schema modernization
        source_db_type: Source database type (e.g., "Oracle", "MySQL")
        target_db_type: Target database type (e.g., "PostgreSQL")
        source_schema_path: Path to source schema file (optional for content-in-prompt)
        project_path: Project directory path (optional)
        prompt: Full prompt with schema content (optional for file-access)
        platform: Target platform (default: "linux")
        claude_workspace: Custom Claude workspace path (optional)
    """

    analysis_id: str = Field(
        ...,
        description="Unique identifier for the schema modernization",
        alias="analysisId"
    )

    source_db_type: str = Field(
        ...,
        description="Source database type (e.g., Oracle, MySQL)",
        alias="sourceDbType"
    )

    target_db_type: str = Field(
        ...,
        description="Target database type (e.g., PostgreSQL)",
        alias="targetDbType"
    )

    source_schema_path: Optional[str] = Field(
        default=None,
        description="Path to source schema file (for file-access approach)",
        alias="sourceSchemaPath"
    )

    project_path: Optional[str] = Field(
        default=None,
        description="Project directory path",
        alias="projectPath"
    )

    prompt: Optional[str] = Field(
        default=None,
        description="Full prompt with schema content (for content-in-prompt approach)"
    )

    platform: str = Field(
        default="linux",
        description="Target platform (linux or windows)"
    )

    claude_workspace: Optional[str] = Field(
        default=None,
        description="Custom Claude workspace path",
        alias="claudeWorkspace"
    )

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "analysisId": "schema-001",
                "sourceDbType": "Oracle",
                "targetDbType": "PostgreSQL",
                "sourceSchemaPath": "/path/to/oracle_schema.sql",
                "projectPath": "/projects/db-migration",
                "platform": "linux"
            }
        }

    @field_validator('platform')
    @classmethod
    def validate_platform(cls, v: str) -> str:
        """Validate platform is one of the supported types."""
        try:
            Platform(v)
            return v
        except ValueError:
            valid_platforms = [p.value for p in Platform]
            raise ValueError(
                f"Invalid platform: {v}. Must be one of: {', '.join(valid_platforms)}"
            )


class AssessmentRuleInputItem(BaseModel):
    """
    One catalog rule in a batch request for assessment-rule schema generation.

    Each rule carries its own domain and language so a single batch can mix stacks.
    """

    rule_id: str = Field(
        ...,
        description="Rule identifier from the catalog (do not invent)",
        alias="ruleId",
    )
    domain: str = Field(
        ...,
        description="Domain for this rule's assessment schema (e.g. code-quality, security)",
    )
    language: str = Field(
        ...,
        description="Language/stack for this rule (e.g. dotnet, Java); JSON key ``language``",
    )
    name: str = Field(..., description="Rule name from the catalog")
    description: str = Field(..., description="Rule description from the catalog")
    category: str = Field(
        ...,
        description="Assessment category supplied by the client; copied onto assessmentSchema",
    )
    issue_type: str = Field(
        ...,
        description="Issue type supplied by the client (for example NEUTRAL, BLOCKER, BOOSTER)",
        alias="issueType",
    )
    severity: str = Field(
        ...,
        description="Severity supplied by the client; copied onto assessmentSchema",
    )
    example: Optional[str] = Field(
        default=None,
        description="Optional sample or illustration for the rule (included in the model prompt when set)",
    )

    model_config = {"populate_by_name": True}


class AssessmentRulesBatchRequest(BaseModel):
    """
    Request to generate full assessment-rule JSON objects for a batch of catalog rules.

    Each item in ``rules`` supplies its own ``domain`` and ``language``; the model must
    reflect those values in the corresponding output object (same list order).
    """

    analysis_id: str = Field(
        ...,
        description="Unique id for this batch run (workspace / output paths)",
        alias="analysisId",
    )
    rules: List[AssessmentRuleInputItem] = Field(
        ...,
        description="Catalog rules to expand into assessment schemas",
        min_length=1,
    )
    project_path: Optional[str] = Field(
        default=None,
        description="Working directory for tool execution (optional)",
        alias="projectPath",
    )
    platform: str = Field(
        default="linux",
        description="Target platform (linux or windows)",
    )

    model_config = {"populate_by_name": True}

    @field_validator("platform")
    @classmethod
    def validate_platform_batch(cls, v: str) -> str:
        try:
            Platform(v)
            return v
        except ValueError:
            valid_platforms = [p.value for p in Platform]
            raise ValueError(
                f"Invalid platform: {v}. Must be one of: {', '.join(valid_platforms)}"
            )


class BuildCompilationRequest(ClaudeCliRequest):
    """
    Specialized request model for build compilation operations.
    Extends ClaudeCliRequest with build-specific defaults.
    """

    operation: str = Field(
        default="build-compilation",
        description="Operation type (build-compilation)"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "projectPath": "/projects/java-app",
                "analysisId": "build-001",
                "javaVersion": "17",
                "operation": "build-compilation",
                "platform": "linux"
            }
        }
