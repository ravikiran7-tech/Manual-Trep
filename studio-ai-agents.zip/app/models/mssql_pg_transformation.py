"""Pydantic models for the MSSQL → PostgreSQL launch API.

Launch body matches Oracle: same top-level fields and the same five
``inputPaths`` names. After launch, studio-core calls the existing Oracle
read URLs; those handlers find the MSSQL folder from ``jobId``.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator


class MssqlPgInputPaths(BaseModel):
    """Filesystem paths to pre-staged Compass / assessment artifacts under _claude/.

    Field names match ``OraclePgInputPaths`` so studio-core can send one launch body.
    """

    ddl_export: str = Field(..., alias="ddlExport")
    asis_schema: str = Field(..., alias="asisSchema")
    incompatibility_results: str = Field(..., alias="incompatibilityResults")
    rules_remediation: str = Field(..., alias="rulesRemediation")
    schema_analysis: Optional[str] = Field(default=None, alias="schemaAnalysis")

    class Config:
        populate_by_name = True


class LaunchMssqlPgTransformationRequest(BaseModel):
    """POST /api/mssql-pg-transformation/launch request body (Oracle-aligned)."""

    job_id: Optional[str] = Field(default=None, alias="jobId")
    analysis_id: Optional[str] = Field(default=None, alias="analysisId")
    db_id: Optional[str] = Field(default=None, alias="dbId")
    database_id: Optional[str] = Field(default=None, alias="databaseId")
    db_name: str = Field(..., alias="dbName")
    target_database_version: Literal["15", "16"] = Field(..., alias="targetDatabaseVersion")
    input_paths: MssqlPgInputPaths = Field(..., alias="inputPaths")
    selected_rules: List[str] = Field(
        default_factory=list,
        alias="selectedRules",
        description="Rule IDs when ruleScope is custom.",
    )
    rule_scope: Literal["all", "high_impact", "custom"] = Field(
        default="all",
        alias="ruleScope",
        description="Which transformation rules to apply from rulesRemediation.",
    )
    source_database_version: str = Field(default="SQL Server 2019", alias="sourceDatabaseVersion")
    ai_agent: str = Field(default="claude-sonnet-5-5", alias="aiAgent")

    @field_validator("ai_agent", mode="before")
    @classmethod
    def normalize_ai_agent(cls, value: Any) -> str:
        """Same default as Oracle. Omit, null, or blank still runs as claude-sonnet-5-5."""
        if value is None or (isinstance(value, str) and not value.strip()):
            return "claude-sonnet-5-5"
        return str(value).strip()

    @field_validator("target_database_version", mode="before")
    @classmethod
    def normalize_target_database_version(cls, value: Any) -> str:
        """Accept 15/16 and dotted forms such as 15.0 from clients."""
        if isinstance(value, bool):
            raise ValueError("targetDatabaseVersion must be 15 or 16")
        if isinstance(value, int):
            candidate = str(value)
        elif isinstance(value, float):
            candidate = str(int(value)) if value.is_integer() else str(value)
        else:
            candidate = str(value).strip()

        if candidate in {"15", "15.0"}:
            return "15"
        if candidate in {"16", "16.0"}:
            return "16"
        raise ValueError("targetDatabaseVersion must be 15 or 16")

    class Config:
        populate_by_name = True


class LaunchMssqlPgTransformationResponse(BaseModel):
    job_id: str = Field(..., alias="jobId")
    status: str
    workspace_path: str = Field(..., alias="workspacePath")
    db_name: str = Field(..., alias="dbName")
    message: str = "Transformation job accepted"

    class Config:
        populate_by_name = True
