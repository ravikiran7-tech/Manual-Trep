"""
Response models using Pydantic.
Equivalent to Java response DTOs in the dto package.
"""
from typing import Any, Dict, List, Optional
from pydantic import BaseModel,ConfigDict, Field


class ClaudeCliResponse(BaseModel):
    """
    Response model for Claude CLI command execution.
    Equivalent to Java's ClaudeCliResponse DTO.

    Attributes:
        status: Status of execution ("success" or "error")
        message: Human-readable message
        exit_code: Process exit code (0 for success, non-zero for error)
        output: Command output content
        error: Error message if any
        output_file_path: Path to output file
    """

    status: str = Field(
        ...,
        description="Status of execution (success or error)"
    )

    message: str = Field(
        ...,
        description="Human-readable message"
    )

    exit_code: int = Field(
        default=0,
        description="Process exit code",
        alias="exitCode"
    )

    output: Optional[str] = Field(
        default=None,
        description="Command output content"
    )

    error: Optional[str] = Field(
        default=None,
        description="Error message if any",
        json_schema_extra={"examples": ["Error details here"]}
    )

    output_file_path: Optional[str] = Field(
        default=None,
        description="Path to output file",
        alias="outputFilePath"
    )

    summary: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Operation summary (e.g. buildStatus for build-compilation)"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "status": "success",
                "message": "Command executed successfully",
                "exitCode": 0,
                "output": "/path/to/output.json",
                "error": None,
                "outputFilePath": "/path/to/output.json"
            }
        }
    }

    @classmethod
    def create_success(
        cls,
        message: str = "Command executed successfully",
        exit_code: int = 0,
        output: Optional[str] = None,
        output_file_path: Optional[str] = None
    ) -> "ClaudeCliResponse":
        """
        Factory method for success responses.
        Matches Java's ClaudeCliResponse.success() static method.

        Args:
            message: Success message
            exit_code: Process exit code (default: 0)
            output: Command output content
            output_file_path: Path to output file

        Returns:
            ClaudeCliResponse instance with status="success"
        """
        return cls(
            status="success",
            message=message,
            exit_code=exit_code,
            output=output or "",
            error="",
            output_file_path=output_file_path or ""
        )

    @classmethod
    def create_error(
        cls,
        message: str,
        exit_code: int = -1,
        error: Optional[str] = None
    ) -> "ClaudeCliResponse":
        """
        Factory method for error responses.
        Matches Java's ClaudeCliResponse.error() static method.

        Args:
            message: Error message
            exit_code: Process exit code (default: -1)
            error: Detailed error information

        Returns:
            ClaudeCliResponse instance with status="error"
        """
        return cls(
            status="error",
            message=message,
            exit_code=exit_code,
            output="",
            error=error or message,
            output_file_path=""
        )


class SchemaModernizationResponse(BaseModel):
    """
    Response model for database schema modernization operations.
    Equivalent to Java's ClaudeSchemaModernizationResponse DTO.

    Attributes:
        status: Status of execution ("success" or "error")
        message: Human-readable message
        output_file_path: Path to modernized schema file
        content: Modernized schema content
        error_details: Detailed error information if any
        analysis_id: Unique identifier for the schema modernization
        source_db_type: Source database type
        target_db_type: Target database type
    """

    status: str = Field(
        ...,
        description="Status of execution (success or error)"
    )

    message: str = Field(
        ...,
        description="Human-readable message"
    )

    output_file_path: Optional[str] = Field(
        default=None,
        description="Path to modernized schema file",
        alias="outputFilePath"
    )

    content: Optional[str] = Field(
        default=None,
        description="Modernized schema content"
    )

    error_details: Optional[str] = Field(
        default=None,
        description="Detailed error information",
        alias="errorDetails"
    )

    analysis_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for the schema modernization",
        alias="analysisId"
    )

    source_db_type: Optional[str] = Field(
        default=None,
        description="Source database type",
        alias="sourceDbType"
    )

    target_db_type: Optional[str] = Field(
        default=None,
        description="Target database type",
        alias="targetDbType"
    )

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "status": "success",
                "message": "Schema modernization completed",
                "outputFilePath": "/path/to/modernized_schema.sql",
                "content": "CREATE TABLE...",
                "analysisId": "schema-001",
                "sourceDbType": "Oracle",
                "targetDbType": "PostgreSQL"
            }
        }

    @classmethod
    def create_error(
        cls,
        message: str,
        analysis_id: Optional[str] = None
    ) -> "SchemaModernizationResponse":
        """
        Factory method for error responses.
        Matches Java's ClaudeSchemaModernizationResponse.error() static method.

        Args:
            message: Error message
            analysis_id: Analysis ID if available

        Returns:
            SchemaModernizationResponse instance with status="error"
        """
        return cls(
            status="error",
            message=message,
            error_details=message,
            analysis_id=analysis_id
        )

class AssessmentRuleBatchItem(BaseModel):
    """
    One generated rule. Mirrors Java ``AssessmentRuleBatchItem``:
    ``ruleId``, ``assessmentSchema``, ``detectionSchema`` as JSON objects (maps).
    """

    model_config = ConfigDict(populate_by_name=True)

    rule_id: Optional[str] = Field(
        default=None,
        description="Catalog rule id",
        alias="ruleId",
    )
    assessment_schema: Dict[str, Any] = Field(
        default_factory=dict,
        description="Generated assessment-rule JSON object",
        alias="assessmentSchema",
    )
    detection_schema: Dict[str, Any] = Field(
        default_factory=dict,
        description="Generated detection metadata JSON object",
        alias="detectionSchema",
    )


class AssessmentRulesBatchResponse(BaseModel):
    """
    Response from batch assessment-rule schema generation.

    On success, ``rules`` contains one ``AssessmentRuleBatchItem`` per input rule
    with populated ``assessmentSchema`` and ``detectionSchema`` objects.

    Large batches may emit multiple NATS messages (``status=partial``) before the
    final ``status=success`` message with ``isFinal=true``.
    """

    status: str = Field(
        ...,
        description="partial, success, or error",
    )
    message: str = Field(..., description="Human-readable summary")
    is_final: bool = Field(
        default=True,
        description="False while more chunk results may follow; true on last message",
        alias="isFinal",
    )
    chunk_index: Optional[int] = Field(
        default=None,
        description="1-based index of this chunk",
        alias="chunkIndex",
    )
    chunk_count: Optional[int] = Field(
        default=None,
        description="Total chunks for this batch",
        alias="chunkCount",
    )
    rules_completed_so_far: Optional[int] = Field(
        default=None,
        description="Running total of rules delivered across prior and current chunk",
        alias="rulesCompletedSoFar",
    )
    analysis_id: Optional[str] = Field(
        default=None,
        description="Echo of request analysis id",
        alias="analysisId",
    )
    rule_count_expected: Optional[int] = Field(
        default=None,
        description="Number of rules requested",
        alias="ruleCountExpected",
    )
    rule_count_returned: Optional[int] = Field(
        default=None,
        description="Number of objects parsed from model output",
        alias="ruleCountReturned",
    )
    rules: Optional[List[AssessmentRuleBatchItem]] = Field(
        default=None,
        description=(
            "One item per input rule: ruleId, detectionSchema, assessmentSchema "
            "(same shape as Java AssessmentRuleBatchItem / JsonNode fields)"
        ),
    )
    raw_response: Optional[str] = Field(
        default=None,
        description="Raw assistant text when parse failed or for debugging",
        alias="rawResponse",
    )
    output_file_path: Optional[str] = Field(
        default=None,
        description="Path to stream JSON artifact",
        alias="outputFilePath",
    )
    error_details: Optional[str] = Field(
        default=None,
        alias="errorDetails",
    )

    model_config = {"populate_by_name": True}


class DotnetBuildCompilationResponse(BaseModel):
    """
    Response model for .NET build compilation operations.
    Matches Java's DotnetBuildCompilationResponse DTO structure so that
    the Java microservice can call response.getSummary().getBuildStatus().

    Attributes:
        status: Top-level status ("success", "partial", or "error")
        message: Human-readable message
        output_file_path: Path to the result JSON in reports/
        summary: Nested build summary with buildStatus field
    """

    class BuildCompilationSummary(BaseModel):
        build_status: str = Field(
            ...,
            description="Build status: SUCCESS, PARTIAL, or FAILED",
            alias="buildStatus"
        )

        model_config = {"populate_by_name": True}

    status: str = Field(
        ...,
        description="Top-level status (success, partial, or error)"
    )

    message: str = Field(
        ...,
        description="Human-readable message"
    )

    output_file_path: Optional[str] = Field(
        default=None,
        description="Path to result JSON file in reports/",
        alias="outputFilePath"
    )

    summary: BuildCompilationSummary = Field(
        ...,
        description="Build summary containing buildStatus"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "status": "success",
                "message": ".NET build completed successfully",
                "outputFilePath": "/path/to/reports/build-compilation-result.json",
                "summary": {
                    "buildStatus": "SUCCESS"
                }
            }
        }
    }


class BuildCompilationResponse(BaseModel):
    """
    Response model for build compilation operations.
    Simplified version matching Java's BuildCompilationResponse.

    Attributes:
        assessment_id: Unique identifier for the build assessment
        status: Status of execution ("success", "failed", or "error")
        message: Human-readable message
        cached: Whether results were retrieved from cache
        output_file_path: Path to build output file
        build_output: Build command output
    """

    assessment_id: str = Field(
        ...,
        description="Unique identifier for the build assessment",
        alias="assessmentId"
    )

    status: str = Field(
        ...,
        description="Status of execution (success, failed, or error)"
    )

    message: str = Field(
        ...,
        description="Human-readable message"
    )

    cached: bool = Field(
        default=False,
        description="Whether results were retrieved from cache"
    )

    output_file_path: Optional[str] = Field(
        default=None,
        description="Path to build output file",
        alias="outputFilePath"
    )

    build_output: Optional[str] = Field(
        default=None,
        description="Build command output",
        alias="buildOutput"
    )

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "assessmentId": "build-001",
                "status": "success",
                "message": "Build completed successfully",
                "cached": False,
                "outputFilePath": "/path/to/build-output.json",
                "buildOutput": "BUILD SUCCESS"
            }
        }


class StreamVisualizationResponse(BaseModel):
    """
    Response model for stream visualization data retrieval.

    Attributes:
        analysis_id: Unique identifier for the analysis
        operation: Operation type
        stream_data: Stream data content (JSON string or dict)
        status: Status of retrieval
        message: Human-readable message
    """

    analysis_id: str = Field(
        ...,
        description="Unique identifier for the analysis",
        alias="analysisId"
    )

    operation: str = Field(
        ...,
        description="Operation type"
    )

    stream_data: Optional[str] = Field(
        default=None,
        description="Stream data content",
        alias="streamData"
    )

    status: str = Field(
        default="success",
        description="Status of retrieval"
    )

    message: str = Field(
        default="Stream data retrieved successfully",
        description="Human-readable message"
    )

    class Config:
        populate_by_name = True
