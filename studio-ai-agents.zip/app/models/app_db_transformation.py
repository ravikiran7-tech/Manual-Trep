"""Pydantic models for App+DB (Job 3) transformation APIs.

Public field names are Java camelCase. FastAPI 0.136 clones request models and
drops Field(alias=...) / validators, so snake_case fields would reject appId.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, field_validator, model_validator

OverallStatus = Literal["IN_PROGRESS", "COMPLETED", "FAILED", "QUEUED"]
MilestoneStatus = Literal["COMPLETED", "IN_PROGRESS", "PENDING", "FAILED", "SKIPPED"]
CommitStatus = Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "SKIPPED"]

_LAUNCH_SNAKE_TO_CAMEL = {
    "app_id": "appId",
    "db_id": "dbId",
    "tenant_id": "tenantId",
    "plan_id": "planId",
    "project_path": "projectPath",
    "project_type": "projectType",
    "rules_remediation": "rulesRemediation",
    "schema_file_path": "schemaFilePath",
    "skip_llm": "skipLlm",
    "ai_agent": "aiAgent",
    "app_name": "appName",
    "db_name": "dbName",
    "source_database_version": "sourceDatabaseVersion",
    "target_database_version": "targetDatabaseVersion",
    "target_branch": "targetBranch",
    "repository_url": "repositoryUrl",
    "input_paths": "inputPaths",
}

_INPUT_PATHS_SNAKE_TO_CAMEL = {
    "dependency_findings": "dependencyFindings",
    "rules_remediation": "rulesRemediation",
}


class AppDbInputPaths(BaseModel):
    """Filesystem paths to Java-staged findings + remediation KB under ``_claude/``."""

    dependencyFindings: Optional[str] = None
    rulesRemediation: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def accept_snake_case(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        normalized = dict(value)
        for snake, camel in _INPUT_PATHS_SNAKE_TO_CAMEL.items():
            if snake in normalized and camel not in normalized:
                normalized[camel] = normalized[snake]
        return normalized

_COMMIT_SNAKE_TO_CAMEL = {
    "commit_hash": "commitHash",
    "short_hash": "shortHash",
    "commit_url": "commitUrl",
    "committed_at": "committedAt",
    "repository_url": "repositoryUrl",
    "error_code": "errorCode",
    "dry_run": "dryRun",
    "file_count": "fileCount",
}


class AppDbLaunchRequest(BaseModel):
    """POST /api/app-db-transformation/launch request body.

    Job 3 uses exactly two directories on the shared mount, both created per
    database id by the Java package builder:

    * ``{claude_workspace}/db-code-modernize/{dbId}/_claude/`` — inputs;
      ``inputPaths.dependencyFindings`` (Java-Oracle scan) and
      ``inputPaths.rulesRemediation`` (Oracle-Java remediation KB) name files
      in here; every finding in the dependency file is applied;
    * ``{claude_workspace}/db-code-modernize/{dbId}/reports/`` — outputs; the
      report, progress/log state, SSE streams and the transformed-code ZIP.

    ``projectPath`` is the application checkout whose sources are rewritten in
    place; it is never used as an output location. When the caller does not
    already know it, it may be omitted as long as ``tenantId`` and ``planId``
    are both supplied instead — Job 3 then derives it from the same NFS
    convention Job 1/M-Upgrade's own output already uses (see
    ``workspace.resolve_project_path``).
    """

    appId: str
    dbId: str
    tenantId: Optional[str] = None
    planId: Optional[str] = None
    projectPath: Optional[str] = None
    projectType: str = "java"
    inputPaths: Optional[AppDbInputPaths] = None
    # Legacy single-field alias; prefer inputPaths.rulesRemediation.
    rulesRemediation: Optional[str] = None
    pathway: str = "M-Upgrade"
    schemaFilePath: Optional[str] = None
    skipLlm: bool = False
    aiAgent: str = "claude-sonnet-5-5"
    # Optional display/report metadata (FR3, FR11). Not required — the report
    # falls back to appId/dbId when the caller omits these.
    appName: Optional[str] = None
    dbName: Optional[str] = None
    sourceDatabaseVersion: Optional[str] = None
    targetDatabaseVersion: str = "15.0"
    targetBranch: Optional[str] = None
    repositoryUrl: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def accept_snake_case(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        normalized = dict(value)
        for snake, camel in _LAUNCH_SNAKE_TO_CAMEL.items():
            if snake in normalized and camel not in normalized:
                normalized[camel] = normalized[snake]
        return normalized

    @field_validator("appId", "dbId", mode="before")
    @classmethod
    def coerce_ids(cls, value: Any) -> str:
        if value is None:
            raise ValueError("id is required")
        return str(value)

    @field_validator("tenantId", "planId", mode="before")
    @classmethod
    def coerce_optional_ids(cls, value: Any) -> Optional[str]:
        return None if value is None else str(value)


class AppDbLaunchResponse(BaseModel):
    transformationId: str
    # Public tracking key: application id (one app, one database). The Java
    # client reads "jobId" off the launch acknowledgement
    # (AiAgentsClient.launchAppDbTransformation).
    jobId: str
    status: str
    message: str = "Transformation started"
    workspacePath: Optional[str] = None
    # True when this launch returned an already-running transformation for the
    # same appId+dbId instead of starting a second one (idempotent launch).
    reused: bool = False


class AppDbMilestone(BaseModel):
    id: int
    title: str
    description: str
    # Studio left-panel grouping: Configurations | Transformation | Artifacts.
    group: Optional[str] = None
    status: MilestoneStatus
    timestamp: Optional[str] = None


class AppDbProgressResponse(BaseModel):
    transformationId: str
    overallStatus: OverallStatus
    bannerMessage: str
    currentMilestone: int
    progressPercent: int = 0
    milestones: List[AppDbMilestone]
    metrics: Dict[str, Any] = {}
    report: Dict[str, Any] = {}


class AppDbJobStatusResponse(BaseModel):
    """GET /api/app-db-transformation/jobs/{jobId}.

    Field-compatible with the DB job's status body (AiAgentJobStatusResponse in
    studio-database-code-modernize): lowercase ``status``, ``progressPercent``,
    ``objectsTotal`` / ``objectsConverted``. ``jobId`` is the application id;
    ``transformationId`` remains the internal APPDB-… run id. App+DB counters
    are added alongside; terminal responses carry timing.
    """

    jobId: str
    transformationId: str
    appId: Optional[str] = None
    dbId: Optional[str] = None
    status: str
    overallStatus: OverallStatus
    phase: str
    phaseGroup: Optional[str] = None
    progressPercent: int = 0
    message: str = ""
    bannerMessage: str = ""
    currentMilestone: Optional[int] = None
    milestonesTotal: Optional[int] = None
    objectsTotal: int = 0
    objectsConverted: int = 0
    sessionsCompleted: int = 0
    lastCompletedBatch: Optional[str] = None
    filesScanned: int = 0
    filesModified: int = 0
    violationsTotal: int = 0
    violationsResolved: int = 0
    violationsFailed: int = 0
    rulesProcessed: int = 0
    pgCompatibilityChanges: int = 0
    manualReviewItems: int = 0
    pathway: Optional[str] = None
    errorDetail: Optional[str] = None
    updatedAt: Optional[str] = None
    startedAt: Optional[str] = None
    completedAt: Optional[str] = None
    durationSeconds: Optional[int] = None
    duration: Optional[str] = None
    reportAvailable: Optional[bool] = None
    reportPath: Optional[str] = None
    reportStatus: Optional[str] = None
    reportFileSizeBytes: Optional[int] = None
    statusText: Optional[str] = None


class AppDbLogEntry(BaseModel):
    timestamp: str
    level: str
    message: str
    phase: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    seq: Optional[int] = None
    jobId: Optional[str] = None


class AppDbLogsResponse(BaseModel):
    logs: List[AppDbLogEntry]
    hasMore: bool


class AppDbReportRequest(BaseModel):
    """POST /api/app-db-transformation/internal/report — internal report read."""

    appId: str
    dbId: str
    transformationId: Optional[str] = None

    @field_validator("appId", "dbId", mode="before")
    @classmethod
    def coerce_ids(cls, value: Any) -> str:
        if value is None:
            raise ValueError("id is required")
        return str(value)


class AppDbReportPathResponse(BaseModel):
    """POST /api/app-db-transformation/internal/report/path — file name and path only.

    Returned so the database service can read post_transformation_report.json
    directly off the shared mount instead of pulling the full body through this
    service on every summary request.
    """

    transformationId: str
    name: str
    path: str


class AppDbReportStatusResponse(BaseModel):
    """GET /{transformationId}/report/status — artifact-step progress.

    ``steps`` is the per-step trace (VALIDATE / GENERATE_JSON / PACKAGE_ZIP)
    with durations, so a failed artifact step names the step that failed.
    """

    transformationId: str
    status: str
    available: bool = False
    path: Optional[str] = None
    generatedAt: Optional[str] = None
    fileSizeBytes: Optional[int] = None
    progressPercent: int = 0
    error: Optional[str] = None
    steps: List[Dict[str, Any]] = []


class AppDbCommitStatusResponse(BaseModel):
    """GET /{transformationId}/commit — GitHub Commit artifact-step state."""

    transformationId: str
    status: CommitStatus
    commitHash: Optional[str] = None
    shortHash: Optional[str] = None
    branch: Optional[str] = None
    repositoryUrl: Optional[str] = None
    commitUrl: Optional[str] = None
    committedAt: Optional[str] = None
    fileCount: int = 0
    errorCode: Optional[str] = None
    errorDescription: Optional[str] = None
    error: Optional[str] = None
    retryCount: int = 0
    maxRetries: int = 0
    attemptsRemaining: int = 0
    retryable: bool = False
    nextRetryAt: Optional[str] = None
    terminal: bool = False
    failureMessage: Optional[str] = None
    attempts: List[Dict[str, Any]] = []


class AppDbCommitRetryRequest(BaseModel):
    """POST /{transformationId}/commit/retry — re-arm the commit step."""

    reason: Optional[str] = None


class AppDbCommitRetryResponse(BaseModel):
    transformationId: str
    status: CommitStatus
    attempt: int
    maxRetries: int
    branch: Optional[str] = None
    message: Optional[str] = None
    files: List[str] = []
    commit: Dict[str, Any] = {}


class AppDbCommitResultRequest(BaseModel):
    """Legacy POST body for retired commit-result routes (HTTP 410)."""

    status: CommitStatus
    commitHash: Optional[str] = None
    shortHash: Optional[str] = None
    branch: Optional[str] = None
    commitUrl: Optional[str] = None
    repositoryUrl: Optional[str] = None
    committedAt: Optional[str] = None
    error: Optional[str] = None
    errorCode: Optional[str] = None
    dryRun: bool = False
    fileCount: Optional[int] = None

    @model_validator(mode="before")
    @classmethod
    def accept_snake_case(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        normalized = dict(value)
        for snake, camel in _COMMIT_SNAKE_TO_CAMEL.items():
            if snake in normalized and camel not in normalized:
                normalized[camel] = normalized[snake]
        status = normalized.get("status")
        if isinstance(status, str):
            normalized["status"] = status.strip().upper()
        return normalized


class AppDbCommitResultResponse(BaseModel):
    """Legacy response shape retained for OpenAPI of retired commit routes."""

    transformationId: str
    reportUpdated: bool = False
    commit: Dict[str, Any] = {}


class AppDbArtifactsResponse(BaseModel):
    transformationId: str
    jobId: str
    artifacts: List[Dict[str, Any]]


class AppDbRuleItem(BaseModel):
    id: str
    name: str = ""
    description: str = ""
    category: str = "unknown"
    impactLevel: str = "Moderate"


class AppDbRulesListResponse(BaseModel):
    dbId: str
    language: str = "java"
    rules: List[AppDbRuleItem] = []


class AppDbRulesSelectionRequest(BaseModel):
    dbId: str
    language: str = "java"
    mode: str = "apply_all"
    selectedRuleIds: List[str] = []


class AppDbRulesSelectionResponse(BaseModel):
    dbId: str
    language: str
    mode: str
    rules: List[AppDbRuleItem] = []


class AppDbApprovePlanResponse(BaseModel):
    transformationId: str
    status: str
    message: str = ""


class AppDbJobStatusWithStudioCtaResponse(AppDbJobStatusResponse):
    nextJobCta: Optional[Dict[str, Any]] = None
