"""
Models for direct .NET build execution.
Mirrors Java's BuildRequest and BuildResult DTOs exactly.
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class BuildRequest(BaseModel):
    """
    Request model for direct .NET build execution (no LLM).
    Mirrors Java's BuildRequest DTO.
    """

    project_location: str = Field(
        ...,
        description="Absolute path to the .NET project directory",
        alias="projectLocation"
    )

    analysis_id: str = Field(
        ...,
        description="Unique identifier for the analysis",
        alias="analysisId"
    )

    platform: Optional[str] = Field(
        default=None,
        description="Target platform (linux or windows). Auto-detected if not provided."
    )

    claude_workspace: Optional[str] = Field(
        default=None,
        description="Claude workspace base path for logs and reports",
        alias="claudeWorkspace"
    )

    application_name: Optional[str] = Field(
        default=None,
        description="Application name for logging",
        alias="applicationName"
    )

    build_file: Optional[str] = Field(
        default=None,
        description="Specific build file to pass to the build tool (e.g. MySolution.sln, pom.xml). "
                    "Falls back to tool defaults if not provided.",
        alias="buildFile"
    )

    # ── Java-specific fields ──────────────────────────────────────────────────

    technology: Optional[str] = Field(
        default=None,
        description="Technology type: 'java' or 'dotnet'"
    )

    build_type: Optional[str] = Field(
        default=None,
        description="Build tool: 'maven' (only maven supported for Java currently)",
        alias="buildType"
    )

    version: Optional[str] = Field(
        default=None,
        description="Language/SDK version (Java: '8', '11', '17', '21')"
    )

    skip_tests: Optional[bool] = Field(
        default=False,
        description="Skip test execution during build (Java Maven: -DskipTests)",
        alias="skipTests"
    )

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "projectLocation": "/projects/my-java-app",
                "analysisId": "analysis-001",
                "platform": "linux",
                "claudeWorkspace": "/studio-app/claude-workspace",
                "applicationName": "MyJavaApp",
                "buildFile": "pom.xml",
                "technology": "java",
                "buildType": "maven",
                "version": "17",
                "skipTests": False
            }
        }


class BuildResult(BaseModel):
    """
    Result model for direct .NET build execution.
    Mirrors Java's BuildResult DTO exactly — flat structure.
    """

    exit_code: int = Field(
        ...,
        description="Process exit code (0 = success)",
        alias="exitCode"
    )

    success: bool = Field(
        ...,
        description="True if build succeeded"
    )

    build_status: str = Field(
        ...,
        description="Build status: SUCCESS, FAILURE, or UNKNOWN",
        alias="buildStatus"
    )

    compilation_errors: List[str] = Field(
        default_factory=list,
        description="List of compilation error messages",
        alias="compilationErrors"
    )

    test_failures: List[str] = Field(
        default_factory=list,
        description="List of test failure messages",
        alias="testFailures"
    )

    errors: int = Field(
        default=0,
        description="Total error count"
    )

    warnings: int = Field(
        default=0,
        description="Total warning count"
    )

    total_time: str = Field(
        default="N/A",
        description="Build total time (e.g. '0:01:23')",
        alias="totalTime"
    )

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "exitCode": 0,
                "success": True,
                "buildStatus": "SUCCESS",
                "compilationErrors": [],
                "testFailures": [],
                "errors": 0,
                "warnings": 2,
                "totalTime": "0:00:45"
            }
        }
