"""
Enums for operation types, platforms, and providers.
Equivalent to Java enums used across the application.
"""
from enum import Enum


class OperationType(str, Enum):
    """
    All supported operation types.
    Maps to Java's operation string values.
    """
    ANALYSIS = "analysis"
    FIX_UPGRADE = "fix-upgrade"
    BUILD_COMPILATION = "build-compilation"
    TEST_EXECUTION = "test-execution"
    TEST_CREATION = "test-creation"
    CLOUDREADINESS_ANALYSIS = "cloudreadiness-analysis"
    CLOUDREADINESS_FIX = "cloudreadiness-fix"
    DB_CODE_MODERNIZE_ANALYSIS = "db-code-modernize-analysis"
    DB_CODE_MODERNIZE_FIX = "db-code-modernize-fix"
    SCHEMA_MODERNIZATION = "schema-modernization"
    DOTNET_BUILD_COMPILATION = "dotnet-build-compilation"
    DOTNET_TEST_EXECUTION = "dotnet-test-execution"
    TEST_EXECUTION_BUILD = "test-executionBuild"
    # Containerization operations
    CONTAINERIZATION_ANALYSIS = "containerization-analysis"
    SELECTIVE_FIX = "selective-fix"
    GENERATION = "generation"
    SUMMARY = "summary"


class Platform(str, Enum):
    """
    Supported platforms.
    Java implementation supports both Linux and Windows (via WSL).
    """
    LINUX = "linux"
    WINDOWS = "windows"


class ProviderType(str, Enum):
    """
    AI provider types for model invocation.
    """
    BEDROCK = "aws-bedrock"
    PORTKEY = "portkey"


class DatabaseType(str, Enum):
    """
    Supported database types for schema modernization.
    """
    ORACLE = "Oracle"
    POSTGRESQL = "PostgreSQL"
    MYSQL = "MySQL"
    MSSQL = "MSSQL"
    DB2 = "DB2"


class JavaVersion(str, Enum):
    """
    Supported Java versions for build and test execution.
    """
    JAVA_8  = "8"
    JAVA_17 = "17"
    JAVA_21 = "21"


class DotnetVersion(str, Enum):
    """
    Supported .NET versions for build and test execution.
    """
    DOTNET_6 = "6.0"
    DOTNET_7 = "7.0"
    DOTNET_8 = "8.0"
    DOTNET_10 = "10.0"
