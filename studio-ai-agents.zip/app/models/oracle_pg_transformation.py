"""Pydantic models for Oracle → PostgreSQL agentic transformation API."""

from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator


class OraclePgInputPaths(BaseModel):
    """Filesystem paths to pre-staged Compass / assessment artifacts under _claude/."""

    ddl_export: str = Field(..., alias="ddlExport")
    asis_schema: str = Field(..., alias="asisSchema")
    incompatibility_results: str = Field(..., alias="incompatibilityResults")
    rules_remediation: str = Field(..., alias="rulesRemediation")
    schema_analysis: Optional[str] = Field(default=None, alias="schemaAnalysis")

    class Config:
        populate_by_name = True


class LaunchOraclePgTransformationRequest(BaseModel):
    """POST /api/oracle-pg-transformation/launch request body."""

    job_id: Optional[str] = Field(default=None, alias="jobId")
    analysis_id: Optional[str] = Field(default=None, alias="analysisId")
    db_name: str = Field(..., alias="dbName")
    target_database_version: Literal["15", "16"] = Field(..., alias="targetDatabaseVersion")
    input_paths: OraclePgInputPaths = Field(..., alias="inputPaths")
    selected_rules: List[str] = Field(
        default_factory=list,
        alias="selectedRules",
        description="Rule IDs when ruleScope is custom.",
    )
    rule_scope: Literal["all", "high_impact", "custom"] = Field(
        default="all",
        alias="ruleScope",
        description="Which transformation rules to apply from rulesRemediation.",
    )
    source_database_version: str = Field(default="Oracle 19c", alias="sourceDatabaseVersion")
    ai_agent: str = Field(default="claude-sonnet-5-5", alias="aiAgent")

    @field_validator("target_database_version", mode="before")
    @classmethod
    def normalize_target_database_version(cls, value: Any) -> str:
        """Accept 15/16 and dotted forms such as 15.0 from clients."""
        if isinstance(value, bool):
            raise ValueError("targetDatabaseVersion must be 15 or 16")
        if isinstance(value, int):
            candidate = str(value)
        elif isinstance(value, float):
            candidate = str(int(value)) if value.is_integer() else str(value)
        else:
            candidate = str(value).strip()

        if candidate in {"15", "15.0"}:
            return "15"
        if candidate in {"16", "16.0"}:
            return "16"
        raise ValueError("targetDatabaseVersion must be 15 or 16")

    class Config:
        populate_by_name = True


class LaunchOraclePgTransformationResponse(BaseModel):
    job_id: str = Field(..., alias="jobId")
    status: str
    workspace_path: str = Field(..., alias="workspacePath")
    db_name: str = Field(..., alias="dbName")
    message: str = "Transformation job accepted"

    class Config:
        populate_by_name = True


class OraclePgExecutiveSummary(BaseModel):
    successfully_converted: int = Field(..., alias="successfullyConverted")
    requires_review: int = Field(..., alias="requiresReview")
    failed: int
    total_objects: int = Field(..., alias="totalObjects")

    class Config:
        populate_by_name = True


class OraclePgJobStatusResponse(BaseModel):
    job_id: str = Field(..., alias="jobId")
    status: str
    phase: str
    progress_percent: int = Field(..., alias="progressPercent")
    message: str
    sessions_completed: int = Field(default=0, alias="sessionsCompleted")
    last_completed_batch: Optional[str] = Field(default=None, alias="lastCompletedBatch")
    objects_total: int = Field(default=0, alias="objectsTotal")
    objects_converted: int = Field(default=0, alias="objectsConverted")
    artifacts: Optional[List[dict[str, Any]]] = None
    error_detail: Optional[str] = Field(default=None, alias="errorDetail")
    started_at: Optional[str] = Field(default=None, alias="startedAt")
    completed_at: Optional[str] = Field(default=None, alias="completedAt")
    duration_seconds: Optional[int] = Field(default=None, alias="durationSeconds")
    duration: Optional[str] = None
    executive_summary: Optional[OraclePgExecutiveSummary] = Field(
        default=None, alias="executiveSummary"
    )

    class Config:
        populate_by_name = True

    @classmethod
    def from_progress(
        cls,
        progress: dict[str, Any],
        *,
        executive_summary: Optional[dict[str, Any]] = None,
    ) -> "OraclePgJobStatusResponse":
        from app.services.oracle_pg.report_metrics import timing_fields_for_api

        timing = timing_fields_for_api(progress)
        exec_model = None
        if executive_summary is not None:
            exec_model = OraclePgExecutiveSummary(**executive_summary)

        return cls(
            jobId=progress.get("jobId", ""),
            status=progress.get("status", "unknown"),
            phase=progress.get("phase", ""),
            progressPercent=progress.get("progressPercent", 0),
            message=progress.get("message", ""),
            sessionsCompleted=progress.get("sessionsCompleted", 0),
            lastCompletedBatch=progress.get("lastCompletedBatch"),
            objectsTotal=progress.get("objectsTotal", 0),
            objectsConverted=progress.get("objectsConverted", 0),
            artifacts=progress.get("artifacts"),
            errorDetail=progress.get("errorDetail"),
            startedAt=timing.get("startedAt"),
            completedAt=timing.get("completedAt"),
            durationSeconds=timing.get("durationSeconds"),
            duration=timing.get("duration"),
            executiveSummary=exec_model,
        )


class OraclePgLogEntry(BaseModel):
    """Human-readable log entry streamed to the UI."""

    seq: int
    timestamp: str
    phase: str
    icon: str
    message: str
    color: str
    job_id: Optional[str] = Field(default=None, alias="jobId")

    class Config:
        populate_by_name = True


class OraclePgArtifactsResponse(BaseModel):
    job_id: str = Field(..., alias="jobId")
    db_name: str = Field(..., alias="dbName")
    artifacts: List[dict[str, Any]]

    class Config:
        populate_by_name = True


class OraclePgObjectsResponse(BaseModel):
    job_id: str = Field(..., alias="jobId")
    total: int
    offset: int
    limit: int
    objects: List[dict[str, Any]]

    class Config:
        populate_by_name = True


class OraclePgTransformationSummaryResponse(BaseModel):
    """Full transformation_summary.json payload for post-transformation report UI."""

    job_id: str = Field(..., alias="jobId")
    summary: dict[str, Any]

    class Config:
        populate_by_name = True
