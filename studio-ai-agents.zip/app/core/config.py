"""
Configuration management using Pydantic Settings.
Loads configuration from environment variables and settings files.
"""
import os
import threading
from typing import Optional, Union, List, Any
from pydantic import Field, field_validator, BeforeValidator
from typing_extensions import Annotated
from pydantic_settings import BaseSettings, SettingsConfigDict


def parse_comma_separated_list(v: Any) -> List[str]:
    """Parse comma-separated string into list."""
    if v is None:
        return []
    if isinstance(v, str):
        return [item.strip() for item in v.split(',') if item.strip()]
    if isinstance(v, list):
        return v
    return []


class BedrockConfig(BaseSettings):
    """AWS Bedrock configuration settings."""

    region: str = Field(
        default="us-east-1",
        description="AWS region for Bedrock"
    )

    profile: Optional[str] = Field(
        default=None,
        description="AWS profile name (None = auto-detect from ECS Task Role)"
    )

    model_id_sonnet: str = Field(
        default="anthropic.claude-3-sonnet-20240229-v1:0",
        description="Claude Sonnet model ID"
    )

    model_id_haiku: str = Field(
        default="anthropic.claude-3-haiku-20240307-v1:0",
        description="Claude Haiku model ID"
    )

    default_model: str = Field(
        default="anthropic.claude-3-sonnet-20240229-v1:0",
        description="Default model to use"
    )

    max_tokens: int = Field(
        default=64000,
        description="Maximum tokens for model responses"
    )

    temperature: float = Field(
        default=0.0,
        description="Model temperature"
    )

    model_config = SettingsConfigDict(
        env_prefix="BEDROCK_",
        case_sensitive=False,
        protected_namespaces=()  # Disable protected namespace warnings
    )


class PortkeyConfig(BaseSettings):
    """Portkey configuration settings."""

    base_url: str = Field(
        default="https://api.portkey.ai/v1",
        description="Portkey API base URL"
    )

    model_config = SettingsConfigDict(
        env_prefix="PORTKEY_",
        case_sensitive=False
    )


class OpenAICompatibleConfig(BaseSettings):
    """Env config for the OpenAI-compatible adapter (OPENAI_COMPAT_* env).

    Connection details (base URL, model id, credentials) come from Compass per
    call; these transport and generation knobs stay env-configurable. The
    generation defaults are deliberate: without them the private LLM would
    inherit the Bedrock max_tokens/temperature that LLMOrchestrator falls back
    to.
    """

    max_tokens: int = Field(default=64000, description="Max output tokens (0 = use caller value)")
    temperature: float = Field(default=0.0, description="Sampling temperature (0.0 = deterministic transformation)")
    enable_thinking: Optional[bool] = Field(default=None, description="vLLM/gemma enable_thinking (unset = not sent)")
    timeout: float = Field(default=3600.0, description="HTTP request timeout (seconds)")
    stream: bool = Field(default=True, description="Stream responses (keeps the connection from idling out mid-generation)")

    model_config = SettingsConfigDict(
        env_prefix="OPENAI_COMPAT_",
        case_sensitive=False
    )


class ResilienceConfig(BaseSettings):
    """Resilience patterns configuration."""

    # Retry configuration
    retry_max_attempts: int = Field(
        default=3,
        description="Maximum retry attempts"
    )

    retry_wait_min: int = Field(
        default=1,
        description="Minimum wait time between retries (seconds)"
    )

    retry_wait_max: int = Field(
        default=60,
        description="Maximum wait time between retries (seconds)"
    )

    retry_multiplier: int = Field(
        default=2,
        description="Exponential backoff multiplier"
    )

    # Circuit breaker configuration
    circuit_breaker_fail_threshold: int = Field(
        default=5,
        description="Number of failures before opening circuit"
    )

    circuit_breaker_timeout: int = Field(
        default=60,
        description="Circuit breaker timeout (seconds)"
    )

    # Rate limiting configuration
    rate_limit_per_minute: int = Field(
        default=60,
        description="Requests per minute limit"
    )

    rate_limit_per_hour: int = Field(
        default=1000,
        description="Requests per hour limit"
    )

    model_config = SettingsConfigDict(
        env_prefix="RESILIENCE_",
        case_sensitive=False
    )


class AssessmentRulesBatchConfig(BaseSettings):
    """Chunked batch settings for assessment / detection schema generation."""

    max_rules: int = Field(
        default=50,
        description="Maximum rules accepted per batch request",
    )
    chunk_size: int = Field(
        default=5,
        description="Rules per LLM invocation when processing a batch",
    )
    max_parallel_chunks: int = Field(
        default=2,
        description=(
            "Max concurrent chunk LLM calls per batch request "
            "(1 = sequential; global llm_rate_limiter still caps concurrency)"
        ),
        ge=1,
    )
    max_concurrent_requests: int = Field(
        default=1,
        description=(
            "Max concurrent assessment-rules-batch jobs process-wide "
            "(1 = second HTTP call waits until the first finishes)"
        ),
        ge=1,
    )
    rate_limit_max_retries: int = Field(
        default=12,
        description=(
            "Max dedicated retries for provider RateLimitError (429) per chunk "
            "before failing the chunk"
        ),
        ge=0,
    )

    model_config = SettingsConfigDict(
        env_prefix="ASSESSMENT_RULES_BATCH_",
        case_sensitive=False,
    )


class TimeoutConfig(BaseSettings):
    """Timeout configuration for different operations."""

    default: int = Field(
        default=3000,
        description="Default timeout (seconds)"
    )

    upgrade_operations: int = Field(
        default=3600,
        description="Timeout for upgrade operations (seconds)"
    )

    schema_modernization: int = Field(
        default=3000,
        description="Timeout for schema modernization (seconds)"
    )

    assessment_rules_batch: int = Field(
        default=3000,
        description="Timeout per chunk for assessment rules batch LLM calls (seconds)"
    )

    build_compilation: int = Field(
        default=1800,
        description="Timeout for build compilation (seconds)"
    )

    build_validation: int = Field(
        default=1800,
        description="Timeout for build validation and test execution (seconds)"
    )

    model_config = SettingsConfigDict(
        env_prefix="TIMEOUT_",
        case_sensitive=False
    )


class AssessmentRulesBatchConfig(BaseSettings):
    """Chunked schema generation limits for assessment-rules-batch."""

    max_rules: int = Field(
        default=50,
        description="Maximum catalog rules accepted per request",
    )
    chunk_size: int = Field(
        default=5,
        description="Rules per LLM call (smaller chunks avoid Bedrock read timeouts)",
    )
    max_parallel_chunks: int = Field(
        default=2,
        description=(
            "Max concurrent chunk LLM calls per batch request "
            "(1 = sequential; global llm_rate_limiter still caps concurrency)"
        ),
        ge=1,
    )
    max_concurrent_requests: int = Field(
        default=1,
        description=(
            "Max concurrent assessment-rules-batch jobs process-wide "
            "(1 = second HTTP call waits until the first finishes)"
        ),
        ge=1,
    )
    rate_limit_max_retries: int = Field(
        default=12,
        description=(
            "Max dedicated retries for provider RateLimitError (429) per chunk "
            "before failing the chunk"
        ),
        ge=0,
    )

    model_config = SettingsConfigDict(
        env_prefix="ASSESSMENT_RULES_BATCH_",
        case_sensitive=False,
    )


class WorkspaceConfig(BaseSettings):
    """Workspace configuration."""

    base_path: str = Field(
        default="/studio-app/claude-workspace",
        description="Base path for Claude workspace (all outputs go here)"
    )

    model_config = SettingsConfigDict(
        env_prefix="WORKSPACE_",
        case_sensitive=False
    )


class StudioCoreConfig(BaseSettings):
    """Studio Core / Compass integration configuration."""

    base_url: str = Field(
        ...,
        description="Studio Core base URL"
    )

    compass_component: str = Field(
        default="Platform Model",
        description="Compass component name for connections"
    )

    timeout: int = Field(
        default=60,
        description="API timeout (seconds) - increased for Compass API calls"
    )

    model_config = SettingsConfigDict(
        env_prefix="STUDIO_CORE_",
        case_sensitive=False
    )


class AppDbJob3Config(BaseSettings):
    """App+DB (Job 3) limits for concurrency, report packaging and path resolution.

    Job 3 has no database of its own — report state lives in the workspace.
    """

    max_concurrent_jobs: int = Field(
        default=4,
        description="Maximum App+DB transformations running at once; further launches get 429",
    )

    reuse_in_flight_launch: bool = Field(
        default=True,
        description=(
            "Return the running transformation instead of starting a second one for the "
            "same appId+dbId (idempotent launch). Set false to allow parallel runs."
        ),
    )

    report_generation_timeout_seconds: int = Field(
        default=300,
        description="Report + ZIP packaging budget; exceeding it fails the Artifacts step",
    )

    report_cache_max_age_seconds: int = Field(
        default=300,
        description="Cache-Control max-age on the saved report (it is a point-in-time snapshot)",
    )

    zip_max_size_mb: int = Field(
        default=200,
        description="Refuse to serve a transformed-code archive larger than this",
    )

    nfs_base_path: str = Field(
        default="/modernize-data/studio-data",
        description=(
            "Base of the shared NFS mount holding each app's Job 1/M-Upgrade "
            "output, used to derive projectPath when the caller sends "
            "tenantId+planId instead of an already-resolved path: "
            "{nfs_base_path}/{tenantId}/{appId}/transformed-code/{planId}/"
            "studio-workspace/{componentName}. Matches studio-core's "
            "studio.nfs.base-path."
        ),
    )


def _claude_schema_agent_bedrock_env(
    *,
    sonnet_model_id: str,
    aws_region: str,
    api_timeout_ms: int,
    max_retries: int,
    stream_close_timeout_ms: int,
) -> dict[str, str]:
    """Bedrock env for Claude Code CLI (Oracle and MSSQL schema agents)."""
    return {
        "CLAUDE_CODE_USE_BEDROCK": "1",
        "AWS_REGION": aws_region,
        "ANTHROPIC_DEFAULT_SONNET_MODEL": sonnet_model_id,
        "API_TIMEOUT_MS": str(api_timeout_ms),
        "CLAUDE_CODE_MAX_RETRIES": str(max_retries),
        "CLAUDE_CODE_STREAM_CLOSE_TIMEOUT": str(stream_close_timeout_ms),
    }


class OraclePgAgentConfig(BaseSettings):
    """Claude Agent SDK settings for Oracle → PostgreSQL schema transformation."""

    enabled: bool = Field(
        default=True,
        description="Enable Oracle PG transformation API",
    )

    max_concurrent_jobs: int = Field(
        default=5,
        description="Maximum simultaneous transformation jobs",
    )

    sonnet_model_id: str = Field(
        default="us.anthropic.claude-sonnet-5-5",
        description="Bedrock inference profile ID for Sonnet 5.5",
    )

    max_turns_per_session: int = Field(
        default=50,
        description="Maximum agentic turns per SDK session",
    )

    max_budget_usd_per_session: float = Field(
        default=25.0,
        description="Per-session USD budget cap for Claude Agent SDK",
    )

    max_buffer_size_bytes: int = Field(
        default=50 * 1024 * 1024,
        description="Claude Agent SDK stdout JSON buffer (SDK default is 1MB)",
    )

    resume_on_startup: bool = Field(
        default=True,
        description="Resume in_progress jobs found on workspace at startup",
    )

    cli_path: Optional[str] = Field(
        default=None,
        description="Optional override for bundled Claude Code CLI (claude-agent-sdk ships one by default)",
    )

    input_mode_compass: str = Field(
        default="compass_files",
        description="job_config inputMode value when launch uses inputPaths",
    )

    input_mode_inline: str = Field(
        default="inline_assessment",
        description="job_config inputMode value when launch uses inline assessmentData",
    )

    api_timeout_ms: int = Field(
        default=600000,
        description="API timeout passed to Claude Code CLI (milliseconds)",
    )

    max_retries: int = Field(
        default=2,
        description="Maximum API retries for Claude Code CLI",
    )

    stream_close_timeout_ms: int = Field(
        default=180000,
        description=(
            "Initialize handshake timeout for Claude Agent SDK query() (milliseconds). "
            "SDK reads CLAUDE_CODE_STREAM_CLOSE_TIMEOUT from process env (60s floor); "
            "agent_runner copies this value there as well as into ClaudeAgentOptions.env."
        ),
    )

    model_config = SettingsConfigDict(
        env_prefix="ORACLE_PG_AGENT_",
        case_sensitive=False,
    )

    def bedrock_env(self, aws_region: str) -> dict[str, str]:
        """Environment variables for ClaudeAgentOptions.env (Bedrock + Sonnet 5.5)."""
        return _claude_schema_agent_bedrock_env(
            sonnet_model_id=self.sonnet_model_id,
            aws_region=aws_region,
            api_timeout_ms=self.api_timeout_ms,
            max_retries=self.max_retries,
            stream_close_timeout_ms=self.stream_close_timeout_ms,
        )


class MssqlPgAgentConfig(BaseSettings):
    """Claude Agent SDK settings for MSSQL → PostgreSQL schema transformation."""

    enabled: bool = Field(default=True, description="Enable MSSQL PG transformation API")

    max_concurrent_jobs: int = Field(default=5, description="Maximum simultaneous transformation jobs")

    sonnet_model_id: str = Field(
        default="us.anthropic.claude-sonnet-5-5",
        description="Bedrock inference profile ID for Sonnet 5.5",
    )

    max_turns_per_session: int = Field(default=3, description="Maximum agentic turns per object conversion call")
    max_budget_usd_per_session: float = Field(default=5.0, description="USD budget cap per object conversion call")
    max_buffer_size_bytes: int = Field(default=50 * 1024 * 1024)
    cli_path: Optional[str] = Field(default=None)
    api_timeout_ms: int = Field(default=600000, description="API timeout passed to Claude Code CLI (milliseconds)")
    max_retries: int = Field(default=2, description="Maximum API retries for Claude Code CLI")
    stream_close_timeout_ms: int = Field(default=180000, description="Initialize handshake timeout (milliseconds)")

    ai_call_timeout_seconds: int = Field(default=600, description="Wall-clock limit for a single object conversion call")
    ai_timeout_retries: int = Field(default=1, description="Additional attempts after an AI call times out")
    ai_concurrency: int = Field(default=4, description="Parallel object conversions within one job")

    resume_on_startup: bool = Field(default=True, description="Resume queued/in_progress jobs found at startup")
    expected_rule_count: int = Field(
        default=116,
        description="Expected MSSQL incompatibility rule count; a mismatch is a warning, not a halt",
    )
    input_mode_compass: str = Field(default="compass_files")
    engine_version: str = Field(default="mssql-pg-1.0.0")
    missing_source_halt_percent: float = Field(
        default=5.0,
        description="Halt the job when AS-IS objects missing from the DDL script exceed this percent; 0 disables",
    )

    model_config = SettingsConfigDict(
        env_prefix="MSSQL_PG_AGENT_",
        case_sensitive=False,
    )

    def bedrock_env(self, aws_region: str) -> dict[str, str]:
        """Environment variables for ClaudeAgentOptions.env (Bedrock + Sonnet 5.5)."""
        return _claude_schema_agent_bedrock_env(
            sonnet_model_id=self.sonnet_model_id,
            aws_region=aws_region,
            api_timeout_ms=self.api_timeout_ms,
            max_retries=self.max_retries,
            stream_close_timeout_ms=self.stream_close_timeout_ms,
        )


class AgenticConfig(BaseSettings):
    """Agentic tool execution configuration."""

    enabled: bool = Field(
        default=True,
        description="Enable agentic tool execution (multi-turn conversations)"
    )

    max_iterations: int = Field(
        default=10,
        description="Maximum iterations in agentic loop. Set to 0 for unlimited (production mode). Legacy - use graph_orchestration instead"
    )
    
    unlimited_iterations: bool = Field(
        default=True,
        description="Enable unlimited iterations mode - continue until end_turn or safety limits. For production use with large codebases"
    )

    tool_execution_timeout: int = Field(
        default=30,
        description="Timeout for individual tool execution (seconds)"
    )

    max_consecutive_errors: int = Field(
        default=10,
        description="Maximum consecutive tool execution errors before stopping"
    )

    graph_orchestration_enabled: bool = Field(
        default=True,
        description="Use dependency graph orchestration instead of max_iterations"
    )

    max_module_retries: int = Field(
        default=3,
        description="Maximum retries per module in graph orchestration"
    )

    validation_timeout: int = Field(
        default=300,
        description="Timeout for compiler validation per module (seconds)"
    )
    
    skip_validation: bool = Field(
        default=True,
        description="Skip compiler-based validation (builds) during transformation phase. Set to False to enable builds after transformation. Default True ensures transformation completes without building."
    )

    model_config = SettingsConfigDict(
        env_prefix="AGENTIC_",
        case_sensitive=False
    )


class BedrockRateLimiterConfig(BaseSettings):
    """
    Per-provider rate limiter overrides for AWS Bedrock.
    When a field is 0 the global LLMRateLimiterConfig value is used instead.
    """

    requests_per_minute: int = Field(
        default=0,
        description="Bedrock RPM override (0 = use global LLM_RATE_LIMITER_REQUESTS_PER_MINUTE)"
    )

    tokens_per_minute: int = Field(
        default=0,
        description="Bedrock TPM override (0 = use global LLM_RATE_LIMITER_TOKENS_PER_MINUTE)"
    )

    max_concurrent: int = Field(
        default=0,
        description="Bedrock max concurrent override (0 = use global LLM_RATE_LIMITER_MAX_CONCURRENT)"
    )

    model_config = SettingsConfigDict(
        env_prefix="BEDROCK_RATE_LIMITER_",
        case_sensitive=False
    )


class PortkeyRateLimiterConfig(BaseSettings):
    """
    Per-provider rate limiter overrides for Portkey.
    When a field is 0 the global LLMRateLimiterConfig value is used instead.
    """

    requests_per_minute: int = Field(
        default=0,
        description="Portkey RPM override (0 = use global LLM_RATE_LIMITER_REQUESTS_PER_MINUTE)"
    )

    tokens_per_minute: int = Field(
        default=0,
        description="Portkey TPM override (0 = use global LLM_RATE_LIMITER_TOKENS_PER_MINUTE)"
    )

    max_concurrent: int = Field(
        default=0,
        description="Portkey max concurrent override (0 = use global LLM_RATE_LIMITER_MAX_CONCURRENT)"
    )

    model_config = SettingsConfigDict(
        env_prefix="PORTKEY_RATE_LIMITER_",
        case_sensitive=False
    )


class LLMRateLimiterConfig(BaseSettings):
    """
    Configuration for the proactive LLM outbound rate limiter.

    Controls three mechanisms applied before every LLM API call:
      1. Semaphore  — max_concurrent simultaneous in-flight calls
      2. RPM bucket — requests_per_minute token bucket
      3. TPM bucket — tokens_per_minute token bucket
      4. Adaptive delay — inter-call sleep that self-tunes based on outcomes

    All values are read from LLM_RATE_LIMITER_* environment variables.
    Per-provider overrides come from BEDROCK_RATE_LIMITER_* / PORTKEY_RATE_LIMITER_*.
    """

    enabled: bool = Field(
        default=False,
        description="Master toggle for the LLM rate limiter"
    )

    # Hard quota limits
    requests_per_minute: int = Field(
        default=30,
        description="Max LLM requests per minute (0 = unlimited)"
    )

    tokens_per_minute: int = Field(
        default=100000,
        description="Max tokens per minute across all LLM calls (0 = unlimited)"
    )

    max_concurrent: int = Field(
        default=5,
        description="Max simultaneous in-flight LLM calls"
    )

    # Adaptive delay tuning
    initial_delay: float = Field(
        default=1.0,
        description="Starting inter-call delay in seconds"
    )

    min_delay: float = Field(
        default=0.3,
        description="Minimum inter-call delay floor (seconds)"
    )

    max_delay: float = Field(
        default=30.0,
        description="Maximum inter-call delay ceiling (seconds)"
    )

    success_threshold: int = Field(
        default=5,
        description="Consecutive successes before reducing inter-call delay"
    )

    decrease_factor: float = Field(
        default=0.8,
        description="Multiply current delay by this on success streak (< 1.0 to speed up)"
    )

    increase_factor: float = Field(
        default=1.5,
        description="Multiply current delay by this on throttle (> 1.0 to slow down)"
    )

    throttle_recovery: float = Field(
        default=60.0,
        description="Extra sleep (seconds) applied at start of next acquire() after a 429"
    )

    # Token estimation
    default_estimated_tokens: int = Field(
        default=8000,
        description="Default token estimate for calls that do not know their count upfront"
    )

    # Feature toggles
    enable_adaptive_delays: bool = Field(
        default=True,
        description="Enable adaptive delay sub-system (self-tunes based on success/throttle)"
    )

    enable_token_tracking: bool = Field(
        default=True,
        description="Enable TPM token bucket tracking"
    )

    enable_metrics: bool = Field(
        default=False,
        description="Emit structured rate limiter metrics to logs periodically"
    )

    # Per-provider overrides
    bedrock: BedrockRateLimiterConfig = Field(default_factory=BedrockRateLimiterConfig)
    portkey: PortkeyRateLimiterConfig = Field(default_factory=PortkeyRateLimiterConfig)

    model_config = SettingsConfigDict(
        env_prefix="LLM_RATE_LIMITER_",
        case_sensitive=False
    )


class SecurityConfig(BaseSettings):
    """Security validation configuration."""

    validation_enabled: bool = Field(
        default=True,
        description="Enable/disable security validation"
    )

    bash_command_validation_enabled: bool = Field(
        default=True,
        description="Enable/disable bash command validation (set to false to allow all commands)"
    )
    
    bypass_validation_for_allowed_directories: bool = Field(
        default=False,
        description="Skip security validation for commands in allowed directories (/test-code, etc.)"
    )

    path_traversal_protection_enabled: bool = Field(
        default=True,
        description="Enable/disable path traversal protection"
    )

    allowed_directories: str = Field(
        default="/test-code,/studio-app",
        description="Allowed directories for file operations (comma-separated)"
    )

    allow_safe_pipes: bool = Field(
        default=True,
        description="Allow safe read-only pipes in bash commands"
    )

    allow_safe_command_chains: bool = Field(
        default=True,
        description="Allow safe command chaining with && or || when all commands are whitelisted"
    )

    def get_allowed_directories_list(self) -> List[str]:
        """Parse and return allowed directories as a list."""
        if isinstance(self.allowed_directories, str):
            return [d.strip() for d in self.allowed_directories.split(',') if d.strip()]
        return []

    model_config = SettingsConfigDict(
        env_prefix="SECURITY_",
        case_sensitive=False
    )


class CloudReadinessConfig(BaseSettings):
    """
    Cloud Readiness operation configuration.

    Controls the rule-batched execution mode for cloudreadiness-fix.
    When batch_by_rule is True, the handler parses the embedded analysis JSON
    from the prompt file (after the 'ANALYSIS REPORT:' separator), groups
    blockers by ruleId, and calls the AI model once per unique rule — then
    merges all results into a single output file.

    Toggle via env var:
        CLOUDREADINESS_BATCH_BY_RULE=true   → batched mode
        CLOUDREADINESS_BATCH_BY_RULE=false  → single-call mode (default)
    """

    batch_by_rule: bool = Field(
        default=True,
        description=(
            "When True, parse the analysis JSON embedded in the prompt file and "
            "invoke the AI model once per unique ruleId group (sequential). "
            "Results from all rule calls are merged into one output file."
        )
    )

    analysis_separator: str = Field(
        default="ANALYSIS REPORT:",
        description=(
            "Separator line in the prompt file that marks where the base prompt "
            "ends and the embedded analysis JSON begins."
        )
    )

    max_occurrences_per_call: int = Field(
        default=10,
        description=(
            "Maximum number of occurrences sent to the AI model in a single call "
            "for a given ruleId. If a rule has more occurrences than this, they "
            "are split into sequential sub-batches (e.g. 20 occurrences with a "
            "limit of 10 becomes two calls: 1-10, then 11-20)."
        )
    )

    model_config = SettingsConfigDict(
        env_prefix="CLOUDREADINESS_",
        case_sensitive=False
    )


class SelectiveFixConfig(BaseSettings):
    """
    Selective Fix operation configuration.

    Controls the blocker-batched execution mode for selective-fix.
    When batch_by_rule is True, the handler parses the JSON array embedded
    in the prompt file (after the 'IMPORTANT: Fix ONLY these specific
    blockers:' separator), groups blockers by ruleId, and calls the AI
    model once per unique rule — then merges all results into a single
    output file, same pattern as cloudreadiness-fix.

    Toggle via env var:
        SELECTIVE_FIX_BATCH_BY_RULE=true   → batched mode
        SELECTIVE_FIX_BATCH_BY_RULE=false  → single-call mode (default)
    """

    batch_by_rule: bool = Field(
        default=True,
        description=(
            "When True, parse the blockers JSON array embedded in the prompt file "
            "and invoke the AI model once per unique ruleId group (sequential). "
            "Results from all rule calls are merged into one output file."
        )
    )

    blockers_separator: str = Field(
        default="IMPORTANT: Fix ONLY these specific blockers:",
        description=(
            "Separator line in the prompt file that marks where the base prompt "
            "ends and the embedded blockers JSON array begins."
        )
    )

    max_occurrences_per_call: int = Field(
        default=30,
        description=(
            "Maximum number of occurrences sent to the AI model in a single call "
            "for a given ruleId. If a rule has more occurrences than this, they "
            "are split into sequential sub-batches (e.g. 20 occurrences with a "
            "limit of 10 becomes two calls: 1-10, then 11-20)."
        )
    )

    model_config = SettingsConfigDict(
        env_prefix="SELECTIVE_FIX_",
        case_sensitive=False
    )


class NatsConfig(BaseSettings):
    """NATS transport configuration for schema-generation flow."""

    enabled: bool = Field(
        default=True,
                description=(
                    "Enable NATS subscriber/publisher for schema generation. "
                    "Set NATS_ENABLED=false to disable (e.g. local dev without NATS/SQLite)."
                ),
    )
    servers: Annotated[List[str], BeforeValidator(parse_comma_separated_list)] = Field(
        default_factory=lambda: ["nats://localhost:4222"],
        description="Comma-separated NATS server URLs",
    )
    client_name: str = Field(
        default="studio-ai-agents",
        description="NATS client name",
    )
    connect_timeout_seconds: int = Field(
        default=10,
        description="NATS connect timeout in seconds (aligns with Rules Management jnats default)",
    )
    reconnect_wait_seconds: int = Field(
        default=2,
        description="NATS reconnect wait in seconds",
    )
    max_reconnects: int = Field(
        default=60,
        description="NATS max reconnect attempts",
    )
    sqlite_config_db_path: str = Field(
        default="/etc/app-config/config.db",
        description=(
            "SQLite DB path or JDBC URI (same as Rules Management: "
            "jdbc:sqlite:/etc/app-config/config.db). "
            "Override with NATS_SQLITE_CONFIG_DB_PATH on Windows/local dev."
        ),
    )
    sqlite_config_allowed_dir: str = Field(
        default="/etc/app-config",
        description=(
            "Root directory that NATS SQLite config paths must resolve under "
            "(prevents path traversal / filesystem oracle attacks)."
        ),
    )
    schema_generate_request_subject: str = Field(
        default="schema.generate.request",
        description="NATS subject to subscribe for schema generation requests",
    )
    schema_generate_result_subject: str = Field(
        default="schema.generate.result",
        description="NATS subject to publish schema generation results",
    )
    project_path: Optional[str] = Field(
        default=None,
        description=(
            "Optional projectPath for NATS-driven requests. When unset, the "
            "service creates a private workspace directory per analysisId."
        ),
    )
    platform: str = Field(
        default="linux",
        description="Platform used for NATS-driven requests",
    )

    model_config = SettingsConfigDict(
        env_prefix="NATS_",
        case_sensitive=False,
    )


class Settings(BaseSettings):
    """
    Main application settings.
    Loads configuration from environment variables and .env file.
    """

    # Application settings
    app_name: str = Field(
        default="studio-ai-engine-python",
        description="Application name"
    )

    app_version: str = Field(
        default="1.0.0",
        description="Application version"
    )

    debug: bool = Field(
        default=False,
        description="Debug mode"
    )

    # AWS region (global)
    aws_region: str = Field(
        default="us-east-1",
        description="AWS region"
    )

    aws_profile: str = Field(
        default="default",
        description="AWS profile"
    )

    # Bedrock model IDs
    bedrock_model_id: str = Field(
        default="anthropic.claude-3-sonnet-20240229-v1:0",
        description="Primary Bedrock model ID"
    )

    bedrock_model_id_haiku: str = Field(
        default="anthropic.claude-3-haiku-20240307-v1:0",
        description="Haiku model ID for faster operations"
    )

    # Studio Core
    studio_core_url: str = Field(
        ...,
        description="Studio Core base URL"
    )

    compass_component: str = Field(
        default="Platform Model",
        description="Compass component name"
    )

    git_step_sync_enabled: bool = Field(
        default=True,
        description=(
            "Ask Studio Core to sync the branch before each step and to commit and push it after "
            "each successful step (only a rejected push fails the step)"
        )
    )

    git_step_sync_timeout_seconds: int = Field(
        default=180,
        description="Read timeout (seconds) for the Studio Core git step sync call"
    )

    git_step_commit_push_timeout_seconds: int = Field(
        default=600,
        description="Read timeout (seconds) for the Studio Core git step commit-and-push call"
    )

    # Workspace
    claude_workspace: str = Field(
        default="/studio-app/claude-workspace",
        description="Claude workspace base path (all outputs go here)"
    )

    # Encryption
    encryption_key: str = Field(
        ...,
        description="Encryption key for credentials"
    )

    enc_passphrase: Optional[str] = Field(
        default=None,
        description=(
            "Passphrase for decryptGCMValues-style secrets (NATS user/password in env_config). "
            "Set via ENC_PASSPHRASE. Required when NATS is enabled outside debug mode."
        ),
    )

    # Timeouts
    timeout_default: int = Field(
        default=3000,
        description="Default operation timeout (seconds)"
    )

    timeout_upgrade: int = Field(
        default=3600,
        description="Upgrade operation timeout (seconds)"
    )

    # CORS
    cors_allow_origins: Union[list[str], str] = Field(
        default=["*"],
        description="CORS allowed origins (list or comma-separated string)"
    )

    cors_allow_credentials: bool = Field(
        default=True,
        description="CORS allow credentials"
    )

    cors_allow_methods: Union[list[str], str] = Field(
        default=["*"],
        description="CORS allowed methods (list or comma-separated string)"
    )

    cors_allow_headers: Union[list[str], str] = Field(
        default=["*"],
        description="CORS allowed headers (list or comma-separated string)"
    )

    # Validators for CORS settings
    @field_validator('cors_allow_origins', 'cors_allow_methods', 'cors_allow_headers', mode='before')
    @classmethod
    def parse_cors_list(cls, v):
        """Parse CORS settings from string or list."""
        if isinstance(v, str):
            # Handle comma-separated string
            return [item.strip() for item in v.split(',') if item.strip()]
        return v

    # Nested configurations
    bedrock: BedrockConfig = Field(default_factory=BedrockConfig)
    portkey: PortkeyConfig = Field(default_factory=PortkeyConfig)
    openai_compatible: OpenAICompatibleConfig = Field(default_factory=OpenAICompatibleConfig)
    resilience: ResilienceConfig = Field(default_factory=ResilienceConfig)
    timeouts: TimeoutConfig = Field(default_factory=TimeoutConfig)
    assessment_rules_batch: AssessmentRulesBatchConfig = Field(
        default_factory=AssessmentRulesBatchConfig
    )
    workspace: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    studio_core: Optional[StudioCoreConfig] = None
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    nats: NatsConfig = Field(default_factory=NatsConfig)
    assessment_rules_batch: AssessmentRulesBatchConfig = Field(
        default_factory=AssessmentRulesBatchConfig,
    )
    agentic: AgenticConfig = Field(default_factory=AgenticConfig)
    oracle_pg_agent: OraclePgAgentConfig = Field(default_factory=OraclePgAgentConfig)
    mssql_pg_agent: MssqlPgAgentConfig = Field(default_factory=MssqlPgAgentConfig)
    app_db_job3: AppDbJob3Config = Field(default_factory=AppDbJob3Config)
    llm_rate_limiter: LLMRateLimiterConfig = Field(default_factory=LLMRateLimiterConfig)
    cloudreadiness: CloudReadinessConfig = Field(default_factory=CloudReadinessConfig)
    selective_fix: SelectiveFixConfig = Field(default_factory=SelectiveFixConfig)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="allow"
    )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Initialize nested configs with global values
        if not self.bedrock:
            self.bedrock = BedrockConfig(
                region=self.aws_region,
                profile=self.aws_profile,
                default_model=self.bedrock_model_id,
                model_id_sonnet=self.bedrock_model_id,
                model_id_haiku=self.bedrock_model_id_haiku
            )

        if not self.workspace:
            self.workspace = WorkspaceConfig(
                base_path=self.claude_workspace
            )

        if not self.timeouts:
            self.timeouts = TimeoutConfig(
                default=self.timeout_default,
                upgrade_operations=self.timeout_upgrade
            )

        if not self.studio_core:
            self.studio_core = StudioCoreConfig(
                base_url=self.studio_core_url,
                compass_component=self.compass_component
            )

    def get_timeout_for_operation(self, operation: str) -> int:
        """
        Get timeout for specific operation type.
        Matches Java's timeout logic.

        Args:
            operation: Operation type

        Returns:
            Timeout in seconds
        """
        if operation in ["fix-upgrade", "cloudreadiness-fix", "db-code-modernize-fix"]:
            return self.timeouts.upgrade_operations
        elif operation == "schema-modernization":
            return self.timeouts.schema_modernization
        elif operation in ["build-compilation", "dotnet-build-compilation"]:
            return self.timeouts.build_compilation
        else:
            return self.timeouts.default


# Global settings instance with thread-safe singleton
settings: Optional[Settings] = None
_settings_lock = threading.Lock()


def get_settings() -> Settings:
    """
    Get or create global settings instance (thread-safe singleton).

    Uses double-checked locking pattern to ensure thread safety
    while minimizing lock contention.

    Returns:
        Settings instance
    """
    global settings

    # Fast path without locking for performance
    if settings is not None:
        return settings

    # Slow path with locking for thread safety
    with _settings_lock:
        # Double-check pattern to avoid race conditions
        if settings is None:
            settings = Settings()

    return settings


def reload_settings() -> Settings:
    """
    Reload settings from environment.
    Useful for testing or dynamic configuration changes.

    Returns:
        New Settings instance
    """
    global settings

    with _settings_lock:
        settings = Settings()

    return settings
