"""
Security validation module.
Equivalent to Java's SecureCommandExecutor class.
Prevents command injection, path traversal, and other security vulnerabilities.
"""
import re
import os
from typing import Optional, List
from pathlib import Path
from app.core.config import get_settings


class SecurityValidator:
    """
    Security validator for preventing command injection and path traversal attacks.
    Ports the validation logic from Java's SecureCommandExecutor.

    Key security controls:
    - Dangerous character detection (;, &, |, `, $, etc.)
    - Platform-specific path format validation
    - Alphanumeric validation for identifiers
    - Shell escaping for safe command execution
    """

    # Dangerous characters that could enable command injection
    # Matches Java's SecureCommandExecutor.DANGEROUS_CHARS
    DANGEROUS_CHARS = [
        ";",   # Command separator
        "&",   # Background execution
        "|",   # Pipe
        "`",   # Command substitution
        "$",   # Variable expansion
        "(",   # Subshell
        ")",   # Subshell
        "{",   # Brace expansion
        "}",   # Brace expansion
        "[",   # Character class
        "]",   # Character class
        "<",   # Input redirection
        ">",   # Output redirection
        "*",   # Glob
        "?",   # Glob
        "~",   # Home directory expansion
        "!",   # History expansion
        "\n",  # Newline
        "\r",  # Carriage return
        '"',   # Double quote (can break quoting)
        # Note: Single quote (') is handled differently in escapeForShell
    ]

    # Characters rejected in paths that are only ever handed to filesystem APIs
    # (never interpolated into a shell command line). This is deliberately much
    # narrower than DANGEROUS_CHARS: shell-only metacharacters such as (, ), [, ],
    # {, }, ~, !, *, ? are legal in POSIX/Windows filenames and appear routinely in
    # artifacts produced by upstream tooling (e.g. "oracle_ddl_export (1).sql").
    FILESYSTEM_DANGEROUS_CHARS = [
        "\x00",  # NUL - illegal in every filesystem, truncates C strings
        "\n",    # Newline - log/header injection
        "\r",    # Carriage return - log/header injection
        ";",     # Command separator
        "|",     # Pipe
        "&",     # Background execution
        "`",     # Command substitution
        "$",     # Variable expansion
        "<",     # Input redirection
        ">",     # Output redirection
        '"',     # Double quote
    ]

    # Path validation patterns
    # Matches alphanumeric, spaces, hyphens, underscores, dots, slashes, colons
    SAFE_PATH_PATTERN = re.compile(r'^[a-zA-Z0-9\s\-_./:]+$')

    # Windows path pattern: C:\path\to\file or C:/path/to/file
    WINDOWS_PATH_PATTERN = re.compile(r'^[a-zA-Z]:[\\/ ]?[a-zA-Z0-9\s\-_.\\/ ]*$')

    # Linux/Unix path pattern: /path/to/file
    LINUX_PATH_PATTERN = re.compile(r'^/[a-zA-Z0-9\s\-_./ ]*$')

    # Alphanumeric with hyphens and underscores (for analysisId, etc.)
    ALPHANUMERIC_PATTERN = re.compile(r'^[a-zA-Z0-9\-_]+$')

    @staticmethod
    def is_safe_absolute_path(
        file_path: str,
        project_path: str,
        allowed_dirs: Optional[List[str]] = None
    ) -> bool:
        """
        Check if an absolute path is within project or allowed directories.

        This method allows absolute paths as long as they're within approved directories,
        preventing the overly restrictive blocking of all absolute paths.

        Args:
            file_path: Path to validate (can be absolute or relative)
            project_path: Project base directory path
            allowed_dirs: List of allowed directory paths (optional)

        Returns:
            True if path is safe (within allowed directories), False otherwise

        Examples:
            >>> SecurityValidator.is_safe_absolute_path(
            ...     "/test-code/mini-java-app/pom.xml",
            ...     "/test-code/mini-java-app",
            ...     ["/test-code"]
            ... )
            True

            >>> SecurityValidator.is_safe_absolute_path(
            ...     "/etc/passwd",
            ...     "/test-code/mini-java-app",
            ...     ["/test-code"]
            ... )
            False
        """
        try:
            # Convert to absolute path if relative
            if not os.path.isabs(file_path):
                file_path = os.path.join(project_path, file_path)

            resolved_path = Path(file_path).resolve()

            # Check if within project directory
            try:
                project_resolved = Path(project_path).resolve()
                resolved_path.relative_to(project_resolved)
                return True
            except ValueError:
                # Not within project, check allowed directories
                pass

            # Check if within allowed directories
            if allowed_dirs:
                for allowed_dir in allowed_dirs:
                    try:
                        allowed_resolved = Path(allowed_dir).resolve()
                        resolved_path.relative_to(allowed_resolved)
                        return True
                    except ValueError:
                        continue

            return False
        except Exception:
            # If any error occurs during path resolution, be safe and reject
            return False

    @staticmethod
    def validate_path(path: str, path_type: str = "path") -> str:
        """
        Validate file path to prevent command injection and path traversal.

        Equivalent to Java's SecureCommandExecutor.validatePath()

        Args:
            path: Path to validate
            path_type: Type descriptor for error messages (e.g., "prompt", "project", "output")

        Returns:
            Validated path (same as input if valid)

        Raises:
            ValueError: If path is empty, contains dangerous characters, or doesn't match platform format

        Examples:
            >>> SecurityValidator.validate_path("/home/user/project", "project")
            '/home/user/project'

            >>> SecurityValidator.validate_path("C:/Users/Project", "project")
            'C:/Users/Project'

            >>> SecurityValidator.validate_path("/path/with;semicolon", "test")
            ValueError: Invalid test path: contains dangerous character ';'
        """
        if not path:
            raise ValueError(f"{path_type} path cannot be empty")

        if not path.strip():
            raise ValueError(f"{path_type} path cannot be blank or whitespace only")

        # Check for dangerous characters
        for dangerous in SecurityValidator.DANGEROUS_CHARS:
            if dangerous in path:
                raise ValueError(
                    f"Invalid {path_type} path: contains dangerous character '{dangerous}'"
                )

        # Platform-specific validation
        if path.startswith('/'):
            # Linux/Unix path
            if not SecurityValidator.LINUX_PATH_PATTERN.match(path):
                raise ValueError(
                    f"Invalid {path_type} path: does not match Linux path format. "
                    f"Path must start with / and contain only alphanumeric, spaces, hyphens, "
                    f"underscores, dots, and slashes."
                )
        elif re.match(r'^[a-zA-Z]:', path):
            # Windows path
            if not SecurityValidator.WINDOWS_PATH_PATTERN.match(path):
                raise ValueError(
                    f"Invalid {path_type} path: does not match Windows path format. "
                    f"Path must start with drive letter (e.g., C:) and contain only valid Windows path characters."
                )
        else:
            # Relative path or invalid format
            # For security, we could either reject relative paths or validate them
            # Java implementation doesn't explicitly handle this case
            # Let's validate against safe pattern
            if not SecurityValidator.SAFE_PATH_PATTERN.match(path):
                raise ValueError(
                    f"Invalid {path_type} path: path format not recognized. "
                    f"Must be an absolute Linux path (/path) or Windows path (C:\\path)"
                )

        return path

    @staticmethod
    def validate_filesystem_path(path: str, path_type: str = "path") -> str:
        """
        Validate a path that is only ever resolved through filesystem APIs.

        Unlike :meth:`validate_path`, which guards values that end up on a shell
        command line, this accepts every character that is legal in a filename —
        spaces, parentheses, brackets, braces, '#', '%', '+', ',', '@', '=', "'",
        '~', '!', '*', '?' — because exported assessment artifacts are commonly
        named things like ``oracle_ddl_export (1).sql``. Only NUL, newlines and
        shell metacharacters that never legitimately appear in tool-generated
        filenames are rejected.

        Containment is NOT checked here: callers must still confine the resolved
        path to an allowed root (see ``workspace.ensure_path_under_job_root``).

        Args:
            path: Path to validate
            path_type: Type descriptor for error messages (e.g. "inputPaths.ddlExport")

        Returns:
            Validated path (same as input if valid)

        Raises:
            ValueError: If path is empty, blank, or contains a rejected character

        Examples:
            >>> SecurityValidator.validate_filesystem_path("_claude/ddl (1).sql", "ddlExport")
            '_claude/ddl (1).sql'

            >>> SecurityValidator.validate_filesystem_path("_claude/a;rm -rf b.sql", "ddlExport")
            ValueError: Invalid ddlExport path: contains dangerous character ';'
        """
        if not path:
            raise ValueError(f"{path_type} path cannot be empty")

        if not path.strip():
            raise ValueError(f"{path_type} path cannot be blank or whitespace only")

        for dangerous in SecurityValidator.FILESYSTEM_DANGEROUS_CHARS:
            if dangerous in path:
                raise ValueError(
                    f"Invalid {path_type} path: contains dangerous character "
                    f"'{dangerous.encode('unicode_escape').decode()}'"
                )

        # Any other C0 control character is rejected too (not a real filename char).
        for char in path:
            if ord(char) < 0x20 or ord(char) == 0x7F:
                raise ValueError(
                    f"Invalid {path_type} path: contains control character "
                    f"'{char.encode('unicode_escape').decode()}'"
                )

        return path

    @staticmethod
    def validate_alphanumeric(value: str, field_name: str) -> str:
        """
        Validate that string contains only alphanumeric characters, hyphens, and underscores.
        Used for validating analysisId, operation names, and other identifiers.

        Equivalent to Java's SecureCommandExecutor.validateAlphanumeric()

        Args:
            value: String to validate
            field_name: Field name for error messages

        Returns:
            Validated string (same as input if valid)

        Raises:
            ValueError: If value is empty or contains invalid characters

        Examples:
            >>> SecurityValidator.validate_alphanumeric("analysis-123", "analysisId")
            'analysis-123'

            >>> SecurityValidator.validate_alphanumeric("test_id_456", "testId")
            'test_id_456'

            >>> SecurityValidator.validate_alphanumeric("invalid;id", "analysisId")
            ValueError: Invalid analysisId: must contain only alphanumeric, hyphens, underscores
        """
        if not value:
            raise ValueError(f"{field_name} cannot be empty")

        if not value.strip():
            raise ValueError(f"{field_name} cannot be blank or whitespace only")

        if not SecurityValidator.ALPHANUMERIC_PATTERN.match(value):
            raise ValueError(
                f"Invalid {field_name}: must contain only alphanumeric characters, "
                f"hyphens, and underscores. Got: '{value}'"
            )

        return value

    @staticmethod
    def sanitize_for_shell(value: str) -> str:
        """
        Escape string for safe shell usage by wrapping in single quotes
        and escaping any single quotes within the string.

        Equivalent to Java's SecureCommandExecutor.escapeForShell()

        This method uses single-quote escaping which is safe for bash.
        Single quotes preserve literal values, and we escape any embedded
        single quotes by ending the quoted section, adding an escaped quote,
        and starting a new quoted section.

        Args:
            value: String to escape

        Returns:
            Shell-escaped string wrapped in single quotes

        Examples:
            >>> SecurityValidator.sanitize_for_shell("simple")
            "'simple'"

            >>> SecurityValidator.sanitize_for_shell("it's working")
            "'it'\\''s working'"

            >>> SecurityValidator.sanitize_for_shell("")
            "''"
        """
        if not value:
            return "''"

        # Replace single quotes with '\'' (end quote, escaped quote, start quote)
        # This is the standard way to escape single quotes in bash
        escaped = value.replace("'", "'\\''")

        return f"'{escaped}'"

    @staticmethod
    def validate_operation(operation: str) -> str:
        """
        Validate that operation name is one of the supported types.

        Args:
            operation: Operation name to validate

        Returns:
            Validated operation name

        Raises:
            ValueError: If operation is not in the supported list
        """
        from app.models.enums import OperationType

        # Convert to OperationType enum to validate
        try:
            OperationType(operation)
            return operation
        except ValueError:
            valid_operations = [op.value for op in OperationType]
            raise ValueError(
                f"Invalid operation: '{operation}'. "
                f"Must be one of: {', '.join(valid_operations)}"
            )

    @staticmethod
    def validate_platform(platform: str) -> str:
        """
        Validate that platform is one of the supported types.

        Args:
            platform: Platform name to validate

        Returns:
            Validated platform name

        Raises:
            ValueError: If platform is not in the supported list
        """
        from app.models.enums import Platform

        try:
            Platform(platform)
            return platform
        except ValueError:
            valid_platforms = [p.value for p in Platform]
            raise ValueError(
                f"Invalid platform: '{platform}'. "
                f"Must be one of: {', '.join(valid_platforms)}"
            )

    @staticmethod
    def validate_file_path_within_directory(
        file_path: str,
        allowed_directory: str,
        path_type: str = "file"
    ) -> str:
        """
        Validate that file path is within the allowed directory.
        Prevents path traversal attacks (../ or absolute paths outside allowed directory).

        Args:
            file_path: Path to validate (can be relative or absolute)
            allowed_directory: Root directory that file must be within
            path_type: Type descriptor for error messages

        Returns:
            Absolute path to the file (resolved)

        Raises:
            ValueError: If path traverses outside allowed directory

        Examples:
            >>> SecurityValidator.validate_file_path_within_directory(
            ...     "src/main.py",
            ...     "/home/user/project"
            ... )
            '/home/user/project/src/main.py'

            >>> SecurityValidator.validate_file_path_within_directory(
            ...     "../../../etc/passwd",
            ...     "/home/user/project"
            ... )
            ValueError: Path traversal detected
        """
        # Resolve absolute paths
        try:
            abs_allowed_dir = Path(allowed_directory).resolve()

            # If file_path is absolute, use it directly
            # If relative, join with allowed_directory
            if Path(file_path).is_absolute():
                abs_file_path = Path(file_path).resolve()
            else:
                abs_file_path = (abs_allowed_dir / file_path).resolve()

            # Check if resolved path is within allowed directory
            # Use is_relative_to (Python 3.9+) or manual check
            try:
                abs_file_path.relative_to(abs_allowed_dir)
            except ValueError:
                raise ValueError(
                    f"Path traversal detected: {path_type} path '{file_path}' "
                    f"is outside allowed directory '{allowed_directory}'"
                )

            return str(abs_file_path)

        except Exception as e:
            if "Path traversal detected" in str(e):
                raise
            raise ValueError(
                f"Invalid {path_type} path: {str(e)}"
            )

    @staticmethod
    def _split_pipes_properly(command: str) -> list:
        """
        Split command by pipes, but ignore pipes inside quotes, parentheses, or brackets.
        
        This handles cases like:
          grep -E "(test|Test)" - the | inside () is NOT a pipe
          grep "pattern|other" - the | inside "" is NOT a pipe
          
        Args:
            command: Bash command string
            
        Returns:
            List of command parts split by actual pipe operators
        """
        parts = []
        current = []
        in_single_quote = False
        in_double_quote = False
        paren_depth = 0
        bracket_depth = 0
        i = 0
        
        while i < len(command):
            char = command[i]
            next_char = command[i + 1] if i + 1 < len(command) else ''
            
            # Handle quotes
            if char == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
                current.append(char)
            elif char == '"' and not in_single_quote:
                # Check if it's escaped
                if i > 0 and command[i - 1] == '\\':
                    current.append(char)
                else:
                    in_double_quote = not in_double_quote
                    current.append(char)
            # Handle parentheses and brackets
            elif not in_single_quote and not in_double_quote:
                if char == '(':
                    paren_depth += 1
                    current.append(char)
                elif char == ')':
                    paren_depth -= 1
                    current.append(char)
                elif char == '[':
                    bracket_depth += 1
                    current.append(char)
                elif char == ']':
                    bracket_depth -= 1
                    current.append(char)
                # Handle pipe operator
                elif char == '|':
                    # Check if it's || (logical OR)
                    if next_char == '|':
                        current.append('||')
                        i += 1  # Skip next |
                    # Check if we're inside parentheses/brackets
                    elif paren_depth == 0 and bracket_depth == 0:
                        # This is a real pipe operator!
                        parts.append(''.join(current))
                        current = []
                    else:
                        # Pipe inside parentheses/brackets - not a pipe operator
                        current.append(char)
                else:
                    current.append(char)
            else:
                current.append(char)
            
            i += 1
        
        # Add the last part
        if current:
            parts.append(''.join(current))
        
        return parts

    @staticmethod
    def is_safe_pipe_command(command: str) -> bool:
        """
        Check if a piped command uses only safe read-only operations.

        Allows pipes when all commands in the pipeline are read-only operations
        that cannot modify files or system state.

        Args:
            command: Bash command to check

        Returns:
            True if command is safe (no pipe or only read-only pipes), False otherwise

        Examples:
            >>> SecurityValidator.is_safe_pipe_command("ls -la")
            True

            >>> SecurityValidator.is_safe_pipe_command("cat file.txt | grep pattern")
            True

            >>> SecurityValidator.is_safe_pipe_command("cat file.txt | sh")
            False
        """
        # Read-only commands that are safe to use in pipes
        # These are commands that only read/display data without modifying files or system state
        READ_ONLY_COMMANDS = {
            # File listing and reading
            'ls', 'cat', 'grep', 'find', 'head', 'tail', 'wc',
            
            # Text processing
            'echo', 'sort', 'uniq', 'awk', 'sed', 'cut', 'tr',
            
            # Path utilities
            'basename', 'dirname', 'pwd', 'which',
            
            # Environment
            'printenv', 'export',
            
            # Version control (read-only operations)
            'git',  # When used with read-only commands like git log, git show, etc.
            
            # Java/Build tools (read-only when checking versions, listing, etc.)
            'java', 'javac', 'mvn', 'gradle',
            
            # Test utilities
            'test', '[',  # Conditional test commands
            
            # Additional safe utilities
            'diff', 'comm', 'cmp', 'file', 'stat', 'du', 'df',
            'whoami', 'date', 'env', 'id', 'uname',
            'xargs',  # Safe when used with read-only commands
        }

        # Check if command has real pipes (not just || operators)
        temp_cmd = command.replace('||', '')
        if '|' not in temp_cmd:
            return True

        # Split by single pipe only (not ||) and check each command
        # Use a proper parser that handles quotes, parentheses, and brackets
        parts = SecurityValidator._split_pipes_properly(command)
        for part in parts:
            part = part.strip()
            if not part:
                return False

            # Extract base command (first word)
            cmd_parts = part.split()
            if not cmd_parts:
                return False

            base_cmd = cmd_parts[0]

            # Remove path from command (e.g., /usr/bin/grep -> grep)
            if '/' in base_cmd:
                base_cmd = base_cmd.split('/')[-1]

            # Check if command is in read-only list
            if base_cmd not in READ_ONLY_COMMANDS:
                return False

        return True

    @staticmethod
    def is_safe_command_chain(command: str) -> bool:
        """
        Check if a command chain (using && or ||) uses only safe whitelisted commands.

        Allows command chaining when all commands in the chain are from the
        allowed commands whitelist.

        Args:
            command: Bash command to check

        Returns:
            True if command chain is safe, False otherwise

        Examples:
            >>> SecurityValidator.is_safe_command_chain("cd /path && ls")
            True

            >>> SecurityValidator.is_safe_command_chain("ls -la && cat file.txt")
            True

            >>> SecurityValidator.is_safe_command_chain("rm file && ls")
            False
        """
        # Commands that are whitelisted for chaining
        # Using the same list as ALLOWED_COMMANDS from validate_bash_command
        ALLOWED_COMMANDS = {
            # Java build tools
            'mvn', 'mvnw', 'gradle', 'gradlew',
            # .NET tools
            'dotnet',
            # Version control
            'git',
            # File operations (read-only)
            'ls', 'cat', 'grep', 'find', 'head', 'tail', 'wc',
            # Directory operations
            'mkdir',
            # Text processing
            'sort', 'uniq', 'cut', 'tr', 'awk', 'sed',
            # File comparison
            'diff', 'comm', 'cmp',
            # File information
            'file', 'stat', 'du', 'df',
            # SDKMAN for Java version management
            'sdk', 'source',
            # Shell utilities
            'echo', 'pwd', 'which', 'basename', 'dirname', 'cd',
            # Test/conditional commands
            'test', '[',
            # Command construction
            'xargs',
            # Java runtime
            'java', 'javac',
            # Environment and system info
            'export', 'printenv', 'env', 'date', 'whoami', 'uname', 'id',
        }

        # Check if command contains chaining operators
        if '&&' not in command and '||' not in command:
            return True

        # Split by both && and || operators
        # Replace || with && temporarily for consistent splitting
        normalized = command.replace('||', '&&')
        parts = normalized.split('&&')

        for part in parts:
            part = part.strip()
            if not part:
                return False

            # Extract base command (first word)
            cmd_parts = part.split()
            if not cmd_parts:
                return False

            base_cmd = cmd_parts[0]

            # Remove path from command (e.g., /usr/bin/ls -> ls)
            if '/' in base_cmd:
                base_cmd = base_cmd.split('/')[-1]

            # Check if command is in allowed list
            if base_cmd not in ALLOWED_COMMANDS:
                return False

        return True

    @staticmethod
    def validate_bash_command(
        command: str, 
        allow_safe_pipes: bool = True,
        allow_safe_command_chains: bool = True
    ) -> str:
        """
        Validate that bash command is safe and uses only whitelisted commands.

        CRITICAL SECURITY: Prevents arbitrary command execution by AI model.
        Only allows specific commands needed for build/test operations.

        Args:
            command: Bash command to validate

        Returns:
            Validated command

        Raises:
            ValueError: If command is not whitelisted or contains dangerous patterns

        Examples:
            >>> SecurityValidator.validate_bash_command("mvn clean install")
            'mvn clean install'

            >>> SecurityValidator.validate_bash_command("rm -rf /")
            ValueError: Command not allowed: rm
        """
        # Check if validation is disabled - allow all commands
        settings = get_settings()
        if not settings.security.bash_command_validation_enabled:
            return command
        
        # Whitelist of allowed commands for AI operations
        ALLOWED_COMMANDS = [
            # Java build tools
            'mvn', 'mvnw', 'gradle', 'gradlew',

            # .NET tools
            'dotnet',

            # Version control
            'git',

            # File operations (read-only)
            'ls', 'cat', 'grep', 'find', 'head', 'tail', 'wc',

            # Directory operations
            'mkdir',

            # Text processing
            'sort', 'uniq', 'cut', 'tr', 'awk', 'sed',

            # File comparison
            'diff', 'comm', 'cmp',

            # File information
            'file', 'stat', 'du', 'df',

            # SDKMAN for Java version management
            'sdk', 'source',

            # Shell utilities
            'echo', 'pwd', 'which', 'basename', 'dirname', 'cd',
            
            # Test/conditional commands
            'test', '[',

            # Command construction
            'xargs',

            # Java runtime
            'java', 'javac',

            # Environment and system info
            'export', 'printenv', 'env', 'date', 'whoami', 'uname', 'id',
        ]

        # Forbidden commands (even if we accidentally whitelist them)
        FORBIDDEN_COMMANDS = [
            'rm', 'rmdir', 'del', 'deltree',  # Deletion
            'dd', 'shred',  # Disk operations
            'mkfs', 'fdisk', 'parted',  # Partition tools
            'shutdown', 'reboot', 'halt', 'poweroff',  # System control
            'kill', 'killall', 'pkill',  # Process killing
            'chmod', 'chown', 'chgrp',  # Permission changes
            'sudo', 'su',  # Privilege escalation
            'curl', 'wget', 'nc', 'netcat',  # Network (data exfiltration risk)
            'python', 'python3', 'perl', 'ruby', 'node',  # Script interpreters
            'bash', 'sh', 'zsh', 'fish',  # Shell execution
        ]

        if not command or not command.strip():
            raise ValueError("Bash command cannot be empty")

        # Extract base command (first word)
        command_parts = command.strip().split()
        if not command_parts:
            raise ValueError("Invalid bash command format")

        base_command = command_parts[0]

        # Remove path from command (e.g., /usr/bin/mvn -> mvn)
        if '/' in base_command:
            base_command = base_command.split('/')[-1]

        # Check forbidden list first
        if base_command in FORBIDDEN_COMMANDS:
            raise ValueError(
                f"Command forbidden for security reasons: {base_command}"
            )

        # Check whitelist
        if base_command not in ALLOWED_COMMANDS:
            raise ValueError(
                f"Command not allowed: {base_command}. "
                f"Allowed commands: {', '.join(sorted(ALLOWED_COMMANDS))}"
            )

        # Check for dangerous patterns (command substitution, etc.)
        dangerous_patterns = [
            '$(', '`',  # Command substitution
            ';',  # Command separator
            '\n', '\r',  # Newlines
        ]

        for pattern in dangerous_patterns:
            if pattern in command:
                raise ValueError(
                    f"Command contains dangerous pattern: '{pattern}'. "
                    f"Only single commands are allowed."
                )
        
        # Check command chaining separately - allow if safe, reject if unsafe
        if '&&' in command or '||' in command:
            if not allow_safe_command_chains:
                raise ValueError(
                    "Command contains dangerous pattern: '&&' or '||'. "
                    "Only single commands are allowed."
                )
            elif not SecurityValidator.is_safe_command_chain(command):
                raise ValueError(
                    "Command contains unsafe command chain. "
                    "Only whitelisted commands can be chained with && or ||."
                )

        # Check pipes separately - allow if safe, reject if unsafe
        # IMPORTANT: Check for single pipe '|' not part of '||' operator
        # ALSO: Skip pipe validation if command has && or || - those are validated by chain validator
        has_real_pipe = False
        if '|' in command and '&&' not in command and '||' not in command:
            # Remove all || operators to check if real pipes remain (double check)
            temp_cmd = command.replace('||', '')
            if '|' in temp_cmd:
                has_real_pipe = True
        
        if has_real_pipe:
            if not allow_safe_pipes:
                raise ValueError(
                    "Command contains dangerous pattern: '|'. "
                    "Only single commands are allowed."
                )
            elif not SecurityValidator.is_safe_pipe_command(command):
                # Extract which command in the pipe failed
                parts = command.split('|')
                failing_commands = []
                for part in parts:
                    part_stripped = part.strip()
                    if part_stripped:
                        cmd_parts = part_stripped.split()
                        if cmd_parts:
                            base_cmd = cmd_parts[0]
                            if '/' in base_cmd:
                                base_cmd = base_cmd.split('/')[-1]
                            failing_commands.append(base_cmd)
                
                raise ValueError(
                    f"Command contains pipe with non-read-only operations. "
                    f"Only read-only piped commands are allowed. "
                    f"Commands in pipe: {failing_commands}. "
                    f"Full command: {command[:200]}"
                )

        return command

    @staticmethod
    def sanitize_log_message(message: str, sensitive_patterns: Optional[List[str]] = None) -> str:
        """
        Sanitize log message by redacting sensitive information.

        Prevents leaking credentials, API keys, tokens in logs.

        Args:
            message: Log message to sanitize
            sensitive_patterns: Additional regex patterns to redact (optional)

        Returns:
            Sanitized message with sensitive data redacted

        Examples:
            >>> SecurityValidator.sanitize_log_message(
            ...     "API key: sk-1234567890abcdef"
            ... )
            'API key: ***REDACTED***'
        """
        if not message:
            return message

        # Default sensitive patterns
        default_patterns = [
            # API keys
            (r'(api[_-]?key|apikey)["\s:=]+([a-zA-Z0-9\-_]{20,})', r'\1: ***REDACTED***'),

            # Tokens
            (r'(token|bearer)["\s:=]+([a-zA-Z0-9\-_.]{20,})', r'\1: ***REDACTED***'),

            # AWS credentials
            (r'(aws[_-]?secret|access[_-]?key)["\s:=]+([A-Za-z0-9/+=]{20,})', r'\1: ***REDACTED***'),

            # Passwords
            (r'(password|passwd|pwd)["\s:=]+([^\s"\']{3,})', r'\1: ***REDACTED***'),

            # Encryption keys (base64)
            (r'(encryption[_-]?key|secret[_-]?key)["\s:=]+([A-Za-z0-9+/=]{16,})', r'\1: ***REDACTED***'),

            # Credit card numbers (basic pattern)
            (r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b', '****-****-****-****'),

            # Email addresses (partial redaction)
            (r'([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', r'***@\2'),
        ]

        sanitized = message

        # Apply default patterns
        for pattern, replacement in default_patterns:
            sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE)

        # Apply custom patterns if provided
        if sensitive_patterns:
            for pattern in sensitive_patterns:
                sanitized = re.sub(pattern, '***REDACTED***', sanitized)

        return sanitized
