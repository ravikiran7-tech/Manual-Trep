"""
Resilience patterns: retry, circuit breaker, and rate limiting.
This is a major enhancement over the Java implementation which has none of these.
"""
import asyncio
import time
from functools import wraps
from typing import Callable, Any, Optional, Type

from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryError
)
from pybreaker import CircuitBreaker, CircuitBreakerError as PyBreakerCircuitBreakerError
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import get_settings
from app.core.exceptions import (
    CircuitBreakerError,
    OperationTimeoutError,
    ProviderError,
    RateLimitError
)


# Get settings
settings = get_settings()


# ============================================================================
# RETRY CONFIGURATION
# ============================================================================

def create_retry_decorator(
    max_attempts: Optional[int] = None,
    wait_min: Optional[int] = None,
    wait_max: Optional[int] = None,
    multiplier: Optional[int] = None,
    retry_exceptions: tuple = (Exception,)
):
    """
    Create a retry decorator with exponential backoff.

    Args:
        max_attempts: Maximum retry attempts (default from config)
        wait_min: Minimum wait time in seconds (default from config)
        wait_max: Maximum wait time in seconds (default from config)
        multiplier: Exponential backoff multiplier (default from config)
        retry_exceptions: Tuple of exceptions to retry on

    Returns:
        Tenacity retry decorator

    Example:
        @create_retry_decorator(max_attempts=3)
        async def call_api():
            ...
    """
    config = settings.resilience

    return retry(
        stop=stop_after_attempt(max_attempts or config.retry_max_attempts),
        wait=wait_exponential(
            multiplier=multiplier or config.retry_multiplier,
            min=wait_min or config.retry_wait_min,
            max=wait_max or config.retry_wait_max
        ),
        retry=retry_if_exception_type(retry_exceptions),
        reraise=True
    )


# Default retry decorator for provider errors
retry_on_provider_error = create_retry_decorator(
    max_attempts=3,
    retry_exceptions=(ProviderError, RateLimitError, ConnectionError, TimeoutError)
)


# ============================================================================
# CIRCUIT BREAKER CONFIGURATION
# ============================================================================

class AsyncCircuitBreaker(CircuitBreaker):
    """
    Async-compatible circuit breaker.
    Extends pybreaker's CircuitBreaker to support async functions.
    """

    async def call_async(self, func: Callable, *args, **kwargs) -> Any:
        """
        Call an async function with circuit breaker protection.

        Args:
            func: Async function to call
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Function result

        Raises:
            CircuitBreakerError: If circuit is open
        """
        # Check if circuit is open using current_state property
        if self.current_state == 'open':
            raise CircuitBreakerError(
                f"Circuit breaker is open. "
                f"Too many failures ({self.fail_counter}/{self.fail_max}). "
                f"Try again later."
            )

        try:
            result = await func(*args, **kwargs)
            # PyBreaker doesn't have call_succeeded/call_failed for async
            # The state is managed by the CircuitBreaker.call() method
            return result
        except Exception as e:
            # Let the exception propagate - pybreaker tracks failures automatically
            raise


# Create global circuit breakers
# PyBreaker CircuitBreaker parameters:
# - fail_max: number of failures before opening circuit
# - reset_timeout: seconds before attempting to close the circuit
# - name: circuit breaker name for identification
bedrock_circuit_breaker = AsyncCircuitBreaker(
    fail_max=settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=settings.resilience.circuit_breaker_timeout,
    name="bedrock_circuit_breaker"
)

portkey_circuit_breaker = AsyncCircuitBreaker(
    fail_max=settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=settings.resilience.circuit_breaker_timeout,
    name="portkey_circuit_breaker"
)

compass_circuit_breaker = AsyncCircuitBreaker(
    fail_max=settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=settings.resilience.circuit_breaker_timeout,
    name="compass_circuit_breaker"
)


def with_circuit_breaker(breaker: Optional[AsyncCircuitBreaker] = None):
    """
    Decorator to apply circuit breaker pattern.

    Args:
        breaker: Circuit breaker instance (default: bedrock_circuit_breaker)

    Returns:
        Decorator function

    Example:
        @with_circuit_breaker(bedrock_circuit_breaker)
        async def call_bedrock():
            ...
    """
    circuit_breaker = breaker or bedrock_circuit_breaker

    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await circuit_breaker.call_async(func, *args, **kwargs)
            except PyBreakerCircuitBreakerError as e:
                raise CircuitBreakerError(
                    f"Circuit breaker '{circuit_breaker.name}' is open: {str(e)}"
                )

        return wrapper

    return decorator


# ============================================================================
# RATE LIMITING
# ============================================================================

# Create rate limiter for API endpoints
# This will be used in FastAPI route decorators
rate_limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[
        f"{settings.resilience.rate_limit_per_minute}/minute",
        f"{settings.resilience.rate_limit_per_hour}/hour"
    ]
)


# ============================================================================
# TIMEOUT HANDLING
# ============================================================================

def with_timeout(timeout_seconds: Optional[int] = None):
    """
    Decorator to apply timeout to async functions.

    Args:
        timeout_seconds: Timeout in seconds (default from config)

    Returns:
        Decorator function

    Example:
        @with_timeout(3600)
        async def long_running_operation():
            ...
    """
    effective_timeout = timeout_seconds or settings.timeouts.default

    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=effective_timeout
                )
            except asyncio.TimeoutError:
                raise OperationTimeoutError(
                    f"Operation '{func.__name__}' timed out",
                    timeout_seconds=effective_timeout
                )

        return wrapper

    return decorator


# ============================================================================
# COMBINED RESILIENCE DECORATOR
# ============================================================================

def with_resilience(
    retry_attempts: Optional[int] = None,
    retry_exceptions: tuple = (Exception,),
    use_circuit_breaker: bool = True,
    circuit_breaker: Optional[AsyncCircuitBreaker] = None,
    timeout_seconds: Optional[int] = None,
    operation_name: str = None
):
    """
    Combined decorator applying retry, circuit breaker, and timeout.

    This is the primary decorator to use for resilient operations.
    It applies patterns in this order:
    1. Timeout (outermost)
    2. Circuit breaker
    3. Retry (innermost)

    Args:
        retry_attempts: Maximum retry attempts (default from config)
        retry_exceptions: Tuple of exceptions to retry on
        use_circuit_breaker: Whether to use circuit breaker
        circuit_breaker: Circuit breaker instance (default: bedrock_circuit_breaker)
        timeout_seconds: Timeout in seconds (default from config)
        operation_name: Operation name for logging

    Returns:
        Decorator function

    Example:
        @with_resilience(
            retry_attempts=3,
            timeout_seconds=3600,
            operation_name="bedrock_invocation"
        )
        async def execute_operation():
            ...

    Usage Notes:
        - For Bedrock operations: use default circuit breaker
        - For Portkey operations: pass portkey_circuit_breaker
        - For Compass operations: pass compass_circuit_breaker
        - For operations without external dependencies: use_circuit_breaker=False
    """
    effective_timeout = timeout_seconds or settings.timeouts.default
    effective_circuit_breaker = circuit_breaker or bedrock_circuit_breaker
    effective_retry_attempts = retry_attempts or settings.resilience.retry_max_attempts

    def decorator(func: Callable):
        # Build the resilience stack from inside out

        # 1. Innermost: Retry logic
        @create_retry_decorator(
            max_attempts=effective_retry_attempts,
            retry_exceptions=retry_exceptions
        )
        async def with_retry(*args, **kwargs):
            return await func(*args, **kwargs)

        # 2. Middle: Circuit breaker (optional)
        if use_circuit_breaker:
            @with_circuit_breaker(effective_circuit_breaker)
            async def with_breaker(*args, **kwargs):
                return await with_retry(*args, **kwargs)

            middle_func = with_breaker
        else:
            middle_func = with_retry

        # 3. Outermost: Timeout
        @with_timeout(effective_timeout)
        async def resilient_func(*args, **kwargs):
            return await middle_func(*args, **kwargs)

        # Preserve function metadata
        resilient_func.__name__ = func.__name__
        resilient_func.__doc__ = func.__doc__

        # Add resilience metadata for introspection
        resilient_func._resilience_config = {
            "retry_attempts": effective_retry_attempts,
            "timeout_seconds": effective_timeout,
            "circuit_breaker": effective_circuit_breaker.name if use_circuit_breaker else None,
            "operation_name": operation_name or func.__name__
        }

        return resilient_func

    return decorator


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_circuit_breaker_status(breaker: AsyncCircuitBreaker) -> dict:
    """
    Get circuit breaker status information.

    Args:
        breaker: Circuit breaker instance

    Returns:
        Dictionary with status information
    """
    return {
        "name": breaker.name,
        "state": breaker.current_state,
        "fail_counter": breaker.fail_counter,
        "fail_max": breaker.fail_max
    }


def reset_circuit_breaker(breaker: AsyncCircuitBreaker) -> None:
    """
    Manually reset a circuit breaker.

    Args:
        breaker: Circuit breaker instance to reset
    """
    breaker._state = breaker.STATE_CLOSED
    breaker.fail_counter = 0


def reset_all_circuit_breakers() -> None:
    """
    Reset all global circuit breakers.
    Useful for testing or manual recovery.
    """
    reset_circuit_breaker(bedrock_circuit_breaker)
    reset_circuit_breaker(portkey_circuit_breaker)
    reset_circuit_breaker(compass_circuit_breaker)


# ============================================================================
# HEALTH CHECK
# ============================================================================

def get_resilience_health() -> dict:
    """
    Get health status of all resilience components.

    Returns:
        Dictionary with health information
    """
    return {
        "circuit_breakers": {
            "bedrock": get_circuit_breaker_status(bedrock_circuit_breaker),
            "portkey": get_circuit_breaker_status(portkey_circuit_breaker),
            "compass": get_circuit_breaker_status(compass_circuit_breaker)
        },
        "rate_limiting": {
            "enabled": True,
            "per_minute": settings.resilience.rate_limit_per_minute,
            "per_hour": settings.resilience.rate_limit_per_hour
        },
        "retry_config": {
            "max_attempts": settings.resilience.retry_max_attempts,
            "wait_min": settings.resilience.retry_wait_min,
            "wait_max": settings.resilience.retry_wait_max,
            "multiplier": settings.resilience.retry_multiplier
        }
    }
