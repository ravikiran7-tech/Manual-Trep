"""
Custom exception classes for the studio-ai-engine application.
Provides structured error handling across the application.
"""


class StudioAIEngineException(Exception):
    """
    Base exception class for all studio-ai-engine exceptions.
    All custom exceptions should inherit from this class.
    """

    def __init__(self, message: str, details: str = None):
        """
        Initialize exception with message and optional details.

        Args:
            message: Main error message
            details: Additional error details
        """
        self.message = message
        self.details = details
        super().__init__(self.message)

    def __str__(self):
        if self.details:
            return f"{self.message} Details: {self.details}"
        return self.message


class ValidationError(StudioAIEngineException):
    """
    Exception raised for validation errors.
    Used for input validation failures (paths, IDs, parameters, etc.)
    """
    
    def __init__(self, message: str, field: str = None, details: str = None):
        """
        Initialize validation error with field name.
        
        Args:
            message: Main error message
            field: Field name that failed validation
            details: Additional error details
        """
        self.field = field
        super().__init__(message, details)
    
    def __str__(self):
        field_info = f" (Field: {self.field})" if self.field else ""
        if self.details:
            return f"{self.message}{field_info} Details: {self.details}"
        return f"{self.message}{field_info}"


class AuthenticationError(StudioAIEngineException):
    """
    Exception raised for authentication failures.
    Used when API authentication fails (Bedrock, Portkey, Compass).
    """
    pass


class ConfigurationError(StudioAIEngineException):
    """
    Exception raised for configuration errors.
    Used when required configuration is missing or invalid.
    """
    pass


class ProviderError(StudioAIEngineException):
    """
    Exception raised for AI provider errors.
    Used when Bedrock or Portkey API calls fail.
    """

    def __init__(self, message: str, provider: str = None, details: str = None):
        """
        Initialize provider error with provider name.

        Args:
            message: Main error message
            provider: Provider name (bedrock, portkey)
            details: Additional error details
        """
        self.provider = provider
        super().__init__(message, details)

    def __str__(self):
        provider_info = f" (Provider: {self.provider})" if self.provider else ""
        if self.details:
            return f"{self.message}{provider_info} Details: {self.details}"
        return f"{self.message}{provider_info}"


class CompassClientError(StudioAIEngineException):
    """
    Exception raised for Compass API errors.
    Used when Studio Core/Compass API calls fail.
    """
    pass


class OperationTimeoutError(StudioAIEngineException):
    """
    Exception raised when an operation times out.
    Used for long-running operations that exceed configured timeouts.
    """

    def __init__(self, message: str, timeout_seconds: int = None, details: str = None):
        """
        Initialize timeout error with timeout duration.

        Args:
            message: Main error message
            timeout_seconds: Timeout duration that was exceeded
            details: Additional error details
        """
        self.timeout_seconds = timeout_seconds
        super().__init__(message, details)

    def __str__(self):
        timeout_info = f" (Timeout: {self.timeout_seconds}s)" if self.timeout_seconds else ""
        if self.details:
            return f"{self.message}{timeout_info} Details: {self.details}"
        return f"{self.message}{timeout_info}"


class CircuitBreakerError(StudioAIEngineException):
    """
    Exception raised when circuit breaker is open.
    Used when too many failures have occurred and the circuit is opened.
    """
    pass


class RateLimitError(StudioAIEngineException):
    """
    Exception raised when rate limit is exceeded.
    Used when API rate limits are hit.
    """

    def __init__(self, message: str, retry_after: int = None, details: str = None):
        """
        Initialize rate limit error with retry information.

        Args:
            message: Main error message
            retry_after: Seconds to wait before retrying
            details: Additional error details
        """
        self.retry_after = retry_after
        super().__init__(message, details)

    def __str__(self):
        retry_info = f" (Retry after: {self.retry_after}s)" if self.retry_after else ""
        if self.details:
            return f"{self.message}{retry_info} Details: {self.details}"
        return f"{self.message}{retry_info}"


class FileOperationError(StudioAIEngineException):
    """
    Exception raised for file operation failures.
    Used when file read/write operations fail.
    """

    def __init__(self, message: str, file_path: str = None, details: str = None):
        """
        Initialize file operation error with file path.

        Args:
            message: Main error message
            file_path: Path to the file that caused the error
            details: Additional error details
        """
        self.file_path = file_path
        super().__init__(message, details)

    def __str__(self):
        file_info = f" (File: {self.file_path})" if self.file_path else ""
        if self.details:
            return f"{self.message}{file_info} Details: {self.details}"
        return f"{self.message}{file_info}"


class StreamParsingError(StudioAIEngineException):
    """
    Exception raised for stream parsing failures.
    Used when parsing Bedrock stream events fails.
    """
    pass


class ToolExecutionError(StudioAIEngineException):
    """
    Exception raised for tool execution failures.
    Used when code_editor or bash tool execution fails.
    """

    def __init__(self, message: str, tool_name: str = None, details: str = None):
        """
        Initialize tool execution error with tool name.

        Args:
            message: Main error message
            tool_name: Name of the tool that failed (code_editor, bash)
            details: Additional error details
        """
        self.tool_name = tool_name
        super().__init__(message, details)

    def __str__(self):
        tool_info = f" (Tool: {self.tool_name})" if self.tool_name else ""
        if self.details:
            return f"{self.message}{tool_info} Details: {self.details}"
        return f"{self.message}{tool_info}"


class BuildCompilationError(StudioAIEngineException):
    """
    Exception raised for build compilation failures.
    Used when Java/DotNet build operations fail.
    """

    def __init__(self, message: str, exit_code: int = None, details: str = None):
        """
        Initialize build compilation error with exit code.

        Args:
            message: Main error message
            exit_code: Build process exit code
            details: Additional error details (build logs)
        """
        self.exit_code = exit_code
        super().__init__(message, details)

    def __str__(self):
        exit_info = f" (Exit code: {self.exit_code})" if self.exit_code is not None else ""
        if self.details:
            return f"{self.message}{exit_info} Details: {self.details}"
        return f"{self.message}{exit_info}"
