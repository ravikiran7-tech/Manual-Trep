"""
LLM Rate Limiter - Proactive rate limiting for outbound LLM API calls.

Controls three independent mechanisms applied in sequence before every LLM call:

  1. Semaphore      — caps maximum concurrent in-flight LLM calls globally.
  2. RPM bucket     — token bucket that enforces requests-per-minute quota.
  3. TPM bucket     — token bucket that enforces tokens-per-minute quota.
  4. Adaptive delay — inter-call delay that backs off on throttle signals and
                      speeds up on sustained success streaks.

All mechanisms use asyncio primitives (Semaphore, sleep) — they suspend only
the waiting coroutine; the event loop continues processing other work.
No LLM call ever fails due to this rate limiter: it queues and waits.

This complements the existing reactive resilience patterns:
  - tenacity retry (catches RateLimitError after the fact)
  - pybreaker circuit breaker (trips on hard failure streaks)

These remain as the outer safety net. The rate limiter prevents most 429s
from ever occurring.

Integration pattern (both clients):
    async with portkey_llm_rate_limiter.acquire(estimated_tokens=8000):
        response = await client.post(url, ...)  # LLM call only

    async with bedrock_llm_rate_limiter.acquire(estimated_tokens=8000):
        response = bedrock_runtime.converse(**request_body)

The semaphore is released as soon as the LLM response arrives, long before
tool execution begins — so tool calls (file read/write/bash) are never gated.
"""
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import Optional

logger = logging.getLogger(__name__)


# ============================================================================
# TOKEN BUCKET
# ============================================================================

class TokenBucket:
    """
    Async token bucket for rate limiting.

    Tokens refill continuously at a fixed rate up to capacity.
    Callers await acquire(n) — if insufficient tokens exist, the coroutine
    sleeps exactly the time needed for the bucket to refill, then proceeds.

    All state mutations are within an asyncio.Lock so concurrent awaiters
    do not race on the token count.
    """

    def __init__(self, capacity: float, refill_rate: float):
        """
        Args:
            capacity:     Maximum token capacity (bucket starts full).
            refill_rate:  Tokens added per second.
        """
        self._capacity = capacity
        self._tokens = capacity
        self._refill_rate = refill_rate
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        """Add tokens proportional to elapsed time since last refill."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self._capacity, self._tokens + elapsed * self._refill_rate)
        self._last_refill = now

    async def acquire(self, tokens: float = 1.0) -> None:
        """
        Acquire tokens, waiting until they are available.

        Caps the request at bucket capacity so very large token counts
        (late-iteration agentic calls with massive context) do not wait
        forever — they consume the full bucket and proceed.

        Args:
            tokens: Number of tokens to consume.
        """
        tokens = min(tokens, self._capacity)
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return
                wait_time = (tokens - self._tokens) / self._refill_rate

            logger.debug(
                f"Token bucket depleted — waiting {wait_time:.2f}s "
                f"(need {tokens:.0f} tokens, refill_rate={self._refill_rate:.1f}/s)"
            )
            await asyncio.sleep(wait_time)


# ============================================================================
# LLM RATE LIMITER
# ============================================================================

class LLMRateLimiter:
    """
    Proactive rate limiter for LLM API calls.

    Applied once per LLM HTTP/boto3 call (not per tool execution).

    Usage:
        async with rate_limiter.acquire(estimated_tokens=10000):
            response = await llm_client.call(...)
        # RateLimitError from within the context updates adaptive delay state.
        # Any other exception leaves adaptive delay unchanged.
    """

    def __init__(
        self,
        provider: str,
        max_concurrent: int,
        requests_per_minute: int,
        tokens_per_minute: int,
        initial_delay: float,
        min_delay: float,
        max_delay: float,
        success_threshold: int,
        decrease_factor: float,
        increase_factor: float,
        throttle_recovery: float,
        default_estimated_tokens: int,
        enabled: bool = True,
        enable_adaptive_delays: bool = True,
        enable_token_tracking: bool = True,
    ):
        """
        Args:
            provider:                  Provider name for logging ("portkey"/"bedrock").
            max_concurrent:            Max simultaneous in-flight LLM calls.
            requests_per_minute:       RPM cap (0 = disabled).
            tokens_per_minute:         TPM cap (0 = disabled).
            initial_delay:             Starting inter-call sleep (seconds).
            min_delay:                 Floor for adaptive delay.
            max_delay:                 Ceiling for adaptive delay.
            success_threshold:         Consecutive successes before reducing delay.
            decrease_factor:           Multiply delay by this on success streak (< 1.0).
            increase_factor:           Multiply delay by this on throttle (> 1.0).
            throttle_recovery:         Extra sleep (seconds) added to adaptive delay
                                       after a throttle event, applied at the START
                                       of the next acquire() — not blocking others.
            default_estimated_tokens:  Token estimate for calls that don't know count.
            enabled:                   Master toggle.
            enable_adaptive_delays:    Toggle adaptive delay sub-system.
            enable_token_tracking:     Toggle TPM bucket.
        """
        self.provider = provider
        self.enabled = enabled
        self.enable_adaptive_delays = enable_adaptive_delays

        # --- Concurrency semaphore ---
        self._semaphore = asyncio.Semaphore(max_concurrent if max_concurrent > 0 else 1000)

        # --- RPM token bucket ---
        if requests_per_minute > 0:
            self._rpm_bucket: Optional[TokenBucket] = TokenBucket(
                capacity=float(requests_per_minute),
                refill_rate=requests_per_minute / 60.0,
            )
        else:
            self._rpm_bucket = None

        # --- TPM token bucket ---
        if tokens_per_minute > 0 and enable_token_tracking:
            self._tpm_bucket: Optional[TokenBucket] = TokenBucket(
                capacity=float(tokens_per_minute),
                refill_rate=tokens_per_minute / 60.0,
            )
        else:
            self._tpm_bucket = None

        # --- Adaptive delay state ---
        self._current_delay = initial_delay
        self._min_delay = min_delay
        self._max_delay = max_delay
        self._success_threshold = success_threshold
        self._decrease_factor = decrease_factor
        self._increase_factor = increase_factor
        self._throttle_recovery = throttle_recovery
        self._consecutive_successes = 0
        # Monotonic timestamp until which recovery sleep must be applied
        self._recovery_until = 0.0

        # --- Defaults ---
        self._default_estimated_tokens = default_estimated_tokens

        # --- Metrics ---
        self._total_calls = 0
        self._throttle_count = 0
        self._total_wait_ms = 0

        logger.info(
            f"LLMRateLimiter [{provider}] initialised — "
            f"max_concurrent={max_concurrent}, "
            f"rpm={'unlimited' if requests_per_minute == 0 else requests_per_minute}, "
            f"tpm={'unlimited' if tokens_per_minute == 0 else tokens_per_minute}, "
            f"initial_delay={initial_delay}s, "
            f"enabled={enabled}"
        )

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    @asynccontextmanager
    async def acquire(self, estimated_tokens: Optional[int] = None):
        """
        Async context manager that gates one LLM call.

        Sequence of waits before the call fires:
          1. Semaphore   — suspends if max_concurrent slots are occupied.
          2. Recovery    — sleeps any remaining throttle-recovery time.
          3. RPM bucket  — sleeps until a request token is available.
          4. TPM bucket  — sleeps until enough token-budget is available.
          5. Adaptive    — sleeps the current inter-call delay.

        On context exit:
          - RateLimitError raised inside → _record_throttle() (increases delay,
            schedules recovery sleep for the NEXT call).
          - Clean exit (no exception)   → _record_success()  (may reduce delay).
          - Any other exception         → adaptive delay is left unchanged.

        The semaphore is ALWAYS released on exit regardless of outcome.

        Args:
            estimated_tokens: Approximate total tokens for this call.
                               Defaults to default_estimated_tokens from config.
                               Capped at TPM bucket capacity so late-iteration
                               agentic calls with huge context still proceed.
        """
        if not self.enabled:
            yield
            return

        tokens = estimated_tokens or self._default_estimated_tokens
        start_time = time.monotonic()

        # Step 1: Acquire concurrency slot
        await self._semaphore.acquire()

        try:
            # Step 2: Throttle-recovery delay (runs once, then clears)
            now = time.monotonic()
            if self._recovery_until > now:
                recovery_wait = self._recovery_until - now
                logger.info(
                    f"[{self.provider}] Throttle recovery wait: {recovery_wait:.1f}s "
                    f"(scheduled after previous 429)"
                )
                await asyncio.sleep(recovery_wait)
                self._recovery_until = 0.0

            # Step 3: RPM token bucket
            if self._rpm_bucket is not None:
                await self._rpm_bucket.acquire(1.0)

            # Step 4: TPM token bucket
            if self._tpm_bucket is not None:
                await self._tpm_bucket.acquire(float(tokens))

            # Step 5: Adaptive inter-call delay
            if self.enable_adaptive_delays and self._current_delay > 0:
                await asyncio.sleep(self._current_delay)

            wait_ms = int((time.monotonic() - start_time) * 1000)
            self._total_calls += 1
            self._total_wait_ms += wait_ms

            if wait_ms > 100:
                logger.info(
                    f"[{self.provider}] Pre-call wait: {wait_ms}ms "
                    f"(estimated_tokens={tokens}, total_calls={self._total_calls})"
                )

            # --- Yield to caller (LLM call happens here) ---
            try:
                yield
            except Exception as exc:
                from app.core.exceptions import RateLimitError
                if isinstance(exc, RateLimitError):
                    self._record_throttle()
                # Other exceptions leave adaptive delay unchanged
                raise
            else:
                self._record_success()

        finally:
            # Always release the semaphore
            self._semaphore.release()

    def get_metrics(self) -> dict:
        """Return current rate limiter metrics for health checks and logging."""
        avg_wait = self._total_wait_ms / max(1, self._total_calls)
        return {
            "provider": self.provider,
            "enabled": self.enabled,
            "total_calls": self._total_calls,
            "throttle_count": self._throttle_count,
            "total_wait_ms": self._total_wait_ms,
            "avg_wait_ms": round(avg_wait, 1),
            "current_delay_s": round(self._current_delay, 3),
            "consecutive_successes": self._consecutive_successes,
            "recovery_pending_s": max(0.0, round(self._recovery_until - time.monotonic(), 1)),
        }

    # -------------------------------------------------------------------------
    # Internal helpers (sync — no await, safe to call from async context)
    # -------------------------------------------------------------------------

    def _record_success(self) -> None:
        """Reduce adaptive delay after sustained success streak."""
        if not self.enable_adaptive_delays:
            return
        self._consecutive_successes += 1
        if self._consecutive_successes >= self._success_threshold:
            old = self._current_delay
            self._current_delay = max(self._min_delay, old * self._decrease_factor)
            self._consecutive_successes = 0
            if self._current_delay < old:
                logger.debug(
                    f"[{self.provider}] Adaptive delay reduced: "
                    f"{old:.3f}s → {self._current_delay:.3f}s "
                    f"(after {self._success_threshold} consecutive successes)"
                )

    def _record_throttle(self) -> None:
        """
        Increase adaptive delay and schedule recovery on next acquire().

        Recovery sleep is not applied immediately — it is deferred to the
        START of the NEXT acquire() call. This way the current coroutine
        exits quickly (so tenacity retry can schedule the next attempt),
        but all subsequent acquire() calls across ALL coroutines will wait
        for the recovery period before firing another LLM request.
        """
        self._throttle_count += 1
        if not self.enable_adaptive_delays:
            return
        old = self._current_delay
        self._current_delay = min(self._max_delay, old * self._increase_factor)
        self._consecutive_successes = 0
        # Schedule recovery: next acquire() will sleep until this timestamp
        self._recovery_until = time.monotonic() + self._throttle_recovery
        logger.warning(
            f"[{self.provider}] Throttled (#{self._throttle_count})! "
            f"Adaptive delay: {old:.3f}s → {self._current_delay:.3f}s. "
            f"Recovery sleep {self._throttle_recovery}s deferred to next acquire()."
        )


# ============================================================================
# FACTORY & MODULE-LEVEL SINGLETONS
# ============================================================================

def _create_rate_limiter(provider: str) -> LLMRateLimiter:
    """
    Create a provider-specific LLMRateLimiter from settings.

    Provider-specific overrides (BEDROCK_RATE_LIMITER_* / PORTKEY_RATE_LIMITER_*)
    take precedence over global LLM_RATE_LIMITER_* values when non-zero.
    """
    from app.core.config import get_settings
    settings = get_settings()
    cfg = settings.llm_rate_limiter

    if provider == "bedrock":
        override = cfg.bedrock
    elif provider == "portkey":
        override = cfg.portkey
    else:
        override = None

    def resolve(override_val: int, global_val: int) -> int:
        """Use override if set (> 0), otherwise fall back to global."""
        return override_val if (override_val and override_val > 0) else global_val

    rpm = resolve(getattr(override, "requests_per_minute", 0), cfg.requests_per_minute)
    tpm = resolve(getattr(override, "tokens_per_minute", 0), cfg.tokens_per_minute)
    concurrent = resolve(getattr(override, "max_concurrent", 0), cfg.max_concurrent)

    return LLMRateLimiter(
        provider=provider,
        max_concurrent=concurrent,
        requests_per_minute=rpm,
        tokens_per_minute=tpm,
        initial_delay=cfg.initial_delay,
        min_delay=cfg.min_delay,
        max_delay=cfg.max_delay,
        success_threshold=cfg.success_threshold,
        decrease_factor=cfg.decrease_factor,
        increase_factor=cfg.increase_factor,
        throttle_recovery=cfg.throttle_recovery,
        default_estimated_tokens=cfg.default_estimated_tokens,
        enabled=cfg.enabled,
        enable_adaptive_delays=cfg.enable_adaptive_delays,
        enable_token_tracking=cfg.enable_token_tracking,
    )


# Module-level singletons — same pattern as bedrock_circuit_breaker /
# portkey_circuit_breaker in resilience.py.
bedrock_llm_rate_limiter: LLMRateLimiter = _create_rate_limiter("bedrock")
portkey_llm_rate_limiter: LLMRateLimiter = _create_rate_limiter("portkey")


def get_llm_rate_limiter_health() -> dict:
    """
    Return health/metrics for both rate limiter instances.
    Consumed by the /health endpoint alongside circuit breaker status.
    """
    return {
        "bedrock": bedrock_llm_rate_limiter.get_metrics(),
        "portkey": portkey_llm_rate_limiter.get_metrics(),
    }
