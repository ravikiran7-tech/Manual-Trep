"""Shared tool schemas. Provider-neutral — each adapter wraps these in its SDK's
expected tool format (Bedrock toolSpec, Anthropic input_schema, Azure AI
Inference function tool, etc.).
"""
from app.services.llm.protocol import ToolSpec


CODE_EDITOR_TOOL = ToolSpec(
    name="code_editor",
    description=(
        "Edit, create, or delete files in the codebase. Use patch operation for "
        "efficient small changes, write for complete file replacement. "
        "IMPORTANT: For 'write' operation, 'content' is required. For 'patch' "
        "operation, 'patch_format' and 'patch_data' are required."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the file relative to project directory",
            },
            "operation": {
                "type": "string",
                "enum": ["read", "write", "delete", "patch"],
                "description": (
                    "Operation to perform: read (read file), write (replace entire "
                    "file), delete (delete file), patch (apply diff-based changes)"
                ),
            },
            "content": {
                "type": "string",
                "description": (
                    "Complete file content for write operations (REQUIRED when "
                    "operation is 'write', omit for other operations)"
                ),
            },
            "patch_format": {
                "type": "string",
                "enum": ["unified_diff", "line_edits", "structured"],
                "description": (
                    "Patch format for patch operation (REQUIRED when operation is "
                    "'patch'): unified_diff (standard diff format), line_edits "
                    "(line-based edits), structured (JSON range-based edits)"
                ),
            },
            "patch_data": {
                "type": ["string", "object", "array"],
                "description": (
                    "Patch data (format depends on patch_format). For unified_diff: "
                    "string with diff text; each hunk starts with '@@' and its body "
                    "uses ' ' for context, '-' for removed and '+' for added lines. "
                    "Copy context and '-' lines exactly as they appear in the file - "
                    "hunks are located by matching that content. For line_edits: "
                    "array of edit objects using 1-BASED line numbers; include "
                    "'old_text' so the edit is verified against the file. "
                    "For structured: object with edits array."
                ),
            },
        },
        "required": ["path", "operation"],
    },
)


BASH_TOOL = ToolSpec(
    name="bash",
    description=(
        "Execute bash commands in the project context. Use this for running "
        "builds, tests, and other command-line operations."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Bash command to execute",
            },
            "working_directory": {
                "type": "string",
                "description": "Working directory for command execution (optional)",
            },
        },
        "required": ["command"],
    },
)


DEFAULT_TOOLS: list[ToolSpec] = [CODE_EDITOR_TOOL, BASH_TOOL]
