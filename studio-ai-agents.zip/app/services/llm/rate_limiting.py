"""Per-provider rate limiter and circuit breaker registry.

Reuses existing singletons for Bedrock and Portkey (no edits to core/). Adds
new ones for Azure and the OpenAI-compatible adapter (Concierto private LLM),
constructed locally. The OpenAI-compatible limiter is intentionally disabled —
see the comment on it.
"""
from __future__ import annotations

from app.core.config import get_settings
from app.core.llm_rate_limiter import (
    LLMRateLimiter,
    _create_rate_limiter,
    bedrock_llm_rate_limiter,
    portkey_llm_rate_limiter,
)
from app.core.resilience import (
    AsyncCircuitBreaker,
    bedrock_circuit_breaker,
    portkey_circuit_breaker,
)

_settings = get_settings()


# _create_rate_limiter("azure") falls through to global defaults because the
# legacy if/elif in llm_rate_limiter.py has no "azure" branch. That is the
# desired behavior and deliberately avoids touching the legacy file.
azure_llm_rate_limiter: LLMRateLimiter = _create_rate_limiter("azure")

azure_circuit_breaker = AsyncCircuitBreaker(
    fail_max=_settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=_settings.resilience.circuit_breaker_timeout,
    name="azure_circuit_breaker",
)

# "openai-compatible" is the adapter name used by the Concierto private LLM.
# It is self-hosted, so there is no upstream quota to protect and no throttling
# is wanted. LLMOrchestrator types rate_limiter as required and calls
# rate_limiter.acquire() unconditionally, so this cannot be None — instead it
# gets a limiter that is switched off: enabled=False makes acquire() yield
# immediately, with no semaphore, no RPM/TPM buckets and no adaptive delay.
openai_compatible_llm_rate_limiter: LLMRateLimiter = LLMRateLimiter(
    provider="openai-compatible",
    max_concurrent=0,          # 0 = unbounded
    requests_per_minute=0,     # 0 = no RPM bucket
    tokens_per_minute=0,       # 0 = no TPM bucket
    initial_delay=0.0,
    min_delay=0.0,
    max_delay=0.0,
    success_threshold=1,
    decrease_factor=1.0,
    increase_factor=1.0,
    throttle_recovery=0.0,
    default_estimated_tokens=0,
    enabled=False,
    enable_adaptive_delays=False,
    enable_token_tracking=False,
)

# The circuit breaker is deliberately kept. It is not rate limiting: without it
# a dead or unreachable CEI endpoint is retried indefinitely instead of failing
# fast.
openai_compatible_circuit_breaker = AsyncCircuitBreaker(
    fail_max=_settings.resilience.circuit_breaker_fail_threshold,
    reset_timeout=_settings.resilience.circuit_breaker_timeout,
    name="openai_compatible_circuit_breaker",
)


_RATE_LIMITERS: dict[str, LLMRateLimiter] = {
    "aws-bedrock": bedrock_llm_rate_limiter,
    "portkey": portkey_llm_rate_limiter,
    "azure": azure_llm_rate_limiter,
    "openai-compatible": openai_compatible_llm_rate_limiter,
}

_CIRCUIT_BREAKERS: dict[str, AsyncCircuitBreaker] = {
    "aws-bedrock": bedrock_circuit_breaker,
    "portkey": portkey_circuit_breaker,
    "azure": azure_circuit_breaker,
    "openai-compatible": openai_compatible_circuit_breaker,
}


def get_rate_limiter(provider_name: str) -> LLMRateLimiter:
    try:
        return _RATE_LIMITERS[provider_name]
    except KeyError:
        raise KeyError(
            f"No rate limiter registered for provider '{provider_name}'. "
            f"Known: {sorted(_RATE_LIMITERS.keys())}"
        )


def get_circuit_breaker(provider_name: str) -> AsyncCircuitBreaker:
    try:
        return _CIRCUIT_BREAKERS[provider_name]
    except KeyError:
        raise KeyError(
            f"No circuit breaker registered for provider '{provider_name}'. "
            f"Known: {sorted(_CIRCUIT_BREAKERS.keys())}"
        )
