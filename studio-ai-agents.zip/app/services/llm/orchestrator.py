"""LLMOrchestrator — the one canonical tool loop.

Provider-agnostic. The orchestrator owns:
- Multi-turn tool-use loop (Fix #2: smart termination, 5 follow-ups max)
- File-write retry with exponential backoff (Fix #7)
- File-write verification (Fix #3)
- Consecutive-failure tracking (Fix #7)
- Enhanced tool error messages (Fix #7)
- Event normalization to Claude CLI stream-json format
- Security validation of tool inputs (delegates to SecurityValidator)
- Rate limiter + circuit breaker gating

Adapters only translate neutral types <-> their SDK wire format. They do not
participate in any of the above.

Public method signatures match legacy BedrockClient / PortkeyClient so the 18
operation handlers continue to work unchanged when the factory swaps the
returned object.
"""
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any, Awaitable, Callable

from app.core.config import get_settings
from app.core.exceptions import ProviderError, RateLimitError
from app.core.llm_rate_limiter import LLMRateLimiter
from app.core.security import SecurityValidator
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    LLMProvider,
    ToolResult,
    ToolSpec,
    ToolUse,
)
from app.services.llm.tools import DEFAULT_TOOLS

logger = logging.getLogger(__name__)
_settings = get_settings()


_MAX_FOLLOW_UP_TURNS = 5
_MAX_CONSECUTIVE_TOOL_FAILURES_DEFAULT = 3
_FILE_WRITE_MAX_RETRIES = 3
_FILE_WRITE_INITIAL_DELAY_SECONDS = 0.5


# Verbatim port of legacy BedrockClient._get_completion_instructions /
# PortkeyClient._get_completion_instructions. Downstream Java services rely
# on the model emitting a ```json``` block in its final text — without this
# system prompt the orchestrator path produced narratives only, breaking
# extract_and_write_json_result and every *-result.json reader.
_COMPLETION_INSTRUCTIONS = """
═══════════════════════════════════════════════════════════════════════════════
🚨 MANDATORY FINAL OUTPUT FORMAT - NON-NEGOTIABLE 🚨
═══════════════════════════════════════════════════════════════════════════════

ABSOLUTE REQUIREMENT:
When you complete ALL your operations, you MUST output a JSON response in your final
text message. This is NOT optional. This is NOT a suggestion. This MUST be done.

FORMAT SPECIFICATION (FOLLOW EXACTLY):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Step 1: Complete all required operations (read files, write files, run commands, etc.)

Step 2: Write your final summary/explanation text

Step 3: Output the JSON response wrapped in triple backticks with 'json' language tag:

```json
{
  ... your JSON output here following the EXACT schema from the prompt ...
}
```

CRITICAL CONSTRAINTS:
✓ Output JSON in your TEXT RESPONSE (conversational message)
✓ Use EXACTLY this format: ```json ... ``` (triple backticks with 'json' tag)
✓ Follow the EXACT JSON schema/structure specified in the original prompt
✓ Use the EXACT field names, types, and structure from the prompt template
✓ JSON must be valid, parseable, and match the prompt's schema
✗ DO NOT use code_editor tool to write JSON to files
✗ DO NOT omit the triple backticks
✗ DO NOT omit the 'json' language tag after opening backticks
✗ DO NOT modify or change the required JSON schema from the prompt
✗ DO NOT add extra fields not specified in the prompt schema
✗ DO NOT skip required fields from the prompt schema

SCHEMA SOURCE - READ CAREFULLY:
The JSON schema/template was provided in your original prompt above.
Review the prompt to find the exact JSON structure you must output.
Match field names, data types, and structure EXACTLY as specified.

WHY THIS MATTERS:
• The entire system pipeline depends on extracting this JSON from your text response
• JSON parser expects the EXACT schema defined in the prompt
• Without properly formatted JSON output matching the schema, the operation FAILS completely
• This is the ONLY way results are captured, parsed, and returned to the user
• Wrong schema = Parser fails = No results = System failure

VERIFICATION CHECKLIST (before sending end_turn):
□ Have I completed all required operations?
□ Have I reviewed the JSON schema in the original prompt?
□ Have I included JSON in my final text response?
□ Is the JSON wrapped in ```json ... ``` triple backticks with 'json' tag?
□ Does my JSON match the EXACT schema/structure from the prompt?
□ Have I included ALL required fields from the prompt schema?
□ Are ALL field names and types correct per the prompt?

═══════════════════════════════════════════════════════════════════════════════
"""


def _get_completion_instructions() -> str:
    """Return the JSON-output system prompt appended on every iteration.

    Ported verbatim from legacy BedrockClient/PortkeyClient. Module-level so
    it stays a single source of truth.
    """
    return _COMPLETION_INSTRUCTIONS


def _compose_system_prompt(user_system_prompt: str | None) -> str:
    """Compose the system prompt sent to the provider.

    Always include the completion instructions; prepend the caller's system
    prompt if one was supplied. Matches legacy behaviour exactly:
        request_body["system"] = f"{system_prompt}\\n\\n{completion_instructions}"
    """
    instructions = _get_completion_instructions()
    if user_system_prompt:
        return f"{user_system_prompt}\n\n{instructions}"
    return instructions


class LLMOrchestrator:
    """Wraps an LLMProvider adapter with the shared tool-loop / normalization.

    Public method signatures mirror legacy BedrockClient exactly so handlers
    are unaware of the switch.
    """

    def __init__(
        self,
        provider: LLMProvider,
        rate_limiter: LLMRateLimiter,
        circuit_breaker: Any | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> None:
        self.provider = provider
        self.rate_limiter = rate_limiter
        self.circuit_breaker = circuit_breaker
        self.max_tokens = max_tokens if max_tokens is not None else _settings.bedrock.max_tokens
        self.temperature = temperature if temperature is not None else _settings.bedrock.temperature

    # ---------------------------------------------------------------- interface

    @property
    def model_id(self) -> str:
        return self.provider.model_id

    @property
    def provider_name(self) -> str:
        return self.provider.name

    # --------------------------------------------------------------- invoke_simple

    async def invoke_simple(
        self,
        prompt: str,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> dict[str, Any]:
        """One-shot call, no tools, returns the raw provider response dict."""
        mt = max_tokens or self.max_tokens
        tp = temperature if temperature is not None else self.temperature
        messages = [ChatMessage(role="user", content=[prompt])]

        response = await self._chat(
            messages=messages,
            system=None,
            tools=None,
            max_tokens=mt,
            temperature=tp,
        )
        return response.raw

    # ---------------------------------------------------------- invoke_with_tools

    async def invoke_with_tools(
        self,
        prompt: str,
        project_path: str,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        enable_tools: bool = True,
        process_response: bool = True,
        prepend_project_context: bool = True,
    ) -> list[dict[str, Any]]:
        """Multi-turn tool-use invocation. Returns normalized event list."""
        return await self._invoke_tool_loop(
            prompt=prompt,
            project_path=project_path,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            enable_tools=enable_tools,
            process_response=process_response,
            on_event=None,
            max_turns=_MAX_FOLLOW_UP_TURNS,
            prepend_project_context=prepend_project_context,
        )

    # -------------------------------------------------------- agentic variants

    async def invoke_with_tools_agentic(
        self,
        prompt: str,
        project_path: str,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        enable_tools: bool = True,
        process_response: bool = True,
        on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None = None,
        prepend_project_context: bool = True,
    ) -> list[dict[str, Any]]:
        """Unlimited-turn variant with event callbacks.

        Honors `agentic.unlimited_iterations` (default True) the same way the
        legacy BedrockClient/PortkeyClient agentic loops do: when set, the
        loop runs until the model emits stop_reason=end_turn (or hits a tool
        failure / max_tokens safety net). Otherwise caps at
        `agentic.max_iterations`.
        """
        agentic = getattr(_settings, "agentic", None)
        max_iterations = int(getattr(agentic, "max_iterations", 10) or 10)
        unlimited = bool(getattr(agentic, "unlimited_iterations", False)) or max_iterations == 0
        max_turns = (1 << 31) if unlimited else max_iterations
        return await self._invoke_tool_loop(
            prompt=prompt,
            project_path=project_path,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            enable_tools=enable_tools,
            process_response=process_response,
            on_event=on_event,
            max_turns=max_turns,
            prepend_project_context=prepend_project_context,
        )

    async def invoke_with_tools_agentic_graph(
        self,
        prompt: str,
        project_path: str,
        provider_factory: Any | None = None,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        enable_tools: bool = True,
        process_response: bool = True,
        on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None = None,
        prepend_project_context: bool = True,
    ) -> list[dict[str, Any]]:
        """Graph-based orchestration: splits project into modules, transforms each.

        Uses the existing GraphOrchestrator which handles dependency ordering,
        per-module retries, and compiler validation. The GraphOrchestrator calls
        back into provider.invoke_with_tools_agentic() for each module — so it
        works with any provider (Bedrock, Portkey, Azure) transparently.

        Falls back to flat agentic mode if no provider_factory is supplied.
        """
        if provider_factory is None:
            return await self.invoke_with_tools_agentic(
                prompt=prompt,
                project_path=project_path,
                system_prompt=system_prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                enable_tools=enable_tools,
                process_response=process_response,
                on_event=on_event,
                prepend_project_context=prepend_project_context,
            )

        from app.orchestrator.graph_orchestrator import GraphOrchestrator

        logger.info("Starting graph-based agentic execution (%s)", self.provider_name)

        orchestrator = GraphOrchestrator(
            project_path=project_path,
            provider_factory=provider_factory,
            max_retries=getattr(
                getattr(_settings, "agentic", None), "max_module_retries", 3
            ),
            validation_timeout=getattr(
                getattr(_settings, "agentic", None), "validation_timeout", 300
            ),
            skip_validation=getattr(
                getattr(_settings, "agentic", None), "skip_validation", False
            ),
        )

        try:
            state = await orchestrator.orchestrate(prompt, on_event=on_event)
        except Exception as e:
            logger.error("Graph orchestration failed: %s", e, exc_info=True)
            raise

        return _graph_state_to_events(state, on_event)

    # --------------------------------------------------------------- health_check

    async def health_check(self) -> dict[str, Any]:
        return await self.provider.health_check()

    # ================================================================ internals

    async def _invoke_tool_loop(
        self,
        *,
        prompt: str,
        project_path: str,
        system_prompt: str | None,
        max_tokens: int | None,
        temperature: float | None,
        enable_tools: bool,
        process_response: bool,
        on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
        max_turns: int,
        prepend_project_context: bool = True,
    ) -> list[dict[str, Any]]:
        mt = max_tokens or self.max_tokens
        tp = temperature if temperature is not None else self.temperature
        tools = DEFAULT_TOOLS if enable_tools else None

        # Always inject the JSON-output system prompt; downstream Java services
        # parse a ```json``` block out of the final assistant text. Mirrors the
        # legacy BedrockClient/PortkeyClient behaviour of sending it on every
        # iteration.
        effective_system = _compose_system_prompt(system_prompt)

        user_text = (
            f"Project directory: {project_path}\n\n{prompt}"
            if prepend_project_context
            else prompt
        )
        conversation: list[ChatMessage] = [
            ChatMessage(role="user", content=[user_text])
        ]

        events: list[dict[str, Any]] = []
        usage_totals: dict[str, int] = {}
        turns = 0

        response = await self._chat(
            messages=conversation,
            system=effective_system,
            tools=tools,
            max_tokens=mt,
            temperature=tp,
        )
        turns += 1
        _accumulate_usage(usage_totals, response.usage)

        if process_response:
            new_events = self._normalize(response, project_path)
            events.extend(new_events)
            await _emit(on_event, new_events)
        else:
            events.append(response.raw)

        if not enable_tools:
            await self._emit_usage_summary(
                usage_totals, turns, events, on_event
            )
            return events

        follow_up_count = 0

        # Canonical agent loop: the provider's stop_reason is the single source
        # of truth for whether to continue. Mirrors legacy invoke_with_tools_agentic
        # in bedrock_client.py / portkey_client.py.
        while follow_up_count < max_turns:
            if response.stop_reason == "end_turn":
                logger.info(
                    "Model completed (stop_reason=end_turn) after %d follow-up turns",
                    follow_up_count,
                )
                break
            if response.stop_reason == "max_tokens":
                logger.warning(
                    "Model hit max_tokens after %d follow-up turns",
                    follow_up_count,
                )
                break
            if response.stop_reason != "tool_use":
                logger.info(
                    "Stopping on stop_reason=%s after %d follow-up turns",
                    response.stop_reason,
                    follow_up_count,
                )
                break
            if not response.tool_uses:
                break

            # Preserve assistant turn in wire order. Sonnet 5.5 thinking
            # blocks must be sent back unchanged or the next tool turn 400s.
            if response.ordered_content:
                assistant_content = list(response.ordered_content)
            else:
                assistant_content = []
                for text in response.text_blocks:
                    assistant_content.append(text)
                for tu in response.tool_uses:
                    assistant_content.append(tu)
            if assistant_content:
                conversation.append(ChatMessage(role="assistant", content=assistant_content))

            # Execute each tool, build ToolResult blocks, and capture events.
            tool_results, stopped = await self._execute_tools(
                response.tool_uses,
                project_path=project_path,
                events=events,
                on_event=on_event,
            )
            if stopped:
                break

            # Feed results back as a user turn.
            conversation.append(
                ChatMessage(
                    role="user",
                    content=list(tool_results),  # list[ToolResult] is compatible with ContentBlock
                )
            )

            response = await self._chat(
                messages=conversation,
                system=effective_system,
                tools=tools,
                max_tokens=mt,
                temperature=tp,
            )
            turns += 1
            _accumulate_usage(usage_totals, response.usage)
            new_events = self._normalize(response, project_path)
            events.extend(new_events)
            await _emit(on_event, new_events)

            follow_up_count += 1

        # Match legacy: emit max_iterations_reached when the loop hits its cap.
        if follow_up_count >= max_turns and response.stop_reason not in (
            "end_turn",
            "max_tokens",
        ):
            max_ev = {
                "type": "system",
                "subtype": "max_iterations_reached",
                "message": (
                    f"Agentic loop reached maximum iterations ({max_turns}). "
                    "Task may be incomplete."
                ),
                "timestamp": int(time.time() * 1000),
            }
            events.append(max_ev)
            await _emit(on_event, [max_ev])
            logger.warning(
                "Agentic loop reached max_turns (%d); task may be incomplete.",
                max_turns,
            )

        await self._emit_usage_summary(usage_totals, turns, events, on_event)
        return events

    async def _emit_usage_summary(
        self,
        usage_totals: dict[str, int],
        turns: int,
        events: list[dict[str, Any]],
        on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
    ) -> None:
        """Append and stream a single `system/usage_summary` event with cumulative
        token counts and cache hit rate for the whole agent loop.
        """
        if turns == 0:
            return
        summary = _build_usage_summary_event(
            usage_totals,
            turns,
            self.provider.name,
            int(time.time() * 1000),
        )
        events.append(summary)
        await _emit(on_event, [summary])
        total_in = summary["total_input_tokens"]
        cache_read = summary["cache_read_input_tokens"]
        hit_pct = summary["cache_hit_rate"] * 100.0
        logger.info(
            "[%s] usage summary: turns=%d, total_in=%d, cache_read=%d (%.1f%% hit), "
            "cache_write=%d, out=%d",
            summary["provider"],
            summary["turns"],
            total_in,
            cache_read,
            hit_pct,
            summary["cache_write_input_tokens"],
            summary["output_tokens"],
        )

    async def _chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse:
        try:
            async with self.rate_limiter.acquire(estimated_tokens=max_tokens):
                response = await self.provider.chat(
                    messages=messages,
                    system=system,
                    tools=tools,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
        except RateLimitError:
            raise
        except Exception as e:
            # Leave adapter-raised exceptions (ProviderError, AuthenticationError) alone.
            if isinstance(e, ProviderError):
                raise
            raise ProviderError(
                message=f"Unexpected LLM error: {e}",
                provider=self.provider.name,
                details=str(e),
            )

        _log_per_turn_usage(self.provider.name, self.provider.model_id, response.usage)
        return response

    # -------------------------------------------------- tool execution (fix #7)

    async def _execute_tools(
        self,
        tool_uses: list[ToolUse],
        *,
        project_path: str,
        events: list[dict[str, Any]],
        on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
    ) -> tuple[list[ToolResult], bool]:
        """Execute each tool call; return (ToolResult list, stopped_flag)."""
        from app.services.tool_executor import ToolExecutor, format_tool_result_for_model

        settings = get_settings()
        executor = ToolExecutor(
            project_path=project_path,
            working_directory=project_path,
            timeout=settings.agentic.tool_execution_timeout,
        )

        max_consecutive_failures = getattr(
            getattr(settings, "agentic", None),
            "max_consecutive_errors",
            _MAX_CONSECUTIVE_TOOL_FAILURES_DEFAULT,
        ) or _MAX_CONSECUTIVE_TOOL_FAILURES_DEFAULT

        results: list[ToolResult] = []
        consecutive_failures = 0
        timestamp = int(time.time() * 1000)

        for tu in tool_uses:
            logger.info("Executing tool: %s (ID: %s)", tu.name, tu.tool_use_id)

            # Authoritative security gate. Refuses to execute tool calls that
            # `SecurityValidator` rejects. Mirrors the cosmetic check inside
            # `_normalize` but is the only call that actually prevents
            # execution. The model receives the rejection as an error
            # tool_result and can self-correct on the next turn.
            rejection_reason = _security_rejection_reason(tu.name, tu.input, project_path)
            if rejection_reason is not None:
                logger.error(
                    "SECURITY: Refusing to execute %s: %s",
                    tu.name,
                    rejection_reason,
                )
                rejected_content = (
                    f"Security validation rejected this tool call: {rejection_reason}. "
                    "The tool was NOT executed. Adjust the input to comply with "
                    "the project's security policy and try again."
                )
                results.append(
                    ToolResult(
                        tool_use_id=tu.tool_use_id,
                        content=rejected_content,
                        is_error=True,
                    )
                )
                rejected_event = {
                    "type": "tool_result",
                    "tool": {
                        "toolUseId": tu.tool_use_id,
                        "name": tu.name,
                        "result": {"content": rejected_content, "is_error": True},
                    },
                    "success": False,
                    "timestamp": timestamp,
                }
                events.append(rejected_event)
                await _emit(on_event, [rejected_event])

                # Count toward the consecutive-failure cap so a model that
                # keeps trying unsafe inputs is stopped automatically.
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    stop_event = {
                        "type": "error",
                        "error": (
                            f"Max consecutive failures reached ({consecutive_failures}). "
                            f"Last failure: {tu.name} - security validation rejected"
                        ),
                        "timestamp": timestamp,
                    }
                    events.append(stop_event)
                    await _emit(on_event, [stop_event])
                    return results, True
                continue

            if tu.name == "code_editor" and tu.input.get("operation") == "write":
                result = _execute_with_write_retry(
                    executor, tu.name, tu.input, tu.tool_use_id, project_path
                )
            else:
                result = executor.execute_tool(tu.name, tu.input, tu.tool_use_id)

            # Fix #7: consecutive failure guard.
            if not result.success:
                consecutive_failures += 1
                logger.warning(
                    "Tool execution failed (%d/%d): %s — %s",
                    consecutive_failures,
                    max_consecutive_failures,
                    tu.name,
                    result.error,
                )
                if consecutive_failures >= max_consecutive_failures:
                    stop_event = {
                        "type": "error",
                        "error": (
                            f"Max consecutive failures reached ({consecutive_failures}). "
                            f"Last failure: {tu.name} - {result.error}"
                        ),
                        "timestamp": timestamp,
                    }
                    events.append(stop_event)
                    await _emit(on_event, [stop_event])
                    return results, True
                result.error = _enhance_tool_error(tu, result.error)
            else:
                consecutive_failures = 0

            formatted = format_tool_result_for_model(tu.tool_use_id, result)
            results.append(
                ToolResult(
                    tool_use_id=tu.tool_use_id,
                    content=formatted.get("content", ""),
                    is_error=not result.success,
                )
            )

            tool_result_event = {
                "type": "tool_result",
                "tool": {
                    "toolUseId": tu.tool_use_id,
                    "name": tu.name,
                    "result": formatted,
                },
                "success": result.success,
                "timestamp": timestamp,
            }
            events.append(tool_result_event)
            await _emit(on_event, [tool_result_event])

            logger.info(
                "Tool %s executed: success=%s, time=%sms",
                tu.name,
                result.success,
                getattr(result, "execution_time_ms", "?"),
            )

        return results, False

    # ---------------------------------------------- event normalization

    def _normalize(self, response: ChatResponse, project_path: str) -> list[dict[str, Any]]:
        """Convert a ChatResponse into Claude CLI stream-json event list.

        Mirrors legacy BedrockClient._process_response / PortkeyClient equivalent.
        """
        timestamp = int(time.time() * 1000)
        events: list[dict[str, Any]] = [
            {"type": "system", "subtype": "init", "timestamp": timestamp}
        ]

        for text in response.text_blocks:
            events.append({"type": "assistant", "subtype": "content_start", "timestamp": timestamp})
            events.append(
                {"type": "assistant", "subtype": "text_delta", "text": text, "timestamp": timestamp}
            )
            events.append({"type": "assistant", "subtype": "content_stop", "timestamp": timestamp})

        for tu in response.tool_uses:
            events.append({"type": "assistant", "subtype": "content_start", "timestamp": timestamp})
            if not _tool_input_is_safe(tu.name, tu.input, project_path, events, timestamp):
                events.append(
                    {"type": "assistant", "subtype": "content_stop", "timestamp": timestamp}
                )
                continue
            events.append(
                {
                    "type": "tool_use",
                    "tool": {
                        "toolUseId": tu.tool_use_id,
                        "name": tu.name,
                        "input": tu.input,
                    },
                    "timestamp": timestamp,
                }
            )
            events.append({"type": "assistant", "subtype": "content_stop", "timestamp": timestamp})

        stop_reason = response.stop_reason
        events.append(
            {"type": "message_stop", "stop_reason": stop_reason, "timestamp": timestamp}
        )

        # Adapters now normalize usage to a canonical shape with input_tokens
        # (uncached/full-price), output_tokens, cache_read_input_tokens,
        # cache_write_input_tokens, total_input_tokens, provider.
        usage = response.usage or {}
        input_tokens = int(usage.get("input_tokens", 0) or 0)
        output_tokens = int(usage.get("output_tokens", 0) or 0)
        cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
        cache_write = int(usage.get("cache_write_input_tokens", 0) or 0)
        total_input = int(usage.get("total_input_tokens", 0) or 0) or (
            input_tokens + cache_read + cache_write
        )

        events.append(
            {
                "type": "result",
                "is_error": False,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cache_read_input_tokens": cache_read,
                "cache_write_input_tokens": cache_write,
                "total_input_tokens": total_input,
                "provider": usage.get("provider", self.provider_name),
                "stop_reason": stop_reason,
                "timestamp": timestamp,
            }
        )
        return events


# ---------------------------------------------------------------------- helpers


async def _emit(
    on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
    new_events: list[dict[str, Any]],
) -> None:
    if on_event is None:
        return
    for ev in new_events:
        res = on_event(ev)
        if hasattr(res, "__await__"):
            await res  # type: ignore[func-returns-value]


def _security_rejection_reason(
    tool_name: str,
    tool_input: dict[str, Any],
    project_path: str,
) -> str | None:
    """Return None if the tool input is safe, else a short rejection reason.

    Pure function: no side effects, no event mutation, no logging. Callers
    decide what to do with the reason. Used by both `_tool_input_is_safe`
    (cosmetic event-stream filter inside `_normalize`) and `_execute_tools`
    (the authoritative security gate that prevents execution).
    """
    settings = get_settings()

    if tool_name == "bash":
        command = tool_input.get("command", "")
        if not command:
            return None
        if not settings.security.bash_command_validation_enabled:
            return None
        try:
            SecurityValidator.validate_bash_command(
                command,
                allow_safe_pipes=settings.security.allow_safe_pipes,
                allow_safe_command_chains=settings.security.allow_safe_command_chains,
            )
            return None
        except ValueError as e:
            return str(e)

    if tool_name == "code_editor":
        file_path = tool_input.get("path", "")
        if not file_path:
            return None
        if not settings.security.path_traversal_protection_enabled:
            return None
        try:
            if ".." in file_path:
                raise ValueError(f"Path traversal detected (..): {file_path}")
            if file_path.startswith("/") and not SecurityValidator.is_safe_absolute_path(
                file_path,
                project_path,
                allowed_dirs=settings.security.get_allowed_directories_list(),
            ):
                raise ValueError(f"Absolute path outside allowed directories: {file_path}")
            return None
        except ValueError as e:
            return str(e)

    return None


def _tool_input_is_safe(
    tool_name: str,
    tool_input: dict[str, Any],
    project_path: str,
    events: list[dict[str, Any]],
    timestamp: int,
) -> bool:
    """Cosmetic security filter for the event stream inside `_normalize`.

    On rejection, appends an `error` event to the visible stream and returns
    False. This is NOT the authoritative security gate — `_execute_tools`
    runs `_security_rejection_reason` independently and refuses to execute
    rejected tool calls regardless of what `_normalize` did.
    """
    settings = get_settings()

    # Preserve the warn-when-validation-disabled log for parity with prior behavior.
    if tool_name == "bash" and tool_input.get("command") and not settings.security.bash_command_validation_enabled:
        logger.warning(
            "SECURITY: Bash validation disabled, allowing command: %s",
            tool_input["command"][:50],
        )
    if tool_name == "code_editor" and tool_input.get("path") and not settings.security.path_traversal_protection_enabled:
        logger.warning("SECURITY: Path validation disabled, allowing: %s", tool_input["path"])

    reason = _security_rejection_reason(tool_name, tool_input, project_path)
    if reason is None:
        return True

    if tool_name == "bash":
        logger.error("SECURITY: Rejected unsafe bash command: %s", reason)
    elif tool_name == "code_editor":
        logger.error("SECURITY: Rejected unsafe file path: %s", reason)
    events.append(
        {"type": "error", "error": f"Security validation failed: {reason}", "timestamp": timestamp}
    )
    return False


def _execute_with_write_retry(
    executor: Any,
    tool_name: str,
    tool_input: dict[str, Any],
    tool_use_id: str,
    project_path: str,
) -> Any:
    """Fix #7 + Fix #3: retry file writes with backoff and verify existence."""
    delay = _FILE_WRITE_INITIAL_DELAY_SECONDS
    result = None
    for attempt in range(_FILE_WRITE_MAX_RETRIES):
        result = executor.execute_tool(tool_name, tool_input, tool_use_id)

        if result.success:
            file_path = tool_input.get("path", "")
            if file_path:
                if not os.path.isabs(file_path):
                    file_path = os.path.join(project_path, file_path)
                file_path = str(Path(file_path).resolve())

                if os.path.exists(file_path):
                    stat = os.stat(file_path)
                    logger.info(
                        "File write verified: %s exists, size=%d bytes, mtime=%s",
                        file_path,
                        stat.st_size,
                        stat.st_mtime,
                    )
                    return result

                result.success = False
                result.error = f"File write verification failed: file {file_path} does not exist"
                logger.warning(
                    "File write verification failed (%d/%d): %s",
                    attempt + 1,
                    _FILE_WRITE_MAX_RETRIES,
                    file_path,
                )

        if attempt < _FILE_WRITE_MAX_RETRIES - 1:
            logger.info(
                "File write failed (%d/%d), retrying in %.1fs: %s",
                attempt + 1,
                _FILE_WRITE_MAX_RETRIES,
                delay,
                result.error,
            )
            time.sleep(delay)
            delay *= 2

    return result


def _enhance_tool_error(tu: ToolUse, base_error: str) -> str:
    enhanced = f"Tool execution failed: {tu.name}"
    if tu.name == "code_editor":
        operation = tu.input.get("operation", "")
        file_path = tu.input.get("path", "")
        enhanced += f"\nOperation: {operation}"
        if file_path:
            enhanced += f"\nFile path: {file_path}"
    elif tu.name == "bash":
        command = tu.input.get("command", "")
        if command:
            enhanced += f"\nCommand: {command[:100]}"
    enhanced += f"\nError details: {base_error}"
    enhanced += "\nSuggestion: Check file permissions, disk space, or command syntax"
    return enhanced


def _graph_state_to_events(
    state: Any,
    on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
) -> list[dict[str, Any]]:
    """Convert GraphState into the same event list format the legacy client produces.

    Also emits summary events (graph_start, module_completed, graph_complete) via
    on_event so they appear in the live stream file — matching legacy behavior.
    Module tool-execution events were already streamed during orchestrate().
    """
    timestamp = int(time.time() * 1000)
    events: list[dict[str, Any]] = []

    graph_start_ev = {
        "type": "system",
        "subtype": "graph_start",
        "message": f"Graph orchestration started: {state.total_modules} modules",
        "timestamp": timestamp,
    }
    events.append(graph_start_ev)
    _emit_sync(on_event, graph_start_ev)

    for module in state.graph.values():
        module_ev = {
            "type": "module_completed",
            "module": module.name,
            "path": module.path,
            "status": module.status.value,
            "retries": module.retries,
            "files_changed": module.files_changed,
            "error": module.last_error,
            "timestamp": timestamp,
        }
        events.append(module_ev)
        _emit_sync(on_event, module_ev)

        if module.events:
            for event in module.events:
                event_with_context = event.copy()
                event_with_context["module"] = module.name
                events.append(event_with_context)

    progress = state.get_progress()
    graph_complete_ev = {
        "type": "system",
        "subtype": "graph_complete",
        "message": (
            f"Graph orchestration complete: "
            f"{progress['locked']} succeeded, "
            f"{progress['failed']} failed, "
            f"{progress['skipped']} skipped, "
            f"{state.current_iteration} iterations"
        ),
        "progress": progress,
        "timestamp": timestamp,
    }
    events.append(graph_complete_ev)
    _emit_sync(on_event, graph_complete_ev)

    logger.info(
        "Graph execution complete: %d events, %d modules succeeded",
        len(events),
        progress["locked"],
    )

    return events


def _emit_sync(
    on_event: Callable[[dict[str, Any]], Awaitable[None] | None] | None,
    event: dict[str, Any],
) -> None:
    """Fire on_event synchronously (the base_handler callback writes to a file)."""
    if on_event is not None:
        on_event(event)


def _log_per_turn_usage(
    provider_name: str, model_id: str, usage: dict[str, Any] | None
) -> None:
    """Emit a single human-readable INFO line summarizing tokens used this turn.

    Adapters normalize the canonical fields. If usage is missing or all zeros
    we skip the log to avoid noise.
    """
    if not usage:
        return
    inp = int(usage.get("input_tokens", 0) or 0)
    out = int(usage.get("output_tokens", 0) or 0)
    cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
    cache_write = int(usage.get("cache_write_input_tokens", 0) or 0)
    if inp == 0 and out == 0 and cache_read == 0 and cache_write == 0:
        return
    total_input = inp + cache_read + cache_write
    hit_pct = (cache_read / total_input * 100.0) if total_input > 0 else 0.0
    logger.info(
        "[%s/%s] tokens: in=%d (uncached), cache_read=%d (%.0f%% hit), "
        "cache_write=%d, out=%d, total_in=%d",
        provider_name,
        model_id,
        inp,
        cache_read,
        hit_pct,
        cache_write,
        out,
        total_input,
    )


def _accumulate_usage(totals: dict[str, int], usage: dict[str, Any] | None) -> None:
    """Add one turn's usage into a running totals dict (mutated in place)."""
    if not usage:
        return
    for key in (
        "input_tokens",
        "output_tokens",
        "cache_read_input_tokens",
        "cache_write_input_tokens",
        "total_input_tokens",
    ):
        totals[key] = totals.get(key, 0) + int(usage.get(key, 0) or 0)


def _build_usage_summary_event(
    totals: dict[str, int],
    turns: int,
    provider_name: str,
    timestamp: int,
) -> dict[str, Any]:
    total_in = totals.get("total_input_tokens", 0) or (
        totals.get("input_tokens", 0)
        + totals.get("cache_read_input_tokens", 0)
        + totals.get("cache_write_input_tokens", 0)
    )
    cache_read = totals.get("cache_read_input_tokens", 0)
    hit_rate = round(cache_read / total_in, 4) if total_in > 0 else 0.0
    return {
        "type": "system",
        "subtype": "usage_summary",
        "turns": turns,
        "input_tokens": totals.get("input_tokens", 0),
        "output_tokens": totals.get("output_tokens", 0),
        "cache_read_input_tokens": cache_read,
        "cache_write_input_tokens": totals.get("cache_write_input_tokens", 0),
        "total_input_tokens": total_in,
        "cache_hit_rate": hit_rate,
        "provider": provider_name,
        "timestamp": timestamp,
    }
