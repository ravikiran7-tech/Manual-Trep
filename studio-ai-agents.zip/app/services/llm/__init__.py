"""LLM orchestrator stack.

Importing this module has a side effect: it pre-populates
app.services.provider_factory._default_factory with an
OrchestratorProviderFactory so every call to get_provider_factory() returns the
orchestrator/adapter stack.

This is the default execution path. LLM_USE_ORCHESTRATOR defaults to "true";
setting it to "false" is the rollback switch that leaves the dormant legacy
factory to be constructed lazily instead.
"""
import logging
import os

logger = logging.getLogger(__name__)


def _flag_is_enabled() -> bool:
    return os.getenv("LLM_USE_ORCHESTRATOR", "true").strip().lower() == "true"


def _install_orchestrator_factory() -> None:
    import app.services.provider_factory as _legacy
    from app.services.llm.factory import OrchestratorProviderFactory

    if _legacy._default_factory is not None:
        logger.warning(
            "Legacy ProviderFactory already constructed; orchestrator stack "
            "will not replace it. Import app.services.llm earlier in startup."
        )
        return

    _legacy._default_factory = OrchestratorProviderFactory()
    logger.info("LLM_USE_ORCHESTRATOR=true — orchestrator provider stack active")


if _flag_is_enabled():
    _install_orchestrator_factory()
