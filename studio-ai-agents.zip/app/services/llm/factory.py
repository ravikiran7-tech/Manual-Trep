"""OrchestratorProviderFactory — drop-in replacement for legacy ProviderFactory.

Matches the public surface of app.services.provider_factory.ProviderFactory so
callers of get_provider_factory() don't need to change. Returns an
LLMOrchestrator (which in turn holds a thin adapter) in place of the legacy
BedrockClient / PortkeyClient. Handler method calls on that orchestrator
match the legacy client surface.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from app.clients.compass_client import CompassClient
from app.core.config import get_settings
from app.core.exceptions import ConfigurationError, ProviderError
from app.services.llm.adapters.azure import AzureAdapter
from app.services.llm.adapters.bedrock import BedrockAdapter
from app.services.llm.adapters.openai_compatible import (
    OpenAICompatibleAdapter,
    generation_defaults as openai_compatible_generation_defaults,
)
from app.services.llm.adapters.portkey import PortkeyAdapter
from app.services.llm.orchestrator import LLMOrchestrator
from app.services.llm.rate_limiting import get_circuit_breaker, get_rate_limiter
from app.utils.encryption import EncryptionUtils, get_encryption_utils

logger = logging.getLogger(__name__)
_settings = get_settings()


_ADAPTER_REGISTRY = {
    "aws-bedrock": BedrockAdapter,
    "portkey": PortkeyAdapter,
    "azure": AzureAdapter,
    "azure-ai-foundry": AzureAdapter,
    "concierto-private-llm": OpenAICompatibleAdapter,
}


def _generation_settings(adapter_name: str) -> dict[str, Any]:
    """Per-adapter max_tokens / temperature for LLMOrchestrator.

    LLMOrchestrator defaults both to _settings.bedrock.max_tokens /
    .temperature, so any non-Bedrock provider that does not pass its own
    silently inherits Bedrock's generation settings. Bedrock and the Azure /
    Portkey adapters are left on that existing fallback; the OpenAI-compatible
    adapter (Concierto private LLM) supplies its own OPENAI_COMPAT_* values.
    """
    if adapter_name == OpenAICompatibleAdapter.name:
        return openai_compatible_generation_defaults()
    return {}


def supported_adapter_types() -> list[str]:
    """Compass providerType values this stack can build an adapter for."""
    return sorted(_ADAPTER_REGISTRY.keys())


def build_orchestrator(
    connection: Any,
    encryption_utils: Optional[EncryptionUtils] = None,
) -> LLMOrchestrator:
    """Build an LLMOrchestrator for a Compass connection.

    Shared by OrchestratorProviderFactory and the legacy ProviderFactory.
    The legacy factory only has Bedrock and Portkey clients; Azure and
    concierto-private-llm exist only here, so it delegates those types.
    """
    provider_key = (getattr(connection, "provider_type", None) or "").lower()
    adapter_cls = _ADAPTER_REGISTRY.get(provider_key)
    if adapter_cls is None:
        raise ConfigurationError(
            message=f"Unsupported provider type: {getattr(connection, 'provider_type', None)}",
            details=f"Supported: {supported_adapter_types()}",
        )

    encryption_utils = encryption_utils or get_encryption_utils()
    try:
        adapter = adapter_cls.from_connection(
            connection,
            encryption_utils=encryption_utils,
        )
    except ConfigurationError:
        raise
    except Exception as e:
        raise ProviderError(
            message=f"Failed to create {provider_key} adapter: {e}",
            provider=provider_key,
            details=str(e),
        )

    logger.info(
        "Created %s adapter (model=%s) wrapped in LLMOrchestrator",
        adapter.name,
        adapter.model_id,
    )
    return LLMOrchestrator(
        provider=adapter,
        rate_limiter=get_rate_limiter(adapter.name),
        circuit_breaker=get_circuit_breaker(adapter.name),
        **_generation_settings(adapter.name),
    )


class OrchestratorProviderFactory:
    """Factory returning LLMOrchestrator instances. Public surface matches
    app.services.provider_factory.ProviderFactory for drop-in replacement.
    """

    def __init__(
        self,
        compass_client: Optional[CompassClient] = None,
        encryption_utils: Optional[EncryptionUtils] = None,
    ) -> None:
        self.compass_client = compass_client or CompassClient()
        self.encryption_utils = encryption_utils or get_encryption_utils()
        logger.info(
            "OrchestratorProviderFactory initialized (adapters: %s)",
            sorted(_ADAPTER_REGISTRY.keys()),
        )

    async def get_provider(
        self,
        component: Optional[str] = None,
        prefer_bedrock: bool = True,  # kept for signature parity; unused
    ) -> LLMOrchestrator:
        effective = component or _settings.studio_core.compass_component
        logger.info("Resolving provider via Compass for component: %s", effective)

        connection = await self.compass_client.get_active_connection(effective)
        if not connection:
            raise ConfigurationError(
                message=f"No active connection found for component: {effective}",
                details="Check Compass configuration in Studio Core",
            )

        return build_orchestrator(connection, self.encryption_utils)

    async def get_provider_type(
        self,
        component: Optional[str] = None,
    ) -> Optional[str]:
        effective = component or _settings.studio_core.compass_component
        try:
            connection = await self.compass_client.get_active_connection(effective)
            return connection.provider_type if connection else None
        except Exception as e:  # noqa: BLE001
            logger.error("Error getting provider type: %s", e)
            return None

    async def health_check(self) -> dict[str, Any]:
        health: dict[str, Any] = {"compass": False, "providers": {}}
        try:
            health["compass"] = await self.compass_client.health_check()
        except Exception as e:  # noqa: BLE001
            logger.error("Compass health check failed: %s", e)
            health["compass"] = False
        return health
