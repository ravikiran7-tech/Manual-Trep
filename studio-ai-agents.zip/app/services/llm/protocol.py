"""Provider-neutral data types and the LLMProvider protocol.

Adapters translate between these neutral types and their SDK's wire format.
The orchestrator works only in these types — it never sees a boto3 response or
an httpx response directly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, Union, runtime_checkable


StopReason = Literal["end_turn", "tool_use", "max_tokens", "other"]
Role = Literal["user", "assistant"]


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass(frozen=True)
class ToolUse:
    tool_use_id: str
    name: str
    input: dict[str, Any]


@dataclass(frozen=True)
class ToolResult:
    tool_use_id: str
    content: str
    is_error: bool = False


@dataclass(frozen=True)
class ReasoningBlock:
    """Provider wire block that must be echoed unchanged on the next turn.

    Sonnet 5.5 signs thinking blocks. Dropping one makes the following tool
    turn return 400. ``payload`` is the original content block.
    """

    payload: dict[str, Any]


ContentBlock = Union[str, ToolUse, ToolResult, ReasoningBlock]


def model_rejects_sampling_parameters(model_id: str) -> bool:
    """Sonnet 5.5 returns 400 if temperature, top_p, or top_k is sent."""
    return "claude-sonnet-5-5" in (model_id or "").lower()


@dataclass(frozen=True)
class ChatMessage:
    role: Role
    content: list[ContentBlock]


@dataclass
class ChatResponse:
    text_blocks: list[str] = field(default_factory=list)
    tool_uses: list[ToolUse] = field(default_factory=list)
    stop_reason: StopReason = "end_turn"
    raw: dict[str, Any] = field(default_factory=dict)
    usage: dict[str, Any] | None = None
    # Wire order, including reasoning blocks. Empty means the caller only
    # filled text_blocks and tool_uses (older call sites and test fakes).
    ordered_content: list[ContentBlock] = field(default_factory=list)


@runtime_checkable
class LLMProvider(Protocol):
    """The full surface an adapter implements. Two methods."""

    name: str
    model_id: str

    async def chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse: ...

    async def health_check(self) -> dict[str, Any]: ...
