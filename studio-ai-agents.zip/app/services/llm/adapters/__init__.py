"""Provider adapters. Each adapter implements the LLMProvider protocol:
translate neutral types <-> its SDK's wire format. Nothing more.
"""
