"""BedrockAdapter — boto3 Bedrock Converse behind the LLMProvider protocol.

Pure translation layer. No tool loop, no retries, no event normalization —
those live in LLMOrchestrator.
"""
from __future__ import annotations

import logging
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from app.clients.compass_client import ConnectionData
from app.core.config import get_settings
from app.core.exceptions import AuthenticationError, ProviderError, RateLimitError
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    LLMProvider,
    ReasoningBlock,
    ToolResult,
    ToolSpec,
    ToolUse,
    model_rejects_sampling_parameters,
)

logger = logging.getLogger(__name__)
_settings = get_settings()


_RATE_LIMIT_CODES = {
    "ThrottlingException",
    "TooManyRequestsException",
    "ServiceQuotaExceededException",
}
_AUTH_CODES = {"AccessDeniedException", "UnauthorizedException"}


class BedrockAdapter(LLMProvider):
    """LLMProvider implementation for AWS Bedrock."""

    name: str = "aws-bedrock"

    def __init__(
        self,
        region: str,
        model_id: str,
        profile: str | None,
    ) -> None:
        self.region = region
        self.model_id = model_id
        self.profile = profile or None

        session = boto3.Session(profile_name=self.profile, region_name=self.region)
        cfg = Config(
            region_name=self.region,
            retries={"max_attempts": 0},
            read_timeout=3600,
            connect_timeout=60,
            max_pool_connections=50,
        )
        try:
            self._runtime = session.client(service_name="bedrock-runtime", config=cfg)
        except Exception as e:
            msg = f"Failed to initialize Bedrock client: {e}"
            logger.error(msg)
            if "credentials" in str(e).lower():
                raise AuthenticationError(
                    message=msg,
                    details="AWS credentials not found or invalid.",
                )
            raise ProviderError(message=msg, provider="bedrock", details=str(e))

    # ------------------------------------------------------------------ factory

    @classmethod
    def from_connection(
        cls,
        connection: ConnectionData,
        encryption_utils: Any = None,  # unused; kept for uniform factory signature
    ) -> "BedrockAdapter":
        cfg = connection.configuration
        return cls(
            region=cfg.aws_region or _settings.bedrock.region,
            model_id=cfg.model_id or _settings.bedrock.default_model,
            profile=_settings.bedrock.profile,
        )

    # ------------------------------------------------------------------- chat

    async def chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse:
        # Two cache breakpoints: one after the static system prompt, one at
        # the end of the most recent user turn. On follow-up turns, both
        # become cache reads because the prefix is byte-identical, cutting
        # input-token cost ~80% on long agent loops. Once the prefix exceeds
        # the model's minimum cacheable size (4096 tokens for Sonnet 4.5),
        # the cachePoint writes; below it, Bedrock treats it as a no-op.
        #
        # cachePoint requires botocore that bundles it in the Converse model
        # (>= the version pinned in requirements.txt). An older SDK rejects it
        # client-side with ParamValidationError — that is intentional: fail
        # fast so a stale dependency surfaces immediately instead of silently
        # disabling caching.
        serialized_messages = [_message_to_bedrock(m) for m in messages]
        if serialized_messages and serialized_messages[-1]["role"] == "user":
            serialized_messages[-1]["content"].append({"cachePoint": {"type": "default"}})

        inference_config: dict[str, Any] = {"maxTokens": max_tokens}
        # Sonnet 5.5 returns 400 when temperature, top_p, or top_k is set.
        if not model_rejects_sampling_parameters(self.model_id):
            inference_config["temperature"] = temperature
        request: dict[str, Any] = {
            "modelId": self.model_id,
            "messages": serialized_messages,
            "inferenceConfig": inference_config,
        }
        if system:
            request["system"] = [{"text": system}, {"cachePoint": {"type": "default"}}]
        if tools:
            request["toolConfig"] = {
                "tools": [_tool_spec_to_bedrock(t) for t in tools],
                "toolChoice": {"auto": {}},
            }

        try:
            raw = self._runtime.converse(**request)
        except ClientError as e:
            _raise_translated(e)

        return _response_from_bedrock(raw)

    # ------------------------------------------------------------------- health

    async def health_check(self) -> dict[str, Any]:
        try:
            # Lightweight control-plane call.
            session = boto3.Session(profile_name=self.profile, region_name=self.region)
            ctl = session.client("bedrock", region_name=self.region)
            ctl.list_foundation_models(byOutputModality="TEXT")
            return {"provider": self.name, "status": "healthy", "model": self.model_id}
        except Exception as e:
            return {
                "provider": self.name,
                "status": "unhealthy",
                "model": self.model_id,
                "error": str(e),
            }


# ---------------------------------------------------------------------- helpers


def _tool_spec_to_bedrock(tool: ToolSpec) -> dict[str, Any]:
    return {
        "toolSpec": {
            "name": tool.name,
            "description": tool.description,
            "inputSchema": {"json": tool.input_schema},
        }
    }


def _message_to_bedrock(msg: ChatMessage) -> dict[str, Any]:
    content: list[dict[str, Any]] = []
    for block in msg.content:
        if isinstance(block, str):
            content.append({"text": block})
        elif isinstance(block, ToolUse):
            content.append(
                {
                    "toolUse": {
                        "toolUseId": block.tool_use_id,
                        "name": block.name,
                        "input": block.input,
                    }
                }
            )
        elif isinstance(block, ReasoningBlock):
            content.append(block.payload)
        elif isinstance(block, ToolResult):
            result_payload: dict[str, Any] = {
                "toolUseId": block.tool_use_id,
                "content": [{"text": block.content}],
            }
            if block.is_error:
                result_payload["status"] = "error"
            content.append({"toolResult": result_payload})
        else:
            raise TypeError(f"Unsupported content block type: {type(block).__name__}")
    return {"role": msg.role, "content": content}


def _response_from_bedrock(raw: dict[str, Any]) -> ChatResponse:
    output = raw.get("output", {})
    message = output.get("message", {})
    blocks = message.get("content", []) or []

    text_blocks: list[str] = []
    tool_uses: list[ToolUse] = []
    ordered_content: list[Any] = []
    for block in blocks:
        if "reasoningContent" in block:
            # Keep the signed block, including an empty thinking body.
            ordered_content.append(ReasoningBlock(payload=block))
        elif "text" in block:
            text = block["text"]
            text_blocks.append(text)
            ordered_content.append(text)
        elif "toolUse" in block:
            tu = block["toolUse"]
            tool = ToolUse(
                tool_use_id=tu.get("toolUseId", ""),
                name=tu.get("name", ""),
                input=tu.get("input", {}) or {},
            )
            tool_uses.append(tool)
            ordered_content.append(tool)

    stop_raw = raw.get("stopReason", "end_turn")
    if stop_raw == "tool_use":
        stop_reason = "tool_use"
    elif stop_raw == "max_tokens":
        stop_reason = "max_tokens"
    elif stop_raw == "end_turn":
        stop_reason = "end_turn"
    else:
        stop_reason = "other"

    usage = _normalize_usage(raw.get("usage") or {})

    return ChatResponse(
        text_blocks=text_blocks,
        tool_uses=tool_uses,
        stop_reason=stop_reason,  # type: ignore[arg-type]
        raw=raw,
        usage=usage,
        ordered_content=ordered_content,
    )


def _normalize_usage(raw_usage: dict[str, Any]) -> dict[str, Any]:
    """Convert Bedrock TokenUsage into the canonical usage shape.

    Bedrock's `inputTokens` is the TOTAL input (it already includes
    `cacheReadInputTokens` and `cacheWriteInputTokens`). The canonical
    `input_tokens` is the uncached/full-price portion only, so we
    subtract the cache fields. See AWS docs:
      https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_TokenUsage.html
    """
    if not raw_usage:
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_input_tokens": 0,
            "cache_write_input_tokens": 0,
            "total_input_tokens": 0,
            "provider": "aws-bedrock",
        }
    total_input = int(raw_usage.get("inputTokens", 0) or 0)
    cache_read = int(raw_usage.get("cacheReadInputTokens", 0) or 0)
    cache_write = int(raw_usage.get("cacheWriteInputTokens", 0) or 0)
    uncached_input = max(total_input - cache_read - cache_write, 0)
    return {
        "input_tokens": uncached_input,
        "output_tokens": int(raw_usage.get("outputTokens", 0) or 0),
        "cache_read_input_tokens": cache_read,
        "cache_write_input_tokens": cache_write,
        "total_input_tokens": total_input,
        "provider": "aws-bedrock",
    }


def _raise_translated(err: ClientError) -> None:
    info = err.response.get("Error", {}) if hasattr(err, "response") else {}
    code = info.get("Code", "Unknown")
    msg = info.get("Message", str(err))

    if code in _RATE_LIMIT_CODES:
        raise RateLimitError(
            message=f"Bedrock rate limit exceeded: {msg}",
            retry_after=60,
            details=f"Error code: {code}",
        )
    if code in _AUTH_CODES:
        raise AuthenticationError(
            message=f"Bedrock authentication failed: {msg}",
            details=f"Error code: {code}",
        )
    raise ProviderError(
        message=f"Bedrock API error: {msg}",
        provider="bedrock",
        details=f"Error code: {code}",
    )
