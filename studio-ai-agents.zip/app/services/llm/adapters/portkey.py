"""PortkeyAdapter — Anthropic Messages API via Portkey proxy.

Pure translation layer. Tool loop and normalization live in LLMOrchestrator.
"""
from __future__ import annotations

import logging
from typing import Any

import httpx

from app.clients.compass_client import ConnectionData
from app.core.config import get_settings
from app.core.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    LLMProvider,
    ReasoningBlock,
    ToolResult,
    ToolSpec,
    ToolUse,
    model_rejects_sampling_parameters,
)
from app.utils.encryption import EncryptionUtils, get_encryption_utils

logger = logging.getLogger(__name__)
_settings = get_settings()


class PortkeyAdapter(LLMProvider):
    """LLMProvider implementation for Portkey (Anthropic-format gateway)."""

    name: str = "portkey"

    def __init__(
        self,
        api_key: str,
        virtual_key: str,
        model_id: str,
        base_url: str | None = None,
        debug: bool = False,
    ) -> None:
        if not api_key:
            raise ValueError("Portkey API key is required")
        if not virtual_key:
            raise ValueError("Portkey virtual key is required")
        if not model_id:
            raise ValueError("Model ID is required")

        self.api_key = api_key
        self.virtual_key = virtual_key
        self.model_id = model_id
        self.base_url = base_url or _settings.portkey.base_url
        self.debug = debug

        self._headers = {
            "Content-Type": "application/json",
            "x-portkey-api-key": self.api_key,
            "x-portkey-virtual-key": self.virtual_key,
        }
        if self.debug:
            self._headers["x-portkey-debug"] = "true"

    # ------------------------------------------------------------------ factory

    @classmethod
    def from_connection(
        cls,
        connection: ConnectionData,
        encryption_utils: EncryptionUtils | None = None,
    ) -> "PortkeyAdapter":
        """Build from a Compass ConnectionData. Mirrors legacy
        ProviderFactory._create_portkey_client.
        """
        encryption_utils = encryption_utils or get_encryption_utils()

        cfg = connection.configuration
        api_key_encrypted = connection.portkey_api_key or cfg.portkey_api_key
        base_url = connection.portkey_base_url or cfg.portkey_base_url

        if not api_key_encrypted:
            raise ConfigurationError(
                message="Portkey API key is missing in connection configuration",
                details=f"Component: {connection.component}, Connection ID: {connection.connection_id}",
            )
        if not connection.slug:
            raise ConfigurationError(
                message="Portkey slug is missing in connection configuration",
                details=f"Component: {connection.component}, Connection ID: {connection.connection_id}",
            )

        try:
            api_key = encryption_utils.decrypt(api_key_encrypted)
        except Exception as e:
            raise ConfigurationError(
                message=f"Failed to decrypt Portkey API key: {e}",
                details=f"Error: {type(e).__name__}",
            )
        if not api_key:
            raise ConfigurationError(message="Decrypted Portkey API key is empty")

        parts = connection.slug.split("/")
        if len(parts) != 2:
            raise ConfigurationError(
                message="Invalid Portkey slug format",
                details=f"Expected '@virtual-key/model-id', got: {connection.slug}",
            )
        virtual_key = parts[0][1:] if parts[0].startswith("@") else parts[0]
        model_id = parts[1]
        if not virtual_key or not model_id:
            raise ConfigurationError(message="Virtual key or model id empty in slug")

        debug = (
            connection.debug_enabled
            if connection.debug_enabled is not None
            else (cfg.debug_enabled or False)
        )

        return cls(
            api_key=api_key,
            virtual_key=virtual_key,
            model_id=model_id,
            base_url=base_url,
            debug=debug,
        )

    # ------------------------------------------------------------------- chat

    async def chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse:
        # Two cache breakpoints (Anthropic prompt caching): one on the static
        # system prompt, one on the last content block of the most recent user
        # turn. On follow-up turns both become cache reads because the prefix
        # is byte-identical, cutting input-token cost ~80% on long agent loops.
        # If the prefix is below the model's minimum cacheable size, Anthropic
        # silently treats `cache_control` as a no-op — no error path.
        serialized_messages = [_message_to_portkey(m) for m in messages]
        if serialized_messages and serialized_messages[-1]["role"] == "user":
            last_msg = serialized_messages[-1]
            content = last_msg["content"]
            if isinstance(content, str):
                # Promote string content to a list so we can attach cache_control.
                content = [{"type": "text", "text": content}]
                last_msg["content"] = content
            if isinstance(content, list) and content:
                content[-1] = {**content[-1], "cache_control": {"type": "ephemeral"}}

        body: dict[str, Any] = {
            "model": self.model_id,
            "messages": serialized_messages,
            "max_tokens": max_tokens,
            "stream": False,
        }
        # Sonnet 5.5 returns 400 when temperature, top_p, or top_k is set.
        if not model_rejects_sampling_parameters(self.model_id):
            body["temperature"] = temperature
        if system:
            body["system"] = [
                {"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}
            ]
        if tools:
            body["tools"] = [_tool_spec_to_portkey(t) for t in tools]

        url = f"{self.base_url}/messages"
        async with httpx.AsyncClient(timeout=3600) as client:
            response = await client.post(url, headers=self._headers, json=body)

        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise RateLimitError(
                message="Portkey rate limit exceeded",
                retry_after=retry_after,
                details=f"Status: {response.status_code}",
            )
        if response.status_code in (401, 403):
            raise AuthenticationError(
                message=f"Portkey authentication failed (status {response.status_code})",
                details=response.text[:200],
            )
        if response.status_code >= 400:
            raise ProviderError(
                message=f"Portkey API error: {response.status_code}",
                provider="portkey",
                details=response.text[:500],
            )

        return _response_from_portkey(response.json())

    # ------------------------------------------------------------------ health

    async def health_check(self) -> dict[str, Any]:
        """Minimal: send a 1-token probe. No cheap /health endpoint on Portkey."""
        try:
            probe = await self.chat(
                messages=[ChatMessage(role="user", content=["ping"])],
                system=None,
                tools=None,
                max_tokens=1,
                temperature=0.0,
            )
            return {
                "provider": self.name,
                "status": "healthy",
                "model": self.model_id,
                "stop_reason": probe.stop_reason,
            }
        except Exception as e:
            return {
                "provider": self.name,
                "status": "unhealthy",
                "model": self.model_id,
                "error": str(e),
            }


# ---------------------------------------------------------------------- helpers


def _tool_spec_to_portkey(tool: ToolSpec) -> dict[str, Any]:
    return {
        "name": tool.name,
        "description": tool.description,
        "input_schema": tool.input_schema,
    }


def _message_to_portkey(msg: ChatMessage) -> dict[str, Any]:
    # Anthropic accepts either a plain string or a list of content blocks.
    if len(msg.content) == 1 and isinstance(msg.content[0], str):
        return {"role": msg.role, "content": msg.content[0]}

    blocks: list[dict[str, Any]] = []
    for block in msg.content:
        if isinstance(block, str):
            blocks.append({"type": "text", "text": block})
        elif isinstance(block, ToolUse):
            blocks.append(
                {
                    "type": "tool_use",
                    "id": block.tool_use_id,
                    "name": block.name,
                    "input": block.input,
                }
            )
        elif isinstance(block, ReasoningBlock):
            blocks.append(block.payload)
        elif isinstance(block, ToolResult):
            blocks.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.tool_use_id,
                    "content": block.content,
                    "is_error": block.is_error,
                }
            )
        else:
            raise TypeError(f"Unsupported content block: {type(block).__name__}")
    return {"role": msg.role, "content": blocks}


def _response_from_portkey(raw: dict[str, Any]) -> ChatResponse:
    content = raw.get("content", []) or []
    text_blocks: list[str] = []
    tool_uses: list[ToolUse] = []
    ordered_content: list[Any] = []
    for block in content:
        btype = block.get("type")
        if btype in ("thinking", "redacted_thinking"):
            ordered_content.append(ReasoningBlock(payload=block))
        elif btype == "text":
            text = block.get("text", "")
            text_blocks.append(text)
            ordered_content.append(text)
        elif btype == "tool_use":
            tool = ToolUse(
                tool_use_id=block.get("id", ""),
                name=block.get("name", ""),
                input=block.get("input", {}) or {},
            )
            tool_uses.append(tool)
            ordered_content.append(tool)

    raw_stop = raw.get("stop_reason", "end_turn") or "end_turn"
    if raw_stop == "tool_use":
        stop_reason = "tool_use"
    elif raw_stop == "max_tokens":
        stop_reason = "max_tokens"
    elif raw_stop == "end_turn":
        stop_reason = "end_turn"
    else:
        stop_reason = "other"

    return ChatResponse(
        text_blocks=text_blocks,
        tool_uses=tool_uses,
        stop_reason=stop_reason,  # type: ignore[arg-type]
        raw=raw,
        usage=_normalize_usage(raw.get("usage") or {}),
        ordered_content=ordered_content,
    )


def _normalize_usage(raw_usage: dict[str, Any]) -> dict[str, Any]:
    """Convert Anthropic Messages `usage` into the canonical usage shape.

    Anthropic already separates the three input categories:
    - `input_tokens`: uncached/full-price
    - `cache_read_input_tokens`: served from cache
    - `cache_creation_input_tokens`: written to cache this turn
    """
    if not raw_usage:
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_input_tokens": 0,
            "cache_write_input_tokens": 0,
            "total_input_tokens": 0,
            "provider": "portkey",
        }
    uncached_input = int(raw_usage.get("input_tokens", 0) or 0)
    cache_read = int(raw_usage.get("cache_read_input_tokens", 0) or 0)
    cache_write = int(raw_usage.get("cache_creation_input_tokens", 0) or 0)
    return {
        "input_tokens": uncached_input,
        "output_tokens": int(raw_usage.get("output_tokens", 0) or 0),
        "cache_read_input_tokens": cache_read,
        "cache_write_input_tokens": cache_write,
        "total_input_tokens": uncached_input + cache_read + cache_write,
        "provider": "portkey",
    }
