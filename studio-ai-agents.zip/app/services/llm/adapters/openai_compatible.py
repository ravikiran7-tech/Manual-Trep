"""OpenAICompatibleAdapter — Concierto private LLM and other OpenAI-compatible servers.

Talks to any server exposing the OpenAI Chat Completions API at
{base_url}/v1/chat/completions with Bearer auth. Configuration comes from the
Compass connection whose providerType is "concierto-private-llm", which carries
caiBaseUrl / caiModel / caiApiKey. Plain httpx transport; translates between the
neutral protocol types and OpenAI wire JSON. The tool loop lives in
LLMOrchestrator.
"""
from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from app.clients.compass_client import ConnectionData
from app.core.config import get_settings
from app.core.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    LLMProvider,
    ToolResult,
    ToolSpec,
    ToolUse,
)
from app.utils.encryption import EncryptionUtils, get_encryption_utils

logger = logging.getLogger(__name__)
_settings = get_settings()

# Fallbacks for OPENAI_COMPAT_* settings that may not be on the config object
# yet (see _coerce). These mirror the documented defaults for this provider.
_FALLBACK_TIMEOUT = 3600.0
_FALLBACK_MAX_TOKENS = 64000
_FALLBACK_TEMPERATURE = 0.0
_FALLBACK_STREAM = True

# Sentinel that terminates an OpenAI SSE stream.
_SSE_DONE = "[DONE]"


class OpenAICompatibleAdapter(LLMProvider):
    """LLMProvider for OpenAI-compatible chat-completions servers."""

    name: str = "openai-compatible"

    def __init__(
        self,
        base_url: str,
        model_id: str,
        api_key: str | None = None,
        *,
        max_tokens: int | None = None,
        temperature: float | None = None,
        enable_thinking: bool | None = None,
        timeout: float | None = None,
        stream: bool | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("OpenAI-compatible base_url is required")
        if not model_id:
            raise ValueError("Model ID is required")

        self.base_url = base_url
        self.model_id = model_id
        self.api_key = api_key or None
        # When set, these override the caller's per-call values (max_tokens <= 0
        # means "use the caller's value").
        self.max_tokens_override = max_tokens if (max_tokens and max_tokens > 0) else None
        self.temperature_override = temperature
        self.enable_thinking = enable_thinking
        self.timeout = timeout if timeout is not None else _request_timeout()
        self.stream = stream if stream is not None else _request_stream()

        self._url = _completions_url(base_url)
        self._headers = {"Content-Type": "application/json"}
        if self.api_key:
            self._headers["Authorization"] = f"Bearer {self.api_key}"

    # ------------------------------------------------------------------ factory

    @classmethod
    def from_connection(
        cls,
        connection: ConnectionData,
        encryption_utils: EncryptionUtils | None = None,
    ) -> "OpenAICompatibleAdapter":
        """Build from a Compass ConnectionData (providerType concierto-private-llm).

        Upstream populates caiBaseUrl / caiApiKey / caiModel both at the top level
        of the connection and inside configuration{}, so each field is read from
        the top level first and falls back to the nested block. The API key goes
        through _maybe_decrypt, which decrypts only when the value is ciphertext.
        """
        encryption_utils = encryption_utils or get_encryption_utils()

        cfg = connection.configuration
        base_url = connection.cai_base_url or cfg.cai_base_url
        model_id = connection.cai_model or cfg.cai_model
        api_key = connection.cai_api_key or cfg.cai_api_key

        # Only used to annotate the misconfiguration errors below, so whoever
        # reads the log knows which Compass connection is at fault.
        error_context = (
            f"Component: {connection.component}, "
            f"Connection ID: {connection.connection_id}"
        )
        if not base_url:
            raise ConfigurationError(
                message="caiBaseUrl is missing in connection configuration",
                details=error_context,
            )
        if not model_id:
            raise ConfigurationError(
                message="caiModel is missing in connection configuration",
                details=error_context,
            )

        return cls(
            base_url=base_url,
            model_id=model_id,
            api_key=_maybe_decrypt(api_key, encryption_utils),
        )

    async def chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse:
        openai_messages: list[dict[str, Any]] = []
        if system:
            openai_messages.append({"role": "system", "content": system})
        for msg in messages:
            openai_messages.extend(_message_to_openai(msg))

        body: dict[str, Any] = {
            "model": self.model_id,
            "messages": openai_messages,
            "max_tokens": self.max_tokens_override or max_tokens,
            "temperature": (
                self.temperature_override
                if self.temperature_override is not None
                else temperature
            ),
            "stream": self.stream,
        }
        if self.stream:
            # Without this the stream carries no usage block at all, and token
            # accounting downstream silently reports zeros.
            body["stream_options"] = {"include_usage": True}
        if tools:
            body["tools"] = [_tool_spec_to_openai(t) for t in tools]
            body["tool_choice"] = "auto"

        # enable_thinking maps to vLLM/gemma's chat_template_kwargs.
        if self.enable_thinking is not None:
            body["chat_template_kwargs"] = {"enable_thinking": self.enable_thinking}

        if self.stream:
            payload = await self._collect_stream(body)
        else:
            payload = await self._post(body)

        return _response_from_openai(payload, provider=self.name)

    # ---------------------------------------------------------------- transport

    async def _post(self, body: dict[str, Any]) -> dict[str, Any]:
        """One blocking request; the whole payload arrives at the end or not at all."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(self._url, headers=self._headers, json=body)
        except httpx.RequestError as e:
            raise self._request_error(e)

        self._raise_for_status(response)

        try:
            return response.json()
        except ValueError as e:
            raise ProviderError(
                message="OpenAI-compatible response was not valid JSON",
                provider=self.name,
                details=f"{type(e).__name__}: {response.text[:300]}",
            )

    async def _collect_stream(self, body: dict[str, Any]) -> dict[str, Any]:
        """Consume the SSE stream and rebuild the non-streaming payload shape.

        Streaming is not about incremental delivery here — nothing upstream
        consumes partial output. It is about keeping bytes on the wire: an
        intermediary between this process and the inference server drops
        connections that go quiet (the Concierto proxy sits behind a load
        balancer with a 60s idle timeout), and a non-streaming request sends
        nothing at all until generation finishes, so any answer that takes
        longer than that window is lost to a 504. Every delta resets the timer.
        """
        accumulator = _StreamAccumulator()
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                async with client.stream(
                    "POST", self._url, headers=self._headers, json=body
                ) as response:
                    if response.status_code >= 400:
                        # response.text is empty on a streamed response until read.
                        await response.aread()
                        self._raise_for_status(response)
                    async for line in response.aiter_lines():
                        accumulator.consume_line(line)
        except httpx.RequestError as e:
            raise self._request_error(e)

        # A stream that stops without a finish_reason was cut short. The content
        # gathered so far looks like a complete answer and must not be returned
        # as one.
        if not accumulator.completed:
            raise ProviderError(
                message="OpenAI-compatible stream ended without a finish_reason",
                provider=self.name,
                details=(
                    f"URL: {self._url}, chunks: {accumulator.chunks}, "
                    f"content chars: {accumulator.content_length}"
                ),
            )

        return accumulator.to_payload(model=self.model_id)

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Map an error status onto this provider's exceptions.

        Reading response.text requires the body to be available, so a streamed
        response must be aread() before this is called.
        """
        if response.status_code == 429:
            raise RateLimitError(
                message="OpenAI-compatible rate limit exceeded",
                retry_after=_retry_after_seconds(response.headers.get("Retry-After")),
                details=f"Status: {response.status_code}",
            )
        if response.status_code in (401, 403):
            raise AuthenticationError(
                message=f"OpenAI-compatible authentication failed (status {response.status_code})",
                details=response.text[:200],
            )
        if response.status_code >= 400:
            raise ProviderError(
                message=f"OpenAI-compatible API error: {response.status_code}",
                provider=self.name,
                details=response.text[:500],
            )

    def _request_error(self, e: httpx.RequestError) -> ProviderError:
        return ProviderError(
            message=f"OpenAI-compatible request failed: {e}",
            provider=self.name,
            details=f"URL: {self._url}, Error: {type(e).__name__}",
        )

    async def health_check(self) -> dict[str, Any]:
        try:
            probe = await self.chat(
                messages=[ChatMessage(role="user", content=["ping"])],
                system=None,
                tools=None,
                max_tokens=1,
                temperature=0.0,
            )
            return {
                "provider": self.name,
                "status": "healthy",
                "model": self.model_id,
                "stop_reason": probe.stop_reason,
            }
        except Exception as e:  # noqa: BLE001
            return {
                "provider": self.name,
                "status": "unhealthy",
                "model": self.model_id,
                "error": str(e),
            }


# ------------------------------------------------------------------ SSE folding


class _StreamAccumulator:
    """Folds OpenAI SSE deltas back into a single chat-completion payload.

    Tool-call fragments are keyed by their index: the first delta for an index
    carries the id and function.name, later ones carry partial JSON in
    function.arguments, so the pieces are concatenated in arrival order and only
    parsed once the stream ends.

    reasoning_content is accumulated separately and deliberately kept out of
    content. Reasoning models stream their thinking on that field, and the
    non-streaming path never placed it in the assistant text — folding the two
    together here would leak private reasoning into the answer the callers parse.
    """

    def __init__(self) -> None:
        self._content: list[str] = []
        self._reasoning: list[str] = []
        self._tool_calls: dict[int, dict[str, Any]] = {}
        self._finish_reason: str | None = None
        self._usage: dict[str, Any] | None = None
        self._id: str | None = None
        self._model: str | None = None
        self._created: int | None = None
        self.chunks = 0

    @property
    def completed(self) -> bool:
        """True once a finish_reason has arrived, i.e. the stream ran to its end."""
        return self._finish_reason is not None

    @property
    def content_length(self) -> int:
        return sum(len(part) for part in self._content)

    @property
    def reasoning_content(self) -> str:
        """The model's thinking, kept apart from the answer."""
        return "".join(self._reasoning)

    def consume_line(self, line: str) -> None:
        """Fold one raw SSE line, skipping blanks, comments and the [DONE] sentinel."""
        if not line.startswith("data:"):
            return
        data = line[len("data:"):].strip()
        if not data or data == _SSE_DONE:
            return
        try:
            chunk = json.loads(data)
        except ValueError:
            logger.warning("Skipping unparseable OpenAI-compatible stream chunk")
            return
        if isinstance(chunk, dict):
            self.consume(chunk)

    def consume(self, chunk: dict[str, Any]) -> None:
        self.chunks += 1
        self._id = self._id or chunk.get("id")
        self._model = self._model or chunk.get("model")
        self._created = self._created or chunk.get("created")
        # Usage rides a trailing chunk of its own, and only when it was asked for.
        if chunk.get("usage"):
            self._usage = chunk["usage"]

        for choice in chunk.get("choices") or []:
            delta = choice.get("delta") or {}
            if delta.get("content"):
                self._content.append(str(delta["content"]))
            if delta.get("reasoning_content"):
                self._reasoning.append(str(delta["reasoning_content"]))
            for call in delta.get("tool_calls") or []:
                self._merge_tool_call(call)
            if choice.get("finish_reason"):
                self._finish_reason = choice["finish_reason"]

    def _merge_tool_call(self, call: dict[str, Any]) -> None:
        try:
            index = int(call.get("index", 0) or 0)
        except (TypeError, ValueError):
            index = 0
        slot = self._tool_calls.setdefault(index, {"id": "", "name": "", "arguments": []})
        if call.get("id"):
            slot["id"] = str(call["id"])
        function = call.get("function") or {}
        if function.get("name"):
            slot["name"] = str(function["name"])
        if function.get("arguments"):
            slot["arguments"].append(str(function["arguments"]))

    def to_payload(self, *, model: str) -> dict[str, Any]:
        """Rebuild the payload shape _response_from_openai already reads.

        Going back through that function rather than building a ChatResponse here
        keeps streaming and non-streaming on one mapping, and keeps ChatResponse.raw
        a full completion dict — the orchestrator hands it straight to callers.
        """
        message: dict[str, Any] = {
            "role": "assistant",
            "content": "".join(self._content),
        }
        if self._tool_calls:
            message["tool_calls"] = [
                {
                    "id": self._tool_calls[index]["id"],
                    "type": "function",
                    "function": {
                        "name": self._tool_calls[index]["name"],
                        "arguments": "".join(self._tool_calls[index]["arguments"]),
                    },
                }
                for index in sorted(self._tool_calls)
            ]

        return {
            "id": self._id or "",
            "object": "chat.completion",
            "created": self._created or 0,
            "model": self._model or model,
            "choices": [{
                "index": 0,
                "message": message,
                "finish_reason": self._finish_reason,
            }],
            "usage": self._usage or {},
        }


# ---------------------------------------------------------------------- helpers


def _coerce(raw: Any, cast: Any, fallback: Any) -> Any:
    """Cast one settings value, falling back when it is absent or unparseable.

    OpenAICompatibleConfig is being slimmed and restored on a parallel branch,
    so every field is read through here rather than accessed directly.
    """
    if raw is None:
        return fallback
    try:
        return cast(raw)
    except (TypeError, ValueError):
        return fallback


def _request_timeout() -> float:
    """HTTP timeout (seconds) from the OPENAI_COMPAT_* settings block.

    Unchanged in effect from the value that was hardcoded here before — the
    default is still 3600s, it is just overridable per environment now. A 0 or
    empty setting means "not configured" and takes the fallback.
    """
    raw = getattr(_settings.openai_compatible, "timeout", None)
    return _coerce(raw, float, _FALLBACK_TIMEOUT) if raw else _FALLBACK_TIMEOUT


def _request_stream() -> bool:
    """Whether to stream, from OPENAI_COMPAT_STREAM. Defaults to on.

    Streaming is the default because the Concierto proxy sits behind a load
    balancer that closes idle connections well before a long generation
    finishes; see OpenAICompatibleAdapter._collect_stream. The setting exists so
    an environment can turn it back off without a code change.

    Unlike the other settings, False here is a real value rather than "not
    configured", so only None falls back.
    """
    raw = getattr(_settings.openai_compatible, "stream", None)
    if raw is None:
        return _FALLBACK_STREAM
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() not in ("0", "false", "no", "off", "")


def generation_defaults() -> dict[str, Any]:
    """max_tokens / temperature for this provider, from OPENAI_COMPAT_* settings.

    Public because the factory must pass these into LLMOrchestrator explicitly:
    the orchestrator falls back to _settings.bedrock.max_tokens / .temperature
    when they are None, which would silently run the private LLM on Bedrock's
    generation settings.

    A non-positive max_tokens counts as unset; temperature 0.0 is a real value,
    so only None falls back.
    """
    oc = _settings.openai_compatible
    max_tokens = _coerce(getattr(oc, "max_tokens", None), int, _FALLBACK_MAX_TOKENS)
    return {
        "max_tokens": max_tokens if max_tokens > 0 else _FALLBACK_MAX_TOKENS,
        "temperature": _coerce(
            getattr(oc, "temperature", None), float, _FALLBACK_TEMPERATURE
        ),
    }


def _completions_url(base_url: str) -> str:
    """Build the chat-completions URL, accepting host, host/v1, or the full path."""
    trimmed = base_url.rstrip("/")
    if trimmed.endswith("/chat/completions"):
        return trimmed
    if trimmed.endswith("/v1"):
        return f"{trimmed}/chat/completions"
    return f"{trimmed}/v1/chat/completions"


def _maybe_decrypt(raw: str | None, encryption_utils: EncryptionUtils) -> str | None:
    """Decrypt the key only if it looks like ciphertext; otherwise use it as-is."""
    if not raw:
        return None
    try:
        if encryption_utils.is_encrypted(raw):
            decrypted = encryption_utils.decrypt(raw)
            if decrypted:
                return decrypted
    except Exception as e:  # noqa: BLE001
        logger.warning(
            "OpenAI-compatible API key decryption failed (%s); using raw value",
            type(e).__name__,
        )
    return raw


def _retry_after_seconds(value: str | None) -> int:
    try:
        return int(value) if value is not None else 60
    except (TypeError, ValueError):
        return 60


def _tool_spec_to_openai(tool: ToolSpec) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": _sanitize_schema_for_openai(tool.input_schema),
        },
    }


def _sanitize_schema_for_openai(schema: Any) -> Any:
    # OpenAI rejects an "array" type without "items"; default it to {} (any).
    if isinstance(schema, dict):
        out = {k: _sanitize_schema_for_openai(v) for k, v in schema.items()}
        t = out.get("type")
        if (t == "array" or (isinstance(t, list) and "array" in t)) and "items" not in out:
            out["items"] = {}
        return out
    if isinstance(schema, list):
        return [_sanitize_schema_for_openai(v) for v in schema]
    return schema


def _message_to_openai(msg: ChatMessage) -> list[dict[str, Any]]:
    """Convert a neutral ChatMessage into OpenAI chat message(s)."""
    if msg.role == "assistant":
        text_parts: list[str] = []
        tool_calls: list[dict[str, Any]] = []
        for block in msg.content:
            if isinstance(block, str):
                text_parts.append(block)
            elif isinstance(block, ToolUse):
                tool_calls.append({
                    "id": block.tool_use_id,
                    "type": "function",
                    "function": {
                        "name": block.name,
                        "arguments": _stringify_arguments(block.input),
                    },
                })
        out: dict[str, Any] = {"role": "assistant", "content": "\n".join(text_parts)}
        if tool_calls:
            out["tool_calls"] = tool_calls
        return [out]

    # user turn: tool results become separate "tool" messages, emitted first.
    tool_messages: list[dict[str, Any]] = []
    text_parts: list[str] = []
    for block in msg.content:
        if isinstance(block, str):
            text_parts.append(block)
        elif isinstance(block, ToolResult):
            tool_messages.append({
                "role": "tool",
                "tool_call_id": block.tool_use_id,
                "content": block.content,
            })
        elif isinstance(block, ToolUse):
            text_parts.append(f"[tool_use:{block.name}]{block.input}")

    messages = list(tool_messages)
    if text_parts:
        messages.append({"role": "user", "content": "\n".join(text_parts)})
    return messages


def _stringify_arguments(inp: dict[str, Any]) -> str:
    try:
        return json.dumps(inp)
    except TypeError:
        return str(inp)


def _response_from_openai(raw: dict[str, Any], *, provider: str) -> ChatResponse:
    choices = raw.get("choices") or []
    first = choices[0] if choices else {}
    message = first.get("message") or {}

    text_blocks: list[str] = []
    content = message.get("content")
    if content:
        text_blocks.append(str(content))

    tool_uses: list[ToolUse] = []
    for call in message.get("tool_calls") or []:
        fn = call.get("function") or {}
        tool_uses.append(ToolUse(
            tool_use_id=str(call.get("id", "") or ""),
            name=str(fn.get("name", "") or ""),
            input=_parse_arguments(fn.get("arguments", "")),
        ))

    return ChatResponse(
        text_blocks=text_blocks,
        tool_uses=tool_uses,
        stop_reason=_map_finish_reason(first.get("finish_reason")),  # type: ignore[arg-type]
        raw=raw,
        usage=_normalize_usage(raw.get("usage") or {}, provider=provider),
    )


def _map_finish_reason(reason: Any) -> str:
    if reason == "tool_calls":
        return "tool_use"
    if reason == "length":
        return "max_tokens"
    if reason == "stop":
        return "end_turn"
    return "other"


def _normalize_usage(raw_usage: dict[str, Any], *, provider: str) -> dict[str, Any]:
    """Map OpenAI usage into the canonical shape. prompt_tokens is the total
    input; cached tokens come from prompt_tokens_details.cached_tokens."""
    total_input = int(raw_usage.get("prompt_tokens", 0) or 0)
    details = raw_usage.get("prompt_tokens_details") or {}
    cache_read = int(details.get("cached_tokens", 0) or 0)
    return {
        "input_tokens": max(total_input - cache_read, 0),
        "output_tokens": int(raw_usage.get("completion_tokens", 0) or 0),
        "cache_read_input_tokens": cache_read,
        "cache_write_input_tokens": 0,
        "total_input_tokens": total_input,
        "provider": provider,
    }


def _parse_arguments(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {"_raw": parsed}
    except Exception:  # noqa: BLE001
        return {"_raw": str(raw)}
