"""AzureAdapter — Azure AI Inference SDK + Managed Identity.

Unified client for models hosted on Azure AI Foundry (Claude, GPT, Mistral,
Llama). Auth via DefaultAzureCredential: VM Managed Identity in production,
`az login` in dev. No API keys in prod. Mirrors the EC2-IAM-role pattern used
by boto3 in BedrockAdapter.

Pure translation layer; tool loop lives in LLMOrchestrator.
"""
from __future__ import annotations

import logging
from typing import Any

from app.clients.compass_client import ConnectionData
from app.core.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProviderError,
    RateLimitError,
)
from app.services.llm.protocol import (
    ChatMessage,
    ChatResponse,
    LLMProvider,
    ToolResult,
    ToolSpec,
    ToolUse,
    model_rejects_sampling_parameters,
)

logger = logging.getLogger(__name__)


class AzureAdapter(LLMProvider):
    """LLMProvider implementation for Azure AI Inference."""

    name: str = "azure"

    def __init__(
        self,
        endpoint: str,
        model_id: str,
        api_key: str | None = None,
    ) -> None:
        # Import lazily so test environments without azure-* SDKs can still
        # import this module to inspect the adapter's signature.
        from azure.ai.inference.aio import ChatCompletionsClient  # noqa: WPS433

        self.endpoint = endpoint
        self.model_id = model_id

        try:
            if api_key:
                from azure.core.credentials import AzureKeyCredential  # noqa: WPS433

                self._credential = AzureKeyCredential(api_key)
                logger.info("Azure adapter using AzureKeyCredential (api-key auth)")
                self._client = ChatCompletionsClient(
                    endpoint=endpoint,
                    credential=self._credential,
                )
            else:
                from azure.identity.aio import DefaultAzureCredential  # noqa: WPS433

                self._credential = DefaultAzureCredential()
                logger.info("Azure adapter using DefaultAzureCredential (managed identity / az login)")
                # AI Foundry rejects the SDK's default scope; force the audience the resource expects.
                self._client = ChatCompletionsClient(
                    endpoint=endpoint,
                    credential=self._credential,
                    credential_scopes=["https://cognitiveservices.azure.com/.default"],
                )
        except Exception as e:
            msg = f"Failed to initialize Azure AI Inference client: {e}"
            logger.error(msg)
            raise ProviderError(message=msg, provider="azure", details=str(e))

    # ------------------------------------------------------------------ factory

    @classmethod
    def from_connection(
        cls,
        connection: ConnectionData,
        encryption_utils: Any = None,  # unused; Managed Identity — no secrets
    ) -> "AzureAdapter":
        endpoint = connection.azure_ai_endpoint
        if not endpoint:
            raise ConfigurationError(
                message="azureAiEndpoint missing for azure connection",
                details=f"Connection ID: {connection.connection_id}",
            )
        model_id = connection.model_id
        if not model_id:
            raise ConfigurationError(
                message="modelId missing for azure connection",
                details=f"Connection ID: {connection.connection_id}",
            )
        return cls(endpoint=endpoint, model_id=model_id, api_key=None)

    # ------------------------------------------------------------------- chat

    async def chat(
        self,
        *,
        messages: list[ChatMessage],
        system: str | None,
        tools: list[ToolSpec] | None,
        max_tokens: int,
        temperature: float,
    ) -> ChatResponse:
        from azure.core.exceptions import HttpResponseError  # noqa: WPS433

        azure_messages: list[dict[str, Any]] = []
        if system:
            azure_messages.append({"role": "system", "content": system})
        for msg in messages:
            azure_messages.extend(_message_to_azure(msg))

        body: dict[str, Any] = {
            "messages": azure_messages,
            "model": self.model_id,
        }
        # Sonnet 5.5 returns 400 when temperature, top_p, or top_k is set.
        if not model_rejects_sampling_parameters(self.model_id):
            body["temperature"] = temperature
        # GPT models (o1, gpt-4o, gpt-5+) reject "max_tokens" and require
        # "max_completion_tokens" passed via model_extras. Claude/Mistral/Llama
        # on Azure still accept "max_tokens".
        if _is_openai_model(self.model_id):
            body["model_extras"] = {"max_completion_tokens": max_tokens}
        else:
            body["max_tokens"] = max_tokens
        if tools:
            body["tools"] = [_tool_spec_to_azure(t) for t in tools]
            body["tool_choice"] = "auto"

        try:
            raw = await self._client.complete(**body)
        except HttpResponseError as e:
            _raise_translated(e)
        except Exception as e:
            raise ProviderError(
                message=f"Azure AI Inference error: {e}",
                provider="azure",
                details=str(e),
            )

        return _response_from_azure(raw)

    # ------------------------------------------------------------------ health

    async def health_check(self) -> dict[str, Any]:
        try:
            info = await self._client.get_model_info()
            return {
                "provider": self.name,
                "status": "healthy",
                "model": self.model_id,
                "model_info": _model_info_to_dict(info),
            }
        except Exception as e:
            return {
                "provider": self.name,
                "status": "unhealthy",
                "model": self.model_id,
                "error": str(e),
            }


# ---------------------------------------------------------------------- helpers


def _tool_spec_to_azure(tool: ToolSpec) -> dict[str, Any]:
    # Azure AI Inference uses OpenAI-style function tool schema. OpenAI's
    # validator is stricter than Anthropic/Bedrock: any "array" type must
    # carry an "items" schema. Sanitize so shared tool specs remain neutral.
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": _sanitize_schema_for_openai(tool.input_schema),
        },
    }


def _sanitize_schema_for_openai(schema: Any) -> Any:
    """Recursively ensure 'array' type entries declare 'items'.

    OpenAI rejects schemas where a property has type 'array' (or a type
    union including 'array') without an accompanying 'items' definition.
    Default missing items to {} (any) so we don't over-constrain.
    """
    if isinstance(schema, dict):
        out = {k: _sanitize_schema_for_openai(v) for k, v in schema.items()}
        t = out.get("type")
        is_array = t == "array" or (isinstance(t, list) and "array" in t)
        if is_array and "items" not in out:
            out["items"] = {}
        return out
    if isinstance(schema, list):
        return [_sanitize_schema_for_openai(v) for v in schema]
    return schema


def _message_to_azure(msg: ChatMessage) -> list[dict[str, Any]]:
    """Convert a neutral ChatMessage into one-or-more Azure chat messages.

    Tool results in Anthropic-style live inside a user turn; in OpenAI-style
    they are separate messages with role="tool". So a single user ChatMessage
    carrying N ToolResults expands into N tool messages. Assistant turns with
    tool uses become a single assistant message with tool_calls.
    """
    if msg.role == "assistant":
        text_parts: list[str] = []
        tool_calls: list[dict[str, Any]] = []
        for block in msg.content:
            if isinstance(block, str):
                text_parts.append(block)
            elif isinstance(block, ToolUse):
                tool_calls.append(
                    {
                        "id": block.tool_use_id,
                        "type": "function",
                        "function": {
                            "name": block.name,
                            "arguments": _stringify_arguments(block.input),
                        },
                    }
                )
        out: dict[str, Any] = {"role": "assistant"}
        if text_parts:
            out["content"] = "\n".join(text_parts)
        else:
            out["content"] = ""
        if tool_calls:
            out["tool_calls"] = tool_calls
        return [out]

    # role == "user" — may contain plain text, tool results, or a mix.
    messages: list[dict[str, Any]] = []
    text_parts: list[str] = []
    for block in msg.content:
        if isinstance(block, str):
            text_parts.append(block)
        elif isinstance(block, ToolResult):
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": block.tool_use_id,
                    "content": block.content,
                }
            )
        elif isinstance(block, ToolUse):
            # Unusual in a user turn, but pass through as JSON text.
            text_parts.append(f"[tool_use:{block.name}]{block.input}")
    if text_parts:
        # Put the user text first so the model sees it before tool results
        # that stream after on follow-up turns.
        messages.insert(0, {"role": "user", "content": "\n".join(text_parts)})
    return messages


def _stringify_arguments(inp: dict[str, Any]) -> str:
    import json

    try:
        return json.dumps(inp)
    except TypeError:
        return str(inp)


def _response_from_azure(raw: Any) -> ChatResponse:
    """Normalize an Azure AI Inference ChatCompletions response.

    The SDK returns a typed object; duck-type access keeps this adapter
    robust across minor SDK versions.
    """
    choices = _attr(raw, "choices", []) or []
    first = choices[0] if choices else None

    text_blocks: list[str] = []
    tool_uses: list[ToolUse] = []
    finish_reason = "end_turn"

    if first is not None:
        message = _attr(first, "message", None)
        if message is not None:
            content = _attr(message, "content", None)
            if content:
                text_blocks.append(str(content))
            tool_calls = _attr(message, "tool_calls", None) or []
            for call in tool_calls:
                fn = _attr(call, "function", None)
                name = _attr(fn, "name", "") if fn is not None else ""
                args_raw = _attr(fn, "arguments", "") if fn is not None else ""
                tool_uses.append(
                    ToolUse(
                        tool_use_id=str(_attr(call, "id", "") or ""),
                        name=str(name or ""),
                        input=_parse_arguments(args_raw),
                    )
                )
        finish_reason_raw = _attr(first, "finish_reason", "stop") or "stop"
        finish_reason = _map_finish_reason(finish_reason_raw)

    usage = _normalize_usage(_attr(raw, "usage", None))

    # Trust the provider's signal verbatim (matches Bedrock/Portkey adapters).
    # finish_reason is already mapped to neutral StopReason via _map_finish_reason.
    stop_reason = finish_reason

    return ChatResponse(
        text_blocks=text_blocks,
        tool_uses=tool_uses,
        stop_reason=stop_reason,  # type: ignore[arg-type]
        raw=_to_dict(raw),
        usage=usage,
    )


def _map_finish_reason(reason: str) -> str:
    # OpenAI-style finish_reason → neutral stop_reason.
    if reason == "tool_calls":
        return "tool_use"
    if reason == "length":
        return "max_tokens"
    if reason == "stop":
        return "end_turn"
    return "other"


def _normalize_usage(raw_usage: Any) -> dict[str, Any]:
    """Convert Azure / OpenAI-style `usage` into the canonical usage shape.

    Azure returns `prompt_tokens` as the TOTAL input (including any tokens
    served from cache). Cache hits are reported in `prompt_tokens_details.
    cached_tokens`. Azure prompt caching is automatic (no client opt-in)
    and there is no per-request cache-write notion, so cache_write is always 0.
    See: https://learn.microsoft.com/en-us/azure/ai-foundry/openai/how-to/prompt-caching
    """
    if raw_usage is None:
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_input_tokens": 0,
            "cache_write_input_tokens": 0,
            "total_input_tokens": 0,
            "provider": "azure",
        }
    total_input = int(_attr(raw_usage, "prompt_tokens", 0) or 0)
    output = int(_attr(raw_usage, "completion_tokens", 0) or 0)
    details = _attr(raw_usage, "prompt_tokens_details", None)
    cache_read = int(_attr(details, "cached_tokens", 0) or 0) if details is not None else 0
    uncached_input = max(total_input - cache_read, 0)
    return {
        "input_tokens": uncached_input,
        "output_tokens": output,
        "cache_read_input_tokens": cache_read,
        "cache_write_input_tokens": 0,
        "total_input_tokens": total_input,
        "provider": "azure",
    }


def _parse_arguments(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    import json

    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {"_raw": parsed}
    except Exception:
        return {"_raw": str(raw)}


def _attr(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if hasattr(obj, name):
        return getattr(obj, name)
    if isinstance(obj, dict):
        return obj.get(name, default)
    return default


def _to_dict(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "as_dict"):
        try:
            return obj.as_dict()
        except Exception:  # noqa: BLE001
            pass
    return {"_repr": repr(obj)}


def _model_info_to_dict(info: Any) -> dict[str, Any]:
    if info is None:
        return {}
    if isinstance(info, dict):
        return info
    return {
        "model_name": _attr(info, "model_name", None),
        "model_provider": _attr(info, "model_provider_name", None),
        "model_type": _attr(info, "model_type", None),
    }


def _is_openai_model(model_id: str) -> bool:
    """Return True if the model uses OpenAI-style parameters (max_completion_tokens)."""
    m = model_id.lower()
    return m.startswith(("gpt-", "o1", "o3", "o4"))


def _raise_translated(err: Any) -> None:
    status = getattr(err, "status_code", None) or getattr(err, "response", None)
    code = status.status_code if hasattr(status, "status_code") else status
    msg = str(err)

    if code == 429:
        raise RateLimitError(
            message=f"Azure rate limit exceeded: {msg}",
            retry_after=60,
            details=f"Status: {code}",
        )
    if code in (401, 403):
        raise AuthenticationError(
            message=f"Azure authentication failed: {msg}",
            details=f"Status: {code}. Check Managed Identity role assignment.",
        )
    raise ProviderError(
        message=f"Azure API error: {msg}",
        provider="azure",
        details=f"Status: {code}",
    )
