"""MSSQL App+DB Job 3 filenames and rule id prefixes."""

FINDINGS_JAVA_MSSQL = "Java-MSSQL-dependency.json"
FINDINGS_CSHARP_MSSQL = "CSharp-MSSQL-dependency.json"

RULES_JAVA_MSSQL = "java-mssql-remediation-kb.json"
RULES_CSHARP_MSSQL = "csharp-mssql-remediation-kb.json"

RULE_PREFIX_JAVA = "sql-java-"
RULE_PREFIX_CSHARP = "sql-csharp-"
