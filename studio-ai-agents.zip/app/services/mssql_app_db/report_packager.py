"""MSSQL App+DB post-transformation report (wraps Oracle packager, MSSQL labels)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.services.mssql_app_db.source_profile import language_profile_label, SOURCE_MSSQL
from app.services.oracle_pg.app_db_change import report_packager as oracle_report


def _mssql_summary_text(
    app_label: str,
    pathway: str,
    profile: str,
    violations_found: int,
    violations_resolved: int,
    files_with_violation_fix: int,
    pg_compat_changes: int,
    compat_files: int,
) -> str:
    name = app_label or "the application"
    if violations_found > 0:
        return (
            f"The automated App-DB dependency transformation of {name} for the {pathway} pathway "
            f"concluded with resolution of {violations_resolved} {profile} dependency violations "
            f"across {files_with_violation_fix} files, with {pg_compat_changes} additional PostgreSQL "
            f"compatibility changes applied."
        )
    return (
        f"The automated App-DB dependency transformation of {name} completed with "
        f"no {profile} violations in scope. PostgreSQL compatibility changes were applied "
        f"across {compat_files} files."
    )


def build_post_transformation_report(
    *,
    transformation_id: str,
    app_id: str,
    db_id: str,
    pathway: str,
    nfs_mount_path: str,
    app_name: Optional[str] = None,
    db_name: Optional[str] = None,
    source_database_version: Optional[str] = None,
    pg_version: str = "15.0",
    project_type: str = "java",
    schema_file_path: Optional[str] = None,
    overall_status: str = "COMPLETED",
    files_scanned: int = 0,
    violations_found: int = 0,
    skipped_targets: int = 0,
    applied_changes: Optional[List[Dict[str, Any]]] = None,
    violation_outcomes: Optional[List[Dict[str, Any]]] = None,
    compat_applied: Optional[List[Dict[str, Any]]] = None,
    cicd_findings: Optional[List[str]] = None,
    timing: Optional[Dict[str, Any]] = None,
    target_branch: Optional[str] = None,
    repository_url: Optional[str] = None,
) -> Dict[str, Any]:
    profile = language_profile_label(SOURCE_MSSQL, project_type)
    report = oracle_report.build_post_transformation_report(
        transformation_id=transformation_id,
        app_id=app_id,
        db_id=db_id,
        pathway=pathway,
        nfs_mount_path=nfs_mount_path,
        app_name=app_name,
        db_name=db_name,
        oracle_version=source_database_version,
        pg_version=pg_version,
        project_type=project_type,
        schema_file_path=schema_file_path,
        overall_status=overall_status,
        files_scanned=files_scanned,
        violations_found=violations_found,
        skipped_targets=skipped_targets,
        applied_changes=applied_changes,
        violation_outcomes=violation_outcomes,
        compat_applied=compat_applied,
        cicd_findings=cicd_findings,
        timing=timing,
        target_branch=target_branch,
        repository_url=repository_url,
    )
    app_label = app_name or app_id
    exec_summary = report.get("executiveSummary") or {}
    violations_resolved = int(exec_summary.get("violationsResolved") or 0)
    files_modified = int(exec_summary.get("filesModified") or 0)
    compat_applied = compat_applied or []
    pg_compat_changes = len(compat_applied)
    compat_files = len({str(c.get("file") or "") for c in compat_applied if c.get("file")})
    summary_text = _mssql_summary_text(
        app_label,
        pathway,
        profile,
        violations_found,
        violations_resolved,
        files_modified,
        pg_compat_changes,
        compat_files,
    )

    rules_table = report.get("rulesTable") or {}
    rules_table["subHeading"] = f"Code changes by applied {profile} dependency rules"
    report["rulesTable"] = rules_table
    metadata = report.get("metadata") or {}
    metadata["sourceDatabase"] = "Microsoft SQL Server"
    metadata["languageProfile"] = profile
    report["metadata"] = metadata
    summary = report.get("summary") or {}
    if isinstance(summary, dict):
        summary["sourceDialect"] = SOURCE_MSSQL
    report["summary"] = summary
    report["summaryText"] = summary_text
    if isinstance(report.get("transformationSummary"), dict):
        report["transformationSummary"]["summaryLine"] = summary_text
    if isinstance(exec_summary, dict):
        exec_summary["description"] = summary_text
        report["executiveSummary"] = exec_summary
    return report


write_post_transformation_report = oracle_report.write_post_transformation_report
finalize_report_timing = oracle_report.finalize_report_timing
load_report = oracle_report.load_report
resolve_report = oracle_report.resolve_report
resolve_report_location = oracle_report.resolve_report_location
REPORT_FILENAME = oracle_report.REPORT_FILENAME
