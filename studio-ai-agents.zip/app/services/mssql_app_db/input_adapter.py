"""MSSQL App+DB: findings × remediation KB → dependency plan."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.services.mssql_app_db.source_profile import (
    SOURCE_MSSQL,
    language_profile_label,
    normalize_project_type,
    normalize_rule_scope,
)
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.input_adapter import (
    STATUS_FAILED,
    STATUS_PENDING,
    _first,
    _pick_default_remediation,
    flatten_dependency_findings,
    load_json_file,
)

logger = logging.getLogger(__name__)

PLAN_VERSION = "1.0"
_HIGH_IMPACT_SEVERITIES = frozenset({"critical", "high"})

_EMPTY_SCOPE_MESSAGE = (
    "No violations found in scope. Transformation will apply baseline "
    "PostgreSQL compatibility changes only."
)


def _normalize_rule_row(item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    rule_id = _first(item.get("ruleId"), item.get("rule_id"))
    if not rule_id:
        return None
    rem = _pick_default_remediation(item.get("remediations") or item.get("remediation"))
    severity = _first(item.get("severity"), item.get("impactLevel"), item.get("impact_level"))
    return {
        "ruleId": str(rule_id),
        "ruleName": _first(item.get("ruleName"), item.get("rule_name")),
        "category": _first(item.get("category"), "unknown"),
        "description": item.get("description"),
        "severity": str(severity).lower() if severity is not None else None,
        "remediationId": (rem or {}).get("remediationId") or (rem or {}).get("remediation_id"),
        "remediationText": _first(
            (rem or {}).get("detailedDescription"),
            (rem or {}).get("description"),
            item.get("description"),
        ),
        "oldCode": _first((rem or {}).get("oldCode"), (rem or {}).get("old_code")),
        "newCode": _first((rem or {}).get("newCode"), (rem or {}).get("new_code")),
    }


def load_mssql_remediation_catalog(path: Path) -> Dict[str, Dict[str, Any]]:
    """Load Java-MSSQL or C#-MSSQL KB keyed by ruleId (rules array or flat list)."""
    data = load_json_file(path)
    rules_raw: Any = None
    if isinstance(data, dict):
        rules_raw = data.get("rules")
    if rules_raw is None and isinstance(data, list):
        rules_raw = data
    if not isinstance(rules_raw, list):
        raise ValueError("rulesRemediation file must contain a rules array or a JSON list")

    catalog: Dict[str, Dict[str, Any]] = {}
    for item in rules_raw:
        if not isinstance(item, dict):
            continue
        row = _normalize_rule_row(item)
        if row:
            catalog[row["ruleId"]] = row
    return catalog


def filter_catalog_by_rule_scope(
    catalog: Dict[str, Dict[str, Any]],
    rule_scope: str,
    selected_rules: Optional[List[str]] = None,
) -> Dict[str, Dict[str, Any]]:
    scope = normalize_rule_scope(rule_scope)
    if scope == "all":
        return dict(catalog)
    if scope == "high_impact":
        return {
            rid: meta
            for rid, meta in catalog.items()
            if (meta.get("severity") or "").lower() in _HIGH_IMPACT_SEVERITIES
        }
    selected = {str(r) for r in (selected_rules or []) if r}
    return {rid: meta for rid, meta in catalog.items() if rid in selected}


def build_dependency_resolution_plan(
    *,
    findings_path: Path,
    catalog_path: Path,
    app_id: str,
    db_id: str,
    pathway: str = "M-Upgrade",
    project_path: Optional[str] = None,
    project_type: str = "java",
    rule_scope: str = "all",
    selected_rules: Optional[List[str]] = None,
) -> Dict[str, Any]:
    findings_data = load_json_file(findings_path)
    full_catalog = load_mssql_remediation_catalog(catalog_path)
    catalog = filter_catalog_by_rule_scope(full_catalog, rule_scope, selected_rules)
    findings = flatten_dependency_findings(findings_data)

    violations: List[Dict[str, Any]] = []
    warnings: List[str] = []

    for finding in findings:
        rule_id = finding.get("ruleId")
        if not rule_id:
            warnings.append("Skipped finding with no ruleId")
            continue
        rule_key = str(rule_id)
        if rule_key not in catalog:
            warnings.append(f"Skipped finding for unselected ruleId={rule_key}")
            continue
        meta = catalog[rule_key]
        file_path = finding.get("file")
        status = STATUS_PENDING
        reason = None
        if not file_path:
            status = STATUS_FAILED
            reason = "No affected file specified — manual review required"
            warnings.append(f"{rule_id}: {reason}")

        violations.append(
            {
                "violationId": finding.get("violationId"),
                "ruleId": str(rule_id),
                "ruleName": (meta or {}).get("ruleName"),
                "category": (meta or {}).get("category") or "unknown",
                "file": file_path,
                "lines": list(finding.get("lines") or []),
                "beginLine": finding.get("beginLine"),
                "endLine": finding.get("endLine"),
                "status": status,
                "reason": reason,
                "remediationId": (meta or {}).get("remediationId"),
                "remediationText": (meta or {}).get("remediationText"),
                "oldCode": (meta or {}).get("oldCode"),
                "newCode": (meta or {}).get("newCode"),
            }
        )

    in_scope = [v for v in violations if v.get("status") == STATUS_PENDING]
    empty_message = None
    if not in_scope:
        empty_message = (
            _EMPTY_SCOPE_MESSAGE
            if not findings
            else "No actionable violations in scope (missing files or KB entries)."
        )

    project = normalize_project_type(project_type)
    plan = {
        "planVersion": PLAN_VERSION,
        "sourceDialect": SOURCE_MSSQL,
        "projectType": project,
        "languageProfile": language_profile_label(SOURCE_MSSQL, project),
        "appId": app_id,
        "dbId": db_id,
        "pathway": pathway,
        "projectPath": project_path,
        "ruleScope": normalize_rule_scope(rule_scope),
        "selectedRules": list(selected_rules or []),
        "summary": {
            "totalFindings": len(findings),
            "findingsInScope": len(in_scope),
            "rulesInCatalog": len(catalog),
            "emptyScopeMessage": empty_message,
        },
        "violations": violations,
        "catalogSubset": {
            "rules": [
                catalog[rid]
                for rid in sorted({str(v["ruleId"]) for v in violations if v.get("ruleId") in catalog})
            ]
        },
        "assemblyWarnings": warnings,
    }
    return plan


def write_dependency_resolution_plan(db_id: str, plan: Dict[str, Any]) -> Path:
    ws.ensure_reports_dir(db_id)
    path = ws.plan_path(db_id)
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return path


def load_dependency_resolution_plan(db_id: str) -> Optional[Dict[str, Any]]:
    path = ws.plan_path(db_id)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        logger.warning("Unreadable dependency-resolution-plan.json: %s", path)
        return None
    return data if isinstance(data, dict) else None


def build_and_write_plan(
    *,
    db_id: str,
    app_id: str,
    findings_path: Path,
    catalog_path: Path,
    pathway: str = "M-Upgrade",
    project_path: Optional[str] = None,
    project_type: str = "java",
    rule_scope: str = "all",
    selected_rules: Optional[List[str]] = None,
) -> Tuple[Dict[str, Any], Path]:
    plan = build_dependency_resolution_plan(
        findings_path=findings_path,
        catalog_path=catalog_path,
        app_id=app_id,
        db_id=db_id,
        pathway=pathway,
        project_path=project_path,
        project_type=project_type,
        rule_scope=rule_scope,
        selected_rules=selected_rules,
    )
    path = write_dependency_resolution_plan(db_id, plan)
    return plan, path
