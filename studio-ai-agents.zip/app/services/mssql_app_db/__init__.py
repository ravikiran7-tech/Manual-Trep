"""App+DB Job 3 for MSSQL → PostgreSQL (Java and C#).

Uses the same NFS layout and HTTP contract as Oracle-Java Job 3; implementation
is isolated from ``oracle_pg.app_db_change``.
"""
