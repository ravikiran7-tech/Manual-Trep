"""App+DB API facade: Oracle contract; MSSQL engine chosen from staged ``_claude/`` inputs."""

from __future__ import annotations

from typing import Any, Dict, Optional

from app.services.mssql_app_db.infer_launch import ENGINE_MSSQL, infer_engine_for_db, infer_engine_for_launch
from app.services.mssql_app_db.job_manager import get_mssql_app_db_job_manager
from app.services.mssql_app_db.routing import resolve_transformation_id
from app.services.mssql_app_db import report_packager as mssql_report
from app.services.mssql_app_db import rules_api
from app.services.oracle_pg.app_db_change.job_manager import get_app_db_job_manager
from app.services.oracle_pg.app_db_change.progress_tracker import (
    db_id_for_job,
    get_progress_tracker,
    is_job_terminal_on_disk,
    job_dir,
)
from app.services.oracle_pg.app_db_change.report_packager import (
    load_report as oracle_load_report,
    resolve_report as oracle_resolve_report,
    resolve_report_location as oracle_resolve_report_location,
)


def resolve_job_id(candidate: str) -> Optional[str]:
    return resolve_transformation_id(candidate)


def tracker_for(transformation_id: str):
    return get_progress_tracker()


def db_id_for_transformation(transformation_id: str) -> Optional[str]:
    return db_id_for_job(transformation_id)


def events_job_dir(transformation_id: str):
    return job_dir(transformation_id)


def is_terminal_on_disk(transformation_id: str) -> bool:
    if is_job_terminal_on_disk(transformation_id):
        return True
    return get_progress_tracker().is_terminal(transformation_id)


def _mssql_job(db_id: str) -> bool:
    return infer_engine_for_db(db_id) == ENGINE_MSSQL


def load_report_for(transformation_id: str) -> Optional[Dict[str, Any]]:
    db_id = db_id_for_job(transformation_id)
    if db_id and _mssql_job(db_id):
        return mssql_report.load_report(transformation_id)
    return oracle_load_report(transformation_id)


def resolve_report_for(
    *,
    app_id: str,
    db_id: str,
    transformation_id: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    if _mssql_job(db_id):
        return mssql_report.resolve_report(
            app_id=app_id, db_id=db_id, transformation_id=transformation_id
        )
    return oracle_resolve_report(
        app_id=app_id, db_id=db_id, transformation_id=transformation_id
    )


def resolve_report_location_for(
    *,
    app_id: str,
    db_id: str,
    transformation_id: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    if _mssql_job(db_id):
        return mssql_report.resolve_report_location(
            app_id=app_id, db_id=db_id, transformation_id=transformation_id
        )
    return oracle_resolve_report_location(
        app_id=app_id, db_id=db_id, transformation_id=transformation_id
    )


def active_job_for_app_db(*, app_id: str, db_id: str) -> Optional[str]:
    return get_progress_tracker().find_active_job(app_id=app_id, db_id=db_id)


def total_active_jobs() -> int:
    return get_progress_tracker().count_active()


async def launch_app_db(request: Dict[str, Any]) -> Dict[str, Any]:
    if infer_engine_for_launch(request) == ENGINE_MSSQL:
        return await get_mssql_app_db_job_manager().launch(request)
    return await get_app_db_job_manager().launch(request)


async def approve_and_run(db_id: str) -> None:
    if _mssql_job(db_id):
        await get_mssql_app_db_job_manager().approve_and_run(db_id)
        return
    await get_app_db_job_manager()._enqueue(db_id)


def list_rules_from_catalog(catalog_path, *, language: str = "java"):
    return rules_api.list_rules_from_catalog(catalog_path, language=language)


def filter_rules(rules, *, mode: str, selected_rule_ids=None):
    return rules_api.filter_rules(rules, mode=mode, selected_rule_ids=selected_rule_ids)


def engine_for_db(db_id: str) -> str:
    return infer_engine_for_db(db_id)
