"""Job 3 may start only after Job 2 (schema) completed for this dbId."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Tuple

from app.core.config import get_settings
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.workspace import MODERNIZATION_SUBDIR

_JOB2_COMPLETE = frozenset({"COMPLETED", "completed", "SUCCESS", "success", "Complete"})
_SCHEMA_PROGRESS_SUCCESS = frozenset(
    {"completed", "completed_with_warnings", "success", "complete"}
)


def _read_schema_job_status(db_id: str) -> dict:
    path = ws.reports_dir(db_id) / "schema_job_status.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _schema_modernization_progress(db_id: str) -> dict:
    """Job 2 (MSSQL/Oracle PG) writes ``schema-modernization/{dbId}/state/progress.json``."""
    path = (
        Path(get_settings().claude_workspace)
        / MODERNIZATION_SUBDIR
        / db_id
        / "state"
        / "progress.json"
    )
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _status_from_schema_file(state: dict) -> Optional[str]:
    if not state:
        return None
    for key in ("job2Status", "status", "overallStatus", "jobStatus"):
        value = state.get(key)
        if value is not None and str(value).strip():
            return str(value)
    return None


def job2_completed_for_db(db_id: str) -> Tuple[bool, Optional[str]]:
    state = _read_schema_job_status(db_id)
    status = _status_from_schema_file(state)
    if status in _JOB2_COMPLETE:
        return True, None

    progress = _schema_modernization_progress(db_id)
    prog_status = str(progress.get("status") or "").strip()
    if prog_status.lower() in _SCHEMA_PROGRESS_SUCCESS:
        return True, None

    if not state and not progress:
        return (
            False,
            f"Job 2 (schema transformation) must complete before App+DB launch for dbId={db_id}; "
            "schema_job_status.json not found or not completed",
        )
    if state and status not in _JOB2_COMPLETE:
        return (
            False,
            f"Job 2 (schema transformation) must complete before App+DB launch for dbId={db_id}; "
            f"current status={status!r}",
        )
    if progress and prog_status.lower() not in _SCHEMA_PROGRESS_SUCCESS:
        return (
            False,
            f"Job 2 (schema transformation) must complete before App+DB launch for dbId={db_id}; "
            f"current schema job status={prog_status!r}",
        )
    return (
        False,
        f"Job 2 (schema transformation) must complete before App+DB launch for dbId={db_id}; "
        "schema_job_status.json not found or not completed",
    )
