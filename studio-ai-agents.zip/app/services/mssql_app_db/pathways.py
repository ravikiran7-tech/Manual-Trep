"""MSSQL App+DB pathway compatibility scope."""

from __future__ import annotations

from app.services.mssql_app_db.source_profile import PROJECT_CSHARP, PROJECT_JAVA, normalize_project_type
from app.services.oracle_pg.app_db_change.pathways import (
    PATHWAY_BASIC,
    PATHWAY_CONTAINER,
    PATHWAY_UPGRADE,
    normalize_pathway,
)


def normalize_mssql_pathway(pathway: str) -> str:
    """Normalize Studio pathway labels (e.g. ``M-Container-Mono + DB-Modernize``)."""
    text = (pathway or PATHWAY_UPGRADE).strip()
    if "+" in text:
        text = text.split("+", 1)[0].strip()
    return normalize_pathway(text)


def mssql_compatibility_instructions(pathway: str, project_type: str) -> str:
    """Pathway extras for MSSQL → PostgreSQL. M-Upgrade returns an empty string."""
    normalized = normalize_mssql_pathway(pathway)
    if normalized not in {PATHWAY_BASIC, PATHWAY_CONTAINER}:
        return ""

    project = normalize_project_type(project_type)
    if project == PROJECT_CSHARP:
        scope = (
            "Edit every pending violation file first, including Migrations and Models. "
            "DboSchemaUsage, LinqToSqlQueryUsage, and SqlClientNamespaceImport are not "
            "done by appsettings or csproj edits. After those violation files are updated, "
            "inspect existing appsettings*.json, *.csproj, and Program.cs / Startup.cs. "
            "Replace Microsoft.Data.SqlClient / System.Data.SqlClient with Npgsql, "
            "UseSqlServer() with UseNpgsql(), and SQL Server connection strings with "
            "PostgreSQL placeholders. Remove MSSQL-specific health-check SQL; use "
            "PostgreSQL-compatible SELECT 1. Do not create missing files."
        )
    else:
        scope = (
            "You MUST inspect every existing application*.properties/yml/yaml, pom.xml, "
            "build.gradle/build.gradle.kts, and persistence.xml. Replace MSSQL JDBC URLs "
            "(sqlserver://, jTDS, com.microsoft.sqlserver.jdbc.SQLServerDriver, "
            "net.sourceforge.jtds.jdbc.Driver), mssql-jdbc or jTDS dependency, Hibernate/JPA "
            "dialect, and connection pool settings with PostgreSQL equivalents. "
            "Remove com.microsoft.sqlserver:mssql-jdbc and net.sourceforge.jtds:jtds and add "
            "org.postgresql:postgresql (latest stable). "
            "Flag MSSQL-specific ORM annotations or named queries for manual review. "
            "If MSSQL connection pooling is configured, replace it with HikariCP where applicable."
        )

    if normalized == PATHWAY_CONTAINER:
        scope += (
            " After every violation file has been saved, also inspect existing Dockerfile, "
            "docker-compose*.yml/yaml, and Kubernetes manifests under k8s/ or kubernetes/. "
            "Replace MSSQL JDBC or SQL Server images, URLs, drivers, environment variables, "
            "and health checks with PostgreSQL equivalents. Replace an MSSQL database service "
            "with a PostgreSQL service using image postgres:15 with POSTGRES_* placeholders. "
            "Do not edit CI/CD pipeline files; flag MSSQL driver references for manual review. "
            "Dockerfile and compose edits do not resolve DboSchemaUsage or SqlClientNamespaceImport."
        )
    return scope


def compatibility_instructions(pathway: str, project_type: str = PROJECT_JAVA) -> str:
    return mssql_compatibility_instructions(pathway, project_type)


def compatibility_change_reason(
    file_path: str,
    pathway: str,
    project_type: str = PROJECT_JAVA,
) -> str | None:
    normalized = normalize_mssql_pathway(pathway)
    if normalized not in {PATHWAY_BASIC, PATHWAY_CONTAINER}:
        return None

    project = normalize_project_type(project_type)
    posix = file_path.replace("\\", "/").lower()
    name = posix.rsplit("/", 1)[-1]

    if project == PROJECT_CSHARP:
        if name.startswith("appsettings") and name.endswith(".json"):
            return "PostgreSQL connection string / EF configuration update"
        if name.endswith(".csproj"):
            return "Npgsql NuGet package replacement"
        if name.endswith(".cs") and any(
            part in {"program.cs", "startup.cs"} for part in (name,)
        ):
            return "PostgreSQL EF / hosting configuration update"
    else:
        if name.startswith("application") and name.endswith((".properties", ".yml", ".yaml")):
            return "PostgreSQL datasource configuration update"
        if name in {"pom.xml", "build.gradle", "build.gradle.kts"}:
            return "PostgreSQL JDBC driver replacement"
        if name == "persistence.xml":
            return "PostgreSQL ORM / persistence configuration update"

    if normalized != PATHWAY_CONTAINER:
        return None
    if name == "dockerfile":
        return "Dockerfile PostgreSQL update"
    if name.startswith("docker-compose") and name.endswith((".yml", ".yaml")):
        return "Docker Compose PostgreSQL update"
    if name.endswith((".yml", ".yaml")) and any(
        part in {"k8s", "kubernetes"} for part in posix.split("/")
    ):
        return "Kubernetes manifest PostgreSQL update"
    return None
