"""MSSQL rules list / filter for Rules Selection API."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.mssql_app_db.constants import RULE_PREFIX_CSHARP, RULE_PREFIX_JAVA
from app.services.mssql_app_db.input_adapter import load_mssql_remediation_catalog
from app.services.mssql_app_db.source_profile import (
    PROJECT_CSHARP,
    normalize_project_type,
    SOURCE_MSSQL,
)

_HIGH_IMPACT = frozenset({"critical", "high"})


def _rule_row(rule_id: str, meta: Dict[str, Any]) -> Dict[str, Any]:
    rid = str(meta.get("ruleId") or rule_id)
    impact = str(meta.get("impactLevel") or meta.get("severity") or "moderate").lower()
    return {
        "id": rid,
        "name": meta.get("ruleName") or rule_id,
        "description": meta.get("description") or meta.get("ruleDescription") or "",
        "category": meta.get("category") or "unknown",
        "impactLevel": impact.title() if impact else "Moderate",
    }


def list_rules_from_catalog(catalog_path: Path, *, language: str = "java") -> List[Dict[str, Any]]:
    project = normalize_project_type(language)
    prefix = RULE_PREFIX_CSHARP if project == PROJECT_CSHARP else RULE_PREFIX_JAVA
    catalog = load_mssql_remediation_catalog(catalog_path)
    rows = []
    unmatched = []
    for rule_id, meta in sorted(catalog.items()):
        row = _rule_row(str(rule_id), meta or {})
        if str(rule_id).startswith(prefix):
            rows.append(row)
        else:
            unmatched.append(row)
    # A KB discovered by content may use a rule-id shape other than sql-java- / sql-csharp-.
    return rows or unmatched


def filter_rules(
    rules: List[Dict[str, Any]],
    *,
    mode: str,
    selected_rule_ids: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    mode_key = (mode or "apply_all").strip().lower().replace("-", "_")
    if mode_key in ("apply_all", "all"):
        return list(rules)
    if mode_key in ("high_impact_only", "high_impact"):
        return [r for r in rules if str(r.get("impactLevel") or "").lower() in _HIGH_IMPACT]
    if mode_key == "customize":
        selected = {str(r) for r in (selected_rule_ids or []) if r}
        return [r for r in rules if r.get("id") in selected]
    return list(rules)


def load_catalog_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
