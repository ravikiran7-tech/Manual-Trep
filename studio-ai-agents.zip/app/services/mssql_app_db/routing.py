"""Launch/read routing — same job resolution as Oracle App+DB."""

from __future__ import annotations

from typing import Optional

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.progress_tracker import (
    ProgressTracker,
    get_progress_tracker,
)


def resolve_transformation_id(candidate: str) -> Optional[str]:
    """Map appId / dbId / APPDB-… to transformation id (Oracle tracker + disk)."""
    key = (candidate or "").strip()
    if not key:
        return None
    tracker = get_progress_tracker()
    resolved = tracker.resolve_job_id(key)
    if resolved:
        return resolved
    folder = ws.find_db_id(transformation_id=key, app_id=key, db_id=key)
    if not folder:
        return None
    state = ws.read_state(folder)
    if not state:
        return None
    tid = str(state.get("transformation_id") or "").strip()
    return tid or None


def get_tracker_for_transformation(_transformation_id: str) -> ProgressTracker:
    return get_progress_tracker()
