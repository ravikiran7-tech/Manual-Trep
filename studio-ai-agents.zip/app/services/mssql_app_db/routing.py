"""Launch/read routing — same job resolution as Oracle App+DB."""

from __future__ import annotations

import json
from typing import Optional

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.progress_tracker import (
    ProgressTracker,
    get_progress_tracker,
    register_job_db_id,
)


def _transformation_from_saved_config(candidate: str) -> Optional[str]:
    """Find a finished job by appId when this worker never held it in memory.

    The studio polls logs with the application id. Another replica, or a
    process restarted after the run, still has ``job_config.json`` on the
    shared workspace even when its in-memory tracker is empty.
    """
    root = ws.jobs_base()
    if not root.is_dir():
        return None
    fields = ("appId", "jobId", "transformationId", "dbId", "app_id", "db_id")
    for folder in root.iterdir():
        if not folder.is_dir():
            continue
        for name in (ws.JOB_CONFIG_FILENAME, ws.REQUEST_FILENAME):
            path = folder / "reports" / name
            if not path.is_file():
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict):
                continue
            values = {str(data.get(field) or "").strip() for field in fields}
            if candidate not in values:
                continue
            tid = str(data.get("transformationId") or data.get("transformation_id") or "").strip()
            if not tid:
                state = ws.read_state(folder.name)
                tid = str((state or {}).get("transformation_id") or "").strip()
            if not tid:
                continue
            register_job_db_id(tid, folder.name)
            return tid
    return None


def resolve_transformation_id(candidate: str) -> Optional[str]:
    """Map appId / dbId / APPDB-… to transformation id (Oracle tracker + disk)."""
    key = (candidate or "").strip()
    if not key:
        return None
    tracker = get_progress_tracker()
    resolved = tracker.resolve_job_id(key)
    if resolved:
        return resolved
    folder = ws.find_db_id(transformation_id=key, app_id=key, db_id=key)
    if folder:
        state = ws.read_state(folder)
        if state:
            tid = str(state.get("transformation_id") or "").strip()
            if tid:
                register_job_db_id(tid, folder)
                return tid
    return _transformation_from_saved_config(key)


def get_tracker_for_transformation(_transformation_id: str) -> ProgressTracker:
    return get_progress_tracker()
