"""Checkout scanning for MSSQL App+DB (Java and C#)."""

from __future__ import annotations

from pathlib import Path
from typing import List

from app.services.mssql_app_db.source_profile import PROJECT_CSHARP, normalize_project_type
from app.services.oracle_pg.app_db_change.file_ops import SKIP_DIR_NAMES, diff_snapshot, relative_to_root

JAVA_GLOBS = (
    "**/*.java",
    "**/*.xml",
    "**/*.properties",
    "**/*.yml",
    "**/*.yaml",
    "**/*.sql",
    "**/Dockerfile",
    "**/build.gradle",
    "**/build.gradle.kts",
)

CSHARP_GLOBS = (
    "**/*.cs",
    "**/*.csproj",
    "**/appsettings*.json",
    "**/*.json",
    "**/*.yml",
    "**/*.yaml",
    "**/Dockerfile",
    "**/docker-compose*.yml",
    "**/docker-compose*.yaml",
)


def scan_globs_for_project(project_type: str) -> tuple[str, ...]:
    if normalize_project_type(project_type) == PROJECT_CSHARP:
        return CSHARP_GLOBS
    return JAVA_GLOBS


def scan_codebase(location: str, *, project_type: str = "java") -> List[Path]:
    root = Path(location)
    if not root.exists():
        return []
    found: List[Path] = []
    for pattern in scan_globs_for_project(project_type):
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            if path.name.endswith(".bak"):
                continue
            found.append(path)
    return sorted(set(found), key=lambda p: str(p).replace("\\", "/"))


def snapshot_files(location: str, *, project_type: str = "java") -> dict:
    root = Path(location)
    snapshot: dict = {}
    for path in scan_codebase(location, project_type=project_type):
        try:
            stat = path.stat()
        except OSError:
            continue
        snapshot[relative_to_root(path, root)] = (stat.st_mtime, stat.st_size)
    return snapshot


__all__ = [
    "scan_codebase",
    "scan_globs_for_project",
    "relative_to_root",
    "snapshot_files",
    "diff_snapshot",
]
