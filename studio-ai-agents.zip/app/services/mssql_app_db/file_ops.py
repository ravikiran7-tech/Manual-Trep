"""Checkout scanning for MSSQL App+DB (Java and C#)."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.mssql_app_db.source_profile import PROJECT_CSHARP, normalize_project_type
from app.services.oracle_pg.app_db_change.file_ops import SKIP_DIR_NAMES, diff_snapshot, relative_to_root

JAVA_GLOBS = (
    "**/*.java",
    "**/*.xml",
    "**/*.properties",
    "**/*.yml",
    "**/*.yaml",
    "**/*.sql",
    "**/Dockerfile",
    "**/build.gradle",
    "**/build.gradle.kts",
)

CSHARP_GLOBS = (
    "**/*.cs",
    "**/*.csproj",
    "**/appsettings*.json",
    "**/*.json",
    "**/*.yml",
    "**/*.yaml",
    "**/Dockerfile",
    "**/docker-compose*.yml",
    "**/docker-compose*.yaml",
)


def _studio_component_tail(raw: str) -> Optional[str]:
    """Path after ``studio-workspace/<component>/``.

    Scan rows often store
    ``APP901193/transformed-code/183/studio-workspace/MupCShapp/ContosoUniversity/Models/Department.cs``
    while the checkout file is ``ContosoUniversity/Models/Department.cs``.
    """
    parts = [part for part in raw.replace("\\", "/").split("/") if part and part != "."]
    if "studio-workspace" not in parts:
        return None
    rest = parts[parts.index("studio-workspace") + 2 :]
    return "/".join(rest) if rest else None


def _path_suffix_tails(raw: str) -> List[str]:
    """Longest-first path tails (for scan absolute paths → checkout-relative)."""
    parts = [p for p in raw.replace("\\", "/").split("/") if p and p != "."]
    if not parts:
        return []
    return ["/".join(parts[i:]) for i in range(len(parts))]


def _shared_suffix_len(relative: str, planned: str) -> int:
    left = [part for part in relative.replace("\\", "/").split("/") if part]
    right = [part for part in planned.replace("\\", "/").split("/") if part]
    shared = 0
    for found, scanned in zip(reversed(left), reversed(right)):
        if found != scanned:
            break
        shared += 1
    return shared


def resolve_plan_file_under_checkout(checkout: Path, plan_file: str) -> Optional[str]:
    """Return a checkout-relative path when the plan file exists (suffix-tolerant).

    Scan payloads often store
    ``modernize-data/.../sourcecode/.../ContosoUniversity/Models/Student.cs``
    while the checkout file is ``ContosoUniversity/Models/Student.cs`` or sits
    one directory deeper. The longest shared suffix wins when it is unique.
    """
    raw = str(plan_file or "").strip().replace("\\", "/")
    if not raw or not checkout.is_dir():
        return None
    component_tail = _studio_component_tail(raw)
    if component_tail:
        hit = _casefold_relative(checkout, component_tail)
        if hit is not None and hit.is_file():
            try:
                return hit.resolve().relative_to(checkout.resolve()).as_posix()
            except ValueError:
                return component_tail
    direct = checkout / raw.lstrip("/")
    if direct.is_file():
        try:
            return direct.resolve().relative_to(checkout.resolve()).as_posix()
        except ValueError:
            return raw.lstrip("/")
    for tail in _path_suffix_tails(raw):
        candidate = checkout / tail
        if candidate.is_file():
            return tail
    name = Path(raw).name
    if not name or name in {".", ".."}:
        return None
    scored: List[tuple[int, str]] = []
    for path in checkout.rglob(name):
        if not path.is_file():
            continue
        if any(part in SKIP_DIR_NAMES for part in path.parts):
            continue
        try:
            rel = path.relative_to(checkout.resolve()).as_posix()
        except ValueError:
            continue
        shared = _shared_suffix_len(rel, raw)
        if shared < 1:
            continue
        scored.append((shared, rel))
    if not scored:
        return None
    best = max(score for score, _rel in scored)
    # Identical names in two folders stay unresolved. A longer shared directory
    # suffix (Models/Student.cs and beyond) identifies the scan file.
    if best == 1:
        names = {rel for score, rel in scored if score == best}
        if len(names) == 1 and len(scored) == 1:
            return names.pop()
        return None
    top = [rel for score, rel in scored if score == best]
    if len(set(top)) == 1:
        return top[0]
    return None


def matches_plan_file(changed_file: str, plan_file: str, *, checkout: Optional[Path] = None) -> bool:
    """True when a diff path corresponds to a plan violation file."""
    changed = changed_file.replace("\\", "/")
    planned = str(plan_file or "").replace("\\", "/")
    resolved = planned
    if checkout and planned:
        found = resolve_plan_file_under_checkout(checkout, planned)
        if found:
            resolved = found
    if changed == resolved or changed.endswith(resolved) or resolved.endswith(changed):
        return True
    if changed == planned or changed.endswith(planned) or planned.endswith(changed):
        return True
    # The same source file can show up under transformed-code and under
    # sourcecode. A shared directory + filename (Models/Department.cs) is the
    # same violation target; a bare filename is not.
    return _shared_suffix_len(changed, planned) >= 2 or _shared_suffix_len(changed, resolved) >= 2


def plan_file_exists_under_checkout(checkout: Path, plan_file: str) -> bool:
    return resolve_plan_file_under_checkout(checkout, plan_file) is not None


def _casefold_child(directory: Path, name: str) -> Optional[Path]:
    direct = directory / name
    if direct.exists():
        return direct
    target = name.casefold()
    try:
        for child in directory.iterdir():
            if child.name.casefold() == target:
                return child
    except OSError:
        return None
    return None


def _casefold_relative(root: Path, relative: str) -> Optional[Path]:
    current = root
    for part in [part for part in relative.split("/") if part and part != "."]:
        if not current.is_dir():
            return None
        nxt = _casefold_child(current, part)
        if nxt is None:
            return None
        current = nxt
    return current if current.is_file() else None


def checkout_ancestors(checkout: Path, *, limit: int = 8) -> List[Path]:
    """Checkout plus parents, stopping at the app folder or the studio mount."""
    roots: List[Path] = []
    current = checkout.resolve()
    for _ in range(limit):
        roots.append(current)
        if (current / "sourcecode").is_dir() and (current / "transformed-code").is_dir():
            break
        if current.name in {"studio-app", "studio-data"} or current.parent == current:
            break
        current = current.parent
    return roots


def _find_tail_under(base: Path, tails: List[str], *, max_dirs: int = 2500) -> Optional[Path]:
    """Find ``tail`` under ``base``, including nested source folders."""
    if not base.is_dir():
        return None
    skip = SKIP_DIR_NAMES | {"bin", "obj", "packages", "node_modules"}
    stack = [base]
    seen = 0
    while stack:
        directory = stack.pop()
        seen += 1
        if seen > max_dirs:
            break
        for tail in tails:
            direct = directory / tail
            if direct.is_file():
                return direct
            folded = _casefold_relative(directory, tail)
            if folded is not None:
                return folded
        try:
            children = [
                child
                for child in directory.iterdir()
                if child.is_dir() and child.name not in skip and not child.name.startswith(".")
            ]
        except OSError:
            continue
        stack.extend(children)
    return None


def locate_source_file(checkout: Path, plan_file: str) -> Optional[Path]:
    """Absolute path of a plan file under the checkout or the app source tree.

    C# findings are relative (``ContosoUniversity/Migrations/...cs``). Container
    and upgrade checkouts often hold the web project only, while those files
    live under the app ``sourcecode`` tree. The returned path is still inside
    the app folder so the plan can store a relative path.
    """
    if not checkout.is_dir():
        return None
    resolved = resolve_plan_file_under_checkout(checkout, plan_file)
    if resolved:
        return (checkout / resolved).resolve()
    tails = [tail for tail in _path_suffix_tails(plan_file) if "/" in tail]
    if not tails:
        tails = _path_suffix_tails(plan_file)
    for root in checkout_ancestors(checkout)[1:]:
        source = root / "sourcecode"
        bases = [source] if source.is_dir() else [root]
        for base in bases:
            found = _find_tail_under(base, tails)
            if found is not None:
                return found.resolve()
    return None


def anchor_checkout(checkout: Path, plan_files: List[str]) -> tuple[Path, Dict[str, Path]]:
    """Directory that contains the checkout and every located source file."""
    located: Dict[str, Path] = {}
    if not checkout.is_dir():
        return checkout, located
    for raw in plan_files:
        key = str(raw or "").replace("\\", "/").strip()
        if not key or key in located:
            continue
        found = locate_source_file(checkout, key)
        if found is not None:
            located[key] = found
    if not located:
        return checkout.resolve(), located
    base = checkout.resolve()
    try:
        common = Path(os.path.commonpath([str(base), *[str(path.parent) for path in located.values()]]))
    except ValueError:
        return base, located
    try:
        base.relative_to(common)
    except ValueError:
        return base, located
    return common, located


def scan_globs_for_project(project_type: str) -> tuple[str, ...]:
    if normalize_project_type(project_type) == PROJECT_CSHARP:
        return CSHARP_GLOBS
    return JAVA_GLOBS


def scan_codebase(location: str, *, project_type: str = "java") -> List[Path]:
    root = Path(location)
    if not root.exists():
        return []
    found: List[Path] = []
    for pattern in scan_globs_for_project(project_type):
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            if path.name.endswith(".bak"):
                continue
            found.append(path)
    return sorted(set(found), key=lambda p: str(p).replace("\\", "/"))


def snapshot_files(location: str, *, project_type: str = "java") -> dict:
    root = Path(location)
    snapshot: dict = {}
    for path in scan_codebase(location, project_type=project_type):
        try:
            stat = path.stat()
        except OSError:
            continue
        snapshot[relative_to_root(path, root)] = (stat.st_mtime, stat.st_size)
    return snapshot


def _is_scan_absolute_path(path: str) -> bool:
    raw = path.replace("\\", "/")
    return raw.startswith("/") or (len(raw) > 1 and raw[1] == ":")


def normalize_violation_paths_in_plan(plan: Dict[str, Any], checkout: Path) -> List[str]:
    """Map scan paths (C# absolute, Java relative) to checkout-relative ``file`` for Claude."""
    notes: List[str] = []
    if not checkout.is_dir():
        return notes
    for item in plan.get("violations") or []:
        raw = item.get("file")
        if not raw:
            continue
        raw_s = str(raw).replace("\\", "/")
        resolved = resolve_plan_file_under_checkout(checkout, raw_s)
        if not resolved:
            continue
        if resolved != raw_s:
            if _is_scan_absolute_path(raw_s):
                item.setdefault("scanFile", raw_s)
            item["file"] = resolved
            notes.append(f"Remapped violation file to checkout path: {resolved}")
        else:
            item["file"] = resolved
    return notes


__all__ = [
    "matches_plan_file",
    "normalize_violation_paths_in_plan",
    "plan_file_exists_under_checkout",
    "resolve_plan_file_under_checkout",
    "scan_codebase",
    "scan_globs_for_project",
    "relative_to_root",
    "snapshot_files",
    "diff_snapshot",
]
