"""Checkout scanning for MSSQL App+DB (Java and C#)."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.mssql_app_db.source_profile import PROJECT_CSHARP, normalize_project_type
from app.services.oracle_pg.app_db_change.file_ops import SKIP_DIR_NAMES, diff_snapshot, relative_to_root

JAVA_GLOBS = (
    "**/*.java",
    "**/*.xml",
    "**/*.properties",
    "**/*.yml",
    "**/*.yaml",
    "**/*.sql",
    "**/Dockerfile",
    "**/build.gradle",
    "**/build.gradle.kts",
)

CSHARP_GLOBS = (
    "**/*.cs",
    "**/*.csproj",
    "**/appsettings*.json",
    "**/*.json",
    "**/*.yml",
    "**/*.yaml",
    "**/Dockerfile",
    "**/docker-compose*.yml",
    "**/docker-compose*.yaml",
)


def _path_match(relative: str, planned: str) -> bool:
    left = relative.replace("\\", "/")
    right = planned.replace("\\", "/")
    return left == right or left.endswith(right) or right.endswith(left)


def _path_suffix_tails(raw: str) -> List[str]:
    """Longest-first path tails (for scan absolute paths → checkout-relative)."""
    parts = [p for p in raw.replace("\\", "/").split("/") if p and p != "."]
    if not parts:
        return []
    return ["/".join(parts[i:]) for i in range(len(parts))]


def _pick_unique_suffix_match(raw: str, matches: List[str]) -> Optional[str]:
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]
    by_suffix = [m for m in matches if raw.endswith(m)]
    if len(by_suffix) == 1:
        return by_suffix[0]
    if by_suffix:
        return max(by_suffix, key=len)
    return None


def resolve_plan_file_under_checkout(checkout: Path, plan_file: str) -> Optional[str]:
    """Return a checkout-relative path when the plan file exists (suffix-tolerant)."""
    raw = str(plan_file or "").strip().replace("\\", "/")
    if not raw or not checkout.is_dir():
        return None
    direct = checkout / raw
    if direct.is_file():
        return raw.lstrip("/")
    for tail in _path_suffix_tails(raw):
        candidate = checkout / tail
        if candidate.is_file():
            return tail
    name = Path(raw).name
    if not name:
        return None
    matches: List[str] = []
    for path in checkout.rglob(name):
        if not path.is_file():
            continue
        if any(part in SKIP_DIR_NAMES for part in path.parts):
            continue
        try:
            rel = path.relative_to(checkout.resolve()).as_posix()
        except ValueError:
            continue
        if _path_match(rel, raw):
            matches.append(rel)
    return _pick_unique_suffix_match(raw, matches)


def matches_plan_file(changed_file: str, plan_file: str, *, checkout: Optional[Path] = None) -> bool:
    """True when a diff path corresponds to a plan violation file."""
    changed = changed_file.replace("\\", "/")
    planned = str(plan_file or "").replace("\\", "/")
    if checkout and planned:
        resolved = resolve_plan_file_under_checkout(checkout, planned)
        if resolved:
            planned = resolved
    return changed == planned or changed.endswith(planned) or planned.endswith(changed)


def plan_file_exists_under_checkout(checkout: Path, plan_file: str) -> bool:
    return resolve_plan_file_under_checkout(checkout, plan_file) is not None


def scan_globs_for_project(project_type: str) -> tuple[str, ...]:
    if normalize_project_type(project_type) == PROJECT_CSHARP:
        return CSHARP_GLOBS
    return JAVA_GLOBS


def scan_codebase(location: str, *, project_type: str = "java") -> List[Path]:
    root = Path(location)
    if not root.exists():
        return []
    found: List[Path] = []
    for pattern in scan_globs_for_project(project_type):
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            if path.name.endswith(".bak"):
                continue
            found.append(path)
    return sorted(set(found), key=lambda p: str(p).replace("\\", "/"))


def snapshot_files(location: str, *, project_type: str = "java") -> dict:
    root = Path(location)
    snapshot: dict = {}
    for path in scan_codebase(location, project_type=project_type):
        try:
            stat = path.stat()
        except OSError:
            continue
        snapshot[relative_to_root(path, root)] = (stat.st_mtime, stat.st_size)
    return snapshot


def _is_scan_absolute_path(path: str) -> bool:
    raw = path.replace("\\", "/")
    return raw.startswith("/") or (len(raw) > 1 and raw[1] == ":")


def normalize_violation_paths_in_plan(plan: Dict[str, Any], checkout: Path) -> List[str]:
    """Map scan paths (C# absolute, Java relative) to checkout-relative ``file`` for Claude."""
    notes: List[str] = []
    if not checkout.is_dir():
        return notes
    for item in plan.get("violations") or []:
        raw = item.get("file")
        if not raw:
            continue
        raw_s = str(raw).replace("\\", "/")
        resolved = resolve_plan_file_under_checkout(checkout, raw_s)
        if not resolved:
            continue
        if resolved != raw_s:
            if _is_scan_absolute_path(raw_s):
                item.setdefault("scanFile", raw_s)
            item["file"] = resolved
            notes.append(f"Remapped violation file to checkout path: {resolved}")
        else:
            item["file"] = resolved
    return notes


__all__ = [
    "matches_plan_file",
    "normalize_violation_paths_in_plan",
    "plan_file_exists_under_checkout",
    "resolve_plan_file_under_checkout",
    "scan_codebase",
    "scan_globs_for_project",
    "relative_to_root",
    "snapshot_files",
    "diff_snapshot",
]
