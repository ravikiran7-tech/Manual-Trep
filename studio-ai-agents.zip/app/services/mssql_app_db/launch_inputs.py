"""Resolve MSSQL Job 3 input files under ``_claude`` (Oracle uses oracle defaults)."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)
from app.services.oracle_pg.app_db_change import workspace as ws


def _defaults(project_type: str) -> tuple[str, str]:
    if str(project_type).lower() in {"csharp", "c#", "dotnet", "cs"}:
        return FINDINGS_CSHARP_MSSQL, RULES_CSHARP_MSSQL
    return FINDINGS_JAVA_MSSQL, RULES_JAVA_MSSQL


def resolve_mssql_launch_inputs(
    db_id: str,
    project_type: str,
    *,
    dependency_findings: Optional[str] = None,
    rules_remediation: Optional[str] = None,
) -> Dict[str, Path]:
    dep_default, rules_default = _defaults(project_type)
    findings_raw = (dependency_findings or "").strip() or dep_default
    rules_raw = (rules_remediation or "").strip() or rules_default
    findings_path = ws.resolve_input_file(
        db_id, findings_raw, label="inputPaths.dependencyFindings"
    )
    rules_path = ws.resolve_input_file(db_id, rules_raw, label="inputPaths.rulesRemediation")
    if not findings_path.is_file():
        raise ValueError(
            f"dependencyFindings file not found in {ws.inputs_dir(db_id)}: {findings_raw}"
        )
    if not rules_path.is_file():
        raise ValueError(
            f"rulesRemediation file not found in {ws.inputs_dir(db_id)}: {rules_raw}"
        )
    return {"dependencyFindings": findings_path, "rulesRemediation": rules_path}
