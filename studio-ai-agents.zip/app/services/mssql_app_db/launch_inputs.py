"""Resolve MSSQL Job 3 input files under ``_claude`` (Oracle uses oracle defaults).

The remediation file name is not fixed. Any JSON under ``_claude`` whose rules
carry MSSQL rule ids (``sql-java-`` / ``sql-csharp-``, or another id that
names MSSQL) and a remediation body is the knowledge base. Those remediations
are joined onto the findings and sent to Claude in the prompt.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.input_adapter import flatten_dependency_findings


def _defaults(project_type: str) -> tuple[str, str]:
    if str(project_type).lower() in {"csharp", "c#", "dotnet", "cs"}:
        return FINDINGS_CSHARP_MSSQL, RULES_CSHARP_MSSQL
    return FINDINGS_JAVA_MSSQL, RULES_JAVA_MSSQL


_MAX_JSON_BYTES = 20_000_000


def _load_json(path: Path) -> Any:
    try:
        if not path.is_file() or path.stat().st_size > _MAX_JSON_BYTES:
            return None
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return None


def _rule_rows(data: Any) -> list[dict]:
    if isinstance(data, dict):
        for key in ("rules", "remediations"):
            rows = data.get(key)
            if isinstance(rows, list):
                return [row for row in rows if isinstance(row, dict)]
        rows = []
        for key, value in data.items():
            if not isinstance(value, dict):
                continue
            if value.get("ruleId") or value.get("rule_id") or _mssql_rule_language(str(key)):
                row = dict(value)
                row.setdefault("ruleId", key)
                rows.append(row)
        return rows
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    return []


def _rule_id(item: dict) -> str:
    return str(item.get("ruleId") or item.get("rule_id") or "").strip()


def _mssql_rule_language(rule_id: str) -> str | None:
    """``java``, ``csharp``, or ``mssql`` when the id is an MSSQL app rule."""
    low = rule_id.strip().lower().replace("_", "-")
    if not low:
        return None
    if low.startswith("sql-java-") or "sql-java-" in low or low.startswith("java-mssql"):
        return "java"
    if (
        low.startswith("sql-csharp-")
        or "sql-csharp-" in low
        or low.startswith("csharp-mssql")
        or low.startswith("cs-mssql")
    ):
        return "csharp"
    if "mssql" in low or "sqlserver" in low or "sql-server" in low:
        if "csharp" in low or low.startswith("cs-"):
            return "csharp"
        if "java" in low:
            return "java"
        return "mssql"
    return None


def _row_has_remediation(item: dict) -> bool:
    for key in ("remediationText", "remediation_text", "detailedDescription"):
        if str(item.get(key) or "").strip():
            return True
    rem = item.get("remediations")
    if rem is None:
        rem = item.get("remediation")
    if isinstance(rem, str) and rem.strip():
        return True
    if isinstance(rem, dict):
        return True
    if isinstance(rem, list) and any(isinstance(row, (dict, str)) and row for row in rem):
        return True
    return False


def _language_key(project_type: str) -> str:
    return "csharp" if str(project_type).lower() in {"csharp", "c#", "dotnet", "cs"} else "java"


def score_remediation_file(path: Path) -> dict[str, int] | None:
    """Count MSSQL rule ids in a JSON file. ``None`` when it is not a KB."""
    rows = _rule_rows(_load_json(path))
    if not rows:
        return None
    counts = {"java": 0, "csharp": 0, "mssql": 0, "text": 0}
    for item in rows:
        language = _mssql_rule_language(_rule_id(item))
        if not language:
            continue
        counts[language] += 1
        if _row_has_remediation(item):
            counts["text"] += 1
    if counts["java"] + counts["csharp"] + counts["mssql"] == 0:
        return None
    return counts


def remediation_rule_ids(path: Path) -> set[str]:
    ids: set[str] = set()
    for item in _rule_rows(_load_json(path)):
        rule_id = _rule_id(item)
        if _mssql_rule_language(rule_id):
            ids.add(rule_id)
    return ids


def find_mssql_remediation_file(
    root: Path,
    project_type: str,
    preferred: Path | None = None,
) -> Path | None:
    """Pick the JSON KB for this language. The file name does not matter."""
    if not root.is_dir():
        return None
    want = _language_key(project_type)
    other = "java" if want == "csharp" else "csharp"
    ranked: list[tuple] = []
    for path in root.rglob("*.json"):
        if not path.is_file():
            continue
        score = score_remediation_file(path)
        if not score:
            continue
        language_hits = score[want] + score["mssql"]
        if language_hits == 0 and score[other] > 0:
            continue
        depth = len(path.relative_to(root).parts)
        ranked.append((language_hits, score["text"], score[want], -depth, path))
    if not ranked:
        return None
    if preferred is not None:
        try:
            preferred_resolved = preferred.resolve()
        except OSError:
            preferred_resolved = preferred
        for hits, _text, _want, _depth, path in ranked:
            try:
                same = path.resolve() == preferred_resolved
            except OSError:
                same = path == preferred
            if same and hits > 0:
                return path
    ranked.sort(reverse=True)
    return ranked[0][-1]


def _finding_rule_ids(path: Path) -> set[str]:
    data = _load_json(path)
    if not isinstance(data, dict):
        return set()
    try:
        rows = flatten_dependency_findings(data)
    except ValueError:
        return set()
    return {str(row.get("ruleId")) for row in rows if row.get("ruleId")}


def find_mssql_findings_file(
    root: Path,
    catalog_ids: set[str],
    preferred: Path | None = None,
    *,
    skip: Path | None = None,
) -> Path | None:
    """Pick the findings JSON whose rule ids overlap the remediation KB."""
    if not root.is_dir() or not catalog_ids:
        return None
    skip_resolved = None
    if skip is not None:
        try:
            skip_resolved = skip.resolve()
        except OSError:
            skip_resolved = skip
    if preferred is not None and preferred.is_file():
        try:
            preferred_resolved = preferred.resolve()
        except OSError:
            preferred_resolved = preferred
        if preferred_resolved != skip_resolved and _finding_rule_ids(preferred) & catalog_ids:
            return preferred

    best: Path | None = None
    best_key: tuple = ()
    for path in root.rglob("*.json"):
        if not path.is_file():
            continue
        try:
            if skip_resolved is not None and path.resolve() == skip_resolved:
                continue
        except OSError:
            continue
        overlap = _finding_rule_ids(path) & catalog_ids
        if not overlap:
            continue
        depth = len(path.relative_to(root).parts)
        key = (len(overlap), -depth)
        if key > best_key:
            best_key = key
            best = path
    return best


def _find_staged(db_id: str, *names: str) -> Path | None:
    """Find a findings or rules file at the ``_claude`` root or one level down.

    The copied Java package builder still writes ``Db-dependency/Java-Oracle-dependency.json``
    for an MSSQL application. Job 3 has already chosen the MSSQL engine by then.
    """
    root = ws.inputs_dir(db_id)
    if not root.is_dir():
        return None
    wanted = {name.lower() for name in names if name}
    matches: list[Path] = []
    for path in root.rglob("*"):
        if path.is_file() and path.name.lower() in wanted:
            matches.append(path)
    if not matches:
        return None
    oracle_names = {
        "java-oracle-dependency.json",
        "oracle-to-postgresql-rules_remediation.json",
    }

    def _rank(path: Path) -> tuple:
        copied = path.name.lower() in oracle_names
        return (1 if copied else 0, len(path.relative_to(root).parts), str(path))

    matches.sort(key=_rank)
    return matches[0]


def _existing_input(db_id: str, raw: str, label: str) -> Path | None:
    text = (raw or "").strip()
    if not text:
        return None
    path = ws.resolve_input_file(db_id, text, label=label)
    return path if path.is_file() else None


def resolve_mssql_launch_inputs(
    db_id: str,
    project_type: str,
    *,
    dependency_findings: Optional[str] = None,
    rules_remediation: Optional[str] = None,
) -> Dict[str, Path]:
    dep_default, rules_default = _defaults(project_type)
    root = ws.inputs_dir(db_id)
    preferred_rules = _existing_input(
        db_id, rules_remediation or "", "inputPaths.rulesRemediation"
    )
    rules_path = find_mssql_remediation_file(root, project_type, preferred_rules)
    if rules_path is None:
        staged_rules = _find_staged(
            db_id,
            rules_default,
            "oracle-to-postgresql-rules_remediation.json",
        )
        if staged_rules is not None and score_remediation_file(staged_rules):
            rules_path = staged_rules
    if rules_path is None or not rules_path.is_file():
        raise ValueError(
            "rulesRemediation file not found in "
            f"{root}: no JSON file contains MSSQL rule-id remediations"
        )

    catalog_ids = remediation_rule_ids(rules_path)
    preferred_findings = _existing_input(
        db_id, dependency_findings or "", "inputPaths.dependencyFindings"
    )
    findings_path = find_mssql_findings_file(
        root, catalog_ids, preferred_findings, skip=rules_path
    )
    if findings_path is None:
        staged = _find_staged(
            db_id,
            dep_default,
            "Java-Oracle-dependency.json",
            "java-oracle-dependency.json",
        )
        findings_path = staged
    if findings_path is None or not findings_path.is_file():
        raise ValueError(
            f"dependencyFindings file not found in {root}: {dependency_findings or dep_default}"
        )
    return {"dependencyFindings": findings_path, "rulesRemediation": rules_path}
