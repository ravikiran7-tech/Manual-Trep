"""Find the Job 1 checkout on the mount this agent can see.

Studio Core addresses the same NFS tree as
``/modernize-data/studio-data/{tenant}/{app}/transformed-code/...``.
The agent container mounts that tree at ``/studio-app``.
"""

from __future__ import annotations

from pathlib import Path

_STUDIO_NFS_PREFIX = "/modernize-data/studio-data"
_STUDIO_NFS_PARENT = "/modernize-data"


def _safe_tail(raw: str, prefix: str) -> str | None:
    base = prefix.rstrip("/")
    if not base or not (raw == base or raw.startswith(base + "/")):
        return None
    tail = raw[len(base) :].lstrip("/")
    if not tail or ".." in Path(tail).parts:
        return None
    return tail


def candidate_tails(raw: str, extra_prefixes: list[str] | None = None) -> list[str]:
    prefixes = [_STUDIO_NFS_PREFIX, _STUDIO_NFS_PARENT, *(extra_prefixes or [])]
    ordered = sorted({item.rstrip("/") for item in prefixes if item}, key=len, reverse=True)
    tails: list[str] = []
    for prefix in ordered:
        tail = _safe_tail(raw, prefix)
        if tail and tail not in tails:
            tails.append(tail)
    return tails


def resolve_against_mounts(requested: str, mounts: list[Path], prefixes: list[str] | None = None) -> tuple[str | None, list[str]]:
    """Return ``(visible path, paths that were not the checkout)``.

    ``None`` means every candidate was missing. An existing requested path is
    returned unchanged.
    """
    raw = str(requested or "").strip()
    if not raw:
        return None, []
    direct = Path(raw)
    if direct.is_dir():
        return str(direct), []

    tried: list[str] = []
    for tail in candidate_tails(raw, prefixes):
        for mount in mounts:
            root = Path(mount)
            if not root.is_dir():
                continue
            candidate = root / tail
            try:
                candidate.resolve().relative_to(root.resolve())
            except (OSError, ValueError):
                continue
            text = str(candidate)
            if text == raw or text in tried:
                continue
            tried.append(text)
            if candidate.is_dir():
                return text, tried
    return None, tried


def _mount_roots() -> tuple[list[Path], list[str]]:
    roots: list[Path] = []
    prefixes: list[str] = []
    try:
        from app.core.config import get_settings

        settings = get_settings()
    except Exception:
        settings = None
    if settings is not None:
        workspace = Path(str(getattr(settings, "claude_workspace", "") or ""))
        if workspace.name and str(workspace.parent) not in {"", "/"}:
            roots.append(workspace.parent)
        nfs = str(getattr(getattr(settings, "app_db_job3", None), "nfs_base_path", "") or "")
        if nfs:
            prefixes.append(nfs)
            roots.append(Path(nfs))
        security = getattr(settings, "security", None)
        if security is not None and hasattr(security, "get_allowed_directories_list"):
            for item in security.get_allowed_directories_list():
                if item:
                    roots.append(Path(item))
    for fallback in ("/studio-app",):
        path = Path(fallback)
        if path not in roots:
            roots.append(path)
    unique: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        text = str(root)
        if text in seen or text in {"", "/"}:
            continue
        seen.add(text)
        unique.append(root)
    return unique, prefixes


def locate_checkout(project_path: str) -> str:
    """Return the checkout directory, rewriting a Studio NFS prefix when needed."""
    raw = str(project_path or "").strip()
    mounts, prefixes = _mount_roots()
    found, tried = resolve_against_mounts(raw, mounts, prefixes)
    if found:
        return found
    extra = f" (also tried {', '.join(tried)})" if tried else ""
    raise FileNotFoundError(f"NFS mount path not found: {raw}{extra}")


def resolve_visible_checkout(
    project_path: str,
    *,
    app_id: str | None = None,
    tenant_id: str | None = None,
    plan_id: str | None = None,
) -> str:
    """Locate checkout on visible mounts; re-derive from tenant/plan if the path is stale."""
    from app.services.oracle_pg.app_db_change import workspace as ws

    raw = str(project_path or "").strip()
    try:
        return locate_checkout(raw)
    except FileNotFoundError:
        pass
    if tenant_id and plan_id and app_id:
        try:
            derived = ws.resolve_project_path(
                None,
                app_id=app_id,
                tenant_id=tenant_id,
                plan_id=plan_id,
            )
        except ValueError:
            derived = ""
        if derived and derived != raw:
            return locate_checkout(derived)
    extra = raw or "(empty projectPath)"
    raise FileNotFoundError(f"NFS mount path not found: {extra}")
