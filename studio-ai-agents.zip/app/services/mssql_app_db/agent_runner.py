"""MSSQL App+DB Claude remediator session."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.config import get_settings
from app.services.mssql_app_db.file_ops import (
    normalize_violation_paths_in_plan,
    relative_to_root,
    scan_codebase,
)
from app.services.mssql_app_db.literal_edits import related_configuration_files
from app.services.mssql_app_db.pathways import (
    compatibility_change_reason,
    compatibility_instructions,
    normalize_mssql_pathway,
)
from app.services.oracle_pg.app_db_change.progress_tracker import get_progress_tracker
from app.services.mssql_app_db.source_profile import normalize_project_type
from app.services.oracle_pg.agent_runner import (
    SessionResult,
    _apply_stream_close_timeout_env,
    _cli_stderr_logger,
    _is_initialize_timeout,
    _iter_sdk_messages,
    _kill_orphaned_claude_clis,
)


def _result_message_is_success(message: Any) -> bool:
    if getattr(message, "is_error", False):
        return False
    if message.subtype != "success":
        return False
    text = (message.result or "").lower()
    if any(
        marker in text
        for marker in (
            "authentication failed",
            "explicit deny",
            "accessdenied",
            "bedrock:invokemodel",
        )
    ):
        return False
    return True


def _result_message_error_detail(message: Any) -> str:
    errors = getattr(message, "errors", None) or []
    if errors:
        return "; ".join(str(e) for e in errors)
    status = getattr(message, "api_error_status", None)
    detail = message.result or message.subtype or "agent session failed"
    if status:
        return f"{detail} (HTTP {status})"
    return detail
from app.services.oracle_pg.live_logs import build_log_entry, format_post_tool_use

logger = logging.getLogger(__name__)
settings = get_settings()

_INITIALIZE_RETRY_SLEEP_SECONDS = 2

# The SDK/CLI occasionally emits a final result with is_error=True and
# subtype="success" (no structured errors list). query.py's read-loop then
# turns the subprocess's post-turn ProcessError into this exact text instead
# of a real error, even though the CLI's turn had already completed. Treat it
# as a transient crash worth one retry rather than a real remediation error.
_TRANSIENT_CLI_RESULT_MARKER = "Claude Code returned an error result:"


def _is_transient_cli_result_crash(exc: BaseException | str) -> bool:
    return _TRANSIENT_CLI_RESULT_MARKER in str(exc)


def _pending_violations(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]


def _needs_configuration_scope(pending: List[Dict[str, Any]]) -> bool:
    return any(
        str(v.get("ruleId") or "") == "sql-java-013"
        or "properties" in str(v.get("ruleName") or "").lower()
        for v in pending
    )


def _file_scope_line(*, compatibility_scope: str, needs_config: bool) -> str:
    """Same branching as ``oracle_pg.app_db_change.agent_runner`` with MSSQL config scope."""
    if compatibility_scope:
        return "- Edit plan files plus only the pathway compatibility files described below."
    if needs_config:
        return (
            "- Edit plan violation files and relatedConfigurationFiles "
            "(properties/YAML/persistence.xml) when JDBC or datasource remediations apply."
        )
    return "- Edit ONLY the files listed in the plan violations."


def _pathway_section(
    *,
    pathway: str,
    project_type: str,
    project_path: str,
    project_root: Path,
    compatibility_scope: str,
) -> str:
    if not compatibility_scope:
        return ""
    compatibility_files = [
        relative_path
        for path in scan_codebase(project_path, project_type=project_type)
        if (relative_path := relative_to_root(path, project_root))
        and compatibility_change_reason(relative_path, pathway, project_type)
    ]
    return (
        "\n## Required pathway compatibility work\n"
        f"{compatibility_scope}\n"
        "Existing compatibility files discovered in this checkout:\n"
        + (
            "\n".join(f"- {file_path}" for file_path in compatibility_files)
            if compatibility_files
            else "- None"
        )
        + "\nDo the plan violations before these files. A session that only updates "
        "appsettings, the csproj, or Program.cs still fails the dependency rules.\n"
    )


def _zero_skip_mandate(*, profile: str, retry: bool = False) -> str:
    opener = (
        "Retry pass: the first session left violations unresolved on disk. "
        if retry
        else ""
    )
    return f"""{opener}## Mandatory violation resolution (zero-skip)
- Resolve **every** pending violation in this plan before you end the session. Do not skip, defer,
  ignore, waive, or leave any item for manual review.
- Each item is resolved only when on-disk source (and applicable relatedConfigurationFiles) matches
  that item's {profile} remediationText and any oldCode→newCode pair from the ``rules`` catalog.
- Do not invent a different fix than the knowledge base. Do not stop while any pending item remains.
- Treat an empty findings scope as “apply pathway compatibility only”; when violations are listed,
  each one requires a substantive edit — not a comment-only note or unchanged file."""


def _per_violation_workflow() -> str:
    return """## Per-violation workflow (repeat for every pending item)
1. **Read** the violation ``file`` (relative to projectPath only; ignore ``scanFile`` for edits).
2. **Locate** the issue at ``beginLine``–``endLine``. Read that window first.
3. **Match** the ``ruleId`` row in ``rules`` and apply its remediationText exactly.
4. When ``oldCode`` and ``newCode`` are on the violation or rule row, apply that substitution at
   the listed lines (or at every in-file occurrence if the window text already differs but ``oldCode``
   still appears elsewhere in the same file).
5. **If the line window does not match** the remediation (line drift, partial prior edit):
   Grep the file for ``oldCode``, rule keywords, and MSSQL/SQL Server identifiers from
   remediationText; apply the fix at the discovered location in that file — do not abandon the item.
6. **Config scope**: for JDBC URL / datasource / properties rules, also update every path in
   ``relatedConfigurationFiles`` when URLs, drivers, or dialects live there.
7. **Same file, multiple violations**: each pending row has its own line range and ruleId. Fixing one
   occurrence does not resolve the others; edit every row for that file."""


def _is_type_mapping_rule(rule_id: str, rule_name: str) -> bool:
    name = rule_name.lower()
    return name.endswith("mapping") or "tosql" in name.replace(" ", "").lower()


def _is_properties_config_rule(rule_id: str, rule_name: str) -> bool:
    name = rule_name.lower()
    return (
        rule_id == "sql-java-013"
        or "properties" in name
        or "configuration" in name
    )


def _rule_category_playbook(pending: List[Dict[str, Any]]) -> str:
    """Targeted guidance for the two rule categories most often reported as
    "No file change detected for this violation" when the model under-searches
    the file: type/column mapping rules and properties/configuration rules.
    Only the categories actually present in this plan are included, so the
    prompt stays focused.
    """
    has_mapping = False
    has_config = False
    for item in pending:
        rule_id = str(item.get("ruleId") or "")
        rule_name = str(item.get("ruleName") or "")
        if _is_type_mapping_rule(rule_id, rule_name):
            has_mapping = True
        if _is_properties_config_rule(rule_id, rule_name):
            has_config = True
    if not has_mapping and not has_config:
        return ""

    blocks: List[str] = ["## Rule-category playbook (apply in addition to the per-violation workflow)"]
    if has_mapping:
        blocks.append(
            """### Type/column mapping rules (ruleName ending in "...Mapping", e.g.
DateToSqlDateMapping, ByteArrayToSqlVarbinaryMapping)
These describe a Java<->JDBC<->PostgreSQL type substitution. The exact text
named in oldCode rarely appears verbatim at beginLine; the real touchpoints
are spread across the file. Concrete examples from this KB:
- **ByteArrayToSqlVarbinaryMapping**: find every JPA ``@Column(columnDefinition = "...")``
  that says ``VARBINARY`` or ``VARBINARY(MAX)`` and rewrite it to ``BYTEA``.
  Find every JDBC parameter declared with ``java.sql.Types.VARBINARY`` and
  change it to ``java.sql.Types.BINARY`` -- PostgreSQL's BYTEA has no
  ``Types.BYTEA`` constant, never introduce one. Leave ``byte[]`` fields and
  ``getBytes()``/``setBytes()`` calls as-is; they already work against BYTEA.
- **DateToSqlDateMapping**: find every ``java.sql.Date``/``java.util.Date``
  field, getter, setter, or ResultSet/PreparedStatement call
  (``getDate``/``setDate``) tied to a column that was SQL Server ``DATE``.
  Where the field only ever needs a date (no time component), migrate the
  declared type to ``java.time.LocalDate`` and its accessors
  (``getObject(.., LocalDate.class)`` / ``setObject``); otherwise keep
  ``java.sql.Date`` but confirm it round-trips a date-only PostgreSQL ``DATE``
  column correctly.
- For any other mapping rule, apply the same approach: grep the WHOLE file
  (not just the beginLine window) for every field declaration, getter/setter,
  JDBC parameter setter, and ``Types.*``/annotation reference tied to the old
  type, and apply the oldCode->newCode substitution (or the equivalent
  construct remediationText describes) at every occurrence. A mapping
  violation is resolved only when none of these touchpoints still reference
  the old type in that file."""
        )
    if has_config:
        blocks.append(
            """### Properties/configuration rules (ruleId sql-java-013
PropertiesFileConfiguration, or ruleName mentioning "properties"/"configuration")
These detect SQL Server JDBC/datasource settings. The fix belongs wherever
the setting actually lives on disk -- check both locations, fix whichever
one(s) are present, and do not skip either:
1. **Properties/YAML files** (relatedConfigurationFiles): if
   ``spring.datasource.url``, ``spring.datasource.driver-class-name``, or any
   other SQL Server JDBC/dialect/platform key is set in a ``.properties``,
   ``.yml``/``.yaml``, or ``persistence.xml`` file, translate it there to the
   PostgreSQL URL format, ``org.postgresql.Driver``, and PostgreSQL dialect.
2. **The violation's own Java file**: the dependency scanner attributed this
   finding to a specific ``.java`` file -- that usually means the JDBC
   URL/driver/datasource value is hardcoded or built as a literal string
   in that file (not externalized), so check at and around beginLine for a
   SQL Server connection string, driver class name, or SQL Server-specific
   property key and translate it in place to the PostgreSQL equivalent.
3. When several pending rows share the same ruleId in the same file (e.g.
   multiple PropertiesFileConfiguration hits in one class), each row names a
   distinct line/property; resolve every row independently -- do not treat
   the first fix as covering the rest."""
        )
    return "\n\n".join(blocks)


def _completion_verification_mandate() -> str:
    return """## Before you end the session
For every pending violation, re-open its ``file`` (and any
relatedConfigurationFiles you touched for it) and confirm the edit is present
in the current on-disk content -- not just in your plan or reasoning. The
pipeline that reads your work after this session compares file content
before and after this turn; a violation whose file is byte-identical to
before is reported as "No file change detected for this violation" and
counted as a failure, even if you intended to fix it. If any pending item's
file is still unchanged, make the edit now before ending the turn."""


def _java_remediation_playbook() -> str:
    return """## MSSQL-Java remediation focus
- JDBC: replace ``jdbc:sqlserver`` / jTDS URLs, ``SQLServerDriver`` / jTDS driver classes, and
  MSSQL pool settings with PostgreSQL URL, ``org.postgresql.Driver``, dialect, and HikariCP as the
  remediation describes.
- ORM/JPA: update ``persistence.xml``, ``application*.properties|yml``, ``pom.xml`` / Gradle deps
  when the rule or sql-java-013-style datasource findings require it.
- T-SQL and MSSQL-only SQL in strings, annotations, or native queries: rewrite to PostgreSQL syntax
  per remediationText (functions, types, limits, identity/sequence, TOP→LIMIT, etc.).
- Types: ``java.sql.Types`` has no ``BYTEA``. Column / ``columnDefinition`` VARBINARY→BYTEA per KB;
  JDBC ``Types.VARBINARY`` in code becomes ``Types.BINARY``, never ``Types.BYTEA``."""


def _csharp_remediation_playbook() -> str:
    return """## MSSQL-C# remediation focus
- DboSchemaUsage: open every listed Migrations and DAL file and delete the ``dbo.`` prefix at
  each pending beginLine–endLine. One migration file often has many rows; edit all of them in
  that file before leaving it. A file that still contains those ``dbo.`` qualifiers is a failure.
- SqlClientNamespaceImport: in the listed file, replace ``System.Data.SqlClient`` and
  ``Microsoft.Data.SqlClient`` with ``Npgsql``, and ``SqlConnection`` / ``SqlCommand`` /
  ``SqlParameter`` with the Npgsql equivalents from remediationText. The file must change.
- SqlExceptionHandling: replace ``SqlException`` at each listed line with ``PostgresException``.
- SqlErrorCollectionHandling: replace ``SqlErrorCollection`` and ``SqlError`` at each listed
  line with ``PostgresException``.
- LinqToSqlQueryUsage: replace LINQ-to-SQL types and calls (``EntitySet``, ``DataLoadOptions``,
  ``SubmitChanges``, ``System.Data.Linq``) with the EF Core shape in remediationText.
- Every other selected rule is included the same way: one row in the plan is one required edit.
  A rule is done only when every one of its violations is resolved.
- Connection strings and ``UseSqlServer()`` in ``appsettings*.json``, ``Program.cs``,
  ``Startup.cs``, and ``*.csproj`` come after the violation files above are saved.
- Remove SQL Server health-check SQL; use PostgreSQL-compatible ``SELECT 1`` where remediations say so."""


def _csharp_file_mandate(pending: List[Dict[str, Any]]) -> str:
    """Name every C# violation file so M-Upgrade and M-Mono edit them, not only the short model files."""
    grouped: Dict[str, Dict[str, int]] = {}
    for item in pending:
        file_path = str(item.get("file") or "").replace("\\", "/").strip()
        if not file_path:
            continue
        rule = str(item.get("ruleName") or item.get("ruleId") or "violation")
        counts = grouped.setdefault(file_path, {})
        counts[rule] = counts.get(rule, 0) + 1
    if not grouped:
        return ""
    by_rule: Dict[str, int] = {}
    for item in pending:
        rule = str(item.get("ruleName") or item.get("ruleId") or "violation")
        by_rule[rule] = by_rule.get(rule, 0) + 1
    lines = [
        "## Selected rules — resolve every violation of each rule",
        "These are the rules selected for this run. Every violation row under a rule has to be resolved.",
    ]
    for rule, count in sorted(by_rule.items()):
        lines.append(f"- {rule}: {count} violation(s)")
    lines.extend(
        [
            "## C# files that must change before any other file",
            "Save an edit in every file below before appsettings, the csproj, Program.cs, or Docker files.",
            "DboSchemaUsage means delete `dbo.` at each listed line. SqlClientNamespaceImport means replace the SqlClient namespace in that file.",
            "SqlExceptionHandling means replace `SqlException`. SqlErrorCollectionHandling means replace `SqlErrorCollection` and `SqlError`.",
        ]
    )
    for file_path in sorted(grouped):
        summary = ", ".join(
            f"{rule} x{count}" for rule, count in sorted(grouped[file_path].items())
        )
        lines.append(f"- `{file_path}` — {summary}")
    lines.append(
        "Do not end the session while any file above is still byte-identical to when you opened it."
    )
    return "\n".join(lines)


def _remediation_body(
    *, project_type: str, profile: str, retry: bool, pending: List[Dict[str, Any]]
) -> str:
    lang_key = normalize_project_type(project_type)
    playbook = (
        _csharp_remediation_playbook()
        if lang_key == "csharp"
        else _java_remediation_playbook()
    )
    sections = [
        _zero_skip_mandate(profile=profile, retry=retry),
        _per_violation_workflow(),
        playbook,
    ]
    if lang_key == "csharp":
        file_mandate = _csharp_file_mandate(pending)
        if file_mandate:
            sections.append(file_mandate)
    category_playbook = _rule_category_playbook(pending)
    if category_playbook:
        sections.append(category_playbook)
    sections.append(_completion_verification_mandate())
    return "\n\n".join(sections)


def _plan_excerpt(
    *,
    plan: Dict[str, Any],
    project_path: str,
    project_root: Path,
    pending: List[Dict[str, Any]],
    include_pathway: bool = True,
) -> Dict[str, Any]:
    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    catalog = ((plan.get("catalogSubset") or {}).get("rules")) or []
    needs_config = _needs_configuration_scope(pending)
    excerpt: Dict[str, Any] = {
        "projectPath": project_path,
        "projectType": project_type,
        "violations": pending,
        "rules": catalog,
    }
    if include_pathway:
        excerpt["pathway"] = pathway
    if needs_config and normalize_project_type(project_type) == "java":
        excerpt["relatedConfigurationFiles"] = related_configuration_files(
            project_root, project_type
        )
    return excerpt


def render_remediator_prompt(*, plan: Dict[str, Any], project_path: str) -> str:
    """Build the App+DB remediator prompt (layout aligned with Oracle Job 3)."""
    project_root = Path(project_path)
    if project_root.is_dir():
        normalize_violation_paths_in_plan(plan, project_root)
    pending = _pending_violations(plan)
    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    profile = plan.get("languageProfile") or "MSSQL-Java"
    compatibility_scope = compatibility_instructions(pathway, project_type)
    file_scope = _file_scope_line(
        compatibility_scope=compatibility_scope,
        needs_config=_needs_configuration_scope(pending),
    )
    pathway_section = _pathway_section(
        pathway=pathway,
        project_type=project_type,
        project_path=project_path,
        project_root=project_root,
        compatibility_scope=compatibility_scope,
    )
    excerpt = _plan_excerpt(
        plan=plan,
        project_path=project_path,
        project_root=project_root,
        pending=pending,
    )
    lang = "C#" if normalize_project_type(project_type) == "csharp" else "Java"
    remediation_body = _remediation_body(
        project_type=project_type, profile=profile, retry=False, pending=pending
    )
    return f"""You are an expert {lang} developer and database migration engineer for Microsoft SQL Server
→ PostgreSQL. You apply dependency-scan remediations with precision and leave no violation behind.

## Role
Transform the checked-out application at the NFS code path below. Apply **every**
pending violation from the dependency-resolution plan using the {profile} knowledge base
(``rules`` + per-row remediationText, oldCode, newCode).

## Constraints
- Work only under: {project_path}
- {file_scope}
- Prefer Read/Edit for surgical changes at the given beginLine/endLine.
- Preserve style. Only change MSSQL/SQL Server-specific logic required by remediations.
- Do not use git. Do not commit. Do not write post_transformation_report.json
  (deterministic packaging writes that file after this session).

{remediation_body}
{pathway_section}
## Plan (resolve every pending violation)
{json.dumps(excerpt, indent=2)}

## Expected result
- On disk: every pending violation has a matching edit on its ``file`` (and on
  relatedConfigurationFiles when the rule requires it).
- Plus: every required MSSQL-to-PostgreSQL pathway compatibility update above.
- Before you finish, mentally verify each plan row: MSSQL construct gone or replaced exactly as
  remediationText specifies. Unresolved items are unacceptable.
"""


def render_remediator_retry_prompt(*, plan: Dict[str, Any], project_path: str) -> str:
    """Second pass when the primary session left violations without file changes."""
    project_root = Path(project_path)
    if project_root.is_dir():
        normalize_violation_paths_in_plan(plan, project_root)
    pending = _pending_violations(plan)
    project_type = str(plan.get("projectType") or "java")
    profile = plan.get("languageProfile") or "MSSQL-Java"
    needs_config = _needs_configuration_scope(pending)
    file_scope = _file_scope_line(compatibility_scope="", needs_config=needs_config)
    excerpt = _plan_excerpt(
        plan=plan,
        project_path=project_path,
        project_root=project_root,
        pending=pending,
        include_pathway=False,
    )
    lang = "C#" if normalize_project_type(project_type) == "csharp" else "Java"
    remediation_body = _remediation_body(
        project_type=project_type, profile=profile, retry=True, pending=pending
    )
    return f"""You are an expert {lang} developer and database migration engineer for Microsoft SQL Server
→ PostgreSQL. This is a **retry** session: prior edits did not fully resolve the plan.

## Role
Apply **every** unresolved violation below using the {profile} knowledge base. You must produce
on-disk fixes for all listed items before ending.

## Constraints
- Work only under: {project_path}
- {file_scope}
- Prefer Read/Edit at beginLine/endLine; use Write only when remediation requires new content.
- Do not use git. Do not commit. Do not write post_transformation_report.json.

{remediation_body}

## Plan (unresolved violations only — all must be fixed)
{json.dumps(excerpt, indent=2)}

## Expected result
- Each row below yields a concrete file change on ``file`` or an applicable relatedConfigurationFiles
  path. Structural rules (LINQ to SQL, EF providers, varbinary/type mappings) need real code edits.
- If a previous pass partially edited a file, complete the remaining rows at their own line ranges.
- Do not end the session until every item in this plan is resolved per its remediationText.
"""


def _build_app_db_options(checkout: Path, transformation_id: str) -> Any:
    from claude_agent_sdk import ClaudeAgentOptions

    _apply_stream_close_timeout_env()
    opts = ClaudeAgentOptions(
        cwd=str(checkout),
        model="sonnet",
        permission_mode="acceptEdits",
        setting_sources=[],
        allowed_tools=["Read", "Write", "Edit", "Glob", "Grep"],
        max_turns=settings.oracle_pg_agent.max_turns_per_session,
        max_budget_usd=settings.oracle_pg_agent.max_budget_usd_per_session,
        max_buffer_size=settings.oracle_pg_agent.max_buffer_size_bytes,
        env=settings.oracle_pg_agent.bedrock_env(settings.bedrock.region),
        hooks=_make_app_db_hooks(transformation_id, checkout),
        stderr=_cli_stderr_logger(transformation_id),
    )
    if settings.oracle_pg_agent.cli_path:
        opts.cli_path = settings.oracle_pg_agent.cli_path
    return opts


def _make_app_db_hooks(transformation_id: str, checkout: Path) -> Optional[dict]:
    try:
        from claude_agent_sdk import HookMatcher
    except ImportError:
        return None

    tracker = get_progress_tracker()

    async def on_tool_use(
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input") or {}
        public_job_id = tracker.public_job_id(transformation_id)
        log_entry = format_post_tool_use(
            public_job_id,
            tool_name,
            tool_input,
            job_root=checkout,
        )
        if log_entry:
            tracker.add_log_entry(
                transformation_id,
                "INFO",
                log_entry["message"],
                icon=log_entry["icon"],
            )
        return {}

    return {
        "PostToolUse": [
            HookMatcher(matcher="Write", hooks=[on_tool_use]),
            HookMatcher(matcher="Edit", hooks=[on_tool_use]),
            HookMatcher(matcher="Read", hooks=[on_tool_use]),
            HookMatcher(matcher="Glob", hooks=[on_tool_use]),
            HookMatcher(matcher="Grep", hooks=[on_tool_use]),
        ],
    }


async def run_app_db_remediator_session(
    *,
    transformation_id: str,
    checkout: Path,
    plan: Dict[str, Any],
    retry: bool = False,
) -> SessionResult:
    try:
        from claude_agent_sdk.types import ResultMessage
    except ImportError as exc:
        return SessionResult(
            success=False,
            error_message=f"claude-agent-sdk not installed: {exc}",
        )

    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    pending = [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]
    compatibility_scope = compatibility_instructions(pathway, project_type)
    if retry:
        if not pending:
            return SessionResult(success=True, result_text="No violations to retry")
        prompt = render_remediator_retry_prompt(plan=plan, project_path=str(checkout))
    else:
        if not pending and not compatibility_scope:
            return SessionResult(success=True, result_text="No pending violations")
        prompt = render_remediator_prompt(plan=plan, project_path=str(checkout))
    options = _build_app_db_options(checkout, transformation_id)
    session_result = SessionResult(success=False)
    tracker = get_progress_tracker()
    if retry:
        session_message = f"Retry Claude session for {len(pending)} unresolved violation(s)"
    else:
        session_message = (
            f"Starting Claude remediator session for {len(pending)} pending violation(s)"
            + (" and pathway compatibility" if compatibility_scope else "")
        )
    start_entry = build_log_entry(
        tracker.public_job_id(transformation_id),
        message=session_message,
        icon="play",
    )
    tracker.add_log_entry(
        transformation_id,
        "INFO",
        start_entry["message"],
        icon=start_entry["icon"],
    )

    async def _drain() -> None:
        async for message in _iter_sdk_messages(prompt, options):
            if isinstance(message, ResultMessage):
                session_result.session_id = message.session_id
                session_result.subtype = message.subtype
                session_result.result_text = message.result
                session_result.total_cost_usd = message.total_cost_usd
                session_result.success = _result_message_is_success(message)
                if not session_result.success:
                    session_result.error_message = _result_message_error_detail(message)

    try:
        try:
            await _drain()
        except Exception as exc:
            if _is_initialize_timeout(exc):
                logger.warning(
                    "CLI initialize timeout for MSSQL App+DB %s; retrying once",
                    transformation_id,
                )
            elif _is_transient_cli_result_crash(exc):
                # Known claude-agent-sdk/CLI quirk: the final result message
                # can be tagged ``is_error=True`` with ``subtype="success"``
                # and no structured errors, which the SDK surfaces as a
                # ProcessError after the turn already finished. The CLI
                # process has exited either way, so retry the whole session
                # once rather than losing every edit made before the crash.
                logger.warning(
                    "Transient Claude CLI result error for MSSQL App+DB %s (%s); retrying once",
                    transformation_id,
                    exc,
                )
            else:
                raise
            _kill_orphaned_claude_clis(checkout)
            await asyncio.sleep(_INITIALIZE_RETRY_SLEEP_SECONDS)
            await _drain()
    except Exception as exc:
        logger.exception("MSSQL App+DB remediator session failed for %s", transformation_id)
        session_result.error_message = str(exc)
    finally:
        _kill_orphaned_claude_clis(checkout)

    return session_result
