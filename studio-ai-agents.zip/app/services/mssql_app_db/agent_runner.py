"""MSSQL App+DB Claude remediator session."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.config import get_settings
from app.services.mssql_app_db.file_ops import (
    normalize_violation_paths_in_plan,
    relative_to_root,
    scan_codebase,
)
from app.services.mssql_app_db.literal_edits import related_configuration_files
from app.services.mssql_app_db.pathways import (
    compatibility_change_reason,
    compatibility_instructions,
    normalize_mssql_pathway,
)
from app.services.oracle_pg.app_db_change.progress_tracker import get_progress_tracker
from app.services.mssql_app_db.source_profile import normalize_project_type
from app.services.oracle_pg.agent_runner import (
    SessionResult,
    _apply_stream_close_timeout_env,
    _cli_stderr_logger,
    _is_initialize_timeout,
    _iter_sdk_messages,
    _kill_orphaned_claude_clis,
)


def _result_message_is_success(message: Any) -> bool:
    if getattr(message, "is_error", False):
        return False
    if message.subtype != "success":
        return False
    text = (message.result or "").lower()
    if any(
        marker in text
        for marker in (
            "authentication failed",
            "explicit deny",
            "accessdenied",
            "bedrock:invokemodel",
        )
    ):
        return False
    return True


def _result_message_error_detail(message: Any) -> str:
    errors = getattr(message, "errors", None) or []
    if errors:
        return "; ".join(str(e) for e in errors)
    status = getattr(message, "api_error_status", None)
    detail = message.result or message.subtype or "agent session failed"
    if status:
        return f"{detail} (HTTP {status})"
    return detail
from app.services.oracle_pg.live_logs import build_log_entry, format_post_tool_use

logger = logging.getLogger(__name__)
settings = get_settings()

_INITIALIZE_RETRY_SLEEP_SECONDS = 2

# The SDK/CLI occasionally emits a final result with is_error=True and
# subtype="success" (no structured errors list). query.py's read-loop then
# turns the subprocess's post-turn ProcessError into this exact text instead
# of a real error, even though the CLI's turn had already completed. Treat it
# as a transient crash worth one retry rather than a real remediation error.
_TRANSIENT_CLI_RESULT_MARKER = "Claude Code returned an error result:"


def _is_transient_cli_result_crash(exc: BaseException | str) -> bool:
    return _TRANSIENT_CLI_RESULT_MARKER in str(exc)


def _pending_violations(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]


def _needs_configuration_scope(pending: List[Dict[str, Any]]) -> bool:
    return any(
        str(v.get("ruleId") or "") == "sql-java-013"
        or "properties" in str(v.get("ruleName") or "").lower()
        for v in pending
    )


def _file_scope_line(*, compatibility_scope: str, needs_config: bool) -> str:
    """Same branching as ``oracle_pg.app_db_change.agent_runner`` with MSSQL config scope."""
    if compatibility_scope:
        return "- Edit plan files plus only the pathway compatibility files described below."
    if needs_config:
        return (
            "- Edit plan violation files and relatedConfigurationFiles "
            "(properties/YAML/persistence.xml) when JDBC or datasource remediations apply."
        )
    return "- Edit ONLY the files listed in the plan violations."


def _pathway_section(
    *,
    pathway: str,
    project_type: str,
    project_path: str,
    project_root: Path,
    compatibility_scope: str,
) -> str:
    if not compatibility_scope:
        return ""
    compatibility_files = [
        relative_path
        for path in scan_codebase(project_path, project_type=project_type)
        if (relative_path := relative_to_root(path, project_root))
        and compatibility_change_reason(relative_path, pathway, project_type)
    ]
    return (
        "\n## Required pathway compatibility work\n"
        f"{compatibility_scope}\n"
        "Existing compatibility files discovered in this checkout:\n"
        + (
            "\n".join(f"- {file_path}" for file_path in compatibility_files)
            if compatibility_files
            else "- None"
        )
        + "\nComplete this inspection even after all plan violations are fixed.\n"
    )


def _plan_excerpt(
    *,
    plan: Dict[str, Any],
    project_path: str,
    project_root: Path,
    pending: List[Dict[str, Any]],
    include_pathway: bool = True,
) -> Dict[str, Any]:
    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    catalog = ((plan.get("catalogSubset") or {}).get("rules")) or []
    needs_config = _needs_configuration_scope(pending)
    excerpt: Dict[str, Any] = {
        "projectPath": project_path,
        "projectType": project_type,
        "violations": pending,
        "rules": catalog,
    }
    if include_pathway:
        excerpt["pathway"] = pathway
    if needs_config and normalize_project_type(project_type) == "java":
        excerpt["relatedConfigurationFiles"] = related_configuration_files(
            project_root, project_type
        )
    return excerpt


def render_remediator_prompt(*, plan: Dict[str, Any], project_path: str) -> str:
    """Build the App+DB remediator prompt (layout aligned with Oracle Job 3)."""
    project_root = Path(project_path)
    if project_root.is_dir():
        normalize_violation_paths_in_plan(plan, project_root)
    pending = _pending_violations(plan)
    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    profile = plan.get("languageProfile") or "MSSQL-Java"
    compatibility_scope = compatibility_instructions(pathway, project_type)
    file_scope = _file_scope_line(
        compatibility_scope=compatibility_scope,
        needs_config=_needs_configuration_scope(pending),
    )
    pathway_section = _pathway_section(
        pathway=pathway,
        project_type=project_type,
        project_path=project_path,
        project_root=project_root,
        compatibility_scope=compatibility_scope,
    )
    excerpt = _plan_excerpt(
        plan=plan,
        project_path=project_path,
        project_root=project_root,
        pending=pending,
    )
    lang = "C#" if normalize_project_type(project_type) == "csharp" else "Java"
    return f"""You are an expert {lang} developer specializing in Microsoft SQL Server to PostgreSQL application migration.

## Role
Transform the checked-out application at the NFS code path below. Apply every
pending violation from the dependency-resolution plan using the remediation
text from the {profile} knowledge base.

## Constraints
- Work only under: {project_path}
- {file_scope}
- Prefer Read/Edit for surgical changes at the given beginLine/endLine.
- Preserve style. Only change MSSQL/SQL Server-specific logic.
- Do not use git. Do not commit. Do not write post_transformation_report.json
  (deterministic packaging writes that file after this session).

## MSSQL remediation (stricter than leave-unchanged defaults)
- Each violation ``file`` is relative to projectPath. C# scan payloads may also
  include ``scanFile`` (absolute source path); always Read/Edit using ``file`` only.
- For each pending item, apply that ruleId's remediationText from the ``rules`` catalog.
- When oldCode and newCode are present on the rule or violation row, use them at the listed lines.
- Edit or Write every pending violation file when the remediation applies there.
- For datasource/properties rules, also update relatedConfigurationFiles when JDBC strings live there.
- Several pending items can point at the SAME file with DIFFERENT beginLine/endLine —
  each is tracked and verified individually. Fixing one occurrence in a file does
  NOT resolve the others: go through every pending item for that file and fix its
  own line(s), even after you have already changed something else nearby.
- JDBC type mapping note: ``java.sql.Types`` has no ``BYTEA`` constant. When a
  violation's remediation says to map VARBINARY to PostgreSQL BYTEA, that applies
  to the DATABASE COLUMN TYPE (and any JPA ``columnDefinition="VARBINARY(MAX)"``
  annotation, which becomes ``columnDefinition="BYTEA"``) — a Java
  ``Types.VARBINARY`` constant in JDBC code (e.g. ``registerOutParameter``,
  ``setNull``) must become ``Types.BINARY``, never ``Types.BYTEA``.
{pathway_section}
## Plan (apply every pending violation)
{json.dumps(excerpt, indent=2)}

## Expected result
Updated source files on the checkout for each pending violation, plus every
required MSSQL-to-PostgreSQL pathway compatibility update described above.
For each pending violation, apply that item's remediationText to its file and
lines. When oldCode and newCode are present, use them as the change. Do not
invent a different fix. Only skip a violation when the code at the listed lines
does not match what the remediation describes.
"""


def render_remediator_retry_prompt(*, plan: Dict[str, Any], project_path: str) -> str:
    """Second pass when the primary session left violations without file changes."""
    project_root = Path(project_path)
    if project_root.is_dir():
        normalize_violation_paths_in_plan(plan, project_root)
    pending = _pending_violations(plan)
    project_type = str(plan.get("projectType") or "java")
    profile = plan.get("languageProfile") or "MSSQL-Java"
    needs_config = _needs_configuration_scope(pending)
    file_scope = _file_scope_line(compatibility_scope="", needs_config=needs_config)
    excerpt = _plan_excerpt(
        plan=plan,
        project_path=project_path,
        project_root=project_root,
        pending=pending,
        include_pathway=False,
    )
    lang = "C#" if normalize_project_type(project_type) == "csharp" else "Java"
    return f"""You are an expert {lang} developer specializing in Microsoft SQL Server to PostgreSQL migration.

## Role
Retry pass: the first session completed without fixing the violations below on disk.
Apply every listed rule using the {profile} knowledge base.

## Constraints
- Work only under: {project_path}
- {file_scope}
- Prefer Read/Edit at beginLine/endLine.
- Do not use git. Do not commit. Do not write post_transformation_report.json.

## MSSQL remediation (required on this pass)
- You MUST Read each violation file and apply ruleId remediationText (and oldCode→newCode when set).
- Structural rules (e.g. LINQ to SQL, varbinary mappings) require substantive edits, not skipping.
- Datasource/properties rules must update relatedConfigurationFiles when URLs or drivers are there.
- Each unresolved item below is tracked by its own beginLine/endLine, even when several
  share the same file. A previous pass may have fixed one occurrence in a file and left
  others untouched — treat every item in this list as needing its own fix at its own
  lines, regardless of what else already changed in that file.
- JDBC type mapping note: ``java.sql.Types`` has no ``BYTEA`` constant. A Java
  ``Types.VARBINARY`` usage becomes ``Types.BINARY``, never ``Types.BYTEA`` — BYTEA
  is the PostgreSQL column type, not a JDBC Types constant.

## Plan (unresolved violations only)
{json.dumps(excerpt, indent=2)}

## Expected result
Every listed violation must produce a file change on ``file`` or an applicable
relatedConfigurationFiles path. Do not end the session until each item is addressed
or the code at the listed lines genuinely does not match the remediation.
"""


def _build_app_db_options(checkout: Path, transformation_id: str) -> Any:
    from claude_agent_sdk import ClaudeAgentOptions

    _apply_stream_close_timeout_env()
    opts = ClaudeAgentOptions(
        cwd=str(checkout),
        model="sonnet",
        permission_mode="acceptEdits",
        setting_sources=[],
        allowed_tools=["Read", "Write", "Edit", "Glob", "Grep"],
        max_turns=settings.oracle_pg_agent.max_turns_per_session,
        max_budget_usd=settings.oracle_pg_agent.max_budget_usd_per_session,
        max_buffer_size=settings.oracle_pg_agent.max_buffer_size_bytes,
        env=settings.oracle_pg_agent.bedrock_env(settings.bedrock.region),
        hooks=_make_app_db_hooks(transformation_id, checkout),
        stderr=_cli_stderr_logger(transformation_id),
    )
    if settings.oracle_pg_agent.cli_path:
        opts.cli_path = settings.oracle_pg_agent.cli_path
    return opts


def _make_app_db_hooks(transformation_id: str, checkout: Path) -> Optional[dict]:
    try:
        from claude_agent_sdk import HookMatcher
    except ImportError:
        return None

    tracker = get_progress_tracker()

    async def on_tool_use(
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input") or {}
        public_job_id = tracker.public_job_id(transformation_id)
        log_entry = format_post_tool_use(
            public_job_id,
            tool_name,
            tool_input,
            job_root=checkout,
        )
        if log_entry:
            tracker.add_log_entry(
                transformation_id,
                "INFO",
                log_entry["message"],
                icon=log_entry["icon"],
            )
        return {}

    return {
        "PostToolUse": [
            HookMatcher(matcher="Write", hooks=[on_tool_use]),
            HookMatcher(matcher="Edit", hooks=[on_tool_use]),
            HookMatcher(matcher="Read", hooks=[on_tool_use]),
            HookMatcher(matcher="Glob", hooks=[on_tool_use]),
            HookMatcher(matcher="Grep", hooks=[on_tool_use]),
        ],
    }


async def run_app_db_remediator_session(
    *,
    transformation_id: str,
    checkout: Path,
    plan: Dict[str, Any],
    retry: bool = False,
) -> SessionResult:
    try:
        from claude_agent_sdk.types import ResultMessage
    except ImportError as exc:
        return SessionResult(
            success=False,
            error_message=f"claude-agent-sdk not installed: {exc}",
        )

    pathway = normalize_mssql_pathway(str(plan.get("pathway") or "M-Upgrade"))
    project_type = str(plan.get("projectType") or "java")
    pending = [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]
    compatibility_scope = compatibility_instructions(pathway, project_type)
    if retry:
        if not pending:
            return SessionResult(success=True, result_text="No violations to retry")
        prompt = render_remediator_retry_prompt(plan=plan, project_path=str(checkout))
    else:
        if not pending and not compatibility_scope:
            return SessionResult(success=True, result_text="No pending violations")
        prompt = render_remediator_prompt(plan=plan, project_path=str(checkout))
    options = _build_app_db_options(checkout, transformation_id)
    session_result = SessionResult(success=False)
    tracker = get_progress_tracker()
    if retry:
        session_message = f"Retry Claude session for {len(pending)} unresolved violation(s)"
    else:
        session_message = (
            f"Starting Claude remediator session for {len(pending)} pending violation(s)"
            + (" and pathway compatibility" if compatibility_scope else "")
        )
    start_entry = build_log_entry(
        tracker.public_job_id(transformation_id),
        message=session_message,
        icon="play",
    )
    tracker.add_log_entry(
        transformation_id,
        "INFO",
        start_entry["message"],
        icon=start_entry["icon"],
    )

    async def _drain() -> None:
        async for message in _iter_sdk_messages(prompt, options):
            if isinstance(message, ResultMessage):
                session_result.session_id = message.session_id
                session_result.subtype = message.subtype
                session_result.result_text = message.result
                session_result.total_cost_usd = message.total_cost_usd
                session_result.success = _result_message_is_success(message)
                if not session_result.success:
                    session_result.error_message = _result_message_error_detail(message)

    try:
        try:
            await _drain()
        except Exception as exc:
            if _is_initialize_timeout(exc):
                logger.warning(
                    "CLI initialize timeout for MSSQL App+DB %s; retrying once",
                    transformation_id,
                )
            elif _is_transient_cli_result_crash(exc):
                # Known claude-agent-sdk/CLI quirk: the final result message
                # can be tagged ``is_error=True`` with ``subtype="success"``
                # and no structured errors, which the SDK surfaces as a
                # ProcessError after the turn already finished. The CLI
                # process has exited either way, so retry the whole session
                # once rather than losing every edit made before the crash.
                logger.warning(
                    "Transient Claude CLI result error for MSSQL App+DB %s (%s); retrying once",
                    transformation_id,
                    exc,
                )
            else:
                raise
            _kill_orphaned_claude_clis(checkout)
            await asyncio.sleep(_INITIALIZE_RETRY_SLEEP_SECONDS)
            await _drain()
    except Exception as exc:
        logger.exception("MSSQL App+DB remediator session failed for %s", transformation_id)
        session_result.error_message = str(exc)
    finally:
        _kill_orphaned_claude_clis(checkout)

    return session_result
