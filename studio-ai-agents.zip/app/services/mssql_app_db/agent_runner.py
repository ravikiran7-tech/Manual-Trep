"""MSSQL App+DB Claude remediator session."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from app.core.config import get_settings
from app.services.mssql_app_db.file_ops import relative_to_root, scan_codebase
from app.services.mssql_app_db.pathways import (
    compatibility_change_reason,
    compatibility_instructions,
)
from app.services.oracle_pg.app_db_change.progress_tracker import get_progress_tracker
from app.services.mssql_app_db.source_profile import normalize_project_type
from app.services.oracle_pg.agent_runner import (
    SessionResult,
    _apply_stream_close_timeout_env,
    _cli_stderr_logger,
    _is_initialize_timeout,
    _iter_sdk_messages,
    _kill_orphaned_claude_clis,
)


def _result_message_is_success(message: Any) -> bool:
    if getattr(message, "is_error", False):
        return False
    if message.subtype != "success":
        return False
    text = (message.result or "").lower()
    if any(
        marker in text
        for marker in (
            "authentication failed",
            "explicit deny",
            "accessdenied",
            "bedrock:invokemodel",
        )
    ):
        return False
    return True


def _result_message_error_detail(message: Any) -> str:
    errors = getattr(message, "errors", None) or []
    if errors:
        return "; ".join(str(e) for e in errors)
    status = getattr(message, "api_error_status", None)
    detail = message.result or message.subtype or "agent session failed"
    if status:
        return f"{detail} (HTTP {status})"
    return detail
from app.services.oracle_pg.live_logs import build_log_entry, format_post_tool_use

logger = logging.getLogger(__name__)
settings = get_settings()

_INITIALIZE_RETRY_SLEEP_SECONDS = 2


def render_remediator_prompt(*, plan: Dict[str, Any], project_path: str) -> str:
    pending = [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]
    catalog = ((plan.get("catalogSubset") or {}).get("rules")) or []
    pathway = str(plan.get("pathway") or "M-Upgrade")
    project_type = str(plan.get("projectType") or "java")
    profile = plan.get("languageProfile") or "MSSQL-Java"
    excerpt = {
        "projectPath": project_path,
        "pathway": pathway,
        "projectType": project_type,
        "violations": pending,
        "rules": catalog,
    }
    compatibility_scope = compatibility_instructions(pathway, project_type)
    file_scope = (
        "- Edit ONLY the files listed in the plan violations.\n"
        if not compatibility_scope
        else "- Edit plan files plus only the pathway compatibility files described below.\n"
    )
    project_root = Path(project_path)
    compatibility_files = [
        relative_path
        for path in scan_codebase(project_path, project_type=project_type)
        if (relative_path := relative_to_root(path, project_root))
        and compatibility_change_reason(relative_path, pathway, project_type)
    ]
    pathway_section = (
        (
            "\n## Required pathway compatibility work\n"
            f"{compatibility_scope}\n"
            "Existing compatibility files discovered in this checkout:\n"
            + (
                "\n".join(f"- {file_path}" for file_path in compatibility_files)
                if compatibility_files
                else "- None"
            )
            + "\nComplete this inspection even after all plan violations are fixed.\n"
        )
        if compatibility_scope
        else ""
    )
    lang = "C#" if normalize_project_type(project_type) == "csharp" else "Java"
    return f"""You are an expert {lang} developer specializing in Microsoft SQL Server to PostgreSQL application migration.

## Role
Transform the checked-out application at the NFS code path below. Apply every
pending violation from the dependency-resolution plan using the remediation
text from the {profile} knowledge base.

## Constraints
- Work only under: {project_path}
{file_scope.rstrip()}
- Prefer Read/Edit for surgical changes at the given beginLine/endLine.
- Preserve style. Only change MSSQL/SQL Server-specific logic.
- Do not use git. Do not commit. Do not write post_transformation_report.json
  (deterministic packaging writes that file after this session).
{pathway_section}
## Plan (apply every pending violation)
{json.dumps(excerpt, indent=2)}

## Expected result
Updated source files on the checkout for each pending violation, plus every
required MSSQL-to-PostgreSQL pathway compatibility update described above.
For each pending violation, apply that item's remediationText to its file and
lines. When oldCode and newCode are present, use them as the change. Do not
invent a different fix. When a remediation cannot be applied safely, leave
the file unchanged for that item.
"""


def _build_app_db_options(checkout: Path, transformation_id: str) -> Any:
    from claude_agent_sdk import ClaudeAgentOptions

    _apply_stream_close_timeout_env()
    opts = ClaudeAgentOptions(
        cwd=str(checkout),
        model="sonnet",
        permission_mode="acceptEdits",
        setting_sources=[],
        allowed_tools=["Read", "Write", "Edit", "Glob", "Grep"],
        max_turns=settings.oracle_pg_agent.max_turns_per_session,
        max_budget_usd=settings.oracle_pg_agent.max_budget_usd_per_session,
        max_buffer_size=settings.oracle_pg_agent.max_buffer_size_bytes,
        env=settings.oracle_pg_agent.bedrock_env(settings.bedrock.region),
        hooks=_make_app_db_hooks(transformation_id, checkout),
        stderr=_cli_stderr_logger(transformation_id),
    )
    if settings.oracle_pg_agent.cli_path:
        opts.cli_path = settings.oracle_pg_agent.cli_path
    return opts


def _make_app_db_hooks(transformation_id: str, checkout: Path) -> Optional[dict]:
    try:
        from claude_agent_sdk import HookMatcher
    except ImportError:
        return None

    tracker = get_progress_tracker()

    async def on_tool_use(
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input") or {}
        public_job_id = tracker.public_job_id(transformation_id)
        log_entry = format_post_tool_use(
            public_job_id,
            tool_name,
            tool_input,
            job_root=checkout,
        )
        if log_entry:
            tracker.add_log_entry(
                transformation_id,
                "INFO",
                log_entry["message"],
                icon=log_entry["icon"],
            )
        return {}

    return {
        "PostToolUse": [
            HookMatcher(matcher="Write", hooks=[on_tool_use]),
            HookMatcher(matcher="Edit", hooks=[on_tool_use]),
            HookMatcher(matcher="Read", hooks=[on_tool_use]),
            HookMatcher(matcher="Glob", hooks=[on_tool_use]),
            HookMatcher(matcher="Grep", hooks=[on_tool_use]),
        ],
    }


async def run_app_db_remediator_session(
    *,
    transformation_id: str,
    checkout: Path,
    plan: Dict[str, Any],
) -> SessionResult:
    try:
        from claude_agent_sdk.types import ResultMessage
    except ImportError as exc:
        return SessionResult(
            success=False,
            error_message=f"claude-agent-sdk not installed: {exc}",
        )

    pathway = str(plan.get("pathway") or "M-Upgrade")
    project_type = str(plan.get("projectType") or "java")
    pending = [
        v
        for v in (plan.get("violations") or [])
        if str(v.get("status") or "").lower() == "pending" and v.get("file")
    ]
    compatibility_scope = compatibility_instructions(pathway, project_type)
    if not pending and not compatibility_scope:
        return SessionResult(success=True, result_text="No pending violations")

    prompt = render_remediator_prompt(plan=plan, project_path=str(checkout))
    options = _build_app_db_options(checkout, transformation_id)
    session_result = SessionResult(success=False)
    tracker = get_progress_tracker()
    session_message = (
        f"Starting Claude remediator session for {len(pending)} pending violation(s)"
        + (" and pathway compatibility" if compatibility_scope else "")
    )
    start_entry = build_log_entry(
        tracker.public_job_id(transformation_id),
        message=session_message,
        icon="play",
    )
    tracker.add_log_entry(
        transformation_id,
        "INFO",
        start_entry["message"],
        icon=start_entry["icon"],
    )

    async def _drain() -> None:
        async for message in _iter_sdk_messages(prompt, options):
            if isinstance(message, ResultMessage):
                session_result.session_id = message.session_id
                session_result.subtype = message.subtype
                session_result.result_text = message.result
                session_result.total_cost_usd = message.total_cost_usd
                session_result.success = _result_message_is_success(message)
                if not session_result.success:
                    session_result.error_message = _result_message_error_detail(message)

    try:
        try:
            await _drain()
        except Exception as exc:
            if not _is_initialize_timeout(exc):
                raise
            logger.warning(
                "CLI initialize timeout for MSSQL App+DB %s; retrying once",
                transformation_id,
            )
            _kill_orphaned_claude_clis(checkout)
            await asyncio.sleep(_INITIALIZE_RETRY_SLEEP_SECONDS)
            await _drain()
    except Exception as exc:
        logger.exception("MSSQL App+DB remediator session failed for %s", transformation_id)
        session_result.error_message = str(exc)
    finally:
        _kill_orphaned_claude_clis(checkout)

    return session_result
