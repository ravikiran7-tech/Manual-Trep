"""MSSQL App+DB Job 3 orchestrator."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

from app.services.mssql_app_db.agent_runner import run_app_db_remediator_session
from app.services.mssql_app_db.literal_edits import (
    apply_literal_remediations,
    related_configuration_files,
    violation_accepts_config_file_changes,
)
from app.services.mssql_app_db.checkout_path import resolve_visible_checkout
from app.services.mssql_app_db.file_ops import (
    diff_snapshot,
    matches_plan_file,
    normalize_violation_paths_in_plan,
    plan_file_exists_under_checkout,
    snapshot_files,
)
from app.services.mssql_app_db.input_adapter import (
    STATUS_FAILED,
    STATUS_PENDING,
    build_and_write_plan,
    load_dependency_resolution_plan,
    write_dependency_resolution_plan,
)
from app.services.mssql_app_db.pathways import compatibility_change_reason, compatibility_instructions
from app.services.mssql_app_db.pathways import normalize_mssql_pathway
from app.services.oracle_pg.app_db_change.progress_tracker import (
    MILESTONE_ARTIFACTS,
    MILESTONE_FINAL,
    STATUS_COMPLETED,
    STATUS_FAILED as OVERALL_FAILED,
    STATUS_IN_PROGRESS,
    get_progress_tracker,
)
from app.services.mssql_app_db.report_packager import (
    build_post_transformation_report,
    finalize_report_timing,
    write_post_transformation_report,
)
from app.services.mssql_app_db.source_profile import (
    default_dependency_findings_filename,
    default_rules_remediation_filename,
    SOURCE_MSSQL,
)
from app.services.oracle_pg.app_db_change import artifacts as artifact_ops
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.pathways import PATHWAY_UPGRADE

logger = logging.getLogger(__name__)

_MAX_REMEDIATION_ATTEMPTS = 3


def _changed_files(before: dict, checkout: str, project_type: str) -> List[str]:
    return [
        rel
        for rel in diff_snapshot(before, snapshot_files(checkout, project_type=project_type))
        if not rel.endswith(".bak")
    ]


def _violation_change(item: Dict[str, Any]) -> Dict[str, Any]:
    rule = str(item.get("ruleName") or item.get("ruleId") or "Rule")
    text = str(item.get("remediationText") or "").strip()
    change: Dict[str, Any] = {"reason": f"{rule} — {text}" if text else rule}
    line = item.get("beginLine")
    if line:
        change["line"] = line
    return change


def _classify_changes(
    changed: List[str],
    pending: List[Dict[str, Any]],
    pathway: str,
    project_type: str,
    checkout: Path,
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    applied: List[Dict[str, Any]] = []
    compat_applied: List[Dict[str, Any]] = []
    for rel in changed:
        matches = [
            item
            for item in pending
            if item.get("file")
            and matches_plan_file(rel, str(item.get("file")), checkout=checkout)
        ]
        compat_reason = None if matches else compatibility_change_reason(rel, pathway, project_type)
        if matches:
            changes = [_violation_change(item) for item in matches]
        else:
            changes = [
                {
                    "reason": (
                        compat_reason or "AI-applied MSSQL→PostgreSQL dependency change"
                    )
                }
            ]
        entry = {
            "file": rel,
            "changes": changes,
            "violations_fixed": [],
        }
        applied.append(entry)
        if compat_reason:
            compat_applied.append(entry)
    return applied, compat_applied


def _violation_file_matched(
    item: Dict[str, Any],
    changed_set: set[str],
    checkout: Path,
    project_type: str,
) -> bool:
    file_path = str(item.get("file") or "").replace("\\", "/")
    if any(matches_plan_file(c, file_path, checkout=checkout) for c in changed_set):
        return True
    if not violation_accepts_config_file_changes(item):
        return False
    config_paths = set(related_configuration_files(checkout, project_type))
    return any(c in config_paths for c in changed_set)


def _mark_violation_outcomes(
    pending: List[Dict[str, Any]],
    changed_set: set[str],
    applied: List[Dict[str, Any]],
    checkout: Path,
    skip_llm: bool,
    project_type: str,
) -> None:
    checkout_root = checkout
    for item in pending:
        if str(item.get("status") or "").lower() == "resolved":
            continue
        file_path = str(item.get("file") or "").replace("\\", "/")
        matched = _violation_file_matched(item, changed_set, checkout_root, project_type)
        if matched:
            item["status"] = "resolved"
            item["reason"] = None
            for entry in applied:
                if entry["file"] in (file_path,) or file_path.endswith(entry["file"]) or entry[
                    "file"
                ].endswith(Path(file_path).name):
                    fixed = list(entry.get("violations_fixed") or [])
                    rid = item.get("ruleId")
                    if rid and rid not in fixed:
                        fixed.append(rid)
                    entry["violations_fixed"] = fixed
        elif skip_llm:
            item["status"] = STATUS_FAILED
            item["reason"] = "Claude session skipped (skipLlm=true)"
        else:
            item["status"] = STATUS_FAILED
            item["reason"] = item.get("reason") or "No file change detected for this violation"


def _plan_to_outcomes(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    outcomes: List[Dict[str, Any]] = []
    for item in plan.get("violations") or []:
        status = str(item.get("status") or "").lower()
        mapped = "RESOLVED" if status == "resolved" else "FAILED"
        outcomes.append(
            {
                "rule_id": item.get("ruleId"),
                "rule_name": item.get("ruleName"),
                "file": item.get("file"),
                "status": mapped,
                "reason": item.get("reason"),
                "category": item.get("category"),
            }
        )
    return outcomes


class MssqlAppDbOrchestrator:
    def __init__(self, job_manager: Any = None) -> None:
        self._job_manager = job_manager
        self.tracker = get_progress_tracker()

    async def run(self, folder_key: str) -> None:
        config = self._load_job_config(folder_key)
        if not config:
            logger.error("Missing job_config.json for MSSQL App+DB folder %s", folder_key)
            return
        tid = str(config.get("transformationId") or "")
        try:
            await self._run_phases(folder_key, config, tid)
        except Exception as exc:
            logger.exception("MSSQL App+DB transformation %s failed", tid)
            if tid:
                self.tracker.mark_failed(tid, str(exc))
                try:
                    self._write_failed_report(folder_key, config, tid, str(exc))
                except Exception:  # noqa: BLE001
                    logger.warning("Could not write failed report for %s", tid)
        finally:
            if self._job_manager is not None:
                self._job_manager.clear_running(folder_key)

    def _load_job_config(self, folder_key: str) -> Dict[str, Any]:
        path = ws.job_config_path(folder_key)
        if not path.is_file():
            return {}
        try:
            import json

            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def _log(self, tid: str, level: str, message: str) -> None:
        self.tracker.add_log_entry(tid, level, message)

    @staticmethod
    def _store_project_path(folder_key: str, config: Dict[str, Any]) -> None:
        import json

        path = ws.job_config_path(folder_key)
        path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    async def _run_phases(self, folder_key: str, config: Dict[str, Any], tid: str) -> None:
        checkout = Path(str(config.get("projectPath") or ""))
        pathway = normalize_mssql_pathway(str(config.get("pathway") or PATHWAY_UPGRADE))
        project_type = str(config.get("projectType") or "java")
        skip_llm = bool(config.get("skipLlm"))
        rule_scope = str(config.get("ruleScope") or "all")
        selected_rules = list(config.get("selectedRules") or [])

        self.tracker.update_milestone(tid, 1, STATUS_IN_PROGRESS)
        self._log(tid, "INFO", "Loading dependency findings and remediation rules")
        requested = str(checkout)
        resolved = resolve_visible_checkout(
            requested,
            app_id=str(config.get("appId") or ""),
            tenant_id=config.get("tenantId"),
            plan_id=config.get("planId"),
        )
        if resolved != requested:
            self._log(tid, "INFO", f"NFS checkout is {resolved}")
            config["projectPath"] = resolved
            checkout = Path(resolved)
            self._store_project_path(folder_key, config)

        input_paths = config.get("inputPaths") or {}
        findings_name = (
            input_paths.get("dependencyFindings")
            or default_dependency_findings_filename(SOURCE_MSSQL, project_type)
        )
        rules_name = (
            input_paths.get("rulesRemediation")
            or default_rules_remediation_filename(SOURCE_MSSQL, project_type)
        )
        findings_path = ws.resolve_input_file(
            folder_key, findings_name, label="inputPaths.dependencyFindings"
        )
        catalog_path = ws.resolve_input_file(
            folder_key, rules_name, label="inputPaths.rulesRemediation"
        )
        plan, plan_file = build_and_write_plan(
            db_id=folder_key,
            app_id=str(config.get("appId") or ""),
            findings_path=findings_path,
            catalog_path=catalog_path,
            pathway=pathway,
            project_path=str(checkout),
            project_type=project_type,
            rule_scope=rule_scope,
            selected_rules=selected_rules,
        )
        path_notes = normalize_violation_paths_in_plan(plan, checkout)
        if path_notes:
            write_dependency_resolution_plan(folder_key, plan)
            for note in path_notes[:10]:
                self._log(tid, "INFO", note)
        pending = [
            v
            for v in (plan.get("violations") or [])
            if str(v.get("status") or "").lower() == STATUS_PENDING
        ]
        missing_on_disk = [
            str(v.get("file"))
            for v in pending
            if v.get("file") and not plan_file_exists_under_checkout(checkout, str(v.get("file")))
        ]
        if missing_on_disk:
            self._log(
                tid,
                "WARN",
                f"{len(missing_on_disk)} plan file(s) missing under checkout "
                f"(Claude cannot remediate): {', '.join(missing_on_disk[:5])}",
            )
        failed_pre = [
            v
            for v in (plan.get("violations") or [])
            if str(v.get("status") or "").lower() == STATUS_FAILED
        ]
        self.tracker.update_metrics(
            tid,
            violationsFound=len(plan.get("violations") or []),
            rulesProcessed=len(
                {str(v.get("ruleId") or "") for v in (plan.get("violations") or []) if v.get("ruleId")}
            ),
            violationsFailed=len(failed_pre),
        )
        self._log(
            tid,
            "INFO",
            f"Wrote {plan_file.name} from {Path(catalog_path).name}: "
            f"{len(pending)} pending, {len(failed_pre)} pre-failed",
        )
        self.tracker.update_milestone(tid, 1, STATUS_COMPLETED)

        self.tracker.update_milestone(tid, 2, STATUS_IN_PROGRESS)
        applied: List[Dict[str, Any]] = []
        compat_applied: List[Dict[str, Any]] = []
        compat_scope = compatibility_instructions(pathway, project_type)
        changed: List[str] = []
        if skip_llm:
            self._log(tid, "INFO", "skipLlm=true; skipping Claude remediator session")
            for item in pending:
                item["status"] = STATUS_FAILED
                item["reason"] = "Claude session skipped (skipLlm=true)"
        elif pending or compat_scope:
            snapshot_before = snapshot_files(str(checkout), project_type=project_type)
            for attempt in range(_MAX_REMEDIATION_ATTEMPTS):
                unresolved = [
                    v
                    for v in pending
                    if str(v.get("status") or "").lower() not in ("resolved",)
                ]
                if not unresolved and attempt > 0:
                    break
                if attempt > 0:
                    for item in unresolved:
                        if "No file change detected" in str(item.get("reason") or ""):
                            item["status"] = STATUS_PENDING
                            item["reason"] = None
                    self._log(
                        tid,
                        "INFO",
                        f"Retry Claude pass ({attempt + 1}/{_MAX_REMEDIATION_ATTEMPTS}) "
                        f"for {len(unresolved)} unresolved violation(s)",
                    )
                for note in apply_literal_remediations(
                    checkout, pending, project_type=project_type
                ):
                    self._log(tid, "INFO", note)
                delta_literal = _changed_files(snapshot_before, str(checkout), project_type)
                if delta_literal:
                    changed = list(dict.fromkeys([*changed, *delta_literal]))
                    snapshot_before = snapshot_files(str(checkout), project_type=project_type)
                retry_session = attempt > 0
                if attempt == 0:
                    self._log(tid, "INFO", "Calling Claude Agent SDK for application remediations")
                result = await run_app_db_remediator_session(
                    transformation_id=tid,
                    checkout=checkout,
                    plan=plan,
                    retry=retry_session,
                )
                if not result.success:
                    raise RuntimeError(result.error_message or "Claude remediator session failed")
                delta_claude = _changed_files(snapshot_before, str(checkout), project_type)
                if delta_claude:
                    changed = list(dict.fromkeys([*changed, *delta_claude]))
                snapshot_before = snapshot_files(str(checkout), project_type=project_type)
                applied, compat_applied = _classify_changes(
                    changed, pending, pathway, project_type, checkout
                )
                _mark_violation_outcomes(
                    pending, set(changed), applied, checkout, skip_llm, project_type
                )
                remaining = [
                    v
                    for v in pending
                    if str(v.get("status") or "").lower() == STATUS_FAILED
                    and "No file change detected" in str(v.get("reason") or "")
                ]
                if not remaining:
                    break
                if attempt == 0 and not changed:
                    self._log(
                        tid,
                        "WARN",
                        "Claude session completed with 0 modified files under checkout; "
                        f"{len(pending)} pending violation(s) will be marked failed unless "
                        "paths match after a silent edit",
                    )
            self._log(tid, "INFO", "Claude remediator session(s) finished")
        else:
            self._log(tid, "INFO", "No pending violations; skipping remediator session")
            applied, compat_applied = _classify_changes(
                changed, pending, pathway, project_type, checkout
            )

        write_dependency_resolution_plan(folder_key, plan)
        resolved = sum(
            1 for v in (plan.get("violations") or []) if str(v.get("status")).lower() == "resolved"
        )
        failed = sum(
            1 for v in (plan.get("violations") or []) if str(v.get("status")).lower() == STATUS_FAILED
        )
        self.tracker.update_metrics(
            tid,
            violationsResolved=resolved,
            violationsFailed=failed,
            filesModified=len(applied),
            pgCompatibilityChanges=len(compat_applied),
        )
        self.tracker.update_milestone(tid, 2, STATUS_COMPLETED)

        self.tracker.update_milestone(tid, 3, STATUS_IN_PROGRESS)
        self._log(
            tid,
            "INFO",
            f"PostgreSQL compatibility changes applied: {len(compat_applied)}",
        )
        self.tracker.update_milestone(tid, 3, STATUS_COMPLETED)

        self.tracker.update_milestone(tid, MILESTONE_ARTIFACTS, STATUS_IN_PROGRESS)
        self._log(tid, "INFO", "Generating post_transformation_report.json")
        outcomes = _plan_to_outcomes(plan)
        timing = self.tracker.get_timing(tid)
        metrics = (self.tracker.get_progress(tid).get("metrics") or {})
        report = build_post_transformation_report(
            transformation_id=tid,
            app_id=str(config.get("appId") or ""),
            db_id=str(config.get("dbId") or folder_key),
            pathway=pathway,
            nfs_mount_path=str(checkout),
            app_name=config.get("appName"),
            db_name=config.get("dbName"),
            source_database_version=config.get("sourceDatabaseVersion"),
            pg_version=str(config.get("targetDatabaseVersion") or "15.0"),
            project_type=project_type,
            schema_file_path=config.get("schemaFilePath"),
            overall_status=STATUS_COMPLETED,
            files_scanned=int(metrics.get("filesScanned") or 0),
            violations_found=len(plan.get("violations") or []),
            skipped_targets=failed,
            applied_changes=applied,
            violation_outcomes=outcomes,
            compat_applied=compat_applied,
            cicd_findings=[],
            timing=timing,
            target_branch=config.get("targetBranch"),
            repository_url=config.get("repositoryUrl"),
        )
        write_post_transformation_report(report, nfs_mount_path=str(checkout))
        try:
            artifact_ops.build_modified_files_zip(tid, report)
        except Exception:  # noqa: BLE001
            logger.warning("Could not package modified-files ZIP for %s", tid)

        nfs_file = ws.reports_dir(folder_key) / "post_transformation_report.json"
        self.tracker.set_report(
            tid,
            path=str(nfs_file),
            file_size_bytes=nfs_file.stat().st_size if nfs_file.is_file() else None,
        )
        self._log(tid, "INFO", f"Wrote artifact {nfs_file}")

        self.tracker.update_milestone(tid, MILESTONE_ARTIFACTS, STATUS_COMPLETED)
        self.tracker.update_milestone(tid, MILESTONE_FINAL, STATUS_IN_PROGRESS)
        self.tracker.update_milestone(tid, MILESTONE_FINAL, STATUS_COMPLETED)
        timing = self.tracker.get_timing(tid)
        finalize_report_timing(
            tid,
            started_at=timing.get("startedAt"),
            completed_at=timing.get("completedAt"),
        )
        self._log(tid, "INFO", "Transformation completed")

    def _write_failed_report(
        self, folder_key: str, config: Dict[str, Any], tid: str, error: str
    ) -> None:
        plan = load_dependency_resolution_plan(folder_key) or {"violations": []}
        checkout = str(config.get("projectPath") or "")
        report = build_post_transformation_report(
            transformation_id=tid,
            app_id=str(config.get("appId") or ""),
            db_id=str(config.get("dbId") or folder_key),
            pathway=str(config.get("pathway") or PATHWAY_UPGRADE),
            nfs_mount_path=checkout,
            overall_status=OVERALL_FAILED,
            violations_found=len(plan.get("violations") or []),
            violation_outcomes=_plan_to_outcomes(plan),
            applied_changes=[],
        )
        write_post_transformation_report(report, nfs_mount_path=checkout)
