"""Deterministic KB and pattern edits before / between Claude passes."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from app.services.mssql_app_db.source_profile import PROJECT_JAVA, normalize_project_type

_CONFIG_GLOBS_JAVA = (
    "**/*.properties",
    "**/persistence.xml",
    "**/application*.yml",
    "**/application*.yaml",
)

_RULE_PATTERN_SUBSTITUTIONS: Dict[str, Sequence[Tuple[str, str]]] = {
    "sql-java-013": (
        ("jdbc:sqlserver:", "jdbc:postgresql:"),
        ("jdbc:sqlserver", "jdbc:postgresql"),
        ("com.microsoft.sqlserver.jdbc.SQLServerDriver", "org.postgresql.Driver"),
    ),
    "sql-java-145": (
        ("VARBINARY", "BYTEA"),
        ("Types.VARBINARY", "Types.BINARY"),
    ),
}


def related_configuration_files(checkout: Path, project_type: str) -> List[str]:
    if normalize_project_type(project_type) != PROJECT_JAVA or not checkout.is_dir():
        return []
    found: List[str] = []
    for pattern in _CONFIG_GLOBS_JAVA:
        for path in checkout.glob(pattern):
            if not path.is_file() or path.name.endswith(".bak"):
                continue
            try:
                found.append(path.relative_to(checkout.resolve()).as_posix())
            except ValueError:
                continue
    return sorted(set(found))


def violation_accepts_config_file_changes(item: Dict[str, Any]) -> bool:
    rule_id = str(item.get("ruleId") or "")
    rule_name = str(item.get("ruleName") or "").lower()
    return rule_id == "sql-java-013" or "properties" in rule_name


def _edit_targets(
    checkout: Path,
    item: Dict[str, Any],
    project_type: str,
) -> List[Path]:
    targets: List[Path] = []
    rel = item.get("file")
    if rel:
        targets.append(checkout / str(rel).replace("\\", "/"))
    if violation_accepts_config_file_changes(item):
        for cfg in related_configuration_files(checkout, project_type):
            targets.append(checkout / cfg)
    return [p for p in targets if p.is_file()]


def _apply_substitutions(text: str, pairs: Sequence[Tuple[str, str]]) -> tuple[str, bool]:
    updated = text
    touched = False
    for old, new in pairs:
        if old in updated:
            updated = updated.replace(old, new)
            touched = True
    return updated, touched


def apply_literal_remediations(
    checkout: Path,
    pending: List[Dict[str, Any]],
    *,
    project_type: str = "java",
) -> List[str]:
    """Replace KB oldCode/newCode and known JDBC/type patterns when present on disk."""
    notes: List[str] = []
    if not checkout.is_dir():
        return notes
    for item in pending:
        if str(item.get("status") or "").lower() != "pending":
            continue
        rule = str(item.get("ruleId") or item.get("ruleName") or "rule")
        old = str(item.get("oldCode") or "").strip()
        new = str(item.get("newCode") or "").strip()
        pattern_pairs = _RULE_PATTERN_SUBSTITUTIONS.get(str(item.get("ruleId") or ""), ())
        for path in _edit_targets(checkout, item, project_type):
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                continue
            updated = text
            touched = False
            if old and new and old in updated:
                updated = updated.replace(old, new)
                touched = True
            if pattern_pairs:
                updated, sub_touched = _apply_substitutions(updated, pattern_pairs)
                touched = touched or sub_touched
            if touched and updated != text:
                path.write_text(updated, encoding="utf-8")
                rel = path.relative_to(checkout.resolve()).as_posix()
                notes.append(f"{rule} literal edit on {rel}")
    return notes
