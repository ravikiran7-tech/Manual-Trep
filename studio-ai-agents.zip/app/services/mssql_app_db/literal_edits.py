"""Deterministic KB and pattern edits before / between Claude passes."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from app.services.mssql_app_db.source_profile import PROJECT_JAVA, normalize_project_type

_CONFIG_GLOBS_JAVA = (
    "**/*.properties",
    "**/persistence.xml",
    "**/application*.yml",
    "**/application*.yaml",
)

_RULE_PATTERN_SUBSTITUTIONS: Dict[str, Sequence[Tuple[str, str]]] = {
    "sql-java-013": (
        ("jdbc:sqlserver:", "jdbc:postgresql:"),
        ("jdbc:sqlserver", "jdbc:postgresql"),
        ("com.microsoft.sqlserver.jdbc.SQLServerDriver", "org.postgresql.Driver"),
    ),
    "sql-java-145": (
        # Order matters: "Types.VARBINARY" and "VARBINARY(MAX)" are more
        # specific superstrings of the bare "VARBINARY" pattern below. A
        # naive substring replace that ran the generic pair first would
        # consume those occurrences first and turn "Types.VARBINARY" into
        # the nonexistent "Types.BYTEA" instead of "Types.BINARY" (BYTEA has
        # no java.sql.Types constant), so the specific pairs must run first.
        ("Types.VARBINARY", "Types.BINARY"),
        ("VARBINARY(MAX)", "BYTEA"),
        ("VARBINARY(max)", "BYTEA"),
        ("VARBINARY", "BYTEA"),
    ),
}


def related_configuration_files(checkout: Path, project_type: str) -> List[str]:
    if normalize_project_type(project_type) != PROJECT_JAVA or not checkout.is_dir():
        return []
    found: List[str] = []
    for pattern in _CONFIG_GLOBS_JAVA:
        for path in checkout.glob(pattern):
            if not path.is_file() or path.name.endswith(".bak"):
                continue
            try:
                found.append(path.relative_to(checkout.resolve()).as_posix())
            except ValueError:
                continue
    return sorted(set(found))


def violation_accepts_config_file_changes(item: Dict[str, Any]) -> bool:
    rule_id = str(item.get("ruleId") or "")
    rule_name = str(item.get("ruleName") or "").lower()
    return rule_id == "sql-java-013" or "properties" in rule_name


def _edit_targets(
    checkout: Path,
    item: Dict[str, Any],
    project_type: str,
) -> List[Path]:
    targets: List[Path] = []
    rel = item.get("file")
    if rel:
        targets.append(checkout / str(rel).replace("\\", "/"))
    if violation_accepts_config_file_changes(item):
        for cfg in related_configuration_files(checkout, project_type):
            targets.append(checkout / cfg)
    return [p for p in targets if p.is_file()]


def _apply_substitutions(text: str, pairs: Sequence[Tuple[str, str]]) -> tuple[str, bool]:
    updated = text
    touched = False
    for old, new in pairs:
        if old and old in updated and old != new:
            updated = updated.replace(old, new)
            touched = True
    return updated, touched


def _csharp_window_pairs(item: Dict[str, Any]) -> List[Tuple[str, str]]:
    """Line-window substitutions for the C# rules selected on the Rules screen.

    Longer tokens come first so ``SqlError`` does not consume ``SqlErrorCollection``
    or ``SqlException``.
    """
    rule_id = str(item.get("ruleId") or "")
    name = str(item.get("ruleName") or "").lower().replace(" ", "")
    pairs: List[Tuple[str, str]] = []
    if "dbo" in name or rule_id == "sql-csharp-0045":
        pairs.extend(
            (
                ("dbo.", ""),
                ("Dbo.", ""),
                ("DBO.", ""),
                ("[dbo].", ""),
                ("[Dbo].", ""),
                ("[DBO].", ""),
                ('"dbo".', ""),
            )
        )
    if "sqlclient" in name or rule_id == "sql-csharp-0014":
        pairs.extend(
            (
                ("Microsoft.Data.SqlClient", "Npgsql"),
                ("System.Data.SqlClient", "Npgsql"),
            )
        )
    if "errorcollection" in name or "sqlerror" in name or rule_id == "sql-csharp-0096":
        pairs.extend(
            (
                ("SqlErrorCollection", "PostgresException"),
                ("SqlError", "PostgresException"),
            )
        )
    if rule_id == "sql-csharp-0088" or ("exception" in name and "sqlclient" not in name):
        pairs.append(("SqlException", "PostgresException"))
    old = item.get("oldCode")
    new = item.get("newCode")
    if isinstance(old, str) and old.strip() and new is not None and str(old) != str(new):
        pairs.append((str(old), str(new)))
    return pairs


def _replace_in_line_window(text: str, item: Dict[str, Any], pairs: Sequence[Tuple[str, str]]) -> tuple[str, bool]:
    """Apply pairs only on this violation's beginLine–endLine, plus two lines of context."""
    begin = item.get("beginLine")
    end = item.get("endLine") or begin
    if not begin or not pairs:
        return text, False
    try:
        begin_i = max(1, int(begin))
        end_i = max(begin_i, int(end))
    except (TypeError, ValueError):
        return text, False
    lines = text.splitlines(keepends=True)
    if not lines:
        return text, False
    start = max(1, begin_i - 2)
    stop = min(len(lines), end_i + 2)
    chunk = "".join(lines[start - 1 : stop])
    updated, touched = _apply_substitutions(chunk, pairs)
    if not touched or updated == chunk:
        return text, False
    return "".join(lines[: start - 1]) + updated + "".join(lines[stop:]), True


def apply_literal_remediations(
    checkout: Path,
    pending: List[Dict[str, Any]],
    *,
    project_type: str = "java",
) -> List[str]:
    """Replace KB oldCode/newCode and known JDBC/type patterns when present on disk."""
    notes: List[str] = []
    if not checkout.is_dir():
        return notes
    for item in pending:
        if str(item.get("status") or "").lower() != "pending":
            continue
        rule = str(item.get("ruleId") or item.get("ruleName") or "rule")
        old = str(item.get("oldCode") or "").strip()
        new = str(item.get("newCode") or "").strip()
        pattern_pairs = _RULE_PATTERN_SUBSTITUTIONS.get(str(item.get("ruleId") or ""), ())
        for path in _edit_targets(checkout, item, project_type):
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                continue
            updated = text
            touched = False
            window_pairs = _csharp_window_pairs(item)
            if window_pairs:
                updated, window_touched = _replace_in_line_window(updated, item, window_pairs)
                touched = window_touched
            if old and new and old in updated:
                updated = updated.replace(old, new)
                touched = True
            if pattern_pairs:
                updated, sub_touched = _apply_substitutions(updated, pattern_pairs)
                touched = touched or sub_touched
            if touched and updated != text:
                path.write_text(updated, encoding="utf-8")
                try:
                    rel = path.resolve().relative_to(checkout.resolve()).as_posix()
                except ValueError:
                    rel = str(item.get("file") or path.name).replace("\\", "/")
                notes.append(f"{rule} literal edit on {rel}")
    return notes
