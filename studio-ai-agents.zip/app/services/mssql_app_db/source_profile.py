"""Source dialect and language profile for MSSQL App+DB Job 3."""
#Start of Selection
from __future__ import annotations

from typing import Any

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)

SOURCE_ORACLE = "oracle"
SOURCE_MSSQL = "mssql"

PROJECT_JAVA = "java"
PROJECT_CSHARP = "csharp"

MSSQL_VIOLATION_MILESTONE = (
    "Remediating MSSQL-language dependency violations in source files"
)

RULE_SCOPES = frozenset({"all", "high_impact", "custom"})


def normalize_source_database(value: Any = None) -> str:
    """Return ``oracle`` or ``mssql``. Empty values stay on the Oracle path."""
    if value is None or str(value).strip() == "":
        return SOURCE_ORACLE
    compact = str(value).strip().lower().replace(" ", "").replace("_", "")
    if compact in {"oracle"}:
        return SOURCE_ORACLE
    if compact in {"mssql", "sqlserver", "microsoftsqlserver", "azuresql"}:
        return SOURCE_MSSQL
    raise ValueError("sourceDialect must be oracle or mssql")


def normalize_project_type(value: Any = None) -> str:
    raw = str(value or PROJECT_JAVA).strip().lower()
    if raw in {"c#", "csharp", "cs"}:
        return PROJECT_CSHARP
    if raw == "dotnet":
        raise ValueError("projectType 'dotnet' is not supported for MSSQL App-DB; use 'csharp'")
    if raw != PROJECT_JAVA:
        raise ValueError(f"projectType '{raw}' is not supported for MSSQL App-DB")
    return PROJECT_JAVA


def normalize_rule_scope(value: Any = None) -> str:
    scope = str(value or "all").strip().lower()
    if scope not in RULE_SCOPES:
        raise ValueError("ruleScope must be one of: all, high_impact, custom")
    return scope


def default_dependency_findings_filename(source_database: str, project_type: str) -> str:
    source = normalize_source_database(source_database)
    project = normalize_project_type(project_type)
    if source == SOURCE_MSSQL and project == PROJECT_CSHARP:
        return FINDINGS_CSHARP_MSSQL
    if source == SOURCE_MSSQL:
        return FINDINGS_JAVA_MSSQL
    raise ValueError("default_dependency_findings_filename requires sourceDialect=mssql")


def default_rules_remediation_filename(source_database: str, project_type: str) -> str:
    source = normalize_source_database(source_database)
    project = normalize_project_type(project_type)
    if source == SOURCE_MSSQL and project == PROJECT_CSHARP:
        return RULES_CSHARP_MSSQL
    if source == SOURCE_MSSQL:
        return RULES_JAVA_MSSQL
    raise ValueError("default_rules_remediation_filename requires sourceDialect=mssql")


def language_profile_label(source_database: str, project_type: str) -> str:
    source = normalize_source_database(source_database)
    project = normalize_project_type(project_type)
    if source == SOURCE_MSSQL and project == PROJECT_CSHARP:
        return "MSSQL-C#"
    if source == SOURCE_MSSQL:
        return "MSSQL-Java"
    return "Oracle-Java"


def violation_milestone_description(source_database: str) -> str:
    if normalize_source_database(source_database) == SOURCE_MSSQL:
        return MSSQL_VIOLATION_MILESTONE
    return "Remediating Oracle-Java dependency violations in source files"


def mssql_progress_milestones(milestones: list) -> list:
    """Copy of the shared milestone list with the MSSQL one-line description.

    The tracker is shared with Oracle and keeps Oracle's sentence in its
    constant. MSSQL responses use the ticket text instead.
    """
    rows = []
    for item in milestones or []:
        row = dict(item)
        if row.get("id") == 2:
            row["description"] = MSSQL_VIOLATION_MILESTONE
        rows.append(row)
    return rows


def is_mssql_config(config: dict[str, Any]) -> bool:
    try:
        return normalize_source_database(config.get("sourceDialect")) == SOURCE_MSSQL
    except ValueError:
        return False
