"""Infer Oracle vs MSSQL App+DB Job 3 from staged ``_claude/`` inputs."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)
from app.services.oracle_pg.app_db_change import workspace as ws

ENGINE_ORACLE = "oracle"
ENGINE_MSSQL = "mssql"

_MSSQL_INPUT_NAMES = frozenset(
    name.lower()
    for name in (
        FINDINGS_JAVA_MSSQL,
        FINDINGS_CSHARP_MSSQL,
        RULES_JAVA_MSSQL,
        RULES_CSHARP_MSSQL,
        "java-mssql-remediation-kb.json",
        "csharp-mssql-remediation-kb.json",
    )
)

_ORACLE_RULES_NAME = "oracle-to-postgresql-rules_remediation.json"
_ORACLE_FINDINGS_NAME = "java-oracle-dependency.json"


def _inputs_filenames(db_id: str) -> set[str]:
    folder = ws.inputs_dir(db_id)
    if not folder.is_dir():
        return set()
    return {p.name.lower() for p in folder.iterdir() if p.is_file()}


def infer_engine_for_db(db_id: str) -> str:
    names = _inputs_filenames(db_id)
    if names & _MSSQL_INPUT_NAMES:
        return ENGINE_MSSQL
    if _ORACLE_RULES_NAME.lower() in names or _ORACLE_FINDINGS_NAME.lower() in names:
        return ENGINE_ORACLE
    return ENGINE_ORACLE


def infer_engine_for_launch(request: Dict[str, Any]) -> str:
    db_id = str(request.get("dbId") or "").strip()
    if not db_id:
        return ENGINE_ORACLE
    input_paths = request.get("inputPaths") or {}
    if isinstance(input_paths, dict):
        for value in input_paths.values():
            if not value:
                continue
            low = str(value).lower()
            if any(marker in low for marker in ("mssql", "sql-java-", "sql-csharp-")):
                return ENGINE_MSSQL
            if "oracle-to-postgresql" in low or "java-oracle" in low:
                return ENGINE_ORACLE

    return infer_engine_for_db(db_id)
