"""Infer Oracle vs MSSQL App+DB Job 3 from staged ``_claude/`` inputs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from app.services.mssql_app_db.constants import (
    FINDINGS_CSHARP_MSSQL,
    FINDINGS_JAVA_MSSQL,
    RULES_CSHARP_MSSQL,
    RULES_JAVA_MSSQL,
)
from app.services.oracle_pg.app_db_change import workspace as ws

ENGINE_ORACLE = "oracle"
ENGINE_MSSQL = "mssql"

_MSSQL_INPUT_NAMES = frozenset(
    name.lower()
    for name in (
        FINDINGS_JAVA_MSSQL,
        FINDINGS_CSHARP_MSSQL,
        RULES_JAVA_MSSQL,
        RULES_CSHARP_MSSQL,
        "java-mssql-remediation-kb.json",
        "csharp-mssql-remediation-kb.json",
    )
)

_ORACLE_RULES_NAME = "oracle-to-postgresql-rules_remediation.json"
_ORACLE_FINDINGS_NAME = "java-oracle-dependency.json"

_MSSQL_TEXT_MARKERS = (
    "sql-java-",
    "sql-csharp-",
    "java-mssql",
    "csharp-mssql",
    "mssql-java",
    "mssql-c#",
    "microsoft sql server",
    "stringtovarchar",
)

_MSSQL_VERSION_TOKENS = ("mssql", "sqlserver", "microsoftsqlserver", "azuresql")


def _inputs_filenames(db_id: str) -> set[str]:
    folder = ws.inputs_dir(db_id)
    if not folder.is_dir():
        return set()
    names: set[str] = set()
    for path in folder.rglob("*"):
        if path.is_file():
            names.add(path.name.lower())
    return names


def _request_says_mssql(request: Dict[str, Any]) -> bool:
    for key in ("sourceDatabaseVersion", "sourceDialect", "sourceDatabase", "databaseType"):
        compact = str(request.get(key) or "").lower().replace(" ", "").replace("_", "").replace("-", "")
        if any(token in compact for token in _MSSQL_VERSION_TOKENS):
            return True
    return False


def _schema_folder_is_mssql(*folder_names: str) -> bool:
    """True when Job 2 for this database was the MSSQL engine.

    The Java package builder still drops Oracle filenames for an MSSQL app.
    The schema job's ``engine`` marker is the source of truth in that case.
    """
    try:
        from app.core.config import get_settings
        from app.services.oracle_pg.workspace import MODERNIZATION_SUBDIR

        root = Path(get_settings().claude_workspace) / MODERNIZATION_SUBDIR
    except Exception:
        return False
    for name in folder_names:
        text = str(name or "").strip()
        if not text or text in {".", ".."} or "/" in text or "\\" in text:
            continue
        path = root / text / "job_config.json"
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict) and str(data.get("engine") or "").lower() == ENGINE_MSSQL:
            return True
    return False


def _staged_json_is_mssql(db_id: str) -> bool:
    folder = ws.inputs_dir(db_id)
    if not folder.is_dir():
        return False
    for path in folder.rglob("*.json"):
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")[:200_000].lower()
        except OSError:
            continue
        if any(marker in text for marker in _MSSQL_TEXT_MARKERS):
            return True
    return False


def infer_engine_for_db(db_id: str) -> str:
    names = _inputs_filenames(db_id)
    if names & _MSSQL_INPUT_NAMES:
        return ENGINE_MSSQL
    if _schema_folder_is_mssql(db_id):
        return ENGINE_MSSQL
    if _staged_json_is_mssql(db_id):
        return ENGINE_MSSQL
    if _ORACLE_RULES_NAME.lower() in names or _ORACLE_FINDINGS_NAME.lower() in names:
        return ENGINE_ORACLE
    return ENGINE_ORACLE


def infer_engine_for_launch(request: Dict[str, Any]) -> str:
    db_id = str(request.get("dbId") or "").strip()
    db_name = str(request.get("dbName") or "").strip()
    if _request_says_mssql(request):
        return ENGINE_MSSQL
    if db_id and _schema_folder_is_mssql(db_id, db_name):
        return ENGINE_MSSQL

    saw_oracle_path = False
    input_paths = request.get("inputPaths") or {}
    if isinstance(input_paths, dict):
        for value in input_paths.values():
            if not value:
                continue
            low = str(value).lower()
            if any(marker in low for marker in ("mssql", "sql-java-", "sql-csharp-")):
                return ENGINE_MSSQL
            if "oracle-to-postgresql" in low or "java-oracle" in low:
                saw_oracle_path = True

    if not db_id:
        return ENGINE_ORACLE
    if _staged_json_is_mssql(db_id):
        return ENGINE_MSSQL
    inferred = infer_engine_for_db(db_id)
    if inferred == ENGINE_MSSQL:
        return ENGINE_MSSQL
    if saw_oracle_path:
        return ENGINE_ORACLE
    return inferred
