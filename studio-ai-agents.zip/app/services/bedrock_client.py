"""
AWS Bedrock client for Claude model invocation.
Replaces Java's ProcessBuilder Claude CLI calls with direct AWS Bedrock API.

Key features:
- Tool use (code_editor, bash) for file editing and command execution
- Streaming responses
- Event normalization to Claude CLI stream-json format
- IAM role auto-detection
- Resilience patterns
"""
import asyncio
import json
import time
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Callable

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from app.core.config import get_settings
from app.core.exceptions import ProviderError, AuthenticationError, RateLimitError
from app.core.resilience import with_resilience, bedrock_circuit_breaker
from app.core.llm_rate_limiter import bedrock_llm_rate_limiter


logger = logging.getLogger(__name__)
settings = get_settings()


class BedrockClient:
    """
    AWS Bedrock client for Claude model invocation.

    Replaces Java's Claude CLI subprocess execution with direct Bedrock API calls.
    Implements tool use for file editing and command execution.
    """

    # Tool definitions equivalent to --allowedTools MultiEdit,Bash
    CODE_EDITOR_TOOL = {
        "toolSpec": {
            "name": "code_editor",
            "description": "Edit, create, or delete files in the codebase. Use patch operation for efficient small changes, write for complete file replacement.",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the file relative to project directory"
                        },
                        "operation": {
                            "type": "string",
                            "enum": ["read", "write", "delete", "patch"],
                            "description": "Operation to perform: read (read file), write (replace entire file), delete (delete file), patch (apply diff-based changes)"
                        },
                        "content": {
                            "type": "string",
                            "description": "Complete file content for write operations (required for write)"
                        },
                        "patch_format": {
                            "type": "string",
                            "enum": ["unified_diff", "line_edits", "structured"],
                            "description": "Patch format for patch operation: unified_diff (standard diff format), line_edits (line-based edits), structured (JSON range-based edits)"
                        },
                        "patch_data": {
                            "type": ["string", "object", "array"],
                            "description": "Patch data (format depends on patch_format). For unified_diff: string with diff text. For line_edits: array of edit objects. For structured: object with edits array."
                        }
                    },
                    "required": ["path", "operation"]
                }
            }
        }
    }

    BASH_TOOL = {
        "toolSpec": {
            "name": "bash",
            "description": "Execute bash commands in the project context. Use this for running builds, tests, and other command-line operations.",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Bash command to execute"
                        },
                        "working_directory": {
                            "type": "string",
                            "description": "Working directory for command execution (optional)"
                        }
                    },
                    "required": ["command"]
                }
            }
        }
    }

    def __init__(
        self,
        region: Optional[str] = None,
        model_id: Optional[str] = None,
        profile: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None
    ):
        """
        Initialize Bedrock client with IAM role auto-detection.

        Args:
            region: AWS region (default from config: us-east-1)
            model_id: Claude model ID (default from config)
            profile: AWS profile name (default: default)
            max_tokens: Maximum tokens (default from config: 64000)
            temperature: Model temperature (default from config: 0.7)

        Raises:
            AuthenticationError: If AWS credentials are not available
            ProviderError: If Bedrock client initialization fails
        """
        self.region = region or settings.bedrock.region
        self.model_id = model_id or settings.bedrock.default_model
        # Use None when no profile set so boto3 auto-detects from ECS Task Role
        raw_profile = profile if profile is not None else settings.bedrock.profile
        self.profile = raw_profile if raw_profile else None
        self.max_tokens = max_tokens or settings.bedrock.max_tokens
        self.temperature = temperature or settings.bedrock.temperature

        logger.info(
            f"Initializing Bedrock client: region={self.region}, "
            f"model={self.model_id}, profile={self.profile}"
        )

        try:
            # Create boto3 session with profile
            session = boto3.Session(
                profile_name=self.profile,
                region_name=self.region
            )

            # Configure boto3 client with custom settings
            # Disable automatic retries - we handle retries via resilience module
            config = Config(
                region_name=self.region,
                retries={'max_attempts': 0},  # We handle retries ourselves
                read_timeout=3600,  # 1 hour for long-running operations
                connect_timeout=60,
                max_pool_connections=50
            )

            # Create Bedrock Runtime client
            self.bedrock_runtime = session.client(
                service_name='bedrock-runtime',
                config=config
            )

            logger.info("Bedrock client initialized successfully")

        except Exception as e:
            error_msg = f"Failed to initialize Bedrock client: {str(e)}"
            logger.error(error_msg)

            if "credentials" in str(e).lower():
                raise AuthenticationError(
                    message=error_msg,
                    details="AWS credentials not found or invalid. Check IAM role or AWS profile configuration."
                )
            else:
                raise ProviderError(
                    message=error_msg,
                    provider="bedrock",
                    details=str(e)
                )

    async def invoke_with_tools(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        process_response: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Invoke Bedrock with tool use capability.

        This method is equivalent to Java's Claude CLI execution with:
        claude -p "<prompt>" --add-dir <project_path> --allowedTools MultiEdit,Bash

        Args:
            prompt: User prompt content
            project_path: Project directory path (for context)
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens (default: from config)
            temperature: Model temperature (default: from config)
            enable_tools: Whether to enable tool use (default: True)

        Returns:
            List of events in normalized format compatible with Claude CLI stream-json

        Raises:
            ProviderError: If Bedrock API call fails
        """
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature

        logger.info(
            f"Invoking Bedrock with tools: project={project_path}, "
            f"max_tokens={effective_max_tokens}, enable_tools={enable_tools}"
        )

        # Build messages
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "text": f"Project directory: {project_path}\n\n{prompt}"
                    }
                ]
            }
        ]

        # Build request body
        request_body = {
            "modelId": self.model_id,
            "messages": messages,
            "inferenceConfig": {
                "maxTokens": effective_max_tokens,
                "temperature": effective_temperature
            }
        }

        # Add system prompt if provided
        if system_prompt:
            request_body["system"] = [{"text": system_prompt}]

        # Add tools if enabled
        if enable_tools:
            request_body["toolConfig"] = {
                "tools": [
                    self.CODE_EDITOR_TOOL,
                    self.BASH_TOOL
                ],
                "toolChoice": {"auto": {}}
            }

        try:
            # Invoke Bedrock (non-streaming) — gated by LLM rate limiter
            logger.debug(f"Bedrock request: modelId={self.model_id}")

            async with bedrock_llm_rate_limiter.acquire(
                estimated_tokens=effective_max_tokens
            ):
                try:
                    response = await self._converse_async(request_body)
                except ClientError as bedrock_err:
                    err_code = bedrock_err.response.get('Error', {}).get('Code', 'Unknown')
                    err_msg = bedrock_err.response.get('Error', {}).get('Message', str(bedrock_err))
                    if err_code in ['ThrottlingException', 'TooManyRequestsException', 'ServiceQuotaExceededException']:
                        raise RateLimitError(
                            message=f"Bedrock rate limit exceeded: {err_msg}",
                            retry_after=60,
                            details=f"Error code: {err_code}"
                        )
                    raise

            # Process response — skip normalization when caller opts out
            if process_response:
                events = await self._process_response(response, project_path)
            else:
                events = [response]

            # Check if tools were requested and execute them
            # Handle multiple turns: execute tools, send results back, execute follow-up tools if needed
            stop_reason = response.get('stopReason', 'end_turn')
            max_follow_up_turns = 5  # Allow more complex transformations (Fix #2)
            follow_up_count = 0
            consecutive_no_tool_turns = 0  # Track consecutive turns without tool requests (Fix #2)
            
            while enable_tools and follow_up_count < max_follow_up_turns:
                # Smart termination: break if stop_reason is end_turn (model finished)
                if stop_reason == "end_turn":
                    logger.info(f"Model completed (stopReason=end_turn) after {follow_up_count} follow-up turns")
                    break
                
                # Only process if tools were requested
                if stop_reason != "tool_use":
                    consecutive_no_tool_turns += 1
                    # Smart termination: break if no tools requested for 2 consecutive turns
                    if consecutive_no_tool_turns >= 2:
                        logger.info(f"Smart termination: No tools requested for {consecutive_no_tool_turns} consecutive turns")
                        break
                    # If first turn without tools, break immediately (no need to continue)
                    break
                else:
                    consecutive_no_tool_turns = 0  # Reset counter when tools are requested
                if follow_up_count == 0:
                    logger.info("Tool use requested in single-turn mode, executing tools")
                else:
                    logger.info(f"Follow-up turn {follow_up_count}: executing tools")
                
                # Extract tool uses from current response (Bedrock format)
                output = response.get('output', {})
                message = output.get('message', {})
                content_blocks = message.get('content', [])
                
                current_tool_use_events = []
                import time
                timestamp = int(time.time() * 1000)
                for content_block in content_blocks:
                    if 'toolUse' in content_block:
                        tool_use = content_block['toolUse']
                        tool_use_id = tool_use.get('toolUseId', '')
                        tool_name = tool_use.get('name', '')
                        tool_input = tool_use.get('input', {})
                        tool_use_event = {
                            "type": "tool_use",
                            "tool": {
                                "toolUseId": tool_use_id,
                                "name": tool_name,
                                "input": tool_input
                            },
                            "timestamp": timestamp
                        }
                        current_tool_use_events.append(tool_use_event)
                        # CRITICAL FIX #1: Preserve tool_use events immediately
                        # Add to events list BEFORE execution so orchestrator can track them
                        events.append(tool_use_event)
                        logger.debug(f"Preserved tool_use event: {tool_name} (ID: {tool_use_id})")
                
                if not current_tool_use_events:
                    break
                
                from app.services.tool_executor import ToolExecutor, format_tool_result_for_model
                from app.core.config import get_settings
                
                settings = get_settings()
                
                # Initialize tool executor
                tool_executor = ToolExecutor(
                    project_path=project_path,
                    working_directory=project_path,
                    timeout=settings.agentic.tool_execution_timeout
                )
                
                # Execute each tool and collect results
                tool_results_content = []
                consecutive_failures = 0  # Fix #7: Track consecutive failures
                max_consecutive_failures = 3  # Stop after 3 consecutive failures
                
                for tool_event in current_tool_use_events:
                    tool = tool_event.get("tool", {})
                    tool_use_id = tool.get("toolUseId", "")
                    tool_name = tool.get("name", "")
                    tool_input = tool.get("input", {})
                    
                    logger.info(f"Executing tool: {tool_name} (ID: {tool_use_id})")
                    
                    # Fix #7: Retry logic with exponential backoff for file writes
                    result = None
                    max_retries = 3
                    retry_delay = 0.5  # Start with 0.5 seconds
                    
                    if tool_name == "code_editor" and tool_input.get("operation") == "write":
                        # Retry file writes with exponential backoff
                        for attempt in range(max_retries):
                            result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                            
                            if result.success:
                                # Fix #3: Verify file writes actually happened
                                file_path = tool_input.get("path", "")
                                if file_path:
                                    import os
                                    from pathlib import Path
                                    
                                    # Convert relative paths to absolute
                                    if not os.path.isabs(file_path):
                                        file_path = os.path.join(project_path, file_path)
                                    file_path = str(Path(file_path).resolve())
                                    
                                    # Verify file exists
                                    if os.path.exists(file_path):
                                        file_stat = os.stat(file_path)
                                        file_size = file_stat.st_size
                                        file_mtime = file_stat.st_mtime
                                        
                                        logger.info(
                                            f"File write verified: {file_path} exists, "
                                            f"size={file_size} bytes, modified={file_mtime}"
                                        )
                                        
                                        # Additional verification: check if file is readable
                                        try:
                                            with open(file_path, 'r', encoding='utf-8') as f:
                                                content_preview = f.read(100)  # Read first 100 chars
                                            logger.debug(f"File content preview (first 100 chars): {content_preview[:100]}")
                                        except Exception as e:
                                            logger.warning(f"Could not read file for verification: {file_path}, error: {e}")
                                        
                                        # Success - break retry loop
                                        break
                                    else:
                                        # File doesn't exist - retry
                                        result.success = False
                                        result.error = f"File write verification failed: file {file_path} does not exist"
                                        logger.warning(
                                            f"File write verification failed (attempt {attempt + 1}/{max_retries}): "
                                            f"{file_path} does not exist"
                                        )
                            
                            # If failed and not last attempt, retry with exponential backoff
                            if not result.success and attempt < max_retries - 1:
                                logger.info(
                                    f"File write failed (attempt {attempt + 1}/{max_retries}), "
                                    f"retrying in {retry_delay}s: {result.error}"
                                )
                                time.sleep(retry_delay)
                                retry_delay *= 2  # Exponential backoff: 0.5s, 1s, 2s
                            else:
                                break
                    else:
                        # Non-file-write operations: execute once without retry
                        result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                    
                    # Fix #7: Track consecutive failures
                    if not result.success:
                        consecutive_failures += 1
                        logger.warning(
                            f"Tool execution failed (consecutive failures: {consecutive_failures}/{max_consecutive_failures}): "
                            f"{tool_name}, error: {result.error}"
                        )
                        
                        if consecutive_failures >= max_consecutive_failures:
                            logger.error(
                                f"Max consecutive failures reached ({consecutive_failures}), "
                                f"stopping tool execution to prevent infinite loops"
                            )
                            # Add error event
                            events.append({
                                "type": "error",
                                "error": f"Max consecutive failures reached ({consecutive_failures}). "
                                        f"Last failure: {tool_name} - {result.error}",
                                "timestamp": timestamp
                            })
                            break
                    else:
                        consecutive_failures = 0  # Reset counter on success
                    
                    # Fix #7: Enhance error messages for model
                    if not result.success:
                        # Provide detailed error context
                        enhanced_error = f"Tool execution failed: {tool_name}"
                        if tool_name == "code_editor":
                            operation = tool_input.get("operation", "")
                            file_path = tool_input.get("path", "")
                            enhanced_error += f"\nOperation: {operation}"
                            if file_path:
                                enhanced_error += f"\nFile path: {file_path}"
                        elif tool_name == "bash":
                            command = tool_input.get("command", "")
                            if command:
                                enhanced_error += f"\nCommand: {command[:100]}"  # First 100 chars
                        
                        enhanced_error += f"\nError details: {result.error}"
                        enhanced_error += f"\nSuggestion: Check file permissions, disk space, or command syntax"
                        
                        result.error = enhanced_error
                        logger.error(f"Enhanced error message: {enhanced_error}")
                    
                    # Format result for model (Bedrock format)
                    tool_result_content = format_tool_result_for_model(tool_use_id, result)
                    tool_results_content.append({
                        "toolResult": {
                            "toolUseId": tool_use_id,
                            "content": [
                                {
                                    "text": tool_result_content.get("content", "")
                                }
                            ]
                        }
                    })
                    
                    # Add tool result event to events list
                    events.append({
                        "type": "tool_result",
                        "tool": {
                            "toolUseId": tool_use_id,
                            "name": tool_name,
                            "result": tool_result_content
                        },
                        "success": result.success,
                        "timestamp": timestamp
                    })
                    
                    logger.info(
                        f"Tool {tool_name} executed: success={result.success}, "
                        f"time={result.execution_time_ms}ms"
                    )
                
                # Build messages for follow-up request (Bedrock format)
                follow_up_messages = []
                
                # Add initial user message (only on first turn)
                if follow_up_count == 0:
                    follow_up_messages.append({
                        "role": "user",
                        "content": [
                            {
                                "text": f"Project directory: {project_path}\n\n{prompt}"
                            }
                        ]
                    })
                
                # Add assistant message with tool uses (from current response)
                assistant_content = []
                for content_block in content_blocks:
                    if 'text' in content_block:
                        assistant_content.append(content_block)
                    elif 'toolUse' in content_block:
                        assistant_content.append(content_block)
                
                if assistant_content:
                    follow_up_messages.append({
                        "role": "assistant",
                        "content": assistant_content
                    })
                
                # Add tool results as user message (Bedrock format)
                follow_up_messages.append({
                    "role": "user",
                    "content": tool_results_content
                })
                
                # Make follow-up request (Bedrock format)
                follow_up_request = {
                    "modelId": self.model_id,
                    "messages": follow_up_messages,
                    "inferenceConfig": {
                        "maxTokens": effective_max_tokens,
                        "temperature": effective_temperature
                    }
                }
                
                if system_prompt:
                    follow_up_request["system"] = [{"text": system_prompt}]
                
                if enable_tools:
                    follow_up_request["toolConfig"] = {
                        "tools": [
                            self.CODE_EDITOR_TOOL,
                            self.BASH_TOOL
                        ],
                        "toolChoice": {"auto": {}}
                    }
                
                logger.info("Sending tool results back to model for follow-up turn")
                async with bedrock_llm_rate_limiter.acquire(
                    estimated_tokens=effective_max_tokens
                ):
                    try:
                        response = await self._converse_async(follow_up_request)
                    except ClientError as bedrock_err:
                        err_code = bedrock_err.response.get('Error', {}).get('Code', 'Unknown')
                        err_msg = bedrock_err.response.get('Error', {}).get('Message', str(bedrock_err))
                        if err_code in ['ThrottlingException', 'TooManyRequestsException', 'ServiceQuotaExceededException']:
                            raise RateLimitError(
                                message=f"Bedrock rate limit exceeded: {err_msg}",
                                retry_after=60,
                                details=f"Error code: {err_code}"
                            )
                        raise
                
                # Process follow-up response and append to events
                follow_up_events = await self._process_response(response, project_path)
                events.extend(follow_up_events)
                
                logger.info(f"Follow-up turn completed: {len(follow_up_events)} additional events")
                
                # Check if model indicated completion in text response (Fix #2: Smart termination)
                completion_indicators = ["done", "complete", "finished", "completed", "all set", "no further"]
                text_content = ""
                output = response.get('output', {})
                message = output.get('message', {})
                for content_block in message.get('content', []):
                    if 'text' in content_block:
                        text_content += content_block.get('text', '').lower()
                
                if any(indicator in text_content for indicator in completion_indicators):
                    logger.info(f"Smart termination: Model indicated completion in text response")
                    break
                
                # Check if follow-up response also requests tools
                stop_reason = response.get('stopReason', 'end_turn')
                follow_up_count += 1

            logger.info("Bedrock invocation completed successfully")
            return events

        except RateLimitError:
            raise  # Already correctly formatted; tenacity retry handles it

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))

            logger.error(f"Bedrock ClientError: {error_code} - {error_message}")

            if error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AuthenticationError(
                    message=f"Bedrock authentication failed: {error_message}",
                    details=f"Error code: {error_code}"
                )
            else:
                raise ProviderError(
                    message=f"Bedrock API error: {error_message}",
                    provider="bedrock",
                    details=f"Error code: {error_code}"
                )

        except Exception as e:
            error_msg = f"Unexpected error during Bedrock invocation: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ProviderError(
                message=error_msg,
                provider="bedrock",
                details=str(e)
            )

    async def _process_response(
        self,
        response: Dict[str, Any],
        project_path: str
    ) -> List[Dict[str, Any]]:
        """
        Process Bedrock response and normalize to Claude CLI format.

        Converts Bedrock converse response to match Java's stream-json format
        expected by existing visualization and parsing services.

        Args:
            response: Bedrock converse response
            project_path: Project path for security validation

        Returns:
            List of normalized events

        Event format transformation:
            Bedrock response structure is converted to event list:
            - {"type": "system", "subtype": "init"}
            - {"type": "assistant", "subtype": "content_start"}
            - {"type": "assistant", "subtype": "text_delta", "text": "..."}
            - {"type": "tool_use", "tool": {...}}
            - {"type": "assistant", "subtype": "content_stop"}
            - {"type": "message_stop", "stop_reason": "..."}
            - {"type": "result", "input_tokens": ..., "output_tokens": ...}
        """
        from app.core.security import SecurityValidator

        events = []
        timestamp = int(time.time() * 1000)

        try:
            # Add init event
            events.append({
                        "type": "system",
                        "subtype": "init",
                        "timestamp": timestamp
            })

            # Extract response components
            output = response.get('output', {})
            message = output.get('message', {})
            content_blocks = message.get('content', [])
            stop_reason = response.get('stopReason', 'end_turn')

            # Get usage information
            usage = response.get('usage', {})
            input_tokens = usage.get('inputTokens', 0)
            output_tokens = usage.get('outputTokens', 0)

            # Process each content block
            for content_block in content_blocks:
                # Content start event
                events.append({
                        "type": "assistant",
                        "subtype": "content_start",
                        "timestamp": timestamp
                })

                # Text content
                if 'text' in content_block:
                    text = content_block['text']
                    events.append({
                            "type": "assistant",
                            "subtype": "text_delta",
                            "text": text,
                            "timestamp": timestamp
                    })

                # Tool use content - SECURITY: Validate tool inputs before adding
                elif 'toolUse' in content_block:
                    tool_use = content_block['toolUse']

                    # Extract tool name and input
                    tool_name = tool_use.get('name', '')
                    tool_input = tool_use.get('input', {})

                    # CRITICAL SECURITY: Validate bash commands
                    if tool_name == 'bash':
                        command = tool_input.get('command', '')
                        if command:
                            try:
                                from app.core.config import get_settings
                                settings = get_settings()

                                # Skip validation if disabled
                                if not settings.security.bash_command_validation_enabled:
                                    logger.warning(f"SECURITY: Bash validation disabled, allowing command: {command[:50]}...")
                                else:
                                    # Validate command with safe pipe and command chain support
                                    validated_command = SecurityValidator.validate_bash_command(
                                        command,
                                        allow_safe_pipes=settings.security.allow_safe_pipes,
                                        allow_safe_command_chains=settings.security.allow_safe_command_chains
                                    )
                                    logger.info(f"Validated bash command: {validated_command[:50]}...")
                            except ValueError as e:
                                # Command validation failed - log and add error event
                                logger.error(f"SECURITY: Rejected unsafe bash command: {e}")
                                events.append({
                                    "type": "error",
                                    "error": f"Security validation failed: {str(e)}",
                                    "timestamp": timestamp
                                })
                                continue

                    # CRITICAL SECURITY: Validate file paths
                    elif tool_name == 'code_editor':
                        file_path = tool_input.get('path', '')
                        if file_path:
                            try:
                                from app.core.config import get_settings
                                settings = get_settings()

                                # Skip validation if disabled
                                if not settings.security.path_traversal_protection_enabled:
                                    logger.warning(f"SECURITY: Path validation disabled, allowing path: {file_path}")
                                else:
                                    # Check for path traversal using improved validation
                                    if '..' in file_path:
                                        raise ValueError(f"Path traversal detected (..): {file_path}")

                                    # Allow absolute paths if they're in approved directories
                                    if file_path.startswith('/'):
                                        if not SecurityValidator.is_safe_absolute_path(
                                            file_path,
                                            project_path,
                                            allowed_dirs=settings.security.get_allowed_directories_list()
                                        ):
                                            raise ValueError(
                                                f"Absolute path outside allowed directories: {file_path}"
                                            )

                                logger.info(f"Validated file path: {file_path}")
                            except ValueError as e:
                                logger.error(f"SECURITY: Rejected unsafe file path: {e}")
                                events.append({
                                    "type": "error",
                                    "error": f"Security validation failed: {str(e)}",
                                    "timestamp": timestamp
                                })
                                continue

                    # Validation passed or not applicable - add tool use event
                    events.append({
                        "type": "tool_use",
                        "tool": {
                            "toolUseId": tool_use.get('toolUseId', ''),
                            "name": tool_name,
                            "input": tool_input
                        },
                        "timestamp": timestamp
                    })

                # Content stop event
                events.append({
                        "type": "assistant",
                        "subtype": "content_stop",
                        "timestamp": timestamp
                })

            # Message stop event
            events.append({
                        "type": "message_stop",
                        "stop_reason": stop_reason,
                        "timestamp": timestamp
            })

            # Final result event (matches Java's stream-json format)
            events.append({
                "type": "result",
                "is_error": False,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "stop_reason": stop_reason,
                "timestamp": timestamp
            })

            return events

        except Exception as e:
            logger.error(f"Error processing Bedrock response: {str(e)}", exc_info=True)
            events.append({
                "type": "error",
                "error": str(e),
                "timestamp": int(time.time() * 1000)
            })
            return events

    async def _converse_async(self, request_body: Dict[str, Any]) -> Dict[str, Any]:
        """Run sync boto3 converse in a thread so the event loop stays responsive."""
        return await asyncio.to_thread(self.bedrock_runtime.converse, **request_body)

    def _map_converse_client_error(self, error: ClientError, iteration: int) -> None:
        """Raise typed errors for Bedrock ClientError responses."""
        error_code = error.response.get("Error", {}).get("Code", "Unknown")
        error_message = error.response.get("Error", {}).get("Message", str(error))
        logger.error(
            "Bedrock ClientError in iteration %s: %s - %s",
            iteration,
            error_code,
            error_message,
        )
        if error_code in ["AccessDeniedException", "UnauthorizedException"]:
            raise AuthenticationError(
                message=f"Bedrock authentication failed: {error_message}",
                details=f"Error code: {error_code}",
            )
        if error_code in [
            "ThrottlingException",
            "TooManyRequestsException",
            "ServiceQuotaExceededException",
        ]:
            raise RateLimitError(
                message=f"Bedrock rate limit exceeded: {error_message}",
                retry_after=60,
                details=f"Error code: {error_code}",
            )
        raise ProviderError(
            message=f"Bedrock API error: {error_message}",
            provider="bedrock",
            details=f"Error code: {error_code}",
        )

    async def _invoke_single_turn_no_tools(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        process_response: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None,
        prepend_project_context: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        One Bedrock call with tools disabled — used for JSON schema generation.
        Avoids the agentic loop, ToolExecutor, and heavy completion instructions.
        """
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature
        user_text = (
            f"Project directory: {project_path}\n\n{prompt}"
            if prepend_project_context
            else prompt
        )
        request_body: Dict[str, Any] = {
            "modelId": self.model_id,
            "messages": [{"role": "user", "content": [{"text": user_text}]}],
            "inferenceConfig": {
                "maxTokens": effective_max_tokens,
                "temperature": effective_temperature,
            },
            "system": [
                {
                    "text": system_prompt
                    or (
                        "Return valid JSON exactly as requested. "
                        "Do not use tools. Output a JSON array only."
                    )
                }
            ],
        }

        started_at_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        logger.info(
            "Single-turn Bedrock call START model=%s max_tokens=%s "
            "prompt_chars=%s prepend_project=%s started_at=%s",
            self.model_id,
            effective_max_tokens,
            len(prompt),
            prepend_project_context,
            started_at_utc,
        )
        started = time.monotonic()
        async with bedrock_llm_rate_limiter.acquire(
            estimated_tokens=effective_max_tokens
        ):
            try:
                response = await self._converse_async(request_body)
            except ClientError as e:
                self._map_converse_client_error(e, iteration=1)

        elapsed = time.monotonic() - started
        completed_at_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        usage = response.get("usage") or {}
        logger.info(
            "Single-turn Bedrock call COMPLETE started_at=%s completed_at=%s "
            "duration_sec=%.2f input_tokens=%s output_tokens=%s stop_reason=%s",
            started_at_utc,
            completed_at_utc,
            elapsed,
            usage.get("inputTokens"),
            usage.get("outputTokens"),
            response.get("stopReason"),
        )

        if process_response:
            events = await self._process_response(response, project_path)
        else:
            events = [response]
        if on_event:
            for event in events:
                on_event(event)
        return events

    def _get_completion_instructions(self, iteration: int, max_iterations: Optional[int] = None, unlimited: bool = False) -> str:
        """
        Generate completion instructions for the model.
        
        Args:
            iteration: Current iteration number (not used, kept for compatibility)
            max_iterations: Maximum iterations allowed (None if unlimited)
            unlimited: Whether unlimited iterations mode is enabled
            
        Returns:
            Completion instructions string
        """
        # Single unified instruction set focusing only on JSON output format
        base_instructions = """
═══════════════════════════════════════════════════════════════════════════════
🚨 MANDATORY FINAL OUTPUT FORMAT - NON-NEGOTIABLE 🚨
═══════════════════════════════════════════════════════════════════════════════

ABSOLUTE REQUIREMENT:
When you complete ALL your operations, you MUST output a JSON response in your final 
text message. This is NOT optional. This is NOT a suggestion. This MUST be done.

FORMAT SPECIFICATION (FOLLOW EXACTLY):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Step 1: Complete all required operations (read files, write files, run commands, etc.)

Step 2: Write your final summary/explanation text

Step 3: Output the JSON response wrapped in triple backticks with 'json' language tag:

```json
{
  ... your JSON output here following the EXACT schema from the prompt ...
}
```

CRITICAL CONSTRAINTS:
✓ Output JSON in your TEXT RESPONSE (conversational message)
✓ Use EXACTLY this format: ```json ... ``` (triple backticks with 'json' tag)
✓ Follow the EXACT JSON schema/structure specified in the original prompt
✓ Use the EXACT field names, types, and structure from the prompt template
✓ JSON must be valid, parseable, and match the prompt's schema
✗ DO NOT use code_editor tool to write JSON to files
✗ DO NOT omit the triple backticks
✗ DO NOT omit the 'json' language tag after opening backticks
✗ DO NOT modify or change the required JSON schema from the prompt
✗ DO NOT add extra fields not specified in the prompt schema
✗ DO NOT skip required fields from the prompt schema

SCHEMA SOURCE - READ CAREFULLY:
The JSON schema/template was provided in your original prompt above. 
Review the prompt to find the exact JSON structure you must output.
Match field names, data types, and structure EXACTLY as specified.

WHY THIS MATTERS:
• The entire system pipeline depends on extracting this JSON from your text response
• JSON parser expects the EXACT schema defined in the prompt
• Without properly formatted JSON output matching the schema, the operation FAILS completely
• This is the ONLY way results are captured, parsed, and returned to the user
• Wrong schema = Parser fails = No results = System failure

VERIFICATION CHECKLIST (before sending end_turn):
□ Have I completed all required operations?
□ Have I reviewed the JSON schema in the original prompt?
□ Have I included JSON in my final text response?
□ Is the JSON wrapped in ```json ... ``` triple backticks with 'json' tag?
□ Does my JSON match the EXACT schema/structure from the prompt?
□ Have I included ALL required fields from the prompt schema?
□ Are ALL field names and types correct per the prompt?

═══════════════════════════════════════════════════════════════════════════════
"""
        return base_instructions

    async def invoke_with_tools_agentic(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        process_response: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None,
        prepend_project_context: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Invoke Bedrock with agentic tool execution (multi-turn conversation).

        This method implements the full agentic loop:
        1. Send initial prompt to model
        2. If model requests tools, execute them
        3. Send results back to model
        4. Repeat until model finishes (stop_reason: end_turn)

        Args:
            prompt: User prompt content
            project_path: Project directory path (for context and tool execution)
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens per turn (default: from config)
            temperature: Model temperature (default: from config)
            enable_tools: Whether to enable tool use (default: True)
            process_response: Whether to normalize the raw API response through
                _process_response (security validation + event format conversion).
                Set to False to get the raw Bedrock response directly, useful for
                simple single-turn completions where normalization is unnecessary.
                Defaults to True to preserve existing behavior.
            on_event: Optional callback for event notifications

        Returns:
            List of all events from all iterations combined

        Raises:
            ProviderError: If Bedrock API call fails
        """
        from app.services.tool_executor import ToolExecutor, format_tool_result_for_model
        from app.core.config import get_settings
        
        settings = get_settings()
        
        # Check if agentic mode is enabled
        if not settings.agentic.enabled:
            logger.info("Agentic mode disabled, falling back to single-turn")
            return await self.invoke_with_tools(
                prompt, project_path, system_prompt, max_tokens, temperature, enable_tools
            )

        if not enable_tools:
            logger.info("Tools disabled — single-turn path (skipping agentic loop)")
            return await self._invoke_single_turn_no_tools(
                prompt=prompt,
                project_path=project_path,
                system_prompt=system_prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                process_response=process_response,
                on_event=on_event,
                prepend_project_context=prepend_project_context,
            )
        
        logger.info("Starting agentic loop for tool execution")
        
        # Initialize tool executor
        tool_executor = ToolExecutor(
            project_path=project_path,
            working_directory=project_path,
            timeout=settings.agentic.tool_execution_timeout
        )
        
        # Track state across iterations
        all_events = []
        iteration = 0
        consecutive_errors = 0
        
        # Determine if unlimited mode is enabled
        unlimited_mode = settings.agentic.unlimited_iterations or settings.agentic.max_iterations == 0
        effective_max_iterations = settings.agentic.max_iterations if not unlimited_mode else None
        
        # Build initial messages
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "text": f"Project directory: {project_path}\n\n{prompt}"
                    }
                ]
            }
        ]
        
        # Agentic loop - continue until end_turn or safety limits
        while True:
            # Check iteration limit (only if not unlimited)
            if not unlimited_mode and iteration >= settings.agentic.max_iterations:
                break
            
            iteration += 1
            if unlimited_mode:
                logger.info(f"Agentic iteration {iteration} (unlimited mode)")
            else:
                logger.info(f"Agentic iteration {iteration}/{settings.agentic.max_iterations}")
            
            try:
                # Build request for this iteration
                request_body = {
                    "modelId": self.model_id,
                    "messages": messages,
                    "inferenceConfig": {
                        "maxTokens": max_tokens or self.max_tokens,
                        "temperature": temperature or self.temperature
                    }
                }
                
                # Add system prompt with completion instructions (every iteration, matching Portkey)
                completion_instructions = self._get_completion_instructions(
                    iteration,
                    effective_max_iterations,
                    unlimited_mode
                )
                if system_prompt:
                    request_body["system"] = [{"text": f"{system_prompt}\n\n{completion_instructions}"}]
                else:
                    request_body["system"] = [{"text": completion_instructions}]
                
                # Add tools if enabled
                if enable_tools:
                    request_body["toolConfig"] = {
                        "tools": [
                            self.CODE_EDITOR_TOOL,
                            self.BASH_TOOL
                        ],
                        "toolChoice": {"auto": {}}
                    }
                
                # Invoke Bedrock — gated by LLM rate limiter (semaphore + RPM/TPM + adaptive delay).
                # The semaphore is released as soon as converse() returns;
                # tool execution below runs freely without holding any rate limiter slot.
                logger.info(
                    "Agentic iteration %s: invoking Bedrock (max_tokens=%s)",
                    iteration,
                    max_tokens or self.max_tokens,
                )
                bedrock_started = time.monotonic()
                async with bedrock_llm_rate_limiter.acquire(
                    estimated_tokens=max_tokens or self.max_tokens
                ):
                    try:
                        response = await self._converse_async(request_body)
                    except ClientError as e:
                        self._map_converse_client_error(e, iteration)
                logger.info(
                    "Agentic iteration %s: Bedrock returned in %.1fs",
                    iteration,
                    time.monotonic() - bedrock_started,
                )
                
                # Process response — skip normalization when caller opts out
                if process_response:
                    events = await self._process_response(response, project_path)
                else:
                    events = [response]
                all_events.extend(events)
                if on_event:
                    for e in events:
                        on_event(e)

                # Extract stop reason
                if process_response:
                    result_event = next((e for e in reversed(events) if e.get("type") == "result"), None)
                    if result_event:
                        stop_reason = result_event.get("stop_reason")
                        logger.info(f"Iteration {iteration}: stop_reason={stop_reason}")
                    else:
                        logger.warning(f"Iteration {iteration}: No result event found")
                        stop_reason = "unknown"
                else:
                    # Raw Bedrock converse response — stopReason is a top-level field
                    stop_reason = response.get("stopReason", "unknown")
                    if stop_reason == "unknown":
                        logger.warning(f"Iteration {iteration}: stopReason missing from raw response")
                    else:
                        logger.info(f"Iteration {iteration}: stop_reason={stop_reason} (raw response)")

                # Check stop reason
                if stop_reason == "end_turn":
                    logger.info(f"Agentic loop completed normally after {iteration} iterations")
                    break
                
                elif stop_reason == "tool_use":
                    logger.info(f"Iteration {iteration}: Tool use requested, executing tools")
                    
                    # Extract tool uses from events
                    tool_use_events = [e for e in events if e.get("type") == "tool_use"]
                    
                    if not tool_use_events:
                        logger.warning("stop_reason=tool_use but no tool_use events found")
                        break
                    
                    # Execute each tool
                    tool_results_content = []
                    tool_execution_success = False
                    file_write_detected = False
                    file_patch_detected = False
                    
                    for tool_event in tool_use_events:
                        tool = tool_event.get("tool", {})
                        tool_use_id = tool.get("toolUseId", "")
                        tool_name = tool.get("name", "")
                        tool_input = tool.get("input", {})
                        operation = tool_input.get("operation", "")
                        
                        logger.info(f"Executing tool: {tool_name} (ID: {tool_use_id})")
                        
                        # Track file modifications for progress detection
                        if tool_name == "code_editor":
                            if operation == "write":
                                file_write_detected = True
                                last_file_write_iteration = iteration
                            elif operation == "patch":
                                file_patch_detected = True
                                last_file_write_iteration = iteration
                        
                        # Execute the tool
                        result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                        
                        if result.success:
                            tool_execution_success = True
                            consecutive_errors = 0
                        else:
                            consecutive_errors += 1
                            logger.error(
                                f"Tool execution failed: {tool_name}, "
                                f"consecutive_errors={consecutive_errors}"
                            )
                        
                        # Format result and wrap in Bedrock toolResult structure
                        tool_result_content = format_tool_result_for_model(tool_use_id, result)
                        tool_results_content.append({
                            "toolResult": {
                                "toolUseId": tool_use_id,
                                "content": [
                                    {
                                        "text": tool_result_content.get("content", "")
                                    }
                                ]
                            }
                        })

                        # Log execution
                        logger.info(
                            f"Tool {tool_name} executed: success={result.success}, "
                            f"time={result.execution_time_ms}ms, "
                            f"output_len={len(result.output)}"
                        )

                    # Check consecutive errors
                    if consecutive_errors >= settings.agentic.max_consecutive_errors:
                        logger.error(
                            f"Max consecutive errors reached: {consecutive_errors}, stopping"
                        )
                        break

                    # Add assistant message (from response)
                    output = response.get('output', {})
                    message_content = output.get('message', {})
                    messages.append({
                        "role": "assistant",
                        "content": message_content.get('content', [])
                    })

                    # Add tool results as user message (Bedrock format)
                    messages.append({
                        "role": "user",
                        "content": tool_results_content
                    })
                    
                    logger.debug(f"Added tool results to conversation, continuing to iteration {iteration + 1}")
                
                elif stop_reason == "max_tokens":
                    logger.warning(f"Model reached max_tokens in iteration {iteration}")
                    break
                
                else:
                    logger.info(f"Unexpected stop_reason: {stop_reason}, ending loop")
                    break
            
            except Exception as e:
                logger.error(f"Error in agentic iteration {iteration}: {str(e)}", exc_info=True)
                consecutive_errors += 1
                if consecutive_errors >= settings.agentic.max_consecutive_errors:
                    logger.error("Max consecutive errors reached, stopping agentic loop")
                    break

                # Add error event
                err_ev = {
                    "type": "error",
                    "error": f"Iteration {iteration} error: {str(e)}",
                    "timestamp": int(time.time() * 1000)
                }
                all_events.append(err_ev)
                if on_event:
                    on_event(err_ev)
                break
        
        # Add final event if loop ended due to max_iterations (only in limited mode)
        if not unlimited_mode and iteration >= settings.agentic.max_iterations:
            logger.warning(f"Agentic loop reached max_iterations ({settings.agentic.max_iterations}), task may be incomplete")
            max_ev = {
                "type": "system",
                "subtype": "max_iterations_reached",
                "message": f"Agentic loop reached maximum iterations ({settings.agentic.max_iterations}). Task may be incomplete.",
                "timestamp": int(time.time() * 1000)
            }
            all_events.append(max_ev)
            if on_event:
                on_event(max_ev)
        
        # Log final statistics
        logger.info(
            f"Agentic loop finished: iterations={iteration}, events={len(all_events)}"
        )
        
        return all_events

    async def invoke_with_tools_agentic_graph(
        self,
        prompt: str,
        project_path: str,
        provider_factory,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> List[Dict[str, Any]]:
        """
        Agentic execution using dependency graph (NO max_iterations).
        
        This method uses graph-based execution instead of max_iterations.
        Execution is bounded by graph size, not arbitrary iteration limits.
        Works deterministically with topological ordering.
        
        Args:
            prompt: User prompt content
            project_path: Project directory path
            provider_factory: ProviderFactory instance for creating providers
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens per turn (default: from config)
            temperature: Model temperature (default: from config)
            enable_tools: Whether to enable tool use (default: True)
            
        Returns:
            List of events from graph execution
            
        Raises:
            ValueError: If graph has circular dependencies or invalid structure
            ProviderError: If provider operations fail
        """
        from app.orchestrator.graph_orchestrator import GraphOrchestrator
        from app.core.config import get_settings
        
        settings = get_settings()
        
        logger.info("Starting graph-based agentic execution (Bedrock)")
        
        # Create orchestrator
        orchestrator = GraphOrchestrator(
            project_path=project_path,
            provider_factory=provider_factory,
            max_retries=getattr(settings.agentic, 'max_module_retries', 3),
            validation_timeout=getattr(settings.agentic, 'validation_timeout', 300),
            skip_validation=getattr(settings.agentic, 'skip_validation', False)
        )
        
        # Execute orchestration
        try:
            state = await orchestrator.orchestrate(prompt, on_event=on_event)
        except Exception as e:
            logger.error(f"Graph orchestration failed: {e}", exc_info=True)
            raise
        
        # Convert state to events format (compatible with existing event structure)
        events = []
        
        # Add graph start event
        graph_start_ev = {
            "type": "system",
            "subtype": "graph_start",
            "message": f"Graph orchestration started: {state.total_modules} modules",
            "timestamp": int(time.time() * 1000)
        }
        events.append(graph_start_ev)
        if on_event:
            on_event(graph_start_ev)
        
        # Add module completion events AND all tool execution events
        for module in state.graph.values():
            # Add module summary event
            module_ev = {
                "type": "module_completed",
                "module": module.name,
                "path": module.path,
                "status": module.status.value,
                "retries": module.retries,
                "files_changed": module.files_changed,
                "error": module.last_error,
                "timestamp": int(time.time() * 1000)
            }
            events.append(module_ev)
            if on_event:
                on_event(module_ev)
            
            # Add all tool execution events from this module (already streamed via on_event in orchestrator)
            if module.events:
                # Add module context to events for clarity
                for event in module.events:
                    # Add module name to event for traceability
                    event_with_context = event.copy()
                    event_with_context["module"] = module.name
                    events.append(event_with_context)
        
        # Add graph completion event
        progress = state.get_progress()
        graph_complete_ev = {
            "type": "system",
            "subtype": "graph_complete",
            "message": (
                f"Graph orchestration complete: "
                f"{progress['locked']} succeeded, "
                f"{progress['failed']} failed, "
                f"{progress['skipped']} skipped, "
                f"{state.current_iteration} iterations"
            ),
            "progress": progress,
            "timestamp": int(time.time() * 1000)
        }
        events.append(graph_complete_ev)
        if on_event:
            on_event(graph_complete_ev)
        
        logger.info(
            f"Graph execution complete: {len(events)} events, "
            f"{progress['locked']} modules succeeded"
        )
        
        return events

    async def invoke_simple(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Simple invoke for read-only operations without tool use.

        Lighter weight than invoke_with_tools for operations that don't
        need file editing or command execution (e.g., simple analysis).

        Args:
            prompt: User prompt content
            max_tokens: Maximum tokens (default from config)
            temperature: Model temperature (default from config)

        Returns:
            Complete response dictionary

        Raises:
            ProviderError: If Bedrock API call fails
        """
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature

        logger.info("Invoking Bedrock (simple mode, no tools)")

        messages = [
            {
                "role": "user",
                "content": [{"text": prompt}]
            }
        ]

        request_body = {
            "modelId": self.model_id,
            "messages": messages,
            "inferenceConfig": {
                "maxTokens": effective_max_tokens,
                "temperature": effective_temperature
            }
        }

        try:
            async with bedrock_llm_rate_limiter.acquire(
                estimated_tokens=effective_max_tokens
            ):
                try:
                    response = await self._converse_async(request_body)
                except ClientError as bedrock_err:
                    err_code = bedrock_err.response.get('Error', {}).get('Code', 'Unknown')
                    err_msg = bedrock_err.response.get('Error', {}).get('Message', str(bedrock_err))
                    if err_code in ['ThrottlingException', 'TooManyRequestsException', 'ServiceQuotaExceededException']:
                        raise RateLimitError(
                            message=f"Bedrock rate limit exceeded: {err_msg}",
                            retry_after=60,
                            details=f"Error code: {err_code}"
                        )
                    raise
            logger.info("Bedrock simple invocation completed")
            return response

        except RateLimitError:
            raise

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))

            raise ProviderError(
                message=f"Bedrock API error: {error_message}",
                provider="bedrock",
                details=f"Error code: {error_code}"
            )

    async def health_check(self) -> bool:
        """
        Check if Bedrock is reachable by listing foundation models.

        Returns:
            True if Bedrock is accessible, False otherwise
        """
        try:
            bedrock = self.bedrock_runtime._endpoint._endpoint_prefix
            # Use a lightweight call — list accessible models
            session = boto3.Session(
                profile_name=self.profile,
                region_name=self.region
            )
            bedrock_client = session.client(
                service_name='bedrock',
                region_name=self.region
            )
            bedrock_client.list_foundation_models(byOutputModality='TEXT')
            logger.info("Bedrock health check: OK")
            return True

        except Exception as e:
            logger.error(f"Bedrock health check error: {str(e)}")
            return False
