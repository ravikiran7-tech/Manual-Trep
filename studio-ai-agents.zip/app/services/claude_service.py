"""
Claude Service - Main orchestrator for AI operations.

Routes requests to appropriate operation handlers based on operation type.
Equivalent to Java's ClaudeCliService.
"""
import logging
from typing import Optional, Dict, Type

from app.models.requests import (
    ClaudeCliRequest,
    SchemaModernizationRequest,
    AssessmentRulesBatchRequest,
)
from app.models.responses import (
    ClaudeCliResponse,
    SchemaModernizationResponse,
    AssessmentRulesBatchResponse,
)
from app.services.provider_factory import ProviderFactory, get_provider_factory
from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.services.operation_handlers.analysis_handler import AnalysisHandler
from app.services.operation_handlers.fix_upgrade_handler import FixUpgradeHandler
from app.services.operation_handlers.schema_modernization_handler import SchemaModernizationHandler
from app.services.operation_handlers.assessment_rules_batch_handler import (
    AssessmentRulesBatchHandler,
    ProgressCallback,
)
from app.services.operation_handlers.build_compilation_handler import BuildCompilationHandler
from app.services.operation_handlers.test_execution_handler import TestExecutionHandler
from app.services.operation_handlers.test_creation_handler import TestCreationHandler
from app.services.operation_handlers.cloudreadiness_analysis_handler import CloudReadinessAnalysisHandler
from app.services.operation_handlers.cloudreadiness_fix_handler import CloudReadinessFixHandler
from app.services.operation_handlers.db_modernize_analysis_handler import DbModernizeAnalysisHandler
from app.services.operation_handlers.db_modernize_fix_handler import DbModernizeFixHandler
from app.services.operation_handlers.dotnet_build_handler import DotnetBuildHandler
from app.services.operation_handlers.dotnet_test_handler import DotnetTestHandler
from app.services.operation_handlers.containerization_analysis_handler import ContainerizationAnalysisHandler
from app.services.operation_handlers.selective_fix_handler import SelectiveFixHandler
from app.services.operation_handlers.generation_handler import GenerationHandler
from app.services.operation_handlers.summary_handler import SummaryHandler
from app.services.studio_core_git_sync import (
    GIT_PUSH_REJECTED_MESSAGE,
    commit_and_push_after_step,
    sync_before_step,
)
from app.core.exceptions import ValidationError
from app.core.config import get_settings


logger = logging.getLogger(__name__)
settings = get_settings()


class ClaudeService:
    """
    Main orchestrator for Claude AI operations.

    Routes requests to appropriate operation handlers based on operation type.
    Manages handler lifecycle and provider factory.

    Equivalent to Java's ClaudeCliService (orchestrator that routes to
    platform-specific services).
    """

    def __init__(
        self,
        provider_factory: Optional[ProviderFactory] = None
    ):
        """
        Initialize Claude service.

        Args:
            provider_factory: Provider factory for creating AI clients
        """
        self.provider_factory = provider_factory or get_provider_factory()

        # Initialize handler registry with all 16 operation types
        self._handler_registry: Dict[str, Type[BaseOperationHandler]] = {
            "analysis": AnalysisHandler,
            "fix-upgrade": FixUpgradeHandler,
            # "build-compilation": BuildCompilationHandler,
            "test-execution": TestExecutionHandler,
            "test-creation": TestCreationHandler,
            "cloudreadiness-analysis": CloudReadinessAnalysisHandler,
            "cloudreadiness-fix": CloudReadinessFixHandler,
            "db-code-modernize-analysis": DbModernizeAnalysisHandler,
            "db-code-modernize-fix": DbModernizeFixHandler,
            "build-compilation": DotnetBuildHandler,
            "test-executionbuild": DotnetTestHandler,
            # Containerization operations
            "containerization-analysis": ContainerizationAnalysisHandler,
            "selective-fix": SelectiveFixHandler,
            # "fix": SelectiveFixHandler,
            "generation": GenerationHandler,
            "summary": SummaryHandler,
        }

        logger.info("ClaudeService initialized with provider factory")

    async def execute_non_interactive_command(
        self,
        request: ClaudeCliRequest
    ) -> ClaudeCliResponse:
        """
        Execute non-interactive Claude command.

        Routes request to appropriate operation handler based on operation type.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response

        Raises:
            ValidationError: If operation type is invalid or handler not found
        """
        operation = request.operation.lower()

        logger.info(f"Executing non-interactive command: operation={operation}")

        # Get handler for operation type.
        # Java build requests carry java_version; route them to BuildCompilationHandler.
        # .NET build requests do not carry java_version; fall through to DotnetBuildHandler.
        if operation == "build-compilation" and request.java_version:
            handler_class = BuildCompilationHandler
        else:
            handler_class = self._handler_registry.get(operation)

        if not handler_class:
            error_msg = (
                f"Operation '{operation}' not supported or not yet implemented. "
                f"Supported operations: {list(self._handler_registry.keys())}"
            )
            logger.error(error_msg)
            raise ValidationError(
                message=error_msg,
                field="operation"
            )

        # Instantiate handler
        handler = handler_class(provider_factory=self.provider_factory)

        await sync_before_step(request.analysis_id, request.project_path)

        # Execute handler
        try:
            response = await handler.execute(request)
            logger.info(f"Operation '{operation}' completed with status: {response.status}")
            if response.status == "success" and await commit_and_push_after_step(
                request.analysis_id,
                request.project_path,
                operation,
            ):
                response = ClaudeCliResponse(
                    status="error",
                    message=GIT_PUSH_REJECTED_MESSAGE,
                    exit_code=1,
                    output="",
                    error=GIT_PUSH_REJECTED_MESSAGE,
                )
            return response

        except Exception as e:
            logger.error(f"Operation '{operation}' failed: {str(e)}", exc_info=True)
            raise

    async def execute_schema_modernization(
        self,
        request: SchemaModernizationRequest
    ) -> SchemaModernizationResponse:
        """
        Execute schema modernization operation.

        Converts database schemas between different database types.

        Args:
            request: Schema modernization request

        Returns:
            Schema modernization response

        Raises:
            ValidationError: If request validation fails
        """
        logger.info(
            f"Executing schema modernization: {request.source_db_type} → "
            f"{request.target_db_type}"
        )

        # Use schema modernization handler
        handler = SchemaModernizationHandler(provider_factory=self.provider_factory)

        try:
            response = await handler.execute(request)
            logger.info(f"Schema modernization completed with status: {response.status}")
            return response

        except Exception as e:
            logger.error(f"Schema modernization failed: {str(e)}", exc_info=True)
            raise

    async def execute_assessment_rules_batch(
        self,
        request: AssessmentRulesBatchRequest,
        on_progress: Optional[ProgressCallback] = None,
    ) -> AssessmentRulesBatchResponse:
        """
        Generate assessment-rule JSON objects for each catalog rule in the batch.

        Args:
            request: Batch request; each rule carries its own domain and language
            on_progress: Optional async callback invoked after each chunk result
                (used by NATS for progressive publishing)

        Returns:
            AssessmentRulesBatchResponse with parsed rules array or error details
        """
        logger.info(
            "Executing assessment rules batch: analysisId=%s, rule_count=%s",
            request.analysis_id,
            len(request.rules),
        )
        handler = AssessmentRulesBatchHandler(provider_factory=self.provider_factory)
        try:
            response = await handler.execute_batch(
                request, on_progress=on_progress
            )
            logger.info(
                "Assessment rules batch finished: status=%s", response.status
            )
            return response
        except Exception as e:
            logger.error(
                "Assessment rules batch failed: %s", str(e), exc_info=True
            )
            raise

    def register_handler(
        self,
        operation: str,
        handler_class: Type[BaseOperationHandler]
    ):
        """
        Register a new operation handler.

        Allows dynamic registration of handlers for extensibility.

        Args:
            operation: Operation type (e.g., "build-compilation")
            handler_class: Handler class

        Example:
            >>> service = ClaudeService()
            >>> service.register_handler("build-compilation", BuildCompilationHandler)
        """
        self._handler_registry[operation.lower()] = handler_class
        logger.info(f"Registered handler for operation: {operation}")

    def get_supported_operations(self) -> list:
        """
        Get list of supported operation types.

        Returns:
            List of operation type strings
        """
        return list(self._handler_registry.keys())


# ============================================================================
# MODULE-LEVEL INSTANCE
# ============================================================================

_default_service: Optional[ClaudeService] = None


def get_claude_service() -> ClaudeService:
    """
    Get or create default ClaudeService instance.

    Returns:
        ClaudeService instance

    Example:
        >>> service = get_claude_service()
        >>> response = await service.execute_non_interactive_command(request)
    """
    global _default_service
    if _default_service is None:
        _default_service = ClaudeService()
    return _default_service
