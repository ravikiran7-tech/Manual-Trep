"""
Direct .NET build execution service (no LLM).

Runs 'dotnet build' as a subprocess, parses the output, and saves the result.
Mirrors Java's DotnetBuildCompilationService.executeBuild() logic exactly.
"""
import asyncio
import json
import logging
import re
import sys
from pathlib import Path
from typing import Callable, List, Optional

from app.models.dotnet_build import BuildRequest, BuildResult


logger = logging.getLogger(__name__)

# Mirrors Java's static Pattern fields
_ERROR_COUNT_PATTERN = re.compile(r"(\d+)\s+Error\(s\)")
_WARNING_COUNT_PATTERN = re.compile(r"(\d+)\s+Warning\(s\)")
_BUILD_TIME_PATTERN = re.compile(r"Time Elapsed\s+(\S+)")
_COMPILATION_ERROR_PATTERN = re.compile(r".*\.cs\(\d+,\d+\):\s*error\s+CS\d+:")


async def execute_dotnet_build(request: BuildRequest) -> BuildResult:
    """
    Execute .NET build without LLM.

    Mirrors Java's DotnetBuildCompilationService.executeBuild():
      1. Create log/reports directories
      2. Run 'dotnet build' subprocess
      3. Parse build output
      4. Save build-result.json to reports folder
      5. Return BuildResult

    Args:
        request: BuildRequest with project location and metadata

    Returns:
        BuildResult with parsed build output

    Raises:
        RuntimeError: If dotnet build process fails to start or exits with error
    """
    logger.info("=== STARTING .NET BUILD EXECUTION PROCESS ===")
    logger.info("Project location: %s", request.project_location)
    logger.info("AnalysisID: %s", request.analysis_id)
    logger.info("Platform: %s", request.platform)
    logger.info("Claude workspace location: %s", request.claude_workspace)

    platform = _get_platform(request.platform)
    logger.info("Resolved platform: %s", platform)

    log_file = _create_directories_and_get_log_path(
        request.analysis_id, request.claude_workspace
    )

    exit_code, output_lines = await _run_dotnet_build(
        request.project_location, log_file, request.build_file
    )

    if exit_code == 0:
        logger.info(
            ".NET build execution completed successfully for project: %s",
            request.project_location,
        )
    else:
        logger.error(".NET build execution failed with exit code: %d", exit_code)
        # Mirrors Java: throw but still parse and save what we have
        # We continue to parse so the caller gets a useful BuildResult,
        # then raise after saving — caller can catch if needed.

    build_result = _parse_build_result(exit_code, output_lines)

    logger.info("=== SAVING BUILD RESULT TO REPORTS ===")
    _save_build_result(build_result, request.analysis_id, request.claude_workspace)
    logger.info("Build result saved to reports folder")

    if exit_code != 0:
        raise RuntimeError(
            f"Build execution failed with exit code: {exit_code}"
        )

    return build_result


############################################################
# Private helpers
############################################################

def _get_platform(platform: Optional[str]) -> str:
    """
    Mirrors Java's getPlatform().
    Auto-detects platform if not specified.
    """
    if not platform or not platform.strip():
        return "windows" if sys.platform == "win32" else "linux"
    return platform


def _create_directories_and_get_log_path(
    analysis_id: str,
    claude_workspace: Optional[str],
) -> Path:
    """
    Mirrors Java's createDirectoriesForBuildLogs() + getBuildLogFilePath().
    Creates:
      {workspace}/validation/{analysisId}/logs/
      {workspace}/validation/{analysisId}/reports/
    Returns path to build.log.
    """
    base = Path(claude_workspace) / "validation" / analysis_id
    logs_dir = base / "logs"
    reports_dir = base / "reports"

    logs_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    logger.info("Created build directories under: %s", base)
    return logs_dir / "build.log"


async def _run_dotnet_build(
    project_location: str,
    log_file: Path,
    build_file: Optional[str] = None,
) -> tuple[int, List[str]]:
    """
    Run 'dotnet build' as an async subprocess.

    Build target logic mirrors Java's script builder:
      - buildFile ends with .sln  → dotnet build <buildFile>
      - buildFile is set (non-empty) → dotnet build <buildFile>
      - buildFile is None/empty   → dotnet build   (picks up project in cwd)

    Captures combined stdout+stderr, writes to log file, returns (exit_code, lines).
    """
    if build_file and build_file.endswith(".sln"):
        cmd = ["dotnet", "build", build_file]
    elif build_file and build_file.strip():
        cmd = ["dotnet", "build", build_file]
    else:
        cmd = ["dotnet", "build"]

    logger.info("Running command: %s", " ".join(cmd))

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=project_location,
        )
        stdout_bytes, _ = await proc.communicate()
        output = stdout_bytes.decode("utf-8", errors="replace")
    except FileNotFoundError:
        error_msg = "'dotnet' executable not found. Ensure .NET SDK is installed."
        logger.error(error_msg)
        log_file.write_text(error_msg, encoding="utf-8")
        return 1, [error_msg]
    except Exception as e:
        error_msg = f"Failed to run dotnet build: {e}"
        logger.error(error_msg, exc_info=True)
        log_file.write_text(error_msg, encoding="utf-8")
        return 1, [error_msg]

    log_file.write_text(output, encoding="utf-8")
    logger.info("Build output written to: %s", log_file)

    return proc.returncode, output.splitlines()


def _parse_build_result(exit_code: int, output_lines: List[str]) -> BuildResult:
    """Mirrors Java's parseBuildResult()."""
    return BuildResult(
        exit_code=exit_code,
        success=exit_code == 0,
        build_status=_determine_build_status(output_lines),
        compilation_errors=_extract_compilation_errors(output_lines),
        test_failures=_extract_test_failures(output_lines),
        errors=_extract_errors_count(output_lines),
        warnings=_extract_warnings_count(output_lines),
        total_time=_extract_total_time(output_lines),
    )


def _determine_build_status(output_lines: List[str]) -> str:
    """Mirrors Java's determineBuildStatus()."""
    for line in output_lines:
        if "Build succeeded" in line:
            return "SUCCESS"
        if "Build FAILED" in line or "Build failed" in line:
            return "FAILURE"
    return "UNKNOWN"


def _extract_compilation_errors(output_lines: List[str]) -> List[str]:
    """
    Mirrors Java's extractCompilationErrors().
    Pattern: file.cs(line,col): error CS####: message
    """
    errors = []
    for line in output_lines:
        if _COMPILATION_ERROR_PATTERN.match(line):
            errors.append(line.strip())
    # deduplicate preserving order
    seen = set()
    return [e for e in errors if not (e in seen or seen.add(e))]


def _extract_test_failures(output_lines: List[str]) -> List[str]:
    """Mirrors Java's extractTestFailures()."""
    failures = []
    for line in output_lines:
        if "Failed" in line and "test" in line:
            stripped = line.strip()
            if stripped:
                failures.append(stripped)
    seen = set()
    return [f for f in failures if not (f in seen or seen.add(f))]


def _extract_count_from_summary(
    output_lines: List[str],
    pattern: re.Pattern,
    fallback_filter: Callable[[str], bool],
) -> int:
    """Mirrors Java's extractCountFromSummary()."""
    for line in output_lines:
        m = pattern.search(line)
        if m:
            return int(m.group(1))
    return sum(1 for line in output_lines if fallback_filter(line))


def _extract_errors_count(output_lines: List[str]) -> int:
    """Mirrors Java's extractErrorsCount()."""
    return _extract_count_from_summary(
        output_lines,
        _ERROR_COUNT_PATTERN,
        lambda line: "error CS" in line or "error:" in line,
    )


def _extract_warnings_count(output_lines: List[str]) -> int:
    """Mirrors Java's extractWarningsCount()."""
    return _extract_count_from_summary(
        output_lines,
        _WARNING_COUNT_PATTERN,
        lambda line: "warning CS" in line or "warning:" in line,
    )


def _extract_total_time(output_lines: List[str]) -> str:
    """Mirrors Java's extractTotalTime()."""
    for line in output_lines:
        m = _BUILD_TIME_PATTERN.search(line)
        if m:
            return m.group(1).strip()
    return "N/A"


def _save_build_result(
    build_result: BuildResult,
    analysis_id: str,
    claude_workspace: Optional[str],
) -> None:
    """
    Mirrors Java's saveBuildResult().
    Writes build-result.json to {workspace}/validation/{analysisId}/reports/
    """
    if not claude_workspace:
        raise ValueError(
            "claude_workspace is required to save build results but was not provided"
        )
    reports_dir = (
        Path(claude_workspace) / "validation" / analysis_id / "reports"
    )
    reports_dir.mkdir(parents=True, exist_ok=True)

    result_path = reports_dir / "build-result.json"
    result_path.write_text(
        json.dumps(build_result.model_dump(by_alias=True), indent=2),
        encoding="utf-8",
    )
    logger.info("build-result.json saved to: %s", result_path)
