"""
Provider factory for AI provider selection and instantiation.

Fetches connection configurations from Compass and creates appropriate
provider clients (Bedrock or Portkey) with credential management.

Replaces Java's ClaudeCommandConstructionHelper for provider orchestration.
"""
import logging
from typing import Optional, Union, Dict, Any
from enum import Enum

from app.clients.compass_client import CompassClient, ConnectionData
from app.services.bedrock_client import BedrockClient
from app.services.portkey_client import PortkeyClient
from app.utils.encryption import EncryptionUtils, get_encryption_utils
from app.core.config import get_settings
from app.core.exceptions import ConfigurationError, ProviderError


logger = logging.getLogger(__name__)
settings = get_settings()


class ProviderType(str, Enum):
    """Provider types supported by the factory."""
    AWS_BEDROCK = "aws-bedrock"
    PORTKEY = "portkey"


class ProviderFactory:
    """
    Factory for creating AI provider clients.

    Fetches connection configurations from Compass, decrypts credentials,
    and instantiates appropriate provider clients (Bedrock or Portkey).

    This is the central orchestration point for provider selection,
    replacing Java's ClaudeCommandConstructionHelper authentication logic.
    """

    def __init__(
        self,
        compass_client: Optional[CompassClient] = None,
        encryption_utils: Optional[EncryptionUtils] = None
    ):
        """
        Initialize provider factory.

        Args:
            compass_client: Compass client for fetching connections (default: new instance)
            encryption_utils: Encryption utilities for credential decryption (default: singleton)
        """
        self.compass_client = compass_client or CompassClient()
        self.encryption_utils = encryption_utils or get_encryption_utils()

        logger.info("Provider factory initialized")

    async def get_provider(
        self,
        component: Optional[str] = None,
        prefer_bedrock: bool = True
    ) -> Union[BedrockClient, PortkeyClient, Any]:
        """
        Get AI provider client based on Compass configuration.

        Fetches connection configuration from Compass and creates the
        appropriate provider client. Bedrock and Portkey use the legacy
        clients. Azure and concierto-private-llm return an LLMOrchestrator.

        Args:
            component: Compass component name (default from config: "claude-code")
            prefer_bedrock: If True, prefer Bedrock over Portkey when both available

        Returns:
            BedrockClient or PortkeyClient instance

        Raises:
            ConfigurationError: If no valid connection found
            ProviderError: If provider creation fails

        Example:
            >>> factory = ProviderFactory()
            >>> provider = await factory.get_provider("claude-code")
            >>> # Use provider for AI operations
            >>> events = await provider.invoke_with_tools(prompt, project_path)
            >>> for event in events:
            >>>     print(event)
        """
        effective_component = component or settings.studio_core.compass_component

        logger.info(f"Getting provider for component: {effective_component}")

        # Fetch connection from Compass
        connection = await self.compass_client.get_active_connection(effective_component)

        if not connection:
            raise ConfigurationError(
                message=f"No active connection found for component: {effective_component}",
                details="Check Compass configuration in Studio Core"
            )

        logger.info(
            f"Found connection: provider={connection.provider_type}, "
            f"slug={connection.slug}"
        )

        # Create provider based on type.
        # Bedrock and Portkey keep their legacy clients. Azure and
        # concierto-private-llm have no legacy client; those Compass types
        # are built by the orchestrator adapter registry.
        provider_type = connection.provider_type.lower()

        if provider_type == ProviderType.AWS_BEDROCK:
            return await self._create_bedrock_client(connection)
        elif provider_type == ProviderType.PORTKEY:
            return await self._create_portkey_client(connection)

        from app.services.llm.factory import (
            build_orchestrator,
            supported_adapter_types,
        )

        if provider_type in supported_adapter_types():
            logger.info(
                "Delegating provider type %s to orchestrator adapter",
                connection.provider_type,
            )
            return build_orchestrator(connection, self.encryption_utils)

        raise ConfigurationError(
            message=f"Unsupported provider type: {connection.provider_type}",
            details=f"Supported types: {supported_adapter_types()}",
        )

    async def _create_bedrock_client(
        self,
        connection: ConnectionData
    ) -> BedrockClient:
        """
        Create Bedrock client from connection configuration.

        Args:
            connection: Connection data from Compass

        Returns:
            Configured BedrockClient instance

        Raises:
            ConfigurationError: If configuration is invalid
        """
        config = connection.configuration

        # Extract configuration with fallbacks
        region = config.aws_region or settings.bedrock.region
        model_id = config.model_id or settings.bedrock.default_model
        profile = settings.bedrock.profile

        logger.info(
            f"Creating Bedrock client: region={region}, "
            f"model={model_id}, profile={profile}"
        )

        try:
            client = BedrockClient(
                region=region,
                model_id=model_id,
                profile=profile,
                max_tokens=settings.bedrock.max_tokens,
                temperature=settings.bedrock.temperature
            )

            logger.info("Bedrock client created successfully")
            return client

        except Exception as e:
            error_msg = f"Failed to create Bedrock client: {str(e)}"
            logger.error(error_msg)
            raise ProviderError(
                message=error_msg,
                provider="bedrock",
                details=str(e)
            )

    async def _create_portkey_client(
        self,
        connection: ConnectionData
    ) -> PortkeyClient:
        """
        Create Portkey client from connection configuration.

        Decrypts API key and extracts virtual key from slug.

        Args:
            connection: Connection data from Compass

        Returns:
            Configured PortkeyClient instance

        Raises:
            ConfigurationError: If configuration is invalid or decryption fails
        """
        # Portkey API key can be at connection level or in configuration
        portkey_api_key = connection.portkey_api_key or connection.configuration.portkey_api_key
        portkey_base_url = connection.portkey_base_url or connection.configuration.portkey_base_url

        # Validate required fields
        if not portkey_api_key:
            raise ConfigurationError(
                message="Portkey API key is missing in connection configuration",
                details=f"Component: {connection.component}, Connection ID: {connection.connection_id}"
            )

        if not connection.slug:
            raise ConfigurationError(
                message="Portkey slug is missing in connection configuration",
                details=f"Component: {connection.component}, Connection ID: {connection.connection_id}"
            )

        # Decrypt API key
        logger.info("Decrypting Portkey API key")
        try:
            api_key = self.encryption_utils.decrypt(portkey_api_key)

            if not api_key:
                raise ConfigurationError(
                    message="Decrypted Portkey API key is empty",
                    details="Check encryption key configuration"
                )

            logger.debug("Portkey API key decrypted successfully")

        except Exception as e:
            error_msg = f"Failed to decrypt Portkey API key: {str(e)}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"Check ENCRYPTION_KEY environment variable. Error: {type(e).__name__}"
            )

        # Parse slug format: @virtual-key/model-id
        # Example: @bedrock-virtual-key/claude-3-sonnet-20240229
        try:
            slug_parts = connection.slug.split('/')

            if len(slug_parts) != 2:
                raise ValueError(f"Invalid slug format: {connection.slug}")

            virtual_key_with_at = slug_parts[0]
            model_id = slug_parts[1]

            # Remove @ prefix from virtual key
            if virtual_key_with_at.startswith('@'):
                virtual_key = virtual_key_with_at[1:]
            else:
                virtual_key = virtual_key_with_at

            if not virtual_key or not model_id:
                raise ValueError("Virtual key or model ID is empty")

            logger.info(
                f"Parsed Portkey slug: virtual_key={virtual_key[:8]}..., "
                f"model_id={model_id}"
            )

        except Exception as e:
            error_msg = f"Failed to parse Portkey slug: {str(e)}"
            logger.error(error_msg)
            raise ConfigurationError(
                message=error_msg,
                details=f"Expected format: @virtual-key/model-id, Got: {connection.slug}"
            )

        # Get base URL and debug setting
        base_url = portkey_base_url or settings.portkey.base_url
        debug = connection.debug_enabled if connection.debug_enabled is not None else connection.configuration.debug_enabled or False

        logger.info(
            f"Creating Portkey client: model={model_id}, "
            f"virtual_key={virtual_key[:8]}..., debug={debug}"
        )

        try:
            client = PortkeyClient(
                api_key=api_key,
                virtual_key=virtual_key,
                model_id=model_id,
                base_url=base_url,
                debug=debug,
                max_tokens=settings.bedrock.max_tokens,
                temperature=settings.bedrock.temperature
            )

            logger.info("Portkey client created successfully")
            return client

        except Exception as e:
            error_msg = f"Failed to create Portkey client: {str(e)}"
            logger.error(error_msg)
            raise ProviderError(
                message=error_msg,
                provider="portkey",
                details=str(e)
            )

    async def get_provider_type(
        self,
        component: Optional[str] = None
    ) -> Optional[str]:
        """
        Get provider type for a component without creating the client.

        Useful for logging, monitoring, or conditional logic.

        Args:
            component: Compass component name (default from config)

        Returns:
            Provider type string ("aws-bedrock" or "portkey"), or None if not found

        Example:
            >>> factory = ProviderFactory()
            >>> provider_type = await factory.get_provider_type("claude-code")
            >>> print(f"Using provider: {provider_type}")
        """
        effective_component = component or settings.studio_core.compass_component

        try:
            connection = await self.compass_client.get_active_connection(effective_component)

            if connection:
                return connection.provider_type

            return None

        except Exception as e:
            logger.error(f"Error getting provider type: {str(e)}")
            return None

    async def health_check(self) -> Dict[str, Any]:
        """
        Check health of all provider dependencies.

        Returns:
            Dictionary with health status of Compass and available providers

        Example:
            >>> factory = ProviderFactory()
            >>> health = await factory.health_check()
            >>> print(f"Compass: {health['compass']}, Providers: {health['providers']}")
        """
        health = {
            "compass": False,
            "providers": {}
        }

        # Check Compass connectivity
        try:
            health["compass"] = await self.compass_client.health_check()
        except Exception as e:
            logger.error(f"Compass health check failed: {str(e)}")
            health["compass"] = False

        return health


# ============================================================================
# MODULE-LEVEL INSTANCE
# ============================================================================

_default_factory: Optional[ProviderFactory] = None


def get_provider_factory() -> ProviderFactory:
    """
    Get or create default ProviderFactory instance.

    Returns:
        ProviderFactory instance with default configuration

    Example:
        >>> factory = get_provider_factory()
        >>> provider = await factory.get_provider()
    """
    global _default_factory
    if _default_factory is None:
        _default_factory = ProviderFactory()
    return _default_factory
