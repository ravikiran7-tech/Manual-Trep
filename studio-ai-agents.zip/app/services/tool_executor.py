"""
Tool Executor Module - Executes AI-requested tools safely.

This module provides the core functionality for executing bash commands
and file operations requested by the AI model in an agentic loop.

CRITICAL SECURITY: All tools are validated before execution.
"""
import subprocess
import logging
import os
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass

from app.core.config import get_settings
from app.core.security import SecurityValidator
from app.execution.patch_manager import PatchManager


logger = logging.getLogger(__name__)
settings = get_settings()


@dataclass
class ToolResult:
    """Result of a tool execution."""
    success: bool
    output: str
    error: Optional[str] = None
    execution_time_ms: int = 0


class ToolExecutor:
    """
    Executes validated tools requested by AI model.
    
    Supports:
    - bash: Execute shell commands
    - code_editor: Read/write/delete files
    
    All operations are validated and executed with security constraints.
    """
    
    def __init__(
        self,
        project_path: str,
        working_directory: Optional[str] = None,
        timeout: int = 30
    ):
        """
        Initialize tool executor.
        
        Args:
            project_path: Base project path for operations
            working_directory: Working directory for bash commands (defaults to project_path)
            timeout: Execution timeout in seconds
        """
        self.project_path = project_path
        self.working_directory = working_directory or project_path
        self.timeout = timeout
        
        logger.info(
            f"ToolExecutor initialized: project={project_path}, "
            f"working_dir={self.working_directory}, timeout={timeout}s"
        )
    
    def execute_tool(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        tool_use_id: str
    ) -> ToolResult:
        """
        Execute a tool based on its name and input.
        
        Args:
            tool_name: Name of the tool ("bash" or "code_editor")
            tool_input: Tool input parameters
            tool_use_id: Unique ID for this tool use
        
        Returns:
            ToolResult with execution outcome
        """
        logger.info(f"Executing tool: {tool_name} (ID: {tool_use_id})")
        
        try:
            if tool_name == "bash":
                return self._execute_bash(tool_input, tool_use_id)
            elif tool_name == "code_editor":
                return self._execute_file_operation(tool_input, tool_use_id)
            else:
                error_msg = f"Unknown tool: {tool_name}"
                logger.error(error_msg)
                return ToolResult(
                    success=False,
                    output="",
                    error=error_msg
                )
        
        except Exception as e:
            error_msg = f"Tool execution failed: {str(e)}"
            logger.error(f"{error_msg} (tool={tool_name}, id={tool_use_id})", exc_info=True)
            return ToolResult(
                success=False,
                output="",
                error=error_msg
            )
    
    def _execute_bash(
        self,
        tool_input: Dict[str, Any],
        tool_use_id: str
    ) -> ToolResult:
        """
        Execute a bash command.
        
        Args:
            tool_input: Dict with "command" and optional "working_directory"
            tool_use_id: Tool use ID for logging
        
        Returns:
            ToolResult with command output
        """
        command = tool_input.get('command', '')
        custom_working_dir = tool_input.get('working_directory')
        
        if not command:
            return ToolResult(
                success=False,
                output="",
                error="No command provided"
            )
        
        # Use custom working directory if provided, otherwise use default
        working_dir = custom_working_dir or self.working_directory
        
        # Ensure working directory exists
        if not os.path.exists(working_dir):
            return ToolResult(
                success=False,
                output="",
                error=f"Working directory does not exist: {working_dir}"
            )
        
        logger.info(f"Executing bash command: {command[:100]}... in {working_dir}")
        
        import time
        start_time = time.time()
        
        try:
            # Execute command with timeout
            result = subprocess.run(
                command,
                shell=True,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                env=os.environ.copy()
            )
            
            execution_time = int((time.time() - start_time) * 1000)
            
            # Combine stdout and stderr for output
            output = result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}"
            
            # Determine success - handle special cases where non-zero exit is valid
            success = result.returncode == 0
            error = None
            
            # Special handling for grep/rg: exit code 1 means "no matches found" (valid result)
            if not success and result.returncode == 1:
                command_lower = command.lower().strip()
                if command_lower.startswith('grep ') or ' grep ' in command_lower or \
                   command_lower.startswith('rg ') or ' rg ' in command_lower:
                    # No matches found is a valid result for grep, not an error 
                    success = True
                    error = None
                    logger.debug(f"grep/rg returned no matches (exit 1) - treating as success")
                else:
                    error = f"Command exited with code {result.returncode}"
            elif not success:
                error = f"Command exited with code {result.returncode}"
            
            logger.info(
                f"Bash execution completed: success={success}, "
                f"time={execution_time}ms, output_len={len(output)}"
            )
            
            return ToolResult(
                success=success,
                output=output.strip() if output else "(no output)",
                error=error,
                execution_time_ms=execution_time
            )
        
        except subprocess.TimeoutExpired:
            execution_time = int((time.time() - start_time) * 1000)
            error_msg = f"Command timed out after {self.timeout}s"
            logger.error(f"{error_msg}: {command[:100]}")
            return ToolResult(
                success=False,
                output="",
                error=error_msg,
                execution_time_ms=execution_time
            )
        
        except Exception as e:
            execution_time = int((time.time() - start_time) * 1000)
            error_msg = f"Command execution error: {str(e)}"
            logger.error(f"{error_msg}: {command[:100]}", exc_info=True)
            return ToolResult(
                success=False,
                output="",
                error=error_msg,
                execution_time_ms=execution_time
            )
    
    def _execute_file_operation(
        self,
        tool_input: Dict[str, Any],
        tool_use_id: str
    ) -> ToolResult:
        """
        Execute a file operation (read/write/delete/patch).
        
        Args:
            tool_input: Dict with "path", "operation", and optional "content" or "patch_data"
            tool_use_id: Tool use ID for logging
            
        Returns:
            ToolResult with operation outcome
        """
        file_path = tool_input.get('path', '')
        operation = tool_input.get('operation', '')
        content = tool_input.get('content', '')
        
        if not file_path or not operation:
            return ToolResult(
                success=False,
                output="",
                error="Missing path or operation"
            )
        
        logger.info(f"File operation: {operation} on {file_path}")
        
        import time
        start_time = time.time()
        
        try:
            # Convert relative paths to absolute
            if not os.path.isabs(file_path):
                file_path = os.path.join(self.project_path, file_path)
            
            # Resolve path to prevent traversal
            file_path = str(Path(file_path).resolve())
            
            # Execute operation
            if operation == "read":
                result = self._read_file(file_path)
            elif operation == "write":
                result = self._write_file(file_path, content)
            elif operation == "delete":
                result = self._delete_file(file_path)
            elif operation == "patch":
                result = self._patch_file(file_path, tool_input)
            else:
                result = ToolResult(
                    success=False,
                    output="",
                    error=f"Unknown operation: {operation}. Supported: read, write, delete, patch"
                )
            
            execution_time = int((time.time() - start_time) * 1000)
            result.execution_time_ms = execution_time
            
            logger.info(
                f"File operation completed: {operation} on {file_path}, "
                f"success={result.success}, time={execution_time}ms"
            )
            
            return result
        
        except Exception as e:
            execution_time = int((time.time() - start_time) * 1000)
            error_msg = f"File operation error: {str(e)}"
            logger.error(f"{error_msg}: {operation} on {file_path}", exc_info=True)
            return ToolResult(
                success=False,
                output="",
                error=error_msg,
                execution_time_ms=execution_time
            )
    
    def _read_file(self, file_path: str) -> ToolResult:
        """Read file contents."""
        try:
            if not os.path.exists(file_path):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"File not found: {file_path}"
                )
            
            if not os.path.isfile(file_path):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Path is not a file: {file_path}"
                )
            
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
            
            logger.info(f"Read {len(content)} bytes from {file_path}")
            return ToolResult(
                success=True,
                output=content
            )
        
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=f"Read error: {str(e)}"
            )
    
    def _write_file(self, file_path: str, content: str) -> ToolResult:
        """Write content to file."""
        try:
            # Create parent directory if it doesn't exist
            parent_dir = os.path.dirname(file_path)
            if parent_dir and not os.path.exists(parent_dir):
                os.makedirs(parent_dir, exist_ok=True)
                logger.info(f"Created directory: {parent_dir}")
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"Wrote {len(content)} bytes to {file_path}")
            return ToolResult(
                success=True,
                output=f"Successfully wrote {len(content)} bytes to {file_path}"
            )
        
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=f"Write error: {str(e)}"
            )
    
    def _delete_file(self, file_path: str) -> ToolResult:
        """Delete a file."""
        try:
            if not os.path.exists(file_path):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"File not found: {file_path}"
                )
            
            if os.path.isfile(file_path):
                os.remove(file_path)
                logger.info(f"Deleted file: {file_path}")
                return ToolResult(
                    success=True,
                    output=f"Successfully deleted: {file_path}"
                )
            else:
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Path is not a file: {file_path}"
                )
        
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=f"Delete error: {str(e)}"
            )
    
    def _patch_file(
        self,
        file_path: str,
        tool_input: Dict[str, Any]
    ) -> ToolResult:
        """
        Apply patch to file using diff-based patching.
        
        Expected tool_input:
        {
            "path": "/path/to/file",
            "operation": "patch",
            "patch_format": "unified_diff" | "line_edits" | "structured",
            "patch_data": <format-specific data>
        }
        """
        patch_format = tool_input.get("patch_format", "unified_diff")
        patch_data = tool_input.get("patch_data")
        
        if not patch_data:
            return ToolResult(
                success=False,
                output="",
                error="patch_data is required for patch operation"
            )
        
        # Validate patch before applying
        is_valid, error_msg = PatchManager.validate_patch(
            file_path, patch_format, patch_data
        )
        
        if not is_valid:
            return ToolResult(
                success=False,
                output="",
                error=f"Patch validation failed: {error_msg}"
            )
        
        # Apply patch
        patch_result = PatchManager.apply_patch(
            file_path, patch_format, patch_data
        )
        
        if patch_result.success:
            return ToolResult(
                success=True,
                output=(
                    f"Successfully applied patch: {patch_result.lines_changed} lines changed. "
                    f"File: {patch_result.original_line_count} -> {patch_result.new_line_count} lines"
                )
            )
        else:
            return ToolResult(
                success=False,
                output="",
                error=patch_result.error or "Patch application failed"
            )


def format_tool_result_for_model(
    tool_use_id: str,
    result: ToolResult
) -> Dict[str, Any]:
    """
    Format tool result for sending back to the model.
    
    Args:
        tool_use_id: ID of the tool use this result is for
        result: Tool execution result
    
    Returns:
        Formatted content block for model API
    """
    if result.success:
        content = result.output
    else:
        content = f"Error: {result.error}\n\nOutput: {result.output}" if result.output else f"Error: {result.error}"
    
    # Format for Anthropic/Bedrock API
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": content,
        "is_error": not result.success
    }
