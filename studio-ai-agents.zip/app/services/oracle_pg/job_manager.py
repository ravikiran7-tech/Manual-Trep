"""Job manager: enqueue, concurrency, frozen config, crash resume."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Optional

from app.core.config import get_settings
from app.core.security import SecurityValidator
from app.services.oracle_pg.orchestrator import TransformationOrchestrator
from app.services.oracle_pg.progress import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_IN_PROGRESS,
    STATUS_QUEUED,
    default_progress,
    load_progress,
    save_progress,
    utc_now_iso,
)
from app.services.oracle_pg.workspace import (
    INPUT_PATH_KEYS,
    _resolve_input_file_path,
    ensure_job_dirs,
    job_config_path,
    job_root,
    jobs_base,
    relative_to_job_root,
    resolve_folder_key,
    validate_under_claude_dir,
)

_RESUMABLE_STATUSES = frozenset({STATUS_QUEUED, STATUS_IN_PROGRESS})

logger = logging.getLogger(__name__)
settings = get_settings()

_job_manager: Optional["JobManager"] = None

INPUT_MODE_COMPASS = settings.oracle_pg_agent.input_mode_compass


class JobManager:
    def __init__(self) -> None:
        max_jobs = settings.oracle_pg_agent.max_concurrent_jobs
        self._semaphore = asyncio.Semaphore(max_jobs)
        self._running: set[str] = set()
        self._tasks: dict[str, asyncio.Task] = {}
        self._orchestrator = TransformationOrchestrator(self)

    def clear_running(self, folder_key: str) -> None:
        self._running.discard(folder_key)

    def is_running(self, folder_key: str) -> bool:
        return folder_key in self._running

    def _workspace_root(self) -> str:
        return settings.claude_workspace

    def _resolve_folder_key(self, job_id: str) -> str:
        folder_key = resolve_folder_key(job_id, self._workspace_root())
        if folder_key is None:
            raise FileNotFoundError(f"Job not found: {job_id}")
        return folder_key

    async def launch(self, request: dict[str, Any]) -> dict[str, Any]:
        db_name = request.get("dbName")
        if not db_name:
            raise ValueError("dbName is required")

        SecurityValidator.validate_alphanumeric(str(db_name).replace("-", "_"), "dbName")

        job_id = request.get("jobId") or request.get("analysisId") or db_name
        SecurityValidator.validate_alphanumeric(job_id.replace("-", "_"), "jobId")

        input_paths = request.get("inputPaths")
        if not input_paths:
            raise ValueError("inputPaths is required")

        if request.get("claudeWorkspace"):
            raise ValueError(
                "claudeWorkspace must not be sent in the request; use CLAUDE_WORKSPACE env"
            )

        workspace_override = self._workspace_root()
        folder_key = db_name

        resolved_paths = self._resolve_input_paths(
            folder_key, input_paths, workspace_override
        )
        ddl_path = resolved_paths["ddlExport"]

        ensure_job_dirs(folder_key, workspace_override)

        frozen = self._freeze_config(
            job_id,
            request,
            ddl_path,
            resolved_paths=resolved_paths,
            workspace_override=workspace_override,
            folder_key=folder_key,
        )

        self._stage_compass_inputs(folder_key, resolved_paths)

        progress = default_progress(job_id)
        progress["status"] = STATUS_QUEUED
        progress["message"] = "Job queued"
        save_progress(folder_key, progress)

        await self._enqueue(folder_key)

        return {
            "jobId": job_id,
            "status": STATUS_QUEUED,
            "workspacePath": str(job_root(folder_key, workspace_override)),
            "dbName": frozen.get("dbName"),
        }

    def _resolve_input_paths(
        self,
        db_name: str,
        input_paths: dict[str, Any],
        workspace_override: Optional[str],
    ) -> dict[str, str]:
        """Validate compass file paths under _claude and return job-relative paths."""
        required = ("ddlExport", "asisSchema", "incompatibilityResults", "rulesRemediation")
        for key in required:
            if not input_paths.get(key):
                raise ValueError(f"inputPaths.{key} is required")

        resolved: dict[str, str] = {}
        for key in INPUT_PATH_KEYS:
            raw = input_paths.get(key)
            if not raw:
                continue

            # Filesystem-only value: it is opened with pathlib and referenced from
            # prompts, never placed on a command line. Compass artifact names may
            # legitimately contain spaces and parentheses, so the shell-oriented
            # validate_path() is too strict here. Containment is enforced below by
            # _resolve_input_file_path() + validate_under_claude_dir().
            SecurityValidator.validate_filesystem_path(raw, f"inputPaths.{key}")
            src = _resolve_input_file_path(db_name, raw, workspace_override)

            if not src.is_file():
                raise FileNotFoundError(f"Input file not found for inputPaths.{key}: {raw}")

            validate_under_claude_dir(db_name, src, workspace_override)
            resolved[key] = relative_to_job_root(db_name, src, workspace_override)

        return resolved

    def _freeze_config(
        self,
        job_id: str,
        request: dict[str, Any],
        ddl_path: str,
        *,
        resolved_paths: dict[str, str],
        workspace_override: str,
        folder_key: str,
    ) -> dict[str, Any]:
        selected_rules = list(request.get("selectedRules") or [])
        rule_scope = str(request.get("ruleScope", "all"))
        frozen: dict[str, Any] = {
            "jobId": job_id,
            "analysisId": request.get("analysisId") or job_id,
            "dbName": request.get("dbName", "database"),
            "sourceDatabaseVersion": request.get("sourceDatabaseVersion", "Oracle 19c"),
            "targetDatabaseVersion": str(request.get("targetDatabaseVersion", "16")),
            "aiAgent": request.get("aiAgent", "claude-sonnet-5-5"),
            "selectedRules": selected_rules,
            "ruleScope": rule_scope,
            "inputMode": INPUT_MODE_COMPASS,
            "assessmentDataPath": "input/assessment.json",
            "frozenAt": utc_now_iso(),
            "claudeWorkspace": workspace_override,
            "inputPaths": resolved_paths,
            "ddlExportPath": resolved_paths.get("ddlExport", ddl_path),
        }

        path = job_config_path(folder_key, workspace_override)
        with path.open("w", encoding="utf-8") as fh:
            json.dump(frozen, fh, indent=2)
        return frozen

    def _stage_compass_inputs(self, folder_key: str, resolved_paths: dict[str, str]) -> None:
        """Compass mode references files in-place under _claude; no copying."""
        logger.info(
            "Job %s using in-place compass inputs: %s",
            folder_key,
            list(resolved_paths.keys()),
        )

    def _has_active_task(self, folder_key: str) -> bool:
        task = self._tasks.get(folder_key)
        return task is not None and not task.done()

    def _track_task(self, folder_key: str, task: asyncio.Task) -> None:
        self._tasks[folder_key] = task

        def _on_done(_: asyncio.Task) -> None:
            if self._tasks.get(folder_key) is task:
                self._tasks.pop(folder_key, None)

        task.add_done_callback(_on_done)

    async def _enqueue(self, folder_key: str) -> None:
        if folder_key in self._running or self._has_active_task(folder_key):
            return
        task = asyncio.create_task(
            self._run_with_semaphore(folder_key),
            name=f"oracle-pg-{folder_key}",
        )
        self._track_task(folder_key, task)

    async def _run_with_semaphore(self, folder_key: str) -> None:
        async with self._semaphore:
            self._running.add(folder_key)
            progress = load_progress(folder_key)
            progress["status"] = STATUS_IN_PROGRESS
            save_progress(folder_key, progress)
            await self._orchestrator.run(folder_key)

    def _iter_job_directories(self) -> list[tuple[str, Path]]:
        """Yield (folder_key, job_dir) pairs under schema-modernization/."""
        base = jobs_base(self._workspace_root())
        if not base.exists():
            return []

        directories: list[tuple[str, Path]] = []
        for child in base.iterdir():
            if child.is_dir():
                directories.append((child.name, child))
        return directories

    @staticmethod
    def _resume_sort_key(job_dir: Path) -> str:
        progress_file = job_dir / "state" / "progress.json"
        if progress_file.exists():
            try:
                with progress_file.open(encoding="utf-8") as fh:
                    updated_at = json.load(fh).get("updatedAt")
                if updated_at:
                    return str(updated_at)
            except (json.JSONDecodeError, OSError):
                pass

        config_file = job_dir / "job_config.json"
        if config_file.exists():
            try:
                with config_file.open(encoding="utf-8") as fh:
                    frozen_at = json.load(fh).get("frozenAt")
                if frozen_at:
                    return str(frozen_at)
            except (json.JSONDecodeError, OSError):
                pass

        return job_dir.name

    def _load_progress_from_dir(self, job_dir: Path, folder_key: str) -> dict[str, Any]:
        progress_file = job_dir / "state" / "progress.json"
        if not progress_file.exists():
            return default_progress(folder_key)
        with progress_file.open(encoding="utf-8") as fh:
            return json.load(fh)

    async def resume_in_progress_jobs(self) -> int:
        """Re-enqueue queued and in-progress jobs found on disk (survives container restart)."""
        candidates: list[tuple[str, Path]] = []
        for folder_key, job_dir in self._iter_job_directories():
            progress_file = job_dir / "state" / "progress.json"
            config_file = job_dir / "job_config.json"
            if not progress_file.exists() or not config_file.exists():
                continue

            progress = self._load_progress_from_dir(job_dir, folder_key)
            if progress.get("status") not in _RESUMABLE_STATUSES:
                continue

            if folder_key in self._running or self._has_active_task(folder_key):
                continue

            candidates.append((folder_key, job_dir))

        candidates.sort(key=lambda item: self._resume_sort_key(item[1]))

        resumed = 0
        for folder_key, _job_dir in candidates:
            logger.info("Resuming Oracle PG job %s", folder_key)
            await self._enqueue(folder_key)
            resumed += 1

        return resumed

    def get_status(self, job_id: str) -> dict[str, Any]:
        SecurityValidator.validate_alphanumeric(job_id.replace("-", "_"), "jobId")
        folder_key = self._resolve_folder_key(job_id)
        return load_progress(folder_key)

    def get_job_config(self, job_id: str) -> dict[str, Any]:
        folder_key = self._resolve_folder_key(job_id)
        path = job_config_path(folder_key, self._workspace_root())
        if not path.exists():
            raise FileNotFoundError(f"Job config not found: {job_id}")
        with path.open(encoding="utf-8") as fh:
            return json.load(fh)

    def list_objects(
        self,
        job_id: str,
        *,
        offset: int = 0,
        limit: int = 100,
    ) -> dict[str, Any]:
        from app.services.oracle_pg.progress import load_conversion_plan

        folder_key = self._resolve_folder_key(job_id)
        plan = load_conversion_plan(folder_key)
        slice_ = plan[offset : offset + limit]
        items = [
            {
                "objectId": o.get("objectId"),
                "schema": o.get("schema"),
                "name": o.get("name"),
                "type": o.get("type"),
                "status": o.get("status"),
                "conversionStatus": o.get("conversionStatus"),
                "confidenceScore": o.get("confidenceScore"),
                "requiresManualReview": o.get("requiresManualReview"),
                "executionPhase": o.get("executionPhase"),
            }
            for o in slice_
        ]
        return {
            "jobId": job_id,
            "total": len(plan),
            "offset": offset,
            "limit": limit,
            "objects": items,
        }


def get_job_manager() -> JobManager:
    global _job_manager
    if _job_manager is None:
        _job_manager = JobManager()
    return _job_manager
