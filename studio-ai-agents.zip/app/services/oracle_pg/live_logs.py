"""Human-readable live log formatters for Oracle PG transformation."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# Keep in sync with PHASE_INITIALIZE in progress.py (avoid circular import).
_DEFAULT_PHASE = "Schema Analysis"

# Mirror transformation_log_service icon/color palette for UI consistency.
ALLOWED_ICONS: dict[str, str] = {
    "play": "#4CAF50",
    "code": "#2196F3",
    "lightning": "#FF9800",
    "check": "#4CAF50",
    "search": "#2196F3",
    "settings": "#9C27B0",
    "warning": "#FFC107",
    "info": "#2196F3",
}

DEFAULT_ICON = "info"
DEFAULT_COLOR = ALLOWED_ICONS[DEFAULT_ICON]

# job_id -> current phase (updated on progress events)
_current_phase: dict[str, str] = {}

_MAX_MESSAGE_LEN = 200


def icon_color(icon: str) -> str:
    return ALLOWED_ICONS.get(icon, DEFAULT_COLOR)


def set_current_phase(job_id: str, phase: str) -> None:
    if phase:
        _current_phase[job_id] = phase


def get_current_phase(job_id: str) -> str:
    return _current_phase.get(job_id, _DEFAULT_PHASE)


def _now_hms() -> str:
    return datetime.now(timezone.utc).strftime("%H:%M:%S")


def _truncate(text: str, limit: int = _MAX_MESSAGE_LEN) -> str:
    stripped = " ".join(text.split())
    if len(stripped) <= limit:
        return stripped
    return stripped[: limit - 3] + "..."


def relative_path(job_root: Path | str | None, file_path: str) -> str:
    """Return a path relative to the job root when possible."""
    if not file_path:
        return file_path
    normalized = file_path.replace("\\", "/")
    if job_root:
        root = Path(job_root).resolve()
        try:
            return Path(file_path).resolve().relative_to(root).as_posix()
        except ValueError:
            pass
    parts = normalized.split("/schema-modernization/", 1)
    if len(parts) == 2:
        sub = parts[1].split("/", 1)
        if len(sub) == 2:
            return sub[1]
    return normalized.split("/")[-1] if "/" in normalized else normalized


def build_log_entry(
    job_id: str,
    *,
    message: str,
    icon: str = DEFAULT_ICON,
    phase: Optional[str] = None,
    timestamp: Optional[str] = None,
) -> dict[str, Any]:
    resolved_phase = phase or get_current_phase(job_id)
    resolved_icon = icon if icon in ALLOWED_ICONS else DEFAULT_ICON
    return {
        "timestamp": timestamp or _now_hms(),
        "phase": resolved_phase,
        "icon": resolved_icon,
        "message": message,
        "color": icon_color(resolved_icon),
    }


def format_progress_event(job_id: str, progress: dict[str, Any]) -> dict[str, Any]:
    phase = progress.get("phase") or get_current_phase(job_id)
    set_current_phase(job_id, phase)

    status = progress.get("status", "")
    if status == "completed":
        icon = "check"
    elif status == "failed":
        icon = "warning"
    elif status == "queued":
        icon = "info"
    else:
        icon = "settings"

    message = progress.get("message") or f"Phase: {phase}"
    if progress.get("errorDetail"):
        message = f"{message} — {progress['errorDetail']}"

    return build_log_entry(job_id, message=message, icon=icon, phase=phase)


def format_session_start(
    job_id: str,
    session_kind: str,
    *,
    batch_type: Optional[str] = None,
) -> dict[str, Any]:
    labels = {
        "initializer": "initializer",
        "converter": "converter",
        "artifact": "artifact",
    }
    label = labels.get(session_kind, session_kind)
    if session_kind == "converter" and batch_type:
        message = f"Starting {label} session for {batch_type} batch"
    else:
        message = f"Starting {label} session"
    return build_log_entry(job_id, message=message, icon="play")


def format_post_tool_use(
    job_id: str,
    tool_name: str,
    tool_input: dict[str, Any],
    *,
    job_root: Path | str | None = None,
) -> Optional[dict[str, Any]]:
    if tool_name == "Read":
        file_path = str(tool_input.get("file_path", ""))
        if not file_path:
            return None
        rel = relative_path(job_root, file_path)
        return build_log_entry(job_id, message=f"Reading {rel}", icon="search")

    if tool_name == "Glob":
        pattern = str(tool_input.get("pattern", tool_input.get("glob_pattern", "*")))
        return build_log_entry(job_id, message=f"Searching files: {pattern}", icon="search")

    if tool_name == "Grep":
        pattern = str(tool_input.get("pattern", ""))
        path = str(tool_input.get("path", tool_input.get("glob", "")))
        if path:
            rel = relative_path(job_root, path)
            return build_log_entry(
                job_id,
                message=f"Searching '{pattern}' in {rel}",
                icon="search",
            )
        return build_log_entry(job_id, message=f"Searching for '{pattern}'", icon="search")

    if tool_name in ("Write", "Edit"):
        file_path = str(tool_input.get("file_path", ""))
        if not file_path:
            return None
        if file_path.replace("\\", "/").endswith("/state/progress.json"):
            return None
        rel = relative_path(job_root, file_path)
        if "conversion-plan" in file_path.replace("\\", "/"):
            return build_log_entry(job_id, message="Updating conversion plan", icon="lightning")
        if file_path.endswith(".sql"):
            name = Path(file_path).name
            return build_log_entry(job_id, message=f"Writing SQL script: {name}", icon="lightning")
        verb = "Updating" if tool_name == "Edit" else "Writing"
        return build_log_entry(job_id, message=f"{verb} {rel}", icon="lightning")

    return None


def format_assistant_text(job_id: str, text: str) -> Optional[dict[str, Any]]:
    cleaned = text.strip()
    if not cleaned:
        return None
    return build_log_entry(job_id, message=_truncate(cleaned), icon="info")


def format_tool_use_block(job_id: str, name: str, tool_input: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Format a ToolUseBlock from AssistantMessage (pre-execution intent)."""
    if name == "Read":
        file_path = str(tool_input.get("file_path", ""))
        if file_path:
            return build_log_entry(job_id, message=f"Reading {Path(file_path).name}", icon="search")
    if name in ("Write", "Edit"):
        file_path = str(tool_input.get("file_path", ""))
        if file_path:
            return build_log_entry(
                job_id,
                message=f"Preparing to {'edit' if name == 'Edit' else 'write'} {Path(file_path).name}",
                icon="lightning",
            )
    if name == "Glob":
        pattern = str(tool_input.get("pattern", "*"))
        return build_log_entry(job_id, message=f"Listing files: {pattern}", icon="search")
    if name == "Grep":
        pattern = str(tool_input.get("pattern", ""))
        return build_log_entry(job_id, message=f"Searching for '{pattern}'", icon="search")
    return None


def format_sdk_message(job_id: str, message: Any) -> list[dict[str, Any]]:
    """Convert an SDK message object into zero or more log entries."""
    entries: list[dict[str, Any]] = []

    try:
        from claude_agent_sdk.types import AssistantMessage, ResultMessage, SystemMessage
        from claude_agent_sdk.types import TextBlock, ToolUseBlock
    except ImportError:
        return entries

    if isinstance(message, SystemMessage):
        subtype = getattr(message, "subtype", None)
        if subtype in ("thinking_tokens", "init"):
            return entries
        return entries

    if isinstance(message, AssistantMessage):
        for block in message.content:
            if isinstance(block, TextBlock):
                entry = format_assistant_text(job_id, block.text)
                if entry:
                    entries.append(entry)
            elif isinstance(block, ToolUseBlock):
                entry = format_tool_use_block(job_id, block.name, block.input or {})
                if entry:
                    entries.append(entry)
        return entries

    if isinstance(message, ResultMessage):
        subtype = getattr(message, "subtype", None)
        if subtype == "success":
            entries.append(
                build_log_entry(job_id, message="Agent session completed", icon="check")
            )
        else:
            result = getattr(message, "result", None) or subtype or "unknown"
            entries.append(
                build_log_entry(
                    job_id,
                    message=f"Agent session stopped: {result}",
                    icon="warning",
                )
            )
        return entries

    return entries
