"""Job workspace path helpers."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from app.core.config import get_settings

MODERNIZATION_SUBDIR = "schema-modernization"
LEGACY_WORKSPACE_SUBDIR = "oracle-pg-transformation"
WORKSPACE_SUBDIR = MODERNIZATION_SUBDIR
CLAUDE_SUBDIR = "_claude"

INPUT_PATH_KEYS = (
    "ddlExport",
    "asisSchema",
    "incompatibilityResults",
    "rulesRemediation",
    "schemaAnalysis",
)


def workspace_base(workspace_override: Optional[str] = None) -> Path:
    if workspace_override:
        return Path(workspace_override)
    return Path(get_settings().claude_workspace)


def jobs_base(workspace_override: Optional[str] = None) -> Path:
    return workspace_base(workspace_override) / MODERNIZATION_SUBDIR


def legacy_jobs_base(workspace_override: Optional[str] = None) -> Path:
    return workspace_base(workspace_override) / LEGACY_WORKSPACE_SUBDIR


def job_root(db_name: str, workspace_override: Optional[str] = None) -> Path:
    """Job directory: {claude_workspace}/schema-modernization/{dbName}/"""
    return jobs_base(workspace_override) / db_name


def modernization_job_root(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override)


def claude_inputs_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / CLAUDE_SUBDIR


def claude_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return claude_inputs_dir(db_name, workspace_override)


def job_config_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "job_config.json"


def input_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "input"


def state_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "state"


def output_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "output"


def stream_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "stream"


def conversion_plan_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "conversion-plan.json"


def progress_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "progress.json"


def events_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "events.jsonl"


def logs_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "logs.jsonl"


def logs_meta_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "logs.meta.json"


def workspace_override_from_config(config: dict[str, Any]) -> Optional[str]:
    return config.get("claudeWorkspace")


def resolve_job_path(
    db_name: str,
    relative_or_absolute: str,
    workspace_override: Optional[str] = None,
) -> Path:
    """Resolve a path relative to the job root; absolute paths must stay under that root."""
    return ensure_path_under_job_root(
        db_name,
        Path(relative_or_absolute),
        workspace_override,
    )


def ensure_path_under_job_root(
    db_name: str,
    candidate: Path,
    workspace_override: Optional[str] = None,
) -> Path:
    """Resolve ``candidate`` and ensure it stays under ``job_root(db_name)`` (Sonar S2083/S6549)."""
    allowed_root = job_root(db_name, workspace_override).resolve()
    if candidate.is_absolute():
        canonical = candidate.resolve()
    else:
        canonical = (allowed_root / candidate).resolve()
    try:
        canonical.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(
            f"Path traversal detected: '{candidate}' is outside job workspace '{allowed_root}'"
        ) from exc
    return canonical


def ensure_path_under_jobs_base(
    path: Path,
    workspace_override: Optional[str] = None,
) -> Path:
    """Resolve ``path`` and ensure it stays under ``jobs_base``."""
    allowed_root = jobs_base(workspace_override).resolve()
    canonical = path.resolve()
    try:
        canonical.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(
            f"Path traversal detected: '{path}' is outside jobs base '{allowed_root}'"
        ) from exc
    return canonical


def _load_json_dict(validated_path: Path) -> Optional[dict[str, Any]]:
    """Load JSON object from a path that has already been validated for containment."""
    if not validated_path.is_file():
        return None
    try:
        with validated_path.open(encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def read_json_file_at(
    db_name: str,
    path: Path | str,
    workspace_override: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """Read a JSON object from a path under the job workspace."""
    safe_path = ensure_path_under_job_root(db_name, Path(path), workspace_override)
    return _load_json_dict(safe_path)


def write_json_file_at(
    db_name: str,
    path: Path | str,
    payload: Any,
    workspace_override: Optional[str] = None,
    *,
    indent: int = 2,
) -> Path:
    """Write JSON to a path under the job workspace."""
    safe_path = ensure_path_under_job_root(db_name, Path(path), workspace_override)
    safe_path.parent.mkdir(parents=True, exist_ok=True)
    with safe_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=indent)
    return safe_path


def input_path(db_name: str, key: str, config: dict[str, Any]) -> Path:
    """Resolve a configured input file path from frozen job_config."""
    override = workspace_override_from_config(config)
    input_paths = config.get("inputPaths") or {}

    if key in input_paths:
        return resolve_job_path(db_name, input_paths[key], override)

    if key == "assessment":
        return resolve_job_path(
            db_name,
            config.get("assessmentDataPath", "input/assessment.json"),
            override,
        )

    raise KeyError(f"Unknown or unset input path key: {key}")


def _resolve_input_file_path(
    db_name: str,
    raw: str,
    workspace_override: Optional[str] = None,
) -> Path:
    """Resolve client inputPaths entry to a path under the job workspace."""
    return ensure_path_under_job_root(db_name, Path(raw), workspace_override)


def validate_under_claude_dir(
    db_name: str,
    absolute_path: Path,
    workspace_override: Optional[str] = None,
) -> None:
    """Ensure input file lives under {job_root}/_claude/."""
    claude = claude_inputs_dir(db_name, workspace_override).resolve()
    resolved = absolute_path.resolve()
    try:
        resolved.relative_to(claude)
    except ValueError as exc:
        raise ValueError(
            f"Input file must be under {claude}, got: {resolved}"
        ) from exc


def relative_to_job_root(
    db_name: str,
    absolute_path: Path,
    workspace_override: Optional[str] = None,
) -> str:
    """Return a path relative to the job root for freezing in job_config."""
    root = job_root(db_name, workspace_override).resolve()
    resolved = absolute_path.resolve()
    try:
        return resolved.relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError(
            f"Input file must be under job workspace {root}, got: {resolved}"
        ) from exc


def ensure_job_dirs(db_name: str, workspace_override: Optional[str] = None) -> Path:
    root = job_root(db_name, workspace_override)
    for sub in ("input", "state", "output", "stream"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    claude_inputs_dir(db_name, workspace_override).mkdir(parents=True, exist_ok=True)
    return root


def _read_job_config(
    path: Path,
    workspace_override: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    if not path.exists():
        return None
    safe_path = ensure_path_under_jobs_base(path, workspace_override)
    return _load_json_dict(safe_path)


def _folder_key_from_config(data: dict[str, Any], job_id: str) -> Optional[str]:
    if data.get("jobId") == job_id or data.get("dbName") == job_id:
        return data.get("dbName") or data.get("jobId")
    return None


def resolve_folder_key(job_id: str, workspace_override: Optional[str] = None) -> Optional[str]:
    """Map API jobId to on-disk folder name (dbName under schema-modernization)."""
    if job_root(job_id, workspace_override).exists():
        return job_id

    for base in (jobs_base(workspace_override), legacy_jobs_base(workspace_override)):
        if not base.exists():
            continue
        for child in sorted(base.iterdir()):
            if not child.is_dir():
                continue
            data = _read_job_config(child / "job_config.json", workspace_override)
            if not data:
                continue
            key = _folder_key_from_config(data, job_id)
            if key and child.name == key:
                return child.name
            if data.get("jobId") == job_id:
                return child.name
    return None


def discover_workspace_override(job_id: str) -> Optional[str]:
    """Locate job_config.json and return the workspace override used for this job."""
    settings = get_settings()
    folder_key = resolve_folder_key(job_id) or job_id
    candidates: list[Optional[str]] = [None, settings.claude_workspace]

    for override in candidates:
        for base_fn, name in (
            (jobs_base, MODERNIZATION_SUBDIR),
            (legacy_jobs_base, LEGACY_WORKSPACE_SUBDIR),
        ):
            cfg_path = base_fn(override) / folder_key / "job_config.json"
            if not cfg_path.exists() and folder_key == job_id:
                cfg_path = base_fn(override) / job_id / "job_config.json"
            if not cfg_path.exists():
                continue
            data = _read_job_config(cfg_path, override)
            if data:
                return data.get("claudeWorkspace") or override or settings.claude_workspace
    return settings.claude_workspace
