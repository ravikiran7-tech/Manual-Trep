"""Artifact validation and packaging for Oracle PG transformation jobs."""

from __future__ import annotations

import csv
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Optional

from app.services.oracle_pg.plan_schema import (
    converted_object_label,
    output_location_for_object,
    source_object_label,
)
from app.services.oracle_pg.progress import (
    PHASE_LABELS,
    SCRIPT_ORDER,
    count_deliverable_conversions,
    load_conversion_plan,
    load_progress,
)
from app.services.oracle_pg.report_metrics import (
    build_confidence_breakdown,
    build_database_metadata,
    build_executive_summary,
    build_generated_scripts,
    build_objects_by_type,
    build_timing_block,
)
from app.services.oracle_pg.rule_engine import user_facing_status
from app.services.oracle_pg.workspace import input_path, output_dir

MANUAL_REVIEW_CSV = "Manual_Review_Checklist.csv"
TRANSFORMATION_SUMMARY_JSON = "transformation_summary.json"

CONFIDENCE_SORT = {"MANUAL": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3}


def expected_script_names(db_name: str) -> list[str]:
    return [f"{db_name}_{name}" for name in SCRIPT_ORDER]


def normalize_output_scripts(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> list[str]:
    """Rename unprefixed or legacy agent scripts to PRD {dbName}_create_*.sql naming."""
    from app.services.oracle_pg.progress import LEGACY_SCRIPT_MAP

    out = output_dir(job_id, workspace_override)
    renamed: list[str] = []

    for suffix in SCRIPT_ORDER:
        prefixed = out / f"{db_name}_{suffix}"
        if prefixed.exists():
            continue
        candidates = [out / suffix]
        for legacy, mapped in LEGACY_SCRIPT_MAP.items():
            if mapped == suffix:
                candidates.append(out / legacy)
                candidates.append(out / f"{db_name}_{legacy}")
        for candidate in candidates:
            if candidate.exists() and candidate != prefixed:
                candidate.rename(prefixed)
                renamed.append(prefixed.name)
                break
    return renamed


def validate_script_order(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> list[str]:
    warnings: list[str] = []
    out = output_dir(job_id, workspace_override)
    for script in expected_script_names(db_name):
        if not (out / script).exists():
            warnings.append(f"Missing script: {script}")
    return warnings


def _status_mismatch_warnings(plan: list[dict[str, Any]]) -> list[str]:
    warnings: list[str] = []
    for obj in plan:
        if obj.get("status") != "converted":
            continue
        expected = obj.get("expectedConversionStatus")
        actual = obj.get("conversionStatus")
        if expected and actual and expected != actual:
            name = source_object_label(obj)
            warnings.append(f"Status mismatch for {name}: expected {expected}, got {actual}")
    return warnings


def _extract_ddl_snippet(
    ddl_path: Path, schema: str, name: str, max_lines: int = 8
) -> Optional[str]:
    if not ddl_path.is_file():
        return None
    try:
        text = ddl_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    pattern = (
        rf"(?im)^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:TABLE|VIEW|INDEX|SEQUENCE|TRIGGER|"
        rf"PROCEDURE|FUNCTION|PACKAGE)\s+"
        rf"(?:{re.escape(schema)}\.)?{re.escape(name)}\b.*?(?=^\s*CREATE\s+|\Z)"
    )
    match = re.search(pattern, text, re.DOTALL | re.MULTILINE)
    if match:
        return "\n".join(match.group(0).strip().splitlines()[:max_lines])
    return None


def _extract_pg_snippet(
    sql_path: Path, schema: str, name: str, max_lines: int = 8
) -> Optional[str]:
    if not sql_path.is_file():
        return None
    try:
        text = sql_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    for line in text.splitlines():
        if name.lower() in line.lower():
            idx = text.splitlines().index(line)
            return "\n".join(text.splitlines()[idx : idx + max_lines])
    return None


def _review_reason(obj: dict[str, Any]) -> str:
    reasons: list[str] = []
    guidance = obj.get("reviewGuidance")
    if guidance:
        reasons.append(str(guidance))
    changes = obj.get("changes") or []
    if not isinstance(changes, list):
        return "; ".join(reasons)
    for change in changes:
        if isinstance(change, dict):
            if change.get("requiresReview") and change.get("description"):
                reasons.append(str(change["description"]))
        elif isinstance(change, str) and change.strip():
            # Converter agents sometimes emit free-text change notes.
            reasons.append(change.strip())
    return "; ".join(reasons)


def _format_source_location_for_display(value: str) -> str:
    """Show basename and line range only (no workspace paths like _claude/)."""
    if not value:
        return value
    normalized = value.replace("\\", "/")
    if ":" in normalized:
        path_part, _, rest = normalized.partition(":")
        return f"{Path(path_part).name}:{rest}"
    return Path(normalized).name


def _include_in_manual_review(obj: dict[str, Any]) -> bool:
    if obj.get("requiresManualReview"):
        return True
    confidence = str(obj.get("confidenceScore", "")).upper()
    if confidence in {"LOW", "MANUAL"}:
        return True
    if obj.get("status") == "failed":
        return True
    if obj.get("conversionStatus") == "manual_implementation":
        return True
    return False


def build_manual_review_checklist(
    plan: list[dict[str, Any]],
    db_name: str,
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for obj in plan:
        if not _include_in_manual_review(obj):
            continue
        rows.append(
            {
                "Source Object": source_object_label(obj),
                "Converted Object": converted_object_label(obj),
                "Object Type": str(obj.get("type", "")),
                "Confidence": str(obj.get("confidenceScore", "MEDIUM")),
                "Review Reason": _review_reason(obj),
                "Source Location": _format_source_location_for_display(
                    str(obj.get("sourceLocation", ""))
                ),
                "Output Location": output_location_for_object(obj, db_name),
            }
        )

    rows.sort(
        key=lambda r: (
            CONFIDENCE_SORT.get(r["Confidence"].upper(), 99),
            r["Object Type"],
            r["Source Object"],
        )
    )
    return rows


def write_manual_review_csv(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> Path:
    plan = load_conversion_plan(job_id)
    rows = build_manual_review_checklist(plan, db_name)
    path = output_dir(job_id, workspace_override) / MANUAL_REVIEW_CSV
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "Source Object",
        "Converted Object",
        "Object Type",
        "Confidence",
        "Review Reason",
        "Source Location",
        "Output Location",
    ]
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return path


def build_transformation_summary(
    plan: list[dict[str, Any]],
    job_config: dict[str, Any],
    db_name: str,
    *,
    progress: Optional[dict[str, Any]] = None,
    job_id: Optional[str] = None,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    converted = sum(1 for o in plan if o.get("status") == "converted")
    failed = sum(1 for o in plan if o.get("status") == "failed")
    total = len(plan)
    deliverable = count_deliverable_conversions(plan)
    auto = sum(1 for o in plan if o.get("conversionStatus") == "auto_converted")
    deliverable_rate = f"{int((deliverable / total) * 100)}%" if total else "0%"
    auto_rate = f"{int((auto / total) * 100)}%" if total else "0%"

    type_counts: Counter[str] = Counter()
    package_source = 0
    package_functions = 0
    for obj in plan:
        if obj.get("status") != "converted":
            continue
        t = str(obj.get("type", "")).upper()
        type_counts[t] += 1
        if t == "PACKAGE":
            package_source += 1
        if t == "FUNCTION" and obj.get("decomposedFromPackage"):
            package_functions += 1

    confidence = Counter(str(o.get("confidenceScore", "")).upper() for o in plan)
    review_count = sum(1 for o in plan if _include_in_manual_review(o))

    packages_label = str(package_source)
    if package_source or package_functions:
        packages_label = f"{package_source} (decomposed into {package_functions} functions)"

    summary: dict[str, Any] = {
        "database": {
            "name": db_name,
            "from": job_config.get("sourceDatabaseVersion", "Oracle"),
            "to": f"PostgreSQL {job_config.get('targetDatabaseVersion', '16')}",
        },
        "conversionResult": {
            "total_objects": total,
            "converted": converted,
            "deliverable_converted": deliverable,
            "failed": failed,
            "conversion_rate": deliverable_rate,
            "auto_conversion_rate": auto_rate,
        },
        "whatWasConverted": {
            "tables": type_counts.get("TABLE", 0),
            "column_defaults": type_counts.get("DEFAULT", 0),
            "sequences": type_counts.get("SEQUENCE", 0),
            "primary_keys": type_counts.get("PRIMARY_KEY", 0),
            "unique_constraints": type_counts.get("UNIQUE", 0),
            "foreign_keys": type_counts.get("FOREIGN_KEY", 0),
            "check_constraints": type_counts.get("CHECK", 0),
            "indexes": type_counts.get("INDEX", 0),
            "views": type_counts.get("VIEW", 0),
            "materialized_views": type_counts.get("MATERIALIZED_VIEW", 0),
            "functions": type_counts.get("FUNCTION", 0),
            "procedures": type_counts.get("PROCEDURE", 0),
            "packages": packages_label,
            "triggers": type_counts.get("TRIGGER", 0),
        },
        "reviewNeeded": {
            "objects_requiring_review": review_count,
            "high_confidence_objects": confidence.get("HIGH", 0),
            "medium_confidence_objects": confidence.get("MEDIUM", 0),
            "low_confidence_objects": confidence.get("LOW", 0),
            "manual_follow_up_required": confidence.get("MANUAL", 0),
            "could_not_convert": failed,
        },
    }

    effective_job_id = job_id or str(job_config.get("jobId") or db_name)
    summary["databaseMetadata"] = build_database_metadata(
        effective_job_id,
        job_config,
        db_name,
        workspace_override,
    )
    summary["timing"] = build_timing_block(progress or {})
    summary["executiveSummary"] = build_executive_summary(plan)
    summary["objectsByType"] = build_objects_by_type(plan)
    summary["confidenceBreakdown"] = build_confidence_breakdown(plan)
    if job_id is not None:
        summary["generatedScripts"] = build_generated_scripts(
            job_id, db_name, workspace_override
        )
    return summary


def write_transformation_summary(
    job_id: str,
    db_name: str,
    job_config: dict[str, Any],
    workspace_override: Optional[str] = None,
) -> Path:
    plan = load_conversion_plan(job_id)
    progress = load_progress(job_id)
    summary = build_transformation_summary(
        plan,
        job_config,
        db_name,
        progress=progress,
        job_id=job_id,
        workspace_override=workspace_override,
    )
    path = output_dir(job_id, workspace_override) / TRANSFORMATION_SUMMARY_JSON
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    return path


def build_complete_schema(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> Path:
    out = output_dir(job_id, workspace_override)
    complete_path = out / f"{db_name}_complete_schema.sql"
    parts: list[str] = []
    for phase_num, suffix in enumerate(SCRIPT_ORDER, start=1):
        script_path = out / f"{db_name}_{suffix}"
        label = PHASE_LABELS.get(phase_num, suffix)
        parts.append(f"-- ========== {label} ==========")
        if script_path.is_file():
            parts.append(script_path.read_text(encoding="utf-8", errors="replace").strip())
        else:
            parts.append(f"-- (no objects in {suffix})")
        parts.append("")
    complete_path.write_text("\n".join(parts).strip() + "\n", encoding="utf-8")
    return complete_path


def _per_type_summary(plan: list[dict[str, Any]]) -> list[dict[str, Any]]:
    buckets: dict[str, Counter[str]] = {}
    for obj in plan:
        obj_type = str(obj.get("type", "UNKNOWN"))
        bucket = buckets.setdefault(obj_type, Counter())
        bucket[obj.get("conversionStatus") or "pending"] += 1

    rows: list[dict[str, Any]] = []
    for obj_type in sorted(buckets.keys()):
        counts = buckets[obj_type]
        total = sum(counts.values())
        auto = counts.get("auto_converted", 0)
        review = counts.get("require_review", 0)
        manual = counts.get("manual_implementation", 0)
        deliverable = auto + review + manual
        auto_rate = round((auto / total) * 100, 1) if total else 0.0
        deliverable_rate = round((deliverable / total) * 100, 1) if total else 0.0
        rows.append(
            {
                "objectType": obj_type,
                "total": total,
                "autoConverted": auto,
                "needReview": review,
                "manualEffortRequired": manual,
                "deliverableConverted": deliverable,
                "conversionRatePercent": deliverable_rate,
                "autoConversionRatePercent": auto_rate,
            }
        )
    return rows


def build_post_transformation_report(
    job_id: str,
    db_name: str,
    job_config: Optional[dict[str, Any]] = None,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    plan = load_conversion_plan(job_id)
    progress = load_progress(job_id)
    status_counts = Counter(obj.get("conversionStatus") or "pending" for obj in plan)
    deliverable = count_deliverable_conversions(plan)
    total_objects = len(plan)

    ddl_path: Optional[Path] = None
    if job_config:
        try:
            ddl_path = input_path(job_id, "ddlExport", job_config)
        except KeyError:
            ddl_path = None

    samples: dict[str, Any] = {}
    type_set = {str(o.get("type", "UNKNOWN")) for o in plan}
    for obj_type in sorted(type_set):
        for obj in plan:
            if obj.get("type") == obj_type and obj.get("status") == "converted":
                schema = obj.get("schema", "")
                name = obj.get("name", "")
                output_file = obj.get("outputFile", "")
                pg_path = output_dir(job_id, workspace_override) / f"{db_name}_{output_file}"
                sample: dict[str, Any] = {
                    "objectName": source_object_label(obj),
                    "conversionStatus": user_facing_status(obj.get("conversionStatus", "")),
                    "outputFile": f"{db_name}_{output_file}",
                }
                if ddl_path:
                    before = _extract_ddl_snippet(ddl_path, schema, name)
                    if before:
                        sample["oracleSnippet"] = before
                after = _extract_pg_snippet(pg_path, schema, name)
                if after:
                    sample["postgresqlSnippet"] = after
                samples[obj_type] = sample
                break

    out = output_dir(job_id, workspace_override)
    scripts = []
    for script in expected_script_names(db_name):
        path = out / script
        scripts.append(
            {
                "name": script,
                "path": str(path),
                "exists": path.exists(),
                "sizeBytes": path.stat().st_size if path.exists() else 0,
            }
        )

    warnings = validate_script_order(job_id, db_name, workspace_override)
    warnings.extend(_status_mismatch_warnings(plan))

    timing = build_timing_block(progress)
    executive = build_executive_summary(plan)
    failed_count = executive["failed"]
    confidence = build_confidence_breakdown(plan)

    report: dict[str, Any] = {
        "jobId": job_id,
        "dbName": db_name,
        "timing": timing,
        "summary": {
            "totalObjects": total_objects,
            "deliverableConverted": deliverable,
            "deliverableConversionRatePercent": round(
                (deliverable / total_objects) * 100, 1
            )
            if total_objects
            else 0.0,
            "autoConverted": status_counts.get("auto_converted", 0),
            "requireReview": status_counts.get("require_review", 0),
            "manualImplementation": status_counts.get("manual_implementation", 0),
            "failed": failed_count,
        },
        "executiveSummary": executive,
        "confidenceBreakdown": {
            "high": confidence["high"],
            "medium": confidence["medium"],
            "low": confidence["low"],
            "manual": confidence["manualRequired"],
            "manualRequired": confidence["manualRequired"],
        },
        "conversionSummaryByType": _per_type_summary(plan),
        "objectsByType": build_objects_by_type(plan),
        "perObjectType": {
            t: dict(c)
            for t, c in {
                str(o.get("type", "UNKNOWN")): Counter()
                for o in plan
            }.items()
        },
        "samples": samples,
        "generatedScripts": scripts,
        "validationWarnings": warnings,
    }

    per_type: dict[str, Counter[str]] = {}
    for obj in plan:
        obj_type = str(obj.get("type", "UNKNOWN"))
        bucket = per_type.setdefault(obj_type, Counter())
        bucket[obj.get("conversionStatus") or "pending"] += 1
    report["perObjectType"] = {k: dict(v) for k, v in per_type.items()}

    if job_config:
        report["databaseMetadata"] = build_database_metadata(
            job_id, job_config, db_name, workspace_override
        )
    if job_config and job_config.get("inputPaths"):
        report["inputSources"] = dict(job_config["inputPaths"])
    return report


def write_report(
    job_id: str,
    db_name: str,
    job_config: Optional[dict[str, Any]] = None,
    workspace_override: Optional[str] = None,
) -> Path:
    report = build_post_transformation_report(
        job_id, db_name, job_config=job_config, workspace_override=workspace_override
    )
    path = output_dir(job_id, workspace_override) / "post_transformation_report.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    return path


def create_scripts_zip(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> Path:
    out = output_dir(job_id, workspace_override)
    zip_path = out / f"{db_name}_postgresql_scripts.zip"
    extras = [
        f"{db_name}_00_README.txt",
        f"{db_name}_complete_schema.sql",
        "post_transformation_report.json",
        TRANSFORMATION_SUMMARY_JSON,
        MANUAL_REVIEW_CSV,
    ]

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in extras:
            path = out / name
            if path.exists():
                zf.write(path, arcname=name)
        for script in expected_script_names(db_name):
            path = out / script
            if path.exists():
                zf.write(path, arcname=path.name)
    return zip_path


def list_artifacts(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> list[dict[str, Any]]:
    out = output_dir(job_id, workspace_override)
    candidates = [
        f"{db_name}_00_README.txt",
        f"{db_name}_complete_schema.sql",
        "post_transformation_report.json",
        TRANSFORMATION_SUMMARY_JSON,
        MANUAL_REVIEW_CSV,
        f"{db_name}_postgresql_scripts.zip",
    ]
    candidates.extend(expected_script_names(db_name))

    artifacts: list[dict[str, Any]] = []
    for name in candidates:
        path = out / name
        if path.exists():
            artifacts.append(
                {
                    "name": name,
                    "path": str(path),
                    "sizeBytes": path.stat().st_size,
                }
            )
    return artifacts


def package_all_artifacts(
    job_id: str,
    db_name: str,
    job_config: dict[str, Any],
    workspace_override: Optional[str] = None,
) -> list[str]:
    """Normalize scripts and write all deterministic deliverables."""
    created: list[str] = []
    created.extend(normalize_output_scripts(job_id, db_name, workspace_override))
    write_report(job_id, db_name, job_config=job_config, workspace_override=workspace_override)
    created.append("post_transformation_report.json")
    write_transformation_summary(job_id, db_name, job_config, workspace_override)
    created.append(TRANSFORMATION_SUMMARY_JSON)
    write_manual_review_csv(job_id, db_name, workspace_override)
    created.append(MANUAL_REVIEW_CSV)
    complete = build_complete_schema(job_id, db_name, workspace_override)
    created.append(complete.name)
    zip_path = create_scripts_zip(job_id, db_name, workspace_override)
    created.append(zip_path.name)
    return created
