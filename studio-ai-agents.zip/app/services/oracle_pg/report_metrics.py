"""Shared report metric builders for Oracle PG transformation deliverables."""

from __future__ import annotations

import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from app.services.oracle_pg.progress import SCRIPT_ORDER
from app.services.oracle_pg.workspace import (
    input_path,
    output_dir,
    read_json_file_at,
    workspace_override_from_config,
)

# First eight rows match AC3 Section 3. Others is extra (DEFAULT/SEQUENCE/SCHEMA/TYPE).
REPORT_OBJECT_TYPE_ORDER: tuple[str, ...] = (
    "Tables",
    "Views",
    "Stored Procedures",
    "Functions",
    "Packages",
    "Triggers",
    "Indexes",
    "Constraints",
    "Others",
)

_INTERNAL_TO_REPORT_ROW: dict[str, str] = {
    "TABLE": "Tables",
    "DEFAULT": "Others",
    "SEQUENCE": "Others",
    "SCHEMA": "Others",
    "TYPE": "Others",
    "VIEW": "Views",
    "MATERIALIZED_VIEW": "Views",
    "PROCEDURE": "Stored Procedures",
    "FUNCTION": "Functions",
    "PACKAGE": "Packages",
    "TRIGGER": "Triggers",
    "INDEX": "Indexes",
    "PRIMARY_KEY": "Constraints",
    "UNIQUE": "Constraints",
    "FOREIGN_KEY": "Constraints",
    "CHECK": "Constraints",
}


def format_duration(seconds: Optional[int]) -> Optional[str]:
    """Format elapsed seconds as a human-readable duration string."""
    if seconds is None:
        return None
    if seconds <= 0:
        return "0s"
    if seconds >= 60:
        minutes = seconds // 60
        remainder = seconds % 60
        if remainder:
            return f"{minutes}m {remainder}s"
        return f"{minutes}m"
    return f"{seconds}s"


def build_timing_block(progress: dict[str, Any]) -> dict[str, Any]:
    """Build timing section from job progress.json fields."""
    started = progress.get("startedAt")
    completed = progress.get("completedAt")
    duration_seconds: Optional[int] = None

    if started and completed:
        try:
            start_dt = datetime.fromisoformat(str(started).replace("Z", "+00:00"))
            end_dt = datetime.fromisoformat(str(completed).replace("Z", "+00:00"))
            duration_seconds = int((end_dt - start_dt).total_seconds())
        except ValueError:
            duration_seconds = None

    return {
        "startedAt": started,
        "completedAt": completed,
        "durationSeconds": duration_seconds,
        "duration": format_duration(duration_seconds),
    }


def timing_fields_for_api(progress: dict[str, Any]) -> dict[str, Any]:
    """Flat timing fields for API responses and SSE events."""
    timing = build_timing_block(progress)
    fields: dict[str, Any] = {}
    if timing.get("startedAt") is not None:
        fields["startedAt"] = timing["startedAt"]
    if timing.get("completedAt") is not None:
        fields["completedAt"] = timing["completedAt"]
    if timing.get("durationSeconds") is not None:
        fields["durationSeconds"] = timing["durationSeconds"]
    if timing.get("duration") is not None:
        fields["duration"] = timing["duration"]
    return fields


def build_executive_summary(plan: list[dict[str, Any]]) -> dict[str, Any]:
    """Executive summary cards aligned with conversion-status columns."""
    auto = 0
    requires_review = 0
    failed = 0

    for obj in plan:
        if obj.get("status") == "failed":
            failed += 1
            continue
        status = str(obj.get("conversionStatus") or "").lower()
        if status == "auto_converted":
            auto += 1
        elif status == "require_review":
            requires_review += 1
        elif status == "manual_implementation":
            requires_review += 1

    return {
        "successfullyConverted": auto,
        "requiresReview": requires_review,
        "failed": failed,
        "totalObjects": len(plan),
    }


def build_confidence_breakdown(plan: list[dict[str, Any]]) -> dict[str, int]:
    """Confidence distribution for report section 4."""
    counts = Counter(str(o.get("confidenceScore", "")).upper() for o in plan)
    return {
        "high": counts.get("HIGH", 0),
        "medium": counts.get("MEDIUM", 0),
        "low": counts.get("LOW", 0),
        "manualRequired": counts.get("MANUAL", 0),
    }


def _object_status_bucket(obj: dict[str, Any]) -> str:
    if obj.get("status") == "failed":
        return "failed"
    return str(obj.get("conversionStatus") or "pending")


def _rollup_row_metrics(counts: Counter[str]) -> dict[str, Any]:
    auto = counts.get("auto_converted", 0)
    review = counts.get("require_review", 0)
    manual = counts.get("manual_implementation", 0)
    failed = counts.get("failed", 0)
    pending = counts.get("pending", 0)
    total = auto + review + manual + failed + pending
    deliverable = auto + review + manual
    deliverable_rate = round((deliverable / total) * 100, 1) if total else 0.0
    return {
        "total": total,
        "autoConverted": auto,
        "needReview": review,
        "manualEffortRequired": manual,
        "conversionRatePercent": deliverable_rate,
    }


def build_objects_by_type(plan: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Roll internal object types into AC report rows plus Others."""
    buckets: dict[str, Counter[str]] = {
        label: Counter() for label in REPORT_OBJECT_TYPE_ORDER
    }

    for obj in plan:
        internal_type = str(obj.get("type", "UNKNOWN")).upper()
        report_row = _INTERNAL_TO_REPORT_ROW.get(internal_type)
        if not report_row:
            continue
        buckets[report_row][_object_status_bucket(obj)] += 1

    rows: list[dict[str, Any]] = []
    for object_type in REPORT_OBJECT_TYPE_ORDER:
        metrics = _rollup_row_metrics(buckets[object_type])
        rows.append({"objectType": object_type, **metrics})
    return rows


def load_compass_metadata(
    job_id: str,
    job_config: dict[str, Any],
    db_name: str,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    """Best-effort database metadata from Compass input JSON files."""
    folder_key = str(job_config.get("dbName") or job_id)
    effective_override = workspace_override or workspace_override_from_config(job_config)
    database_id: Optional[str] = None
    name: Optional[str] = job_config.get("dbName", db_name)
    owner: Optional[str] = None
    description: Optional[str] = None

    try:
        incompat = read_json_file_at(
            folder_key,
            input_path(folder_key, "incompatibilityResults", job_config),
            effective_override,
        )
        if incompat:
            scan_request = incompat.get("scan_request") or {}
            metadata = incompat.get("metadata") or {}
            database_id = scan_request.get("database_id") or scan_request.get("databaseId")
            name = metadata.get("database_name") or metadata.get("databaseName") or name
            description = metadata.get("description")
    except KeyError:
        pass

    try:
        asis = read_json_file_at(
            folder_key,
            input_path(folder_key, "asisSchema", job_config),
            effective_override,
        )
        if asis:
            scan_metadata = asis.get("scan_metadata") or {}
            source_db = scan_metadata.get("source_database") or {}
            if not name or name == db_name:
                name = source_db.get("database_name") or source_db.get("databaseName") or name
            owner = scan_metadata.get("owner") or scan_metadata.get("database_owner")
            if owner is None:
                statistics = asis.get("statistics") or {}
                schema_count = statistics.get("schemas")
                if isinstance(schema_count, int) and schema_count == 1:
                    owner = "default"
    except KeyError:
        pass

    source_database = job_config.get("sourceDatabaseVersion", "Oracle")
    target_version = job_config.get("targetDatabaseVersion", "16")
    target_database = f"PostgreSQL {target_version}"

    return {
        "databaseId": database_id,
        "name": name,
        "owner": owner,
        "description": description,
        "sourceDatabase": source_database,
        "targetDatabase": target_database,
    }


def build_database_metadata(
    job_id: str,
    job_config: dict[str, Any],
    db_name: str,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    """Alias for load_compass_metadata used by report builders."""
    return load_compass_metadata(job_id, job_config, db_name, workspace_override)


def expected_script_names(db_name: str) -> list[str]:
    """PRD script file names including complete schema."""
    return [f"{db_name}_complete_schema.sql", *[f"{db_name}_{name}" for name in SCRIPT_ORDER]]


def build_generated_scripts(
    job_id: str,
    db_name: str,
    workspace_override: Optional[str] = None,
) -> list[dict[str, Any]]:
    """List generated SQL scripts with existence and size metadata."""
    out = output_dir(job_id, workspace_override)
    scripts: list[dict[str, Any]] = []
    for script in expected_script_names(db_name):
        path = out / script
        scripts.append(
            {
                "name": script,
                "path": str(path),
                "exists": path.exists(),
                "sizeBytes": path.stat().st_size if path.exists() else 0,
            }
        )
    return scripts


def load_transformation_summary_file(
    job_id: str,
    workspace_override: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """Load transformation_summary.json from job output if present."""
    path = output_dir(job_id, workspace_override) / "transformation_summary.json"
    return read_json_file_at(job_id, path, workspace_override)
