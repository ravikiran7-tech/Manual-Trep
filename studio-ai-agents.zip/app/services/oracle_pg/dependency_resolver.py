"""Pass 2: cross-object dependency resolution for Oracle PG jobs."""

from __future__ import annotations

import json
import re
from typing import Any

from app.services.oracle_pg.progress import load_conversion_plan, save_conversion_plan
from app.services.oracle_pg.workspace import state_dir


def _plan_index(plan: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    index: dict[str, dict[str, Any]] = {}
    for obj in plan:
        schema = obj.get("schema", "")
        name = obj.get("name", "")
        label = f"{schema}.{name}" if schema else name
        index[label.lower()] = obj
        index[name.lower()] = obj
    return index


def _append_change(obj: dict[str, Any], change_type: str, description: str) -> None:
    changes = obj.setdefault("changes", [])
    changes.append(
        {
            "changeType": change_type,
            "description": description,
            "requiresReview": True,
        }
    )


def _replace_package_calls(
    caller: dict[str, Any],
    package_name: str,
    function_names: list[str],
) -> int:
    snippet = caller.get("convertedSqlSnippet") or ""
    if not snippet:
        return 0
    replacements = 0
    pkg = package_name
    for func in function_names:
        pattern = re.compile(rf"\b{re.escape(pkg)}\s*\.\s*{re.escape(func)}\s*\(", re.IGNORECASE)
        new_snippet, count = pattern.subn(f"{func}(", snippet)
        if count:
            snippet = new_snippet
            replacements += count
    if replacements:
        caller["convertedSqlSnippet"] = snippet
        _append_change(
            caller,
            "PACKAGE_CALL_UPDATE",
            f"Updated package calls after {package_name} decomposition",
        )
        caller["requiresManualReview"] = True
        guidance = caller.get("reviewGuidance") or ""
        note = "Verify package function calls work correctly after decomposition"
        caller["reviewGuidance"] = f"{guidance}; {note}".strip("; ")
    return replacements


def resolve_dependencies(job_id: str, workspace_override: str | None = None) -> dict[str, Any]:
    """Apply Pass 2 dependency updates to the conversion plan."""
    plan = load_conversion_plan(job_id)
    index = _plan_index(plan)
    audit: dict[str, Any] = {"packageUpdates": [], "viewFlags": [], "signatureFlags": []}

    for obj in plan:
        obj_type = str(obj.get("type", "")).upper()
        if obj_type != "PACKAGE":
            continue
        package_name = obj.get("name", "")
        decomposed = obj.get("decomposedFunctions") or obj.get("callerUpdatesNeeded") or []
        if isinstance(decomposed, dict):
            decomposed = list(decomposed.keys())
        callers = (obj.get("aiAnalysis") or {}).get("called_by", [])
        if not callers and obj.get("callerUpdatesNeeded"):
            callers = obj["callerUpdatesNeeded"]

        for caller_ref in callers:
            caller_key = str(caller_ref).lower()
            caller = index.get(caller_key)
            if not caller:
                continue
            count = _replace_package_calls(caller, package_name, list(decomposed))
            if count:
                audit["packageUpdates"].append(
                    {"caller": caller_ref, "package": package_name, "replacements": count}
                )

    for obj in plan:
        if not obj.get("signatureChanged"):
            continue
        callee_label = f"{obj.get('schema', '')}.{obj.get('name', '')}".strip(".")
        audit["signatureFlags"].append(
            {
                "object": callee_label,
                "note": "Signature changed; callers require manual validation",
            }
        )
        obj["requiresManualReview"] = True

    for obj in plan:
        if str(obj.get("type", "")).upper() != "VIEW":
            continue
        base_tables = (obj.get("aiAnalysis") or {}).get("base_tables", [])
        for base in base_tables:
            base_key = str(base).lower()
            base_obj = index.get(base_key)
            if not base_obj:
                continue
            column_renames = base_obj.get("columnRenames") or []
            if column_renames:
                obj["requiresManualReview"] = True
                note = f"Updated due to base table {base} conversion"
                guidance = obj.get("reviewGuidance") or ""
                obj["reviewGuidance"] = f"{guidance}; {note}".strip("; ")
                audit["viewFlags"].append({"view": obj.get("name"), "base": base})

    save_conversion_plan(job_id, plan)
    audit_path = state_dir(job_id, workspace_override) / "dependency_resolution.json"
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("w", encoding="utf-8") as fh:
        json.dump(audit, fh, indent=2)
    return audit
