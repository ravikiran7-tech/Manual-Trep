"""Deterministic Compass JSON → conversion-plan adapter for Oracle PG jobs."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

from app.services.oracle_pg.ddl_extractor import index_ddl_blocks
from app.services.oracle_pg.plan_schema import seed_plan_metadata
from app.services.oracle_pg.progress import output_file_for_type
from app.services.oracle_pg.rule_engine import is_high_impact_rule

logger = logging.getLogger(__name__)

# AS-IS section name → default internal object type when item lacks object_type.
ASIS_SECTION_DEFAULT_TYPE: dict[str, str] = {
    "tables": "TABLE",
    "constraints": "CONSTRAINT",
    "indexes": "INDEX",
    "materialized_views": "MATERIALIZED_VIEW",
    "views": "VIEW",
    "procedures": "PROCEDURE",
    "functions": "FUNCTION",
    "triggers": "TRIGGER",
    "packages": "PACKAGE",
    "sequences": "SEQUENCE",
    "custom_types": "TYPE",
}

CONSTRAINT_TYPE_MAP = {
    "PRIMARY_KEY": "PRIMARY_KEY",
    "PRIMARY KEY": "PRIMARY_KEY",
    "PK": "PRIMARY_KEY",
    "UNIQUE": "UNIQUE",
    "UNIQUE KEY": "UNIQUE",
    "FOREIGN_KEY": "FOREIGN_KEY",
    "FOREIGN KEY": "FOREIGN_KEY",
    "FK": "FOREIGN_KEY",
    "REFERENTIAL": "FOREIGN_KEY",
    "CHECK": "CHECK",
    "DEFAULT": "DEFAULT",
}

SKIP_CONSTRAINT_TYPES: frozenset[str] = frozenset()

# Map vendor / assessment object_type strings to internal batch types.
OBJECT_TYPE_ALIASES: dict[str, str] = {
    "TABLE": "TABLE",
    "EXTERNAL_TABLE": "TABLE",
    "GLOBAL_TEMPORARY_TABLE": "TABLE",
    "STORED_PROCEDURE": "PROCEDURE",
    "PROCEDURE": "PROCEDURE",
    "FUNCTION": "FUNCTION",
    "TRIGGER": "TRIGGER",
    "VIEW": "VIEW",
    "MATERIALIZED_VIEW": "MATERIALIZED_VIEW",
    "INDEX": "INDEX",
    "CONSTRAINT": "CONSTRAINT",
    "PRIMARY_KEY": "PRIMARY_KEY",
    "UNIQUE": "UNIQUE",
    "FOREIGN_KEY": "FOREIGN_KEY",
    "CHECK": "CHECK",
    "DEFAULT": "DEFAULT",
    "SEQUENCE": "SEQUENCE",
    "PACKAGE": "PACKAGE",
    "TYPE": "TYPE",
    "CUSTOM_TYPE": "TYPE",
    "USER_DEFINED_TYPE": "TYPE",
    "SCHEMA": "SCHEMA",
    "table": "TABLE",
    "procedure": "PROCEDURE",
    "function": "FUNCTION",
    "trigger": "TRIGGER",
    "view": "VIEW",
    "materialized_view": "MATERIALIZED_VIEW",
    "index": "INDEX",
    "constraint": "CONSTRAINT",
    "sequence": "SEQUENCE",
    "package": "PACKAGE",
    "type": "TYPE",
    "schema": "SCHEMA",
}

CLASSIFICATION_RANK = {"DS": 0, "SC": 1, "NS": 2}
EFFORT_RANK = {"low": 0, "medium": 1, "high": 2}


def normalize_object_type(raw_type: Optional[str], section: Optional[str] = None) -> str:
    if raw_type:
        key = raw_type.strip()
        mapped = OBJECT_TYPE_ALIASES.get(key) or OBJECT_TYPE_ALIASES.get(key.upper())
        if mapped:
            return mapped
        return key.upper()
    if section and section in ASIS_SECTION_DEFAULT_TYPE:
        return ASIS_SECTION_DEFAULT_TYPE[section]
    return "TABLE"


def _constraint_subtype(item: dict[str, Any]) -> Optional[str]:
    raw = str(item.get("constraint_type", "")).upper().replace(" ", "_")
    mapped = CONSTRAINT_TYPE_MAP.get(raw) or CONSTRAINT_TYPE_MAP.get(raw.replace("_", " "))
    if mapped and mapped not in SKIP_CONSTRAINT_TYPES:
        return mapped
    if raw in SKIP_CONSTRAINT_TYPES:
        return None
    return "CHECK"


def _extract_structural_metadata(item: dict[str, Any], section: str) -> dict[str, Any]:
    meta: dict[str, Any] = {}
    if section == "tables":
        if item.get("columns"):
            meta["columns"] = item["columns"]
        if item.get("structure"):
            meta["structure"] = item["structure"]
        if item.get("features"):
            meta["features"] = item["features"]
    elif section in ("procedures", "functions"):
        if item.get("parameters"):
            meta["parameters"] = item["parameters"]
        if item.get("return_type") is not None:
            meta["returnType"] = item["return_type"]
    elif section == "packages":
        for key in ("package_variables", "procedures", "functions", "has_body"):
            if key in item:
                meta[key] = item[key]
    elif section == "triggers":
        for key in ("trigger_timing", "trigger_event", "trigger_scope", "owner_table"):
            if key in item:
                meta[key] = item[key]
    elif section == "constraints":
        meta["constraintType"] = item.get("constraint_type")
        meta["constraintDetails"] = item.get("constraint_details", {})
        meta["ownerTable"] = item.get("owner_table") or item.get("ownerTable")
    elif section == "views":
        if item.get("column_count") is not None:
            meta["columnCount"] = item["column_count"]
    return meta


def _object_key(schema: str, name: str, obj_type: str) -> tuple[str, str, str]:
    return (schema.lower(), name.lower(), obj_type.upper())


def load_asis_objects(path: Path) -> list[dict[str, Any]]:
    """Parse oracle-dbschema-asis.json into normalized object records."""
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)

    database_objects = data.get("database_objects", {})
    if not isinstance(database_objects, dict):
        return []

    objects: list[dict[str, Any]] = []
    for section, items in database_objects.items():
        if not isinstance(items, list):
            continue
        default_type = ASIS_SECTION_DEFAULT_TYPE.get(section, "TABLE")
        for item in items:
            if not isinstance(item, dict):
                continue
            schema = str(item.get("schema", item.get("owner_schema", ""))).strip()
            name = str(item.get("name", "")).strip()
            if not name:
                continue

            if section == "constraints":
                subtype = _constraint_subtype(item)
                if not subtype:
                    continue
                obj_type = subtype
                owning = item.get("owner_table") or item.get("ownerTable")
            else:
                obj_type = normalize_object_type(item.get("object_type"), section)
                if not obj_type:
                    obj_type = default_type
                owning = None

            object_id = item.get("object_id") or (f"{schema}.{name}" if schema else name)
            record: dict[str, Any] = {
                "objectId": object_id,
                "type": obj_type,
                "schema": schema,
                "name": name,
                "sourceSection": section,
                "structuralMetadata": _extract_structural_metadata(item, section),
            }
            if owning:
                record["owningTable"] = str(owning)
            objects.append(record)
    return objects


def load_schema_analysis_index(path: Path) -> dict[tuple[str, str, str], dict[str, Any]]:
    """Index AI schema analysis objects by (schema, name, type)."""
    if not path.is_file():
        return {}
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)

    objects = data.get("objects", data.get("analyzed_objects", []))
    if not isinstance(objects, list):
        return {}

    index: dict[tuple[str, str, str], dict[str, Any]] = {}
    for item in objects:
        if not isinstance(item, dict):
            continue
        schema = str(item.get("schema", "")).strip()
        name = str(item.get("object_name", item.get("name", ""))).strip()
        obj_type = normalize_object_type(item.get("object_type"))
        if not name:
            continue
        subset = {
            k: item[k]
            for k in (
                "business_purpose",
                "depends_on_code",
                "called_by",
                "base_tables",
                "execution_order",
                "circular_dependencies",
                "conversion_strategy",
                "logic_flow",
                "side_effects",
            )
            if k in item
        }
        if "execution_order" not in subset and isinstance(data.get("execution_order"), dict):
            subset["execution_order"] = data["execution_order"]
        if "circular_dependencies" not in subset and isinstance(
            data.get("circular_dependencies"), list
        ):
            subset["circular_dependencies"] = data["circular_dependencies"]
        index[_object_key(schema, name, obj_type)] = subset
    return index


def _pick_default_remediation(remediations: list[dict[str, Any]]) -> dict[str, Any]:
    if not remediations:
        raise ValueError("Rule has no remediations")
    for item in remediations:
        if item.get("default") or item.get("isDefault"):
            return item
    return remediations[0]


def load_remediation_catalog(path: Path) -> dict[str, dict[str, Any]]:
    """Parse rules remediation JSON into ruleId → rule metadata with default remediation."""
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)

    rules = data.get("rules", [])
    if not isinstance(rules, list):
        raise ValueError("rulesRemediation file must contain a rules array")

    catalog: dict[str, dict[str, Any]] = {}
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        rule_id = rule.get("ruleId")
        if not rule_id:
            continue
        default = _pick_default_remediation(rule.get("remediations", []))
        catalog[rule_id] = {
            "ruleId": rule_id,
            "ruleName": rule.get("ruleName", ""),
            "category": rule.get("category", ""),
            "severity": rule.get("severity", rule.get("impact", "")),
            "impact": rule.get("impact", ""),
            "description": rule.get("description", ""),
            "remediation": {
                "remediationId": default.get("remediationId", ""),
                "description": default.get("description", ""),
                "detailedDescription": default.get("detailedDescription", ""),
                "effort": default.get("effort", ""),
            },
        }
    return catalog


def _normalize_incompat_row(row: dict[str, Any]) -> Optional[dict[str, Any]]:
    schema = str(row.get("schema", "")).strip()
    name = str(row.get("object_name", "")).strip()
    obj_type = normalize_object_type(row.get("object_type"))
    if not name:
        return None

    entry: dict[str, Any] = {
        "incompatibilityId": row.get("incompatibility_id", ""),
        "ruleId": row.get("rule_id", ""),
        "ruleName": row.get("rule_name", ""),
        "affectedElement": row.get("affected_element", {}),
        "compatibility": str(row.get("compatibility", "SC")).upper(),
        "effort": str(row.get("effort", "Medium")),
        "note": row.get("note", ""),
        "subPropertyCategory": row.get("sub_property_category", ""),
    }
    if row.get("owning_table"):
        entry["owningTable"] = row["owning_table"]
    return {
        "key": _object_key(schema, name, obj_type),
        "entry": entry,
    }


def filter_incompatibilities_by_scope(
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]],
    *,
    rule_scope: str = "all",
    selected_rules: Optional[list[str]] = None,
    remediation_catalog: Optional[dict[str, dict[str, Any]]] = None,
) -> dict[tuple[str, str, str], list[dict[str, Any]]]:
    """Filter incompatibility rows per ruleScope / selectedRules."""
    if rule_scope == "all" and not selected_rules:
        return grouped

    allowed_rules: Optional[set[str]] = None
    if rule_scope == "custom" and selected_rules:
        allowed_rules = set(selected_rules)
    elif rule_scope == "high_impact" and remediation_catalog:
        allowed_rules = {
            rid for rid, meta in remediation_catalog.items() if is_high_impact_rule(meta)
        }

    if allowed_rules is None:
        return grouped

    filtered: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for key, rows in grouped.items():
        kept = [row for row in rows if row.get("ruleId") in allowed_rules]
        if kept:
            filtered[key] = kept
    return filtered


def aggregate_incompatibilities_detailed(
    path: Path,
) -> dict[tuple[str, str, str], list[dict[str, Any]]]:
    """Group full incompatibility rows by object."""
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)

    rows = data.get("incompatibilities", [])
    if not isinstance(rows, list):
        return {}

    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        normalized = _normalize_incompat_row(row)
        if not normalized:
            continue
        grouped.setdefault(normalized["key"], []).append(normalized["entry"])
    return grouped


def _default_constraint_columns(obj: dict[str, Any]) -> list[str]:
    """Column names targeted by a DEFAULT constraint object."""
    meta = obj.get("structuralMetadata") or {}
    details = meta.get("constraintDetails") or meta.get("constraint_details") or {}
    columns = details.get("columns") or []
    return [str(col) for col in columns if col]


def _incompatibilities_for_default_object(
    obj: dict[str, Any],
    incompat_details: dict[tuple[str, str, str], list[dict[str, Any]]],
    remediation_catalog: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Map table-level default_expression incompatibilities onto DEFAULT constraint objects."""
    schema = str(obj.get("schema", "")).strip()
    owning_table = str(obj.get("owningTable") or "").strip()
    if not owning_table:
        meta = obj.get("structuralMetadata") or {}
        owning_table = str(meta.get("ownerTable") or "").strip()
    if not schema or not owning_table:
        return []

    columns = {col.lower() for col in _default_constraint_columns(obj)}
    if not columns:
        return []

    table_key = _object_key(schema, owning_table, "TABLE")
    direct_key = _object_key(schema, obj.get("name", ""), "DEFAULT")
    candidate_rows: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for key in (direct_key, table_key):
        for row in incompat_details.get(key, []):
            row_id = str(row.get("incompatibilityId") or row.get("ruleId") or "")
            if row_id and row_id in seen_ids:
                continue
            affected = row.get("affectedElement") or {}
            affected_type = str(affected.get("type", "")).lower()
            affected_name = str(affected.get("name", "")).lower()
            if key == table_key:
                if affected_type != "default_expression":
                    continue
                if affected_name and affected_name not in columns:
                    continue
            if row_id:
                seen_ids.add(row_id)
            candidate_rows.append(row)

    return attach_remediations(candidate_rows, remediation_catalog)


def attach_remediations(
    rows: list[dict[str, Any]],
    catalog: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Resolve remediation for each incompatibility row; fail if rule_id is missing."""
    enriched: list[dict[str, Any]] = []
    for row in rows:
        rule_id = row.get("ruleId")
        if not rule_id:
            continue
        rule_meta = catalog.get(rule_id)
        if not rule_meta:
            raise ValueError(f"No remediation found for rule_id: {rule_id}")
        enriched.append({**row, "remediation": dict(rule_meta["remediation"])})
    return enriched


def _summarize_incompat_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "classification": "DS",
        "complexity": "low",
        "ruleIds": [],
        "notes": [],
    }
    if not rows:
        return summary
    for row in rows:
        compatibility = str(row.get("compatibility", "SC")).upper()
        if CLASSIFICATION_RANK.get(compatibility, 1) > CLASSIFICATION_RANK.get(
            summary["classification"], 0
        ):
            summary["classification"] = compatibility

        effort = str(row.get("effort", "Medium")).lower()
        if EFFORT_RANK.get(effort, 1) > EFFORT_RANK.get(summary["complexity"], 0):
            summary["complexity"] = effort

        rule_id = row.get("ruleId")
        if rule_id and rule_id not in summary["ruleIds"]:
            summary["ruleIds"].append(rule_id)

        note = row.get("note")
        if note and note not in summary["notes"]:
            summary["notes"].append(note)

    return summary


def aggregate_incompatibilities(path: Path) -> dict[tuple[str, str, str], dict[str, Any]]:
    """Group incompatibility rows by object and compute worst-case classification."""
    detailed = aggregate_incompatibilities_detailed(path)
    return {key: _summarize_incompat_rows(rows) for key, rows in detailed.items()}


def derive_schema_objects(objects: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Add SCHEMA entries for each unique schema name found in AS-IS objects."""
    schemas = sorted({obj["schema"] for obj in objects if obj.get("schema")})
    schema_objects = []
    for schema in schemas:
        schema_objects.append(
            {
                "objectId": f"schema.{schema}",
                "type": "SCHEMA",
                "schema": schema,
                "name": schema,
                "sourceSection": "derived_schemas",
                "structuralMetadata": {},
            }
        )
    return schema_objects


def build_conversion_plan(
    asis_objects: list[dict[str, Any]],
    incompat_map: dict[tuple[str, str, str], dict[str, Any]],
    *,
    incompat_details: Optional[dict[tuple[str, str, str], list[dict[str, Any]]]] = None,
    remediation_catalog: Optional[dict[str, dict[str, Any]]] = None,
    ai_analysis_index: Optional[dict[tuple[str, str, str], dict[str, Any]]] = None,
    ddl_index: Optional[dict[tuple[str, str], Any]] = None,
    include_schemas: bool = True,
) -> list[dict[str, Any]]:
    """Merge AS-IS catalog with incompatibility assessments into a conversion plan."""
    all_objects = list(asis_objects)
    if include_schemas:
        existing_schemas = {obj["name"].lower() for obj in all_objects if obj.get("type") == "SCHEMA"}
        for schema_obj in derive_schema_objects(asis_objects):
            if schema_obj["name"].lower() not in existing_schemas:
                all_objects.insert(0, schema_obj)

    plan: list[dict[str, Any]] = []
    for idx, obj in enumerate(all_objects, start=1):
        schema = obj.get("schema", "")
        name = obj.get("name", "")
        obj_type = obj.get("type", "TABLE")
        key = _object_key(schema, name, obj_type)
        incompat = incompat_map.get(key, {})

        classification = incompat.get("classification", "SC")
        complexity = incompat.get("complexity", "medium")
        rule_ids = list(incompat.get("ruleIds", []))

        incompatibilities: list[dict[str, Any]] = []
        if incompat_details and remediation_catalog:
            if obj_type == "DEFAULT":
                incompatibilities = _incompatibilities_for_default_object(
                    obj, incompat_details, remediation_catalog
                )
            else:
                raw_rows = incompat_details.get(key, [])
                incompatibilities = attach_remediations(raw_rows, remediation_catalog)

        if obj_type == "DEFAULT" and incompatibilities:
            default_summary = _summarize_incompat_rows(incompatibilities)
            classification = default_summary.get("classification", classification)
            complexity = default_summary.get("complexity", complexity)
            rule_ids = list(default_summary.get("ruleIds", rule_ids))
            if default_summary.get("notes"):
                incompat = {**incompat, "notes": default_summary["notes"]}

        source_location = None
        source_snippet = None
        if ddl_index is not None:
            block = ddl_index.get((schema.lower(), name.lower()))
            if block:
                source_location = block.source_location
                source_snippet = block.text[:2000]

        ai_analysis = None
        if ai_analysis_index:
            ai_analysis = ai_analysis_index.get(key) or ai_analysis_index.get(
                _object_key(schema, name, normalize_object_type(obj_type))
            )

        base = {
            "objectId": obj.get("objectId") or f"OBJ_{idx:04d}",
            "type": obj_type,
            "schema": schema,
            "name": name,
            "ruleIds": rule_ids,
            "assessmentNotes": incompat.get("notes", [])[:5],
            "incompatibilities": incompatibilities,
        }
        if obj.get("owningTable"):
            base["owningTable"] = obj["owningTable"]

        entry = seed_plan_metadata(
            base,
            classification=classification,
            complexity=complexity,
            structural_metadata=obj.get("structuralMetadata"),
            ai_analysis=ai_analysis,
            source_location=source_location,
            source_code_snippet=source_snippet,
        )
        entry["outputFile"] = output_file_for_type(obj_type)
        plan.append(entry)
    return plan


def validate_plan_completeness(
    asis_objects: list[dict[str, Any]],
    plan: list[dict[str, Any]],
    ddl_index: dict[tuple[str, str], Any],
) -> tuple[list[dict[str, Any]], list[str]]:
    """Return skipped objects and warnings when DDL source is missing."""
    skipped: list[dict[str, Any]] = []
    warnings: list[str] = []
    plan_keys = {
        (obj.get("schema", "").lower(), obj.get("name", "").lower())
        for obj in plan
        if obj.get("type") not in ("SCHEMA",)
    }

    for obj in asis_objects:
        if obj.get("type") == "SCHEMA":
            continue
        schema = obj.get("schema", "").lower()
        name = obj.get("name", "").lower()
        if (schema, name) not in plan_keys:
            continue
        if (schema, name) not in ddl_index:
            skipped.append(
                {
                    "schema": obj.get("schema", ""),
                    "name": obj.get("name", ""),
                    "type": obj.get("type"),
                    "reason": "Source DDL not found in export file",
                }
            )
            warnings.append(f"Missing DDL for {obj.get('schema')}.{obj.get('name')}")

    return skipped, warnings


def write_skipped_objects(
    job_id: str,
    skipped: list[dict[str, Any]],
    workspace_override: Optional[str] = None,
) -> None:
    from app.services.oracle_pg.workspace import state_dir

    path = state_dir(job_id, workspace_override) / "skipped_objects.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump({"skipped": skipped}, fh, indent=2)


def write_normalized_assessment(
    job_id: str,
    plan: list[dict[str, Any]],
    workspace_override: Optional[str] = None,
) -> Path:
    """Write a simplified assessment snapshot derived from the conversion plan."""
    from app.services.oracle_pg.workspace import input_dir

    snapshot = {
        "objects": [
            {
                "objectId": obj["objectId"],
                "type": obj["type"],
                "schema": obj["schema"],
                "name": obj["name"],
                "classification": obj["classification"],
                "complexity": obj["complexity"],
                "confidenceScore": obj.get("confidenceScore"),
                "remediationIds": [
                    inc.get("remediation", {}).get("remediationId")
                    for inc in obj.get("incompatibilities", [])
                    if inc.get("remediation", {}).get("remediationId")
                ],
            }
            for obj in plan
        ]
    }
    path = input_dir(job_id, workspace_override) / "assessment.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(snapshot, fh, indent=2)
    return path


def write_remediation_index(
    job_id: str,
    catalog_subset: dict[str, dict[str, Any]],
    workspace_override: Optional[str] = None,
) -> Path:
    """Write rules referenced by this job for agent lookup."""
    from app.services.oracle_pg.workspace import state_dir

    path = state_dir(job_id, workspace_override) / "remediation-index.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"rules": list(catalog_subset.values())}
    with path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    return path


def _catalog_subset_for_plan(
    plan: list[dict[str, Any]],
    catalog: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    rule_ids: set[str] = set()
    for obj in plan:
        for inc in obj.get("incompatibilities", []):
            rule_id = inc.get("ruleId")
            if rule_id:
                rule_ids.add(rule_id)
    return {rule_id: catalog[rule_id] for rule_id in sorted(rule_ids) if rule_id in catalog}


def build_plan_from_compass_files(
    asis_path: Path,
    incompat_path: Path,
    remediation_path: Path,
    *,
    ddl_path: Optional[Path] = None,
    schema_analysis_path: Optional[Path] = None,
    rule_scope: str = "all",
    selected_rules: Optional[list[str]] = None,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Load Compass JSON files and produce a remediation-enriched conversion plan."""
    asis_objects = load_asis_objects(asis_path)
    remediation_catalog = load_remediation_catalog(remediation_path)
    incompat_details = aggregate_incompatibilities_detailed(incompat_path)
    incompat_details = filter_incompatibilities_by_scope(
        incompat_details,
        rule_scope=rule_scope,
        selected_rules=selected_rules,
        remediation_catalog=remediation_catalog,
    )
    incompat_map = {key: _summarize_incompat_rows(rows) for key, rows in incompat_details.items()}

    ai_index = (
        load_schema_analysis_index(schema_analysis_path)
        if schema_analysis_path
        else {}
    )
    if schema_analysis_path and not schema_analysis_path.is_file():
        logger.warning("schemaAnalysis path configured but file not found: %s", schema_analysis_path)

    ddl_index = index_ddl_blocks(ddl_path) if ddl_path else {}

    plan = build_conversion_plan(
        asis_objects,
        incompat_map,
        incompat_details=incompat_details,
        remediation_catalog=remediation_catalog,
        ai_analysis_index=ai_index or None,
        ddl_index=ddl_index or None,
    )
    skipped, warnings = validate_plan_completeness(asis_objects, plan, ddl_index)
    catalog_subset = _catalog_subset_for_plan(plan, remediation_catalog)
    return plan, catalog_subset, skipped, warnings
