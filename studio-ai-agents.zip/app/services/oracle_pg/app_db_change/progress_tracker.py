"""In-memory + on-disk progress, log and SSE state for App+DB (Job 3) jobs.

The milestone list is the Studio left-panel structure for Job 3:

    Job 3: App-DB Dependency Code Changes
      → Configurations        (milestone 1)
      → Transformation        (milestones 2-3)
      → Artifacts             (milestone 4 — post-transformation report)
      → Transformation Complete          (milestone 5)

Every milestone owns a slice of the 0-100 progress bar so the SSE
``progress_updated`` events carry a real ``progressPercent``, matching the DB
job's contract that the Java BFF and the MFE already parse.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.config import get_settings
from app.services.oracle_pg.app_db_change import events as event_bus
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.live_logs import ALLOWED_ICONS, icon_color

logger = logging.getLogger(__name__)

# (id, title, description, group, percent_at_start, percent_at_completion)
MILESTONES = (
    (1, "Initializing Transformation", "Loading dependency findings and remediation rules", "Configurations", 0, 15),
    (2, "Applying Violation Remediations", "Remediating Oracle-Java dependency violations in source files", "Transformation", 15, 50),
    (3, "Applying PostgreSQL Compatibility Changes", "Updating config, connection drivers, and ORM settings", "Transformation", 50, 75),
    (4, "Generating Artifacts", "Creating post-transformation report", "Artifacts", 75, 97),
    (5, "Transformation Complete", "All changes applied successfully", "Transformation", 97, 100),
)

MILESTONE_ARTIFACTS = 4
MILESTONE_FINAL = 5

_MILESTONE_TITLES = {mid: title for mid, title, _, _, _, _ in MILESTONES}
_MILESTONE_GROUPS = {mid: group for mid, _, _, group, _, _ in MILESTONES}
_MILESTONE_SPAN = {mid: (start, end) for mid, _, _, _, start, end in MILESTONES}

STATUS_QUEUED = "QUEUED"
STATUS_IN_PROGRESS = "IN_PROGRESS"
STATUS_COMPLETED = "COMPLETED"
STATUS_FAILED = "FAILED"
STATUS_PENDING = "PENDING"
STATUS_SKIPPED = "SKIPPED"

# Lowercase job status the Java poller (AiAgentJobStatusResponse) matches on.
_API_STATUS = {
    STATUS_QUEUED: "queued",
    STATUS_IN_PROGRESS: "in_progress",
    STATUS_COMPLETED: "completed",
    STATUS_FAILED: "failed",
}

# FR3 Section 1 — Overall Progress banner. Exactly these three strings.
BANNER_IN_PROGRESS = "App-DB Dependency Transformation in progress."
BANNER_COMPLETED = "App-DB Dependency Code Changes Completed Successfully."
BANNER_FAILED = "App-DB Dependency Transformation encountered an error."


def banner_for(overall_status: str) -> str:
    if overall_status == STATUS_COMPLETED:
        return BANNER_COMPLETED
    if overall_status == STATUS_FAILED:
        return BANNER_FAILED
    return BANNER_IN_PROGRESS


_DEFAULT_METRICS = {
    "filesScanned": 0,
    "filesModified": 0,
    "violationsFound": 0,
    "violationsResolved": 0,
    "violationsFailed": 0,
    "pgCompatibilityChanges": 0,
    "rulesProcessed": 0,
    "manualReviewItems": 0,
}


def _phase_for(state: Dict[str, Any]) -> str:
    """UI-facing phase label — mirrors the DB job's SSE "phase" field."""
    overall = state.get("overall_status")
    if overall == STATUS_COMPLETED:
        return "Completed"
    if overall == STATUS_FAILED:
        return "Failed"
    return _MILESTONE_TITLES.get(state.get("current_milestone"), _MILESTONE_TITLES[1])


def _icon_for(level: str, state: Dict[str, Any]) -> str:
    """Icon derived from job status, mirroring live_logs.format_progress_event."""
    overall = state.get("overall_status")
    if overall == STATUS_COMPLETED:
        return "check"
    if overall == STATUS_FAILED or level in ("WARN", "ERROR"):
        return "warning"
    return "settings"


def _now() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _public_job_id(state: Dict[str, Any]) -> str:
    """Public tracking key is appId (one app, one database)."""
    return str(state.get("app_id") or state.get("transformation_id") or "")


def job3_limits():
    """App+DB Job 3 limits, tolerating a settings object without the section.

    Callers that stub ``get_settings`` (tests, embedded use) only need to
    provide ``claude_workspace``; the artifact limits then fall back to their
    declared defaults instead of raising.
    """
    from app.core.config import AppDbJob3Config

    return getattr(get_settings(), "app_db_job3", None) or AppDbJob3Config()


def jobs_dir() -> Path:
    """``{claude_workspace}/db-code-modernize`` — parent of every job folder."""
    return ws.jobs_base()


_DB_ID_BY_JOB: Dict[str, str] = {}


def register_job_db_id(transformation_id: str, db_id: str) -> str:
    """Bind a transformation to the folder that holds its files.

    The folder is named by database id, matching the Java package builder. A
    caller without a dbId (direct/embedded use) falls back to the
    transformation id so the job still has somewhere to write.
    """
    resolved = ws.folder_key(db_id, transformation_id)
    _DB_ID_BY_JOB[transformation_id] = resolved
    return resolved


def db_id_for_job(transformation_id: str) -> Optional[str]:
    """dbId whose ``reports`` folder holds this transformation's files."""
    cached = _DB_ID_BY_JOB.get(transformation_id)
    if cached:
        return cached
    found = ws.find_db_id(transformation_id=transformation_id)
    if found:
        _DB_ID_BY_JOB[transformation_id] = found
    return found


def job_dir(transformation_id: str) -> Path:
    """``.../db-code-modernize/{dbId}/reports`` — where Job 3 writes."""
    db_id = db_id_for_job(transformation_id)
    if not db_id:
        return ws.jobs_base() / "_unresolved" / transformation_id
    return ws.reports_dir(db_id)


def is_job_terminal_on_disk(transformation_id: str) -> bool:
    """Terminal job status from ``state.json`` (schema-style disk source of truth)."""
    db_id = db_id_for_job(transformation_id)
    if not db_id:
        return False
    state = ws.read_state(db_id)
    if not state:
        return False
    overall = state.get("overall_status")
    return overall in (STATUS_COMPLETED, STATUS_FAILED)


def _state_path(transformation_id: str) -> Path:
    return job_dir(transformation_id) / ws.STATE_FILENAME


def duration_text(seconds: Optional[int]) -> Optional[str]:
    """Human duration used across the report and SSE (e.g. "98m 28s")."""
    if seconds is None:
        return None
    seconds = max(0, int(seconds))
    minutes, secs = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    parts: List[str] = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def _elapsed_seconds(started: Optional[str], completed: Optional[str]) -> Optional[int]:
    if not started or not completed:
        return None
    try:
        start = datetime.fromisoformat(str(started).replace("Z", "+00:00"))
        end = datetime.fromisoformat(str(completed).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return max(0, int((end - start).total_seconds()))


class ProgressTracker:
    """Thread-safe tracker. State is also written to workspace for polling after restart."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._jobs: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------ setup

    def initialize_tracking(
        self,
        transformation_id: str,
        *,
        app_id: str = "",
        db_id: str = "",
        nfs_mount_path: str = "",
        pathway: str = "M-Upgrade",
        app_name: Optional[str] = None,
        db_name: Optional[str] = None,
        target_branch: Optional[str] = None,
        repository_url: Optional[str] = None,
        overall_status: str = STATUS_IN_PROGRESS,
    ) -> Dict[str, Any]:
        ws.ensure_reports_dir(register_job_db_id(transformation_id, db_id))
        with self._lock:
            state = {
                "transformation_id": transformation_id,
                "app_id": app_id,
                "db_id": db_id,
                "nfs_mount_path": nfs_mount_path,
                "pathway": pathway,
                "app_name": app_name,
                "db_name": db_name,
                "target_branch": target_branch,
                "repository_url": repository_url,
                "overall_status": overall_status,
                "current_milestone": 1,
                "progress_percent": 0,
                "message": (
                    "Transformation queued"
                    if overall_status == STATUS_QUEUED
                    else "Transformation started"
                ),
                "milestones": [
                    {
                        "id": mid,
                        "title": title,
                        "description": desc,
                        "group": group,
                        "status": STATUS_PENDING,
                        "timestamp": None,
                    }
                    for mid, title, desc, group, _, _ in MILESTONES
                ],
                "metrics": dict(_DEFAULT_METRICS),
                "report": {
                    "status": "PENDING",
                    "available": False,
                    "path": None,
                    "generatedAt": None,
                    "fileSizeBytes": None,
                    "steps": [],
                },
                "artifacts": [],
                "logs": [],
                "created_at": _iso(),
                "updated_at": _iso(),
                "completed_at": None,
                "error": None,
            }
            self._jobs[transformation_id] = state
            self._persist(state)
            self._emit_progress(state, message="Transformation started")
            return state

    # -------------------------------------------------------------- mutations

    def update_milestone(
        self,
        transformation_id: str,
        milestone_id: int,
        status: str,
        *,
        message: Optional[str] = None,
    ) -> None:
        stamp = _now()
        with self._lock:
            state = self._require(transformation_id)
            for item in state["milestones"]:
                if item["id"] == milestone_id:
                    item["status"] = status
                    item["timestamp"] = stamp
            start, end = _MILESTONE_SPAN.get(milestone_id, (0, 0))
            if status == STATUS_IN_PROGRESS:
                state["current_milestone"] = milestone_id
                state["overall_status"] = STATUS_IN_PROGRESS
                state["progress_percent"] = max(int(state.get("progress_percent") or 0), start)
            elif status in (STATUS_COMPLETED, STATUS_SKIPPED):
                state["current_milestone"] = milestone_id
                state["progress_percent"] = max(int(state.get("progress_percent") or 0), end)
            elif status == STATUS_FAILED:
                state["current_milestone"] = milestone_id
                state["overall_status"] = STATUS_FAILED
            if milestone_id == MILESTONE_FINAL and status == STATUS_COMPLETED:
                state["overall_status"] = STATUS_COMPLETED
                state["current_milestone"] = MILESTONE_FINAL
                state["progress_percent"] = 100
                state["completed_at"] = _iso()
            if message:
                state["message"] = message
            else:
                state["message"] = _MILESTONE_TITLES.get(milestone_id, state.get("message") or "")
            state["updated_at"] = _iso()
            self._persist(state)
            self._emit_progress(state)

    def update_metrics(self, transformation_id: str, **metrics: Any) -> None:
        """Record the counters the SSE stream and the report both report on."""
        with self._lock:
            state = self._require(transformation_id)
            current = dict(state.get("metrics") or _DEFAULT_METRICS)
            for key, value in metrics.items():
                if value is None:
                    continue
                current[key] = value
            state["metrics"] = current
            state["updated_at"] = _iso()
            self._persist(state)

    def add_log_entry(
        self,
        transformation_id: str,
        level: str,
        message: str,
        timestamp: Optional[str] = None,
        *,
        icon: Optional[str] = None,
    ) -> Dict[str, Any]:
        level = level.upper() if level.upper() in {"INFO", "WARN", "ERROR"} else "INFO"
        with self._lock:
            state = self._require(transformation_id)
            if icon and icon in ALLOWED_ICONS:
                resolved_icon = icon
            else:
                resolved_icon = _icon_for(level, state)
            entry = {
                "timestamp": timestamp or _now(),
                "level": level,
                "phase": _phase_for(state),
                "icon": resolved_icon,
                "message": message,
                "color": icon_color(resolved_icon),
                "seq": len(state["logs"]) + 1,
                "jobId": _public_job_id(state),
            }
            state["logs"].append(entry)
            state["updated_at"] = _iso()
            self._persist(state)
            self._append_log_line(transformation_id, entry)
            return entry

    def mark_failed(self, transformation_id: str, error: str) -> None:
        with self._lock:
            state = self._require(transformation_id)
            state["overall_status"] = STATUS_FAILED
            state["error"] = error
            state["message"] = error
            state["completed_at"] = _iso()
            current = state.get("current_milestone") or 1
            for item in state["milestones"]:
                if item["id"] == current and item["status"] == STATUS_IN_PROGRESS:
                    item["status"] = STATUS_FAILED
                    item["timestamp"] = _now()
            state["updated_at"] = _iso()
            self._persist(state)
        self.add_log_entry(transformation_id, "ERROR", error)
        with self._lock:
            self._emit_progress(self._require(transformation_id))

    def add_report_step(
        self,
        transformation_id: str,
        step: str,
        status: str,
        *,
        duration_ms=None,
        message=None,
    ) -> None:
        """Per-step trace of the report artifact (VALIDATE / GENERATE / WRITE / PACKAGE).

        The in-workspace equivalent of a report_generation_logs table: it backs
        ``GET /{id}/report/status``, so a failed artifact step names the step
        that failed instead of just reporting "failed".
        """
        with self._lock:
            state = self._require(transformation_id)
            report = dict(state.get("report") or {})
            steps = list(report.get("steps") or [])
            steps.append(
                {
                    "step": step,
                    "status": status,
                    "durationMs": duration_ms,
                    "message": message,
                    "at": _iso(),
                }
            )
            report["steps"] = steps
            state["report"] = report
            state["updated_at"] = _iso()
            self._persist(state)

    def set_report(
        self,
        transformation_id: str,
        *,
        path: Optional[str],
        available: bool = True,
        file_size_bytes=None,
        status=None,
        error=None,
    ) -> None:
        with self._lock:
            state = self._require(transformation_id)
            report = dict(state.get("report") or {})
            report.update(
                {
                    "status": status or ("COMPLETED" if available else "FAILED"),
                    "available": available,
                    "path": path,
                    "generatedAt": _iso(),
                    "fileSizeBytes": file_size_bytes,
                    "error": error,
                }
            )
            state["report"] = report
            state["updated_at"] = _iso()
            self._persist(state)
            event_bus.publish(
                job_dir(transformation_id),
                transformation_id,
                {
                    "type": event_bus.EVENT_ARTIFACT_READY,
                    "jobId": _public_job_id(state),
                    "transformationId": transformation_id,
                    "artifact": "post_transformation_report.json",
                    "path": path,
                    "available": available,
                    "timestamp": _iso(),
                },
            )

    # ----------------------------------------------------------------- reads

    def get_job_context(self, transformation_id: str) -> Dict[str, Any]:
        with self._lock:
            state = self._require(transformation_id)
            return {
                "app_id": state.get("app_id") or "",
                "db_id": state.get("db_id") or "",
                "nfs_mount_path": state.get("nfs_mount_path") or "",
                "pathway": state.get("pathway") or "M-Upgrade",
                "app_name": state.get("app_name"),
                "db_name": state.get("db_name"),
                "target_branch": state.get("target_branch"),
                "repository_url": state.get("repository_url"),
                "metrics": dict(state.get("metrics") or _DEFAULT_METRICS),
                "startedAt": state.get("created_at"),
                "updatedAt": state.get("updated_at"),
                "completedAt": state.get("completed_at") or state.get("updated_at"),
            }

    def get_timing(self, transformation_id: str) -> Dict[str, Optional[Any]]:
        ctx = self.get_job_context(transformation_id)
        started = ctx.get("startedAt")
        completed = ctx.get("completedAt")
        seconds = _elapsed_seconds(started, completed)
        return {
            "startedAt": started,
            "completedAt": completed,
            "durationSeconds": seconds,
            "duration": duration_text(seconds),
        }

    def get_progress(self, transformation_id: str) -> Dict[str, Any]:
        with self._lock:
            state = self._require(transformation_id)
            overall = state["overall_status"]
            return {
                "transformation_id": state["transformation_id"],
                "overall_status": overall,
                "banner_message": banner_for(overall),
                "current_milestone": state["current_milestone"],
                "progress_percent": int(state.get("progress_percent") or 0),
                "milestones": list(state["milestones"]),
                "metrics": dict(state.get("metrics") or _DEFAULT_METRICS),
                "report": dict(state.get("report") or {}),
            }

    def get_status_payload(self, transformation_id: str) -> Dict[str, Any]:
        """DB-job-shaped status body (``GET .../jobs/{jobId}``).

        Field names match ``AiAgentJobStatusResponse`` in
        studio-database-code-modernize so the existing poller works unchanged;
        App+DB-specific counters are added alongside.
        """
        with self._lock:
            state = self._require(transformation_id)
            return self._status_payload(state)

    def get_logs(self, transformation_id: str, from_index: int = 0) -> Dict[str, Any]:
        with self._lock:
            state = self._require(transformation_id)
            logs: List[Dict[str, Any]] = state["logs"]
            start = max(0, int(from_index or 0))
            slice_ = logs[start:]
            return {
                "logs": slice_,
                "has_more": False,
                "next_index": start + len(slice_),
                "total": len(logs),
            }

    def is_terminal(self, transformation_id: str) -> bool:
        if is_job_terminal_on_disk(transformation_id):
            return True
        try:
            with self._lock:
                state = self._require(transformation_id)
        except KeyError:
            return True
        return state.get("overall_status") in (STATUS_COMPLETED, STATUS_FAILED)

    def refresh_state_from_disk(self, transformation_id: str) -> None:
        """Reload ``state.json`` into the in-memory cache (multi-worker / SSE readers)."""
        path = _state_path(transformation_id)
        if not path.is_file():
            return
        with self._lock:
            self._jobs[transformation_id] = json.loads(path.read_text(encoding="utf-8"))

    def exists(self, transformation_id: str) -> bool:
        with self._lock:
            if transformation_id in self._jobs:
                return True
            path = _state_path(transformation_id)
            if path.exists():
                self._jobs[transformation_id] = json.loads(path.read_text(encoding="utf-8"))
                return True
            return False

    def find_by_app_db(
        self, *, app_id: Optional[str] = None, db_id: Optional[str] = None
    ) -> Optional[str]:
        """Newest transformation id for an app/db pair.

        Public ``jobId`` is the application id (one app maps to one database).
        Routes still accept a dbId or the internal APPDB-… transformation id.
        Job folders are named by database id, so this walks
        ``db-code-modernize/*/reports/state.json``.
        """
        best: Optional[tuple] = None
        for folder, state in ws.iter_job_states():
            if app_id is not None and str(state.get("app_id") or "") != str(app_id):
                continue
            if db_id is not None and str(state.get("db_id") or "") != str(db_id):
                continue
            tid = str(state.get("transformation_id") or "")
            if not tid:
                continue
            _DB_ID_BY_JOB.setdefault(tid, folder)
            stamp = str(state.get("updated_at") or state.get("created_at") or "")
            candidate = (stamp, tid)
            if best is None or candidate > best:
                best = candidate
        return best[1] if best else None

    def count_active(self) -> int:
        """Transformations currently running — backs the launch concurrency cap."""
        return sum(
            1
            for _, state in ws.iter_job_states()
            if state.get("overall_status") in (STATUS_IN_PROGRESS, STATUS_QUEUED)
        )

    def find_active_job(self, *, app_id: str, db_id: str) -> Optional[str]:
        """An in-flight transformation for this app/db pair, if any.

        Job 3 rewrites files in a shared checkout and writes one report path,
        so two concurrent runs for the same app+db would race each other. The
        launch endpoint uses this to stay idempotent rather than starting a
        second run.
        """
        candidate = self.find_by_app_db(app_id=app_id, db_id=db_id)
        if not candidate:
            return None
        try:
            with self._lock:
                state = self._require(candidate)
        except KeyError:
            return None
        return (
            candidate
            if state.get("overall_status") in (STATUS_IN_PROGRESS, STATUS_QUEUED)
            else None
        )

    def public_job_id(self, transformation_id: str) -> str:
        """Caller-facing job id: ``appId``, falling back to the internal run id."""
        try:
            with self._lock:
                state = self._require(transformation_id)
        except KeyError:
            return transformation_id
        return _public_job_id(state)

    def resolve_job_id(self, candidate: str) -> Optional[str]:
        """Map an incoming ``{jobId}`` (appId, dbId or transformationId) to a job."""
        if not candidate:
            return None
        if self.exists(candidate):
            return candidate
        by_app = self.find_by_app_db(app_id=candidate)
        if by_app:
            return by_app
        return self.find_by_app_db(db_id=candidate)

    # -------------------------------------------------------------- internals

    def _status_payload(self, state: Dict[str, Any]) -> Dict[str, Any]:
        tid = state["transformation_id"]
        overall = state.get("overall_status") or STATUS_IN_PROGRESS
        metrics = dict(state.get("metrics") or _DEFAULT_METRICS)
        started = state.get("created_at")
        completed = state.get("completed_at")
        seconds = _elapsed_seconds(started, completed)
        report = dict(state.get("report") or {})

        payload: Dict[str, Any] = {
            "jobId": _public_job_id(state),
            "transformationId": tid,
            "appId": state.get("app_id"),
            "dbId": state.get("db_id"),
            "status": _API_STATUS.get(overall, "in_progress"),
            "overallStatus": overall,
            "phase": _phase_for(state),
            "phaseGroup": _MILESTONE_GROUPS.get(state.get("current_milestone"), "Transformation"),
            "progressPercent": int(state.get("progress_percent") or 0),
            "message": state.get("message") or "",
            "bannerMessage": banner_for(overall),
            "currentMilestone": state.get("current_milestone"),
            "milestonesTotal": len(MILESTONES),
            # DB-job aliases so one parser handles both job types. Files
            # created during the run (docker-compose.yml, db-secret.yaml) are
            # not in the initial scan, so the total is floored at the modified
            # count to keep objectsConverted/objectsTotal <= 1.
            "objectsTotal": max(
                int(metrics.get("filesScanned", 0) or 0),
                int(metrics.get("filesModified", 0) or 0),
            ),
            "objectsConverted": metrics.get("filesModified", 0),
            "sessionsCompleted": max(0, int(state.get("current_milestone") or 1) - 1),
            "lastCompletedBatch": _MILESTONE_TITLES.get(state.get("current_milestone")),
            # App+DB counters (FR4 summary cards).
            "filesScanned": metrics.get("filesScanned", 0),
            "filesModified": metrics.get("filesModified", 0),
            "violationsTotal": metrics.get("violationsFound", 0),
            "violationsResolved": metrics.get("violationsResolved", 0),
            "violationsFailed": metrics.get("violationsFailed", 0),
            "rulesProcessed": metrics.get("rulesProcessed", 0),
            "pgCompatibilityChanges": metrics.get("pgCompatibilityChanges", 0),
            "manualReviewItems": metrics.get("manualReviewItems", 0),
            "pathway": state.get("pathway"),
            "errorDetail": state.get("error"),
            "updatedAt": state.get("updated_at"),
        }
        if started:
            payload["startedAt"] = started
        if report.get("available"):
            payload["reportAvailable"] = True
            payload["reportPath"] = report.get("path")
            payload["reportStatus"] = report.get("status")
            payload["reportFileSizeBytes"] = report.get("fileSizeBytes")
        if overall in (STATUS_COMPLETED, STATUS_FAILED):
            payload["completedAt"] = completed
            payload["durationSeconds"] = seconds
            payload["duration"] = duration_text(seconds)
            payload["statusText"] = self._status_text(overall)
        return payload

    @staticmethod
    def _status_text(overall: str) -> str:
        if overall == STATUS_FAILED:
            return "Transformation failed"
        return "Transformation complete"

    def _emit_progress(self, state: Dict[str, Any], *, message: Optional[str] = None) -> None:
        tid = state["transformation_id"]
        payload = self._status_payload(state)
        if message:
            payload["message"] = message
        payload.update(
            {
                "type": event_bus.EVENT_PROGRESS_UPDATED,
                "timestamp": _iso(),
            }
        )
        event_bus.publish(job_dir(tid), tid, payload)

    def _require(self, transformation_id: str) -> Dict[str, Any]:
        if transformation_id in self._jobs:
            return self._jobs[transformation_id]
        path = _state_path(transformation_id)
        if path.exists():
            state = json.loads(path.read_text(encoding="utf-8"))
            self._jobs[transformation_id] = state
            return state
        raise KeyError(transformation_id)

    def _persist(self, state: Dict[str, Any]) -> None:
        path = _state_path(state["transformation_id"])
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, indent=2), encoding="utf-8")

    def _append_log_line(self, transformation_id: str, entry: Dict[str, Any]) -> None:
        """Mirror each log entry into ``reports/logs.jsonl``.

        ``state.json`` already carries the full list, but a line-per-entry file
        is what the DB job publishes and what makes the logs tail-able straight
        off the mount (``tail -f logs.jsonl``) without parsing a growing JSON
        document.
        """
        db_id = db_id_for_job(transformation_id)
        if not db_id:
            return
        try:
            path = ws.logs_path(db_id)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(entry) + "\n")
        except OSError as exc:  # noqa: BLE001 - logging must never fail the job
            logger.warning("Could not append Job 3 log line for %s: %s", transformation_id, exc)


_tracker: Optional[ProgressTracker] = None
_tracker_lock = threading.Lock()


def get_progress_tracker() -> ProgressTracker:
    global _tracker
    with _tracker_lock:
        if _tracker is None:
            _tracker = ProgressTracker()
        return _tracker


def reset_progress_tracker() -> ProgressTracker:
    global _tracker
    with _tracker_lock:
        _tracker = ProgressTracker()
        return _tracker
