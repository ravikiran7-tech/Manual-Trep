"""NFS workspace layout for App+DB (Job 3).

The Java BFF (``studio-database-code-modernize`` →
``TransformPackageBuilder.buildAppDbPackage``) creates two sibling directories
per database id on the shared mount:

    {claude_workspace}/db-code-modernize/{dbId}/_claude/    inputs  — Java writes
    {claude_workspace}/db-code-modernize/{dbId}/reports/    outputs — this service writes

Job 3 reads only from ``_claude`` and writes only into ``reports`` — the same
contract the DB schema job (Job 2) uses, and the only two locations this
service is allowed to touch.

Everything the job produces lands under ``reports`` on the shared mount:
``post_transformation_report.json``, ``state.json`` (progress + logs),
``events.jsonl`` and ``logs.jsonl`` (the SSE replay sources), the frozen
``request.json``/``rules.json``, and the transformed-code ZIP. That keeps the
whole job inspectable from the mount and lets it survive a container restart,
instead of living in a container-local workspace folder.

The directory is keyed by **database id**, matching how the Java side names it
and how Job 2 keys its folder by database name.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Iterator, Optional, Tuple

from app.core.config import get_settings

logger = logging.getLogger(__name__)

DB_CODE_MODERNIZE_SUBDIR = "db-code-modernize"
CLAUDE_SUBDIR = "_claude"
REPORTS_SUBDIR = "reports"

STATE_FILENAME = "state.json"
EVENTS_FILENAME = "events.jsonl"
LOGS_FILENAME = "logs.jsonl"
REQUEST_FILENAME = "request.json"
RULES_FILENAME = "rules.json"
JOB_CONFIG_FILENAME = "job_config.json"
PLAN_FILENAME = "dependency-resolution-plan.json"

DEFAULT_RULES_REMEDIATION_FILENAME = "oracle-to-postgresql-rules_remediation.json"
DEFAULT_DEPENDENCY_FINDINGS_FILENAME = "java-oracle-dependency.json"


def _safe_segment(value: Any, *, label: str = "dbId") -> str:
    """Validate that ``value`` is usable as a single directory name.

    The database id arrives from an API caller and becomes a path segment, so
    separators and traversal are rejected outright (Sonar S2083/S6549) rather
    than normalized away.
    """
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{label} is required to resolve the Job 3 workspace")
    if text in (".", "..") or "/" in text or "\\" in text or "\x00" in text:
        raise ValueError(f"Invalid {label} for a workspace path: {value!r}")
    return text


def folder_key(db_id: Any, fallback: Any = None) -> str:
    """Folder name for a job: the database id, or ``fallback`` when absent.

    Real launches always carry a dbId (the Java side names the directory after
    it). The fallback keeps direct callers — tests, embedded use — working
    instead of failing on a path that cannot be built.
    """
    try:
        return _safe_segment(db_id)
    except ValueError:
        if fallback is None:
            raise
        return _safe_segment(fallback, label="transformationId")


def workspace_base() -> Path:
    return Path(get_settings().claude_workspace)


def jobs_base() -> Path:
    """``{claude_workspace}/db-code-modernize`` — parent of every job folder."""
    return workspace_base() / DB_CODE_MODERNIZE_SUBDIR


def db_root(db_id: str) -> Path:
    """``{claude_workspace}/db-code-modernize/{dbId}``."""
    return jobs_base() / _safe_segment(db_id)


def inputs_dir(db_id: str) -> Path:
    """``.../{dbId}/_claude`` — read-only for this service."""
    return db_root(db_id) / CLAUDE_SUBDIR


def reports_dir(db_id: str) -> Path:
    """``.../{dbId}/reports`` — every Job 3 output goes here."""
    return db_root(db_id) / REPORTS_SUBDIR


def ensure_reports_dir(db_id: str) -> Path:
    """Create ``reports`` if the Java side has not already made it."""
    target = reports_dir(db_id)
    target.mkdir(parents=True, exist_ok=True)
    return target


def state_path(db_id: str) -> Path:
    return reports_dir(db_id) / STATE_FILENAME


def events_path(db_id: str) -> Path:
    return reports_dir(db_id) / EVENTS_FILENAME


def logs_path(db_id: str) -> Path:
    return reports_dir(db_id) / LOGS_FILENAME


def request_path(db_id: str) -> Path:
    return reports_dir(db_id) / REQUEST_FILENAME


def rules_path(db_id: str) -> Path:
    return reports_dir(db_id) / RULES_FILENAME


def resolve_input_file(db_id: str, value: str, *, label: str = "inputPaths") -> Path:
    """Resolve an input file to a path inside ``_claude``.

    Accepts a bare file name ("oracle-to-postgresql-rules_remediation.json"),
    a path relative to ``_claude``, or the absolute path the Java side reports
    on the launch request. An absolute path outside ``_claude`` is rejected so
    a caller cannot steer Job 3 at arbitrary files on the mount.
    """
    allowed_root = inputs_dir(db_id).resolve()
    raw = str(value or "").strip()
    if not raw:
        raise ValueError(f"{label} is required")
    candidate = Path(raw)
    resolved = candidate.resolve() if candidate.is_absolute() else (allowed_root / candidate).resolve()
    try:
        resolved.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(
            f"{label} must be under {allowed_root}, got: {resolved}"
        ) from exc
    return resolved


def default_rules_remediation(db_id: str) -> Path:
    """The conventional rules-remediation file the Java side writes."""
    return inputs_dir(db_id) / DEFAULT_RULES_REMEDIATION_FILENAME


def default_dependency_findings(db_id: str) -> Path:
    """The conventional Java-Oracle dependency findings file."""
    return inputs_dir(db_id) / DEFAULT_DEPENDENCY_FINDINGS_FILENAME


def job_config_path(db_id: str) -> Path:
    return reports_dir(db_id) / JOB_CONFIG_FILENAME


def plan_path(db_id: str) -> Path:
    return reports_dir(db_id) / PLAN_FILENAME


def relative_to_inputs(db_id: str, path: Path) -> str:
    """Return a path relative to ``_claude`` for frozen job_config."""
    root = inputs_dir(db_id).resolve()
    resolved = path.resolve()
    try:
        return str(resolved.relative_to(root)).replace("\\", "/")
    except ValueError:
        return resolved.name


def resolve_launch_inputs(
    db_id: str,
    *,
    dependency_findings: Optional[str] = None,
    rules_remediation: Optional[str] = None,
) -> Dict[str, Path]:
    """Resolve both Job 3 input files under ``_claude``."""
    findings_raw = (dependency_findings or "").strip() or DEFAULT_DEPENDENCY_FINDINGS_FILENAME
    rules_raw = (rules_remediation or "").strip() or DEFAULT_RULES_REMEDIATION_FILENAME
    findings_path = resolve_input_file(db_id, findings_raw, label="inputPaths.dependencyFindings")
    rules_path_resolved = resolve_input_file(db_id, rules_raw, label="inputPaths.rulesRemediation")
    if not findings_path.is_file():
        raise ValueError(
            f"dependencyFindings file not found in {inputs_dir(db_id)}: {findings_raw}"
        )
    if not rules_path_resolved.is_file():
        raise ValueError(
            f"rulesRemediation file not found in {inputs_dir(db_id)}: {rules_raw}"
        )
    return {
        "dependencyFindings": findings_path,
        "rulesRemediation": rules_path_resolved,
    }


def read_state(db_id: str) -> Optional[Dict[str, Any]]:
    path = state_path(db_id)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        logger.warning("Unreadable Job 3 state file: %s", path)
        return None
    return data if isinstance(data, dict) else None


def iter_job_states() -> Iterator[Tuple[str, Dict[str, Any]]]:
    """Yield ``(dbId, state)`` for every job folder that has a state file."""
    root = jobs_base()
    if not root.is_dir():
        return
    for folder in sorted(root.iterdir()):
        if not folder.is_dir():
            continue
        state = read_state(folder.name)
        if state:
            yield folder.name, state


def resolve_project_path(
    project_path: Optional[str],
    *,
    app_id: Any,
    tenant_id: Optional[Any] = None,
    plan_id: Optional[Any] = None,
) -> str:
    """Resolve the application checkout Job 3 rewrites in place.

    Callers that already know the checkout location send ``projectPath``
    directly and it is returned as-is. When it is omitted, derive it from the
    same NFS convention studio-core's own Job 1/M-Upgrade output already uses
    — confirmed against ``TransformationCodeDownloadServiceImpl``,
    ``ArtifactsListServiceImpl``, ``HtmlReportServiceImpl`` and
    ``PreviewReportServiceImpl`` in studio-core, which all build:

        {nfs_base_path}/{tenantId}/{appId}/transformed-code/{planId}/studio-workspace/{componentName}

    ``componentName`` is not supplied by the caller — it is discovered by
    listing ``studio-workspace/`` and excluding the reserved ``artifacts``
    folder, the same way ``TransformationCodeDownloadServiceImpl`` lists it on
    the Java side. This is Job 1's output directory, not a fresh checkout, so
    Job 3 continues modernizing the code Job 1 already produced.
    """
    if project_path and str(project_path).strip():
        return str(project_path).strip()

    if not tenant_id or not plan_id:
        raise ValueError(
            "projectPath is required, or both tenantId and planId must be "
            "supplied so it can be derived from the app's Job 1/M-Upgrade "
            "output location"
        )

    nfs_base = get_settings().app_db_job3.nfs_base_path
    workspace_dir = (
        Path(nfs_base)
        / _safe_segment(tenant_id, label="tenantId")
        / _safe_segment(app_id, label="appId")
        / "transformed-code"
        / _safe_segment(plan_id, label="planId")
        / "studio-workspace"
    )
    if not workspace_dir.is_dir():
        raise ValueError(f"Transformed-code workspace not found: {workspace_dir}")

    candidates = sorted(
        p for p in workspace_dir.iterdir() if p.is_dir() and p.name != "artifacts"
    )
    if not candidates:
        raise ValueError(f"No component directory found under {workspace_dir}")
    if len(candidates) > 1:
        names = ", ".join(p.name for p in candidates)
        raise ValueError(
            f"Multiple component directories under {workspace_dir} ({names}); "
            "supply projectPath explicitly to disambiguate"
        )
    return str(candidates[0])


def find_db_id(
    *,
    transformation_id: Optional[str] = None,
    app_id: Optional[str] = None,
    db_id: Optional[str] = None,
) -> Optional[str]:
    """Locate the job folder for a transformation id, app id, or database id.

    Callers track jobs by application id. Database id and the internal
    ``APPDB-…`` transformation id still resolve to the same folder. When several
    folders match, the most recently updated one wins.
    """
    if db_id:
        try:
            if state_path(db_id).is_file():
                return _safe_segment(db_id)
        except ValueError:
            return None

    matches: list[tuple] = []
    for folder, state in iter_job_states():
        if transformation_id and str(state.get("transformation_id") or "") == str(transformation_id):
            return folder
        if app_id and str(state.get("app_id") or "") == str(app_id):
            matches.append((str(state.get("updated_at") or state.get("created_at") or ""), folder))
        elif db_id and str(state.get("db_id") or "") == str(db_id):
            matches.append((str(state.get("updated_at") or state.get("created_at") or ""), folder))
    if not matches:
        return None
    matches.sort()
    return matches[-1][1]
