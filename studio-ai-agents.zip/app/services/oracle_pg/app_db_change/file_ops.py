"""Checkout file scanning helpers for App+DB Job 3."""

from __future__ import annotations

from pathlib import Path
from typing import List

SCAN_GLOBS = (
    "**/*.java",
    "**/*.xml",
    "**/*.properties",
    "**/*.yml",
    "**/*.yaml",
    "**/*.sql",
    "**/Dockerfile",
    "**/build.gradle",
    "**/build.gradle.kts",
)
SKIP_DIR_NAMES = {".git", "node_modules", "target", "build", ".idea"}


def scan_codebase(location: str) -> List[Path]:
    root = Path(location)
    if not root.exists():
        return []
    found: List[Path] = []
    for pattern in SCAN_GLOBS:
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            if path.name.endswith(".bak"):
                continue
            found.append(path)
    return sorted(set(found), key=lambda p: str(p).replace("\\", "/"))


def relative_to_root(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


def snapshot_files(location: str) -> dict:
    """Map relative path -> (mtime, size) for every scannable file.

    Taken before and after the Claude Agent SDK session so files the LLM edited
    are counted in ``filesModified`` — the counter the report stores and the
    SSE progress stream reports (the App+DB analogue of ``objectsConverted``).
    """
    root = Path(location)
    snapshot: dict = {}
    for path in scan_codebase(location):
        try:
            stat = path.stat()
        except OSError:
            continue
        snapshot[relative_to_root(path, root)] = (stat.st_mtime, stat.st_size)
    return snapshot


def diff_snapshot(before: dict, after: dict) -> List[str]:
    """Relative paths that were added or changed between two snapshots."""
    changed = [key for key, value in after.items() if before.get(key) != value]
    return sorted(changed)
