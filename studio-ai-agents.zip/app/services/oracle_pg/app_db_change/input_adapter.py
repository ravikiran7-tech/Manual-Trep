"""Deterministic Java-Oracle findings × remediation KB → dependency plan.

Mirrors Job 2 ``input_adapter``: findings and KB are joined by ``ruleId`` before
any Claude session. The remediation catalog defines scope: only findings whose
``ruleId`` appears in the rules file become plan violations; other dependency
rows are skipped (see ``assemblyWarnings``).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.services.oracle_pg.app_db_change import workspace as ws

logger = logging.getLogger(__name__)

PLAN_VERSION = "1.0"
STATUS_PENDING = "pending"
STATUS_FAILED = "failed"


def _first(*values: Any) -> Any:
    for value in values:
        if value not in (None, ""):
            return value
    return None


def _pick_default_remediation(remediations: Any) -> Optional[Dict[str, Any]]:
    if isinstance(remediations, dict):
        return remediations
    if not isinstance(remediations, list) or not remediations:
        return None
    for item in remediations:
        if isinstance(item, dict) and (item.get("default") or item.get("isDefault")):
            return item
    first = remediations[0]
    return first if isinstance(first, dict) else None


def load_json_file(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        raise ValueError(f"Could not read input file: {path} ({exc})") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Input file is not valid JSON: {path} ({exc.msg})") from exc


def load_java_remediation_catalog(path: Path) -> Dict[str, Dict[str, Any]]:
    """Load Oracle-Java remediation KB keyed by ruleId."""
    data = load_json_file(path)
    if not isinstance(data, dict):
        raise ValueError("rulesRemediation file must contain a JSON object")
    rules = data.get("rules")
    if not isinstance(rules, list):
        raise ValueError("rulesRemediation file must contain a rules array")

    catalog: Dict[str, Dict[str, Any]] = {}
    for item in rules:
        if not isinstance(item, dict):
            continue
        rule_id = _first(item.get("ruleId"), item.get("rule_id"))
        if not rule_id:
            continue
        rem = _pick_default_remediation(item.get("remediations") or item.get("remediation"))
        catalog[str(rule_id)] = {
            "ruleId": str(rule_id),
            "ruleName": _first(item.get("ruleName"), item.get("rule_name")),
            "category": _first(item.get("category"), "unknown"),
            "description": item.get("description"),
            "severity": item.get("severity"),
            "remediationId": (rem or {}).get("remediationId") or (rem or {}).get("remediation_id"),
            "remediationText": _first(
                (rem or {}).get("detailedDescription"),
                (rem or {}).get("description"),
                item.get("description"),
            ),
            "oldCode": _first((rem or {}).get("oldCode"), (rem or {}).get("old_code")),
            "newCode": _first((rem or {}).get("newCode"), (rem or {}).get("new_code")),
        }
    return catalog


def flatten_dependency_findings(data: Any) -> List[Dict[str, Any]]:
    """Flatten ``scan_results.Results[].violationDetails`` into plan rows."""
    if not isinstance(data, dict):
        raise ValueError("dependencyFindings file must contain a JSON object")

    results = (data.get("scan_results") or data.get("scanResults") or {}).get("Results")
    if results is None:
        results = (data.get("scan_results") or data.get("scanResults") or {}).get("results")
    if not isinstance(results, list):
        # Legacy / test shapes: top-level violations list
        rows = data.get("violations") or data.get("findings") or []
        if isinstance(rows, list):
            return [_normalize_legacy_finding(item) for item in rows if isinstance(item, dict)]
        raise ValueError("dependencyFindings missing scan_results.Results")

    findings: List[Dict[str, Any]] = []
    for result in results:
        if not isinstance(result, dict):
            continue
        details = result.get("violationDetails") or result.get("violation_details") or []
        if not isinstance(details, list):
            continue
        for file_entry in details:
            if not isinstance(file_entry, dict):
                continue
            filename = _first(file_entry.get("filename"), file_entry.get("file"), file_entry.get("affectedFile"))
            violations = file_entry.get("violations") or []
            if not isinstance(violations, list):
                continue
            for index, violation in enumerate(violations):
                if not isinstance(violation, dict):
                    continue
                rule_id = _first(violation.get("ruleId"), violation.get("rule_id"))
                if not rule_id:
                    continue
                begin = violation.get("beginLine") or violation.get("begin_line")
                end = violation.get("endLine") or violation.get("end_line") or begin
                lines: List[int] = []
                for value in (begin, end):
                    if value is None:
                        continue
                    try:
                        line = int(value)
                    except (TypeError, ValueError):
                        continue
                    if line not in lines:
                        lines.append(line)
                findings.append(
                    {
                        "violationId": (
                            f"{filename}:{rule_id}:{begin}:{index}"
                            if filename
                            else f"{rule_id}:{index}"
                        ),
                        "ruleId": str(rule_id),
                        "file": str(filename).replace("\\", "/") if filename else None,
                        "lines": lines,
                        "beginLine": begin,
                        "endLine": end,
                        "beginColumn": violation.get("beginColumn") or violation.get("begin_column"),
                        "endColumn": violation.get("endColumn") or violation.get("end_column"),
                    }
                )
    return findings


def _normalize_legacy_finding(item: Dict[str, Any]) -> Dict[str, Any]:
    rule_id = _first(item.get("ruleId"), item.get("rule_id"))
    filename = _first(item.get("filename"), item.get("file"), item.get("affectedFile"), item.get("affected_file"))
    lines_raw = item.get("affectedLines") or item.get("affected_lines") or item.get("lines") or []
    if isinstance(lines_raw, (int, str)):
        lines_raw = [lines_raw]
    lines: List[int] = []
    for value in lines_raw:
        try:
            lines.append(int(value))
        except (TypeError, ValueError):
            continue
    return {
        "violationId": str(item.get("violationId") or item.get("id") or f"{filename}:{rule_id}"),
        "ruleId": str(rule_id) if rule_id else None,
        "file": str(filename).replace("\\", "/") if filename else None,
        "lines": lines,
        "beginLine": lines[0] if lines else None,
        "endLine": lines[-1] if lines else None,
    }


def build_dependency_resolution_plan(
    *,
    findings_path: Path,
    catalog_path: Path,
    app_id: str,
    db_id: str,
    pathway: str = "M-Upgrade",
    project_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Join every finding to the KB and return a frozen plan payload."""
    findings_data = load_json_file(findings_path)
    catalog = load_java_remediation_catalog(catalog_path)
    findings = flatten_dependency_findings(findings_data)

    violations: List[Dict[str, Any]] = []
    warnings: List[str] = []
    files_map: Dict[str, Dict[str, Any]] = {}

    for finding in findings:
        rule_id = finding.get("ruleId")
        if not rule_id:
            warnings.append("Skipped finding with no ruleId")
            continue
        rule_key = str(rule_id)
        if rule_key not in catalog:
            warnings.append(f"Skipped finding for unselected ruleId={rule_key}")
            continue
        meta = catalog[rule_key]
        file_path = finding.get("file")
        status = STATUS_PENDING
        reason = None
        if not file_path:
            status = STATUS_FAILED
            reason = "No affected file specified — manual review required"
            warnings.append(f"{rule_id}: {reason}")

        item = {
            "violationId": finding.get("violationId"),
            "ruleId": str(rule_id),
            "ruleName": (meta or {}).get("ruleName"),
            "category": (meta or {}).get("category") or "unknown",
            "file": file_path,
            "lines": list(finding.get("lines") or []),
            "beginLine": finding.get("beginLine"),
            "endLine": finding.get("endLine"),
            "status": status,
            "reason": reason,
            "remediationId": (meta or {}).get("remediationId"),
            "remediationText": (meta or {}).get("remediationText"),
            "oldCode": (meta or {}).get("oldCode"),
            "newCode": (meta or {}).get("newCode"),
        }
        violations.append(item)

        if file_path:
            entry = files_map.setdefault(
                file_path,
                {"file": file_path, "violationCount": 0, "rulesTriggered": []},
            )
            entry["violationCount"] += 1
            if str(rule_id) not in entry["rulesTriggered"]:
                entry["rulesTriggered"].append(str(rule_id))

    in_scope = [v for v in violations if v.get("status") == STATUS_PENDING]
    empty_message = None
    if not in_scope:
        empty_message = (
            "No violations found in scope. Transformation will apply baseline "
            "PostgreSQL compatibility changes only."
            if not findings
            else "No actionable violations in scope (missing files or KB entries)."
        )

    plan = {
        "planVersion": PLAN_VERSION,
        "appId": app_id,
        "dbId": db_id,
        "pathway": pathway,
        "projectPath": project_path,
        "summary": {
            "totalFindings": len(findings),
            "findingsInScope": len(in_scope),
            "rulesInCatalog": len(catalog),
            "filesAffected": len(files_map),
            "emptyScopeMessage": empty_message,
        },
        "files": list(files_map.values()),
        "violations": violations,
        "catalogSubset": {
            "rules": [
                catalog[rid]
                for rid in sorted({str(v["ruleId"]) for v in violations if v.get("ruleId") in catalog})
            ]
        },
        "assemblyWarnings": warnings,
    }
    return plan


def write_dependency_resolution_plan(db_id: str, plan: Dict[str, Any]) -> Path:
    ws.ensure_reports_dir(db_id)
    path = ws.plan_path(db_id)
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return path


def load_dependency_resolution_plan(db_id: str) -> Optional[Dict[str, Any]]:
    path = ws.plan_path(db_id)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        logger.warning("Unreadable dependency-resolution-plan.json: %s", path)
        return None
    return data if isinstance(data, dict) else None


def build_and_write_plan(
    *,
    db_id: str,
    app_id: str,
    findings_path: Path,
    catalog_path: Path,
    pathway: str = "M-Upgrade",
    project_path: Optional[str] = None,
) -> Tuple[Dict[str, Any], Path]:
    plan = build_dependency_resolution_plan(
        findings_path=findings_path,
        catalog_path=catalog_path,
        app_id=app_id,
        db_id=db_id,
        pathway=pathway,
        project_path=project_path,
    )
    path = write_dependency_resolution_plan(db_id, plan)
    return plan, path
