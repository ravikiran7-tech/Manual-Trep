"""SSE event fan-out for App+DB (Job 3) transformations.

Mirrors ``app/services/oracle_pg/hooks.py`` (the DB job) so the Java BFF
(``studio-database-code-modernize`` → ``TransformProgressService``) and the
Studio MFE can consume both job types with one parser:

* every state change publishes a ``progress_updated`` event carrying
  ``progressPercent``;
* the terminal event additionally carries ``startedAt`` / ``completedAt`` /
  ``durationSeconds`` / ``duration`` and the finished-work counters
  (``filesModified`` — the App+DB analogue of the DB job's
  ``objectsConverted``) and the report location.

Events are persisted per job (``events.jsonl``) so a late SSE subscriber can
replay everything that already happened instead of starting mid-stream.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
from collections import defaultdict
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List

logger = logging.getLogger(__name__)

EVENT_PROGRESS_UPDATED = "progress_updated"
EVENT_ARTIFACT_READY = "artifact_ready"

EVENTS_FILENAME = "events.jsonl"

_subscribers: Dict[str, List[Callable[[Dict[str, Any]], Awaitable[None]]]] = defaultdict(list)
_lock = threading.RLock()


def events_path(job_dir: Path) -> Path:
    return job_dir / EVENTS_FILENAME


def subscribe(job_id: str, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
    with _lock:
        _subscribers[job_id].append(callback)


def unsubscribe(job_id: str, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
    with _lock:
        callbacks = _subscribers.get(job_id)
        if not callbacks:
            return
        try:
            callbacks.remove(callback)
        except ValueError:
            pass
        if not callbacks:
            _subscribers.pop(job_id, None)


def unsubscribe_all(job_id: str) -> None:
    with _lock:
        _subscribers.pop(job_id, None)


def read_events(job_dir: Path) -> List[Dict[str, Any]]:
    """Replay persisted events (skipping any partially written line)."""
    path = events_path(job_dir)
    if not path.exists():
        return []
    entries: List[Dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            entries.append(parsed)
    return entries


def persist_event(job_dir: Path, event: Dict[str, Any]) -> None:
    path = events_path(job_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event) + "\n")


def publish(job_dir: Path, job_id: str, event: Dict[str, Any]) -> Dict[str, Any]:
    """Persist an event and push it to live SSE subscribers.

    Safe to call from the worker thread: when no event loop is running in this
    thread the event is still persisted, and SSE readers pick it up from
    ``events.jsonl`` on their next poll.
    """
    persist_event(job_dir, event)
    _schedule_notify(job_id, event)
    return event


def _schedule_notify(job_id: str, event: Dict[str, Any]) -> None:
    with _lock:
        callbacks = list(_subscribers.get(job_id, []))
    if not callbacks:
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return

    async def _run() -> None:
        for callback in callbacks:
            try:
                await callback(event)
            except Exception:  # noqa: BLE001 - a dead subscriber must not stop the job
                logger.debug("App+DB SSE subscriber failed for %s", job_id, exc_info=True)

    loop.create_task(_run())


def is_terminal_event(event: Dict[str, Any]) -> bool:
    """True once the job reached a terminal state (closes the SSE stream)."""
    if event.get("type") != EVENT_PROGRESS_UPDATED:
        return False
    return str(event.get("status") or "").lower() in {"completed", "failed"}
