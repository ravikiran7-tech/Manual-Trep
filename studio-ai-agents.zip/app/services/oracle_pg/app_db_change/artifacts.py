"""App+DB (Job 3) artifact packaging.

Two artifacts come out of the Artifacts phase:

1. ``post_transformation_report.json`` — written by ``report_packager``;
2. ``<transformationId>_job3_modified_files.zip`` — every file Job 3 touched,
   available for download from the artifacts API.

The ZIP is built from the paths recorded in the report, so it always matches
what the report claims was modified — it never re-scans the checkout.
"""

from __future__ import annotations

import logging
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.services.oracle_pg.app_db_change.progress_tracker import job_dir
from app.services.oracle_pg.app_db_change.report_packager import REPORT_FILENAME, report_path

logger = logging.getLogger(__name__)


def zip_name(transformation_id: str) -> str:
    return f"{transformation_id}_job3_modified_files.zip"


def zip_path(transformation_id: str) -> Path:
    return job_dir(transformation_id) / zip_name(transformation_id)


def modified_file_paths(report: Dict[str, Any]) -> List[str]:
    """Relative paths of every file Job 3 modified, in report order."""
    paths: List[str] = []
    for item in report.get("fileModifications") or []:
        rel = item.get("filePath")
        if rel and rel not in paths and rel != "(unresolved)":
            paths.append(rel)
    if paths:
        return paths
    for item in report.get("appliedChanges") or []:
        rel = item.get("file")
        if rel and rel not in paths:
            paths.append(rel)
    return paths


def build_modified_files_zip(
    transformation_id: str,
    report: Dict[str, Any],
    *,
    project_path: Optional[str] = None,
) -> Optional[Path]:
    """Zip the Job 3 modified files plus the report; None when nothing to zip."""
    root_value = project_path or (report.get("inputSources") or {}).get("projectPath")
    if not root_value:
        return None
    root = Path(str(root_value))
    relatives = modified_file_paths(report)
    destination = zip_path(transformation_id)
    destination.parent.mkdir(parents=True, exist_ok=True)

    written = 0
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in relatives:
            source = root / relative
            if not source.is_file():
                logger.debug("Skipping missing Job 3 file for ZIP: %s", source)
                continue
            archive.write(source, arcname=relative.replace("\\", "/"))
            written += 1
        saved_report = report_path(transformation_id)
        if saved_report.is_file():
            archive.write(saved_report, arcname=REPORT_FILENAME)
    if written == 0 and not relatives:
        # Report-only archive is still useful, but flag the empty change set.
        logger.info("Job 3 %s produced no modified files to package", transformation_id)
    return destination


def list_artifacts(transformation_id: str, report: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Artifacts-section rows for the Studio left panel (FR1, FR12, FR13)."""
    entries: List[Dict[str, Any]] = []

    saved_report = report_path(transformation_id)
    project_report: Optional[Path] = None
    if report:
        declared = str(report.get("reportPath") or "").strip()
        if declared:
            project_report = Path(declared)

    report_file = project_report if project_report and project_report.is_file() else saved_report
    entries.append(
        {
            "key": "postTransformationReport",
            "name": REPORT_FILENAME,
            "label": "Post-Transformation Report",
            "type": "report",
            "path": str(report_file),
            "exists": report_file.is_file(),
            "sizeBytes": report_file.stat().st_size if report_file.is_file() else 0,
            "downloadUrl": (
                f"/studio-ai-agents/api/app-db-transformation/{transformation_id}/report"
            ),
        }
    )

    archive = zip_path(transformation_id)
    entries.append(
        {
            "key": "transformedCode",
            "name": zip_name(transformation_id),
            "label": "Transformed Code (Job 3 files)",
            "type": "archive",
            "path": str(archive),
            "exists": archive.is_file(),
            "sizeBytes": archive.stat().st_size if archive.is_file() else 0,
            "downloadUrl": (
                f"/studio-ai-agents/api/app-db-transformation/{transformation_id}"
                "/artifacts/download"
            ),
        }
    )
    return entries
