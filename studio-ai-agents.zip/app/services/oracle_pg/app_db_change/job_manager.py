"""App+DB Job 3 manager: freeze config, semaphore, enqueue, crash resume."""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from app.core.config import get_settings
from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.orchestrator import AppDbOrchestrator
from app.services.oracle_pg.app_db_change.pathways import normalize_pathway
from app.services.oracle_pg.app_db_change.progress_tracker import (
    STATUS_IN_PROGRESS,
    STATUS_QUEUED,
    get_progress_tracker,
)

logger = logging.getLogger(__name__)
settings = get_settings()

_RESUMABLE_STATUSES = frozenset({STATUS_QUEUED, STATUS_IN_PROGRESS})

_job_manager: Optional["AppDbJobManager"] = None


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class AppDbJobManager:
    def __init__(self) -> None:
        max_jobs = settings.app_db_job3.max_concurrent_jobs
        self._semaphore = asyncio.Semaphore(max_jobs)
        self._running: set[str] = set()
        self._tasks: dict[str, asyncio.Task] = {}
        self._orchestrator = AppDbOrchestrator(self)
        self.tracker = get_progress_tracker()

    def clear_running(self, folder_key: str) -> None:
        self._running.discard(folder_key)

    def is_running(self, folder_key: str) -> bool:
        return folder_key in self._running

    async def launch(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Validate inputs, freeze job_config, queue the orchestrator."""
        app_id = str(request.get("appId") or "").strip()
        db_id = str(request.get("dbId") or "").strip()
        if not app_id:
            raise ValueError("appId is required")
        if not db_id:
            raise ValueError("dbId is required")

        project_type = str(request.get("projectType") or "java").strip().lower()
        if project_type != "java":
            raise ValueError(
                f"projectType '{project_type}' is not supported; "
                "App-DB Job 3 currently supports: java"
            )

        project_path = ws.resolve_project_path(
            request.get("projectPath"),
            app_id=app_id,
            tenant_id=request.get("tenantId"),
            plan_id=request.get("planId"),
        )

        input_paths = request.get("inputPaths") or {}
        if not isinstance(input_paths, dict):
            input_paths = {}
        # Legacy single-field alias on the launch body.
        if not input_paths.get("rulesRemediation") and request.get("rulesRemediation"):
            input_paths = dict(input_paths)
            input_paths["rulesRemediation"] = request.get("rulesRemediation")

        resolved = ws.resolve_launch_inputs(
            db_id,
            dependency_findings=input_paths.get("dependencyFindings"),
            rules_remediation=input_paths.get("rulesRemediation"),
        )
        frozen_paths = {
            "dependencyFindings": ws.relative_to_inputs(db_id, resolved["dependencyFindings"]),
            "rulesRemediation": ws.relative_to_inputs(db_id, resolved["rulesRemediation"]),
        }

        transformation_id = f"APPDB-{uuid.uuid4().hex[:12].upper()}"
        pathway = normalize_pathway(str(request.get("pathway") or "M-Upgrade"))

        self.tracker.initialize_tracking(
            transformation_id,
            app_id=app_id,
            db_id=db_id,
            nfs_mount_path=project_path,
            pathway=pathway,
            app_name=request.get("appName"),
            db_name=request.get("dbName"),
            target_branch=request.get("targetBranch"),
            repository_url=request.get("repositoryUrl"),
            overall_status=STATUS_QUEUED,
        )
        self.tracker.add_log_entry(transformation_id, "INFO", "Transformation queued")
        self.tracker.add_log_entry(
            transformation_id,
            "INFO",
            f"Reading inputs from {ws.inputs_dir(db_id)}; writing outputs to {ws.reports_dir(db_id)}",
        )

        frozen = {
            "transformationId": transformation_id,
            "jobId": app_id,
            "appId": app_id,
            "dbId": db_id,
            "tenantId": request.get("tenantId"),
            "planId": request.get("planId"),
            "projectPath": project_path,
            "projectType": project_type,
            "pathway": pathway,
            "schemaFilePath": request.get("schemaFilePath"),
            "skipLlm": bool(request.get("skipLlm")),
            "aiAgent": request.get("aiAgent") or "claude-sonnet-5-5",
            "appName": request.get("appName"),
            "dbName": request.get("dbName"),
            "sourceDatabaseVersion": request.get("sourceDatabaseVersion"),
            "targetDatabaseVersion": str(request.get("targetDatabaseVersion") or "15.0"),
            "targetBranch": request.get("targetBranch"),
            "repositoryUrl": request.get("repositoryUrl"),
            "inputPaths": frozen_paths,
            "frozenAt": _utc_now_iso(),
            "claudeWorkspace": settings.claude_workspace,
        }
        ws.ensure_reports_dir(db_id)
        config_path = ws.job_config_path(db_id)
        config_path.write_text(json.dumps(frozen, indent=2), encoding="utf-8")
        # Keep legacy request.json for inspectability / older helpers.
        ws.request_path(db_id).write_text(json.dumps(frozen, indent=2), encoding="utf-8")

        await self._enqueue(db_id)

        return {
            "transformationId": transformation_id,
            "jobId": app_id,
            "status": STATUS_QUEUED,
            "message": "Transformation queued",
            "workspacePath": str(ws.db_root(db_id)),
        }

    def _has_active_task(self, folder_key: str) -> bool:
        task = self._tasks.get(folder_key)
        return task is not None and not task.done()

    def _track_task(self, folder_key: str, task: asyncio.Task) -> None:
        self._tasks[folder_key] = task

        def _on_done(_: asyncio.Task) -> None:
            if self._tasks.get(folder_key) is task:
                self._tasks.pop(folder_key, None)

        task.add_done_callback(_on_done)

    async def _enqueue(self, folder_key: str) -> None:
        if folder_key in self._running or self._has_active_task(folder_key):
            return
        task = asyncio.create_task(
            self._run_with_semaphore(folder_key),
            name=f"app-db-{folder_key}",
        )
        self._track_task(folder_key, task)

    async def _run_with_semaphore(self, folder_key: str) -> None:
        async with self._semaphore:
            self._running.add(folder_key)
            try:
                config = self._load_job_config(folder_key)
                tid = str(config.get("transformationId") or "")
                if tid and self.tracker.exists(tid):
                    # Flip QUEUED → IN_PROGRESS before the orchestrator starts.
                    progress = self.tracker.get_progress(tid)
                    if progress.get("overall_status") == STATUS_QUEUED:
                        self.tracker.update_milestone(tid, 1, STATUS_IN_PROGRESS)
                await self._orchestrator.run(folder_key)
            finally:
                self.clear_running(folder_key)

    @staticmethod
    def _load_job_config(folder_key: str) -> Dict[str, Any]:
        path = ws.job_config_path(folder_key)
        if not path.is_file():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _iter_job_directories(self) -> list[tuple[str, Path]]:
        base = ws.jobs_base()
        if not base.exists():
            return []
        return [(child.name, child) for child in base.iterdir() if child.is_dir()]

    @staticmethod
    def _resume_sort_key(job_dir: Path) -> str:
        state_file = job_dir / "reports" / "state.json"
        if state_file.exists():
            try:
                updated_at = json.loads(state_file.read_text(encoding="utf-8")).get("updated_at")
                if updated_at:
                    return str(updated_at)
            except (json.JSONDecodeError, OSError):
                pass
        config_file = job_dir / "reports" / "job_config.json"
        if config_file.exists():
            try:
                frozen_at = json.loads(config_file.read_text(encoding="utf-8")).get("frozenAt")
                if frozen_at:
                    return str(frozen_at)
            except (json.JSONDecodeError, OSError):
                pass
        return job_dir.name

    async def resume_in_progress_jobs(self) -> int:
        """Re-enqueue queued / in-progress App+DB jobs found on disk."""
        candidates: list[tuple[str, Path]] = []
        for folder_key, job_dir in self._iter_job_directories():
            state_file = job_dir / "reports" / "state.json"
            config_file = job_dir / "reports" / "job_config.json"
            if not state_file.is_file() or not config_file.is_file():
                continue
            try:
                state = json.loads(state_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if not isinstance(state, dict):
                continue
            if state.get("overall_status") not in _RESUMABLE_STATUSES:
                continue
            if folder_key in self._running or self._has_active_task(folder_key):
                continue
            candidates.append((folder_key, job_dir))

        candidates.sort(key=lambda item: self._resume_sort_key(item[1]))
        resumed = 0
        for folder_key, _ in candidates:
            logger.info("Resuming App+DB job %s", folder_key)
            await self._enqueue(folder_key)
            resumed += 1
        return resumed


def get_app_db_job_manager() -> AppDbJobManager:
    global _job_manager
    if _job_manager is None:
        _job_manager = AppDbJobManager()
    return _job_manager


def reset_app_db_job_manager() -> AppDbJobManager:
    global _job_manager
    _job_manager = AppDbJobManager()
    return _job_manager
