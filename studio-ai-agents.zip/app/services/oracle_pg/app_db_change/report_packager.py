"""Deterministic App+DB post_transformation_report.json (same role as DB artifact_packager).

The payload is UI-ready: every label, badge, sub-label and formatted timestamp
the Post-Transformation Report modal renders is computed here, so the frontend
reads the file as-is and performs no further calculation. It carries three
overlapping shapes on purpose:

* the Job 1 app-modernization report shape (``application`` /
  ``executiveSummary`` / ``rulesResults`` / ``fileModifications`` /
  ``metadata``) so the existing Studio report modal renders it unchanged;
* explicit display blocks (``header`` / ``metadataRow`` / ``summaryCards`` /
  ``rulesTable`` / ``filesSection`` / ``footer``) that map 1:1 onto the report
  sections in the spec;
* the original App+DB fields (``summary`` / ``appliedChanges`` /
  ``reportPath``) for backward compatibility with the internal report API,
  studio-core and studio-database-code-modernize.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.services.oracle_pg.app_db_change import workspace as ws
from app.services.oracle_pg.app_db_change.pathways import (
    PATHWAY_BASIC,
    PATHWAY_CONTAINER,
    PATHWAY_UPGRADE,
    normalize_pathway,
)
from app.services.oracle_pg.app_db_change.progress_tracker import job_dir

REPORT_FILENAME = "post_transformation_report.json"

REPORT_SUBTITLE = "Post transformation summary"
NO_FAILURES_PLACEHOLDER = "Zero failed violations"
NO_VIOLATIONS_LABEL = "0 — No violations in scope"
NOT_APPLICABLE = "N/A"

# PostgreSQL compatibility change categories surfaced as extra rule rows, gated
# by pathway (FR5). M-Upgrade shows violation remediations only.
_PATHWAY_COMPAT_CATEGORIES = {
    PATHWAY_UPGRADE: [],
    PATHWAY_BASIC: [
        "Datasource Configuration Updates",
        "JDBC Driver Replacement",
        "ORM / Persistence Configuration",
        "Connection Pool Migration",
    ],
    PATHWAY_CONTAINER: [
        "Datasource Configuration Updates",
        "JDBC Driver Replacement",
        "ORM / Persistence Configuration",
        "Connection Pool Migration",
        "Dockerfile PostgreSQL Updates",
        "Docker Compose PostgreSQL Updates",
        "Kubernetes Manifest Updates",
        "Health Check Configuration",
    ],
}

_CICD_NAMES = {"jenkinsfile", "azure-pipelines.yml", "azure-pipelines.yaml", ".gitlab-ci.yml"}
_CONFIG_NAMES = {"pom.xml", "build.gradle", "build.gradle.kts", "persistence.xml"}
_CONTAINER_NAMES = {"dockerfile", "docker-compose.yml", "docker-compose.yaml", "db-secret.yaml"}

_CICD_MANUAL_REVIEW_REASON = (
    "CI-CD pipeline Oracle JDBC reference detected — manual replacement required"
)


def _file_category(file_path: str) -> str:
    """Classify a modified file for report display (java/config/container/cicd)."""
    posix = file_path.replace("\\", "/")
    name = posix.rsplit("/", 1)[-1].lower()
    parts = posix.lower().split("/")
    if name in _CICD_NAMES or ".github" in parts and "workflows" in parts:
        return "cicd"
    if name in _CONTAINER_NAMES or "k8s" in parts or "kubernetes" in parts:
        return "container"
    if name.endswith(".java"):
        return "java"
    if name in _CONFIG_NAMES or name.startswith("application") and name.endswith(
        (".properties", ".yml", ".yaml")
    ):
        return "config"
    return "config"


def report_path(transformation_id: str) -> Path:
    """``.../db-code-modernize/{dbId}/reports/post_transformation_report.json``."""
    return job_dir(transformation_id) / REPORT_FILENAME


def report_path_for_db(db_id: str) -> Path:
    return ws.reports_dir(db_id) / REPORT_FILENAME


def nfs_report_path(db_id: str) -> Path:
    """The report's location on the shared mount, keyed by database id.

    Job 3 writes into ``{claude_workspace}/db-code-modernize/{dbId}/reports``
    and nowhere else — never into the application checkout — so the database
    service and the Studio UI read one agreed location.
    """
    return report_path_for_db(db_id)


def build_post_transformation_report(
    *,
    transformation_id: str,
    app_id: str,
    db_id: str,
    pathway: str,
    nfs_mount_path: str,
    app_name: Optional[str] = None,
    db_name: Optional[str] = None,
    oracle_version: Optional[str] = None,
    pg_version: str = "15.0",
    project_type: str = "java",
    schema_file_path: Optional[str] = None,
    overall_status: str = "COMPLETED",
    files_scanned: int = 0,
    violations_found: int = 0,
    skipped_targets: int = 0,
    applied_changes: Optional[List[Dict[str, Any]]] = None,
    violation_outcomes: Optional[List[Dict[str, Any]]] = None,
    compat_applied: Optional[List[Dict[str, Any]]] = None,
    cicd_findings: Optional[List[str]] = None,
    timing: Optional[Dict[str, Any]] = None,
    target_branch: Optional[str] = None,
    repository_url: Optional[str] = None,
) -> Dict[str, Any]:
    """UI-ready camelCase payload. Reads this file as-is — no further calculation."""
    pathway = normalize_pathway(pathway or PATHWAY_UPGRADE)
    applied = list(applied_changes or [])
    outcomes = list(violation_outcomes or [])
    compat = list(compat_applied or [])
    app_label = str(app_name or app_id or "")
    db_label = str(db_name or db_id or "")
    pathway_label = _pathway_label(pathway)

    files_modified = len(applied)
    if outcomes:
        violations_resolved = sum(1 for o in outcomes if o.get("status") == "RESOLVED")
        violations_failed = sum(1 for o in outcomes if o.get("status") == "FAILED")
    else:
        violations_resolved = sum(
            len(item.get("violations_fixed") or item.get("violationsFixed") or []) for item in applied
        )
        violations_failed = skipped_targets
    rules_processed = _count_rules_processed(outcomes, applied)
    success_rate = round((violations_resolved / violations_found) * 100, 2) if violations_found else 0
    pg_compat_changes = sum(len(item.get("changes") or []) for item in compat)
    compat_files = len({item.get("file") for item in compat if item.get("file")})
    files_with_violation_fix = len(
        {o.get("file") for o in outcomes if o.get("status") == "RESOLVED" and o.get("file")}
    ) or files_modified

    started_at = (timing or {}).get("startedAt")
    completed_at = (timing or {}).get("completedAt")
    duration_seconds, duration_display = _duration(started_at, completed_at)

    rules_results = _build_rules_results(outcomes, applied, pathway)
    file_modifications = _build_file_modifications(applied, outcomes)
    manual_review = _build_manual_review(outcomes)

    # CI/CD findings are never edited — surface them as manual-review items.
    touched_files = [item.get("file") for item in applied if item.get("file")]
    cicd_files = [f for f in touched_files if _file_category(f) == "cicd"]
    for found in cicd_findings or []:
        if found not in cicd_files:
            cicd_files.append(found)
    by_path = {entry["filePath"]: entry for entry in file_modifications}
    for f in cicd_files:
        manual_review.append({"rule": None, "file": f, "reason": _CICD_MANUAL_REVIEW_REASON})
        entry = by_path.get(f)
        if entry is not None:
            entry["manualReview"].append(_CICD_MANUAL_REVIEW_REASON)

    # FR6: per-file failed panel copy is decided here so the modal only renders.
    for entry in file_modifications:
        entry["failedPlaceholder"] = NO_FAILURES_PLACEHOLDER
        entry["hasFailures"] = bool(entry["failed"])
        entry["hasManualReview"] = bool(entry["manualReview"])
        entry["badges"] = {
            "violationsFixed": entry["violationsFixed"],
            "violationsFailed": entry["violationsFailed"],
            "fixedLabel": f"{entry['violationsFixed']} Violations Fixed",
            "failedLabel": f"{entry['violationsFailed']} Violations Failed",
        }

    summary_text = _summary_text(
        app_label,
        pathway,
        violations_found,
        violations_resolved,
        files_with_violation_fix,
        pg_compat_changes,
        compat_files,
    )

    workspace_path = report_path_for_db(db_id) if db_id else report_path(transformation_id)
    public_path = workspace_path

    generated_at = datetime.now()
    success_rate_display = f"{round(success_rate)}%" if violations_found else NOT_APPLICABLE

    summary_cards = _build_summary_cards(
        rules_processed=rules_processed,
        violations_found=violations_found,
        violations_resolved=violations_resolved,
        violations_failed=violations_failed,
        files_modified=files_modified,
        success_rate_display=success_rate_display,
    )
    metadata_row = _build_metadata_row(
        app_label=app_label,
        app_id=app_id,
        pathway_label=pathway_label,
        duration_display=duration_display,
        completed_at=completed_at,
    )

    return {
        "transformationId": transformation_id,
        "appId": str(app_id),
        "dbId": str(db_id),
        "pathway": pathway,
        "pathwayLabel": pathway_label,
        "overallStatus": overall_status,
        "timing": {
            "startedAt": started_at,
            "completedAt": completed_at,
            "durationSeconds": duration_seconds,
            "duration": duration_display,
        },
        # --- FR2 modal header ---
        "header": {
            "title": (
                "Post-Transformation Report: App-DB Dependency Code Changes for "
                f"{pathway} + DB pathway"
            ),
            "subtitle": REPORT_SUBTITLE,
            "closable": True,
        },
        "reportTitle": (
            f"Post-Transformation Report: App-DB Dependency Code Changes for {pathway} + DB pathway"
        ),
        "reportSubtitle": REPORT_SUBTITLE,
        # --- FR3 metadata row ---
        "metadataRow": metadata_row,
        # --- Job 1 app-modernization report shape (Studio report modal) ---
        "application": {
            "name": app_label,
            "id": str(app_id),
            "applicationId": str(app_id),
            "dbId": str(db_id),
            "dbName": db_label,
            "pathway": pathway,
            "pathwayLabel": pathway_label,
            "duration": duration_display,
            "completedOn": completed_at,
            "completedOnDisplay": _format_completed_on(completed_at),
        },
        "executiveSummary": {
            "totalRulesProcessed": rules_processed,
            "totalViolations": violations_found,
            "violationsResolved": violations_resolved,
            "violationsFailed": violations_failed,
            "filesModified": files_modified,
            "successRate": success_rate,
            "successRateDisplay": success_rate_display,
            "summaryCards": summary_cards,
            "description": summary_text,
            # legacy DB-style fields kept for existing consumers:
            "successfullyConverted": files_modified,
            "requiresReview": violations_failed,
            "failed": 0 if overall_status == "COMPLETED" else 1,
            "totalFiles": files_scanned,
        },
        # --- FR4 transformation summary section ---
        "transformationSummary": {
            "heading": "Transformation Summary",
            "summaryLine": summary_text,
            "cards": summary_cards,
        },
        "summaryText": summary_text,
        # --- FR5 rule-by-rule section ---
        "rulesResults": rules_results,
        "rulesTable": {
            "heading": "Rule by Rule Results",
            "subHeading": "Code changes by applied Oracle-Java dependency rules",
            # The table holds the Oracle-Java rule rows plus the pathway's
            # PostgreSQL-compatibility rows, so the two counts differ on
            # M-Basic / M-Container-Mono. `title` counts what is rendered;
            # `rulesProcessed` is the Oracle-Java rule count shown on the
            # summary card, so the UI can title the table either way.
            "title": f"Rules ({len(rules_results)})",
            "rowCount": len(rules_results),
            "rulesProcessed": rules_processed,
            "compatibilityRows": len(rules_results) - rules_processed,
            "columns": [
                "S.No",
                "Rule Name",
                "Files Impacted",
                "Violations",
                "Success",
                "Failed",
            ],
            "rows": rules_results,
        },
        # --- FR6 file modification section ---
        "fileModifications": file_modifications,
        "filesSection": {
            "heading": "File Modification Details",
            "subHeading": "Detailed breakdown of dependency code changes at file level",
            "title": f"Modified Files ({len(file_modifications)})",
            "noFailuresPlaceholder": NO_FAILURES_PLACEHOLDER,
            "manualReviewLabel": "Requires Manual Review",
            "files": file_modifications,
        },
        "manualReview": manual_review,
        # --- FR7 footer ---
        "footer": {
            "generatedOn": generated_at.strftime("%d/%m/%Y"),
            "generatedAtTime": _format_time(generated_at),
            "generatedOnText": (
                f"Report generated on {generated_at.strftime('%d/%m/%Y')} - {_format_time(generated_at)}"
            ),
            "saved": True,
            "savedText": "Report saved successfully",
            "downloadPdf": {"enabled": True, "label": "Download PDF"},
        },
        "metadata": {
            "reportType": "App-DB Dependency Code Changes",
            "transformationJob": "Job 3",
            "generatedBy": "Concierto Modernize Studio",
            "generatedAt": generated_at.isoformat(timespec="seconds"),
            "projectType": project_type,
            "oracleVersion": oracle_version,
            "targetDatabaseVersion": pg_version,
            "reportVersion": 2,
        },
        # --- original App+DB fields (internal report API / studio-core) ---
        "summary": {
            "filesScanned": files_scanned,
            "filesModified": files_modified,
            "violationsFound": violations_found,
            "violationsResolved": violations_resolved,
            "violationsFailed": violations_failed,
            "skippedTargets": skipped_targets,
            "rulesProcessed": rules_processed,
            "pgCompatibilityChanges": pg_compat_changes,
            "manualReviewItems": len(manual_review),
            "successRate": success_rate,
        },
        "appliedChanges": [_public_change(item) for item in applied],
        "inputSources": {
            "projectPath": nfs_mount_path,
            "schemaFilePath": schema_file_path,
        },
        "reportPath": str(public_path),
        "note": "This file is UI-ready; no further calculation required.",
    }


def _pathway_label(pathway: str) -> str:
    return f"{pathway} + DB-Modernize"


def _format_completed_on(value: Optional[str]) -> Optional[str]:
    """FR3 "Completed On" — MMM DD, YYYY, HH:MM AM/PM."""
    parsed = _parse_iso(value)
    if parsed is None:
        return None
    return f"{parsed.strftime('%b %d, %Y')}, {_format_time(parsed)}"


def _format_time(value: datetime) -> str:
    """HH:MM AM/PM without the platform-specific %-I / %#I difference."""
    hour = value.hour % 12 or 12
    meridiem = "AM" if value.hour < 12 else "PM"
    return f"{hour:02d}:{value.minute:02d} {meridiem}"


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def _build_metadata_row(
    *,
    app_label: str,
    app_id: str,
    pathway_label: str,
    duration_display: Optional[str],
    completed_at: Optional[str],
) -> List[Dict[str, Any]]:
    return [
        {"key": "applicationName", "label": "Application Name", "value": app_label or NOT_APPLICABLE},
        {"key": "applicationId", "label": "Application ID", "value": str(app_id) or NOT_APPLICABLE},
        {"key": "transformationPathway", "label": "Transformation Pathway", "value": pathway_label},
        {"key": "duration", "label": "Duration", "value": duration_display or NOT_APPLICABLE},
        {
            "key": "completedOn",
            "label": "Completed On",
            "value": _format_completed_on(completed_at) or NOT_APPLICABLE,
        },
    ]


def _build_summary_cards(
    *,
    rules_processed: int,
    violations_found: int,
    violations_resolved: int,
    violations_failed: int,
    files_modified: int,
    success_rate_display: str,
) -> List[Dict[str, Any]]:
    """FR4 four summary cards, including the zero-violation wording."""
    violations_card: Dict[str, Any] = {
        "key": "totalViolations",
        "label": "Total Violations",
        "value": violations_found,
        "displayValue": str(violations_found) if violations_found else NO_VIOLATIONS_LABEL,
        "detail": "Total violation count",
    }
    if violations_found:
        violations_card["subLabel"] = {
            "text": f"{violations_resolved} Resolved / {violations_failed} Failed",
            "resolved": violations_resolved,
            "failed": violations_failed,
            "resolvedColor": "green",
            "failedColor": "red",
        }
    return [
        {
            "key": "totalRulesProcessed",
            "label": "Total Rules Processed",
            "value": rules_processed,
            "displayValue": str(rules_processed),
            "detail": "Subset of Oracle-Java rules selected by user",
        },
        violations_card,
        {
            "key": "filesModified",
            "label": "Modified",
            "value": files_modified,
            "displayValue": str(files_modified),
            "detail": "All files touched during Job 3",
        },
        {
            "key": "successRate",
            "label": "Success Rate",
            "value": success_rate_display,
            "displayValue": success_rate_display,
            "detail": "(Resolved ÷ Total Violations) × 100",
        },
    ]


def _count_rules_processed(
    outcomes: List[Dict[str, Any]], applied: List[Dict[str, Any]]
) -> int:
    keys = set()
    for o in outcomes:
        keys.add(str(o.get("rule_id") or o.get("rule_name") or id(o)))
    if keys:
        return len(keys)
    for item in applied:
        for rid in item.get("violations_fixed") or item.get("violationsFixed") or []:
            keys.add(str(rid))
    return len(keys)


def _build_rules_results(
    outcomes: List[Dict[str, Any]],
    compat_source: List[Dict[str, Any]],
    pathway: str,
) -> List[Dict[str, Any]]:
    """FR5 rule-by-rule table: one row per Oracle-Java rule, plus PG-compat rows.

    ``compat_source`` is the merged applied-change set, so a compatibility
    category counts as applied wherever the change happened — during violation
    remediation or during the compatibility phase. The violation rows count
    violations (not changes), so nothing is double counted. The "additional
    PostgreSQL compatibility changes" figure in the summary stays scoped to the
    compatibility phase.
    """
    order: List[str] = []
    rows: Dict[str, Dict[str, Any]] = {}
    for o in outcomes:
        key = str(o.get("rule_id") or o.get("rule_name") or "unspecified")
        row = rows.get(key)
        if row is None:
            row = {
                "ruleId": o.get("rule_id"),
                "ruleName": o.get("rule_name") or o.get("rule_id") or "Unspecified rule",
                "category": o.get("category") or "unknown",
                "filesImpacted": 0,
                "violations": 0,
                "success": 0,
                "failed": 0,
                "_files": set(),
            }
            rows[key] = row
            order.append(key)
        row["violations"] += 1
        if o.get("status") == "RESOLVED":
            row["success"] += 1
            if o.get("file"):
                row["_files"].add(o["file"])
        else:
            row["failed"] += 1
    result: List[Dict[str, Any]] = []
    for key in order:
        row = rows[key]
        row["filesImpacted"] = len(row.pop("_files"))
        row["violationsDisplay"] = str(row["violations"])
        result.append(row)
    result.extend(_compat_rule_rows(compat_source, pathway))
    # S.No and the highlight flag are assigned once, after compat rows join.
    for index, row in enumerate(result, start=1):
        row["sNo"] = index
        row["hasFailures"] = bool(row.get("failed"))
        row["highlight"] = bool(row.get("failed"))
    return result


def _compat_rule_rows(
    compat: List[Dict[str, Any]], pathway: str
) -> List[Dict[str, Any]]:
    applicable = _PATHWAY_COMPAT_CATEGORIES.get(normalize_pathway(pathway), [])
    if not applicable:
        return []
    tally: Dict[str, Dict[str, Any]] = {
        cat: {"files": set(), "count": 0, "failed": 0, "manual": []} for cat in applicable
    }
    seen: set = set()
    for item in compat:
        fp = item.get("file")
        for change in item.get("changes") or []:
            reason = str(change.get("reason") or "")
            key = (fp, reason)
            if key in seen:
                continue
            seen.add(key)
            category = _categorize_compat(reason)
            bucket = tally.get(category)
            if bucket is None:
                continue
            if change.get("manualReview") or change.get("manual_review"):
                bucket["failed"] += 1
                bucket["manual"].append(
                    f"{fp or category}: {change.get('reason') or 'manual review required'}"
                )
                continue
            bucket["count"] += 1
            if fp:
                bucket["files"].add(fp)
    # Compat changes flagged at file level (not per change) still count.
    for item in compat:
        for flagged in item.get("manual_review") or item.get("manualReview") or []:
            category = _categorize_compat(str(flagged))
            bucket = tally.get(category)
            if bucket is None:
                continue
            bucket["failed"] += 1
            bucket["manual"].append(str(flagged))

    rows = []
    for cat in applicable:
        info = tally[cat]
        applied_count = info["count"]
        rows.append(
            {
                "ruleId": None,
                "ruleName": cat,
                "category": "postgresql-compatibility",
                "filesImpacted": len(info["files"]),
                "violations": NOT_APPLICABLE,
                "violationsDisplay": NOT_APPLICABLE,
                "success": applied_count,
                "failed": info["failed"],
                "applied": applied_count > 0,
                "manualReview": info["manual"],
                "note": None if applied_count or info["failed"] else "No matching files in scope",
            }
        )
    return rows


def _categorize_compat(reason: str) -> str:
    r = reason.lower()
    if "dockerfile" in r:
        return "Dockerfile PostgreSQL Updates"
    if "compose" in r:
        return "Docker Compose PostgreSQL Updates"
    if "kubernetes" in r or "k8s" in r or "manifest" in r or "secret" in r:
        return "Kubernetes Manifest Updates"
    if "health" in r or "actuator" in r or "probe" in r:
        return "Health Check Configuration"
    if "hikari" in r or "pool" in r:
        return "Connection Pool Migration"
    if "dialect" in r or "hibernate" in r or "jpa" in r or "persistence" in r:
        return "ORM / Persistence Configuration"
    if "driver" in r or "ojdbc" in r or "import" in r:
        return "JDBC Driver Replacement"
    return "Datasource Configuration Updates"


def _change_bullet(change: Dict[str, Any]) -> str:
    """FR6 fixed-panel bullet: "[Action taken] — [brief description]"."""
    reason = change.get("reason")
    line = change.get("line") or change.get("lineNumber")
    if reason:
        text = str(reason)
        if line:
            return f"{text} (Line {line})"
        return text
    old = change.get("old_code")
    new = change.get("new_code")
    if old is not None and new is not None:
        suffix = f" (Line {line})" if line else ""
        return f"Replaced {old!r} with {new!r}{suffix}"
    return "Applied Oracle→PostgreSQL change"


def _build_file_modifications(
    applied: List[Dict[str, Any]],
    outcomes: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """FR6 file details: fixed panel from applied changes, failed panel from outcomes."""
    order: List[str] = []
    by_file: Dict[str, Dict[str, Any]] = {}
    for item in applied:
        fp = item.get("file")
        if not fp:
            continue
        by_file[fp] = {
            "filePath": fp,
            "category": _file_category(fp),
            "violationsFixed": len(item.get("violations_fixed") or item.get("violationsFixed") or []),
            "violationsFailed": 0,
            "fixed": [_change_bullet(c) for c in item.get("changes") or []],
            "failed": [],
            "manualReview": [],
        }
        order.append(fp)
    for o in outcomes:
        if o.get("status") != "FAILED":
            continue
        fp = o.get("file") or "(unresolved)"
        entry = by_file.get(fp)
        if entry is None:
            entry = {
                "filePath": fp,
                "category": _file_category(fp),
                "violationsFixed": 0,
                "violationsFailed": 0,
                "fixed": [],
                "failed": [],
                "manualReview": [],
            }
            by_file[fp] = entry
            order.append(fp)
        entry["violationsFailed"] += 1
        bullet = f"{o.get('rule_name') or o.get('rule_id') or 'Rule'}: {o.get('reason') or 'manual review required'}"
        entry["failed"].append(bullet)
        entry["manualReview"].append(bullet)
    return [by_file[fp] for fp in order]


def _build_manual_review(outcomes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items = []
    for o in outcomes:
        if o.get("status") != "FAILED":
            continue
        items.append(
            {
                "rule": o.get("rule_name") or o.get("rule_id"),
                "file": o.get("file"),
                "reason": o.get("reason") or "Manual review required",
            }
        )
    return items


def _summary_text(
    app_label: str,
    pathway: str,
    violations_found: int,
    violations_resolved: int,
    files_with_violation_fix: int,
    pg_compat_changes: int,
    compat_files: int,
) -> str:
    name = app_label or "the application"
    if violations_found > 0:
        return (
            f"The automated App-DB dependency transformation of {name} for the {pathway} pathway "
            f"concluded with resolution of {violations_resolved} Oracle-Java dependency violations "
            f"across {files_with_violation_fix} files, with {pg_compat_changes} additional PostgreSQL "
            f"compatibility changes applied."
        )
    return (
        f"The automated App-DB dependency transformation of {name} completed with no Oracle-Java "
        f"violations in scope. PostgreSQL compatibility changes were applied across {compat_files} files."
    )


def _duration(started: Optional[str], completed: Optional[str]) -> Tuple[Optional[int], Optional[str]]:
    start = _parse_iso(started)
    end = _parse_iso(completed)
    if start is None or end is None:
        return None, None
    seconds = max(0, int((end - start).total_seconds()))
    minutes, secs = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return seconds, " ".join(parts)


def _read_report_file(path: Path) -> Optional[Dict[str, Any]]:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def load_report(transformation_id: str) -> Optional[Dict[str, Any]]:
    """Read a saved report by transformation id.

    The fast path resolves the job's ``reports`` folder through the tracker.
    When the tracker has no state for the id — a report restored without its
    state file — the ``db-code-modernize`` folders are scanned for a report
    carrying that id, so the report on the mount stays readable on its own.
    """
    report = _read_report_file(report_path(transformation_id))
    if report:
        return report
    for db_id, _ in ws.iter_job_states():
        candidate = _read_report_file(report_path_for_db(db_id))
        if candidate and str(candidate.get("transformationId") or "") == str(transformation_id):
            return candidate
    root = ws.jobs_base()
    if not root.is_dir():
        return None
    for folder in sorted(root.iterdir()):
        if not folder.is_dir():
            continue
        candidate = _read_report_file(folder / ws.REPORTS_SUBDIR / REPORT_FILENAME)
        if candidate and str(candidate.get("transformationId") or "") == str(transformation_id):
            return candidate
    return None


def find_latest_transformation_id(app_id: str, db_id: str) -> Optional[str]:
    """Latest job whose state matches appId + dbId.

    Job folders are named by database id under ``db-code-modernize``, so this
    walks ``db-code-modernize/*/reports/state.json``.
    """
    wanted_app = str(app_id)
    wanted_db = str(db_id)
    matches: List[tuple] = []
    for _, state in ws.iter_job_states():
        if str(state.get("app_id") or "") != wanted_app:
            continue
        if str(state.get("db_id") or "") != wanted_db:
            continue
        tid = str(state.get("transformation_id") or "")
        if not tid:
            continue
        stamp = str(state.get("updated_at") or state.get("created_at") or "")
        matches.append((stamp, tid))
    if not matches:
        return None
    matches.sort()
    return matches[-1][1]


def resolve_report(
    *,
    app_id: str,
    db_id: str,
    transformation_id: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    tid = (transformation_id or "").strip() or find_latest_transformation_id(app_id, db_id)
    if not tid:
        return None
    report = load_report(tid)
    if not report:
        return None
    report_app = str(report.get("appId") or "")
    report_db = str(report.get("dbId") or "")
    if report_app and report_app != str(app_id):
        return None
    if report_db and report_db != str(db_id):
        return None
    return report


def resolve_report_location(
    *,
    app_id: str,
    db_id: str,
    transformation_id: Optional[str] = None,
) -> Optional[Dict[str, str]]:
    """Locate post_transformation_report.json and return only its name and path.

    Lets callers (the database service) read the file straight off the shared
    mount instead of fetching the whole report body through this service on
    every summary request.

    There is one location — ``db-code-modernize/{dbId}/reports`` — so the
    report's own ``reportPath`` is authoritative; the dbId-derived path is the
    fallback for a report written before that field existed. Only a path that
    exists on disk is returned.
    """
    report = resolve_report(
        app_id=app_id,
        db_id=db_id,
        transformation_id=transformation_id,
    )
    if not report:
        return None

    tid = str(report.get("transformationId") or "").strip()
    if not tid:
        return None

    candidates: List[Path] = []
    declared = str(report.get("reportPath") or "").strip()
    if declared:
        candidates.append(Path(declared))
    report_db_id = str(report.get("dbId") or db_id or "").strip()
    if report_db_id:
        candidates.append(report_path_for_db(report_db_id))
    candidates.append(report_path(tid))

    for candidate in candidates:
        if candidate.is_file():
            return {
                "transformationId": tid,
                "name": REPORT_FILENAME,
                "path": str(candidate),
            }
    return None


def write_post_transformation_report(
    report: Dict[str, Any],
    nfs_mount_path: Optional[str] = None,
) -> Path:
    """Write the report to ``reports/`` on the shared mount.

    ``nfs_mount_path`` is accepted for call-site compatibility but is no longer
    a write target — the application checkout is never written to. The single
    destination is the job's ``db-code-modernize/{dbId}/reports`` folder, keyed
    by the report's own ``dbId``.
    """
    text = json.dumps(report, indent=2)
    db_id = str(report.get("dbId") or "").strip()
    destination = (
        report_path_for_db(db_id) if db_id else report_path(report["transformationId"])
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8")
    return destination


def finalize_report_timing(
    transformation_id: str,
    *,
    started_at: Optional[str],
    completed_at: Optional[str],
) -> Optional[Dict[str, Any]]:
    """Re-stamp the report's duration once the whole job is done.

    The report is generated during the Artifacts phase, so at write time
    ``completedAt`` is the report's own timestamp and the duration excludes the
    remaining steps. FR3's Duration is "Job 3 start → completion", so it is
    corrected here after the final milestone.
    """
    report = load_report(transformation_id)
    if not report:
        return None
    seconds, display = _duration(started_at, completed_at)
    if display is None:
        return report
    report["timing"] = {
        "startedAt": started_at,
        "completedAt": completed_at,
        "durationSeconds": seconds,
        "duration": display,
    }
    application = dict(report.get("application") or {})
    application["duration"] = display
    application["completedOn"] = completed_at
    application["completedOnDisplay"] = _format_completed_on(completed_at)
    report["application"] = application
    for row in report.get("metadataRow") or []:
        if row.get("key") == "duration":
            row["value"] = display
        elif row.get("key") == "completedOn":
            row["value"] = _format_completed_on(completed_at) or NOT_APPLICABLE
    write_post_transformation_report(report)
    return report


def _public_change(item: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "file": item.get("file"),
        "violationsFixed": list(item.get("violations_fixed") or item.get("violationsFixed") or []),
        "changes": list(item.get("changes") or []),
    }
