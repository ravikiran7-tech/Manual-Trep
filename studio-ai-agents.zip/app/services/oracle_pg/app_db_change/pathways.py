"""App+DB pathway identifiers and normalization."""

from __future__ import annotations

PATHWAY_BASIC = "M-Basic"
PATHWAY_UPGRADE = "M-Upgrade"
PATHWAY_CONTAINER = "M-Container-Mono"

_NORMALIZED = {
    "m-upgrade": PATHWAY_UPGRADE,
    "mupgrade": PATHWAY_UPGRADE,
    "m-basic": PATHWAY_BASIC,
    "mbasic": PATHWAY_BASIC,
    "m-container-mono": PATHWAY_CONTAINER,
    "mcontainermono": PATHWAY_CONTAINER,
}


def normalize_pathway(pathway: str) -> str:
    key = (pathway or PATHWAY_UPGRADE).strip().lower().replace(" ", "").replace("_", "-")
    return _NORMALIZED.get(key, pathway.strip() or PATHWAY_UPGRADE)


def compatibility_instructions(pathway: str) -> str:
    """Required compatibility inspection for the existing Claude session."""
    normalized = normalize_pathway(pathway)
    if normalized not in {PATHWAY_BASIC, PATHWAY_CONTAINER}:
        return ""

    scope = (
        "You MUST inspect every existing compatibility file matching: "
        "application*.properties/yml/yaml, pom.xml, build.gradle/build.gradle.kts, "
        "and persistence.xml. In each matching file, replace every Oracle-specific "
        "datasource URL, JDBC driver/dependency, Hibernate/JPA dialect, and connection "
        "pool setting with its PostgreSQL equivalent. Do not skip these files merely "
        "because they are absent from the violation plan. Leave a matching file "
        "unchanged only when it contains no Oracle-specific setting, and do not create "
        "a missing file."
    )
    if normalized == PATHWAY_CONTAINER:
        scope += (
            " You MUST also inspect every existing Dockerfile, docker-compose*.yml/yaml, "
            "and Kubernetes manifest under k8s/ or kubernetes/, replacing Oracle "
            "database images, URLs, drivers, environment variables, and health checks "
            "with PostgreSQL equivalents. Do not edit CI/CD pipeline files."
        )
    return scope


def compatibility_change_reason(file_path: str, pathway: str) -> str | None:
    """Return a report reason when ``file_path`` is in the pathway's extra scope."""
    normalized = normalize_pathway(pathway)
    if normalized not in {PATHWAY_BASIC, PATHWAY_CONTAINER}:
        return None

    posix = file_path.replace("\\", "/").lower()
    name = posix.rsplit("/", 1)[-1]
    if name.startswith("application") and name.endswith((".properties", ".yml", ".yaml")):
        return "PostgreSQL datasource configuration update"
    if name in {"pom.xml", "build.gradle", "build.gradle.kts"}:
        return "PostgreSQL JDBC driver replacement"
    if name == "persistence.xml":
        return "PostgreSQL ORM / persistence configuration update"

    if normalized != PATHWAY_CONTAINER:
        return None
    if name == "dockerfile":
        return "Dockerfile PostgreSQL update"
    if name.startswith("docker-compose") and name.endswith((".yml", ".yaml")):
        return "Docker Compose PostgreSQL update"
    if (
        name.endswith((".yml", ".yaml"))
        and any(part in {"k8s", "kubernetes"} for part in posix.split("/"))
    ):
        return "Kubernetes manifest PostgreSQL update"
    return None
