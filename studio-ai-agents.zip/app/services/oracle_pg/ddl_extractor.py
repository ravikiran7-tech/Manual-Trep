"""Extract Oracle DDL blocks with line numbers from export files."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


CREATE_KEYWORDS = (
    "TABLE",
    "VIEW",
    "INDEX",
    "SEQUENCE",
    "TRIGGER",
    "PROCEDURE",
    "FUNCTION",
    "PACKAGE",
    "MATERIALIZED VIEW",
    "TYPE",
    "SCHEMA",
)


@dataclass
class DdlBlock:
    schema: str
    name: str
    object_type: str
    start_line: int
    end_line: int
    text: str
    file_name: str

    @property
    def source_location(self) -> str:
        return f"{self.file_name}:{self.start_line}-{self.end_line}"


def _build_create_pattern(schema: str, name: str) -> list[re.Pattern[str]]:
    schema_part = rf"(?:{re.escape(schema)}\.)?" if schema else r"(?:\w+\.)?"
    patterns: list[re.Pattern[str]] = []
    for keyword in CREATE_KEYWORDS:
        kw = keyword.replace(" ", r"\s+")
        patterns.append(
            re.compile(
                rf"(?im)^\s*CREATE\s+(?:OR\s+REPLACE\s+)?{kw}\s+"
                rf"{schema_part}{re.escape(name)}\b",
            )
        )
    return patterns


def extract_object_block(
    ddl_text: str,
    file_name: str,
    schema: str,
    name: str,
) -> Optional[DdlBlock]:
    """Find CREATE statement for an object and return line-bounded block."""
    lines = ddl_text.splitlines()
    if not lines:
        return None

    for pattern in _build_create_pattern(schema, name):
        match = pattern.search(ddl_text)
        if not match:
            continue
        start_line = ddl_text[: match.start()].count("\n") + 1
        remainder = ddl_text[match.start() :]
        next_create = re.search(
            r"(?im)^\s*CREATE\s+(?:OR\s+REPLACE\s+)?",
            remainder[len(match.group(0)) :],
        )
        if next_create:
            end_offset = len(match.group(0)) + next_create.start()
            block_text = remainder[:end_offset].rstrip()
        else:
            block_text = remainder.rstrip()
        end_line = start_line + block_text.count("\n")
        return DdlBlock(
            schema=schema,
            name=name,
            object_type="",
            start_line=start_line,
            end_line=end_line,
            text=block_text,
            file_name=file_name,
        )
    return None


def index_ddl_blocks(ddl_path: Path) -> dict[tuple[str, str], DdlBlock]:
    """Index DDL blocks by (schema.lower(), name.lower())."""
    if not ddl_path.is_file():
        return {}
    text = ddl_path.read_text(encoding="utf-8", errors="replace")
    file_name = ddl_path.name
    index: dict[tuple[str, str], DdlBlock] = {}

    pattern = re.compile(
        r"(?im)^\s*CREATE\s+(?:OR\s+REPLACE\s+)?"
        r"(TABLE|VIEW|(?:MATERIALIZED\s+VIEW)|INDEX|SEQUENCE|TRIGGER|PROCEDURE|FUNCTION|PACKAGE|TYPE)\s+"
        r"(?:(\w+)\.)?(\w+)",
    )
    for match in pattern.finditer(text):
        _obj_type, schema, name = match.groups()
        schema = schema or ""
        block = extract_object_block(text, file_name, schema, name)
        if block:
            index[(schema.lower(), name.lower())] = block
    return index
