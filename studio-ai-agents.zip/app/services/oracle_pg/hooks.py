"""Claude Agent SDK hooks for Oracle PG transformation progress events."""
from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Awaitable

from app.services.oracle_pg.live_logs import (
    format_post_tool_use,
    format_progress_event,
    format_sdk_message,
    set_current_phase,
)
from app.services.oracle_pg.workspace import events_path, job_root, logs_meta_path, logs_path

# job_id -> list of async subscriber callbacks
_subscribers: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]] = defaultdict(list)
_log_subscribers: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]] = defaultdict(list)

UI_STREAM_EVENT_TYPES = frozenset(
    {
        "progress_updated",
        "sql_written",
        "plan_updated",
        "file_written",
        "file_read",
        "file_search",
    }
)

_SDK_NOISE_SUBTYPES = frozenset({"thinking_tokens", "init"})


def is_ui_stream_event(event: dict[str, Any], *, verbose: bool = False) -> bool:
    """Return True when an event should be sent on the default SSE stream."""
    if verbose:
        return True

    event_type = event.get("type")
    if event_type in UI_STREAM_EVENT_TYPES:
        return True

    if event_type == "sdk_message":
        if event.get("subtype") in _SDK_NOISE_SUBTYPES:
            return False
        if event.get("messageType") == "ResultMessage":
            return True
        return False

    return False


def should_persist_sdk_message(payload: dict[str, Any]) -> bool:
    """Only persist session result messages; skip noisy agent token streams."""
    return is_ui_stream_event(payload, verbose=False)


def subscribe(job_id: str, callback: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
    _subscribers[job_id].append(callback)


def unsubscribe_all(job_id: str) -> None:
    _subscribers.pop(job_id, None)


def subscribe_logs(job_id: str, callback: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
    _log_subscribers[job_id].append(callback)


def unsubscribe_logs(job_id: str) -> None:
    _log_subscribers.pop(job_id, None)


def _next_log_seq(job_id: str) -> int:
    meta_path = logs_meta_path(job_id)
    seq = 0
    if meta_path.exists():
        try:
            data = json.loads(meta_path.read_text(encoding="utf-8"))
            seq = int(data.get("lastSeq", 0))
        except (json.JSONDecodeError, TypeError, ValueError):
            seq = 0
    seq += 1
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(json.dumps({"lastSeq": seq}), encoding="utf-8")
    return seq


def _persist_log_entry(job_id: str, entry: dict[str, Any]) -> None:
    path = logs_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")


async def _notify_log_subscribers(job_id: str, entry: dict[str, Any]) -> None:
    for callback in list(_log_subscribers.get(job_id, [])):
        try:
            await callback(entry)
        except Exception:
            continue


def _schedule_log_notify(job_id: str, entry: dict[str, Any]) -> None:
    callbacks = list(_log_subscribers.get(job_id, []))
    if not callbacks:
        return

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return

    async def _run() -> None:
        await _notify_log_subscribers(job_id, entry)

    loop.create_task(_run())


async def append_log_entry(job_id: str, entry: dict[str, Any]) -> dict[str, Any]:
    """Persist and broadcast a human-readable log entry."""
    entry = dict(entry)
    entry.setdefault("timestamp", datetime.now(timezone.utc).strftime("%H:%M:%S"))
    entry["seq"] = _next_log_seq(job_id)
    entry.setdefault("jobId", job_id)
    _persist_log_entry(job_id, entry)
    await _notify_log_subscribers(job_id, entry)
    return entry


def append_log_entry_sync(job_id: str, entry: dict[str, Any]) -> dict[str, Any]:
    """Persist a log entry and schedule subscriber notification from sync code."""
    entry = dict(entry)
    entry.setdefault("timestamp", datetime.now(timezone.utc).strftime("%H:%M:%S"))
    entry["seq"] = _next_log_seq(job_id)
    entry.setdefault("jobId", job_id)
    _persist_log_entry(job_id, entry)
    _schedule_log_notify(job_id, entry)
    return entry


async def _broadcast(job_id: str, event: dict[str, Any]) -> None:
    event.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    event.setdefault("jobId", job_id)

    _persist_event(job_id, event)
    await _notify_subscribers(job_id, event)


def _persist_event(job_id: str, event: dict[str, Any]) -> None:
    path = events_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event) + "\n")


async def _notify_subscribers(job_id: str, event: dict[str, Any]) -> None:
    for callback in list(_subscribers.get(job_id, [])):
        try:
            await callback(event)
        except Exception:
            continue


def _schedule_subscriber_notify(job_id: str, event: dict[str, Any]) -> None:
    """Notify live SSE subscribers from synchronous orchestrator code."""
    callbacks = list(_subscribers.get(job_id, []))
    if not callbacks:
        return

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return

    async def _run() -> None:
        await _notify_subscribers(job_id, event)

    loop.create_task(_run())


def progress_updated_event(job_id: str, progress: dict[str, Any]) -> dict[str, Any]:
    """Build a structured progress payload for SSE consumers (Java BFF / UI)."""
    from app.services.oracle_pg.report_metrics import timing_fields_for_api

    event: dict[str, Any] = {
        "type": "progress_updated",
        "jobId": job_id,
        "status": progress.get("status"),
        "phase": progress.get("phase"),
        "progressPercent": progress.get("progressPercent"),
        "message": progress.get("message"),
        "sessionsCompleted": progress.get("sessionsCompleted", 0),
        "lastCompletedBatch": progress.get("lastCompletedBatch"),
        "objectsTotal": progress.get("objectsTotal", 0),
        "objectsConverted": progress.get("objectsConverted", 0),
        "updatedAt": progress.get("updatedAt"),
    }
    event.update(timing_fields_for_api(progress))
    if progress.get("errorDetail"):
        event["errorDetail"] = progress["errorDetail"]
    notes = progress.get("notes")
    if isinstance(notes, list) and notes:
        event["latestNote"] = notes[-1]
    return event


def notify_progress_update(job_id: str, progress: dict[str, Any]) -> None:
    """Persist and push structured job progress to the SSE stream."""
    event = progress_updated_event(job_id, progress)
    event.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    _persist_event(job_id, event)
    _schedule_subscriber_notify(job_id, event)

    phase = progress.get("phase")
    if phase:
        set_current_phase(job_id, phase)
    append_log_entry_sync(job_id, format_progress_event(job_id, progress))


def make_progress_hooks(job_id: str) -> dict[str, list[Any]] | None:
    """Build HookMatcher map for PostToolUse progress tracking."""
    try:
        from claude_agent_sdk import HookMatcher
    except ImportError:
        return None

    root = job_root(job_id)

    async def on_tool_use(
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input") or {}

        log_entry = format_post_tool_use(
            job_id,
            tool_name,
            tool_input,
            job_root=root,
        )
        if log_entry:
            await append_log_entry(job_id, log_entry)

        if tool_name == "Read":
            file_path = str(tool_input.get("file_path", ""))
            if file_path:
                await _broadcast(
                    job_id,
                    {
                        "type": "file_read",
                        "tool": tool_name,
                        "filePath": file_path,
                    },
                )
            return {}

        if tool_name in ("Glob", "Grep"):
            await _broadcast(
                job_id,
                {
                    "type": "file_search",
                    "tool": tool_name,
                    "pattern": str(
                        tool_input.get("pattern", tool_input.get("glob_pattern", ""))
                    ),
                    "path": str(tool_input.get("path", tool_input.get("glob", ""))),
                },
            )
            return {}

        if tool_name not in ("Write", "Edit"):
            return {}

        file_path = str(tool_input.get("file_path", ""))
        if not file_path:
            return {}

        if file_path.replace("\\", "/").endswith("/state/progress.json"):
            return {}

        event_type = "file_written"
        if "conversion-plan" in file_path:
            event_type = "plan_updated"
        elif file_path.endswith(".sql"):
            event_type = "sql_written"

        await _broadcast(
            job_id,
            {
                "type": event_type,
                "tool": tool_name,
                "filePath": file_path,
            },
        )
        return {}

    return {
        "PostToolUse": [
            HookMatcher(matcher="Write", hooks=[on_tool_use]),
            HookMatcher(matcher="Edit", hooks=[on_tool_use]),
            HookMatcher(matcher="Read", hooks=[on_tool_use]),
            HookMatcher(matcher="Glob", hooks=[on_tool_use]),
            HookMatcher(matcher="Grep", hooks=[on_tool_use]),
        ],
    }


async def append_sdk_message(job_id: str, message: Any) -> None:
    """Persist SDK message summaries for stream replay and live logs."""
    for entry in format_sdk_message(job_id, message):
        await append_log_entry(job_id, entry)

    payload: dict[str, Any] = {"type": "sdk_message"}
    if hasattr(message, "__class__"):
        payload["messageType"] = message.__class__.__name__
    if hasattr(message, "subtype"):
        payload["subtype"] = getattr(message, "subtype", None)
    if hasattr(message, "result"):
        payload["result"] = getattr(message, "result", None)
    if hasattr(message, "session_id"):
        payload["sessionId"] = getattr(message, "session_id", None)
    if not should_persist_sdk_message(payload):
        return
    await _broadcast(job_id, payload)
