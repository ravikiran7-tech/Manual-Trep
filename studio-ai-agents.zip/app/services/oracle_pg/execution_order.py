"""Pass 3: execution order assignment for Oracle PG conversion plan."""

from __future__ import annotations

import json
from collections import defaultdict, deque
from typing import Any, Optional

from app.services.oracle_pg.progress import (
    EXECUTION_PHASE_BY_TYPE,
    OBJECT_BATCH_ORDER,
    load_conversion_plan,
    save_conversion_plan,
)
from app.services.oracle_pg.workspace import state_dir


def _topological_sort(names: list[str], edges: dict[str, set[str]]) -> list[str]:
    """Sort names so dependencies appear before dependents."""
    incoming: dict[str, int] = {name: 0 for name in names}
    graph: dict[str, set[str]] = {name: set() for name in names}

    for name in names:
        for dep in edges.get(name, set()):
            if dep not in graph:
                graph[dep] = set()
                incoming.setdefault(dep, 0)
            if name not in incoming:
                incoming[name] = 0
            graph[dep].add(name)
            incoming[name] = incoming.get(name, 0) + 1

    queue = deque(sorted(n for n, deg in incoming.items() if deg == 0))
    ordered: list[str] = []
    while queue:
        node = queue.popleft()
        if node in names:
            ordered.append(node)
        for child in sorted(graph.get(node, set())):
            incoming[child] -= 1
            if incoming[child] == 0:
                queue.append(child)

    for name in sorted(names):
        if name not in ordered:
            ordered.append(name)
    return ordered


def _object_label(obj: dict[str, Any]) -> str:
    schema = obj.get("schema", "")
    name = obj.get("name", "")
    return f"{schema}.{name}" if schema else name


def _dependency_edges(plan: list[dict[str, Any]]) -> dict[str, set[str]]:
    edges: dict[str, set[str]] = defaultdict(set)
    for obj in plan:
        label = _object_label(obj)
        ai = obj.get("aiAnalysis") or {}
        for dep in ai.get("depends_on_code", []) or []:
            edges[label].add(str(dep))
        for base in ai.get("base_tables", []) or []:
            edges[label].add(str(base))
        meta = obj.get("structuralMetadata") or {}
        owner = meta.get("ownerTable") or obj.get("owningTable")
        if owner and str(obj.get("type", "")).upper() in {
            "DEFAULT",
            "PRIMARY_KEY",
            "UNIQUE",
            "FOREIGN_KEY",
            "CHECK",
            "INDEX",
            "TRIGGER",
        }:
            schema = obj.get("schema", "")
            owner_label = f"{schema}.{owner}" if schema and "." not in str(owner) else str(owner)
            edges[label].add(owner_label)
    return edges


def _phase_from_ai_analysis(
    obj: dict[str, Any],
    global_execution_order: Optional[dict[str, Any]],
) -> Optional[int]:
    if not global_execution_order:
        return None
    label = _object_label(obj).lower()
    for phase_num in range(1, 15):
        key = f"phase_{phase_num}"
        for variant in (key, f"{key}_tables", f"{key}_schemas"):
            items = global_execution_order.get(variant)
            if not isinstance(items, list):
                continue
            for item in items:
                if str(item).lower() == label:
                    return phase_num
    return None


def apply_execution_order(job_id: str, workspace_override: str | None = None) -> dict[str, Any]:
    """Assign executionPhase and phaseOrder to each plan object."""
    plan = load_conversion_plan(job_id)
    edges = _dependency_edges(plan)

    global_order: Optional[dict[str, Any]] = None
    for obj in plan:
        ai = obj.get("aiAnalysis") or {}
        if isinstance(ai.get("execution_order"), dict):
            global_order = ai["execution_order"]
            break

    by_phase: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for obj in plan:
        obj_type = str(obj.get("type", "")).upper()
        phase = _phase_from_ai_analysis(obj, global_order) or EXECUTION_PHASE_BY_TYPE.get(
            obj_type, 3
        )
        obj["executionPhase"] = phase
        by_phase[phase].append(obj)

    phase_order_counter: dict[int, int] = defaultdict(int)
    for phase in sorted(by_phase.keys()):
        objects = by_phase[phase]
        labels = [_object_label(o) for o in objects]
        phase_edges = {
            label: {d for d in edges.get(label, set()) if d in labels} for label in labels
        }
        sorted_labels = _topological_sort(labels, phase_edges)
        label_to_obj = {_object_label(o): o for o in objects}
        for label in sorted_labels:
            obj = label_to_obj.get(label)
            if not obj:
                continue
            phase_order_counter[phase] += 1
            obj["phaseOrder"] = phase_order_counter[phase]

    for obj in plan:
        ai = obj.get("aiAnalysis") or {}
        for cycle in ai.get("circular_dependencies", []) or []:
            if not isinstance(cycle, dict):
                continue
            strategy = str(cycle.get("strategy", "")).upper()
            if strategy in {"DEFERRABLE_CONSTRAINT", "DEFERRABLE_BOTH"}:
                obj["requiresManualReview"] = True
                note = "Self-referencing or circular FK made deferrable for PostgreSQL"
                guidance = obj.get("reviewGuidance") or ""
                obj["reviewGuidance"] = f"{guidance}; {note}".strip("; ")
            elif strategy in {"MANUAL_RESOLUTION", "FORWARD_DECLARATION"}:
                obj["requiresManualReview"] = True
                obj["confidenceScore"] = "LOW"

    for obj in plan:
        obj_type = str(obj.get("type", "")).upper()
        if obj_type in OBJECT_BATCH_ORDER:
            from app.services.oracle_pg.progress import output_file_for_type

            obj["outputFile"] = output_file_for_type(obj_type)

    save_conversion_plan(job_id, plan)

    summary = {
        "phases": {
            str(phase): len(items) for phase, items in sorted(by_phase.items())
        },
        "totalObjects": len(plan),
    }
    path = state_dir(job_id, workspace_override) / "execution_order.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    return summary
