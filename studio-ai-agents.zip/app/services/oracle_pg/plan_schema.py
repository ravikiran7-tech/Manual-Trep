"""Conversion-plan object schema helpers and default metadata seeding."""

from __future__ import annotations

from typing import Any, Optional

from app.services.oracle_pg.progress import EXECUTION_PHASE_BY_TYPE, output_file_for_type
from app.services.oracle_pg.rule_engine import resolve_confidence_score, resolve_conversion_status


def seed_plan_metadata(
    obj: dict[str, Any],
    *,
    classification: str,
    complexity: str,
    structural_metadata: Optional[dict[str, Any]] = None,
    ai_analysis: Optional[dict[str, Any]] = None,
    source_location: Optional[str] = None,
    source_code_snippet: Optional[str] = None,
) -> dict[str, Any]:
    """Build a conversion-plan entry with PRD metadata fields."""
    schema = obj.get("schema", "")
    name = obj.get("name", "")
    obj_type = obj.get("type", "TABLE")
    expected_status = resolve_conversion_status(classification, complexity)
    confidence = resolve_confidence_score(classification, complexity)

    requires_review = confidence in {"LOW", "MANUAL"} or expected_status in {
        "require_review",
        "manual_implementation",
    }

    entry: dict[str, Any] = {
        "objectId": obj.get("objectId") or f"{schema}.{name}" if schema else name,
        "type": obj_type,
        "schema": schema,
        "name": name,
        "classification": classification,
        "complexity": complexity,
        "ruleIds": list(obj.get("ruleIds", [])),
        "status": "pending",
        "outputFile": output_file_for_type(obj_type),
        "executionPhase": EXECUTION_PHASE_BY_TYPE.get(obj_type.upper(), 3),
        "phaseOrder": None,
        "conversionStatus": None,
        "expectedConversionStatus": expected_status,
        "confidenceScore": confidence,
        "requiresManualReview": requires_review,
        "reviewGuidance": "",
        "changes": [],
        "callerUpdatesNeeded": [],
        "convertedObjectName": None,
        "convertedSqlSnippet": None,
        "signatureChanged": False,
        "assessmentNotes": list(obj.get("assessmentNotes", []))[:5],
    }

    if obj.get("owningTable"):
        entry["owningTable"] = obj["owningTable"]
    if structural_metadata:
        entry["structuralMetadata"] = structural_metadata
    if ai_analysis:
        entry["aiAnalysis"] = ai_analysis
    if source_location:
        entry["sourceLocation"] = source_location
    if source_code_snippet:
        entry["sourceCodeSnippet"] = source_code_snippet
    if obj.get("incompatibilities"):
        entry["incompatibilities"] = obj["incompatibilities"]
    if obj.get("sourceSection"):
        entry["sourceSection"] = obj["sourceSection"]

    return entry


def source_object_label(obj: dict[str, Any]) -> str:
    schema = obj.get("schema", "")
    name = obj.get("name", "")
    return f"{schema}.{name}" if schema else name


def converted_object_label(obj: dict[str, Any]) -> str:
    converted = obj.get("convertedObjectName")
    if converted:
        return str(converted)
    obj_type = str(obj.get("type", "")).upper()
    if obj_type == "PACKAGE" and obj.get("decomposedFunctions"):
        funcs = ", ".join(obj["decomposedFunctions"])
        return f"Decomposed into: {funcs}"
    return source_object_label(obj)


def output_location_for_object(obj: dict[str, Any], db_name: str) -> str:
    output_file = obj.get("outputFile") or output_file_for_type(obj.get("type", "TABLE"))
    return f"{db_name}_{output_file}"
