"""Weighted progress calculation for Oracle PG transformation jobs."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.services.oracle_pg.hooks import notify_progress_update
from app.services.oracle_pg.workspace import conversion_plan_path, progress_path

PHASE_INITIALIZE = "Schema Analysis"
PHASE_ENVIRONMENT = "Context Assembly"
PHASE_MIGRATING = "AI-Guided Conversion"
PHASE_RESOLVING = "Dependency Resolution"
PHASE_ORDERING = "Execution Order Application"
PHASE_ARTIFACTS = "Generate PostgreSQL Scripts"
PHASE_COMPLETED = "Completed"
PHASE_FAILED = "Failed"

_LEGACY_PHASE_ALIASES = {
    "initializing": PHASE_INITIALIZE,
    "setting_up_environment": PHASE_ENVIRONMENT,
    "migrating_schema": PHASE_MIGRATING,
    "resolving_dependencies": PHASE_RESOLVING,
    "applying_execution_order": PHASE_ORDERING,
    "generating_artifacts": PHASE_ARTIFACTS,
    "completed": PHASE_COMPLETED,
    "failed": PHASE_FAILED,
}


def normalize_phase(phase: str) -> str:
    """Map legacy slug values to current UI-facing phase labels."""
    return _LEGACY_PHASE_ALIASES.get(phase, phase)

STATUS_QUEUED = "queued"
STATUS_IN_PROGRESS = "in_progress"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"

TERMINAL_JOB_STATUSES = frozenset({STATUS_COMPLETED, STATUS_FAILED})


def is_terminal_job_status(status: Any) -> bool:
    return str(status or "").lower() in TERMINAL_JOB_STATUSES


def is_job_terminal(job_id: str) -> bool:
    return is_terminal_job_status(load_progress(job_id).get("status"))


def is_terminal_progress_event(event: dict[str, Any]) -> bool:
    if event.get("type") != "progress_updated":
        return False
    return is_terminal_job_status(event.get("status"))


DELIVERABLE_CONVERSION_STATUSES = frozenset(
    {"auto_converted", "require_review", "manual_implementation"}
)

# PRD 14-phase script suffixes (prefixed with {dbName}_ at packaging time).
SCRIPT_ORDER = [
    "create_schemas.sql",
    "create_sequences.sql",
    "create_tables.sql",
    "create_primary_keys.sql",
    "create_unique_constraints.sql",
    "create_foreign_keys.sql",
    "create_check_constraints.sql",
    "create_indexes.sql",
    "create_views.sql",
    "create_materialized_views.sql",
    "create_functions.sql",
    "create_procedures.sql",
    "create_packages.sql",
    "create_triggers.sql",
]

PHASE_LABELS = {
    1: "CREATE SCHEMAS",
    2: "CREATE SEQUENCES",
    3: "CREATE TABLES",
    4: "CREATE PRIMARY KEYS",
    5: "CREATE UNIQUE CONSTRAINTS",
    6: "CREATE FOREIGN KEYS",
    7: "CREATE CHECK CONSTRAINTS",
    8: "CREATE INDEXES",
    9: "CREATE VIEWS",
    10: "CREATE MATERIALIZED VIEWS",
    11: "CREATE FUNCTIONS",
    12: "CREATE PROCEDURES",
    13: "CREATE PACKAGES",
    14: "CREATE TRIGGERS",
}

OBJECT_BATCH_ORDER = [
    "SCHEMA",
    "SEQUENCE",
    "TYPE",
    "TABLE",
    "DEFAULT",
    "PRIMARY_KEY",
    "UNIQUE",
    "FOREIGN_KEY",
    "CHECK",
    "INDEX",
    "VIEW",
    "MATERIALIZED_VIEW",
    "FUNCTION",
    "PROCEDURE",
    "PACKAGE",
    "TRIGGER",
]

OUTPUT_FILE_BY_TYPE = {
    "SCHEMA": "create_schemas.sql",
    "SEQUENCE": "create_sequences.sql",
    "TYPE": "create_tables.sql",
    "TABLE": "create_tables.sql",
    "DEFAULT": "create_tables.sql",
    "PRIMARY_KEY": "create_primary_keys.sql",
    "UNIQUE": "create_unique_constraints.sql",
    "FOREIGN_KEY": "create_foreign_keys.sql",
    "CHECK": "create_check_constraints.sql",
    "INDEX": "create_indexes.sql",
    "VIEW": "create_views.sql",
    "MATERIALIZED_VIEW": "create_materialized_views.sql",
    "FUNCTION": "create_functions.sql",
    "PROCEDURE": "create_procedures.sql",
    "PACKAGE": "create_packages.sql",
    "TRIGGER": "create_triggers.sql",
    # Legacy aliases
    "CONSTRAINT": "create_check_constraints.sql",
}

EXECUTION_PHASE_BY_TYPE = {
    "SCHEMA": 1,
    "SEQUENCE": 2,
    "TYPE": 3,
    "TABLE": 3,
    "DEFAULT": 3,
    "PRIMARY_KEY": 4,
    "UNIQUE": 5,
    "FOREIGN_KEY": 6,
    "CHECK": 7,
    "INDEX": 8,
    "VIEW": 9,
    "MATERIALIZED_VIEW": 10,
    "FUNCTION": 11,
    "PROCEDURE": 12,
    "PACKAGE": 13,
    "TRIGGER": 14,
    "CONSTRAINT": 7,
}

# Map legacy 11-file agent output to PRD names during normalization.
LEGACY_SCRIPT_MAP = {
    "01_schemas_and_extensions.sql": "create_schemas.sql",
    "02_sequences.sql": "create_sequences.sql",
    "03_user_defined_types.sql": "create_tables.sql",
    "04_tables.sql": "create_tables.sql",
    "05_indexes.sql": "create_indexes.sql",
    "06_constraints.sql": "create_check_constraints.sql",
    "07_views.sql": "create_views.sql",
    "08_materialized_views.sql": "create_materialized_views.sql",
    "09_functions.sql": "create_functions.sql",
    "10_procedures.sql": "create_procedures.sql",
    "11_triggers.sql": "create_triggers.sql",
}


def output_file_for_type(obj_type: str) -> str:
    return OUTPUT_FILE_BY_TYPE.get(obj_type.upper(), "create_tables.sql")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_progress(job_id: str) -> dict[str, Any]:
    return {
        "jobId": job_id,
        "phase": PHASE_INITIALIZE,
        "status": STATUS_QUEUED,
        "sessionsCompleted": 0,
        "lastCompletedBatch": None,
        "objectsTotal": 0,
        "objectsConverted": 0,
        "progressPercent": 0,
        "message": "Job queued",
        "startedAt": None,
        "updatedAt": utc_now_iso(),
        "completedAt": None,
        "notes": [],
    }


def load_progress(job_id: str) -> dict[str, Any]:
    path = progress_path(job_id)
    if not path.exists():
        return default_progress(job_id)
    with path.open(encoding="utf-8") as fh:
        progress = json.load(fh)
    phase = progress.get("phase")
    if phase:
        progress["phase"] = normalize_phase(phase)
    return progress


def save_progress(job_id: str, progress: dict[str, Any]) -> None:
    progress["updatedAt"] = utc_now_iso()
    path = progress_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(progress, fh, indent=2)
    notify_progress_update(job_id, progress)


def load_conversion_plan(job_id: str) -> list[dict[str, Any]]:
    path = conversion_plan_path(job_id)
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict) and "objects" in data:
        return data["objects"]
    if isinstance(data, list):
        return data
    return []


def save_conversion_plan(job_id: str, plan: list[dict[str, Any]]) -> None:
    path = conversion_plan_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump({"objects": plan}, fh, indent=2)


def count_plan_stats(plan: list[dict[str, Any]]) -> tuple[int, int]:
    total = len(plan)
    converted = sum(1 for obj in plan if obj.get("status") != "pending")
    return total, converted


def compute_progress_percent(
    phase: str,
    objects_total: int,
    objects_converted: int,
    *,
    artifacts_done: bool = False,
) -> int:
    phase = normalize_phase(phase)
    if phase == PHASE_FAILED:
        return load_progress_percent_fallback(objects_total, objects_converted)

    if phase == PHASE_COMPLETED or artifacts_done:
        return 100

    if phase == PHASE_INITIALIZE:
        return 5

    if phase == PHASE_ENVIRONMENT:
        return 10

    if phase in (PHASE_RESOLVING, PHASE_ORDERING):
        return 82

    if phase == PHASE_ARTIFACTS:
        return 90

    if phase == PHASE_MIGRATING:
        if objects_total <= 0:
            return 20
        migration_fraction = objects_converted / objects_total
        return 20 + int(migration_fraction * 60)

    return 0


def load_progress_percent_fallback(objects_total: int, objects_converted: int) -> int:
    if objects_total <= 0:
        return 0
    return min(99, 20 + int((objects_converted / objects_total) * 60))


def update_progress_from_plan(job_id: str, phase: Optional[str] = None) -> dict[str, Any]:
    progress = load_progress(job_id)
    plan = load_conversion_plan(job_id)
    total, converted = count_plan_stats(plan)

    progress["objectsTotal"] = total
    progress["objectsConverted"] = converted
    if phase:
        progress["phase"] = phase
    if not progress.get("startedAt") and progress.get("status") == STATUS_IN_PROGRESS:
        progress["startedAt"] = utc_now_iso()

    progress["progressPercent"] = compute_progress_percent(
        progress.get("phase", PHASE_MIGRATING),
        total,
        converted,
        artifacts_done=progress.get("phase") == PHASE_COMPLETED,
    )
    save_progress(job_id, progress)
    return progress


def is_deliverable_conversion_status(status: Optional[str]) -> bool:
    return str(status or "").lower() in DELIVERABLE_CONVERSION_STATUSES


def finalize_plan_conversion_status(plan: list[dict[str, Any]]) -> int:
    """Backfill conversionStatus on converted objects; return count updated."""
    updated = 0
    for obj in plan:
        if obj.get("status") != "converted":
            continue
        if obj.get("conversionStatus"):
            continue
        obj["conversionStatus"] = obj.get("expectedConversionStatus", "require_review")
        confidence = str(obj.get("confidenceScore", "")).upper()
        if confidence in {"LOW", "MANUAL"} or obj["conversionStatus"] in {
            "require_review",
            "manual_implementation",
        }:
            obj["requiresManualReview"] = True
        updated += 1
    return updated


def count_deliverable_conversions(plan: list[dict[str, Any]]) -> int:
    return sum(
        1
        for obj in plan
        if obj.get("status") == "converted"
        and is_deliverable_conversion_status(obj.get("conversionStatus"))
    )


def next_pending_batch(plan: list[dict[str, Any]]) -> Optional[str]:
    pending_types = {
        obj.get("type", "").upper()
        for obj in plan
        if obj.get("status") == "pending"
    }
    for batch_type in OBJECT_BATCH_ORDER:
        if batch_type in pending_types:
            return batch_type
    return None
