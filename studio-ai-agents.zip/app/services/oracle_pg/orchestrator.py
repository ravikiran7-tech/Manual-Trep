"""Orchestrator for multi-session Oracle → PostgreSQL transformation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from app.core.config import get_settings
from app.services.oracle_pg.agent_runner import run_agent_session
from app.services.oracle_pg.artifact_packager import list_artifacts, package_all_artifacts
from app.services.oracle_pg.dependency_resolver import resolve_dependencies
from app.services.oracle_pg.execution_order import apply_execution_order
from app.services.oracle_pg.input_adapter import (
    build_plan_from_compass_files,
    write_normalized_assessment,
    write_remediation_index,
    write_skipped_objects,
)
from app.services.oracle_pg.plan_schema import seed_plan_metadata
from app.services.oracle_pg.progress import (
    PHASE_ARTIFACTS,
    PHASE_COMPLETED,
    PHASE_ENVIRONMENT,
    PHASE_FAILED,
    PHASE_INITIALIZE,
    PHASE_MIGRATING,
    PHASE_ORDERING,
    PHASE_RESOLVING,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_IN_PROGRESS,
    finalize_plan_conversion_status,
    load_conversion_plan,
    load_progress,
    next_pending_batch,
    output_file_for_type,
    save_conversion_plan,
    save_progress,
    update_progress_from_plan,
    utc_now_iso,
)
from app.services.oracle_pg.workspace import (
    conversion_plan_path,
    discover_workspace_override,
    ensure_job_dirs,
    input_dir,
    input_path,
    job_config_path,
    read_json_file_at,
    state_dir,
    write_json_file_at,
    workspace_override_from_config,
)

logger = logging.getLogger(__name__)
settings = get_settings()

MAX_CONVERTER_SESSIONS = 20


class TransformationOrchestrator:
    """Runs initializer → environment → converter → dependency → order → artifacts."""

    def __init__(self, job_manager: Any):
        self._job_manager = job_manager

    async def run(self, job_id: str) -> None:
        workspace_override = discover_workspace_override(job_id)
        config = self._load_job_config(job_id, workspace_override)
        if not config:
            logger.error("Missing job config for %s", job_id)
            return

        workspace_override = workspace_override_from_config(config) or workspace_override
        root = ensure_job_dirs(job_id, workspace_override)

        try:
            await self._phase_initialize(job_id, root, config, workspace_override)
            await self._phase_environment(job_id, config, workspace_override)
            await self._phase_migrate(job_id, root, config, workspace_override)
            await self._phase_resolve_dependencies(job_id, workspace_override)
            await self._phase_apply_execution_order(job_id, workspace_override)
            await self._phase_artifacts(job_id, root, config, workspace_override)
        except Exception as exc:
            logger.exception("Transformation failed for job %s", job_id)
            self._mark_failed(job_id, str(exc))
        finally:
            self._job_manager.clear_running(job_id)

    def _load_job_config(
        self,
        job_id: str,
        workspace_override: Optional[str] = None,
    ) -> dict[str, Any]:
        return (
            read_json_file_at(
                job_id,
                job_config_path(job_id, workspace_override),
                workspace_override,
            )
            or {}
        )

    def _mark_failed(self, job_id: str, message: str) -> None:
        progress = load_progress(job_id)
        progress["status"] = STATUS_FAILED
        progress["phase"] = PHASE_FAILED
        progress["message"] = "Transformation encountered an issue. Please contact support."
        progress["errorDetail"] = message
        save_progress(job_id, progress)

    def _build_plan_from_compass(self, job_id: str, config: dict[str, Any]) -> list[dict[str, Any]]:
        asis_path = input_path(job_id, "asisSchema", config)
        incompat_path = input_path(job_id, "incompatibilityResults", config)
        remediation_path = input_path(job_id, "rulesRemediation", config)
        ddl_path = input_path(job_id, "ddlExport", config)

        schema_analysis_path = None
        input_paths = config.get("inputPaths", {})
        if input_paths.get("schemaAnalysis"):
            schema_analysis_path = input_path(job_id, "schemaAnalysis", config)

        plan, catalog_subset, skipped, warnings = build_plan_from_compass_files(
            asis_path,
            incompat_path,
            remediation_path,
            ddl_path=ddl_path,
            schema_analysis_path=schema_analysis_path,
            rule_scope=str(config.get("ruleScope", "all")),
            selected_rules=list(config.get("selectedRules") or []),
        )

        workspace_override = workspace_override_from_config(config)
        plan_path = conversion_plan_path(job_id, workspace_override)
        write_json_file_at(
            job_id,
            plan_path,
            {"objects": plan, "assemblyWarnings": warnings},
            workspace_override,
        )

        write_normalized_assessment(job_id, plan, workspace_override)
        write_remediation_index(job_id, catalog_subset, workspace_override)
        if skipped:
            write_skipped_objects(job_id, skipped, workspace_override)
            logger.warning("Job %s has %d objects missing DDL", job_id, len(skipped))

        logger.info("Built conversion plan with %d objects for job %s", len(plan), job_id)
        return plan
    async def _phase_initialize(
        self,
        job_id: str,
        root: Path,
        config: dict[str, Any],
        workspace_override: Optional[str],
    ) -> None:
        progress = load_progress(job_id)
        progress["status"] = STATUS_IN_PROGRESS
        progress["phase"] = PHASE_INITIALIZE
        progress["message"] = "Schema Analysis..."
        progress["progressPercent"] = 5
        if not progress.get("startedAt"):
            progress["startedAt"] = utc_now_iso()
        save_progress(job_id, progress)

        if conversion_plan_exists(job_id, workspace_override) and load_conversion_plan(job_id):
            logger.info("Job %s already has conversion plan; skipping initializer", job_id)
            update_progress_from_plan(job_id, PHASE_INITIALIZE)
            return

        input_mode = config.get("inputMode")
        if input_mode == settings.oracle_pg_agent.input_mode_compass:
            plan = self._build_plan_from_compass(job_id, config)
            if plan:
                update_progress_from_plan(job_id, PHASE_INITIALIZE)
                return

        result = await run_agent_session(job_id, root, config, "initializer")
        if not result.success:
            raise RuntimeError(result.error_message or "Initializer session failed")

        if not load_conversion_plan(job_id):
            self._bootstrap_plan_from_assessment(job_id, config, workspace_override)

        update_progress_from_plan(job_id, PHASE_INITIALIZE)

    async def _phase_environment(
        self,
        job_id: str,
        config: dict[str, Any],
        workspace_override: Optional[str],
    ) -> None:
        progress = load_progress(job_id)
        progress["phase"] = PHASE_ENVIRONMENT
        progress["message"] = "Context Assembly..."
        progress["progressPercent"] = 10
        save_progress(job_id, progress)

        pg_context = {
            "sourceDatabaseVersion": config.get("sourceDatabaseVersion"),
            "targetDatabaseVersion": config.get("targetDatabaseVersion"),
            "dbName": config.get("dbName"),
            "selectedRules": config.get("selectedRules", []),
            "ruleScope": config.get("ruleScope", "all"),
            "aiAgent": config.get("aiAgent"),
            "inputPaths": config.get("inputPaths", {}),
        }
        ctx_path = state_dir(job_id, workspace_override) / "pg_version_context.json"
        write_json_file_at(job_id, ctx_path, pg_context, workspace_override)

    async def _phase_migrate(
        self,
        job_id: str,
        root: Path,
        config: dict[str, Any],
        workspace_override: Optional[str],
    ) -> None:
        sessions = 0
        while sessions < MAX_CONVERTER_SESSIONS:
            plan = load_conversion_plan(job_id)
            batch = next_pending_batch(plan)
            if not batch:
                break

            progress = load_progress(job_id)
            progress["phase"] = PHASE_MIGRATING
            progress["message"] = f"AI-Guided Conversion — batch {batch}"
            save_progress(job_id, progress)

            result = await run_agent_session(
                job_id, root, config, "converter", batch_type=batch
            )
            sessions += 1
            progress = load_progress(job_id)
            progress["sessionsCompleted"] = progress.get("sessionsCompleted", 0) + 1
            progress["lastCompletedBatch"] = batch
            save_progress(job_id, progress)
            update_progress_from_plan(job_id, PHASE_MIGRATING)

            if not result.success:
                raise RuntimeError(result.error_message or f"Converter session failed for {batch}")

            plan = load_conversion_plan(job_id)
            if next_pending_batch(plan) == batch:
                self._mark_batch_converted(job_id, batch, workspace_override)

        plan = load_conversion_plan(job_id)
        finalize_plan_conversion_status(plan)
        save_conversion_plan(job_id, plan)
        update_progress_from_plan(job_id, PHASE_MIGRATING)

    async def _phase_resolve_dependencies(
        self,
        job_id: str,
        workspace_override: Optional[str],
    ) -> None:
        progress = load_progress(job_id)
        progress["phase"] = PHASE_RESOLVING
        progress["message"] = "Dependency Resolution..."
        save_progress(job_id, progress)
        resolve_dependencies(job_id, workspace_override)
        update_progress_from_plan(job_id, PHASE_RESOLVING)

    async def _phase_apply_execution_order(
        self,
        job_id: str,
        workspace_override: Optional[str],
    ) -> None:
        progress = load_progress(job_id)
        progress["phase"] = PHASE_ORDERING
        progress["message"] = "Execution Order Application..."
        save_progress(job_id, progress)
        apply_execution_order(job_id, workspace_override)
        update_progress_from_plan(job_id, PHASE_ORDERING)

    def _mark_batch_converted(
        self,
        job_id: str,
        batch_type: str,
        workspace_override: Optional[str] = None,
    ) -> None:
        """Fallback when agent did not update plan statuses."""
        path = conversion_plan_path(job_id, workspace_override)
        data = read_json_file_at(job_id, path, workspace_override)
        if data is None:
            return
        objects = data["objects"] if isinstance(data, dict) else data
        changed = False
        for obj in objects:
            if obj.get("type", "").upper() == batch_type and obj.get("status") == "pending":
                obj["status"] = "converted"
                expected = obj.get("expectedConversionStatus", "require_review")
                obj.setdefault("conversionStatus", expected)
                obj.setdefault(
                    "confidenceScore",
                    obj.get("confidenceScore") or "MEDIUM",
                )
                if expected in {"require_review", "manual_implementation"} or obj.get(
                    "confidenceScore"
                ) in {"LOW", "MANUAL"}:
                    obj["requiresManualReview"] = True
                else:
                    obj.setdefault("requiresManualReview", False)
                changed = True
        if changed:
            payload = {"objects": objects}
            if isinstance(data, dict):
                payload = {**data, "objects": objects}
            write_json_file_at(job_id, path, payload, workspace_override)

    async def _phase_artifacts(
        self,
        job_id: str,
        root: Path,
        config: dict[str, Any],
        workspace_override: Optional[str],
    ) -> None:
        progress = load_progress(job_id)
        progress["phase"] = PHASE_ARTIFACTS
        progress["message"] = "Generate PostgreSQL Scripts..."
        progress["progressPercent"] = 90
        save_progress(job_id, progress)

        result = await run_agent_session(job_id, root, config, "artifact")
        db_name = config.get("dbName", "database")

        plan = load_conversion_plan(job_id)
        finalize_plan_conversion_status(plan)
        save_conversion_plan(job_id, plan)

        # completedAt must be set before packaging so post_transformation_report.json
        # and transformation_summary.json include duration (build_timing_block needs both timestamps).
        progress = load_progress(job_id)
        progress["completedAt"] = utc_now_iso()
        save_progress(job_id, progress)

        package_all_artifacts(job_id, db_name, config, workspace_override)

        if not result.success:
            logger.warning(
                "Artifact agent session reported issues for %s: %s",
                job_id,
                result.error_message,
            )

        progress = load_progress(job_id)
        progress["status"] = STATUS_COMPLETED
        progress["phase"] = PHASE_COMPLETED
        progress["message"] = "DB Modernization Completed"
        progress["progressPercent"] = 100
        progress["artifacts"] = list_artifacts(job_id, db_name, workspace_override)
        save_progress(job_id, progress)

    def _bootstrap_plan_from_assessment(
        self,
        job_id: str,
        config: dict[str, Any],
        workspace_override: Optional[str] = None,
    ) -> None:
        """Build a minimal conversion plan from assessment when initializer output is empty."""
        assessment_path = input_dir(job_id, workspace_override) / "assessment.json"
        assessment = read_json_file_at(job_id, assessment_path, workspace_override)
        if assessment is None:
            return

        objects_raw = assessment.get("objects", assessment) if isinstance(assessment, dict) else assessment
        if not isinstance(objects_raw, list):
            return

        objects = []
        for idx, item in enumerate(objects_raw, start=1):
            obj_type = str(item.get("type", "TABLE")).upper()
            classification = item.get("classification", "SC")
            complexity = item.get("complexity", "medium")
            base = {
                "objectId": item.get("objectId") or f"OBJ_{idx:04d}",
                "type": obj_type,
                "schema": item.get("schema", ""),
                "name": item.get("name", ""),
                "ruleIds": list(item.get("ruleIds", [])),
                "incompatibilities": item.get("incompatibilities", []),
            }
            entry = seed_plan_metadata(base, classification=classification, complexity=complexity)
            entry["outputFile"] = output_file_for_type(obj_type)
            objects.append(entry)

        path = conversion_plan_path(job_id, workspace_override)
        write_json_file_at(job_id, path, {"objects": objects}, workspace_override)


def conversion_plan_exists(job_id: str, workspace_override: Optional[str] = None) -> bool:
    return conversion_plan_path(job_id, workspace_override).exists()
