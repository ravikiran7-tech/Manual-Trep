"""Claude Agent SDK runner for Oracle PG transformation sessions."""
from __future__ import annotations

import asyncio
import logging
import os
import queue
import signal
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Optional

from app.core.config import get_settings
from app.services.oracle_pg.hooks import append_log_entry, append_sdk_message, make_progress_hooks
from app.services.oracle_pg.live_logs import format_session_start
from app.services.oracle_pg.prompts import artifact_prompt, converter_prompt, initializer_prompt

logger = logging.getLogger(__name__)
settings = get_settings()

_QUERY_DONE = object()
_INITIALIZE_TIMEOUT_MARKER = "Control request timeout: initialize"
_BUNDLED_CLAUDE_MARKER = "claude_agent_sdk/_bundled/claude"
_INITIALIZE_RETRY_SLEEP_SECONDS = 2


def _needs_windows_subprocess_workaround() -> bool:
    """Uvicorn --reload on Windows uses SelectorEventLoop, which cannot spawn subprocesses."""
    if sys.platform != "win32":
        return False
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False
    return not isinstance(loop, asyncio.ProactorEventLoop)


async def _iter_sdk_messages(prompt: str, options: Any) -> AsyncIterator[Any]:
    """Yield SDK messages, using a Proactor loop thread on Windows when required."""
    from claude_agent_sdk import query

    if not _needs_windows_subprocess_workaround():
        async for message in query(prompt=prompt, options=options):
            yield message
        return

    message_queue: queue.Queue[Any] = queue.Queue()
    error_holder: list[BaseException] = []

    def _worker() -> None:
        loop = asyncio.ProactorEventLoop()
        asyncio.set_event_loop(loop)

        async def _run() -> None:
            try:
                async for message in query(prompt=prompt, options=options):
                    message_queue.put(message)
            except BaseException as exc:
                error_holder.append(exc)
            finally:
                message_queue.put(_QUERY_DONE)

        try:
            loop.run_until_complete(_run())
        finally:
            loop.close()

    thread = threading.Thread(target=_worker, name="claude-agent-sdk", daemon=True)
    thread.start()

    while True:
        message = await asyncio.to_thread(message_queue.get)
        if message is _QUERY_DONE:
            break
        yield message

    thread.join(timeout=1)
    if error_holder:
        raise error_holder[0]


def _is_initialize_timeout(exc: BaseException | str) -> bool:
    """True when the SDK failed the control-protocol initialize handshake."""
    return _INITIALIZE_TIMEOUT_MARKER in str(exc)


def _apply_stream_close_timeout_env() -> str:
    """Copy the configured timeout into process env so SDK query() honors it."""
    value = str(settings.oracle_pg_agent.stream_close_timeout_ms)
    os.environ["CLAUDE_CODE_STREAM_CLOSE_TIMEOUT"] = value
    return value


def _cli_stderr_logger(job_id: str) -> Callable[[str], None]:
    def _on_stderr(line: str) -> None:
        text = line.rstrip()
        if text:
            logger.warning("CLI stderr job=%s %s", job_id, text)

    return _on_stderr


def _read_proc_cmdline(proc_root: Path, pid: int) -> str:
    path = proc_root / str(pid) / "cmdline"
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    return data.replace(b"\x00", b" ").decode("utf-8", errors="replace")


def _read_proc_cwd(proc_root: Path, pid: int) -> str:
    cwd_path = proc_root / str(pid) / "cwd"
    try:
        return os.readlink(cwd_path)
    except (OSError, ValueError):
        pass
    try:
        if cwd_path.is_file():
            return cwd_path.read_text(encoding="utf-8").strip()
    except OSError:
        pass
    return ""


def _cwd_is_job_workspace(proc_cwd: str, job_workspace: Path) -> bool:
    if not proc_cwd:
        return False
    try:
        return Path(proc_cwd).resolve() == job_workspace.resolve()
    except OSError:
        return os.path.normcase(os.path.normpath(proc_cwd)) == os.path.normcase(
            os.path.normpath(str(job_workspace))
        )


def _iter_proc_pids(proc_root: Path) -> list[int]:
    try:
        entries = list(proc_root.iterdir())
    except OSError:
        return []
    pids: list[int] = []
    for entry in entries:
        if entry.name.isdigit():
            pids.append(int(entry.name))
    return pids


def _pid_exists(proc_root: Path, pid: int) -> bool:
    return (proc_root / str(pid)).exists()


def _signal_pid(pid: int, sig: int) -> bool:
    try:
        os.kill(pid, sig)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        logger.warning("Failed to signal leftover Claude CLI pid=%s sig=%s", pid, sig, exc_info=True)
        return False


def _find_job_claude_pids(job_workspace: Path, proc_root: Path) -> list[int]:
    """Bundled CLIs whose cwd is this job workspace (not other parallel jobs)."""
    self_pid = os.getpid()
    matched: list[int] = []
    for pid in _iter_proc_pids(proc_root):
        if pid in (1, self_pid):
            continue
        cmdline = _read_proc_cmdline(proc_root, pid).replace("\\", "/")
        if _BUNDLED_CLAUDE_MARKER not in cmdline:
            continue
        if not _cwd_is_job_workspace(_read_proc_cwd(proc_root, pid), job_workspace):
            continue
        matched.append(pid)
    return matched


def _kill_orphaned_claude_clis(
    job_workspace: Path,
    *,
    proc_root: Optional[Path] = None,
    kill_fn: Optional[Callable[[int], None]] = None,
    wait_seconds: float = 0.5,
) -> list[int]:
    """Kill leftover bundled Claude CLIs for this job workspace only.

    Matches on process cwd so a parallel job on the same uvicorn worker is not killed.
    Also catches leftovers reparented to PID 1. SIGTERM first; SIGKILL if still alive.
    """
    if proc_root is None:
        if sys.platform == "win32":
            return []
        proc_root = Path("/proc")

    targets = _find_job_claude_pids(job_workspace, proc_root)
    if not targets:
        return []

    killed: list[int] = []
    for pid in targets:
        try:
            if kill_fn is not None:
                kill_fn(pid)
                sent = True
            else:
                sent = _signal_pid(pid, signal.SIGTERM)
        except OSError:
            logger.warning("Failed to kill leftover Claude CLI pid=%s", pid, exc_info=True)
            continue
        if not sent:
            continue
        killed.append(pid)
        logger.warning(
            "Killed leftover Claude CLI pid=%s job_cwd=%s",
            pid,
            job_workspace,
        )

    if kill_fn is not None or wait_seconds <= 0 or not killed:
        return killed

    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        if not any(_pid_exists(proc_root, pid) for pid in killed):
            return killed
        time.sleep(0.05)
    for pid in killed:
        if _pid_exists(proc_root, pid):
            _signal_pid(pid, signal.SIGKILL)
            logger.warning("SIGKILL leftover Claude CLI pid=%s job_cwd=%s", pid, job_workspace)
    return killed


@dataclass
class SessionResult:
    success: bool
    session_id: Optional[str] = None
    subtype: Optional[str] = None
    result_text: Optional[str] = None
    total_cost_usd: Optional[float] = None
    error_message: Optional[str] = None


def _build_agent_definitions() -> dict[str, Any]:
    try:
        from claude_agent_sdk import AgentDefinition
    except ImportError:
        return {}

    return {
        "initializer": AgentDefinition(
            description="Parse Oracle DDL and build conversion plan",
            prompt="Parse DDL and assessment data; write conversion-plan.json only.",
            tools=["Read", "Write", "Edit", "Glob", "Grep"],
            permissionMode="acceptEdits",
        ),
        "converter": AgentDefinition(
            description="Convert one object-type batch to PostgreSQL DDL",
            prompt=(
                "Convert ONLY pending objects matching the assigned batch type. "
                "Write SQL only to that batch's output script. Do not convert other types."
            ),
            tools=["Read", "Write", "Edit", "Glob", "Grep"],
            permissionMode="acceptEdits",
        ),
        "artifact": AgentDefinition(
            description="Assemble final SQL scripts and transformation report",
            prompt="Assemble README, report, and ordered SQL deliverables.",
            tools=["Read", "Write", "Edit", "Glob", "Grep"],
            permissionMode="acceptEdits",
        ),
    }


def _resolve_model_id(job_config: dict[str, Any]) -> str:
    """Map launch aiAgent to Claude Agent SDK model identifier."""
    agent = str(job_config.get("aiAgent", "")).lower()
    if "haiku" in agent:
        return "haiku"
    if "opus" in agent:
        return "opus"
    if settings.oracle_pg_agent.sonnet_model_id:
        return "sonnet"
    return "sonnet"


def _build_options(job_workspace: Path, job_id: str, job_config: dict[str, Any]) -> Any:
    from claude_agent_sdk import ClaudeAgentOptions

    _apply_stream_close_timeout_env()
    opts = ClaudeAgentOptions(
        cwd=str(job_workspace),
        model=_resolve_model_id(job_config),
        permission_mode="acceptEdits",
        setting_sources=[],
        allowed_tools=["Read", "Write", "Edit", "Glob", "Grep"],
        max_turns=settings.oracle_pg_agent.max_turns_per_session,
        max_budget_usd=settings.oracle_pg_agent.max_budget_usd_per_session,
        max_buffer_size=settings.oracle_pg_agent.max_buffer_size_bytes,
        env=settings.oracle_pg_agent.bedrock_env(settings.bedrock.region),
        hooks=make_progress_hooks(job_id),
        agents=_build_agent_definitions(),
        stderr=_cli_stderr_logger(job_id),
    )

    if settings.oracle_pg_agent.cli_path:
        opts.cli_path = settings.oracle_pg_agent.cli_path

    return opts


async def run_agent_session(
    job_id: str,
    job_workspace: Path,
    job_config: dict[str, Any],
    session_kind: str,
    *,
    batch_type: Optional[str] = None,
    resume_session_id: Optional[str] = None,
) -> SessionResult:
    """
    Run one Claude Agent SDK query() session.

    session_kind: initializer | converter | artifact
    """
    try:
        from claude_agent_sdk.types import ResultMessage
    except ImportError as exc:
        return SessionResult(
            success=False,
            error_message=f"claude-agent-sdk not installed: {exc}",
        )

    if session_kind == "initializer":
        prompt = initializer_prompt(job_config)
    elif session_kind == "converter":
        if not batch_type:
            return SessionResult(success=False, error_message="batch_type required for converter")
        prompt = converter_prompt(job_config, batch_type)
    elif session_kind == "artifact":
        prompt = artifact_prompt(job_config)
    else:
        return SessionResult(success=False, error_message=f"Unknown session kind: {session_kind}")

    options = _build_options(job_workspace, job_id, job_config)
    if resume_session_id:
        options.resume = resume_session_id

    session_result = SessionResult(success=False)

    async def _drain_messages() -> None:
        async for message in _iter_sdk_messages(prompt, options):
            await append_sdk_message(job_id, message)
            if isinstance(message, ResultMessage):
                session_result.session_id = message.session_id
                session_result.subtype = message.subtype
                session_result.result_text = message.result
                session_result.total_cost_usd = message.total_cost_usd
                session_result.success = message.subtype == "success"
                if not session_result.success:
                    session_result.error_message = message.result or message.subtype

    try:
        await append_log_entry(
            job_id,
            format_session_start(job_id, session_kind, batch_type=batch_type),
        )
        try:
            await _drain_messages()
        except Exception as exc:
            if not _is_initialize_timeout(exc):
                raise
            logger.warning(
                "CLI initialize timeout for job %s (%s); killing leftover job CLI and retrying once",
                job_id,
                session_kind,
            )
            _kill_orphaned_claude_clis(job_workspace)
            await asyncio.sleep(_INITIALIZE_RETRY_SLEEP_SECONDS)
            try:
                await _drain_messages()
            except Exception:
                logger.exception(
                    "Agent session retry failed for job %s (%s)", job_id, session_kind
                )
                session_result.error_message = str(exc)
                return session_result
    except Exception as exc:
        logger.exception("Agent session failed for job %s (%s)", job_id, session_kind)
        session_result.error_message = str(exc)
    finally:
        _kill_orphaned_claude_clis(job_workspace)

    return session_result


async def stream_agent_session(
    job_id: str,
    job_workspace: Path,
    job_config: dict[str, Any],
    session_kind: str,
    *,
    batch_type: Optional[str] = None,
) -> AsyncIterator[Any]:
    """Yield raw SDK messages (for testing/integration)."""
    if session_kind == "initializer":
        prompt = initializer_prompt(job_config)
    elif session_kind == "converter":
        prompt = converter_prompt(job_config, batch_type or "TABLE")
    else:
        prompt = artifact_prompt(job_config)

    options = _build_options(job_workspace, job_id, job_config)
    async for message in _iter_sdk_messages(prompt, options):
        await append_sdk_message(job_id, message)
        yield message
