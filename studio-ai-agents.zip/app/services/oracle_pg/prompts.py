"""Prompt templates for Oracle PG transformation agent sessions."""

from __future__ import annotations

from typing import Any

from app.services.oracle_pg.progress import PHASE_INITIALIZE, SCRIPT_ORDER, output_file_for_type


def _format_input_files(job_config: dict[str, Any]) -> str:
    input_paths = job_config.get("inputPaths")
    if input_paths:
        lines = [f"- {key}: {path}" for key, path in input_paths.items()]
        return (
            "Read:\n"
            + "\n".join(lines)
            + "\n- state/remediation-index.json (rules referenced by this job)"
            + "\n- job_config.json (frozen launch configuration)"
        )
    return (
        "Read:\n"
        "- input/oracle_ddl_export.sql (Oracle DDL export)\n"
        "- input/assessment.json (DS/SC/NS classifications from Compass)\n"
        "- job_config.json (frozen launch configuration)"
    )


def _expected_script_names(db_name: str) -> str:
    names = ", ".join(f"{db_name}_{suffix}" for suffix in SCRIPT_ORDER)
    return f"{names} (plus {db_name}_00_README.txt)"


_PLAN_METADATA_FIELDS = """
   confidenceScore (HIGH/MEDIUM/LOW/MANUAL), requiresManualReview (bool),
   reviewGuidance, changes[] (changeType, description, requiresReview),
   callerUpdatesNeeded[], convertedObjectName, convertedSqlSnippet (short excerpt),
   signatureChanged (bool), decomposedFunctions (packages only)
"""


def initializer_prompt(job_config: dict[str, Any]) -> str:
    input_mode = job_config.get("inputMode", "inline_assessment")
    if input_mode == "compass_files":
        return f"""You are the initializer agent for Oracle to PostgreSQL schema conversion job {job_config.get("jobId")}.

The conversion plan was pre-built from Compass assessment files at launch.

Verify state/conversion-plan.json exists and matches the AS-IS catalog.

If the plan is empty or corrupt, rebuild it from the input files below.

{_format_input_files(job_config)}

Tasks (setup only — do NOT convert objects yet):

1. Validate conversion-plan.json object list against AS-IS schema JSON.
2. Ensure each entry has objectId, type, schema, name, classification, complexity, ruleIds,
   incompatibilities (with nested remediation), status ("pending"), outputFile, conversionStatus (null),
   and metadata fields:{_PLAN_METADATA_FIELDS}
3. Ensure progress.json exists under state/ with phase "{PHASE_INITIALIZE}" if missing.

Transformation guidance comes ONLY from each object's incompatibilities[].remediation in conversion-plan.json.
Do not use legacy rule catalogs or selectedRules.

Do not use git. Do not start conversion yet.
"""

    return f"""You are the initializer agent for Oracle to PostgreSQL schema conversion job {job_config.get("jobId")}.

{_format_input_files(job_config)}

Tasks (setup only — do NOT convert objects yet):

1. Parse ALL Oracle objects from the DDL export.
2. Merge assessment classifications (DS/SC/NS) and complexity per object.
3. Write state/conversion-plan.json as {{"objects": [...]}} with metadata fields:{_PLAN_METADATA_FIELDS}
4. Ensure progress.json exists under state/ with phase "{PHASE_INITIALIZE}" if missing.

Apply remediations from rulesRemediation when building incompatibilities on each object.

Do not use git. Do not start conversion yet.
"""


def converter_prompt(job_config: dict[str, Any], batch_type: str) -> str:
    db_name = job_config.get("dbName", "database")
    ddl_hint = job_config.get("inputPaths", {}).get("ddlExport", "input/oracle_ddl_export.sql")
    batch_output = output_file_for_type(batch_type)
    batch_script = f"{db_name}_{batch_output}"
    return f"""You are the converter agent for job {job_config.get("jobId")}.

THIS SESSION ASSIGNED BATCH: {batch_type}
Output script for this batch ONLY: {batch_script}

BATCH SCOPE (mandatory — do not skip):
- Convert ONLY objects where type is "{batch_type}" AND status is "pending".
- Do NOT convert, mark converted, or write SQL for any other object type in this session.
- Other batches (SEQUENCE, TABLE, PROCEDURE, etc.) run in separate later sessions — leave them pending.
- You may read the full Oracle DDL and conversion plan for context, but emit DDL only for this batch.
- Write or append SQL ONLY to output/{batch_script}. Do NOT create or modify any other output/*.sql file.
- Do NOT write {db_name}_00_README.txt, reports, CSV, or zip deliverables (artifact session handles those).
- Do NOT write or edit state/progress.json — the orchestrator updates job progress after each batch.

FIRST — get your bearings every session:

1. Read state/conversion-plan.json (filter to pending {batch_type} objects for this session's work)
2. Read state/remediation-index.json and job_config.json
3. Read Oracle DDL from: {ddl_hint}
4. If state/skipped_objects.json exists, use structuralMetadata and incompatibilities only for
   skipped objects whose type is {batch_type}

THEN — convert ALL pending {batch_type} objects (every matching object must produce PostgreSQL DDL):

- Target PostgreSQL version: {job_config.get("targetDatabaseVersion")}

REMEDIATION-GUIDED TRANSFORMATION (mandatory):

For each pending {batch_type} object, read its incompatibilities array in state/conversion-plan.json.
Apply each entry's remediation.description and remediation.detailedDescription to the
specific affectedElement. Do NOT use legacy rule catalogs or selectedRules.

Objects with an EMPTY incompatibilities array:
- Emit standard PostgreSQL DDL using structuralMetadata and Oracle source DDL/snippets.
- Use conventional Oracle→PostgreSQL mappings (VARCHAR2→VARCHAR, NUMBER→NUMERIC/INTEGER, etc.).
- Set conversionStatus "require_review" and requiresManualReview true unless classification is DS.

EVERY object in this batch must receive executable or stub PostgreSQL DDL — never skip with comment-only output.

Outcome tagging (for each converted {batch_type} object — set status "converted" AND conversionStatus):
- DS or SC-low → conversionStatus "auto_converted", confidenceScore "HIGH"
- SC-medium/high → full PostgreSQL DDL + /* REVIEW: ... */ comments, conversionStatus "require_review",
  confidenceScore "MEDIUM" or "LOW", requiresManualReview true, reviewGuidance explaining what to validate
- NS → best-effort PostgreSQL DDL (stub functions, extension prereqs, placeholder types/columns) PLUS
  /* MANUAL: ... */ comments with remediation steps, conversionStatus "manual_implementation",
  confidenceScore "MANUAL", requiresManualReview true

Batch-specific rules for {batch_type}:
- TABLE: structure-only CREATE TABLE (no PK/UK/FK/CHECK/DEFAULT — use separate script files)
- DEFAULT: ALTER TABLE ... ALTER COLUMN ... SET DEFAULT ... using structuralMetadata.constraintDetails
  and remediation mappings (SYSDATE→CURRENT_TIMESTAMP, seq.NEXTVAL→nextval('seq'), etc.)
- PRIMARY_KEY/UNIQUE/FOREIGN_KEY/CHECK: ALTER TABLE statements only
- PACKAGE: decompose into functions in create_packages.sql; set decomposedFunctions and callerUpdatesNeeded

- Do not mention phases, phase numbers, or execution order in SQL comments or script headers.

AFTER this batch, update ONLY the {batch_type} objects you converted in state/conversion-plan.json with:{_PLAN_METADATA_FIELDS}
Leave all other object types unchanged (still "pending" until their batch session runs).

Do not use git.
"""


def artifact_prompt(job_config: dict[str, Any]) -> str:
    db_name = job_config.get("dbName", "database")
    schema_analysis = job_config.get("inputPaths", {}).get("schemaAnalysis")
    schema_hint = (
        f"\n5. Enrich README using schema analysis: {schema_analysis}"
        if schema_analysis
        else ""
    )
    return f"""You are the artifact agent for job {job_config.get("jobId")}.

All schema objects should be converted. Assemble final deliverables:

1. Read state/conversion-plan.json for final per-object status.
2. Ensure ordered SQL scripts exist under output/ with naming:
   {_expected_script_names(db_name)}
3. Deterministic packaging will generate post_transformation_report.json, transformation_summary.json,
   Manual_Review_Checklist.csv, and {db_name}_complete_schema.sql — focus on README and any missing SQL.
4. README ({db_name}_00_README.txt) must include script run order (list script filenames only), manual intervention items, known limitations.{schema_hint}

Do not use git.
"""
