"""
Stream Visualization Service - Parse and visualize stream data.

Processes stream-json files and extracts structured event data for visualization.
Equivalent to Java's StreamVisualizationService.
"""
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

from app.models.responses import StreamVisualizationResponse
from app.utils.stream_utils import StreamParser
from app.core.config import get_settings
from app.core.exceptions import ValidationError, FileOperationError
from app.core.security import SecurityValidator


logger = logging.getLogger(__name__)
settings = get_settings()


class StreamVisualizationService:
    """
    Service for parsing and visualizing Claude stream output files.

    Retrieves stream data based on analysisId and operation type,
    parses JSONL stream files, and returns structured visualization data.

    Equivalent to Java's StreamVisualizationService.
    """

    def __init__(self):
        """Initialize stream visualization service."""
        self.output_base_dir = Path(settings.workspace.base_path)

        # Operation to output directory mapping (matches BaseOperationHandler)
        self.operation_dir_mapping = {
            "analysis": "versionUpgrade",
            "fix-upgrade": "versionUpgrade",
            "build-compilation": "validation",
            "test-execution": "validation",
            "test-creation": "validation",
            "cloudreadiness-analysis": "cloudreadiness",
            "cloudreadiness-fix": "cloudreadiness",
            "db-code-modernize-analysis": "db-code-modernize",
            "db-code-modernize-fix": "db-code-modernize",
            "schema-modernization": "schema-modernization",
            "dotnet-build-compilation": "validation",
            "dotnet-test-execution": "validation",
            "test-executionbuild": "validation",
        }

        logger.info("StreamVisualizationService initialized")

    async def get_stream_data(
        self,
        analysis_id: str,
        operation: str
    ) -> StreamVisualizationResponse:
        """
        Retrieve and parse stream data for an analysis.

        Args:
            analysis_id: Unique identifier for the analysis
            operation: Operation type (e.g., "analysis", "fix-upgrade")

        Returns:
            StreamVisualizationResponse with parsed stream data

        Raises:
            ValidationError: If inputs are invalid
            FileOperationError: If stream file cannot be read
        """
        logger.info(f"Retrieving stream data: analysisId={analysis_id}, operation={operation}")

        # Validate inputs
        self._validate_inputs(analysis_id, operation)

        # Build stream file path
        stream_file_path = self._build_stream_file_path(analysis_id, operation)

        # Check if file exists
        if not stream_file_path.exists():
            logger.warning(f"Stream file not found: {stream_file_path}")
            return StreamVisualizationResponse(
                analysis_id=analysis_id,
                operation=operation,
                status="not_found",
                message=f"Stream file not found for analysisId={analysis_id}, operation={operation}",
                stream_data=None
            )

        try:
            # Parse stream file
            logger.info(f"Parsing stream file: {stream_file_path}")
            events = StreamParser.parse_stream_file(stream_file_path)

            # Extract metadata
            metadata = StreamParser.extract_metadata(events)

            # Build response with stream data as JSON string
            stream_data_dict = {
                "events": events,
                "metadata": metadata,
                "total_events": len(events),
                "file_path": str(stream_file_path)
            }

            # Convert to JSON string for response
            stream_data_json = json.dumps(stream_data_dict, indent=2)

            logger.info(
                f"Stream data retrieved successfully: {len(events)} events, "
                f"{metadata['input_tokens']} input tokens, "
                f"{metadata['output_tokens']} output tokens"
            )

            return StreamVisualizationResponse(
                analysis_id=analysis_id,
                operation=operation,
                status="success",
                message="Stream data retrieved successfully",
                stream_data=stream_data_json
            )

        except Exception as e:
            error_msg = f"Failed to parse stream file: {str(e)}"
            logger.error(error_msg, exc_info=True)

            return StreamVisualizationResponse(
                analysis_id=analysis_id,
                operation=operation,
                status="error",
                message=error_msg,
                stream_data=None
            )

    def _validate_inputs(self, analysis_id: str, operation: str):
        """
        Validate analysisId and operation inputs.

        Args:
            analysis_id: Analysis ID to validate
            operation: Operation type to validate

        Raises:
            ValidationError: If validation fails
        """
        # Validate analysisId (alphanumeric, hyphens, underscores only)
        if not analysis_id:
            raise ValidationError(
                message="Analysis ID is required",
                field="analysisId"
            )

        SecurityValidator.validate_alphanumeric(analysis_id, "analysisId")

        # Validate operation
        if not operation:
            raise ValidationError(
                message="Operation is required",
                field="operation"
            )

        operation_lower = operation.lower()
        if operation_lower not in self.operation_dir_mapping:
            raise ValidationError(
                message=f"Invalid operation: {operation}. Supported operations: "
                       f"{list(self.operation_dir_mapping.keys())}",
                field="operation"
            )

    def _build_stream_file_path(self, analysis_id: str, operation: str) -> Path:
        """
        Build path to stream file based on analysisId and operation.

        Path structure: {output_dir}/{operation_dir}/{analysisId}/{operation}-stream.json

        Example:
            /studio-app/claude-workspace/versionUpgrade/abc123/analysis-stream.json

        Args:
            analysis_id: Analysis ID
            operation: Operation type

        Returns:
            Path to stream file
        """
        operation_lower = operation.lower()

        # Get output directory for operation type
        output_dir_name = self.operation_dir_mapping.get(operation_lower, "containerization")

        # Build file path
        stream_file_name = f"{operation_lower}-stream.json"
        stream_file_path = (
            self.output_base_dir /
            output_dir_name /
            analysis_id /
            stream_file_name
        )

        logger.debug(f"Built stream file path: {stream_file_path}")

        return stream_file_path

    async def get_stream_summary(
        self,
        analysis_id: str,
        operation: str
    ) -> Dict[str, Any]:
        """
        Get summary information about a stream.

        Returns metadata without full event data for quick status checks.

        Args:
            analysis_id: Analysis ID
            operation: Operation type

        Returns:
            Summary dictionary with metadata
        """
        logger.info(f"Retrieving stream summary: analysisId={analysis_id}, operation={operation}")

        # Validate inputs
        self._validate_inputs(analysis_id, operation)

        # Build stream file path
        stream_file_path = self._build_stream_file_path(analysis_id, operation)

        # Check if file exists
        if not stream_file_path.exists():
            return {
                "status": "not_found",
                "message": f"Stream file not found",
                "exists": False
            }

        try:
            # Parse stream file
            events = StreamParser.parse_stream_file(stream_file_path)

            # Extract metadata
            metadata = StreamParser.extract_metadata(events)

            # Build summary
            summary = {
                "status": "success",
                "exists": True,
                "total_events": len(events),
                "input_tokens": metadata.get("input_tokens", 0),
                "output_tokens": metadata.get("output_tokens", 0),
                "total_tokens": metadata.get("total_tokens", 0),
                "is_error": metadata.get("is_error", False),
                "error_message": metadata.get("error_message"),
                "stop_reason": metadata.get("stop_reason"),
                "file_path": str(stream_file_path),
                "file_size_bytes": stream_file_path.stat().st_size
            }

            logger.info(f"Stream summary retrieved: {summary['total_events']} events")

            return summary

        except Exception as e:
            error_msg = f"Failed to get stream summary: {str(e)}"
            logger.error(error_msg, exc_info=True)

            return {
                "status": "error",
                "message": error_msg,
                "exists": True
            }

    async def list_available_streams(self, analysis_id: str) -> List[Dict[str, Any]]:
        """
        List all available stream files for an analysis.

        Args:
            analysis_id: Analysis ID

        Returns:
            List of stream file information dicts
        """
        logger.info(f"Listing available streams for analysisId={analysis_id}")

        # Validate analysisId
        SecurityValidator.validate_alphanumeric(analysis_id, "analysisId")

        available_streams = []

        # Check each operation type
        for operation in self.operation_dir_mapping.keys():
            stream_file_path = self._build_stream_file_path(analysis_id, operation)

            if stream_file_path.exists():
                try:
                    # Get file stats
                    file_stats = stream_file_path.stat()

                    # Parse to get event count
                    events = StreamParser.parse_stream_file(stream_file_path)
                    metadata = StreamParser.extract_metadata(events)

                    stream_info = {
                        "operation": operation,
                        "file_path": str(stream_file_path),
                        "file_size_bytes": file_stats.st_size,
                        "total_events": len(events),
                        "is_error": metadata.get("is_error", False),
                        "created_at": file_stats.st_ctime
                    }

                    available_streams.append(stream_info)

                except Exception as e:
                    logger.warning(f"Failed to parse stream for operation {operation}: {e}")
                    continue

        logger.info(f"Found {len(available_streams)} available streams for analysisId={analysis_id}")

        return available_streams


# ============================================================================
# MODULE-LEVEL INSTANCE
# ============================================================================

_default_service: Optional[StreamVisualizationService] = None


def get_stream_visualization_service() -> StreamVisualizationService:
    """
    Get or create default StreamVisualizationService instance.

    Returns:
        StreamVisualizationService instance

    Example:
        >>> service = get_stream_visualization_service()
        >>> response = await service.get_stream_data("abc123", "analysis")
    """
    global _default_service
    if _default_service is None:
        _default_service = StreamVisualizationService()
    return _default_service
