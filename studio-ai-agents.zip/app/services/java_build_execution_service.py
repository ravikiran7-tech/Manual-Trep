"""
Direct Java build execution service (no LLM).

Runs Maven builds via SDKMAN-managed Java versions, parses the output,
and saves the result. Mirrors Java's ValidationClaudeServiceLinux /
BuildCompilationService.executeBuild() logic exactly.
"""
import asyncio
import json
import logging
import re
import sys
from pathlib import Path
from typing import Callable, List, Optional

from app.models.dotnet_build import BuildRequest, BuildResult


logger = logging.getLogger(__name__)

# Mirrors Java's static constant
_SDKMAN_INIT_SCRIPT = Path.home() / ".sdkman" / "bin" / "sdkman-init.sh"

# Java version → SDKMAN candidate version mapping
# Mirrors Java's convertToSdkmanVersion()
_SDKMAN_VERSION_MAP: dict[str, str] = {
    "8":   "8.0.422-tem",
    "1.8": "8.0.422-tem",
    "11":  "11.0.25-tem",
    "17":  "17.0.13-tem",
    "21":  "21.0.5-tem",
    "25":  "25.0.4-tem",
}
_DEFAULT_SDKMAN_VERSION = "21.0.5-tem"

# Maven output patterns (different from dotnet)
_MAVEN_ERROR_PATTERN   = re.compile(r"^\[ERROR\]")
_MAVEN_WARNING_PATTERN = re.compile(r"^\[WARNING\]")
_MAVEN_TIME_PATTERN    = re.compile(r"Total time:\s+(.+)")


async def execute_java_build(request: BuildRequest) -> BuildResult:
    """
    Execute Java Maven build without LLM.

    Mirrors Java's BuildCompilationService.executeBuild():
      1. Validate SDKMAN and project structure
      2. Create log/reports directories
      3. Run Maven build via bash script
      4. Parse build output
      5. Save build-result.json to reports folder
      6. Return BuildResult

    Args:
        request: BuildRequest with project location, Java version, etc.

    Returns:
        BuildResult with parsed Maven output

    Raises:
        IllegalStateError: If SDKMAN is not installed
        ValueError: If project structure is invalid
        RuntimeError: If Maven build fails
    """
    logger.info("=== STARTING BUILD EXECUTION PROCESS ===")
    logger.info("Project location: %s", request.project_location)
    logger.info("AnalysisID: %s", request.analysis_id)
    logger.info("Platform: %s", request.platform)
    logger.info("Claude workspace location: %s", request.claude_workspace)

    # Mirrors Java: validate before doing anything
    _verify_sdkman_installed()
    _verify_project_structure(request)

    if request.technology and request.technology.lower() == "java" \
            and request.build_type and request.build_type.lower() == "maven":
        pass  # supported
    else:
        raise NotImplementedError(
            f"Build type '{request.build_type}' for technology '{request.technology}' "
            "is not yet supported. Currently only 'maven' is supported."
        )

    log_file = _create_directories_and_get_log_path(
        request.analysis_id, request.claude_workspace
    )

    exit_code = await _execute_maven_build(request, log_file)

    if exit_code == 0:
        logger.info(
            "Build execution completed successfully for project: %s",
            request.project_location,
        )
    else:
        logger.error("Build execution failed with exit code: %d", exit_code)

    output_lines = _read_log_file(log_file)
    build_result = _parse_build_result(exit_code, output_lines)

    logger.info("=== SAVING BUILD RESULT TO REPORTS ===")
    _save_build_result(build_result, request.analysis_id, request.claude_workspace)
    logger.info("Build result saved to reports folder")

    if exit_code != 0:
        raise RuntimeError(
            f"Build execution failed with exit code: {exit_code}"
        )

    return build_result


# ---------------------------------------------------------------------------
# Private helpers — mirror Java private methods 1-to-1
# ---------------------------------------------------------------------------

def _verify_sdkman_installed() -> None:
    """
    Mirrors Java's verifySdkmanInstalled().
    Raises RuntimeError if SDKMAN init script does not exist.
    """
    logger.info("Verifying SDKMAN installation: %s", _SDKMAN_INIT_SCRIPT)
    if not _SDKMAN_INIT_SCRIPT.exists():
        raise RuntimeError(
            f"SDKMAN is not installed. Please install SDKMAN from https://sdkman.io/ "
            f"(expected at {_SDKMAN_INIT_SCRIPT})"
        )
    logger.info("SDKMAN installation verified at: %s", _SDKMAN_INIT_SCRIPT)


def _verify_project_structure(request: BuildRequest) -> None:
    """
    Mirrors Java's verifyProjectStructure().
    Checks project directory and build file exist.
    """
    project_path = Path(request.project_location)

    if not project_path.exists():
        raise ValueError(
            f"Project location does not exist: {request.project_location}"
        )
    if not project_path.is_dir():
        raise ValueError(
            f"Project location is not a directory: {request.project_location}"
        )

    if request.build_file:
        build_file_path = project_path / request.build_file
        if not build_file_path.exists():
            raise ValueError(
                f"Build file not found: {build_file_path}"
            )

    logger.info("Project structure verified: %s", request.project_location)


def _convert_to_sdkman_version(version: Optional[str]) -> str:
    """
    Mirrors Java's convertToSdkmanVersion().
    Maps "17" → "17.0.13-tem" etc.
    """
    if not version or not version.strip():
        raise ValueError("Java version cannot be null or empty")

    normalized = version.strip()
    sdkman_version = _SDKMAN_VERSION_MAP.get(normalized)
    if sdkman_version:
        return sdkman_version

    logger.warning(
        "Unknown Java version: %s, using default %s", normalized, _DEFAULT_SDKMAN_VERSION
    )
    return _DEFAULT_SDKMAN_VERSION


def _verify_java_version_installed(sdkman_version: str) -> None:
    """
    Mirrors Java's verifyJavaVersionInstalled().
    Checks ~/.sdkman/candidates/java/<version> exists.
    """
    java_path = Path.home() / ".sdkman" / "candidates" / "java" / sdkman_version
    if not java_path.exists():
        raise RuntimeError(
            f"Java version {sdkman_version} is not installed via SDKMAN. "
            f"Please install it first using: sdk install java {sdkman_version}"
        )
    logger.info("Java version %s verified at: %s", sdkman_version, java_path)


def _create_directories_and_get_log_path(
    analysis_id: str,
    claude_workspace: Optional[str],
) -> Path:
    """
    Mirrors Java's createDirectoriesForBuildLogs() + getBuildLogFilePath().
    Creates:
      {workspace}/validation/{analysisId}/logs/
      {workspace}/validation/{analysisId}/reports/
    Returns path to build.log.
    """
    if not claude_workspace:
        raise ValueError(
            "claude_workspace is required to create build directories but was not provided"
        )
    base = Path(claude_workspace) / "validation" / analysis_id
    logs_dir    = base / "logs"
    reports_dir = base / "reports"

    logs_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    logger.info("Created build directories under: %s", base)
    return logs_dir / "build.log"


async def _execute_maven_build(request: BuildRequest, log_file: Path) -> int:
    """
    Mirrors Java's executeMavenBuild().
    Resolves SDKMAN version, verifies installation, builds the bash script,
    and runs it as a subprocess.
    """
    logger.info("Executing Maven build with Java version: %s", request.version)

    sdkman_version = _convert_to_sdkman_version(request.version)
    _verify_java_version_installed(sdkman_version)

    build_script = _create_maven_build_script(request, log_file, sdkman_version)
    logger.info("Running Maven build script for analysisId: %s", request.analysis_id)

    try:
        proc = await asyncio.create_subprocess_exec(
            "/bin/bash", "-c", build_script,
            cwd=request.project_location,
            stdout=asyncio.subprocess.DEVNULL,  # script redirects output to log file itself
            stderr=asyncio.subprocess.DEVNULL,
        )
        exit_code = await proc.wait()
    except FileNotFoundError:
        raise RuntimeError("/bin/bash not found — cannot execute Maven build script")
    except Exception as e:
        raise RuntimeError(f"Failed to run Maven build: {e}") from e

    logger.info(
        "Build completed for analysisId: %s with exit code: %d",
        request.analysis_id, exit_code
    )
    return exit_code


def _create_maven_build_script(
    request: BuildRequest,
    log_file_path: Path,
    sdkman_version: str,
) -> str:
    """
    Mirrors Java's createMavenBuildScript().
    Produces a bash script that sources SDKMAN, switches Java, then runs Maven.
    All output is redirected to log_file_path.
    """
    skip = " -DskipTests" if request.skip_tests else ""
    log  = str(log_file_path).replace("'", "'\\''")  # shell-escape single quotes

    script = (
        "set -e; "
        "{ "
        f"  echo '=== Build started at: '$(date)' ==='; "
        f"  source {_SDKMAN_INIT_SCRIPT}; "
        f"  sdk use java {sdkman_version}; "
        "  echo 'Java version:'; "
        "  java -version; "
        "  echo 'Maven version:'; "
        "  mvn -version; "
        "  echo 'Starting Maven build...'; "
        f"  mvn clean install{skip}; "
        "  echo '=== Build completed at: '$(date)' ==='; "
        f"}} > '{log}' 2>&1"
    )
    return script


def _read_log_file(log_file: Path) -> List[str]:
    """
    Mirrors Java's readLogFile().
    Returns lines from the log file, or a placeholder if not found.
    """
    if not log_file.exists():
        logger.warning("Log file not found: %s", log_file)
        return ["Log file not found"]
    return log_file.read_text(encoding="utf-8", errors="replace").splitlines()


def _parse_build_result(exit_code: int, output_lines: List[str]) -> BuildResult:
    """Mirrors Java's parseBuildResult() — Maven-specific parsing."""
    return BuildResult(
        exit_code=exit_code,
        success=exit_code == 0,
        build_status=_determine_build_status(output_lines),
        compilation_errors=_extract_errors(output_lines),
        test_failures=_extract_test_failures(output_lines),
        errors=_extract_error_count(output_lines),
        warnings=_extract_warning_count(output_lines),
        total_time=_extract_total_time(output_lines),
    )


def _determine_build_status(output_lines: List[str]) -> str:
    """Maven: looks for 'BUILD SUCCESS' or 'BUILD FAILURE'."""
    for line in output_lines:
        if "BUILD SUCCESS" in line:
            return "SUCCESS"
        if "BUILD FAILURE" in line:
            return "FAILURE"
    return "UNKNOWN"


def _extract_errors(output_lines: List[str]) -> List[str]:
    """Maven: collects [ERROR] lines (deduplicated)."""
    seen: set = set()
    errors = []
    for line in output_lines:
        stripped = line.strip()
        if _MAVEN_ERROR_PATTERN.match(stripped) and stripped not in seen:
            seen.add(stripped)
            errors.append(stripped)
    return errors


def _extract_test_failures(output_lines: List[str]) -> List[str]:
    """Maven: collects test failure summary lines."""
    seen: set = set()
    failures = []
    for line in output_lines:
        stripped = line.strip()
        if ("Tests run:" in stripped and "Failures:" in stripped) or \
                ("FAILED" in stripped and "test" in stripped.lower()):
            if stripped and stripped not in seen:
                seen.add(stripped)
                failures.append(stripped)
    return failures


def _extract_error_count(output_lines: List[str]) -> int:
    """Count [ERROR] lines as error count."""
    return sum(1 for line in output_lines if _MAVEN_ERROR_PATTERN.match(line.strip()))


def _extract_warning_count(output_lines: List[str]) -> int:
    """Count [WARNING] lines as warning count."""
    return sum(1 for line in output_lines if _MAVEN_WARNING_PATTERN.match(line.strip()))


def _extract_total_time(output_lines: List[str]) -> str:
    """Maven: 'Total time: 12.345 s'"""
    for line in output_lines:
        m = _MAVEN_TIME_PATTERN.search(line)
        if m:
            return m.group(1).strip()
    return "N/A"


def _save_build_result(
    build_result: BuildResult,
    analysis_id: str,
    claude_workspace: Optional[str],
) -> None:
    """
    Mirrors Java's saveBuildResult().
    Writes build-result.json to {workspace}/validation/{analysisId}/reports/
    """
    if not claude_workspace:
        raise ValueError(
            "claude_workspace is required to save build results but was not provided"
        )
    reports_dir = (
        Path(claude_workspace) / "validation" / analysis_id / "reports"
    )
    reports_dir.mkdir(parents=True, exist_ok=True)

    result_path = reports_dir / "build-result.json"
    result_path.write_text(
        json.dumps(build_result.model_dump(by_alias=True), indent=2),
        encoding="utf-8",
    )
    logger.info("build-result.json saved to: %s", result_path)
