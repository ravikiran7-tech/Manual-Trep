"""
NATS subscriber/publisher for schema generation batch flow.

Consumes requests from ``schema.generate.request``, maps payload to
``AssessmentRulesBatchRequest``, executes generation, and publishes result to
``schema.generate.result``.

Config loading mirrors Rules Management: SQLite ``env_config`` plus process
environment for the same NATS_* keys; optional Base64 AES-GCM decrypt for
``NATS_USERNAME`` / ``NATS_PASSWORD`` (see ``app.utils.encryption``).
"""
import json
import logging
import os
import sqlite3
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urlparse, urlunparse

from app.core.config import get_settings
from app.models.requests import AssessmentRulesBatchRequest
from app.models.responses import AssessmentRulesBatchResponse
from app.services.claude_service import ClaudeService, get_claude_service
from app.utils.encryption import decrypt_secret_if_base64_gcm
from app.utils.path_utils import resolve_path_within_directory


logger = logging.getLogger(__name__)
settings = get_settings()


def _format_nats_endpoint_for_log(url: str) -> str:
    """Return scheme + host + port only; never log userinfo from NATS_URL."""
    raw = (url or "").strip()
    if not raw:
        return "<empty>"
    parsed = urlparse(raw)
    if not parsed.scheme:
        return "<unparseable>"
    host = parsed.hostname
    if not host:
        return f"{parsed.scheme}://<no-host>"
    port = parsed.port
    if port:
        return f"{parsed.scheme}://{host}:{port}"
    return f"{parsed.scheme}://{host}"


def _normalize_nats_server_url(raw_url: str) -> str:
    """
    Normalize one server URL for nats-py.
    - If scheme is missing, default to nats://
    - For nats:// and tls://, default port 4222 when omitted (matches NATS client port)
    - Leave encrypted websocket (wss) URLs unchanged
    """
    candidate = (raw_url or "").strip()
    if not candidate:
        return ""
    parsed = urlparse(candidate if "://" in candidate else f"nats://{candidate}")
    scheme = (parsed.scheme or "").lower()
    if scheme in ("nats", "tls") and parsed.hostname and parsed.port is None:
        if parsed.username is not None or parsed.password is not None:
            u = parsed.username or ""
            p = f":{parsed.password}" if parsed.password is not None else ""
            netloc = f"{u}{p}@{parsed.hostname}:4222"
        else:
            netloc = f"{parsed.hostname}:4222"
        parsed = parsed._replace(netloc=netloc)
        return urlunparse(parsed)
    if "://" not in (raw_url or "").strip():
        return urlunparse(parsed)
    return candidate


def _parse_nats_servers(raw_urls: str) -> List[str]:
    """
    Parse one or many NATS URLs from env_config NATS_URL.
    Accepts comma/semicolon separated values.
    """
    pieces = [p.strip() for p in str(raw_urls).replace(";", ",").split(",") if p.strip()]
    servers = [_normalize_nats_server_url(p) for p in pieces]
    servers = [s for s in servers if s]
    if not servers:
        raise RuntimeError(
            "NATS_URL is missing or blank (check env_config and/or NATS_URL env var)"
        )
    return servers


def _validate_uniform_transport(servers: List[str]) -> None:
    """
    nats-py does not allow mixing websocket and non-websocket URLs.
    Validate early and raise a clear configuration error.
    """
    schemes: Set[str] = {urlparse(s).scheme.lower() for s in servers}
    ws_present = any(s in {"ws", "wss"} for s in schemes)
    tcp_present = any(s in {"nats", "tls"} for s in schemes)
    if ws_present and tcp_present:
        raise RuntimeError(
            "NATS_URL mixes websocket and non-websocket URLs, which is not allowed. "
            f"Use only one transport family. Parsed servers={servers}"
        )


@dataclass
class NatsSecrets:
    """NATS values loaded from env_config table."""

    url: str = ""
    user: str = ""
    password: str = ""
    auth_enabled: str = ""


@dataclass
class Secrets:
    """Service secrets object (mirrors producer structure)."""

    nats: NatsSecrets = field(default_factory=NatsSecrets)


NATS_ENV_KEYS = (
    "NATS_URL",
    "NATS_USERNAME",
    "NATS_PASSWORD",
    "NATS_AUTH_ENABLED",
)


def _merge_nats_from_process_env(store: Dict[str, str]) -> Dict[str, str]:
    """Overlay NATS_* from the process environment (same keys as env_config)."""
    merged = dict(store)
    for key in NATS_ENV_KEYS:
        v = os.environ.get(key)
        if v is not None:
            merged[key] = v
    return merged


def _read_sqlite_env_config(db_path: str) -> Dict[str, str]:
    """Load all key/value rows from env_config; empty dict if DB is missing or unreadable."""
    out: Dict[str, str] = {}
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM env_config")
            rows = cursor.fetchall()
            for key, value in rows:
                if key is not None:
                    out[str(key)] = "" if value is None else str(value)
    except Exception as exc:
        logger.warning(
            "[nats-schema-gen] Could not read SQLite env_config at %s: %s",
            db_path,
            exc,
        )
    return out


def _parse_auth_enabled(raw: str) -> bool:
    """Java ``Boolean.parseBoolean`` semantics plus common truthy strings."""
    if raw is None:
        return False
    return str(raw).strip().lower() in ("true", "1", "yes")


def _decrypt_nats_credentials(nats: NatsSecrets, passphrase: Optional[str]) -> None:
    """Decrypt NATS user/password when stored as Base64 GCM (Rules Management)."""
    nats.user = decrypt_secret_if_base64_gcm(nats.user, passphrase=passphrase)
    nats.password = decrypt_secret_if_base64_gcm(nats.password, passphrase=passphrase)


class SecretService:
    """Loads NATS secrets from SQLite env_config and/or process env (same keys)."""

    def __init__(
        self,
        sqlite_path: str,
        allowed_directory: Optional[str] = None,
    ):
        self.sqlite_path = sqlite_path
        self.allowed_directory = (
            allowed_directory or settings.nats.sqlite_config_allowed_dir
        )

    def load_all_secrets(self) -> Secrets:
        db_path = self._resolve_sqlite_path(
            self.sqlite_path,
            self.allowed_directory,
        )
        secrets_map = _read_sqlite_env_config(db_path)
        secrets_map = _merge_nats_from_process_env(secrets_map)
        return self._map_to_service_secrets(secrets_map)

    @staticmethod
    def _strip_jdbc_sqlite_prefix(raw_path: str) -> str:
        if raw_path.startswith("jdbc:sqlite:"):
            return raw_path[len("jdbc:sqlite:") :].strip()
        return raw_path.strip()

    @staticmethod
    def _resolve_sqlite_path(raw_path: str, allowed_directory: str) -> str:
        file_part = SecretService._strip_jdbc_sqlite_prefix(raw_path)
        canonical = resolve_path_within_directory(
            file_part,
            allowed_directory,
            path_type="sqlite_config",
        )
        return str(canonical)

    @staticmethod
    def _map_to_service_secrets(values: Dict[str, str]) -> Secrets:
        secrets = Secrets()
        secrets.nats.url = values.get("NATS_URL", "")
        secrets.nats.user = values.get("NATS_USERNAME", "")
        secrets.nats.password = values.get("NATS_PASSWORD", "")
        secrets.nats.auth_enabled = values.get("NATS_AUTH_ENABLED", "")
        return secrets


class NatsSchemaGenerateService:
    """NATS integration for schema generation contract."""

    def __init__(self, claude_service: ClaudeService | None = None):
        self._claude_service = claude_service or get_claude_service()
        self._nc = None
        self._subscription = None
        self._started = False
        self._secrets: Secrets | None = None

    async def start(self) -> None:
        """Connect to NATS and subscribe to request subject."""
        if self._started:
            return
        if not settings.nats.enabled:
            logger.info("NATS schema-generation integration is disabled")
            return

        try:
            import nats
        except ImportError as exc:
            raise RuntimeError(
                "NATS is enabled but the `nats` module is not available for THIS Python "
                f"interpreter: {sys.executable}\n"
                "Often `pip install nats-py` went to user site-packages while uvicorn runs "
                "inside a venv. Fix: activate the venv, then run exactly:\n"
                "  python -m pip install nats-py\n"
                "(or: .\\venv\\Scripts\\python.exe -m pip install nats-py)\n"
                "If pip says the venv is not writeable, fix venv permissions or recreate the venv.\n"
                "To start without NATS: set NATS_ENABLED=false."
            ) from exc

        sqlite_raw = settings.nats.sqlite_config_db_path
        sqlite_allowed_dir = settings.nats.sqlite_config_allowed_dir
        sqlite_resolved = SecretService._resolve_sqlite_path(
            sqlite_raw,
            sqlite_allowed_dir,
        )
        self._secrets = SecretService(
            sqlite_raw,
            allowed_directory=sqlite_allowed_dir,
        ).load_all_secrets()
        try:
            _decrypt_nats_credentials(
                self._secrets.nats,
                settings.enc_passphrase,
            )
        except Exception as exc:
            logger.error("[nats-schema-gen] Failed to decrypt NATS credentials: %s", exc)
            raise RuntimeError(
                "Failed to decrypt NATS_USERNAME / NATS_PASSWORD "
                "(check ENC_PASSPHRASE and encryption format)"
            ) from exc

        nats_url_raw = (self._secrets.nats.url or "").strip()
        if not nats_url_raw:
            db_exists = Path(sqlite_resolved).is_file()
            env_url_set = bool((os.environ.get("NATS_URL") or "").strip())
            logger.error(
                "[nats-schema-gen] NATS_URL is empty after merge. sqlite_resolved=%s "
                "file_exists=%s NATS_URL_set_in_os_environ=%s "
                "(fix: mount config.db at that path, set NATS_SQLITE_CONFIG_DB_PATH, "
                "or inject NATS_URL / NATS_* via Kubernetes env / Docker -e)",
                sqlite_resolved,
                db_exists,
                env_url_set,
            )
            raise RuntimeError(
                "NATS_URL is missing. SQLite env_config could not supply it and NATS_URL "
                "is not set (or is blank) in the process environment.\n"
                "Docker/Kubernetes: mount Rules Management config.db (e.g. "
                "volumeMount -> /etc/app-config/config.db) or set env NATS_URL=nats://host:4222 "
                "(and NATS_USERNAME, NATS_PASSWORD, NATS_AUTH_ENABLED if needed). "
                f"Resolved DB path was: {sqlite_resolved}"
            )

        logger.info(
            "[nats-schema-gen] Raw NATS_URL (after SQLite + env merge): %s",
            nats_url_raw,
        )
        servers = _parse_nats_servers(nats_url_raw)
        _validate_uniform_transport(servers)

        auth_flag = (self._secrets.nats.auth_enabled or "").strip()
        auth_on = _parse_auth_enabled(self._secrets.nats.auth_enabled)
        user_configured = bool((self._secrets.nats.user or "").strip())
        pass_configured = bool((self._secrets.nats.password or "").strip())
        logger.info(
            "[nats-schema-gen] Loaded env_config from SQLite: raw_path=%s resolved_path=%s",
            sqlite_raw,
            sqlite_resolved,
        )
        logger.info(
            "[nats-schema-gen] NATS connection plan: endpoint=%s connection_name=%s "
            "connect_timeout_s=%s reconnect_wait_s=%s max_reconnects=%s "
            "NATS_AUTH_ENABLED=%r auth_applied=%s username_configured=%s password_configured=%s "
            "subscribe_subject=%s publish_subject=%s",
            ", ".join(_format_nats_endpoint_for_log(s) for s in servers),
            settings.nats.client_name,
            settings.nats.connect_timeout_seconds,
            settings.nats.reconnect_wait_seconds,
            settings.nats.max_reconnects,
            auth_flag,
            auth_on,
            user_configured,
            pass_configured,
            settings.nats.schema_generate_request_subject,
            settings.nats.schema_generate_result_subject,
        )

        async def _nats_error_cb(err: Any) -> None:
            logger.warning("[nats-schema-gen] NATS error: %s", err)

        connect_kwargs: Dict[str, Any] = {
            "servers": servers,
            "name": settings.nats.client_name,
            "connect_timeout": settings.nats.connect_timeout_seconds,
            "reconnect_time_wait": settings.nats.reconnect_wait_seconds,
            "max_reconnect_attempts": settings.nats.max_reconnects,
            "error_cb": _nats_error_cb,
        }

        if auth_on:
            connect_kwargs["user"] = self._secrets.nats.user
            connect_kwargs["password"] = self._secrets.nats.password

        self._nc = await nats.connect(**connect_kwargs)
        connected = getattr(self._nc, "connected_url", None) or getattr(
            self._nc, "servers", None
        )
        logger.info(
            "[nats-schema-gen] NATS client connected: reported=%s",
            connected,
        )
        self._subscription = await self._nc.subscribe(
            settings.nats.schema_generate_request_subject,
            cb=self._on_message,
        )
        self._started = True
        logger.info(
            "[nats-schema-gen] Subscribed to NATS subject: %s",
            settings.nats.schema_generate_request_subject,
        )

    async def stop(self) -> None:
        """Unsubscribe and close NATS connection."""
        if not self._started:
            return
        if self._subscription:
            await self._subscription.unsubscribe()
        if self._nc:
            await self._nc.drain()
            await self._nc.close()
        self._subscription = None
        self._nc = None
        self._started = False
        logger.info("NATS schema-generation integration stopped")

    async def _on_message(self, msg) -> None:
        """Handle one request message; publish progressive chunk results."""
        analysis_id = None
        try:
            request_payload = self._parse_request_payload(msg.data)
            analysis_id = request_payload["analysisId"]
            request = AssessmentRulesBatchRequest.model_validate(request_payload)

            async def on_progress(response: AssessmentRulesBatchResponse) -> None:
                await self._publish_result(response)

            await self._claude_service.execute_assessment_rules_batch(
                request, on_progress=on_progress
            )
        except Exception as exc:
            logger.error("Failed handling schema.generate.request: %s", exc, exc_info=True)
            failure = AssessmentRulesBatchResponse(
                status="error",
                message=f"schema.generate.request handling failed: {str(exc)}",
                is_final=True,
                chunk_index=1,
                chunk_count=1,
                analysis_id=analysis_id or self._build_analysis_id(),
                error_details=str(exc),
            )
            await self._publish_result(failure)

    def _parse_request_payload(self, raw_data: bytes) -> Dict[str, Any]:
        payload = json.loads(raw_data.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Payload must be a JSON object")

        rules = payload.get("rules")
        if not isinstance(rules, list) or len(rules) == 0:
            raise ValueError("rules is required and must be a non-empty list")

        mapped_rules: List[Dict[str, Any]] = []
        for idx, rule in enumerate(rules):
            if not isinstance(rule, dict):
                raise ValueError(f"rules[{idx}] must be an object")
            self._validate_rule(rule, idx)
            item: Dict[str, Any] = {
                "domain": rule["domain"],
                "name": rule["name"],
                "description": rule["description"],
                "ruleId": rule["ruleId"],
                "language": rule["language"],
                "category": rule["category"],
                "issueType": rule["issueType"],
                "severity": rule["severity"],
            }
            # Optional only; Java AssessmentRuleInputItem has no example field — omit when absent/null
            ex = rule.get("example")
            if ex is not None:
                item["example"] = ex
            mapped_rules.append(item)

        result: Dict[str, Any] = {
            "analysisId": payload.get("analysisId") or self._build_analysis_id(),
            "platform": settings.nats.platform,
            "rules": mapped_rules,
        }
        nats_project_path = (settings.nats.project_path or "").strip()
        if nats_project_path:
            result["projectPath"] = nats_project_path
        return result

    @staticmethod
    def _validate_rule(rule: Dict[str, Any], idx: int) -> None:
        required_non_blank = [
            "domain",
            "name",
            "description",
            "ruleId",
            "language",
            "category",
            "issueType",
            "severity",
        ]
        for field in required_non_blank:
            value = rule.get(field)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"rules[{idx}].{field} is required and must be non-blank")
        if "example" in rule and rule["example"] is not None:
            if not isinstance(rule["example"], str):
                raise ValueError(f"rules[{idx}].example must be a string when provided")

    async def _publish_result(self, response: AssessmentRulesBatchResponse) -> None:
        if not self._nc:
            raise RuntimeError("NATS connection is not available")
        data = response.model_dump(by_alias=True, exclude_none=True, mode="json")
        await self._nc.publish(
            settings.nats.schema_generate_result_subject,
            json.dumps(data, ensure_ascii=False).encode("utf-8"),
        )
        await self._nc.flush()
        logger.info(
            "Published schema generation result to subject: %s status=%s isFinal=%s "
            "chunk=%s/%s analysisId=%s",
            settings.nats.schema_generate_result_subject,
            response.status,
            response.is_final,
            response.chunk_index,
            response.chunk_count,
            response.analysis_id,
        )

    @staticmethod
    def _build_analysis_id() -> str:
        return f"schema-gen-{uuid.uuid4().hex[:12]}"
