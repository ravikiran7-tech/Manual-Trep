"""Pass 2: propagate each converted object's caller-update requirements to its callers.

Reasons handled (from conversion_validator / stub_generator callerUpdatesNeeded):
  SIGNATURE_CHANGE, SYNONYM_RESOLUTION, CLR_REPLACEMENT, UDT_ELIMINATION,
  VIEW_STRUCTURE_CHANGE, TABLE_COLUMN_RENAME, INSTEAD_OF_CONVERSION (log-only).

SYNONYM_RESOLUTION and UDT_ELIMINATION are unambiguous textual substitutions and are
patched automatically. The remaining reasons cannot be rewritten safely by regex, so
callers are flagged for manual review instead (INSTEAD_OF_CONVERSION is recorded in the
audit trail only, with no caller flag, since the trigger body itself was already rewritten).
Also applies PG-080 (EXEC -> CALL normalization) across every code-bearing object.
"""

from __future__ import annotations

import re
from typing import Any, Optional

from app.services.mssql_pg.confidence import lowest
from app.services.mssql_pg.stub_generator import pg_qualified

CODE_BEARING_TYPES = frozenset({"VIEW", "MATERIALIZED_VIEW", "FUNCTION", "PROCEDURE", "TRIGGER"})
AUTO_PATCH_REASONS = frozenset({"SYNONYM_RESOLUTION", "UDT_ELIMINATION"})
LOG_ONLY_REASONS = frozenset({"INSTEAD_OF_CONVERSION"})
MANUAL_FLAG_REASONS = frozenset({"SIGNATURE_CHANGE", "CLR_REPLACEMENT", "VIEW_STRUCTURE_CHANGE", "TABLE_COLUMN_RENAME"})

_EXEC_STMT = re.compile(
    r"(?im)^([ \t]*)EXEC(?:UTE)?\s+(?!\(|sp_executesql\b)(\[?[\w]+\]?(?:\s*\.\s*\[?[\w]+\]?)?)\s*([^;\n]*)(;?)\s*$"
)
_NAMED_ARG = re.compile(r"@(\w+)\s*=\s*")
_POSITIONAL_AT = re.compile(r"@(\w+)\b")


def _strip_brackets(name: str) -> str:
    return name.replace("[", "").replace("]", "").strip()


def _code_of(obj: dict[str, Any]) -> str:
    return obj.get("convertedCode") or ""


def _set_code(obj: dict[str, Any], code: str, note: str) -> None:
    obj["convertedCode"] = code
    obj.setdefault("changesApplied", []).append(note)


def build_name_index(plan: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Map lower-cased 'schema.name' and bare 'name' to the plan entries they identify."""
    index: dict[str, list[dict[str, Any]]] = {}
    for obj in plan:
        qualified = f"{obj['schema']}.{obj['name']}".lower()
        bare = obj["name"].lower()
        index.setdefault(qualified, []).append(obj)
        index.setdefault(bare, []).append(obj)
    return index


def _procedure_args_to_call(args_text: str) -> str:
    """Best-effort T-SQL call arguments -> PostgreSQL CALL arguments."""
    args_text = args_text.strip().rstrip(";")
    if not args_text:
        return ""
    if _NAMED_ARG.search(args_text):
        return _NAMED_ARG.sub(lambda m: f"{m.group(1)} => ", args_text)
    return _POSITIONAL_AT.sub(lambda m: m.group(1), args_text)


def rewrite_exec_to_call(code: str, procedure_names: set[str]) -> tuple[str, int]:
    """PG-080: rewrite `EXEC[UTE] proc ...` to `CALL schema.proc(...)` for known procedures."""
    count = 0

    def _replace(match: "re.Match[str]") -> str:
        nonlocal count
        indent, raw_name, args, _trailing = match.groups()
        name = _strip_brackets(raw_name)
        bare = name.split(".")[-1].lower()
        if name.lower() not in procedure_names and bare not in procedure_names:
            return match.group(0)
        matches = [p for p in procedure_names if p.endswith(f".{bare}") or p == bare]
        qualified = next((p for p in matches if "." in p), matches[0] if matches else bare)
        count += 1
        return f"{indent}CALL {qualified}({_procedure_args_to_call(args)});"

    return _EXEC_STMT.sub(_replace, code), count


def apply_exec_to_call(plan: list[dict[str, Any]]) -> int:
    procedure_names = {f"{o['schema']}.{o['name']}".lower() for o in plan if o["type"] == "PROCEDURE"}
    procedure_names |= {o["name"].lower() for o in plan if o["type"] == "PROCEDURE"}
    total = 0
    for obj in plan:
        if obj["type"] not in CODE_BEARING_TYPES or not _code_of(obj):
            continue
        new_code, count = rewrite_exec_to_call(_code_of(obj), procedure_names)
        if count:
            _set_code(obj, new_code, f"PG-080: rewrote {count} EXEC call(s) to CALL")
            total += count
    return total


def _word_pattern(name: str) -> "re.Pattern[str]":
    escaped = re.escape(name)
    return re.compile(rf"(?i)(\[?{escaped}\]?)\b")


def _declared_callers(plan: list[dict[str, Any]], callee: dict[str, Any]) -> list[dict[str, Any]]:
    """Objects whose AI analysis depends_on_code/calls names this callee."""
    names = {f"{callee['schema']}.{callee['name']}".lower(), callee["name"].lower()}
    callers: list[dict[str, Any]] = []
    for other in plan:
        if other is callee or other["type"] not in CODE_BEARING_TYPES:
            continue
        deps = other.get("dependsOnCode") or []
        if isinstance(deps, str):
            deps = [deps]
        for dep in deps:
            token = str(dep).replace("[", "").replace("]", "").strip().lower()
            if token in names or token.split(".")[-1] == callee["name"].lower():
                callers.append(other)
                break
    return callers


def _flag_caller(caller: dict[str, Any], callee: str, reason: str, detail: str) -> None:
    caller["requiresManualReview"] = True
    caller["confidenceScore"] = lowest(caller.get("confidenceScore"), "LOW")
    caller.setdefault("reviewGuidance", []).append({"reason": f"Caller of {callee} ({reason}); {detail}", "priority": "HIGH"})


def apply_synonym_resolution(plan: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    for obj in plan:
        for update in obj.get("callerUpdatesNeeded") or []:
            if update.get("reason") != "SYNONYM_RESOLUTION":
                continue
            target = update.get("target") or obj.get("convertedName")
            if not target:
                continue
            synonym_name = obj["name"]
            qualified_pattern = _word_pattern(f"{obj['schema']}.{synonym_name}")
            bare_pattern = _word_pattern(synonym_name)
            for other in plan:
                if other is obj or other["type"] not in CODE_BEARING_TYPES:
                    continue
                code = _code_of(other)
                if not code:
                    continue
                new_code, n1 = qualified_pattern.subn(target, code)
                new_code, n2 = bare_pattern.subn(target, new_code)
                if n1 or n2:
                    _set_code(other, new_code, f"PG-082: resolved synonym {obj['schema']}.{synonym_name} -> {target}")
                    audit.append(
                        {
                            "reason": "SYNONYM_RESOLUTION",
                            "callee": f"{obj['schema']}.{synonym_name}",
                            "caller": f"{other['schema']}.{other['name']}",
                            "target": target,
                            "occurrences": n1 + n2,
                            "action": "PATCHED",
                        }
                    )
            patched = {entry["caller"] for entry in audit if entry.get("reason") == "SYNONYM_RESOLUTION"}
            for other in _declared_callers(plan, obj):
                caller_name = f"{other['schema']}.{other['name']}"
                if caller_name in patched:
                    continue
                _flag_caller(other, f"{obj['schema']}.{synonym_name}", "SYNONYM_RESOLUTION", f"verify references now point at {target}")
                audit.append(
                    {
                        "reason": "SYNONYM_RESOLUTION",
                        "callee": f"{obj['schema']}.{synonym_name}",
                        "caller": caller_name,
                        "target": target,
                        "action": "FLAGGED_FOR_REVIEW",
                    }
                )


def apply_udt_elimination(plan: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    for obj in plan:
        for update in obj.get("callerUpdatesNeeded") or []:
            if update.get("reason") != "UDT_ELIMINATION":
                continue
            replacement = update.get("replacement_type") or "jsonb"
            udt_name = obj["name"]
            qualified_pattern = _word_pattern(f"{obj['schema']}.{udt_name}")
            bare_pattern = _word_pattern(udt_name)
            for other in plan:
                if other is obj or other["type"] not in CODE_BEARING_TYPES | {"TABLE"}:
                    continue
                code = _code_of(other)
                if not code:
                    continue
                new_code, n1 = qualified_pattern.subn(replacement, code)
                new_code, n2 = bare_pattern.subn(replacement, new_code)
                if n1 or n2:
                    _set_code(other, new_code, f"PG-083: replaced CLR type {obj['schema']}.{udt_name} with {replacement}")
                    audit.append(
                        {
                            "reason": "UDT_ELIMINATION",
                            "callee": f"{obj['schema']}.{udt_name}",
                            "caller": f"{other['schema']}.{other['name']}",
                            "replacement_type": replacement,
                            "occurrences": n1 + n2,
                        }
                    )


def _replacement_pair(update: dict[str, Any]) -> Optional[tuple[str, str]]:
    """Structured rename from the model, when it supplied both sides of the change."""
    for old_key, new_key in (
        ("old_name", "new_name"),
        ("oldName", "newName"),
        ("from", "to"),
        ("column", "replacement"),
    ):
        old = update.get(old_key)
        new = update.get(new_key)
        if old and new and str(old) != str(new):
            return str(old), str(new)
    return None


def flag_manual_review_callers(plan: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    for obj in plan:
        for update in obj.get("callerUpdatesNeeded") or []:
            reason = update.get("reason")
            callee = str(update.get("callee") or f"{obj['schema']}.{obj['name']}")
            if reason in LOG_ONLY_REASONS:
                audit.append({"reason": reason, "callee": callee, "caller": None, "detail": update.get("detail"), "action": "LOGGED_ONLY"})
                continue
            if reason not in MANUAL_FLAG_REASONS:
                continue
            pair = _replacement_pair(update)
            bare = callee.split(".")[-1].lower()
            seen: set[str] = set()
            candidates = [caller for caller in plan if caller is not obj and caller["type"] in CODE_BEARING_TYPES]
            for caller in candidates:
                code = _code_of(caller)
                referenced = _references(code, callee, bare) or (pair and _word_pattern(pair[0]).search(code))
                declared = caller in _declared_callers(plan, obj)
                if not referenced and not declared:
                    continue
                caller_name = f"{caller['schema']}.{caller['name']}"
                if caller_name in seen:
                    continue
                seen.add(caller_name)
                if pair and referenced:
                    new_code, count = _word_pattern(pair[0]).subn(pair[1], code)
                    if count:
                        _set_code(caller, new_code, f"{reason}: replaced {pair[0]} with {pair[1]}")
                        audit.append(
                            {
                                "reason": reason,
                                "callee": callee,
                                "caller": caller_name,
                                "action": "PATCHED",
                                "occurrences": count,
                            }
                        )
                detail = update.get("detail") or (f"{pair[0]} -> {pair[1]}" if pair else "verify generated call site manually")
                _flag_caller(caller, callee, reason, detail)
                audit.append({"reason": reason, "callee": callee, "caller": caller_name, "action": "FLAGGED_FOR_REVIEW"})


def _references(code: str, qualified: str, bare: str) -> bool:
    if not code:
        return False
    return bool(_word_pattern(qualified.split(".")[-1]).search(code) or _word_pattern(bare).search(code))


_CREATE_FUNCTION = re.compile(r"(?i)CREATE\s+(OR\s+REPLACE\s+)?FUNCTION\b")


def check_procedure_not_downgraded(plan: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    """PG-081 guard: a PROCEDURE object must never come back as a PostgreSQL FUNCTION."""
    for obj in plan:
        if obj["type"] != "PROCEDURE" or obj.get("conversionSource") not in {"AI", "AI_REPAIRED"}:
            continue
        code = _code_of(obj)
        if code and _CREATE_FUNCTION.search(code):
            obj["requiresManualReview"] = True
            obj["confidenceScore"] = lowest(obj.get("confidenceScore"), "LOW")
            obj.setdefault("reviewGuidance", []).append(
                {"reason": "PG-081: model emitted CREATE FUNCTION for a PROCEDURE object; verify CALL semantics manually", "priority": "HIGH"}
            )
            audit.append({"reason": "PG-081", "callee": f"{obj['schema']}.{obj['name']}", "caller": None, "action": "FLAGGED_FOR_REVIEW"})


def resolve_dependencies(plan: list[dict[str, Any]]) -> dict[str, Any]:
    """Run Pass 2 over an already-converted plan. Mutates plan entries in place."""
    audit: list[dict[str, Any]] = []
    exec_rewrites = apply_exec_to_call(plan)
    apply_synonym_resolution(plan, audit)
    apply_udt_elimination(plan, audit)
    flag_manual_review_callers(plan, audit)
    check_procedure_not_downgraded(plan, audit)
    return {
        "execToCallRewrites": exec_rewrites,
        "callerUpdates": audit,
        "flaggedCallers": sum(1 for a in audit if a.get("action") == "FLAGGED_FOR_REVIEW"),
        "autoPatched": sum(1 for a in audit if a["reason"] in AUTO_PATCH_REASONS),
    }
