"""Pass 4: render the 16 phase scripts, complete schema, summary, checklist and zip."""

from __future__ import annotations

import csv
import json
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.services.oracle_pg.report_metrics import format_duration
from app.services.mssql_pg.input_validator import is_placeholder_scan_database_id
from app.services.mssql_pg.hooks import append_log
from app.services.mssql_pg.progress import PHASE_ARTIFACTS, SCRIPT_ORDER, load_conversion_plan, load_progress
from app.services.mssql_pg.report_status import (
    STATUS_AUTO,
    STATUS_FAILED,
    STATUS_MANUAL,
    STATUS_REVIEW,
    count_ui_statuses,
    resolve_ui_conversion_status,
)
from app.services.mssql_pg.workspace import output_dir
from app.services.oracle_pg.live_logs import icon_color

MANUAL_REVIEW_CSV = "Manual_Review_Checklist.csv"


def _report_database_id(job_config: dict[str, Any], artifact_prefix: str) -> str:
    """Shown as Database ID in post-transformation JSON; skip Compass placeholder ids."""
    cid = job_config.get("dbId")
    if cid and not is_placeholder_scan_database_id(cid):
        return str(cid)
    return artifact_prefix
TRANSFORMATION_SUMMARY_JSON = "transformation_summary.json"
POST_TRANSFORMATION_REPORT_JSON = "post_transformation_report.json"

CONFIDENCE_SORT = {"MANUAL": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3}

PHASE_LABELS = {
    1: "Schemas",
    2: "Sequences",
    3: "Types (domains and composite types)",
    4: "Tables (partition function notes inline)",
    5: "Primary Keys (partition scheme notes inline)",
    6: "Unique Constraints",
    7: "Foreign Keys",
    8: "Check Constraints",
    9: "Indexes",
    10: "Views",
    11: "Materialized Views",
    12: "Functions",
    13: "Procedures",
    14: "Triggers",
    15: "Row Security Policies / DDM / Always Encrypted",
    16: "Synonyms",
}


def script_name(db_id: str, phase: int) -> str:
    suffix = SCRIPT_ORDER[phase - 1] if 1 <= phase <= len(SCRIPT_ORDER) else SCRIPT_ORDER[-1]
    return f"{db_id}_{suffix}"


def expected_script_names(db_id: str) -> list[str]:
    return [f"{db_id}_{suffix}" for suffix in SCRIPT_ORDER]


def listed_script_names(db_id: str) -> list[str]:
    """All 16 ticket phase scripts under ``output/`` — same names as zip contents."""
    return [f"{db_id}_{suffix}" for suffix in SCRIPT_ORDER]


def _source_location(obj: dict[str, Any]) -> str:
    source = obj.get("sourceCode") or {}
    file_name = source.get("file_name") or ""
    start = source.get("start_line")
    end = source.get("end_line")
    if file_name and start and end:
        return f"{file_name}:{start}-{end}"
    return file_name or ""


def _limit_words(text: str, limit: int) -> str:
    words = str(text or "").split()
    if len(words) <= limit:
        return " ".join(words)
    return " ".join(words[:limit])


def _object_header(obj: dict[str, Any]) -> str:
    source = _source_location(obj)
    lines = [
        f"-- Converted from MSSQL {obj['type']} {obj['schema']}.{obj['name']}",
        f"-- Source: {source or 'AS-IS / generated'}",
        f"-- Confidence: {obj.get('confidenceScore') or 'N/A'}",
    ]
    for finding in obj.get("incompatibilities") or []:
        rule_id = finding.get("rule_id")
        if rule_id:
            note = (finding.get("remediation") or {}).get("note_template") or finding.get("description") or "applied"
            lines.append(f"-- Remediation {rule_id}: {_limit_words(note, 50)}")
    if obj.get("requiresManualReview"):
        lines.append("-- *** REQUIRES MANUAL REVIEW ***")
        for guidance in obj.get("reviewGuidance") or []:
            reason = _limit_words(str(guidance.get("reason") or ""), 100)
            lines.append(f"--   - [{guidance.get('priority', 'MEDIUM')}] {reason}")
    for comment in obj.get("comments") or []:
        lines.append(f"-- Note: {_limit_words(comment, 50)}")
    return "\n".join(lines)


def render_phase_script(objects: list[dict[str, Any]]) -> str:
    ordered = sorted(objects, key=lambda o: (o.get("phaseOrder") is None, o.get("phaseOrder", 0)))
    blocks = []
    for obj in ordered:
        code = (obj.get("convertedCode") or "").strip()
        if not code:
            continue
        blocks.append(f"{_object_header(obj)}\n{code}")
    if not blocks:
        return "-- (no objects in this phase)"
    return "\n\n-- ----------\n\n".join(blocks)


def write_phase_scripts(job_id: str, db_id: str, plan: list[dict[str, Any]], workspace_override: Optional[str] = None) -> list[str]:
    out = output_dir(job_id, workspace_override)
    out.mkdir(parents=True, exist_ok=True)
    by_phase: dict[int, list[dict[str, Any]]] = {}
    for obj in plan:
        phase = int(obj.get("executionPhase") or 4)
        by_phase.setdefault(phase, []).append(obj)

    written = []
    if not by_phase.get(1):
        schemas = sorted({str(o.get("schema") or "dbo") for o in plan if o.get("schema")})
        if schemas:
            by_phase[1] = [
                {
                    "type": "SCHEMA",
                    "schema": name,
                    "name": name,
                    "phaseOrder": 0,
                    "convertedCode": f"CREATE SCHEMA IF NOT EXISTS {name};",
                    "confidenceScore": "HIGH",
                    "sourceCode": {},
                    "incompatibilities": [],
                    "requiresManualReview": False,
                    "reviewGuidance": [],
                    "comments": ["Synthesized from object schemas; AS-IS had no SCHEMA objects"],
                }
                for name in schemas
            ]

    for phase in range(1, len(SCRIPT_ORDER) + 1):
        label = PHASE_LABELS.get(phase, "")
        content = render_phase_script(by_phase.get(phase, []))
        path = out / script_name(db_id, phase)
        count = len(by_phase.get(phase, []))
        generated = datetime.now(timezone.utc).isoformat()
        header = (
            f"-- ========== Phase {phase}: {label} ==========\n"
            f"-- Object count: {count}\n"
            f"-- Execution order: ticket AC5 phase {phase}; within the phase, topological then alphabetical.\n"
            f"-- Generated at: {generated}\n\n"
        )
        path.write_text(f"{header}{content}\n", encoding="utf-8")
        written.append(path.name)
    return written


def build_complete_schema(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> Path:
    out = output_dir(job_id, workspace_override)
    complete_path = out / f"{db_id}_complete_schema.sql"
    parts: list[str] = []
    for phase in range(1, len(SCRIPT_ORDER) + 1):
        script_path = out / script_name(db_id, phase)
        content = script_path.read_text(encoding="utf-8", errors="replace").strip() if script_path.is_file() else f"-- (missing {script_name(db_id, phase)})"
        parts.append(content)
    complete_path.write_text("\n\n".join(parts).strip() + "\n", encoding="utf-8")
    return complete_path


def validate_complete_schema_matches(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> bool:
    """AC check: complete_schema.sql must be an exact concatenation of the 16 phase scripts."""
    out = output_dir(job_id, workspace_override)
    expected_parts = []
    for phase in range(1, len(SCRIPT_ORDER) + 1):
        script_path = out / script_name(db_id, phase)
        content = script_path.read_text(encoding="utf-8", errors="replace").strip() if script_path.is_file() else f"-- (missing {script_name(db_id, phase)})"
        expected_parts.append(content)
    expected = "\n\n".join(expected_parts).strip() + "\n"
    complete_path = out / f"{db_id}_complete_schema.sql"
    if not complete_path.is_file():
        return False
    return complete_path.read_text(encoding="utf-8", errors="replace") == expected


def _include_in_manual_review(obj: dict[str, Any]) -> bool:
    if obj.get("requiresManualReview"):
        return True
    return str(obj.get("confidenceScore", "")).upper() in {"LOW", "MANUAL"} or obj.get("status") == "failed"


def _phase_file_name(obj: dict[str, Any], db_id: str = "") -> str:
    raw = str(obj.get("outputFile") or "")
    if not raw:
        return ""
    prefix = f"{db_id}_" if db_id else ""
    if prefix and not raw.startswith(prefix):
        return f"{prefix}{raw}"
    return raw


def build_manual_review_checklist(plan: list[dict[str, Any]], db_id: str = "") -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for obj in plan:
        if not _include_in_manual_review(obj):
            continue
        guidance = obj.get("reviewGuidance") or []
        reason = "; ".join(g.get("reason", "") for g in guidance) if guidance else ("; ".join(obj.get("comments") or []) or "Low confidence conversion")
        source = f"{obj.get('schema', '')}.{obj.get('name', '')}"
        converted = obj.get("convertedName") or source
        phase_file = _phase_file_name(obj, db_id)
        rows.append(
            {
                "Source Object": source,
                "Converted Object": converted,
                "Object Type": str(obj.get("type", "")),
                "Confidence": str(obj.get("confidenceScore") or "MEDIUM").upper(),
                "Review Reason": reason,
                "Source Location": _source_location(obj),
                "Output Location": phase_file,
                "Phase File": phase_file,
            }
        )
    rows.sort(key=lambda r: (CONFIDENCE_SORT.get(r["Confidence"], 9), r["Object Type"], r["Source Object"]))
    return rows


FIELDNAMES = [
    "Source Object",
    "Converted Object",
    "Object Type",
    "Confidence",
    "Review Reason",
    "Source Location",
    "Output Location",
    "Phase File",
]
assert len(FIELDNAMES) == 8

_REPORT_TYPE_ORDER = (
    "Tables",
    "Views",
    "Stored Procedures",
    "Functions",
    "Packages",
    "Triggers",
    "Indexes",
    "Constraints",
    "Others",
)
_TYPE_TO_REPORT_ROW = {
    "TABLE": "Tables",
    "VIEW": "Views",
    "MATERIALIZED_VIEW": "Views",
    "PROCEDURE": "Stored Procedures",
    "FUNCTION": "Functions",
    "TRIGGER": "Triggers",
    "INDEX": "Indexes",
    "PRIMARY_KEY": "Constraints",
    "UNIQUE_CONSTRAINT": "Constraints",
    "FOREIGN_KEY": "Constraints",
    "CHECK_CONSTRAINT": "Constraints",
    "DEFAULT_CONSTRAINT": "Constraints",
}


def _timing_block(progress: Optional[dict[str, Any]]) -> dict[str, Any]:
    started = (progress or {}).get("startedAt")
    completed = (progress or {}).get("completedAt")
    duration_seconds = None
    if started and completed:
        try:
            start_dt = datetime.fromisoformat(str(started).replace("Z", "+00:00"))
            end_dt = datetime.fromisoformat(str(completed).replace("Z", "+00:00"))
            duration_seconds = max(0, int((end_dt - start_dt).total_seconds()))
        except ValueError:
            duration_seconds = None
    return {
        "startedAt": started,
        "completedAt": completed,
        "durationSeconds": duration_seconds,
        "duration": format_duration(duration_seconds),
    }


def _objects_by_type(plan: list[dict[str, Any]]) -> list[dict[str, Any]]:
    buckets: dict[str, Counter[str]] = {label: Counter() for label in _REPORT_TYPE_ORDER}
    for obj in plan:
        label = _TYPE_TO_REPORT_ROW.get(str(obj.get("type", "")).upper(), "Others")
        buckets[label][resolve_ui_conversion_status(obj)] += 1
        buckets[label]["total"] += 1
    rows = []
    for object_type in _REPORT_TYPE_ORDER:
        counts = buckets[object_type]
        total = int(counts.get("total") or 0)
        auto = int(counts.get(STATUS_AUTO) or 0)
        review = int(counts.get(STATUS_REVIEW) or 0)
        manual = int(counts.get(STATUS_MANUAL) or 0)
        rows.append(
            {
                "objectType": object_type,
                "total": total,
                "autoConverted": auto,
                "needReview": review,
                "manualEffortRequired": manual,
                "conversionRatePercent": round(((auto + review + manual) / total) * 100, 1) if total else 0.0,
            }
        )
    return rows


def _generated_scripts(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> list[dict[str, Any]]:
    out = output_dir(job_id, workspace_override)
    names = [f"{db_id}_complete_schema.sql", *listed_script_names(db_id)]
    scripts = []
    for name in names:
        path = out / name
        scripts.append(
            {
                "name": name,
                "path": str(path),
                "exists": path.exists(),
                "sizeBytes": path.stat().st_size if path.exists() else 0,
            }
        )
    return scripts


def write_manual_review_csv(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> Path:
    plan = load_conversion_plan(job_id)
    rows = build_manual_review_checklist(plan, db_id)
    path = output_dir(job_id, workspace_override) / MANUAL_REVIEW_CSV
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)
    return path


def build_transformation_summary(
    plan: list[dict[str, Any]],
    skipped: list[dict[str, Any]],
    job_config: dict[str, Any],
    db_id: str,
    *,
    progress: Optional[dict[str, Any]] = None,
    total_objects_expected: Optional[int] = None,
    job_id: Optional[str] = None,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    converted = sum(1 for o in plan if o.get("conversionStatus") in {"SUCCESS", "PARTIAL"})
    failed = sum(1 for o in plan if o.get("conversionStatus") == "UNCONVERTIBLE")
    total = len(plan) + len(skipped)

    type_counts: Counter[str] = Counter(str(o.get("type", "")).upper() for o in plan if o.get("conversionStatus") in {"SUCCESS", "PARTIAL"})
    confidence_counts: Counter[str] = Counter(str(o.get("confidenceScore", "")).upper() for o in plan)
    ui_counts = count_ui_statuses(plan)
    auto_converted = ui_counts[STATUS_AUTO]
    review_count = ui_counts[STATUS_REVIEW] + ui_counts[STATUS_MANUAL]
    conversion_rate = f"{round((converted / total) * 100)}%" if total else "0%"
    auto_rate = f"{round((auto_converted / total) * 100)}%" if total else "0%"
    could_not_convert = sum(
        1 for o in plan if o.get("conversionStatus") == "UNCONVERTIBLE" or o.get("isClr") or o.get("isEncrypted")
    )

    pass2 = (progress or {}).get("pass2") or {}
    caller_updates = int(pass2.get("autoPatched") or 0) + int(pass2.get("flaggedCallers") or 0)
    instead_of = int(pass2.get("insteadOfConversions") or 0)

    reconciliation_errors: list[str] = []
    if converted + failed + len(skipped) != total:
        reconciliation_errors.append(f"converted({converted}) + failed({failed}) + skipped({len(skipped)}) != total({total})")
    if total_objects_expected is not None and total_objects_expected != total:
        reconciliation_errors.append(f"AS-IS total_objects({total_objects_expected}) != assembled total({total})")

    summary: dict[str, Any] = {
        "database": {
            "id": _report_database_id(job_config, db_id),
            "name": job_config.get("dbName") or db_id,
            "from": job_config.get("sourceDatabaseVersion") or "SQL Server",
            "to": f"PostgreSQL {job_config.get('targetDatabaseVersion', '16')}",
        },
        "conversionResult": {
            "total_objects": total,
            "converted": converted,
            "deliverable_converted": converted,
            "failed": failed,
            "skipped": len(skipped),
            "conversion_rate": conversion_rate,
            "auto_conversion_rate": auto_rate,
        },
        "whatWasConverted": {
            "tables": type_counts.get("TABLE", 0),
            "procedures": type_counts.get("PROCEDURE", 0),
            "functions": type_counts.get("FUNCTION", 0),
            "triggers": type_counts.get("TRIGGER", 0),
            "views": type_counts.get("VIEW", 0),
            "materialized_views": type_counts.get("MATERIALIZED_VIEW", 0),
            "sequences": type_counts.get("SEQUENCE", 0),
            "types": type_counts.get("USER_DEFINED_TYPE", 0),
            "synonyms": type_counts.get("SYNONYM", 0),
            "security_policies": type_counts.get("RLS_POLICY", 0) + type_counts.get("DDM_DEFINITION", 0) + type_counts.get("AE_DEFINITION", 0),
            "could_not_convert": could_not_convert,
        },
        "reviewNeeded": {
            "objects_requiring_review": review_count,
            "high_confidence_objects": confidence_counts.get("HIGH", 0),
            "medium_confidence_objects": confidence_counts.get("MEDIUM", 0),
            "low_confidence_objects": confidence_counts.get("LOW", 0),
            "could_not_convert": could_not_convert,
        },
        "pass2": {
            "caller_updates_count": caller_updates,
            "instead_of_conversions_logged": instead_of,
        },
        "skippedObjects": skipped,
        "reconciliation": {
            "isConsistent": not reconciliation_errors,
            "errors": reconciliation_errors,
        },
        "timing": _timing_block(progress),
        "warnings": (progress or {}).get("warnings", []),
        "executiveSummary": {
            "successfullyConverted": auto_converted,
            "requiresReview": review_count,
            "failed": ui_counts[STATUS_FAILED],
            "totalObjects": len(plan),
        },
        "objectsByType": _objects_by_type(plan),
        "confidenceBreakdown": {
            "high": confidence_counts.get("HIGH", 0),
            "medium": confidence_counts.get("MEDIUM", 0),
            "low": confidence_counts.get("LOW", 0),
            "manualRequired": confidence_counts.get("MANUAL", 0),
        },
        "databaseMetadata": {
            "databaseId": _report_database_id(job_config, db_id),
            "name": job_config.get("dbName") or db_id,
            "owner": "default",
            "description": None,
            "sourceDatabase": job_config.get("sourceDatabaseVersion") or "SQL Server",
            "targetDatabase": f"PostgreSQL {job_config.get('targetDatabaseVersion', '16')}",
        },
    }
    if job_id is not None:
        summary["generatedScripts"] = _generated_scripts(job_id, db_id, workspace_override)
    return summary


def write_transformation_summary(
    job_id: str,
    db_id: str,
    job_config: dict[str, Any],
    skipped: list[dict[str, Any]],
    *,
    total_objects_expected: Optional[int] = None,
    workspace_override: Optional[str] = None,
) -> Path:
    plan = load_conversion_plan(job_id)
    progress = load_progress(job_id)
    summary = build_transformation_summary(
        plan,
        skipped,
        job_config,
        db_id,
        progress=progress,
        total_objects_expected=total_objects_expected,
        job_id=job_id,
        workspace_override=workspace_override,
    )
    path = output_dir(job_id, workspace_override) / TRANSFORMATION_SUMMARY_JSON
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    return path


def write_post_transformation_report(
    job_id: str,
    db_id: str,
    job_config: dict[str, Any],
    skipped: list[dict[str, Any]],
    *,
    total_objects_expected: Optional[int] = None,
    workspace_override: Optional[str] = None,
) -> Path:
    plan = load_conversion_plan(job_id)
    progress = load_progress(job_id)
    summary = build_transformation_summary(
        plan,
        skipped,
        job_config,
        db_id,
        progress=progress,
        total_objects_expected=total_objects_expected,
        job_id=job_id,
        workspace_override=workspace_override,
    )
    converted = summary["conversionResult"]["converted"]
    total = summary["conversionResult"]["total_objects"]
    ui_counts = count_ui_statuses(plan)
    report = {
        "jobId": job_config.get("jobId") or job_id,
        "dbName": job_config.get("dbName") or db_id,
        "timing": summary["timing"],
        "summary": {
            "totalObjects": summary["executiveSummary"]["totalObjects"],
            "deliverableConverted": summary["conversionResult"]["deliverable_converted"],
            "deliverableConversionRatePercent": round((converted / total) * 100, 1) if total else 0.0,
            "autoConverted": ui_counts[STATUS_AUTO],
            "requireReview": ui_counts[STATUS_REVIEW],
            "manualImplementation": ui_counts[STATUS_MANUAL],
            "failed": ui_counts[STATUS_FAILED],
        },
        "executiveSummary": summary["executiveSummary"],
        "confidenceBreakdown": {
            "high": summary["confidenceBreakdown"]["high"],
            "medium": summary["confidenceBreakdown"]["medium"],
            "low": summary["confidenceBreakdown"]["low"],
            "manual": summary["confidenceBreakdown"]["manualRequired"],
            "manualRequired": summary["confidenceBreakdown"]["manualRequired"],
        },
        "objectsByType": summary["objectsByType"],
        "databaseMetadata": summary["databaseMetadata"],
        "generatedScripts": summary.get("generatedScripts") or _generated_scripts(job_id, db_id, workspace_override),
        "validationWarnings": summary.get("warnings") or [],
        "skippedObjects": skipped,
        "inputSources": dict(job_config.get("inputPaths") or {}),
    }
    path = output_dir(job_id, workspace_override) / POST_TRANSFORMATION_REPORT_JSON
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    return path


def create_scripts_zip(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> Path:
    out = output_dir(job_id, workspace_override)
    zip_path = out / f"{db_id}_postgresql_scripts.zip"
    extras = [f"{db_id}_complete_schema.sql", TRANSFORMATION_SUMMARY_JSON, POST_TRANSFORMATION_REPORT_JSON, MANUAL_REVIEW_CSV]
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in extras:
            path = out / name
            if path.exists():
                zf.write(path, arcname=name)
        for name in expected_script_names(db_id):
            path = out / name
            if path.exists():
                zf.write(path, arcname=name)
    return zip_path


def list_artifacts(job_id: str, db_id: str, workspace_override: Optional[str] = None) -> list[dict[str, Any]]:
    out = output_dir(job_id, workspace_override)
    candidates = [f"{db_id}_complete_schema.sql", TRANSFORMATION_SUMMARY_JSON, POST_TRANSFORMATION_REPORT_JSON, MANUAL_REVIEW_CSV, f"{db_id}_postgresql_scripts.zip"]
    candidates.extend(listed_script_names(db_id))
    artifacts = []
    for name in candidates:
        path = out / name
        if path.exists():
            artifacts.append({"name": name, "path": str(path), "sizeBytes": path.stat().st_size})
    return artifacts


def _log_file_written(job_id: str, name: str) -> None:
    """One live-log line per generated file, same shape as Oracle's file-written events."""
    append_log(job_id, PHASE_ARTIFACTS, f"Wrote {name}", icon="check", color=icon_color("check"))


def package_all_artifacts(
    job_id: str,
    db_id: str,
    job_config: dict[str, Any],
    plan: list[dict[str, Any]],
    skipped: list[dict[str, Any]],
    *,
    total_objects_expected: Optional[int] = None,
    workspace_override: Optional[str] = None,
) -> dict[str, Any]:
    """Run Pass 4 end-to-end and return a small report of what was produced.

    ``db_id`` is the output-file prefix. Callers pass ``job_config["dbName"]`` so the
    file names match the Oracle artifact URLs, which look files up by dbName.
    """
    created = write_phase_scripts(job_id, db_id, plan, workspace_override)
    for name in created:
        _log_file_written(job_id, name)
    build_complete_schema(job_id, db_id, workspace_override)
    created.append(f"{db_id}_complete_schema.sql")
    _log_file_written(job_id, created[-1])
    schema_ok = validate_complete_schema_matches(job_id, db_id, workspace_override)
    write_transformation_summary(job_id, db_id, job_config, skipped, total_objects_expected=total_objects_expected, workspace_override=workspace_override)
    created.append(TRANSFORMATION_SUMMARY_JSON)
    _log_file_written(job_id, TRANSFORMATION_SUMMARY_JSON)
    write_post_transformation_report(job_id, db_id, job_config, skipped, total_objects_expected=total_objects_expected, workspace_override=workspace_override)
    created.append(POST_TRANSFORMATION_REPORT_JSON)
    _log_file_written(job_id, POST_TRANSFORMATION_REPORT_JSON)
    write_manual_review_csv(job_id, db_id, workspace_override)
    created.append(MANUAL_REVIEW_CSV)
    _log_file_written(job_id, MANUAL_REVIEW_CSV)
    zip_path = create_scripts_zip(job_id, db_id, workspace_override)
    created.append(zip_path.name)
    _log_file_written(job_id, zip_path.name)
    return {"dbId": db_id, "filesCreated": created, "completeSchemaValid": schema_ok}
