"""Detect T-SQL constructs in source DDL when AS-IS feature flags are absent."""

from __future__ import annotations

import re
from typing import Any

_PATTERNS: dict[str, re.Pattern[str]] = {
    "has_error_handling": re.compile(r"(?i)\bBEGIN\s+TRY\b"),
    "has_transaction_control": re.compile(
        r"(?i)\b(BEGIN\s+TRAN(SACTION)?|COMMIT(\s+TRAN(SACTION)?)?|ROLLBACK(\s+TRAN(SACTION)?)?|SAVE\s+TRAN(SACTION)?)\b"
    ),
    "has_dynamic_sql": re.compile(r"(?i)(\bsp_executesql\b|\bEXEC(UTE)?\s*\(\s*@)"),
    "has_cursor": re.compile(r"(?i)\bCURSOR\b"),
    "has_temp_tables": re.compile(r"(?i)(CREATE\s+TABLE\s+#|INTO\s+#|\bFROM\s+#)"),
    "has_global_temp_tables": re.compile(r"##\w+"),
    "has_linked_server_calls": re.compile(r"(?i)\bOPENQUERY\b|\bOPENROWSET\b|(\[?\w+\]?\.){3}\[?\w+\]?\s*\("),
    "uses_scope_identity": re.compile(r"(?i)(SCOPE_IDENTITY\s*\(|@@IDENTITY\b|IDENT_CURRENT\s*\()"),
    "uses_raiserror": re.compile(r"(?i)\bRAISERROR\b"),
    "uses_throw": re.compile(r"(?i)\bTHROW\b"),
    "uses_pivot": re.compile(r"(?i)\b(UN)?PIVOT\b"),
    "uses_for_xml": re.compile(r"(?i)\bFOR\s+XML\b"),
    "uses_apply": re.compile(r"(?i)\b(CROSS|OUTER)\s+APPLY\b"),
    "uses_top": re.compile(r"(?i)\bSELECT\s+(DISTINCT\s+)?TOP\b"),
    "uses_table_valued_parameter": re.compile(r"(?i)\bREADONLY\b"),
    "uses_tsql_specific": re.compile(
        r"(?i)\b(ISNULL|GETDATE|GETUTCDATE|SYSDATETIME|CONVERT|DATEADD|DATEDIFF|DATEPART|DATEFROMPARTS|"
        r"EOMONTH|FORMAT|NOCOUNT|@@ROWCOUNT|@@ERROR|SCOPE_IDENTITY|IIF|LEN|CHARINDEX)\b"
    ),
}


def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"--[^\n]*", " ", text)


def detect_features(ddl: str | None) -> dict[str, bool]:
    if not ddl:
        return {}
    body = _strip_comments(ddl)
    found = {name: bool(pattern.search(body)) for name, pattern in _PATTERNS.items()}
    found["is_multi_branch"] = bool(re.search(r"(?i)\bIF\b.*\bELSE\b", body, flags=re.S))
    return found


def merged_features(obj: dict[str, Any]) -> dict[str, bool]:
    """AS-IS feature flags win; DDL detection fills in anything not declared."""
    meta = obj.get("structuralMetadata") or {}
    merged = detect_features((obj.get("sourceCode") or {}).get("ddl"))
    declared = meta.get("features")
    if isinstance(declared, dict):
        for key, value in declared.items():
            if isinstance(value, bool):
                merged[key] = value
    for key in ("is_clr", "is_encrypted", "is_instead_of", "is_schema_bound"):
        if key in meta:
            merged[key] = bool(meta[key])
    return merged
