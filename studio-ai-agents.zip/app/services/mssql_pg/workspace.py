"""Job workspace paths for MSSQL → PostgreSQL transformation.

Jobs live in the same package as every other database type:
``{claude_workspace}/schema-modernization/{dbName}/``. Compass artifacts are
already staged under ``{job}/_claude/`` before launch. ``job_config.json``
records ``engine: mssql`` so read APIs do not treat the folder as Oracle.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from app.core.config import get_settings
from app.core.security import SecurityValidator
from app.services.oracle_pg.workspace import MODERNIZATION_SUBDIR

WORKSPACE_SUBDIR = MODERNIZATION_SUBDIR
CLAUDE_SUBDIR = "_claude"

# Same names as Oracle. schemaAnalysis is optional on the Pydantic body so
# studio-core can send one JSON shape; launch still requires the file because
# MSSQL Pass 3 reads execution_order from it.
REQUIRED_INPUT_PATH_KEYS = (
    "ddlExport",
    "asisSchema",
    "incompatibilityResults",
    "rulesRemediation",
    "schemaAnalysis",
)
INPUT_PATH_KEYS = (
    "ddlExport",
    "asisSchema",
    "incompatibilityResults",
    "rulesRemediation",
    "schemaAnalysis",
)


def workspace_base(workspace_override: Optional[str] = None) -> Path:
    if workspace_override:
        return Path(workspace_override)
    return Path(get_settings().claude_workspace)


def jobs_base(workspace_override: Optional[str] = None) -> Path:
    return workspace_base(workspace_override) / WORKSPACE_SUBDIR


def job_root(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return jobs_base(workspace_override) / db_name


def claude_inputs_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / CLAUDE_SUBDIR


def job_config_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "job_config.json"


def state_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "state"


def output_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "output"


def stream_dir(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return job_root(db_name, workspace_override) / "stream"


def conversion_plan_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "conversion-plan.json"


def progress_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "progress.json"


def events_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "events.jsonl"


def logs_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "logs.jsonl"


def logs_meta_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return stream_dir(db_name, workspace_override) / "logs.meta.json"


def ddl_index_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "ddl_index.json"


def skipped_objects_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "skipped_objects.json"


def dependency_resolution_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "dependency_resolution.json"


def execution_order_path(db_name: str, workspace_override: Optional[str] = None) -> Path:
    return state_dir(db_name, workspace_override) / "execution_order.json"


def ensure_path_under_job_root(
    db_name: str,
    candidate: Path,
    workspace_override: Optional[str] = None,
) -> Path:
    """Resolve ``candidate`` (relative or absolute) and reject anything outside the job root."""
    allowed_root = job_root(db_name, workspace_override).resolve()
    canonical = candidate.resolve() if candidate.is_absolute() else (allowed_root / candidate).resolve()
    try:
        canonical.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(f"Path traversal detected: '{candidate}' is outside job workspace '{allowed_root}'") from exc
    return canonical


def ensure_path_under_jobs_base(path: Path, workspace_override: Optional[str] = None) -> Path:
    allowed_root = jobs_base(workspace_override).resolve()
    canonical = path.resolve()
    try:
        canonical.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(f"Path traversal detected: '{path}' is outside jobs base '{allowed_root}'") from exc
    return canonical


def resolve_job_path(db_name: str, relative_or_absolute: str, workspace_override: Optional[str] = None) -> Path:
    """Resolve an ``inputPaths`` entry relative to the job root; must stay under that root."""
    return ensure_path_under_job_root(db_name, Path(relative_or_absolute), workspace_override)


def _resolve_input_file_path(db_name: str, raw: str, workspace_override: Optional[str] = None) -> Path:
    """Accept a bare file name, a path relative to ``_claude``, or an absolute path under the job root."""
    candidate = Path(raw)
    if candidate.is_absolute():
        return ensure_path_under_job_root(db_name, candidate, workspace_override)
    direct = resolve_job_path(db_name, raw, workspace_override)
    if direct.is_file():
        return direct
    return ensure_path_under_job_root(db_name, Path(CLAUDE_SUBDIR) / candidate.name, workspace_override)


def validate_under_claude_dir(db_name: str, path: Path, workspace_override: Optional[str] = None) -> Path:
    allowed_root = claude_inputs_dir(db_name, workspace_override).resolve()
    canonical = path.resolve()
    try:
        canonical.relative_to(allowed_root)
    except ValueError as exc:
        raise ValueError(f"inputPaths must resolve under {CLAUDE_SUBDIR}/: got '{path}'") from exc
    return canonical


def relative_to_job_root(db_name: str, path: Path, workspace_override: Optional[str] = None) -> str:
    root = job_root(db_name, workspace_override).resolve()
    return str(path.resolve().relative_to(root)).replace("\\", "/")


def reset_job_conversion_state(db_name: str, workspace_override: Optional[str] = None) -> None:
    """Drop stale plan/order/stream files so a new launch does not resume or replay an old job."""
    for path in (
        conversion_plan_path(db_name, workspace_override),
        skipped_objects_path(db_name, workspace_override),
        dependency_resolution_path(db_name, workspace_override),
        execution_order_path(db_name, workspace_override),
        ddl_index_path(db_name, workspace_override),
        events_path(db_name, workspace_override),
        logs_path(db_name, workspace_override),
        logs_meta_path(db_name, workspace_override),
    ):
        if path.is_file():
            path.unlink()


def ensure_job_dirs(db_name: str, workspace_override: Optional[str] = None) -> Path:
    SecurityValidator.validate_alphanumeric(db_name.replace("-", "_"), "dbName")
    root = job_root(db_name, workspace_override)
    for sub in (CLAUDE_SUBDIR, "state", "output", "stream"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    return root


def read_json_file(path: Path) -> Optional[dict[str, Any]]:
    if not path.is_file():
        return None
    try:
        with path.open(encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def write_json_file(path: Path, payload: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    return path


def resolve_folder_key(job_id: str, workspace_override: Optional[str] = None) -> Optional[str]:
    """Map an API jobId to its on-disk folder (dbName) under schema-modernization."""
    if job_root(job_id, workspace_override).exists():
        return job_id
    base = jobs_base(workspace_override)
    if not base.exists():
        return None
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        data = read_json_file(child / "job_config.json")
        if data and (data.get("jobId") == job_id or data.get("dbName") == job_id):
            return child.name
    return None
