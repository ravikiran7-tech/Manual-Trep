"""Pass 1, step 1: assemble a conversion-plan entry for each AS-IS object (ticket AC2)."""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

from app.services.mssql_pg.confidence import AI_ANALYZED_TYPES, lowest, structural_floor
from app.services.mssql_pg.tsql_features import merged_features
from app.services.mssql_pg.ddl_extractor import DdlBlock, lookup_block
from app.services.mssql_pg.progress import EXECUTION_PHASE_BY_TYPE

WALK_ORDER = (
    ("schemas", "SCHEMA"),
    ("sequences", "SEQUENCE"),
    ("user_defined_types", "USER_DEFINED_TYPE"),
    ("partition_functions", "PARTITION_FUNCTION"),
    ("partition_schemes", "PARTITION_SCHEME"),
    ("tables", "TABLE"),
    ("constraints", None),
    ("indexes", "INDEX"),
    ("views", "VIEW"),
    ("materialized_views", "MATERIALIZED_VIEW"),
    ("functions", "FUNCTION"),
    ("stored_procedures", "PROCEDURE"),
    ("procedures", "PROCEDURE"),
    ("triggers", "TRIGGER"),
    ("synonyms", "SYNONYM"),
    ("linked_servers", "LINKED_SERVER"),
    ("rls_policies", "RLS_POLICY"),
    ("security_policies", "RLS_POLICY"),
    ("masked_column_definitions", "DDM_DEFINITION"),
    ("encrypted_column_definitions", "AE_DEFINITION"),
)

BODY_REQUIRED = frozenset({"VIEW", "MATERIALIZED_VIEW", "FUNCTION", "PROCEDURE", "TRIGGER"})
SECURITY_TYPES = frozenset({"RLS_POLICY", "DDM_DEFINITION", "AE_DEFINITION"})

CONSTRAINT_TYPES = {
    "PRIMARY_KEY": "PRIMARY_KEY",
    "PK": "PRIMARY_KEY",
    "UNIQUE": "UNIQUE_CONSTRAINT",
    "UNIQUE_KEY": "UNIQUE_CONSTRAINT",
    "UNIQUE_CONSTRAINT": "UNIQUE_CONSTRAINT",
    "UQ": "UNIQUE_CONSTRAINT",
    "FOREIGN_KEY": "FOREIGN_KEY",
    "FK": "FOREIGN_KEY",
    "CHECK": "CHECK_CONSTRAINT",
    "CHECK_CONSTRAINT": "CHECK_CONSTRAINT",
    "DEFAULT": "DEFAULT_CONSTRAINT",
    "DEFAULT_CONSTRAINT": "DEFAULT_CONSTRAINT",
}

AI_SECTION_BY_TYPE: dict[str, tuple[str, ...]] = {
    "TABLE": ("tables",),
    "VIEW": ("views",),
    "MATERIALIZED_VIEW": ("materialized_views", "views"),
    "FUNCTION": ("functions",),
    "PROCEDURE": ("stored_procedures", "procedures"),
    "TRIGGER": ("triggers",),
    "INDEX": ("indexes",),
    "SYNONYM": ("synonyms",),
    "USER_DEFINED_TYPE": ("user_defined_types", "types"),
    "SEQUENCE": ("sequences",),
}
assert set(AI_SECTION_BY_TYPE) == AI_ANALYZED_TYPES

_NAME_KEYS = (
    "name",
    "object_name",
    "constraint_name",
    "index_name",
    "policy_name",
    "synonym_name",
    "trigger_name",
    "view_name",
    "type_name",
    "function_name",
    "procedure_name",
    "server_name",
)
_SKIP_META_KEYS = frozenset({"definition", "source_code", "ddl"})


def _object_name(item: dict[str, Any], object_type: Optional[str]) -> str:
    if object_type in {"DDM_DEFINITION", "AE_DEFINITION"} and item.get("column_name") and not item.get("name"):
        return f"{item.get('table_name') or item.get('table')}.{item['column_name']}"
    for key in _NAME_KEYS:
        if item.get(key):
            return str(item[key]).strip()
    return ""


def _schema(item: dict[str, Any]) -> str:
    return str(item.get("schema") or item.get("schema_name") or item.get("owner_schema") or "dbo").strip()


def _norm_constraint_type(item: dict[str, Any]) -> str:
    raw = str(item.get("constraint_type") or item.get("type") or "CHECK").upper().replace(" ", "_")
    return CONSTRAINT_TYPES.get(raw, "CHECK_CONSTRAINT")


def _owning_table(item: dict[str, Any], object_type: str) -> Optional[str]:
    for key in ("owning_table", "owner_table", "table_name", "parent_table", "table", "target_table"):
        value = item.get(key)
        if value:
            value = str(value)
            return value if "." in value else f"{item.get('table_schema') or _schema(item)}.{value}"
    if object_type in SECURITY_TYPES:
        predicates = item.get("predicates")
        if isinstance(predicates, list) and predicates and isinstance(predicates[0], dict):
            target = predicates[0].get("target_table")
            if target:
                return str(target) if "." in str(target) else f"{_schema(item)}.{target}"
    return None


def _strip_brackets(value: str) -> str:
    return value.replace("[", "").replace("]", "").strip()


def _synonym_metadata(item: dict[str, Any]) -> dict[str, Any]:
    ref = _strip_brackets(str(item.get("referenced_object") or item.get("base_object_name") or item.get("target") or ""))
    parts = [p for p in ref.split(".") if p]
    meta: dict[str, Any] = {"referenced_object": ref}
    meta["is_cross_server"] = bool(item.get("is_cross_server", len(parts) >= 4))
    meta["is_cross_database"] = bool(item.get("is_cross_database", len(parts) == 3))
    if parts:
        meta["referenced_name"] = parts[-1]
        meta["referenced_schema"] = parts[-2] if len(parts) >= 2 else "dbo"
        if len(parts) >= 3:
            meta["referenced_database"] = parts[-3]
        if len(parts) >= 4:
            meta["referenced_server"] = parts[-4]
    return meta


def _rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    for key in ("incompatibilities", "findings", "results"):
        rows = payload.get(key)
        if isinstance(rows, list):
            return [r for r in rows if isinstance(r, dict)]
    return []


def _row_identity(row: dict[str, Any]) -> tuple[str, str]:
    name = str(row.get("object_name") or row.get("name") or "")
    schema = str(row.get("schema") or row.get("schema_name") or "dbo")
    if "." in name and not row.get("schema"):
        schema, name = name.split(".", 1)
    return schema.lower(), _strip_brackets(name).lower()


def _attach_remediation(
    rows: list[dict[str, Any]],
    kb: dict[str, dict[str, Any]],
    warnings: list[str],
    label: str,
) -> list[dict[str, Any]]:
    attached = []
    for row in rows:
        rule_id = str(row.get("rule_id") or "")
        remediation = kb.get(rule_id)
        entry = dict(row)
        compat = str(row.get("compatibility") or "").upper()
        if remediation:
            entry["remediation"] = {
                "note_template": remediation.get("note_template"),
                "target_pg_alternative": remediation.get("target_pg_alternative"),
                "conversion_steps": remediation.get("conversion_steps") or remediation.get("detailedDescription"),
            }
            entry["remediation_status"] = "FOUND"
        else:
            entry["remediation"] = None
            entry["remediation_status"] = "UNHANDLED"
            if rule_id and compat in {"SC", "NS"}:
                warnings.append(f"Remediation missing for rule {rule_id} on {label}; flagged for review")
        attached.append(entry)
    return attached


def _index_ai(analysis: dict[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    index: dict[tuple[str, str], dict[str, Any]] = {}
    intelligence = analysis.get("object_intelligence")
    if not isinstance(intelligence, dict):
        return index
    for section, items in intelligence.items():
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            for key in ("object_name", "name", "trigger_name", "view_name", "function_name", "procedure_name"):
                candidate = item.get(key)
                if candidate:
                    bare = _strip_brackets(str(candidate)).split(".")[-1].lower()
                    index.setdefault((section.lower(), bare), item)
                    index.setdefault(("*", bare), item)
                    break
    return index


def _ai_entry(ai_index: dict[tuple[str, str], dict[str, Any]], object_type: str, name: str) -> Optional[dict[str, Any]]:
    bare = name.split(".")[-1].lower()
    for section in AI_SECTION_BY_TYPE.get(object_type, ()):
        hit = ai_index.get((section, bare))
        if hit is not None:
            return hit
    return ai_index.get(("*", bare)) if object_type in AI_SECTION_BY_TYPE else None


def _depends_on_code(obj: dict[str, Any]) -> list[str]:
    """Callers and callees named by AI analysis, including Compass `calls` and the dependency graph."""
    ai = obj.get("aiAnalysis") or {}
    for key in ("depends_on_code", "dependsOnCode", "calls"):
        value = ai.get(key)
        if isinstance(value, list) and value:
            return [str(item) for item in value if str(item).strip()]
    graph = ai.get("dependency_graph") or {}
    code = graph.get("code_dependencies")
    if isinstance(code, list):
        return [str(item) for item in code if str(item).strip()]
    return []


def _graph_dependencies(analysis: dict[str, Any], schema: str, name: str) -> dict[str, Any]:
    graph = analysis.get("dependency_graph")
    if not isinstance(graph, dict):
        return {}
    keys = {f"{schema}.{name}".lower(), name.lower()}
    result: dict[str, Any] = {}
    for section in ("code_dependencies", "table_dependencies", "object_dependencies"):
        entries = graph.get(section)
        if isinstance(entries, dict):
            for key, value in entries.items():
                if str(key).lower() in keys:
                    result[section] = value
        elif isinstance(entries, list):
            for entry in entries:
                if isinstance(entry, dict):
                    label = str(entry.get("object") or entry.get("object_name") or entry.get("name") or "").lower()
                    if label in keys:
                        result[section] = entry
    return result


def _structural_metadata(item: dict[str, Any], object_type: str) -> dict[str, Any]:
    meta = {k: v for k, v in item.items() if k not in _SKIP_META_KEYS}
    if object_type == "SYNONYM":
        meta.update(_synonym_metadata(item))
    if object_type == "TRIGGER":
        timing = str(item.get("trigger_timing") or item.get("timing") or "").upper()
        meta.setdefault("is_instead_of", item.get("is_instead_of", "INSTEAD" in timing))
    return meta


def _skip(name: str, schema: str, object_type: str, reason: str, severity: str, details: str) -> dict[str, Any]:
    return {"object_name": name, "object_type": object_type.lower(), "schema": schema, "reason": reason, "severity": severity, "details": details}


def assemble_context(
    *,
    asis: dict[str, Any],
    incompatibilities: dict[str, Any],
    analysis: dict[str, Any],
    remediation_kb: dict[str, dict[str, Any]],
    ddl_index: dict[tuple[str, str], DdlBlock],
    file_name: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Build one plan entry per AS-IS object. Body-required objects with no DDL are skipped."""
    database_objects = asis.get("database_objects") or {}
    plan: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    warnings: list[str] = []
    seen: set[tuple[str, str, str]] = set()
    ai_index = _index_ai(analysis)
    table_blocks: dict[str, DdlBlock] = {}

    rows_by_object: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in _rows(incompatibilities):
        rows_by_object.setdefault(_row_identity(row), []).append(row)
    matched_rows: set[tuple[str, str]] = set()

    for section, default_type in WALK_ORDER:
        items = database_objects.get(section)
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            object_type = _norm_constraint_type(item) if default_type is None else default_type
            if object_type == "VIEW" and str(item.get("view_type") or "").upper() == "INDEXED":
                object_type = "MATERIALIZED_VIEW"
            name = _object_name(item, object_type)
            if not name:
                warnings.append(f"Unnamed object in AS-IS section '{section}' ignored")
                continue
            schema = _schema(item)
            identity = (schema.lower(), name.lower(), object_type)
            if identity in seen:
                continue
            seen.add(identity)

            is_clr = bool(item.get("is_clr") or str(item.get("udt_category") or "").upper() == "CLR_TYPE")
            is_encrypted = bool(item.get("is_encrypted"))
            owning_table = _owning_table(item, object_type) if object_type not in {"SCHEMA", "TABLE"} else None
            block = lookup_block(ddl_index, schema, name)
            if object_type == "TABLE" and block is not None:
                table_blocks[f"{schema}.{name}".lower()] = block

            if object_type in BODY_REQUIRED and not is_clr and not is_encrypted and block is None:
                skipped.append(_skip(name, schema, object_type, "SOURCE_NOT_FOUND", "CRITICAL", f"CREATE {object_type} {schema}.{name} was not found in {file_name}"))
                matched_rows.add((schema.lower(), name.lower()))
                continue

            source_code = None
            source_origin = "DDL_SCRIPT"
            if block is None and owning_table:
                owner_block = table_blocks.get(owning_table.lower())
                if owner_block is not None and object_type not in SECURITY_TYPES:
                    block = owner_block
                    source_origin = "OWNING_TABLE_DDL"
            if block is not None:
                source_code = {"ddl": block.ddl, "start_line": block.start_line, "end_line": block.end_line, "file_name": block.file_name, "origin": source_origin}
            elif item.get("definition"):
                source_code = {"ddl": str(item["definition"]), "start_line": None, "end_line": None, "file_name": "AS-IS definition", "origin": "ASIS_DEFINITION"}

            key = (schema.lower(), name.lower())
            raw_rows = rows_by_object.get(key, [])
            if raw_rows:
                matched_rows.add(key)
            label = f"{schema}.{name}"
            findings = _attach_remediation(raw_rows, remediation_kb, warnings, label)

            ai = _ai_entry(ai_index, object_type, name)
            graph = _graph_dependencies(analysis, schema, name)
            if ai is not None or graph:
                ai = dict(ai or {})
                if graph:
                    ai["dependency_graph"] = graph
            if ai is None and object_type in AI_SECTION_BY_TYPE:
                warnings.append(f"AI analysis missing for {label}; confidence floor LOW")

            plan.append(
                {
                    "objectId": f"{object_type}:{schema}.{name}",
                    "type": object_type,
                    "schema": schema,
                    "name": name,
                    "owningTable": owning_table,
                    "sourceCode": source_code,
                    "structuralMetadata": _structural_metadata(item, object_type),
                    "aiAnalysis": ai,
                    "incompatibilities": findings,
                    "status": "pending",
                    "conversionStatus": None,
                    "convertedCode": None,
                    "convertedName": None,
                    "newSignature": None,
                    "confidenceScore": None,
                    "changesApplied": [],
                    "comments": [],
                    "requiresManualReview": False,
                    "reviewGuidance": [],
                    "callerUpdatesNeeded": [],
                    "executionPhase": EXECUTION_PHASE_BY_TYPE.get(object_type, 6),
                    "phaseOrder": None,
                    "outputFile": None,
                    "isClr": is_clr,
                    "isEncrypted": is_encrypted,
                }
            )

    view_names = {f"{o['schema']}.{o['name']}".lower() for o in plan if o["type"] == "VIEW"}
    for obj in plan:
        obj["structuralMetadata"]["features"] = merged_features(obj)
        obj["dependsOnCode"] = _depends_on_code(obj)
    for obj in plan:
        owner_is_view = bool(obj.get("owningTable")) and str(obj["owningTable"]).lower() in view_names
        obj["confidenceFloor"] = structural_floor(obj, owner_is_view=owner_is_view)
        if obj["type"] == "TRIGGER":
            obj["structuralMetadata"]["owner_is_view"] = owner_is_view
        if obj["confidenceFloor"] == "MANUAL" or obj["isClr"] or obj["isEncrypted"]:
            obj["requiresManualReview"] = True
        if obj["aiAnalysis"] is None and obj["type"] in AI_SECTION_BY_TYPE:
            obj["confidenceFloor"] = lowest(obj.get("confidenceFloor"), "LOW")
            obj["requiresManualReview"] = True
            obj["reviewGuidance"].append({"reason": "AI analysis entry missing; converted with limited context", "priority": "MEDIUM"})
        for finding in obj["incompatibilities"]:
            if finding.get("remediation_status") == "UNHANDLED" and str(finding.get("compatibility") or "").upper() in {"SC", "NS"}:
                obj["requiresManualReview"] = True
                obj["reviewGuidance"].append({"reason": f"Remediation guidance missing for rule {finding.get('rule_id')}", "priority": "HIGH", "rule_id": finding.get("rule_id")})

    for key, rows in rows_by_object.items():
        if key not in matched_rows:
            for row in rows:
                warnings.append(f"Incompatibility {row.get('rule_id')} references {key[0]}.{key[1]} which is not in AS-IS")
            continue
        if key in ddl_index or ("dbo", key[1]) in ddl_index:
            continue
        assembled_types = {obj["type"] for obj in plan if (obj["schema"].lower(), obj["name"].lower()) == key}
        skipped_here = any(
            str(item.get("schema", "")).lower() == key[0] and str(item.get("object_name", "")).lower() == key[1] for item in skipped
        )
        if skipped_here or (assembled_types & BODY_REQUIRED):
            for row in rows:
                shown = row.get("object_name") or row.get("name") or key[1]
                warnings.append(
                    f"Incompatibility {row.get('rule_id')} references {key[0]}.{shown} which was not found in the source DDL"
                )

    statistics = asis.get("statistics") if isinstance(asis.get("statistics"), dict) else {}
    expected = statistics.get("total_objects", statistics.get("totalObjects"))
    actual = len(plan) + len(skipped)
    if expected is not None:
        expected_count = int(expected)
        mismatch = abs(expected_count - actual)
        percent = (mismatch / expected_count) * 100 if expected_count else 100.0
        if mismatch:
            message = (
                f"AS-IS object count {expected_count} does not equal assembled {len(plan)} + skipped {len(skipped)} "
                f"({percent:.1f}% mismatch). Continuing with the assembled objects."
            )
            logger.warning(message)
            warnings.append(message)
    return plan, skipped, warnings
