"""Pass 3: assign the ticket 16-phase execution order and break dependency cycles.

Within each phase, objects are ordered by Kahn's topological sort (ready objects picked
alphabetically by schema.name for deterministic output). Cross-table FK cycles get
DEFERRABLE INITIALLY DEFERRED. Mutual procedure call cycles are flagged for manual
review — PostgreSQL has no routine forward-declaration (ticket AC5).
"""

from __future__ import annotations

import re
from typing import Any, Optional

from app.services.mssql_pg.confidence import lowest
from app.services.mssql_pg.progress import EXECUTION_PHASE_BY_TYPE, SCRIPT_ORDER

_CODE_TYPES_BY_PHASE_EDGE = {
    "TABLE": frozenset({"TABLE"}),
    "VIEW": frozenset({"VIEW"}),
    "MATERIALIZED_VIEW": frozenset({"MATERIALIZED_VIEW"}),
    "FUNCTION": frozenset({"FUNCTION"}),
    "PROCEDURE": frozenset({"PROCEDURE"}),
}


def _qname(obj: dict[str, Any]) -> str:
    return f"{obj['schema']}.{obj['name']}"


def _code(obj: dict[str, Any]) -> str:
    return obj.get("convertedCode") or ""


def _name_pattern(name: str) -> "re.Pattern[str]":
    return re.compile(rf"(?i)\[?{re.escape(name)}\]?\b")


def _build_same_type_edges(objects: list[dict[str, Any]]) -> dict[str, set[str]]:
    """edges[A] = set of B such that A's DDL references B (A depends on B existing first)."""
    edges: dict[str, set[str]] = {_qname(o): set() for o in objects}
    patterns = [(_qname(o), o["name"], _name_pattern(o["name"])) for o in objects]
    for obj in objects:
        code = _code(obj)
        if not code:
            continue
        self_key = _qname(obj)
        for other_key, other_name, pattern in patterns:
            if other_key == self_key:
                continue
            if pattern.search(code):
                edges[self_key].add(other_key)
    return edges


def _kahn_sort(keys: list[str], edges: dict[str, set[str]], sort_key=None) -> tuple[list[str], list[list[str]]]:
    """Topological sort. ``sort_key`` breaks ties (analysis rank, then name)."""
    sort_key = sort_key or (lambda key: key)
    remaining = set(keys)
    in_degree = {k: 0 for k in keys}
    dependents: dict[str, set[str]] = {k: set() for k in keys}
    for node, deps in edges.items():
        for dep in deps:
            if dep in remaining and node in remaining:
                in_degree[node] += 1
                dependents[dep].add(node)

    order: list[str] = []
    cycles: list[list[str]] = []
    while remaining:
        ready = sorted((key for key in remaining if in_degree.get(key, 0) == 0), key=sort_key)
        if not ready:
            # Cycle: break it by emitting the first remaining node anyway.
            cycle_members = sorted(remaining, key=sort_key)
            cycles.append(cycle_members)
            ready = [cycle_members[0]]
        for key in ready:
            if key not in remaining:
                continue
            order.append(key)
            remaining.discard(key)
            for dependent in dependents.get(key, ()):
                if dependent in remaining:
                    in_degree[dependent] = max(0, in_degree[dependent] - 1)
    return order, cycles


def _rank_key(obj: dict[str, Any]) -> tuple:
    rank = obj.get("analysisRank")
    return (rank is None, rank if isinstance(rank, int) else 0, _qname(obj))


def order_phase(objects: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[list[str]]]:
    """Order objects of one phase; same-type DDL reference edges break ties, else analysis rank then name."""
    if len(objects) <= 1:
        return objects, []
    types_present = {o["type"] for o in objects}
    edge_types = types_present & set(_CODE_TYPES_BY_PHASE_EDGE)
    if not edge_types:
        return sorted(objects, key=_rank_key), []
    by_key = {_qname(o): o for o in objects}
    edges = _build_same_type_edges(objects)
    order, cycles = _kahn_sort(list(by_key), edges, lambda key: _rank_key(by_key[key]))
    return [by_key[k] for k in order], cycles


_FK_TABLE_RE = re.compile(r"(?i)REFERENCES\s+(\[?[\w]+\]?(?:\s*\.\s*\[?[\w]+\]?)?)")
_DEFERRABLE_RE = re.compile(r"(?i)DEFERRABLE")
_FROM_JOIN_RE = re.compile(r"(?i)\b(?:FROM|JOIN)\s+(\[?[\w]+\]?(?:\s*\.\s*\[?[\w]+\]?)?)")
_SQL_KEYWORDS = frozenset({"select", "where", "lateral", "only", "unnest"})


def handle_fk_cycles(fk_objects: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    """Add DEFERRABLE INITIALLY DEFERRED to foreign keys that form a reference cycle."""
    edges: dict[str, set[str]] = {}
    owners: dict[str, dict[str, Any]] = {}
    for obj in fk_objects:
        owner = (obj.get("owningTable") or "").lower()
        if not owner:
            continue
        match = _FK_TABLE_RE.search(_code(obj))
        target = match.group(1).replace("[", "").replace("]", "").strip().lower() if match else None
        if not target:
            continue
        if "." not in target:
            target = f"{obj['schema'].lower()}.{target}"
        edges.setdefault(owner, set()).add(target)
        owners.setdefault(owner, obj)

    in_cycle: set[str] = set()
    for table in edges:
        if table in edges.get(table, set()):
            in_cycle.add(table)  # self-reference
    for a, targets in edges.items():
        for b in targets:
            if b in edges and a in edges[b] and a != b:
                in_cycle.add(a)
                in_cycle.add(b)

    for obj in fk_objects:
        owner = (obj.get("owningTable") or "").lower()
        if owner not in in_cycle:
            continue
        code = _code(obj)
        if not code or _DEFERRABLE_RE.search(code):
            continue
        new_code = code.rstrip().rstrip(";") + " DEFERRABLE INITIALLY DEFERRED;"
        obj["convertedCode"] = new_code
        obj.setdefault("changesApplied", []).append("PG-084: added DEFERRABLE INITIALLY DEFERRED for FK reference cycle")
        audit.append({"type": "FK_CYCLE", "table": owner, "constraint": f"{obj['schema']}.{obj['name']}"})


_CALL_OR_EXEC = re.compile(r"(?i)\b(?:CALL|EXEC(?:UTE)?)\s+(\[?[\w]+\]?(?:\s*\.\s*\[?[\w]+\]?)?)")


def _call_edges(procedures: list[dict[str, Any]]) -> dict[str, set[str]]:
    by_bare: dict[str, str] = {}
    for obj in procedures:
        by_bare[obj["name"].lower()] = _qname(obj)
    edges: dict[str, set[str]] = {_qname(o): set() for o in procedures}
    for obj in procedures:
        for match in _CALL_OR_EXEC.finditer(_code(obj)):
            target = match.group(1).replace("[", "").replace("]", "").strip().lower()
            bare = target.split(".")[-1]
            resolved = by_bare.get(bare)
            if resolved and resolved != _qname(obj):
                edges[_qname(obj)].add(resolved)
    return edges


def _find_sccs(nodes: list[str], edges: dict[str, set[str]]) -> list[list[str]]:
    """Tarjan's strongly-connected-components, iterative to avoid recursion limits."""
    index_counter = [0]
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    lowlink: dict[str, int] = {}
    result: list[list[str]] = []

    def strongconnect(start: str) -> None:
        work = [(start, iter(sorted(edges.get(start, ()))))]
        indices[start] = lowlink[start] = index_counter[0]
        index_counter[0] += 1
        stack.append(start)
        on_stack.add(start)

        while work:
            node, it = work[-1]
            advanced = False
            for succ in it:
                if succ not in indices:
                    indices[succ] = lowlink[succ] = index_counter[0]
                    index_counter[0] += 1
                    stack.append(succ)
                    on_stack.add(succ)
                    work.append((succ, iter(sorted(edges.get(succ, ())))))
                    advanced = True
                    break
                if succ in on_stack:
                    lowlink[node] = min(lowlink[node], indices[succ])
            if advanced:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                lowlink[parent] = min(lowlink[parent], lowlink[node])
            if lowlink[node] == indices[node]:
                component = []
                while True:
                    member = stack.pop()
                    on_stack.discard(member)
                    component.append(member)
                    if member == node:
                        break
                result.append(component)

    for node in nodes:
        if node not in indices:
            strongconnect(node)
    return result


def handle_procedure_cycles(procedures: list[dict[str, Any]], audit: list[dict[str, Any]]) -> None:
    """Mutual procedure call cycles are flagged for application-layer refactoring (AC5)."""
    if len(procedures) < 2:
        return
    by_qname = {_qname(o): o for o in procedures}
    edges = _call_edges(procedures)
    sccs = [c for c in _find_sccs(list(by_qname), edges) if len(c) > 1]
    for cycle in sccs:
        ordered_cycle = sorted(cycle)
        for member_key in ordered_cycle:
            member = by_qname[member_key]
            member["requiresManualReview"] = True
            member["confidenceScore"] = lowest(member.get("confidenceScore"), "LOW")
            member.setdefault("reviewGuidance", []).append(
                {
                    "reason": (
                        "Mutual procedure call cycle "
                        f"({', '.join(ordered_cycle)}); PostgreSQL has no forward declaration — "
                        "refactor at the application layer"
                    ),
                    "priority": "HIGH",
                }
            )
        audit.append({"type": "PROCEDURE_CYCLE", "members": ordered_cycle, "action": "FLAGGED_FOR_REVIEW"})


def _resolve_name(raw: str, schema: str, by_qname: dict[str, dict[str, Any]]) -> Optional[dict[str, Any]]:
    target = raw.replace("[", "").replace("]", "").strip().lower()
    if not target or target in _SQL_KEYWORDS:
        return None
    if "." not in target:
        target = f"{schema.lower()}.{target}"
    return by_qname.get(target)


def validate_execution_order(plan: list[dict[str, Any]]) -> list[str]:
    """AC5 / AC9 gates. Failures are logged; Pass 4 still runs with partial output."""
    errors: list[str] = []
    by_qname = {_qname(o).lower(): o for o in plan}
    assigned = [o for o in plan if o.get("executionPhase") is not None]
    if len(assigned) != len(plan):
        errors.append(f"{len(plan) - len(assigned)} object(s) were not assigned an execution phase")

    for obj in plan:
        if obj["type"] == "FOREIGN_KEY":
            match = _FK_TABLE_RE.search(_code(obj))
            if match:
                ref = _resolve_name(match.group(1), obj["schema"], by_qname)
                if ref and int(ref.get("executionPhase") or 99) > 4:
                    errors.append(f"FK {_qname(obj)} references {_qname(ref)} after phase 4")
        if obj["type"] in {"VIEW", "MATERIALIZED_VIEW"}:
            for match in _FROM_JOIN_RE.finditer(_code(obj)):
                ref = _resolve_name(match.group(1), obj["schema"], by_qname)
                if ref and int(ref.get("executionPhase") or 99) > 10:
                    errors.append(f"View {_qname(obj)} base {_qname(ref)} is after phase 10")
        if obj["type"] == "PROCEDURE":
            for match in _CALL_OR_EXEC.finditer(_code(obj)):
                ref = _resolve_name(match.group(1), obj["schema"], by_qname)
                if ref is None or ref["type"] == "PROCEDURE":
                    continue
                if int(ref.get("executionPhase") or 99) > 12:
                    errors.append(f"Procedure {_qname(obj)} calls {_qname(ref)} after phase 12")
        if obj["type"] == "TRIGGER" and obj.get("owningTable"):
            owner = by_qname.get(str(obj["owningTable"]).lower())
            if owner and int(owner.get("executionPhase") or 99) > 4:
                errors.append(f"Trigger {_qname(obj)} owning table is after phase 4")
    return errors


_PHASE_SUFFIX = {
    "schemas": 1,
    "sequences": 2,
    "user_defined_types": 3,
    "types": 3,
    "partition_functions": 4,
    "tables": 4,
    "partition_schemes": 5,
    "primary_keys": 5,
    "unique_constraints": 6,
    "foreign_keys": 7,
    "check_constraints": 8,
    "indexes": 9,
    "views": 10,
    "materialized_views": 11,
    "functions": 12,
    "stored_procedures": 13,
    "procedures": 13,
    "triggers": 14,
    "security_policies": 15,
    "security": 15,
    "synonyms": 16,
}


def _phase_from_analysis_key(key: str) -> Optional[int]:
    suffix = re.sub(r"^phase_\d+_", "", str(key))
    return _PHASE_SUFFIX.get(suffix)


def annotate_analysis_order(plan: list[dict[str, Any]], analysis: Optional[dict[str, Any]]) -> tuple[int, list[Any]]:
    """Stamp analysisRank from execution_order lists. Returns (matched count, circular_dependencies)."""
    order = (analysis or {}).get("execution_order") or {}
    ranks: dict[tuple[int, str], int] = {}
    if isinstance(order, dict):
        for key, items in order.items():
            phase = _phase_from_analysis_key(key)
            if phase is None or not isinstance(items, list):
                continue
            for index, item in enumerate(items):
                if isinstance(item, dict):
                    label = item.get("name") or item.get("object_name") or ""
                else:
                    label = item
                bare = str(label).replace("[", "").replace("]", "").split(".")[-1].strip().lower()
                if bare:
                    ranks[(phase, bare)] = index
    matched = 0
    for obj in plan:
        phase = EXECUTION_PHASE_BY_TYPE.get(obj["type"], obj.get("executionPhase"))
        rank = ranks.get((int(phase), obj["name"].lower()))
        if rank is None:
            obj.pop("analysisRank", None)
            continue
        obj["analysisRank"] = rank
        matched += 1
    cycles = (analysis or {}).get("circular_dependencies") or []
    return matched, cycles if isinstance(cycles, list) else []


def apply_declared_cycles(plan: list[dict[str, Any]], cycles: list[Any], audit: list[dict[str, Any]]) -> int:
    """Apply circular_dependencies[] strategies that SQL scanning did not already record."""
    applied = 0
    by_name = {o["name"].lower(): o for o in plan}
    for cycle in cycles:
        members = cycle.get("objects") or cycle.get("members") if isinstance(cycle, dict) else cycle
        if not isinstance(members, list) or len(members) < 2:
            continue
        resolved = []
        for member in members:
            label = member.get("name") if isinstance(member, dict) else member
            bare = str(label).replace("[", "").replace("]", "").split(".")[-1].strip().lower()
            obj = by_name.get(bare)
            if obj is not None:
                resolved.append(obj)
        if len(resolved) < 2:
            continue
        kinds = {obj["type"] for obj in resolved}
        if kinds <= {"FOREIGN_KEY"}:
            for obj in resolved:
                code = _code(obj)
                if code and not _DEFERRABLE_RE.search(code):
                    obj["convertedCode"] = code.rstrip().rstrip(";") + " DEFERRABLE INITIALLY DEFERRED;"
            audit.append({"type": "DECLARED_FK_CYCLE", "members": [ _qname(o) for o in resolved ]})
            applied += 1
        elif "PROCEDURE" in kinds:
            for obj in resolved:
                if obj["type"] != "PROCEDURE":
                    continue
                obj["requiresManualReview"] = True
                obj["confidenceScore"] = lowest(obj.get("confidenceScore"), "LOW")
                obj.setdefault("reviewGuidance", []).append(
                    {
                        "reason": "AI analysis circular_dependencies lists a mutual procedure call; PostgreSQL has no forward declaration",
                        "priority": "HIGH",
                    }
                )
            audit.append({"type": "DECLARED_PROCEDURE_CYCLE", "members": [_qname(o) for o in resolved]})
            applied += 1
    return applied


def apply_execution_order(plan: list[dict[str, Any]], analysis: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Assign phaseOrder/outputFile to every object and break structural cycles. Mutates plan."""
    audit: list[dict[str, Any]] = []
    _, declared_cycles = annotate_analysis_order(plan, analysis)
    apply_declared_cycles(plan, declared_cycles, audit)
    by_phase: dict[int, list[dict[str, Any]]] = {}
    for obj in plan:
        phase = EXECUTION_PHASE_BY_TYPE.get(obj["type"], obj.get("executionPhase", 4))
        obj["executionPhase"] = phase
        by_phase.setdefault(phase, []).append(obj)

    fk_objects = by_phase.get(7, [])
    if fk_objects:
        handle_fk_cycles(fk_objects, audit)
    procedures = by_phase.get(13, [])
    if procedures:
        handle_procedure_cycles(procedures, audit)

    cycles_broken: list[dict[str, Any]] = []
    sequence = 0
    for phase in sorted(by_phase):
        ordered, cycles = order_phase(by_phase[phase])
        if cycles:
            cycles_broken.append({"phase": phase, "cycles": cycles})
        output_file = SCRIPT_ORDER[phase - 1] if 1 <= phase <= len(SCRIPT_ORDER) else SCRIPT_ORDER[-1]
        for obj in ordered:
            sequence += 1
            obj["phaseOrder"] = sequence
            obj["outputFile"] = output_file

    validation_errors = validate_execution_order(plan)
    return {
        "cyclesHandled": audit,
        "orderingCyclesBroken": cycles_broken,
        "validationErrors": validation_errors,
        "totalPhases": len(by_phase),
        "totalObjects": len(plan),
    }
