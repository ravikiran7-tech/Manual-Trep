"""Parse and validate the model's JSON response for one object conversion call."""

from __future__ import annotations

import json
import re
from typing import Any, Optional

from app.services.mssql_pg.confidence import CONFIDENCE_RANK, lowest

VALID_STATUSES = frozenset({"SUCCESS", "PARTIAL", "UNCONVERTIBLE"})
VALID_PRIORITIES = frozenset({"CRITICAL", "HIGH", "MEDIUM", "LOW"})
_CALLER_REASONS = frozenset({"SIGNATURE_CHANGE", "SYNONYM_RESOLUTION", "CLR_REPLACEMENT", "UDT_ELIMINATION", "VIEW_STRUCTURE_CHANGE", "TABLE_COLUMN_RENAME", "INSTEAD_OF_CONVERSION"})

_FENCE = re.compile(r"```(?:json)?\s*(\{.*\})\s*```", re.S)


class ValidationError(ValueError):
    """The model response could not be parsed into a usable conversion result."""


def extract_json(raw_text: str) -> dict[str, Any]:
    """Pull one JSON object out of a model response, tolerating markdown fences and stray text."""
    text = (raw_text or "").strip()
    if not text:
        raise ValidationError("Empty response from model")
    fence_match = _FENCE.search(text)
    candidate = fence_match.group(1) if fence_match else text
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValidationError("No JSON object found in model response")
    try:
        return json.loads(candidate[start : end + 1])
    except json.JSONDecodeError as exc:
        raise ValidationError(f"Model response is not valid JSON: {exc}") from exc


def _as_str_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(v) for v in value if str(v).strip()]
    if isinstance(value, str) and value.strip():
        return [value]
    return []


def _normalize_review_guidance(value: Any) -> list[dict[str, str]]:
    result = []
    if isinstance(value, list):
        for item in value:
            if isinstance(item, dict) and item.get("reason"):
                priority = str(item.get("priority") or "MEDIUM").upper()
                result.append({"reason": str(item["reason"]), "priority": priority if priority in VALID_PRIORITIES else "MEDIUM"})
    return result


def _normalize_caller_updates(value: Any, *, schema: str, name: str) -> list[dict[str, Any]]:
    result = []
    if isinstance(value, list):
        for item in value:
            if not isinstance(item, dict):
                continue
            reason = str(item.get("reason") or "").upper()
            if reason not in _CALLER_REASONS:
                continue
            entry = dict(item)
            entry["reason"] = reason
            entry.setdefault("callee", f"{schema}.{name}")
            result.append(entry)
    return result


def parse_and_validate(raw_text: str, obj: dict[str, Any]) -> dict[str, Any]:
    """Validate structure and reconcile confidence with the structural floor.

    Raises ValidationError for malformed/missing required fields so the caller can retry
    with a repair prompt.
    """
    payload = extract_json(raw_text)

    status = str(payload.get("conversionStatus") or "").upper()
    if status not in VALID_STATUSES:
        raise ValidationError(f"conversionStatus must be one of {sorted(VALID_STATUSES)}, got {payload.get('conversionStatus')!r}")

    converted_code = payload.get("convertedCode")
    if not isinstance(converted_code, str):
        raise ValidationError("convertedCode must be a string")
    if status != "UNCONVERTIBLE" and not converted_code.strip():
        raise ValidationError("convertedCode must not be empty when conversionStatus is not UNCONVERTIBLE")

    reported_confidence = str(payload.get("confidenceScore") or "").upper()
    if reported_confidence not in CONFIDENCE_RANK:
        raise ValidationError(f"confidenceScore must be one of {list(CONFIDENCE_RANK)}, got {payload.get('confidenceScore')!r}")

    floor = str(obj.get("confidenceFloor") or "HIGH").upper()
    final_confidence = lowest(reported_confidence, floor)

    requires_review = bool(payload.get("requiresManualReview")) or final_confidence in {"LOW", "MANUAL"} or status != "SUCCESS"

    return {
        "conversionStatus": status,
        "convertedCode": converted_code,
        "convertedName": payload.get("convertedName") or None,
        "newSignature": payload.get("newSignature") or None,
        "confidenceScore": final_confidence,
        "modelReportedConfidence": reported_confidence,
        "changesApplied": _as_str_list(payload.get("changesApplied")),
        "comments": _as_str_list(payload.get("comments")),
        "requiresManualReview": requires_review,
        "reviewGuidance": _normalize_review_guidance(payload.get("reviewGuidance")),
        "callerUpdatesNeeded": _normalize_caller_updates(payload.get("callerUpdatesNeeded"), schema=obj["schema"], name=obj["name"]),
    }


def unconvertible_result(obj: dict[str, Any], reason: str, *, priority: str = "CRITICAL") -> dict[str, Any]:
    """Fallback result used when every AI attempt (initial + repair + timeout retries) fails."""
    return {
        "conversionStatus": "UNCONVERTIBLE",
        "convertedCode": "",
        "convertedName": None,
        "newSignature": None,
        "confidenceScore": "MANUAL",
        "modelReportedConfidence": None,
        "changesApplied": [],
        "comments": [reason],
        "requiresManualReview": True,
        "reviewGuidance": [{"reason": reason, "priority": priority if priority in VALID_PRIORITIES else "CRITICAL"}],
        "callerUpdatesNeeded": [],
    }
