"""Phase 1 validation for the Compass inputs (ticket AC1).

Launch reads the same five files as Oracle: ddlExport, asisSchema,
incompatibilityResults, rulesRemediation, schemaAnalysis.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from app.core.config import get_settings

TICKET_PHASE_KEYS = [
    "phase_1_schemas",
    "phase_2_sequences",
    "phase_3_types",
    "phase_4_tables",
    "phase_5_primary_keys",
    "phase_6_unique_constraints",
    "phase_7_foreign_keys",
    "phase_8_check_constraints",
    "phase_9_indexes",
    "phase_10_views",
    "phase_11_materialized_views",
    "phase_12_functions",
    "phase_13_stored_procedures",
    "phase_14_triggers",
    "phase_15_security_policies",
    "phase_16_synonyms",
]

# Compass analysis files may still emit the older 16-key layout.
LEGACY_PHASE_KEYS = [
    "phase_1_schemas",
    "phase_2_sequences",
    "phase_3_user_defined_types",
    "phase_4_partition_functions",
    "phase_5_partition_schemes",
    "phase_6_tables",
    "phase_7_primary_keys",
    "phase_8_unique_constraints",
    "phase_9_foreign_keys",
    "phase_10_check_constraints",
    "phase_11_indexes",
    "phase_12_views",
    "phase_13_functions",
    "phase_14_stored_procedures",
    "phase_15_triggers",
    "phase_16_synonyms",
]

REQUIRED_PHASE_KEYS = TICKET_PHASE_KEYS

HIGH_IMPACT_SEVERITIES = frozenset({"CRITICAL", "HIGH"})


class InputValidationError(ValueError):
    """A mandatory input is missing, empty, or inconsistent; the job must halt."""


def _load_json(path: Path, label: str) -> Any:
    if not path.is_file() or path.stat().st_size == 0:
        raise InputValidationError(f"{label} is missing or empty: {path.name}")
    try:
        with path.open(encoding="utf-8-sig") as fh:
            return json.load(fh)
    except json.JSONDecodeError as exc:
        raise InputValidationError(f"{label} is not valid JSON: {exc}") from exc


def _database_name(payload: dict[str, Any]) -> str:
    """Read the database name from the shapes Compass actually emits.

    AS-IS stores it under scan_metadata.source_database.database_name.
    Incompatibility results store it under metadata.database_name.
    """
    sections: list[dict[str, Any]] = []
    for key in ("metadata", "scan_metadata", "scan_request"):
        section = payload.get(key)
        if isinstance(section, dict):
            sections.append(section)
            nested = section.get("source_database") or section.get("sourceDatabase")
            if isinstance(nested, dict):
                sections.append(nested)
    nested = payload.get("source_database") or payload.get("sourceDatabase")
    if isinstance(nested, dict):
        sections.append(nested)
    sections.append(payload)
    for source in sections:
        for key in ("database_name", "databaseName", "db_name", "dbName"):
            value = source.get(key)
            if value:
                return str(value)
    return ""


# Compass sometimes emits a sample or placeholder id (e.g. TestDB) in scan_metadata.
# Prefer the real database name from the same payload or the launch request fallback.
_PLACEHOLDER_SCAN_DATABASE_IDS = frozenset(
    {
        "testdb",
        "test_db",
        "sampledb",
        "sample_db",
        "unknown",
        "unknowndb",
        "unknowndatabase",
        "unknown_database",
        "none",
        "null",
        "na",
        "n_a",
    }
)


def _normalize_database_id_fragment(value: Any) -> str:
    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(value))


def is_placeholder_scan_database_id(value: Any) -> bool:
    """True if Compass metadata used a non-distinct placeholder id we should not show in reports."""
    if value is None:
        return True
    normalized = _normalize_database_id_fragment(value).lower()
    if not normalized:
        return True
    return normalized in _PLACEHOLDER_SCAN_DATABASE_IDS


def explicit_database_id(*payloads: dict[str, Any]) -> str:
    """Studio database id from Compass, never the SQL database name.

    Oracle's report reads ``scan_request.database_id`` (for example ``DB0090``).
    The AS-IS ``database_name`` (for example ``ResortsLiteDB``) is a different field.
    """
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        name = _normalize_database_id_fragment(_database_name(payload)).lower()
        sections: list[dict[str, Any]] = []
        for key in ("scan_request", "scan_metadata", "metadata"):
            section = payload.get(key)
            if isinstance(section, dict):
                sections.append(section)
        for source in sections:
            for key in ("database_id", "databaseId", "db_id", "dbId"):
                raw = source.get(key)
                if not raw:
                    continue
                candidate = _normalize_database_id_fragment(raw)
                if is_placeholder_scan_database_id(candidate):
                    continue
                if name and candidate.lower() == name:
                    continue
                return candidate
    return ""


def database_id(payload: dict[str, Any], fallback: str) -> str:
    """Prefix used for output files: scan_metadata database id, else the database name."""
    for section in ("scan_metadata", "metadata", "scan_request"):
        source = payload.get(section) if isinstance(payload.get(section), dict) else {}
        for key in ("database_id", "databaseId", "db_id", "dbId"):
            raw = source.get(key)
            if not raw:
                continue
            candidate = _normalize_database_id_fragment(raw)
            if is_placeholder_scan_database_id(candidate):
                continue
            return candidate
    name = _database_name(payload)
    if name and not is_placeholder_scan_database_id(name):
        return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name)
    if fallback and not is_placeholder_scan_database_id(fallback):
        return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in fallback)
    return ""


def _pick_default_remediation(remediations: list[Any]) -> dict[str, Any]:
    items = [item for item in remediations if isinstance(item, dict)]
    if not items:
        return {}
    for item in items:
        if item.get("default") or item.get("isDefault"):
            return item
    return items[0]


def _normalize_kb_entry(entry: dict[str, Any], fallback_id: str = "") -> Optional[dict[str, Any]]:
    remediations = entry.get("remediations")
    default = _pick_default_remediation(remediations) if isinstance(remediations, list) else {}
    rule_id = entry.get("rule_id") or entry.get("ruleId") or fallback_id
    if not rule_id:
        return None
    conversion_steps = (
        default.get("detailedDescription")
        or default.get("conversion_steps")
        or default.get("conversionSteps")
        or entry.get("conversion_steps")
        or entry.get("conversionSteps")
        or entry.get("detailedDescription")
    )
    note = (
        default.get("description")
        or entry.get("note_template")
        or entry.get("description")
        or ""
    )
    alternative = (
        default.get("targetPgAlternative")
        or default.get("target_pg_alternative")
        or entry.get("target_pg_alternative")
        or ""
    )
    return {
        "rule_id": str(rule_id),
        "ruleId": str(rule_id),
        "note_template": note,
        "target_pg_alternative": alternative,
        "conversion_steps": conversion_steps,
        "severity": entry.get("severity") or entry.get("impact") or "",
        "impact": entry.get("impact") or "",
        "description": entry.get("description") or note,
        "detailedDescription": default.get("detailedDescription") or entry.get("detailedDescription") or "",
    }


def _collect_rule_entries(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        raise InputValidationError("rulesRemediation file must be a JSON object or array")
    if isinstance(payload.get("rules"), list):
        return [item for item in payload["rules"] if isinstance(item, dict)]
    if isinstance(payload.get("remediations"), list):
        return [item for item in payload["remediations"] if isinstance(item, dict)]
    if isinstance(payload.get("remediations"), dict):
        entries: list[dict[str, Any]] = []
        for key, value in payload["remediations"].items():
            if isinstance(value, dict):
                entry = dict(value)
                entry.setdefault("rule_id", value.get("ruleId") or key)
                entries.append(entry)
            else:
                entries.append({"rule_id": key})
        return entries
    return [{"rule_id": key, **value} if isinstance(value, dict) else {"rule_id": key} for key, value in payload.items()]


def _rules_payload(payload: Any) -> Any:
    """Return the rules collection, treating a null catalog as no violations.

    Java writes ``{"rules": null}`` or ``{"rules": []}`` when the onboarded
    database has no violations. Oracle accepts that empty catalog and continues.
    """
    if payload is None:
        return []
    if isinstance(payload, dict) and "rules" in payload:
        rules = payload.get("rules")
        if rules is None:
            return []
        if not isinstance(rules, list):
            raise InputValidationError("rulesRemediation file must contain a rules array")
        return rules
    return payload


def _require_rule_remediations(entry: dict[str, Any], *, oracle_shape: bool) -> None:
    """Match Oracle: a rule in the rules array must have at least one remediation.

    Legacy KB entries that store conversion steps directly and have no
    ``remediations`` field are left unchanged.
    """
    looks_like_oracle_rule = bool(
        entry.get("ruleName") or entry.get("rule_name") or entry.get("severity") or entry.get("category")
    )
    if not oracle_shape and "remediations" not in entry and not looks_like_oracle_rule:
        return
    remediations = entry.get("remediations")
    if isinstance(remediations, list) and remediations:
        return
    raise InputValidationError("Rule has no remediations")


def _load_rules_remediation(path: Path) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    payload = _load_json(path, "rulesRemediation")
    rules_value = _rules_payload(payload)
    if rules_value == []:
        return [], {}

    index: dict[str, dict[str, Any]] = {}
    rules: list[dict[str, Any]] = []
    saw_entry_without_rule_id = False
    oracle_shape = isinstance(payload, dict) and isinstance(payload.get("rules"), list)
    entries = _collect_rule_entries(rules_value if oracle_shape else payload)
    for entry in entries:
        rule_id_raw = entry.get("rule_id") or entry.get("ruleId")
        if not rule_id_raw:
            saw_entry_without_rule_id = True
            continue
        _require_rule_remediations(entry, oracle_shape=oracle_shape)
        normalized = _normalize_kb_entry(entry, fallback_id=str(rule_id_raw))
        if not normalized:
            saw_entry_without_rule_id = True
            continue
        rule_id = normalized["rule_id"]
        index[rule_id] = normalized
        rules.append(normalized)
    if not index and saw_entry_without_rule_id:
        raise InputValidationError("rulesRemediation has no ruleId / rule_id entries")
    return rules, index


def is_high_impact_rule(rule_meta: dict[str, Any]) -> bool:
    severity = str(rule_meta.get("severity") or "").upper()
    if severity in HIGH_IMPACT_SEVERITIES:
        return True
    return str(rule_meta.get("impact") or "").lower() == "high"


def filter_incompatibilities_by_scope(
    incompat: dict[str, Any],
    *,
    rule_scope: str = "all",
    selected_rules: Optional[list[str]] = None,
    remediation_kb: Optional[dict[str, dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Keep incompatibility rows that match Oracle's ruleScope / selectedRules."""
    rows = incompat.get("incompatibilities")
    if not isinstance(rows, list):
        return incompat
    if rule_scope == "all" and not selected_rules:
        return incompat

    allowed: Optional[set[str]] = None
    if rule_scope == "custom" and selected_rules:
        allowed = set(selected_rules)
    elif rule_scope == "high_impact" and remediation_kb:
        allowed = {rid for rid, meta in remediation_kb.items() if is_high_impact_rule(meta)}

    if allowed is None:
        return incompat

    filtered = [row for row in rows if isinstance(row, dict) and (row.get("rule_id") or row.get("ruleId")) in allowed]
    result = dict(incompat)
    result["incompatibilities"] = filtered
    return result


def validate_inputs(
    *,
    rules_remediation: Path,
    asis_schema: Path,
    incompatibility_results: Path,
    schema_analysis: Path,
    ddl_export: Path,
    rule_scope: str = "all",
    selected_rules: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Load and cross-check the Oracle-aligned Compass artifacts.

    Returns the parsed documents plus warnings. Raises InputValidationError when
    the job must halt before any output is written.
    """
    warnings: list[str] = []
    rules, kb = _load_rules_remediation(rules_remediation)
    expected = get_settings().mssql_pg_agent.expected_rule_count
    if rules and len(rules) != expected:
        warnings.append(f"rulesRemediation loaded {len(rules)} rules; expected {expected}. Continuing.")

    asis = _load_json(asis_schema, "AS-IS JSON")
    incompat = _load_json(incompatibility_results, "Incompatibility results JSON")
    analysis = _load_json(schema_analysis, "AI analysis JSON")

    if not isinstance(asis, dict) or not isinstance(asis.get("database_objects"), dict):
        raise InputValidationError("AS-IS JSON must contain a database_objects object")
    statistics = asis.get("statistics") if isinstance(asis.get("statistics"), dict) else {}
    total_objects = statistics.get("total_objects", statistics.get("totalObjects"))
    if total_objects is not None and int(total_objects) <= 0:
        raise InputValidationError("AS-IS statistics.total_objects must be greater than 0")

    if not isinstance(incompat, dict):
        raise InputValidationError("Incompatibility results JSON must be an object")
    incompat = filter_incompatibilities_by_scope(
        incompat,
        rule_scope=rule_scope,
        selected_rules=selected_rules,
        remediation_kb=kb,
    )
    asis_name = _database_name(asis)
    incompat_name = _database_name(incompat)
    if not asis_name or not incompat_name or asis_name.lower() != incompat_name.lower():
        raise InputValidationError(f"Incompatibility database name '{incompat_name}' does not match AS-IS '{asis_name}'")

    if not isinstance(analysis, dict):
        raise InputValidationError("AI analysis JSON must be an object")
    execution_order = analysis.get("execution_order")
    if not isinstance(execution_order, dict):
        raise InputValidationError("AI analysis JSON is missing execution_order")
    ticket_missing = [key for key in TICKET_PHASE_KEYS if key not in execution_order]
    legacy_missing = [key for key in LEGACY_PHASE_KEYS if key not in execution_order]
    if ticket_missing and legacy_missing:
        warnings.append(
            "AI analysis execution_order does not match the ticket 16-phase keys or the Compass legacy keys; "
            "Pass 3 will assign phases from object type. Missing ticket keys: " + ", ".join(ticket_missing)
        )

    if not ddl_export.is_file() or ddl_export.stat().st_size == 0:
        raise InputValidationError(f"Source DDL script is missing or empty: {ddl_export.name}")

    return {
        "rules": rules,
        "remediation_kb": kb,
        "asis": asis,
        "incompatibilities": incompat,
        "analysis": analysis,
        "warnings": warnings,
        "database_name": asis_name,
    }
