"""Wires the four MSSQL -> PostgreSQL transformation passes end to end."""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any, Optional

from app.core.config import get_settings
from app.services.mssql_pg.agent_runner import make_sdk_caller
from app.services.mssql_pg.artifact_packager import list_artifacts, package_all_artifacts
from app.services.mssql_pg.context_assembler import assemble_context
from app.services.mssql_pg.converter import convert_plan
from app.services.mssql_pg.hooks import append_log
from app.services.oracle_pg.live_logs import icon_color
from app.services.mssql_pg.ddl_extractor import index_ddl_blocks
from app.services.mssql_pg.dependency_resolver import resolve_dependencies
from app.services.mssql_pg.execution_order import apply_execution_order
from app.services.mssql_pg.input_validator import (
    InputValidationError,
    _normalize_database_id_fragment,
    explicit_database_id,
    is_placeholder_scan_database_id,
    validate_inputs,
)
from app.services.mssql_pg.progress import (
    PHASE_ARTIFACTS,
    PHASE_ASSEMBLY,
    PHASE_COMPLETED,
    PHASE_FAILED,
    PHASE_MIGRATING,
    PHASE_ORDERING,
    PHASE_RESOLVING,
    PHASE_VALIDATING,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_IN_PROGRESS,
    load_conversion_plan,
    load_progress,
    save_conversion_plan,
    save_progress,
    utc_now_iso,
)
from app.services.mssql_pg.workspace import (
    REQUIRED_INPUT_PATH_KEYS,
    INPUT_PATH_KEYS,
    ensure_job_dirs,
    job_config_path,
    read_json_file,
    resolve_job_path,
    skipped_objects_path,
    write_json_file,
)

logger = logging.getLogger(__name__)
settings = get_settings()


_last_published_phase: dict[str, str] = {}


async def _publish(folder_key: str, progress: dict[str, Any]) -> None:
    """Persist progress and keep each checklist step visible before the next one."""
    save_progress(folder_key, progress)
    phase = str(progress.get("phase") or "")
    phase_changed = _last_published_phase.get(folder_key) != phase
    _last_published_phase[folder_key] = phase
    # A phase change has to stay on the wire long enough for the UI poll/SSE
    # to paint it. Object updates inside one phase are not delayed.
    await asyncio.sleep(0.35 if phase_changed else 0)
    if str(progress.get("status") or "") in {"completed", "completed_with_warnings", "failed"}:
        _last_published_phase.pop(folder_key, None)


def _ddl_text(block: Any) -> str:
    if hasattr(block, "ddl"):
        return str(block.ddl or "")
    if isinstance(block, dict):
        return str(block.get("ddl") or "")
    return ""


def _log(folder_key: str, phase: str, message: str, icon: str = "info") -> None:
    """Write one live-log line in the same shape the Oracle log stream uses."""
    append_log(folder_key, phase, message, icon=icon, color=icon_color(icon))


class TransformationOrchestrator:
    """Runs validate -> parse -> assemble -> convert -> resolve -> order -> package."""

    def __init__(self, job_manager: Any):
        self._job_manager = job_manager

    async def run(self, folder_key: str) -> None:
        config = read_json_file(job_config_path(folder_key)) or {}
        if not config:
            logger.error("Missing job config for %s", folder_key)
            return
        root = ensure_job_dirs(folder_key)

        try:
            inputs = await self._phase_validate(folder_key, config)
            ddl_index = await self._phase_parse(folder_key, inputs)
            ddl_warnings = self._cross_check_incompat_ddl(inputs, ddl_index)
            if ddl_warnings:
                progress = load_progress(folder_key)
                progress["warnings"] = (progress.get("warnings") or []) + ddl_warnings
                await _publish(folder_key, progress)
            plan, skipped, total_expected = await self._phase_assemble(folder_key, config, inputs, ddl_index)
            if await self._halt_on_missing_source(folder_key, skipped, total_expected):
                return
            plan = await self._phase_migrate(folder_key, config, plan)
            await self._phase_resolve(folder_key, plan)
            await self._phase_order(folder_key, plan, inputs.get("analysis") or {})
            await self._phase_artifacts(folder_key, config, plan, skipped, total_expected)
        except InputValidationError as exc:
            await self._mark_failed(folder_key, f"Input validation failed: {exc}")
        except Exception as exc:  # noqa: BLE001 - job must end in a terminal state, never hang
            logger.exception("Transformation failed for job %s", folder_key)
            await self._mark_failed(folder_key, str(exc))
        finally:
            self._job_manager.clear_running(folder_key)

    async def _mark_failed(self, folder_key: str, message: str) -> None:
        progress = load_progress(folder_key)
        progress["status"] = STATUS_FAILED
        progress["phase"] = PHASE_FAILED
        progress["message"] = "Transformation failed. See errorDetail for the root cause."
        progress["errorDetail"] = message
        progress["completedAt"] = utc_now_iso()
        await _publish(folder_key, progress)
        _log(folder_key, PHASE_FAILED, f"Failed: {message}", "warning")

    async def _phase_validate(self, folder_key: str, config: dict[str, Any]) -> dict[str, Any]:
        progress = load_progress(folder_key)
        progress["status"] = STATUS_IN_PROGRESS
        progress["phase"] = PHASE_VALIDATING
        progress["message"] = "Schema Analysis..."
        progress["progressPercent"] = 5
        if not progress.get("startedAt"):
            progress["startedAt"] = utc_now_iso()
        await _publish(folder_key, progress)

        _log(folder_key, PHASE_VALIDATING, "Job started: validating input files", "play")
        input_paths = config.get("inputPaths") or {}
        resolved = {key: resolve_job_path(folder_key, input_paths[key]) for key in INPUT_PATH_KEYS if input_paths.get(key)}
        missing = [key for key in REQUIRED_INPUT_PATH_KEYS if key not in resolved]
        if missing:
            raise InputValidationError(f"Missing required inputPaths: {', '.join(missing)}")

        inputs = validate_inputs(
            rules_remediation=resolved["rulesRemediation"],
            asis_schema=resolved["asisSchema"],
            incompatibility_results=resolved["incompatibilityResults"],
            schema_analysis=resolved["schemaAnalysis"],
            ddl_export=resolved["ddlExport"],
            rule_scope=str(config.get("ruleScope", "all")),
            selected_rules=list(config.get("selectedRules") or []),
        )
        for warning in inputs.get("warnings", []):
            logger.warning("Job %s input warning: %s", folder_key, warning)

        sql_name = str(inputs.get("database_name") or "")
        previous_name = config.get("databaseName")
        config["databaseName"] = sql_name or config.get("dbName") or folder_key
        name_keys = {
            _normalize_database_id_fragment(sql_name).lower(),
            _normalize_database_id_fragment(config.get("dbName") or "").lower(),
        }
        name_keys.discard("")

        def _distinct_id(value: Any) -> str:
            text = str(value or "").strip()
            if is_placeholder_scan_database_id(text):
                return ""
            if _normalize_database_id_fragment(text).lower() in name_keys:
                return ""
            return text

        scanned = explicit_database_id(inputs.get("incompatibilities") or {}, inputs["asis"])
        chosen = (
            _distinct_id(scanned)
            or _distinct_id(config.get("dbId"))
            or _distinct_id(config.get("databaseId"))
            or _distinct_id(config.get("jobId"))
        )
        changed = config.get("databaseName") != previous_name
        if chosen and config.get("dbId") != chosen:
            config["dbId"] = chosen
            changed = True
        if changed:
            write_json_file(job_config_path(folder_key), config)
        inputs["_ddl_path"] = resolved["ddlExport"]
        return inputs

    async def _phase_parse(self, folder_key: str, inputs: dict[str, Any]) -> dict[str, Any]:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_VALIDATING
        progress["message"] = "Schema Analysis..."
        progress["progressPercent"] = 5
        await _publish(folder_key, progress)
        ddl_index = index_ddl_blocks(inputs["_ddl_path"])
        _log(folder_key, PHASE_VALIDATING, f"Parsed source DDL: {len(ddl_index)} object blocks found", "search")
        return ddl_index

    def _cross_check_incompat_ddl(self, inputs: dict[str, Any], ddl_index: dict[Any, Any]) -> list[str]:
        """AC1: every incompatibility object must exist in the source DDL index."""
        from app.services.mssql_pg.context_assembler import _row_identity, _rows

        warnings: list[str] = []
        ddl_text = "\n".join(_ddl_text(block) for block in ddl_index.values())
        for row in _rows(inputs.get("incompatibilities") or {}):
            schema, name = _row_identity(row)
            if not name:
                continue
            if (schema, name) in ddl_index or ("dbo", name) in ddl_index:
                continue
            # Inline CONSTRAINT / PRIMARY KEY names live inside a CREATE TABLE block,
            # not as their own DDL index entry.
            if re.search(rf"(?i)(?<![A-Za-z0-9_]){re.escape(name)}(?![A-Za-z0-9_])", ddl_text):
                continue
            label = f"{schema}.{row.get('object_name') or row.get('name') or name}"
            warnings.append(f"Incompatibility {row.get('rule_id')} references {label} which was not found in the source DDL")
        return warnings

    async def _phase_assemble(
        self,
        folder_key: str,
        config: dict[str, Any],
        inputs: dict[str, Any],
        ddl_index: dict[Any, Any],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], Optional[int]]:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_ASSEMBLY
        progress["message"] = "Context Assembly..."
        progress["progressPercent"] = 10
        await _publish(folder_key, progress)

        existing = load_conversion_plan(folder_key)
        if existing:
            skipped = read_json_file(skipped_objects_path(folder_key)) or []
            skipped_list = skipped.get("skipped", []) if isinstance(skipped, dict) else []
            statistics = inputs["asis"].get("statistics") or {}
            total_expected = statistics.get("total_objects", statistics.get("totalObjects"))
            logger.info("Job %s already has a conversion plan with %d objects; skipping re-assembly", folder_key, len(existing))
            return existing, skipped_list, total_expected

        plan, skipped, warnings = assemble_context(
            asis=inputs["asis"],
            incompatibilities=inputs["incompatibilities"],
            analysis=inputs["analysis"],
            remediation_kb=inputs["remediation_kb"],
            ddl_index=ddl_index,
            file_name=inputs["_ddl_path"].name,
        )
        save_conversion_plan(folder_key, plan, warnings)
        write_json_file(skipped_objects_path(folder_key), {"skipped": skipped})
        _log(folder_key, PHASE_ASSEMBLY, f"Context assembled: {len(plan)} objects to convert, {len(skipped)} skipped", "code")

        progress = load_progress(folder_key)
        progress["objectsTotal"] = len(plan)
        progress["skippedCount"] = len(skipped)
        progress["warnings"] = (progress.get("warnings") or []) + warnings
        await _publish(folder_key, progress)

        statistics = inputs["asis"].get("statistics") or {}
        total_expected = statistics.get("total_objects", statistics.get("totalObjects"))
        return plan, skipped, total_expected

    async def _halt_on_missing_source(self, folder_key: str, skipped: list[dict[str, Any]], total_expected: Optional[int]) -> bool:
        halt_percent = settings.mssql_pg_agent.missing_source_halt_percent
        if halt_percent <= 0 or not total_expected:
            return False
        missing = sum(1 for s in skipped if s.get("reason") == "SOURCE_NOT_FOUND")
        percent = (missing / total_expected) * 100 if total_expected else 0
        if percent <= halt_percent:
            return False
        await self._mark_failed(
            folder_key,
            f"{missing} of {total_expected} objects ({percent:.1f}%) have no matching DDL in the source script; "
            f"halt threshold is {halt_percent}%. Verify the DDL export is complete.",
        )
        return True

    async def _phase_migrate(self, folder_key: str, config: dict[str, Any], plan: list[dict[str, Any]]) -> list[dict[str, Any]]:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_MIGRATING
        progress["message"] = "AI-Guided Conversion..."
        progress["progressPercent"] = 20
        await _publish(folder_key, progress)

        settings = get_settings().mssql_pg_agent
        _log(folder_key, PHASE_MIGRATING, f"Converting {len(plan)} objects with {settings.sonnet_model_id}", "lightning")

        async def _on_object_start(obj: dict[str, Any]) -> None:
            _log(folder_key, PHASE_MIGRATING, f"Converting {obj.get('type')} {obj.get('schema')}.{obj.get('name')}", "code")

        async def _on_progress(done: int, total: int, obj: Optional[dict[str, Any]] = None) -> None:
            progress = load_progress(folder_key)
            progress["objectsTotal"] = total
            progress["objectsConverted"] = sum(1 for o in plan if o.get("conversionStatus") in {"SUCCESS", "PARTIAL"})
            progress["objectsFailed"] = sum(1 for o in plan if o.get("conversionStatus") == "UNCONVERTIBLE")
            progress["requiresReviewCount"] = sum(1 for o in plan if o.get("requiresManualReview"))
            progress["sessionsCompleted"] = done
            if obj:
                progress["lastCompletedBatch"] = f"{obj.get('type')}:{obj.get('schema')}.{obj.get('name')}"
            progress["message"] = f"AI-Guided Conversion — {done}/{total}"
            progress["progressPercent"] = 20 + int((done / total) * 60) if total else 20
            await _publish(folder_key, progress)
            if obj:
                label = f"{obj.get('type')} {obj.get('schema')}.{obj.get('name')}"
                if obj.get("conversionStatus") == "UNCONVERTIBLE":
                    _log(folder_key, PHASE_MIGRATING, f"{done}/{total} {label}: failed - {obj.get('conversionError') or 'unknown error'}", "warning")
                else:
                    attempt_errors = obj.get("attemptErrors") or []
                    if attempt_errors:
                        _log(folder_key, PHASE_MIGRATING, f"{label}: {len(attempt_errors)} failed attempt(s), last: {attempt_errors[-1]}", "warning")
                    confidence = obj.get("confidenceScore") or "N/A"
                    review = " (needs review)" if obj.get("requiresManualReview") else ""
                    _log(folder_key, PHASE_MIGRATING, f"{done}/{total} {label}: converted, confidence {confidence}{review}", "check")
            if done % 10 == 0 or done == total:
                save_conversion_plan(folder_key, plan)

        plan = await convert_plan(
            plan,
            caller_factory=lambda: make_sdk_caller(config),
            on_progress=_on_progress,
            on_object_start=_on_object_start,
        )
        save_conversion_plan(folder_key, plan)
        converted_count = sum(1 for o in plan if o.get("conversionStatus") in {"SUCCESS", "PARTIAL"})
        failed_count = sum(1 for o in plan if o.get("conversionStatus") == "UNCONVERTIBLE")
        _log(folder_key, PHASE_MIGRATING, f"AI-guided conversion finished: {converted_count} converted, {failed_count} failed", "check")
        return plan

    async def _phase_resolve(self, folder_key: str, plan: list[dict[str, Any]]) -> None:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_RESOLVING
        progress["message"] = "Dependency Resolution..."
        progress["progressPercent"] = 82
        await _publish(folder_key, progress)
        audit = resolve_dependencies(plan)
        write_json_file(skipped_objects_path(folder_key).with_name("dependency_resolution.json"), audit)
        instead_of = sum(1 for a in audit.get("callerUpdates", []) if a.get("reason") == "INSTEAD_OF_CONVERSION")
        _log(folder_key, PHASE_RESOLVING, f"Dependencies resolved: {len(audit.get('callerUpdates', []))} caller updates, {instead_of} INSTEAD OF conversions", "settings")
        progress = load_progress(folder_key)
        progress["pass2"] = {
            "autoPatched": audit.get("autoPatched", 0),
            "flaggedCallers": audit.get("flaggedCallers", 0),
            "insteadOfConversions": instead_of,
        }
        await _publish(folder_key, progress)
        save_conversion_plan(folder_key, plan)

    async def _phase_order(self, folder_key: str, plan: list[dict[str, Any]], analysis: Optional[dict[str, Any]] = None) -> None:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_ORDERING
        progress["message"] = "Execution Order Application..."
        progress["progressPercent"] = 82
        await _publish(folder_key, progress)
        audit = apply_execution_order(plan, analysis)
        write_json_file(skipped_objects_path(folder_key).with_name("execution_order.json"), audit)
        save_conversion_plan(folder_key, plan)
        _log(folder_key, PHASE_ORDERING, f"Execution order applied to {len(plan)} objects", "settings")
        if audit.get("validationErrors"):
            progress = load_progress(folder_key)
            progress["warnings"] = (progress.get("warnings") or []) + [f"Pass 3: {err}" for err in audit["validationErrors"]]
            await _publish(folder_key, progress)
            logger.warning("Job %s Pass 3 validation issues (continuing to Pass 4): %s", folder_key, audit["validationErrors"])

    async def _phase_artifacts(
        self,
        folder_key: str,
        config: dict[str, Any],
        plan: list[dict[str, Any]],
        skipped: list[dict[str, Any]],
        total_expected: Optional[int],
    ) -> None:
        progress = load_progress(folder_key)
        progress["phase"] = PHASE_ARTIFACTS
        progress["message"] = "Generate PostgreSQL Scripts..."
        progress["progressPercent"] = 90
        await _publish(folder_key, progress)

        progress = load_progress(folder_key)
        progress["completedAt"] = utc_now_iso()
        await _publish(folder_key, progress)

        # File prefix is dbName (same as the Oracle artifact URLs); dbId stays on the config.
        db_name = config.get("dbName") or folder_key
        result = package_all_artifacts(folder_key, db_name, config, plan, skipped, total_objects_expected=total_expected)

        failed_count = sum(1 for o in plan if o.get("conversionStatus") == "UNCONVERTIBLE")
        review_count = sum(1 for o in plan if o.get("requiresManualReview"))

        artifacts = list_artifacts(folder_key, db_name)
        _log(folder_key, PHASE_ARTIFACTS, f"Generated {len(artifacts)} output files", "check")
        _log(
            folder_key,
            PHASE_COMPLETED,
            f"Completed: {sum(1 for o in plan if o.get('conversionStatus') in {'SUCCESS', 'PARTIAL'})} converted, "
            f"{failed_count} failed, {review_count} need review",
            "check",
        )
        progress = load_progress(folder_key)
        progress["status"] = STATUS_COMPLETED
        progress["phase"] = PHASE_COMPLETED
        progress["message"] = "DB Modernization Completed"
        if failed_count or review_count:
            progress["message"] = f"DB Modernization Completed with warnings: {failed_count} failed, {review_count} need review"
        progress["progressPercent"] = 100
        progress["objectsTotal"] = len(plan)
        progress["objectsConverted"] = sum(1 for o in plan if o.get("conversionStatus") in {"SUCCESS", "PARTIAL"})
        progress["objectsFailed"] = failed_count
        progress["requiresReviewCount"] = review_count
        progress["sessionsCompleted"] = progress.get("sessionsCompleted") or len(plan)
        progress["outputFiles"] = [a["name"] for a in artifacts]
        progress["artifacts"] = artifacts
        if not result.get("completeSchemaValid"):
            progress["warnings"] = (progress.get("warnings") or []) + ["complete_schema.sql did not exactly match the concatenated phase scripts"]
        await _publish(folder_key, progress)
