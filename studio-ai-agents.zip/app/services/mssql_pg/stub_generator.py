"""Deterministic output for objects that are never sent to the model (Sub-PRD 2)."""

from __future__ import annotations

import re
from typing import Any, Optional

_TYPE_MAP = {
    "bit": "boolean",
    "tinyint": "smallint",
    "smallint": "smallint",
    "int": "integer",
    "bigint": "bigint",
    "money": "numeric(19,4)",
    "smallmoney": "numeric(10,4)",
    "float": "double precision",
    "real": "real",
    "datetime": "timestamp(3)",
    "datetime2": "timestamp",
    "smalldatetime": "timestamp(0)",
    "datetimeoffset": "timestamptz",
    "date": "date",
    "time": "time",
    "uniqueidentifier": "uuid",
    "nvarchar": "varchar",
    "varchar": "varchar",
    "nchar": "char",
    "char": "char",
    "ntext": "text",
    "text": "text",
    "varbinary": "bytea",
    "binary": "bytea",
    "image": "bytea",
    "xml": "xml",
    "sql_variant": "text",
    "hierarchyid": "text",
    "geography": "text",
    "geometry": "text",
    "sysname": "varchar(128)",
}


def pg_ident(name: str) -> str:
    return str(name).replace("[", "").replace("]", "").replace('"', "").lower()


def pg_qualified(schema: str, name: str) -> str:
    return f"{pg_ident(schema)}.{pg_ident(name)}"


def map_type(sql_type: Optional[str]) -> str:
    if not sql_type:
        return "text"
    raw = str(sql_type).strip().lower().replace("[", "").replace("]", "")
    match = re.match(r"[a-z_0-9]+", raw)
    if not match:
        return "text"
    name = match.group(0)
    suffix = raw[len(name):].strip()
    if "(max)" in suffix.replace(" ", ""):
        return "bytea" if name in {"varbinary", "binary"} else "text"
    mapped = _TYPE_MAP.get(name)
    if mapped is None:
        return raw
    if name in {"decimal", "numeric"}:
        return f"numeric{suffix}"
    if suffix and name in {"nvarchar", "varchar", "nchar", "char"}:
        return f"{mapped}{suffix}"
    return mapped


def _params(obj: dict[str, Any]) -> list[tuple[str, str, str]]:
    params = (obj.get("structuralMetadata") or {}).get("parameters")
    result = []
    if isinstance(params, list):
        for param in params:
            if not isinstance(param, dict):
                continue
            name = str(param.get("name") or param.get("parameter_name") or "").lstrip("@")
            if not name:
                continue
            mode = "INOUT" if param.get("is_output") or str(param.get("direction") or "").upper() in {"OUT", "OUTPUT", "INOUT"} else "IN"
            result.append((f"p_{pg_ident(name)}", map_type(param.get("data_type") or param.get("type")), mode))
    return result


def _signature(obj: dict[str, Any]) -> str:
    return ", ".join(f"{mode} {name} {ptype}" if mode != "IN" else f"{name} {ptype}" for name, ptype, mode in _params(obj))


def _header_note(lines: list[str]) -> str:
    return "\n".join(f"-- {line}" if line else "--" for line in lines)


def _result(code: str, reason: str, priority: str, confidence: str = "MANUAL", status: str = "PARTIAL") -> dict[str, Any]:
    return {
        "conversionStatus": status,
        "convertedCode": code,
        "confidenceScore": confidence,
        "requiresManualReview": confidence in {"LOW", "MANUAL"},
        "reviewGuidance": [{"reason": reason, "priority": priority}] if reason else [],
        "changesApplied": [],
        "comments": [reason] if reason else [],
    }


def _clr_routine(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    qualified = pg_qualified(obj["schema"], obj["name"])
    assembly = meta.get("assembly_name") or meta.get("clr_assembly") or "unknown"
    clr_method = meta.get("clr_method") or meta.get("external_name") or "unknown"
    note = _header_note(
        [
            f"PG-113 CLR assembly '{assembly}' has no PostgreSQL equivalent.",
            f"Original external name: {clr_method}.",
            "ACTION REQUIRED: rewrite the logic in PL/pgSQL or a supported extension.",
        ]
    )
    if obj["type"] == "PROCEDURE":
        code = (
            f"{note}\nCREATE OR REPLACE PROCEDURE {qualified}({_signature(obj)})\nLANGUAGE plpgsql\nAS $$\nBEGIN\n"
            f"    RAISE EXCEPTION 'CLR procedure {qualified} must be rewritten manually';\nEND;\n$$;"
        )
    else:
        return_type = map_type(meta.get("return_type")) if meta.get("return_type") else "void"
        if str(meta.get("function_type") or "").upper().endswith("TVF"):
            return_type = "SETOF record"
        code = (
            f"{note}\nCREATE OR REPLACE FUNCTION {qualified}({_signature(obj)})\nRETURNS {return_type}\n"
            f"LANGUAGE plpgsql\nAS $$\nBEGIN\n    RAISE EXCEPTION 'CLR function {qualified} must be rewritten manually';\nEND;\n$$;"
        )
    result = _result(code, f"CLR {obj['type'].lower()} stub; rewrite required", "CRITICAL")
    result["newSignature"] = f"{qualified}({_signature(obj)})"
    result["callerUpdatesNeeded"] = [{"reason": "CLR_REPLACEMENT", "callee": f"{obj['schema']}.{obj['name']}", "new_signature": result["newSignature"]}]
    return result


def _clr_trigger(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    qualified = pg_qualified(obj["schema"], obj["name"])
    owner = obj.get("owningTable") or "unknown.table"
    owner_q = pg_qualified(*owner.split(".", 1)) if "." in owner else pg_ident(owner)
    events = meta.get("trigger_events") or ["INSERT", "UPDATE", "DELETE"]
    if isinstance(events, str):
        events = [p.strip() for p in events.split(",") if p.strip()]
    fn_name = f"{qualified}_fn"
    code = (
        f"{_header_note(['PG-113 CLR trigger has no PostgreSQL equivalent.', 'ACTION REQUIRED: rewrite trigger logic in PL/pgSQL.'])}\n"
        f"CREATE OR REPLACE FUNCTION {fn_name}()\nRETURNS trigger\nLANGUAGE plpgsql\nAS $$\nBEGIN\n"
        f"    RAISE WARNING 'CLR trigger {qualified} is a stub and performs no work';\n"
        "    IF TG_OP = 'DELETE' THEN\n        RETURN OLD;\n    END IF;\n    RETURN NEW;\nEND;\n$$;\n\n"
        f"CREATE TRIGGER {pg_ident(obj['name'])}\nAFTER {' OR '.join(str(e).upper() for e in events)} ON {owner_q}\n"
        f"FOR EACH ROW EXECUTE FUNCTION {fn_name}();"
    )
    return _result(code, "CLR trigger stub; rewrite required", "CRITICAL")


def _encrypted(obj: dict[str, Any]) -> dict[str, Any]:
    qualified = pg_qualified(obj["schema"], obj["name"])
    code = _header_note(
        [
            f"{obj['type']} {qualified} is WITH ENCRYPTION in SQL Server; source text is unavailable.",
            "ACTION REQUIRED: obtain the original source from the application team and convert it manually.",
        ]
    )
    return _result(code, "Encrypted object; source unavailable", "CRITICAL", status="UNCONVERTIBLE")


def _udt_clr(obj: dict[str, Any]) -> dict[str, Any]:
    qualified = pg_qualified(obj["schema"], obj["name"])
    code = (
        f"{_header_note(['PG-113 CLR user-defined type has no PostgreSQL equivalent.', 'Columns and parameters use jsonb until a replacement is designed.'])}\n"
        f"CREATE DOMAIN {qualified} AS jsonb;"
    )
    result = _result(code, "CLR user-defined type replaced with jsonb domain", "CRITICAL")
    result["callerUpdatesNeeded"] = [{"reason": "UDT_ELIMINATION", "callee": f"{obj['schema']}.{obj['name']}", "replacement_type": "jsonb"}]
    return result


def _unsupported_index(obj: dict[str, Any], kind: str) -> dict[str, Any]:
    qualified = pg_qualified(obj["schema"], obj["name"])
    suggestion = {
        "COLUMNSTORE": "Consider a BRIN index, partitioning, or a columnar extension such as Citus columnar.",
        "FULLTEXT": "Use a tsvector column with a GIN index.",
        "XML": "Use an expression index on xpath() results.",
    }.get(kind, "Design a PostgreSQL alternative.")
    code = _header_note(
        [
            f"{kind} index {qualified} on {obj.get('owningTable') or 'unknown table'} has no direct equivalent.",
            suggestion,
            "ACTION REQUIRED: create the replacement index manually.",
        ]
    )
    return _result(code, f"{kind} index requires manual redesign", "HIGH", status="UNCONVERTIBLE")


def _partition_comment(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    lines = [f"SQL Server {obj['type'].replace('_', ' ').lower()} {obj['schema']}.{obj['name']}."]
    if meta.get("boundary_values") is not None:
        lines.append(f"Boundary values: {meta.get('boundary_values')} (RANGE {meta.get('range_type') or 'LEFT'}).")
    if meta.get("filegroups"):
        lines.append(f"Filegroups: {meta.get('filegroups')} (no PostgreSQL equivalent).")
    lines.append("PostgreSQL uses declarative partitioning; partitions are created with the tables in phase 6.")
    return _result(_header_note(lines), "", "LOW", confidence="MEDIUM", status="SUCCESS")


def _schema_stub(obj: dict[str, Any]) -> dict[str, Any]:
    return _result(f"CREATE SCHEMA IF NOT EXISTS {pg_ident(obj['name'])};", "", "LOW", confidence="HIGH", status="SUCCESS")


def _linked_server(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    code = _header_note(
        [
            f"Linked server {obj['name']} (provider {meta.get('provider') or 'unknown'}, data source {meta.get('data_source') or 'unknown'}).",
            "Use postgres_fdw / oracle_fdw / tds_fdw: CREATE SERVER, CREATE USER MAPPING, IMPORT FOREIGN SCHEMA.",
            "ACTION REQUIRED: configure the foreign data wrapper and credentials manually.",
        ]
    )
    return _result(code, "Linked server requires FDW setup", "CRITICAL", status="UNCONVERTIBLE")


def _always_encrypted(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    code = _header_note(
        [
            f"Always Encrypted column {obj['name']} (encryption {meta.get('encryption_type') or 'unknown'}, key {meta.get('column_encryption_key') or 'unknown'}).",
            "PostgreSQL has no client-side Always Encrypted equivalent.",
            "Options: pgcrypto pgp_sym_encrypt() with application-managed keys, or application-layer encryption.",
            "ACTION REQUIRED: choose an encryption strategy and migrate keys.",
        ]
    )
    return _result(code, "Always Encrypted has no PostgreSQL equivalent", "CRITICAL")


def _cross_server_synonym(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    code = _header_note(
        [
            f"Synonym {obj['schema']}.{obj['name']} -> {meta.get('referenced_object')} references a linked server.",
            "Create a postgres_fdw foreign table and reference it directly; PostgreSQL has no synonyms.",
            "ACTION REQUIRED: configure the foreign server before resolving callers.",
        ]
    )
    result = _result(code, "Cross-server synonym requires FDW", "CRITICAL", status="UNCONVERTIBLE")
    result["callerUpdatesNeeded"] = [{"reason": "SYNONYM_RESOLUTION", "callee": f"{obj['schema']}.{obj['name']}", "is_cross_server": True}]
    return result


def _synonym(obj: dict[str, Any]) -> dict[str, Any]:
    meta = obj.get("structuralMetadata") or {}
    target_schema = meta.get("referenced_schema") or "dbo"
    target_name = meta.get("referenced_name") or "unknown"
    target = pg_qualified(target_schema, target_name)
    lines = [
        f"Synonym {obj['schema']}.{obj['name']} -> {meta.get('referenced_object')}.",
        f"PostgreSQL has no synonyms; callers reference {target} directly (resolved in Pass 2).",
    ]
    confidence, reason, priority = "HIGH", "", "LOW"
    if meta.get("is_cross_database"):
        lines.append(f"Target is in database {meta.get('referenced_database')}; mapped to schema {pg_ident(target_schema)}. Verify the schema exists or use postgres_fdw.")
        confidence, reason, priority = "LOW", "Cross-database synonym mapped to a local schema", "HIGH"
    result = _result(_header_note(lines), reason, priority, confidence=confidence, status="SUCCESS")
    result["convertedName"] = target
    result["callerUpdatesNeeded"] = [
        {"reason": "SYNONYM_RESOLUTION", "callee": f"{obj['schema']}.{obj['name']}", "target": target, "is_cross_database": bool(meta.get("is_cross_database"))}
    ]
    return result


def _index_kind(obj: dict[str, Any]) -> Optional[str]:
    meta = obj.get("structuralMetadata") or {}
    text = f"{meta.get('index_type') or ''} {(obj.get('sourceCode') or {}).get('ddl') or ''}".upper()
    if "COLUMNSTORE" in text:
        return "COLUMNSTORE"
    if "FULLTEXT" in text or "FULL_TEXT" in text:
        return "FULLTEXT"
    if re.search(r"\bXML\b", text) and "INDEX" in text:
        return "XML"
    return None


def deterministic_result(obj: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Return a stub only when the object has no body the model can rewrite.

    Sub-PRD 2: CLR and encrypted objects skip the model. Every other type,
    including tables and constraints, is sent to the model.
    """
    obj_type = obj["type"]
    if obj.get("isEncrypted"):
        return _encrypted(obj)
    if obj.get("isClr"):
        if obj_type in {"FUNCTION", "PROCEDURE"}:
            return _clr_routine(obj)
        if obj_type == "TRIGGER":
            return _clr_trigger(obj)
        if obj_type == "USER_DEFINED_TYPE":
            return _udt_clr(obj)
        return _clr_routine(obj)
    return None
