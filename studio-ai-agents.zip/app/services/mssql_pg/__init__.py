"""MSSQL → PostgreSQL transformation engine (separate from app.services.oracle_pg)."""
