"""Progress file, phase/status constants and the 16-phase script order."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from app.services.mssql_pg.hooks import notify_progress_update
from app.services.mssql_pg.workspace import conversion_plan_path, progress_path

logger = logging.getLogger(__name__)

# Same labels the Oracle progress checklist already renders.
PHASE_VALIDATING = "Schema Analysis"
PHASE_PARSING = "Schema Analysis"
PHASE_ASSEMBLY = "Context Assembly"
PHASE_MIGRATING = "AI-Guided Conversion"
PHASE_RESOLVING = "Dependency Resolution"
PHASE_ORDERING = "Execution Order Application"
PHASE_ARTIFACTS = "Generate PostgreSQL Scripts"
PHASE_COMPLETED = "Completed"
PHASE_FAILED = "Failed"

STATUS_QUEUED = "queued"
STATUS_IN_PROGRESS = "in_progress"
STATUS_COMPLETED = "completed"
STATUS_COMPLETED_WITH_WARNINGS = "completed_with_warnings"
STATUS_FAILED = "failed"

TERMINAL_JOB_STATUSES = frozenset({STATUS_COMPLETED, STATUS_COMPLETED_WITH_WARNINGS, STATUS_FAILED})

# Pass 4: 16 phase files + complete_schema.sql.
# Indexed views are CREATE MATERIALIZED VIEW statements inside the views file.
# Row security, masking, and Always Encrypted DDL is appended in the tables file.
SCRIPT_ORDER = [
    "create_schemas.sql",
    "create_sequences.sql",
    "create_user_defined_types.sql",
    "create_partition_functions.sql",
    "create_partition_schemes.sql",
    "create_tables.sql",
    "create_primary_keys.sql",
    "create_unique_constraints.sql",
    "create_foreign_keys.sql",
    "create_check_constraints.sql",
    "create_indexes.sql",
    "create_views.sql",
    "create_functions.sql",
    "create_procedures.sql",
    "create_triggers.sql",
    "create_synonyms.sql",
]

EXECUTION_PHASE_BY_TYPE = {
    "SCHEMA": 1,
    "SEQUENCE": 2,
    "USER_DEFINED_TYPE": 3,
    "PARTITION_FUNCTION": 4,
    "PARTITION_SCHEME": 5,
    "TABLE": 6,
    "DEFAULT_CONSTRAINT": 6,
    "RLS_POLICY": 6,
    "DDM_DEFINITION": 6,
    "AE_DEFINITION": 6,
    "PRIMARY_KEY": 7,
    "UNIQUE_CONSTRAINT": 8,
    "FOREIGN_KEY": 9,
    "CHECK_CONSTRAINT": 10,
    "INDEX": 11,
    "VIEW": 12,
    "MATERIALIZED_VIEW": 12,
    "FUNCTION": 13,
    "PROCEDURE": 14,
    "TRIGGER": 15,
    "SYNONYM": 16,
    "LINKED_SERVER": 16,
}

# Defaults are clauses on a table, not their own PostgreSQL object.
INLINE_WITH_TABLE_TYPES = frozenset({"DEFAULT_CONSTRAINT"})


def iter_deliverable_objects(plan: list[dict[str, Any]]):
    """Objects that appear in the PostgreSQL scripts.

    Column defaults are not counted. A table, procedure, or index name that
    the source defines more than once counts once, because PostgreSQL keeps
    one object for that schema-qualified name.
    """
    seen: set[tuple[str, str, str]] = set()
    for obj in plan:
        kind = str(obj.get("type") or "").upper()
        if kind in INLINE_WITH_TABLE_TYPES:
            continue
        schema = str(obj.get("schema") or "").lower()
        name = str(obj.get("name") or "").lower()
        key = (kind, schema, name)
        if key in seen:
            continue
        seen.add(key)
        yield obj


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_terminal_job_status(status: Any) -> bool:
    return str(status or "").lower() in TERMINAL_JOB_STATUSES


def is_job_terminal(job_id: str) -> bool:
    return is_terminal_job_status(load_progress(job_id).get("status"))


def is_terminal_progress_event(event: dict[str, Any]) -> bool:
    if event.get("type") != "progress_updated":
        return False
    return is_terminal_job_status(event.get("status"))


def default_progress(job_id: str) -> dict[str, Any]:
    return {
        "jobId": job_id,
        "phase": PHASE_VALIDATING,
        "status": STATUS_QUEUED,
        "objectsTotal": 0,
        "objectsConverted": 0,
        "objectsFailed": 0,
        "skippedCount": 0,
        "requiresReviewCount": 0,
        "sessionsCompleted": 0,
        "lastCompletedBatch": None,
        "progressPercent": 0,
        "message": "Job queued",
        "startedAt": None,
        "updatedAt": utc_now_iso(),
        "completedAt": None,
        "warnings": [],
        "outputFiles": [],
        "errorDetail": None,
    }


def load_progress(job_id: str) -> dict[str, Any]:
    path = progress_path(job_id)
    if not path.exists():
        return default_progress(job_id)
    try:
        with path.open(encoding="utf-8") as fh:
            progress = json.load(fh)
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        logger.exception("Unreadable progress file for %s; using defaults", job_id)
        return default_progress(job_id)
    if not isinstance(progress, dict):
        return default_progress(job_id)
    return progress


def save_progress(job_id: str, progress: dict[str, Any]) -> None:
    progress["updatedAt"] = utc_now_iso()
    path = progress_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(progress, fh, indent=2)
    # A hook failure must not fail launch or turn the log stream into a 500.
    try:
        notify_progress_update(job_id, progress)
    except Exception:
        logger.exception("Progress notify failed for %s", job_id)


def load_conversion_plan(job_id: str) -> list[dict[str, Any]]:
    path = conversion_plan_path(job_id)
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict) and isinstance(data.get("objects"), list):
        return data["objects"]
    if isinstance(data, list):
        return data
    return []


def save_conversion_plan(job_id: str, plan: list[dict[str, Any]], warnings: list[str] | None = None) -> None:
    path = conversion_plan_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump({"objects": plan, "assemblyWarnings": warnings or []}, fh, indent=2)
