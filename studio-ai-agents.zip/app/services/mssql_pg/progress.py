"""Progress file, phase/status constants and the 16-phase script order."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from app.services.mssql_pg.hooks import notify_progress_update
from app.services.mssql_pg.workspace import conversion_plan_path, progress_path

PHASE_VALIDATING = "Validating Inputs"
PHASE_PARSING = "Parsing DDL"
PHASE_ASSEMBLY = "Context Assembly"
PHASE_MIGRATING = "AI-Guided Conversion"
PHASE_RESOLVING = "Dependency Resolution"
PHASE_ORDERING = "Execution Order Application"
PHASE_ARTIFACTS = "Generate PostgreSQL Scripts"
PHASE_COMPLETED = "Completed"
PHASE_FAILED = "Failed"

STATUS_QUEUED = "queued"
STATUS_IN_PROGRESS = "in_progress"
STATUS_COMPLETED = "completed"
STATUS_COMPLETED_WITH_WARNINGS = "completed_with_warnings"
STATUS_FAILED = "failed"

TERMINAL_JOB_STATUSES = frozenset({STATUS_COMPLETED, STATUS_COMPLETED_WITH_WARNINGS, STATUS_FAILED})

# Ticket AC5 / AC6: 16 phase files + complete_schema.sql.
SCRIPT_ORDER = [
    "create_schemas.sql",
    "create_sequences.sql",
    "create_types.sql",
    "create_tables.sql",
    "create_primary_keys.sql",
    "create_unique_constraints.sql",
    "create_foreign_keys.sql",
    "create_check_constraints.sql",
    "create_indexes.sql",
    "create_views.sql",
    "create_materialized_views.sql",
    "create_functions.sql",
    "create_procedures.sql",
    "create_triggers.sql",
    "create_security_policies.sql",
    "create_synonyms.sql",
]

EXECUTION_PHASE_BY_TYPE = {
    "SCHEMA": 1,
    "SEQUENCE": 2,
    "USER_DEFINED_TYPE": 3,
    "TABLE": 4,
    "DEFAULT_CONSTRAINT": 4,
    "PARTITION_FUNCTION": 4,  # comment-only block in the tables file (AC6)
    "PRIMARY_KEY": 5,
    "PARTITION_SCHEME": 5,  # comment-only block in the PK file (AC6)
    "UNIQUE_CONSTRAINT": 6,
    "FOREIGN_KEY": 7,
    "CHECK_CONSTRAINT": 8,
    "INDEX": 9,
    "VIEW": 10,
    "MATERIALIZED_VIEW": 11,
    "FUNCTION": 12,
    "PROCEDURE": 13,
    "TRIGGER": 14,
    "RLS_POLICY": 15,
    "DDM_DEFINITION": 15,
    "AE_DEFINITION": 15,
    "SYNONYM": 16,
    "LINKED_SERVER": 16,
}

INLINE_WITH_TABLE_TYPES = frozenset({"DEFAULT_CONSTRAINT", "PARTITION_FUNCTION"})


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_terminal_job_status(status: Any) -> bool:
    return str(status or "").lower() in TERMINAL_JOB_STATUSES


def is_job_terminal(job_id: str) -> bool:
    return is_terminal_job_status(load_progress(job_id).get("status"))


def is_terminal_progress_event(event: dict[str, Any]) -> bool:
    if event.get("type") != "progress_updated":
        return False
    return is_terminal_job_status(event.get("status"))


def default_progress(job_id: str) -> dict[str, Any]:
    return {
        "jobId": job_id,
        "phase": PHASE_VALIDATING,
        "status": STATUS_QUEUED,
        "objectsTotal": 0,
        "objectsConverted": 0,
        "objectsFailed": 0,
        "skippedCount": 0,
        "requiresReviewCount": 0,
        "sessionsCompleted": 0,
        "lastCompletedBatch": None,
        "progressPercent": 0,
        "message": "Job queued",
        "startedAt": None,
        "updatedAt": utc_now_iso(),
        "completedAt": None,
        "warnings": [],
        "outputFiles": [],
        "errorDetail": None,
    }


def load_progress(job_id: str) -> dict[str, Any]:
    path = progress_path(job_id)
    if not path.exists():
        return default_progress(job_id)
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def save_progress(job_id: str, progress: dict[str, Any]) -> None:
    progress["updatedAt"] = utc_now_iso()
    path = progress_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(progress, fh, indent=2)
    notify_progress_update(job_id, progress)


def load_conversion_plan(job_id: str) -> list[dict[str, Any]]:
    path = conversion_plan_path(job_id)
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict) and isinstance(data.get("objects"), list):
        return data["objects"]
    if isinstance(data, list):
        return data
    return []


def save_conversion_plan(job_id: str, plan: list[dict[str, Any]], warnings: list[str] | None = None) -> None:
    path = conversion_plan_path(job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump({"objects": plan, "assemblyWarnings": warnings or []}, fh, indent=2)
