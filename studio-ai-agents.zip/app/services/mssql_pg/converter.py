"""Pass 1, step 2: convert every plan entry, deterministically or via the model."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, Optional

from app.core.config import get_settings
from app.services.mssql_pg.agent_runner import SdkCaller
from app.services.mssql_pg.confidence import lowest
from app.services.mssql_pg.conversion_validator import ValidationError, parse_and_validate, unconvertible_result
from app.services.mssql_pg.prompts import build_conversion_prompt, build_repair_prompt
from app.services.mssql_pg.structural_rewriter import normalize_plan_ddl
from app.services.mssql_pg.stub_generator import deterministic_result

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[int, int], Awaitable[None]]


def _apply_result(obj: dict[str, Any], result: dict[str, Any], *, source: str) -> None:
    obj["conversionStatus"] = result["conversionStatus"]
    obj["convertedCode"] = result["convertedCode"]
    obj["convertedName"] = result.get("convertedName")
    obj["newSignature"] = result.get("newSignature")
    obj["confidenceScore"] = lowest(result.get("confidenceScore"), obj.get("confidenceFloor"))
    if obj["confidenceScore"] in {"LOW", "MANUAL"}:
        obj["requiresManualReview"] = True
    obj["changesApplied"] = result.get("changesApplied", [])
    obj["comments"] = result.get("comments", [])
    obj["requiresManualReview"] = bool(obj.get("requiresManualReview")) or bool(result.get("requiresManualReview"))
    obj["reviewGuidance"] = (obj.get("reviewGuidance") or []) + result.get("reviewGuidance", [])
    obj["callerUpdatesNeeded"] = result.get("callerUpdatesNeeded", [])
    obj["conversionSource"] = source
    obj["status"] = "failed" if result["conversionStatus"] == "UNCONVERTIBLE" else "converted"


async def convert_object(
    obj: dict[str, Any],
    caller: Optional[SdkCaller],
    *,
    timeout_seconds: int,
    timeout_retries: int,
) -> dict[str, Any]:
    """Convert one plan entry in place and return it."""
    deterministic = deterministic_result(obj)
    if deterministic is not None:
        _apply_result(obj, deterministic, source="DETERMINISTIC")
        return obj

    if caller is None:
        _apply_result(obj, unconvertible_result(obj, "No model caller configured for this job"), source="AI_UNAVAILABLE")
        return obj

    prompt = build_conversion_prompt(obj)
    last_error = "Unknown error"
    attempts = max(1, timeout_retries + 1)
    attempt_errors: list[str] = []
    obj["attemptErrors"] = attempt_errors

    for attempt in range(attempts):
        try:
            raw = await asyncio.wait_for(caller(prompt), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            last_error = f"Model call timed out after {timeout_seconds}s (attempt {attempt + 1}/{attempts})"
            attempt_errors.append(last_error)
            logger.warning("Conversion timeout for %s.%s: %s", obj["schema"], obj["name"], last_error)
            continue
        except Exception as exc:  # noqa: BLE001 - any SDK/transport failure should retry, not crash the job
            last_error = f"Model call failed: {exc}"
            attempt_errors.append(last_error)
            logger.warning("Conversion call failed for %s.%s: %s", obj["schema"], obj["name"], exc)
            continue

        try:
            result = parse_and_validate(raw, obj)
            _apply_result(obj, result, source="AI")
            return obj
        except ValidationError as verr:
            last_error = f"Invalid model response: {verr}"
            repair_prompt = build_repair_prompt(obj, previous_response=raw, error=str(verr))
            try:
                raw_repair = await asyncio.wait_for(caller(repair_prompt), timeout=timeout_seconds)
                result = parse_and_validate(raw_repair, obj)
                _apply_result(obj, result, source="AI_REPAIRED")
                return obj
            except asyncio.TimeoutError:
                last_error = f"Repair call timed out after {timeout_seconds}s"
            except ValidationError as verr2:
                last_error = f"Repair response still invalid: {verr2}"
            except Exception as exc:  # noqa: BLE001
                last_error = f"Repair call failed: {exc}"
            attempt_errors.append(last_error)
            logger.warning("Repair attempt failed for %s.%s: %s", obj["schema"], obj["name"], last_error)

    obj["conversionError"] = last_error
    _apply_result(obj, unconvertible_result(obj, last_error), source="AI_FAILED")
    return obj


async def convert_plan(
    plan: list[dict[str, Any]],
    *,
    caller_factory: Callable[[], Optional[SdkCaller]],
    concurrency: Optional[int] = None,
    timeout_seconds: Optional[int] = None,
    timeout_retries: Optional[int] = None,
    on_progress: Optional[ProgressCallback] = None,
    on_object_start: Optional[Callable[[dict[str, Any]], Awaitable[None]]] = None,
) -> list[dict[str, Any]]:
    """Convert every pending object, bounding concurrent model calls with a semaphore.

    CLR and encrypted stubs never touch the semaphore or the model. Every other
    pending object is sent through the model. Objects whose status is already
    "converted" or "failed" (a resumed job) are left untouched so a restart
    does not re-spend AI budget on work already done.
    """
    settings = get_settings().mssql_pg_agent
    concurrency = concurrency or settings.ai_concurrency
    timeout_seconds = timeout_seconds or settings.ai_call_timeout_seconds
    timeout_retries = settings.ai_timeout_retries if timeout_retries is None else timeout_retries

    semaphore = asyncio.Semaphore(max(1, concurrency))
    caller = caller_factory()
    todo: list[dict[str, Any]] = []
    for obj in plan:
        if obj.get("status") == "pending":
            todo.append(obj)
        elif obj.get("status") == "failed":
            obj["status"] = "pending"
            todo.append(obj)
    done = len(plan) - len(todo)
    total = len(plan)
    lock = asyncio.Lock()

    async def _run(obj: dict[str, Any]) -> dict[str, Any]:
        nonlocal done
        if deterministic_result(obj) is not None:
            result = await convert_object(obj, None, timeout_seconds=timeout_seconds, timeout_retries=timeout_retries)
        else:
            async with semaphore:
                if on_object_start is not None:
                    await on_object_start(obj)
                result = await convert_object(obj, caller, timeout_seconds=timeout_seconds, timeout_retries=timeout_retries)
        async with lock:
            done += 1
            if on_progress is not None:
                try:
                    await on_progress(done, total, obj)
                except TypeError:
                    await on_progress(done, total)
        return result

    if todo:
        await asyncio.gather(*(_run(obj) for obj in todo))
    normalize_plan_ddl(plan)
    return plan
