"""Claude Agent SDK caller for one-shot, per-object MSSQL -> PostgreSQL conversions.

Unlike the Oracle engine (which runs whole-directory agentic sessions with file tools),
each MSSQL call is a single stateless text-in/text-out exchange: one object's context goes
in, one JSON conversion result comes out. No file tools are granted to the model.
"""

from __future__ import annotations

import asyncio
import os
import queue
import sys
import threading
from typing import Any, AsyncIterator, Awaitable, Callable, Optional

from app.core.config import get_settings

SdkCaller = Callable[[str], Awaitable[str]]

_QUERY_DONE = object()


def _needs_windows_subprocess_workaround() -> bool:
    """Uvicorn --reload on Windows uses SelectorEventLoop, which cannot spawn subprocesses."""
    if sys.platform != "win32":
        return False
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False
    return not isinstance(loop, asyncio.ProactorEventLoop)


async def _iter_sdk_messages(prompt: str, options: Any) -> AsyncIterator[Any]:
    """Yield SDK messages, using a Proactor loop thread on Windows when required."""
    from claude_agent_sdk import query

    if not _needs_windows_subprocess_workaround():
        async for message in query(prompt=prompt, options=options):
            yield message
        return

    message_queue: "queue.Queue[Any]" = queue.Queue()
    error_holder: list[BaseException] = []

    def _worker() -> None:
        loop = asyncio.ProactorEventLoop()
        asyncio.set_event_loop(loop)

        async def _run() -> None:
            try:
                async for message in query(prompt=prompt, options=options):
                    message_queue.put(message)
            except BaseException as exc:
                error_holder.append(exc)
            finally:
                message_queue.put(_QUERY_DONE)

        try:
            loop.run_until_complete(_run())
        finally:
            loop.close()

    thread = threading.Thread(target=_worker, name="mssql-pg-agent-sdk", daemon=True)
    thread.start()

    while True:
        message = await asyncio.to_thread(message_queue.get)
        if message is _QUERY_DONE:
            break
        yield message

    thread.join(timeout=1)
    if error_holder:
        raise error_holder[0]


def _apply_stream_close_timeout_env() -> None:
    """Match Oracle schema agent: SDK reads CLAUDE_CODE_STREAM_CLOSE_TIMEOUT from process env."""
    value = str(get_settings().oracle_pg_agent.stream_close_timeout_ms)
    os.environ["CLAUDE_CODE_STREAM_CLOSE_TIMEOUT"] = value


def _resolve_model_id(job_config: dict[str, Any]) -> str:
    agent = str(job_config.get("aiAgent", "")).lower()
    if "haiku" in agent:
        return "haiku"
    if "opus" in agent:
        return "opus"
    return "sonnet"


def _build_options(job_config: dict[str, Any]) -> Any:
    from claude_agent_sdk import ClaudeAgentOptions

    _apply_stream_close_timeout_env()
    settings = get_settings().mssql_pg_agent
    return ClaudeAgentOptions(
        model=_resolve_model_id(job_config),
        permission_mode="bypassPermissions",
        setting_sources=[],
        allowed_tools=[],
        max_turns=settings.max_turns_per_session,
        max_budget_usd=settings.max_budget_usd_per_session,
        max_buffer_size=settings.max_buffer_size_bytes,
        env=settings.bedrock_env(get_settings().bedrock.region),
        cli_path=settings.cli_path or None,
    )


async def call_model(prompt: str, job_config: dict[str, Any]) -> str:
    """Send one prompt, return the concatenated text of the final assistant result."""
    try:
        from claude_agent_sdk.types import AssistantMessage, ResultMessage, TextBlock
    except ImportError as exc:
        raise RuntimeError(f"claude-agent-sdk not installed: {exc}") from exc

    options = _build_options(job_config)
    result_text: Optional[str] = None
    last_assistant_text: list[str] = []

    async for message in _iter_sdk_messages(prompt, options):
        if isinstance(message, AssistantMessage):
            last_assistant_text = [block.text for block in message.content if isinstance(block, TextBlock)]
        elif isinstance(message, ResultMessage):
            # The CLI can emit subtype="success" with is_error=True (auth, 403, 429).
            if getattr(message, "is_error", False) or message.subtype != "success":
                status = getattr(message, "api_error_status", None)
                errors = getattr(message, "errors", None) or []
                detail = message.result or ("; ".join(str(e) for e in errors) if errors else message.subtype)
                raise RuntimeError(
                    f"Claude Code returned an error result: {detail}"
                    + (f" (HTTP {status})" if status else "")
                )
            result_text = message.result

    if result_text:
        return result_text
    if last_assistant_text:
        return "\n".join(last_assistant_text)
    raise RuntimeError("Agent session produced no output")


def make_sdk_caller(job_config: dict[str, Any]) -> SdkCaller:
    """Bind job config once so converter.py can call `caller(prompt)` per object."""

    async def _caller(prompt: str) -> str:
        return await call_model(prompt, job_config)

    return _caller
