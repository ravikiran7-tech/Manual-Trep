"""Prompt construction for per-object MSSQL -> PostgreSQL conversion calls."""

from __future__ import annotations

import json
from typing import Any

SYSTEM_RULES = """You are a senior database migration engineer converting a single Microsoft SQL \
Server object to PostgreSQL 15+ syntax.

Rules:
1. Convert ONLY the one object given to you. Do not invent related objects.
2. Preserve the original object's name and schema unless a rename is structurally required
   (e.g. SQL Server reserved identifier); if you rename, report it in "convertedName".
3. Apply every incompatibility finding's remediation guidance when present. Do NOT invent a
   remediation that is not in the provided knowledge-base entry. When no remediation is provided,
   convert with limited context, set requiresManualReview true, and explain the gap in "comments".
4. Map T-SQL constructs: ISNULL->COALESCE, GETDATE()/GETUTCDATE()->now()/timezone('utc', now()),
   TOP n->LIMIT n, IDENTITY->GENERATED ALWAYS AS IDENTITY, NVARCHAR/VARCHAR->varchar, SCOPE_IDENTITY()
   -> RETURNING clause or lastval(), TRY/CATCH->BEGIN/EXCEPTION, RAISERROR/THROW->RAISE EXCEPTION,
   sp_executesql/dynamic SQL->EXECUTE format(...), cursors->FOR loops over a query where possible.
   Rewrite bare EXEC calls to stored procedures as CALL.
5. If objectType is PROCEDURE, always emit `CREATE OR REPLACE PROCEDURE` (called with CALL), even
   when the body has no OUT parameters; never convert it to a FUNCTION, including when the body
   contains explicit transaction control (BEGIN TRAN/COMMIT/ROLLBACK) which PostgreSQL functions
   cannot perform but procedures can.
6. Never lower the provided confidenceFloor; you may only report the same tier or a stricter one
   (HIGH < MEDIUM < LOW < MANUAL in increasing risk). If you are not confident the conversion is
   correct, report a stricter tier and explain why in "comments".
7. If the object cannot be converted at all, set "conversionStatus" to "UNCONVERTIBLE" and leave
   "convertedCode" as an empty string; explain why in "comments".
8. Prefix convertedCode with SQL comments: conversion header (converted from MSSQL, source
   object name, source file + line numbers), one remediation comment per applied rule_id
   (≤50 words), a behaviour-change warning when semantics differ (≤50 words), and a manual
   review flag with a validation instruction ≤100 words when requiresManualReview is true.
9. If objectType is TRIGGER and is_instead_of is true on a table (not a view), convert to a
   BEFORE trigger that RETURNS NULL and add callerUpdatesNeeded reason INSTEAD_OF_CONVERSION
   only — do not rewrite other objects' SQL.
10. If objectType is MATERIALIZED_VIEW (or view_type INDEXED), emit CREATE MATERIALIZED VIEW.
11. If objectType is TABLE, emit CREATE TABLE with columns, defaults, and identity only.
    Do not include PRIMARY KEY, UNIQUE, FOREIGN KEY, or CHECK. Those are separate objects
    in later phases.
12. If objectType is PRIMARY_KEY, UNIQUE_CONSTRAINT, FOREIGN_KEY, or CHECK_CONSTRAINT, emit
    only one ALTER TABLE ... ADD CONSTRAINT statement. Never emit CREATE TABLE.
13. If objectType is INDEX and the source is a clustered PRIMARY KEY, do not emit PRIMARY KEY
    or CREATE TABLE. That key belongs to the primary-key object.
14. Respond with ONLY one JSON object matching the schema below. No markdown fences, no prose
    outside the JSON.
"""

RESPONSE_SCHEMA = {
    "conversionStatus": "SUCCESS | PARTIAL | UNCONVERTIBLE",
    "convertedCode": "string: complete PostgreSQL DDL statement(s) for this object only",
    "convertedName": "string or null: schema.name if renamed, else null",
    "newSignature": "string or null: PostgreSQL call signature for functions/procedures, else null",
    "confidenceScore": "HIGH | MEDIUM | LOW | MANUAL",
    "changesApplied": ["list of short strings describing each transformation rule applied"],
    "comments": ["list of short strings: rationale, caveats, anything a reviewer should know"],
    "requiresManualReview": "boolean",
    "reviewGuidance": [{"reason": "string", "priority": "CRITICAL | HIGH | MEDIUM | LOW"}],
    "callerUpdatesNeeded": [
        {"reason": "SIGNATURE_CHANGE | VIEW_STRUCTURE_CHANGE | TABLE_COLUMN_RENAME | INSTEAD_OF_CONVERSION", "detail": "string", "old_name": "string or null", "new_name": "string or null"}
    ],
}

_MAX_DDL_CHARS = 20000


def _trimmed(text: str, limit: int = _MAX_DDL_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n-- [truncated {len(text) - limit} characters]"


def build_context_package(obj: dict[str, Any]) -> dict[str, Any]:
    """The per-object payload handed to the model: everything it needs, nothing it doesn't."""
    source = obj.get("sourceCode") or {}
    findings = [
        {
            "rule_id": f.get("rule_id"),
            "compatibility": f.get("compatibility"),
            "description": f.get("description") or f.get("finding"),
            "remediation": f.get("remediation"),
        }
        for f in obj.get("incompatibilities") or []
    ]
    package: dict[str, Any] = {
        "objectType": obj["type"],
        "schema": obj["schema"],
        "name": obj["name"],
        "owningTable": obj.get("owningTable"),
        "sourceDdl": _trimmed(str(source.get("ddl") or "")),
        "structuralMetadata": obj.get("structuralMetadata") or {},
        "incompatibilityFindings": findings,
        "confidenceFloor": obj.get("confidenceFloor", "HIGH"),
    }
    ai = obj.get("aiAnalysis")
    if ai:
        package["aiAnalysis"] = ai
    if obj.get("dependsOnCode"):
        package["dependsOnCode"] = obj["dependsOnCode"]
    if (obj.get("structuralMetadata") or {}).get("features"):
        package["featureFlags"] = obj["structuralMetadata"]["features"]
    return package


def build_conversion_prompt(obj: dict[str, Any]) -> str:
    package = build_context_package(obj)
    return (
        f"{SYSTEM_RULES}\n"
        f"Response JSON schema (field: description):\n{json.dumps(RESPONSE_SCHEMA, indent=2)}\n\n"
        f"Object to convert:\n{json.dumps(package, indent=2, default=str)}\n"
    )


def build_repair_prompt(obj: dict[str, Any], *, previous_response: str, error: str) -> str:
    package = build_context_package(obj)
    return (
        f"{SYSTEM_RULES}\n"
        "Your previous response could not be used because of a validation error. Fix it and "
        "respond again with ONLY the corrected JSON object (no markdown fences, no prose).\n\n"
        f"Validation error: {error}\n\n"
        f"Your previous response was:\n{previous_response}\n\n"
        f"Response JSON schema (field: description):\n{json.dumps(RESPONSE_SCHEMA, indent=2)}\n\n"
        f"Object to convert:\n{json.dumps(package, indent=2, default=str)}\n"
    )
