"""SSE event/log persistence for MSSQL → PostgreSQL jobs.

Progress events and human-readable logs are appended as JSONL under
``stream/`` so a restarted process can replay history to a newly connected
SSE client, and in-process subscribers get pushed updates immediately.
"""

from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable

from app.services.oracle_pg.live_logs import ALLOWED_ICONS, DEFAULT_COLOR, icon_color
from app.services.oracle_pg.report_metrics import timing_fields_for_api
from app.services.mssql_pg.workspace import events_path, job_config_path, logs_meta_path, logs_path

_subscribers: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]] = defaultdict(list)
_log_subscribers: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]] = defaultdict(list)

UI_STREAM_EVENT_TYPES = frozenset({"progress_updated", "plan_updated"})


def is_ui_stream_event(event: dict[str, Any], *, verbose: bool = False) -> bool:
    if verbose:
        return True
    return event.get("type") in UI_STREAM_EVENT_TYPES


def subscribe(job_id: str, callback: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
    _subscribers[job_id].append(callback)


def unsubscribe_all(job_id: str) -> None:
    _subscribers.pop(job_id, None)


def subscribe_logs(job_id: str, callback: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
    _log_subscribers[job_id].append(callback)


def unsubscribe_logs(job_id: str) -> None:
    _log_subscribers.pop(job_id, None)


def _persist_line(path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload) + "\n")


def _next_log_seq(job_id: str) -> int:
    meta = logs_meta_path(job_id)
    seq = 0
    if meta.exists():
        try:
            seq = int(json.loads(meta.read_text(encoding="utf-8")).get("seq", 0))
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            seq = 0
    seq += 1
    meta.parent.mkdir(parents=True, exist_ok=True)
    meta.write_text(json.dumps({"seq": seq}), encoding="utf-8")
    return seq


def _api_job_id(folder_key: str) -> str:
    """Events must carry the API jobId; the workspace folder is keyed by dbName."""
    try:
        config = json.loads(job_config_path(folder_key).read_text(encoding="utf-8"))
        return str(config.get("jobId") or folder_key)
    except (OSError, json.JSONDecodeError, AttributeError):
        return folder_key


def _schedule_notify(subscribers: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]], key: str, payload: dict[str, Any]) -> None:
    """Push to live SSE subscribers from synchronous orchestrator code."""
    callbacks = list(subscribers.get(key, []))
    if not callbacks:
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return

    async def _run() -> None:
        for callback in callbacks:
            try:
                await callback(payload)
            except Exception:
                continue

    loop.create_task(_run())


def _icon_for_progress(progress: dict[str, Any]) -> str:
    status = str(progress.get("status") or "")
    phase = str(progress.get("phase") or "")
    message = str(progress.get("message") or "")
    if status in {"completed", "completed_with_warnings"}:
        return "check"
    if status == "failed":
        return "warning"
    if status == "queued":
        return "info"
    if phase in {"Validating Inputs", "Parsing DDL"} or message.startswith("Validating") or message.startswith("Parsing"):
        return "search"
    if phase == "AI-Guided Conversion" or message.startswith("AI-guided conversion"):
        return "lightning"
    if phase == "Generate PostgreSQL Scripts" or message.startswith("Generating PostgreSQL"):
        return "lightning"
    if phase == "Completed":
        return "check"
    return "settings"


def progress_updated_event(folder_key: str, progress: dict[str, Any]) -> dict[str, Any]:
    """Same completion envelope Oracle sends so the Java poller can treat both jobs alike."""
    job_id = str(progress.get("jobId") or _api_job_id(folder_key))
    event: dict[str, Any] = {
        "type": "progress_updated",
        "jobId": job_id,
        "status": progress.get("status"),
        "phase": progress.get("phase"),
        "progressPercent": progress.get("progressPercent", 0),
        "message": progress.get("message", ""),
        "sessionsCompleted": progress.get("sessionsCompleted", 0),
        "lastCompletedBatch": progress.get("lastCompletedBatch"),
        "objectsTotal": progress.get("objectsTotal", 0),
        "objectsConverted": progress.get("objectsConverted", 0),
        "updatedAt": progress.get("updatedAt"),
    }
    event.update(timing_fields_for_api(progress))
    event.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    if progress.get("errorDetail"):
        event["errorDetail"] = progress["errorDetail"]
    return event


def notify_progress_update(folder_key: str, progress: dict[str, Any]) -> None:
    job_id = str(progress.get("jobId") or _api_job_id(folder_key))
    event = progress_updated_event(folder_key, progress)
    _persist_line(events_path(folder_key), event)
    icon = _icon_for_progress(progress)
    log_entry = {
        "seq": _next_log_seq(folder_key),
        "timestamp": datetime.now(timezone.utc).strftime("%H:%M:%S"),
        "phase": progress.get("phase", ""),
        "icon": icon if icon in ALLOWED_ICONS else "info",
        "message": progress.get("message", ""),
        "color": icon_color(icon) if icon in ALLOWED_ICONS else DEFAULT_COLOR,
        "jobId": job_id,
    }
    _persist_line(logs_path(folder_key), log_entry)
    _schedule_notify(_subscribers, folder_key, event)
    _schedule_notify(_subscribers, job_id, event)
    _schedule_notify(_log_subscribers, folder_key, log_entry)
    _schedule_notify(_log_subscribers, job_id, log_entry)


def append_log(folder_key: str, phase: str, message: str, *, icon: str = "info", color: str = "blue") -> None:
    log_entry = {
        "seq": _next_log_seq(folder_key),
        "timestamp": datetime.now(timezone.utc).strftime("%H:%M:%S"),
        "phase": phase,
        "icon": icon,
        "message": message,
        "color": color,
        "jobId": _api_job_id(folder_key),
    }
    _persist_line(logs_path(folder_key), log_entry)
    _schedule_notify(_log_subscribers, folder_key, log_entry)
    _schedule_notify(_log_subscribers, log_entry["jobId"], log_entry)
