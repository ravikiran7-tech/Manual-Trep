"""Extract per-object T-SQL DDL blocks from a SQL Server script.

Splits on GO batch separators and finds the start of every ``CREATE`` (including
``CREATE OR ALTER``) and every ``ALTER TABLE ... ADD CONSTRAINT``. A block runs
from its start to the next recognized start or the next GO, whichever is first.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

KIND_TO_TYPE = {
    "SCHEMA": "SCHEMA",
    "TABLE": "TABLE",
    "VIEW": "VIEW",
    "SEQUENCE": "SEQUENCE",
    "SYNONYM": "SYNONYM",
    "TYPE": "USER_DEFINED_TYPE",
    "PROCEDURE": "PROCEDURE",
    "PROC": "PROCEDURE",
    "FUNCTION": "FUNCTION",
    "TRIGGER": "TRIGGER",
    "PARTITION FUNCTION": "PARTITION_FUNCTION",
    "PARTITION SCHEME": "PARTITION_SCHEME",
    "SECURITY POLICY": "RLS_POLICY",
}

_CREATE = re.compile(
    r"(?im)^[ \t]*CREATE\s+(?:OR\s+ALTER\s+)?"
    r"(?P<kind>(?:UNIQUE\s+)?(?:CLUSTERED\s+|NONCLUSTERED\s+)?INDEX|"
    r"PARTITION\s+FUNCTION|PARTITION\s+SCHEME|SECURITY\s+POLICY|"
    r"SCHEMA|PROCEDURE|PROC|FUNCTION|TRIGGER|VIEW|TABLE|SEQUENCE|SYNONYM|TYPE)\b"
)

_ALTER_CONSTRAINT = re.compile(
    r"(?im)^[ \t]*ALTER\s+TABLE\s+"
    r"(?P<table>(?:\[[^\]]+\]|\w+)(?:\s*\.\s*(?:\[[^\]]+\]|\w+))?)\s+"
    r"ADD\s+CONSTRAINT\s+"
)

_GO = re.compile(r"(?im)^[ \t]*GO[ \t]*(?:--.*)?$")

_IDENT = re.compile(r"\[[^\]]+\]|\"[^\"]+\"|\w+")


@dataclass
class DdlBlock:
    schema: str
    name: str
    object_type: str
    start_line: int
    end_line: int
    ddl: str
    file_name: str
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "name": self.name,
            "object_type": self.object_type,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "file_name": self.file_name,
            **self.extra,
        }


def _read_ident(text: str, pos: int) -> tuple[Optional[str], int]:
    """Read one identifier (bracketed, quoted, or bare) at ``pos``. Returns (name, end_pos)."""
    match = _IDENT.match(text, pos)
    if not match:
        return None, pos
    raw = match.group(0)
    if raw.startswith("[") and raw.endswith("]"):
        return raw[1:-1], match.end()
    if raw.startswith('"') and raw.endswith('"'):
        return raw[1:-1], match.end()
    return raw, match.end()


def _qualified_name(text: str, pos: int) -> tuple[str, str, int]:
    """Read ``schema.name`` or bare ``name`` (defaulting schema to dbo) starting at ``pos``."""
    while pos < len(text) and text[pos] in " \t\r\n":
        pos += 1
    first, pos = _read_ident(text, pos)
    if first is None:
        return "dbo", "", pos
    save = pos
    while pos < len(text) and text[pos] in " \t":
        pos += 1
    if pos < len(text) and text[pos] == ".":
        pos += 1
        while pos < len(text) and text[pos] in " \t":
            pos += 1
        second, pos = _read_ident(text, pos)
        if second is not None:
            return first, second, pos
    return "dbo", first, save


def _constraint_type(statement: str) -> str:
    upper = statement.upper()
    if re.search(r"\bFOREIGN\s+KEY\b", upper):
        return "FOREIGN_KEY"
    if re.search(r"\bPRIMARY\s+KEY\b", upper):
        return "PRIMARY_KEY"
    if re.search(r"\bUNIQUE\b", upper):
        return "UNIQUE_CONSTRAINT"
    if re.search(r"\bCHECK\b", upper):
        return "CHECK_CONSTRAINT"
    if re.search(r"\bDEFAULT\b", upper):
        return "DEFAULT_CONSTRAINT"
    return "CHECK_CONSTRAINT"


def _line_of(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def parse_ddl_script(text: str, file_name: str) -> list[DdlBlock]:
    """Split ``text`` into one DdlBlock per CREATE / ALTER-ADD-CONSTRAINT statement."""
    starts: list[tuple[int, str, str, str]] = []  # (offset, schema, name, object_type)

    for match in _CREATE.finditer(text):
        kind = re.sub(r"\s+", " ", match.group("kind").upper()).strip()
        if "INDEX" in kind:
            object_type = "INDEX"
            schema = "dbo"
            pos = match.end()
            while pos < len(text) and text[pos] in " \t\r\n":
                pos += 1
            name, _ = _read_ident(text, pos)
            name = name or ""
        else:
            object_type = KIND_TO_TYPE.get(kind, "TABLE")
            schema, name, _ = _qualified_name(text, match.end())
        if name:
            starts.append((match.start(), schema, name, object_type))

    for match in _ALTER_CONSTRAINT.finditer(text):
        name, _ = _read_ident(text, match.end())
        if name:
            starts.append((match.start(), "dbo", name, "__CONSTRAINT__"))

    starts.sort(key=lambda item: item[0])
    go_positions = sorted(m.start() for m in _GO.finditer(text))

    blocks: list[DdlBlock] = []
    for idx, (offset, schema, name, object_type) in enumerate(starts):
        next_start = starts[idx + 1][0] if idx + 1 < len(starts) else len(text)
        next_go = next((g for g in go_positions if offset < g < next_start), next_start)
        end = min(next_start, next_go)
        statement = text[offset:end]
        if object_type == "__CONSTRAINT__":
            object_type = _constraint_type(statement)
        blocks.append(
            DdlBlock(
                schema=schema,
                name=name,
                object_type=object_type,
                start_line=_line_of(text, offset),
                end_line=_line_of(text, offset + len(statement.rstrip())),
                ddl=statement.strip(),
                file_name=file_name,
            )
        )
    return blocks


def index_ddl_blocks(path: Path) -> dict[tuple[str, str], DdlBlock]:
    """Parse a DDL file and key blocks by (schema.lower(), name.lower())."""
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    index: dict[tuple[str, str], DdlBlock] = {}
    for block in parse_ddl_script(text, path.name):
        index[(block.schema.lower(), block.name.lower())] = block
    return index


def lookup_block(index: dict[tuple[str, str], DdlBlock], schema: str, name: str) -> Optional[DdlBlock]:
    key = (schema.lower(), name.lower())
    if key in index:
        return index[key]
    return index.get(("dbo", name.lower()))
