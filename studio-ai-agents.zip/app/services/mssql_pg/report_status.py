"""Map MSSQL conversion results onto Oracle UI statuses.

The converter still stores SUCCESS / PARTIAL / UNCONVERTIBLE. The report and
objects API expose auto_converted / require_review / manual_implementation so
the same Java cards work for both engines.

Finding-level Compass classes (DS / SC / NS) are rolled up the same way
Oracle rolls object-level class + complexity (ticket AC3 / Sub-PRD 2).
"""

from __future__ import annotations

from typing import Any

STATUS_AUTO = "auto_converted"
STATUS_REVIEW = "require_review"
STATUS_MANUAL = "manual_implementation"
STATUS_FAILED = "failed"

_HIGH_IMPACT = frozenset({"CRITICAL", "HIGH"})
_ELEVATED_COMPLEXITY = frozenset({"medium", "high"})


def resolve_ui_conversion_status(obj: dict[str, Any]) -> str:
    """Oracle-shaped outcome for one MSSQL plan object."""
    if obj.get("conversionStatus") == "UNCONVERTIBLE" or obj.get("status") == "failed":
        return STATUS_FAILED
    if obj.get("isClr") or obj.get("isEncrypted"):
        return STATUS_MANUAL
    if str(obj.get("confidenceScore") or "").upper() == "MANUAL":
        return STATUS_MANUAL

    classification, complexity = _rollup_findings(obj)
    if classification == "NS":
        return STATUS_MANUAL
    if str(obj.get("confidenceScore") or "").upper() == "LOW":
        return STATUS_REVIEW
    if classification == "DS":
        return STATUS_AUTO
    if classification == "SC" and complexity == "low":
        return STATUS_AUTO
    return STATUS_REVIEW


def _rollup_findings(obj: dict[str, Any]) -> tuple[str, str]:
    """Worst Compass class on the object. Missing class is treated as DS (convertible)."""
    worst_class = "DS"
    worst_complexity = "low"
    for finding in obj.get("incompatibilities") or []:
        compat = str(finding.get("compatibility") or "").upper()
        if compat == "NS":
            return "NS", "high"
        if compat != "SC":
            continue
        worst_class = "SC"
        severity = str(finding.get("severity") or finding.get("impact") or "").upper()
        complexity = str(finding.get("complexity") or "").lower()
        if severity in _HIGH_IMPACT or complexity in _ELEVATED_COMPLEXITY:
            worst_complexity = "high" if severity in _HIGH_IMPACT or complexity == "high" else "medium"
    return worst_class, worst_complexity


def count_ui_statuses(plan: list[dict[str, Any]]) -> dict[str, int]:
    counts = {STATUS_AUTO: 0, STATUS_REVIEW: 0, STATUS_MANUAL: 0, STATUS_FAILED: 0}
    for obj in plan:
        status = resolve_ui_conversion_status(obj)
        counts[status] = counts.get(status, 0) + 1
    return counts
