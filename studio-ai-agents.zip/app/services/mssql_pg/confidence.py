"""Deterministic confidence floors per object type (Sub-PRD 2).

The stored confidence for any object is ``lowest(model_score, structural_floor)``:
the model can be more cautious than the floor, never less.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Optional

from app.services.mssql_pg.tsql_features import merged_features

CONFIDENCE_RANK = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, "MANUAL": 3}
CONFIDENCE_VALUES = tuple(CONFIDENCE_RANK)
AI_ANALYZED_TYPES = frozenset(
    {
        "TABLE",
        "VIEW",
        "MATERIALIZED_VIEW",
        "FUNCTION",
        "PROCEDURE",
        "TRIGGER",
        "INDEX",
        "SYNONYM",
        "USER_DEFINED_TYPE",
        "SEQUENCE",
    }
)

_TSQL_IN_EXPRESSION = re.compile(r"(?i)\b(GETDATE|GETUTCDATE|SYSDATETIME|ISNULL|CONVERT|DATEADD|DATEDIFF|DATEPART|LEN|CHARINDEX|IIF)\b")
_UNSUPPORTED_INDEX = ("COLUMNSTORE", "FULLTEXT", "FULL_TEXT", "XML")


def lowest(*scores: Optional[str]) -> str:
    """Riskiest wins: HIGH < MEDIUM < LOW < MANUAL."""
    valid = [s.upper() for s in scores if s and s.upper() in CONFIDENCE_RANK]
    return max(valid, key=lambda s: CONFIDENCE_RANK[s]) if valid else "HIGH"


def _meta(obj: dict[str, Any]) -> dict[str, Any]:
    return obj.get("structuralMetadata") or {}


def _ddl(obj: dict[str, Any]) -> str:
    return str((obj.get("sourceCode") or {}).get("ddl") or "")


def _columns(obj: dict[str, Any]) -> list[dict[str, Any]]:
    cols = _meta(obj).get("columns")
    return [c for c in cols if isinstance(c, dict)] if isinstance(cols, list) else []


def _table_floor(obj: dict[str, Any]) -> str:
    meta = _meta(obj)
    flags = meta.get("features") if isinstance(meta.get("features"), dict) else {}
    table_type = str(meta.get("table_type") or "").upper()
    if flags.get("is_ledger") or table_type == "LEDGER":
        return "MANUAL"
    columns = _columns(obj)
    ddl = _ddl(obj)
    non_persisted = any(c.get("is_computed") and not c.get("is_persisted") for c in columns)
    if (
        non_persisted
        or flags.get("is_temporal")
        or flags.get("is_memory_optimized")
        or table_type in {"TEMPORAL", "MEMORY_OPTIMIZED"}
        or re.search(r"(?i)SYSTEM_VERSIONING|MEMORY_OPTIMIZED", ddl)
    ):
        return "LOW"
    has_identity = flags.get("has_identity_columns") or any(c.get("is_identity") for c in columns) or bool(
        re.search(r"(?i)\bIDENTITY\s*\(", ddl)
    )
    persisted = any(c.get("is_computed") and c.get("is_persisted") for c in columns) or "PERSISTED" in ddl.upper()
    if has_identity or persisted or flags.get("is_partitioned") or re.search(r"(?i)DATA_COMPRESSION", ddl):
        return "MEDIUM"
    return "HIGH"


def _index_floor(obj: dict[str, Any]) -> str:
    meta = _meta(obj)
    index_type = str(meta.get("index_type") or "").upper()
    ddl = _ddl(obj).upper()
    if any(token in index_type for token in _UNSUPPORTED_INDEX) or re.search(r"COLUMNSTORE|FULLTEXT\s+INDEX|XML\s+INDEX", ddl):
        return "MANUAL"
    filter_expr = str(meta.get("filter_expression") or "")
    if not filter_expr and " WHERE " in f" {ddl} ":
        filter_expr = ddl.split("WHERE", 1)[1]
    if "SPATIAL" in index_type or "SPATIAL" in ddl or meta.get("is_partitioned") or (filter_expr and _TSQL_IN_EXPRESSION.search(filter_expr)):
        return "MEDIUM"
    return "HIGH"


def _constraint_floor(obj: dict[str, Any]) -> str:
    meta = _meta(obj)
    expression = str(meta.get("expression") or _ddl(obj))
    if (
        meta.get("is_deferrable")
        or meta.get("is_self_referencing")
        or meta.get("is_cross_schema")
        or meta.get("is_disabled")
        or meta.get("is_not_trusted")
        or (obj.get("type") == "CHECK_CONSTRAINT" and _TSQL_IN_EXPRESSION.search(expression))
    ):
        return "MEDIUM"
    return "HIGH"


def _view_floor(obj: dict[str, Any], features: dict[str, bool]) -> str:
    meta = _meta(obj)
    if features.get("is_encrypted"):
        return "MANUAL"
    if features.get("uses_pivot") or features.get("uses_for_xml"):
        return "LOW"
    if (
        str(meta.get("view_type") or "").upper() == "INDEXED"
        or features.get("is_schema_bound")
        or features.get("uses_apply")
        or features.get("uses_top")
        or features.get("uses_tsql_specific")
    ):
        return "MEDIUM"
    return "HIGH"


def _function_floor(obj: dict[str, Any], features: dict[str, bool]) -> str:
    function_type = str(_meta(obj).get("function_type") or "").upper()
    if features.get("has_dynamic_sql") or features.get("has_cursor") or features.get("uses_table_valued_parameter"):
        return "LOW"
    if function_type in {"SCALAR", "MULTI_STATEMENT_TVF"} or features.get("has_transaction_control"):
        return "MEDIUM"
    return "MEDIUM" if features.get("uses_tsql_specific") else "HIGH"


def _procedure_floor(features: dict[str, bool]) -> str:
    if features.get("has_linked_server_calls"):
        return "MANUAL"
    if features.get("has_global_temp_tables") or features.get("uses_table_valued_parameter"):
        return "LOW"
    medium_flags = (
        "has_error_handling",
        "has_transaction_control",
        "has_dynamic_sql",
        "has_cursor",
        "has_temp_tables",
        "uses_scope_identity",
    )
    hits = sum(1 for flag in medium_flags if features.get(flag))
    if hits >= 4:
        return "LOW"
    return "MEDIUM" if hits else "HIGH"


def _trigger_floor(features: dict[str, bool], meta: dict[str, Any], owner_is_view: bool) -> str:
    if features.get("has_linked_server_calls"):
        return "MANUAL"
    scope = str(meta.get("trigger_scope") or "DML").upper()
    is_instead_of = bool(features.get("is_instead_of"))
    if is_instead_of and not owner_is_view:
        return "LOW" if features.get("is_multi_branch") and features.get("has_transaction_control") else "MEDIUM"
    if is_instead_of or scope == "DDL" or features.get("has_transaction_control") or features.get("has_error_handling"):
        return "MEDIUM"
    return "HIGH"


def structural_floor(obj: dict[str, Any], *, owner_is_view: bool = False) -> str:
    """Floor from object type and feature flags, before any model output is known."""
    features = merged_features(obj)
    obj_type = str(obj.get("type") or "").upper()
    if features.get("is_clr") or features.get("is_encrypted"):
        return "MANUAL"

    if obj_type == "TABLE":
        floor = _table_floor(obj)
    elif obj_type == "INDEX":
        floor = _index_floor(obj)
    elif obj_type in {"PRIMARY_KEY", "UNIQUE_CONSTRAINT", "FOREIGN_KEY", "CHECK_CONSTRAINT"}:
        floor = _constraint_floor(obj)
    elif obj_type in {"VIEW", "MATERIALIZED_VIEW"}:
        floor = _view_floor(obj, features)
    elif obj_type == "FUNCTION":
        floor = _function_floor(obj, features)
    elif obj_type == "PROCEDURE":
        floor = _procedure_floor(features)
    elif obj_type == "TRIGGER":
        floor = _trigger_floor(features, _meta(obj), owner_is_view)
    elif obj_type == "USER_DEFINED_TYPE":
        category = str(_meta(obj).get("udt_category") or "").upper()
        ddl = _ddl(obj).upper()
        if category == "CLR_TYPE" or "EXTERNAL NAME" in ddl:
            floor = "MANUAL"
        elif category == "TABLE_TYPE" or "AS TABLE" in ddl:
            floor = "MEDIUM"
        else:
            floor = "HIGH"
    elif obj_type == "SYNONYM":
        ref = str(_meta(obj).get("referenced_object") or "")
        parts = [p for p in ref.replace("[", "").replace("]", "").split(".") if p]
        floor = "MANUAL" if len(parts) >= 4 else ("LOW" if len(parts) == 3 else "HIGH")
    elif obj_type in {"RLS_POLICY", "DDM_DEFINITION", "PARTITION_FUNCTION", "PARTITION_SCHEME"}:
        floor = "MEDIUM"
    elif obj_type in {"AE_DEFINITION", "LINKED_SERVER"}:
        floor = "MANUAL"
    else:
        floor = "HIGH"

    if obj.get("aiAnalysis") is None and obj_type in AI_ANALYZED_TYPES:
        floor = lowest(floor, "LOW")
    for finding in obj.get("incompatibilities") or []:
        if finding.get("remediation_status") == "UNHANDLED":
            compat = str(finding.get("compatibility") or "").upper()
            if compat == "NS":
                floor = lowest(floor, "LOW")
            elif compat == "SC":
                floor = lowest(floor, "MEDIUM")
    return floor


def highest_priority(priorities: Iterable[str]) -> str:
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    values = [str(p).upper() for p in priorities if str(p).upper() in order]
    return min(values, key=lambda v: order[v]) if values else "MEDIUM"
