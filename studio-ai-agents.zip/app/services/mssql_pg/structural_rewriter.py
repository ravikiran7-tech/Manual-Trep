"""Deterministic T-SQL → PostgreSQL rewrite for structural objects (ticket AC3 HIGH).

Tables, keys, checks and indexes have known mappings. Converting them without a
model call keeps Pass 4 scripts populated when Bedrock is unavailable and avoids
invented remediations for DS-only syntax.
"""

from __future__ import annotations

import re
from typing import Any, Optional

from app.services.mssql_pg.stub_generator import map_type, pg_ident, pg_qualified

_BRACKET = re.compile(r"\[([^\]]+)\]")
_GO = re.compile(r"(?im)^\s*GO\s*;?\s*$")
_ON_FILEGROUP = re.compile(r"(?i)(?<=\))\s+ON\s+(\[?[A-Za-z_][\w]*\]?)")
_CLUSTERED = re.compile(r"(?i)\b(NON)?CLUSTERED\b")
_IDENTITY = re.compile(r"(?i)\bIDENTITY\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)")
_GETDATE = re.compile(r"(?i)\bGETDATE\s*\(\s*\)")
_GETUTCDATE = re.compile(r"(?i)\bGETUTCDATE\s*\(\s*\)")
_CAST_GETDATE_DATE = re.compile(r"(?i)CAST\s*\(\s*GETDATE\s*\(\s*\)\s+AS\s+DATE\s*\)")
_DATEDIFF_DAY = re.compile(r"(?i)DATEDIFF\s*\(\s*DAY\s*,\s*([^,]+?)\s*,\s*([^)]+?)\)")
_TYPE_TOKEN = re.compile(
    r"(?i)\b("
    r"NVARCHAR|VARCHAR|NCHAR|CHAR|NTEXT|TEXT|XML|SYSNAME|"
    r"TINYINT|SMALLINT|INT|BIGINT|BIT|MONEY|SMALLMONEY|FLOAT|REAL|"
    r"DECIMAL|NUMERIC|UNIQUEIDENTIFIER|DATETIME2|DATETIMEOFFSET|DATETIME|"
    r"SMALLDATETIME|DATE|TIME|VARBINARY|BINARY|IMAGE|HIERARCHYID|GEOGRAPHY|GEOMETRY"
    r")(\s*\(\s*(?:MAX|\d+(?:\s*,\s*\d+)?)\s*\))?"
)
_CREATE_INDEX = re.compile(r"(?i)CREATE\s+(UNIQUE\s+)?(?:NON)?CLUSTERED\s+INDEX")
_WITH_INDEX_OPTIONS = re.compile(r"(?is)\bWITH\s*\([^)]*PAD_INDEX[^)]*\)")
_COL_AS = re.compile(r"(?i)(\[[\w]+\]|[A-Za-z_]\w*)\s+AS\s+")
_STRUCTURAL_TYPES = frozenset(
    {
        "TABLE",
        "PRIMARY_KEY",
        "UNIQUE_CONSTRAINT",
        "FOREIGN_KEY",
        "CHECK_CONSTRAINT",
        "DEFAULT_CONSTRAINT",
        "INDEX",
    }
)
_CONSTRAINT_TYPES = frozenset({"PRIMARY_KEY", "UNIQUE_CONSTRAINT", "FOREIGN_KEY", "CHECK_CONSTRAINT"})


def _unbracket(sql: str) -> str:
    return _BRACKET.sub(lambda m: pg_ident(m.group(1)), sql)


def _rewrite_types(sql: str) -> str:
    return _TYPE_TOKEN.sub(lambda m: map_type(m.group(0)), sql)


def _rewrite_expr(expr: str) -> str:
    expr = _CAST_GETDATE_DATE.sub("CURRENT_DATE", expr)
    expr = _DATEDIFF_DAY.sub(r"(\2 - \1)", expr)
    expr = _GETUTCDATE.sub("timezone('utc', now())", expr)
    expr = _GETDATE.sub("now()", expr)
    return _unbracket(expr)


def _col_name(item: Any) -> str:
    if isinstance(item, dict):
        return pg_ident(item.get("column_name") or item.get("name") or "")
    return pg_ident(item)


def _col_list(items: list[Any]) -> str:
    return ", ".join(_col_name(c) for c in items if _col_name(c))


def _owning_table_sql(obj: dict[str, Any]) -> str:
    meta = obj.get("structuralMetadata") or {}
    owning = str(meta.get("owning_table") or obj.get("owningTable") or "")
    if "." in owning:
        schema, name = owning.split(".", 1)
        return pg_qualified(schema, name)
    return pg_qualified(obj.get("schema") or "dbo", owning or obj["name"])


def _constraint_from_metadata(obj: dict[str, Any]) -> Optional[tuple[str, list[str]]]:
    """Build ALTER TABLE from Compass constraint metadata (source is often the owning table)."""
    typ = obj["type"]
    if typ not in _CONSTRAINT_TYPES:
        return None
    meta = obj.get("structuralMetadata") or {}
    table = _owning_table_sql(obj)
    cname = pg_ident(meta.get("constraint_name") or obj["name"])
    notes = ["Emitted ALTER TABLE from AS-IS constraint metadata (no model call)"]

    if typ == "PRIMARY_KEY":
        cols = _col_list(meta.get("columns") or [])
        if not cols:
            return None
        sql = f"ALTER TABLE {table} ADD CONSTRAINT {cname} PRIMARY KEY ({cols});"
        if meta.get("is_clustered"):
            notes.append("Clustered PK mapped to PRIMARY KEY; CLUSTER intent is review-only")
        return sql, notes

    if typ == "UNIQUE_CONSTRAINT":
        cols = _col_list(meta.get("columns") or [])
        if not cols:
            return None
        return f"ALTER TABLE {table} ADD CONSTRAINT {cname} UNIQUE ({cols});", notes

    if typ == "FOREIGN_KEY":
        src = _col_list(meta.get("referencing_columns") or [])
        dst = _col_list(meta.get("referenced_columns") or [])
        ref = meta.get("referenced_table") or ""
        if not (src and dst and ref):
            return None
        if "." in str(ref):
            rschema, rname = str(ref).split(".", 1)
            ref_sql = pg_qualified(rschema, rname)
        else:
            ref_sql = pg_qualified(obj.get("schema") or "dbo", str(ref))
        return f"ALTER TABLE {table} ADD CONSTRAINT {cname} FOREIGN KEY ({src}) REFERENCES {ref_sql} ({dst});", notes

    if typ == "CHECK_CONSTRAINT":
        expr = str(meta.get("expression") or "").strip()
        if not expr:
            return None
        return f"ALTER TABLE {table} ADD CONSTRAINT {cname} CHECK ({_rewrite_expr(expr)});", notes

    return None


def _split_at_depth(sql: str, start: int) -> tuple[str, int]:
    """Read from ``start`` until a comma/close-paren at parenthesis depth 0."""
    depth = 0
    i = start
    while i < len(sql):
        ch = sql[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            if depth == 0:
                break
            depth -= 1
        elif ch == "," and depth == 0:
            break
        i += 1
    return sql[start:i].strip(), i


def _rewrite_computed(sql: str) -> tuple[str, list[str]]:
    notes: list[str] = []
    out: list[str] = []
    last = 0
    for match in _COL_AS.finditer(sql):
        before = sql[last:match.start()]
        if not re.search(r"(?i)CREATE\s+TABLE", sql[: match.start()]):
            continue
        if re.search(r"(?i)\b(GENERATED|DEFAULT|CONSTRAINT)\s*$", before):
            continue
        expr, end = _split_at_depth(sql, match.end())
        persisted = bool(re.search(r"(?i)\bPERSISTED\b", expr))
        expr = re.sub(r"(?i)\s+PERSISTED\s*$", "", expr).strip()
        name = pg_ident(match.group(1))
        expr = _rewrite_expr(expr)
        if not expr.startswith("("):
            expr = f"({expr})"
        notes.append(
            f"{'Persisted' if persisted else 'Non-persisted'} computed column {name} "
            "mapped to GENERATED ALWAYS AS ... STORED"
        )
        col_type = "integer" if persisted else "numeric"
        out.append(sql[last:match.start()])
        out.append(f"{name} {col_type} GENERATED ALWAYS AS {expr} STORED")
        last = end
    out.append(sql[last:])
    return "".join(out) if notes else sql, notes


_COL_PRIMARY_KEY = re.compile(r"(?i)\s+PRIMARY\s+KEY\b")
_COL_UNIQUE = re.compile(r"(?i)\s+UNIQUE\b(?!\s*\()")


def _strip_named_table_constraints(sql: str) -> str:
    """Drop ``, CONSTRAINT name ...`` clauses, respecting parentheses in UNIQUE/CHECK."""
    pattern = re.compile(r"(?i),\s*CONSTRAINT\s+")
    while True:
        match = pattern.search(sql)
        if not match:
            return sql
        _body, end = _split_at_depth(sql, match.end())
        sql = sql[: match.start()] + sql[end:]


def _strip_inline_table_constraints(sql: str, notes: list[str]) -> str:
    """Move PK / UNIQUE / CHECK out of CREATE TABLE so they land in later phases."""
    if "CREATE TABLE" not in sql.upper():
        return sql
    stripped = _strip_named_table_constraints(sql)
    stripped = _COL_PRIMARY_KEY.sub("", stripped)
    stripped = _COL_UNIQUE.sub("", stripped)
    if stripped != sql:
        notes.append("Inline table constraints removed; they are emitted in later phases")
    return stripped


def rewrite_structural_sql(ddl: str, obj: dict[str, Any]) -> tuple[str, list[str]]:
    """Return (postgresql_ddl, change_notes)."""
    notes: list[str] = ["Deterministic T-SQL structural rewrite (no model call)"]
    sql = ddl or ""
    sql = _GO.sub("", sql)
    sql = _WITH_INDEX_OPTIONS.sub("", sql)
    sql = _ON_FILEGROUP.sub(" ", sql)
    sql = _CLUSTERED.sub("", sql)
    if obj.get("type") == "TABLE":
        sql = _strip_inline_table_constraints(sql, notes)
    sql = _CREATE_INDEX.sub(lambda m: "CREATE UNIQUE INDEX" if m.group(1) else "CREATE INDEX", sql)
    sql = re.sub(r"(?i)CREATE\s+INDEX", "CREATE INDEX", sql)
    sql = _rewrite_types(sql)
    sql, computed_notes = _rewrite_computed(sql)
    notes.extend(computed_notes)
    if _IDENTITY.search(sql):
        notes.append("IDENTITY mapped to GENERATED BY DEFAULT AS IDENTITY")
    sql = _IDENTITY.sub(
        lambda m: f"GENERATED BY DEFAULT AS IDENTITY (START WITH {m.group(1)} INCREMENT BY {m.group(2)})",
        sql,
    )
    if _CAST_GETDATE_DATE.search(sql):
        notes.append("CAST(GETDATE() AS DATE) mapped to CURRENT_DATE")
    sql = _CAST_GETDATE_DATE.sub("CURRENT_DATE", sql)
    sql = _DATEDIFF_DAY.sub(r"(\2 - \1)", sql)
    if _GETUTCDATE.search(sql):
        notes.append("GETUTCDATE() mapped to timezone('utc', now())")
    if _GETDATE.search(sql):
        notes.append("GETDATE() mapped to now()")
    sql = _GETUTCDATE.sub("timezone('utc', now())", sql)
    sql = _GETDATE.sub("now()", sql)
    sql = _unbracket(sql)
    sql = re.sub(r"(?i)(boolean\s+DEFAULT)\s+1\b", r"\1 true", sql)
    sql = re.sub(r"(?i)(boolean\s+DEFAULT)\s+0\b", r"\1 false", sql)
    if obj.get("type") == "INDEX":
        sql = re.sub(r"(?i)(WHERE\b[\s\S]*?)=\s*1\b", r"\1= true", sql)
        sql = re.sub(r"(?i)(WHERE\b[\s\S]*?)=\s*0\b", r"\1= false", sql)
    sql = re.sub(r"[ \t]+\n", "\n", sql)
    sql = re.sub(r"\n{3,}", "\n\n", sql).strip()
    if sql and not sql.endswith(";"):
        sql += ";"
    header = [
        f"-- Converted from MSSQL {obj['type']} {obj['schema']}.{obj['name']}",
        "-- Deterministic structural mapping (ticket AC3 HIGH / DS syntax)",
    ]
    return "\n".join(header + [sql]), notes


def _source_is_owning_table(obj: dict[str, Any]) -> bool:
    origin = str((obj.get("sourceCode") or {}).get("origin") or "")
    ddl = (obj.get("sourceCode") or {}).get("ddl") or ""
    return origin == "OWNING_TABLE_DDL" or (
        obj["type"] in _CONSTRAINT_TYPES and "CREATE TABLE" in ddl.upper()
    )


def _constraint_from_emitted_table(obj: dict[str, Any], sql: str) -> Optional[tuple[str, list[str]]]:
    """Build ALTER TABLE when the model repeated the owning CREATE TABLE."""
    typ = obj["type"]
    table = _owning_table_sql(obj)
    cname = pg_ident(obj["name"])
    if typ == "PRIMARY_KEY":
        named = re.search(r"(?i)PRIMARY\s+KEY\s*\(([^)]+)\)", sql)
        inline = re.search(
            r'(?i)(?:"([^"]+)"|\[([^\]]+)\]|([A-Za-z_]\w*))[^,\n]*\bPRIMARY\s+KEY\b',
            sql,
        )
        cols = ""
        if named:
            cols = named.group(1).strip()
        elif inline:
            cols = next(part for part in inline.groups() if part)
        if not cols:
            return None
        return f"ALTER TABLE {table} ADD CONSTRAINT {cname} PRIMARY KEY ({cols});", [
            "Model repeated CREATE TABLE; replaced with ALTER TABLE for the primary-key phase"
        ]
    if typ == "UNIQUE_CONSTRAINT":
        named = re.search(r"(?i)UNIQUE\s*\(([^)]+)\)", sql)
        inline = re.search(
            r'(?i)(?:"([^"]+)"|\[([^\]]+)\]|([A-Za-z_]\w*))[^,\n]*\bUNIQUE\b',
            sql,
        )
        cols = ""
        if named:
            cols = named.group(1).strip()
        elif inline:
            cols = next(part for part in inline.groups() if part)
        if not cols:
            return None
        return f"ALTER TABLE {table} ADD CONSTRAINT {cname} UNIQUE ({cols});", [
            "Model repeated CREATE TABLE; replaced with ALTER TABLE for the unique-constraint phase"
        ]
    return None


def _index_is_primary_key(obj: dict[str, Any], sql: str) -> bool:
    """A clustered primary-key index is already emitted in the primary-key phase."""
    if re.search(r"(?i)\bCREATE\s+(UNIQUE\s+)?INDEX\b", sql):
        return False
    meta = obj.get("structuralMetadata") or {}
    if meta.get("is_primary_key") or meta.get("is_primary"):
        return True
    name = str(obj.get("name") or "")
    if name.upper().startswith("PK_") and "PRIMARY KEY" in sql.upper():
        return True
    origin = str((obj.get("sourceCode") or {}).get("origin") or "")
    return origin == "OWNING_TABLE_DDL" and "PRIMARY KEY" in sql.upper() and "CREATE INDEX" not in sql.upper()


def _table_ref(obj: dict[str, Any]) -> str:
    """schema.table this object belongs to, from metadata or a CREATE TABLE in its DDL."""
    owning = str(obj.get("owningTable") or "").strip()
    if owning:
        if "." not in owning:
            owning = f"{obj.get('schema') or 'dbo'}.{owning}"
        return owning.lower()
    if str(obj.get("type") or "") == "TABLE":
        return f"{obj.get('schema') or 'dbo'}.{obj.get('name')}".lower()
    blob = f"{(obj.get('sourceCode') or {}).get('ddl') or ''}\n{obj.get('convertedCode') or ''}"
    match = re.search(r"(?i)CREATE\s+TABLE\s+(?:(?:\[?(\w+)\]?|\"([^\"]+)\")\s*\.\s*)?(?:\[?(\w+)\]?|\"([^\"]+)\")", blob)
    if not match:
        return ""
    schema = match.group(1) or match.group(2) or obj.get("schema") or "dbo"
    name = match.group(3) or match.group(4) or ""
    return f"{schema}.{name}".lower() if name else ""


def normalize_plan_ddl(plan: list[dict[str, Any]]) -> None:
    """Keep each object in its ticket phase so complete_schema.sql can run.

    Inline keys stay on a table only when no later-phase object owns them.
    A key object that repeated CREATE TABLE becomes ALTER TABLE. A clustered
    primary-key index does not add that key a second time.
    """
    pk_owners = {_table_ref(obj) for obj in plan if obj.get("type") == "PRIMARY_KEY"}
    unique_owners = {_table_ref(obj) for obj in plan if obj.get("type") == "UNIQUE_CONSTRAINT"}
    pk_names = {str(obj.get("name") or "").lower() for obj in plan if obj.get("type") == "PRIMARY_KEY"}
    pk_owners.discard("")
    unique_owners.discard("")

    for obj in plan:
        code = str(obj.get("convertedCode") or "")
        if not code.strip() or obj.get("conversionStatus") == "UNCONVERTIBLE":
            continue
        typ = str(obj.get("type") or "")
        notes: list[str] = []
        if typ == "TABLE" and "CREATE TABLE" in code.upper():
            key = _table_ref(obj)
            if key in pk_owners or key in unique_owners:
                stripped = _rewrite_create_table_body(
                    code,
                    lambda body: _strip_table_keys(
                        body,
                        primary=key in pk_owners,
                        unique=key in unique_owners,
                    ),
                )
                if stripped != code:
                    obj["convertedCode"] = stripped
                    notes.append("Inline keys removed from the table; they are emitted in later phases")
        elif typ in _CONSTRAINT_TYPES and "CREATE TABLE" in code.upper():
            built = _constraint_from_metadata(obj) or _constraint_from_emitted_table(obj, code)
            if built is not None:
                sql, built_notes = built
                obj["convertedCode"] = sql
                notes.extend(built_notes)
        elif typ == "INDEX" and (
            str(obj.get("name") or "").lower() in pk_names or _index_is_primary_key(obj, code)
        ):
            obj["convertedCode"] = (
                f"-- Clustered primary key {obj.get('schema', 'dbo')}.{obj.get('name')} "
                "is created in the primary-key phase.\n"
                "-- PostgreSQL does not keep a separate clustered index for a PRIMARY KEY."
            )
            notes.append("Primary-key index omitted from the index phase to avoid a duplicate PRIMARY KEY")
        if notes:
            obj["comments"] = list(obj.get("comments") or []) + notes


def _rewrite_create_table_body(sql: str, transform) -> str:
    match = re.search(r"(?is)(CREATE\s+TABLE\b[^(]*\()(.*)(\)\s*;?\s*)$", sql)
    if not match:
        return sql
    return sql[: match.start()] + match.group(1) + transform(match.group(2)) + match.group(3)


def _strip_table_keys(body: str, *, primary: bool, unique: bool) -> str:
    stripped = body
    if primary and unique:
        stripped = _strip_named_table_constraints(stripped)
    elif primary:
        stripped = _strip_named_constraint(stripped, "PRIMARY KEY")
    elif unique:
        stripped = _strip_named_constraint(stripped, "UNIQUE")
    if primary:
        stripped = _COL_PRIMARY_KEY.sub("", stripped)
    if unique:
        stripped = _COL_UNIQUE.sub("", stripped)
    return stripped


def _strip_named_constraint(sql: str, kind: str) -> str:
    """Drop ``, CONSTRAINT name <kind> ...`` clauses of one kind."""
    pattern = re.compile(rf"(?i),\s*CONSTRAINT\s+(?:\"[^\"]+\"|\[[^\]]+\]|\w+)\s+{kind}\b")
    while True:
        match = pattern.search(sql)
        if not match:
            return sql
        _body, end = _split_at_depth(sql, match.end())
        sql = sql[: match.start()] + sql[end:]


def structural_result(obj: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Convert a structural object from metadata and/or source DDL."""
    if obj["type"] not in _STRUCTURAL_TYPES:
        return None

    notes: list[str] = []
    code = ""
    if obj["type"] in _CONSTRAINT_TYPES and (_source_is_owning_table(obj) or obj.get("structuralMetadata")):
        built = _constraint_from_metadata(obj)
        if built is not None:
            code, notes = built
            header = [
                f"-- Converted from MSSQL {obj['type']} {obj['schema']}.{obj['name']}",
                "-- Deterministic structural mapping (ticket AC3 HIGH / DS syntax)",
            ]
            code = "\n".join(header + [code])

    if not code.strip():
        source = (obj.get("sourceCode") or {}).get("ddl") or ""
        if not source.strip():
            return None
        if obj["type"] in _CONSTRAINT_TYPES and "CREATE TABLE" in source.upper():
            return None
        code, notes = rewrite_structural_sql(source, obj)

    needs_review = obj["type"] == "CHECK_CONSTRAINT" and ("now()" in code or "CURRENT_DATE" in code)
    computed = any("Non-persisted" in n for n in notes)
    clustered = any("CLUSTER" in n.upper() for n in notes)
    confidence = "MEDIUM" if needs_review or computed else "HIGH"
    guidance = []
    if needs_review:
        guidance.append(
            {
                "reason": "CHECK constraint uses now()/CURRENT_DATE; PostgreSQL requires an immutable expression",
                "priority": "HIGH",
            }
        )
    if computed:
        guidance.append(
            {
                "reason": "Non-persisted computed column stored as GENERATED ALWAYS AS STORED; verify immutability",
                "priority": "MEDIUM",
            }
        )
    if clustered and obj["type"] == "PRIMARY_KEY":
        guidance.append(
            {
                "reason": "SQL Server clustered PK has no PostgreSQL equivalent; review CLUSTER after load",
                "priority": "LOW",
            }
        )
    return {
        "conversionStatus": "SUCCESS",
        "convertedCode": code,
        "confidenceScore": confidence,
        "requiresManualReview": bool(guidance),
        "reviewGuidance": guidance,
        "changesApplied": notes,
        "comments": notes,
        "convertedName": None,
        "newSignature": None,
        "callerUpdatesNeeded": [],
    }
