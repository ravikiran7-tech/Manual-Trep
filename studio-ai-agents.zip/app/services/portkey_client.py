"""
Portkey client for AI provider proxy integration.

Portkey acts as a unified gateway to multiple AI providers (Bedrock, Anthropic, etc.)
with observability, caching, and fallback capabilities.
"""
import json
import time
import logging
from typing import Dict, List, Optional, Any, Callable

import httpx

from app.core.config import get_settings
from app.core.exceptions import ProviderError, AuthenticationError, RateLimitError
from app.core.resilience import with_resilience, portkey_circuit_breaker
from app.core.llm_rate_limiter import portkey_llm_rate_limiter


logger = logging.getLogger(__name__)
settings = get_settings()


class PortkeyClient:
    """
    Portkey proxy client for AI model invocation.

    Provides unified interface to multiple AI providers through Portkey's
    gateway, with support for virtual keys, observability, and streaming.

    Equivalent to Java's Portkey integration with custom headers.
    """

    # Tool definitions matching Bedrock client
    CODE_EDITOR_TOOL = {
        "name": "code_editor",
        "description": "Edit, create, or delete files in the codebase. Use patch operation for efficient small changes, write for complete file replacement. IMPORTANT: For 'write' operation, 'content' is required. For 'patch' operation, 'patch_format' and 'patch_data' are required.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file relative to project directory"
                },
                "operation": {
                    "type": "string",
                    "enum": ["read", "write", "delete", "patch"],
                    "description": "Operation to perform: read (read file), write (replace entire file), delete (delete file), patch (apply diff-based changes)"
                },
                "content": {
                    "type": "string",
                    "description": "Complete file content for write operations (REQUIRED when operation is 'write', omit for other operations)"
                },
                "patch_format": {
                    "type": "string",
                    "enum": ["unified_diff", "line_edits", "structured"],
                    "description": "Patch format for patch operation (REQUIRED when operation is 'patch'): unified_diff (standard diff format), line_edits (line-based edits), structured (JSON range-based edits)"
                },
                "patch_data": {
                    "type": ["string", "object", "array"],
                    "description": "Patch data (REQUIRED when operation is 'patch', format depends on patch_format). For unified_diff: string with diff text. For line_edits: array of edit objects. For structured: object with edits array."
                }
            },
            "required": ["path", "operation"]
        }
    }

    BASH_TOOL = {
        "name": "bash",
        "description": "Execute bash commands in the project context. Use this for running builds, tests, and other command-line operations.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Bash command to execute"
                },
                "working_directory": {
                    "type": "string",
                    "description": "Working directory for command execution (optional)"
                }
            },
            "required": ["command"]
        }
    }

    def __init__(
        self,
        api_key: str,
        virtual_key: str,
        model_id: str,
        base_url: Optional[str] = None,
        debug: bool = False,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None
    ):
        """
        Initialize Portkey client.

        Args:
            api_key: Portkey API key (decrypted from Compass)
            virtual_key: Portkey virtual key for provider routing
            model_id: Model ID to use (e.g., "claude-3-sonnet-20240229")
            base_url: Portkey API base URL (default from config)
            debug: Enable debug mode for detailed logs
            max_tokens: Maximum tokens (default from config: 64000)
            temperature: Model temperature (default from config: 0.7)

        Raises:
            ValueError: If required parameters are missing
        """
        if not api_key:
            raise ValueError("Portkey API key is required")
        if not virtual_key:
            raise ValueError("Portkey virtual key is required")
        if not model_id:
            raise ValueError("Model ID is required")

        self.api_key = api_key
        self.virtual_key = virtual_key
        self.model_id = model_id
        self.base_url = base_url or settings.portkey.base_url
        self.debug = debug
        self.max_tokens = max_tokens or settings.bedrock.max_tokens
        self.temperature = temperature or settings.bedrock.temperature

        logger.info(
            f"Portkey client initialized: model={self.model_id}, "
            f"virtual_key={self.virtual_key[:8]}..., debug={self.debug}"
        )

        # Build headers
        self.headers = {
            "Content-Type": "application/json",
            "x-portkey-api-key": self.api_key,
            "x-portkey-virtual-key": self.virtual_key,
        }

        if self.debug:
            self.headers["x-portkey-debug"] = "true"

    # Note: Resilience decorators don't work with async generators
    # Resilience is applied at the handler level instead
    async def invoke_with_tools(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        process_response: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Invoke Portkey with tool use capability.

        Uses Anthropic Messages API format via Portkey proxy.

        Args:
            prompt: User prompt content
            project_path: Project directory path (for context)
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens (default from config)
            temperature: Model temperature (default from config)
            enable_tools: Whether to enable tool use (default: True)

        Returns:
            List of events in normalized format compatible with Claude CLI stream-json

        Raises:
            ProviderError: If Portkey API call fails
            AuthenticationError: If authentication fails
        """
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature

        logger.info(
            f"Invoking Portkey with tools: project={project_path}, "
            f"max_tokens={effective_max_tokens}, enable_tools={enable_tools}"
        )

        # Build messages (Anthropic format)
        messages = [
            {
                "role": "user",
                "content": f"Project directory: {project_path}\n\n{prompt}"
            }
        ]

        # Build request body (Anthropic Messages API format)
        request_body = {
            "model": self.model_id,
            "messages": messages,
            "max_tokens": effective_max_tokens,
            "temperature": effective_temperature,
            "stream": False  # Non-streaming mode
        }

        # Add system prompt if provided
        if system_prompt:
            request_body["system"] = system_prompt

        # Add tools if enabled
        if enable_tools:
            request_body["tools"] = [
                self.CODE_EDITOR_TOOL,
                self.BASH_TOOL
            ]

        # Portkey endpoint - Anthropic Messages API format
        url = f"{self.base_url}/messages"

        try:
            logger.debug(f"Portkey request: model={self.model_id}, url={url}")

            # Non-streaming request — gated by LLM rate limiter
            async with portkey_llm_rate_limiter.acquire(
                estimated_tokens=effective_max_tokens
            ):
                async with httpx.AsyncClient(timeout=3600) as client:
                    response = await client.post(
                        url,
                        headers=self.headers,
                        json=request_body
                    )
                    if response.status_code == 429:
                        retry_after = int(response.headers.get('Retry-After', 60))
                        raise RateLimitError(
                            message="Portkey rate limit exceeded",
                            retry_after=retry_after,
                            details=f"Status: {response.status_code}"
                        )
                    response.raise_for_status()
                    response_data = response.json()

            # Process response — skip normalization when caller opts out
            if process_response:
                events = await self._process_response(response_data, project_path)
            else:
                events = [response_data]

            # Check if tools were requested and execute them
            # Handle multiple turns: execute tools, send results back, execute follow-up tools if needed
            stop_reason = response_data.get('stop_reason', 'end_turn')
            max_follow_up_turns = 5  # Allow more complex transformations (Fix #2)
            follow_up_count = 0
            consecutive_no_tool_turns = 0  # Track consecutive turns without tool requests (Fix #2)
            
            while enable_tools and follow_up_count < max_follow_up_turns:
                # Smart termination: break if stop_reason is end_turn (model finished)
                if stop_reason == "end_turn":
                    logger.info(f"Model completed (stop_reason=end_turn) after {follow_up_count} follow-up turns")
                    break
                
                # Only process if tools were requested
                if stop_reason != "tool_use":
                    consecutive_no_tool_turns += 1
                    # Smart termination: break if no tools requested for 2 consecutive turns
                    if consecutive_no_tool_turns >= 2:
                        logger.info(f"Smart termination: No tools requested for {consecutive_no_tool_turns} consecutive turns")
                        break
                    # If first turn without tools, break immediately (no need to continue)
                    break
                else:
                    consecutive_no_tool_turns = 0  # Reset counter when tools are requested
                if follow_up_count == 0:
                    logger.info("Tool use requested in single-turn mode, executing tools")
                else:
                    logger.info(f"Follow-up turn {follow_up_count}: executing tools")
                
                # Extract tool uses from current response_data (not from events, as events may contain old tool_use events)
                # Get tool_use events from the most recent response
                current_tool_use_events = []
                timestamp = int(time.time() * 1000)
                for content_block in response_data.get('content', []):
                    if content_block.get('type') == 'tool_use':
                        # Convert to event format
                        tool_use_id = content_block.get('id', '')
                        tool_name = content_block.get('name', '')
                        tool_input = content_block.get('input', {})
                        tool_use_event = {
                            "type": "tool_use",
                            "tool": {
                                "toolUseId": tool_use_id,
                                "name": tool_name,
                                "input": tool_input
                            },
                            "timestamp": timestamp
                        }
                        current_tool_use_events.append(tool_use_event)
                        # CRITICAL FIX #1: Preserve tool_use events immediately
                        # Add to events list BEFORE execution so orchestrator can track them
                        events.append(tool_use_event)
                        logger.debug(f"Preserved tool_use event: {tool_name} (ID: {tool_use_id})")
                
                if not current_tool_use_events:
                    break
                
                from app.services.tool_executor import ToolExecutor, format_tool_result_for_model
                from app.core.config import get_settings
                
                settings = get_settings()
                
                # Initialize tool executor
                tool_executor = ToolExecutor(
                    project_path=project_path,
                    working_directory=project_path,
                    timeout=settings.agentic.tool_execution_timeout
                )
                
                # Execute each tool and collect results
                tool_results_content = []
                consecutive_failures = 0  # Fix #7: Track consecutive failures
                max_consecutive_failures = 3  # Stop after 3 consecutive failures
                
                for tool_event in current_tool_use_events:
                    tool = tool_event.get("tool", {})
                    tool_use_id = tool.get("toolUseId", "")
                    tool_name = tool.get("name", "")
                    tool_input = tool.get("input", {})
                    
                    logger.info(f"Executing tool: {tool_name} (ID: {tool_use_id})")
                    
                    # Fix #7: Retry logic with exponential backoff for file writes
                    result = None
                    max_retries = 3
                    retry_delay = 0.5  # Start with 0.5 seconds
                    
                    if tool_name == "code_editor" and tool_input.get("operation") == "write":
                        # Retry file writes with exponential backoff
                        for attempt in range(max_retries):
                            result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                            
                            if result.success:
                                # Fix #3: Verify file writes actually happened
                                file_path = tool_input.get("path", "")
                                if file_path:
                                    import os
                                    from pathlib import Path
                                    
                                    # Convert relative paths to absolute
                                    if not os.path.isabs(file_path):
                                        file_path = os.path.join(project_path, file_path)
                                    file_path = str(Path(file_path).resolve())
                                    
                                    # Verify file exists
                                    if os.path.exists(file_path):
                                        file_stat = os.stat(file_path)
                                        file_size = file_stat.st_size
                                        file_mtime = file_stat.st_mtime
                                        
                                        logger.info(
                                            f"File write verified: {file_path} exists, "
                                            f"size={file_size} bytes, modified={file_mtime}"
                                        )
                                        
                                        # Additional verification: check if file is readable
                                        try:
                                            with open(file_path, 'r', encoding='utf-8') as f:
                                                content_preview = f.read(100)  # Read first 100 chars
                                            logger.debug(f"File content preview (first 100 chars): {content_preview[:100]}")
                                        except Exception as e:
                                            logger.warning(f"Could not read file for verification: {file_path}, error: {e}")
                                        
                                        # Success - break retry loop
                                        break
                                    else:
                                        # File doesn't exist - retry
                                        result.success = False
                                        result.error = f"File write verification failed: file {file_path} does not exist"
                                        logger.warning(
                                            f"File write verification failed (attempt {attempt + 1}/{max_retries}): "
                                            f"{file_path} does not exist"
                                        )
                            
                            # If failed and not last attempt, retry with exponential backoff
                            if not result.success and attempt < max_retries - 1:
                                logger.info(
                                    f"File write failed (attempt {attempt + 1}/{max_retries}), "
                                    f"retrying in {retry_delay}s: {result.error}"
                                )
                                time.sleep(retry_delay)
                                retry_delay *= 2  # Exponential backoff: 0.5s, 1s, 2s
                            else:
                                break
                    else:
                        # Non-file-write operations: execute once without retry
                        result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                    
                    # Fix #7: Track consecutive failures
                    if not result.success:
                        consecutive_failures += 1
                        logger.warning(
                            f"Tool execution failed (consecutive failures: {consecutive_failures}/{max_consecutive_failures}): "
                            f"{tool_name}, error: {result.error}"
                        )
                        
                        if consecutive_failures >= max_consecutive_failures:
                            logger.error(
                                f"Max consecutive failures reached ({consecutive_failures}), "
                                f"stopping tool execution to prevent infinite loops"
                            )
                            # Add error event
                            events.append({
                                "type": "error",
                                "error": f"Max consecutive failures reached ({consecutive_failures}). "
                                        f"Last failure: {tool_name} - {result.error}",
                                "timestamp": timestamp
                            })
                            break
                    else:
                        consecutive_failures = 0  # Reset counter on success
                    
                    # Fix #7: Enhance error messages for model
                    if not result.success:
                        # Provide detailed error context
                        enhanced_error = f"Tool execution failed: {tool_name}"
                        if tool_name == "code_editor":
                            operation = tool_input.get("operation", "")
                            file_path = tool_input.get("path", "")
                            enhanced_error += f"\nOperation: {operation}"
                            if file_path:
                                enhanced_error += f"\nFile path: {file_path}"
                        elif tool_name == "bash":
                            command = tool_input.get("command", "")
                            if command:
                                enhanced_error += f"\nCommand: {command[:100]}"  # First 100 chars
                        
                        enhanced_error += f"\nError details: {result.error}"
                        enhanced_error += f"\nSuggestion: Check file permissions, disk space, or command syntax"
                        
                        result.error = enhanced_error
                        logger.error(f"Enhanced error message: {enhanced_error}")
                    
                    # Format result for model (Anthropic format)
                    tool_result_content = format_tool_result_for_model(tool_use_id, result)
                    tool_results_content.append(tool_result_content)
                    
                    # Add tool result event to events list
                    events.append({
                        "type": "tool_result",
                        "tool": {
                            "toolUseId": tool_use_id,
                            "name": tool_name,
                            "result": tool_result_content
                        },
                        "success": result.success,
                        "timestamp": timestamp
                    })
                    
                    logger.info(
                        f"Tool {tool_name} executed: success={result.success}, "
                        f"time={result.execution_time_ms}ms"
                    )
                
                # Send tool results back for follow-up (only if stop_reason is tool_use)
                # Build messages for follow-up request
                follow_up_messages = []
                
                # Add initial user message (only on first turn)
                if follow_up_count == 0:
                    follow_up_messages.append({
                        "role": "user",
                        "content": f"Project directory: {project_path}\n\n{prompt}"
                    })
                
                # Add assistant message with tool uses (from current response)
                assistant_content = []
                for content_block in response_data.get('content', []):
                    if content_block.get('type') == 'text':
                        assistant_content.append(content_block)
                    elif content_block.get('type') == 'tool_use':
                        assistant_content.append(content_block)
                
                if assistant_content:
                    follow_up_messages.append({
                        "role": "assistant",
                        "content": assistant_content
                    })
                
                # Add tool results as user message
                follow_up_messages.append({
                    "role": "user",
                    "content": tool_results_content
                })
                
                # Make follow-up request
                follow_up_request = {
                    "model": self.model_id,
                    "messages": follow_up_messages,
                    "max_tokens": effective_max_tokens,
                    "temperature": effective_temperature,
                    "stream": False
                }
                
                if system_prompt:
                    follow_up_request["system"] = system_prompt
                
                if enable_tools:
                    follow_up_request["tools"] = [
                        self.CODE_EDITOR_TOOL,
                        self.BASH_TOOL
                    ]
                
                logger.info("Sending tool results back to model for follow-up turn")
                async with portkey_llm_rate_limiter.acquire(
                    estimated_tokens=effective_max_tokens
                ):
                    async with httpx.AsyncClient(timeout=3600) as client:
                        follow_up_response = await client.post(
                            url,
                            headers=self.headers,
                            json=follow_up_request
                        )
                        if follow_up_response.status_code == 429:
                            retry_after = int(follow_up_response.headers.get('Retry-After', 60))
                            raise RateLimitError(
                                message="Portkey rate limit exceeded",
                                retry_after=retry_after,
                                details=f"Status: {follow_up_response.status_code}"
                            )
                        follow_up_response.raise_for_status()
                        response_data = follow_up_response.json()  # Update for next iteration
                
                # Process follow-up response and append to events
                follow_up_events = await self._process_response(response_data, project_path)
                events.extend(follow_up_events)
                
                logger.info(f"Follow-up turn completed: {len(follow_up_events)} additional events")
                
                # Check if model indicated completion in text response (Fix #2: Smart termination)
                completion_indicators = ["done", "complete", "finished", "completed", "all set", "no further"]
                text_content = ""
                for content_block in response_data.get('content', []):
                    if content_block.get('type') == 'text':
                        text_content += content_block.get('text', '').lower()
                
                if any(indicator in text_content for indicator in completion_indicators):
                    logger.info(f"Smart termination: Model indicated completion in text response")
                    break
                
                # Check if follow-up response also requests tools
                stop_reason = response_data.get('stop_reason', 'end_turn')
                follow_up_count += 1

            logger.info("Portkey invocation completed successfully")
            return events

        except RateLimitError:
            raise  # Already correctly formatted; tenacity retry handles it

        except httpx.HTTPStatusError as e:
            status_code = e.response.status_code

            logger.error(f"Portkey HTTP error: {status_code}")

            if status_code in [401, 403]:
                raise AuthenticationError(
                    message=f"Portkey authentication failed: {e.response.text}",
                    details=f"Status: {status_code}"
                )
            else:
                raise ProviderError(
                    message=f"Portkey API error: {e.response.text}",
                    provider="portkey",
                    details=f"Status: {status_code}"
                )

        except Exception as e:
            error_msg = f"Unexpected error during Portkey invocation: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ProviderError(
                message=error_msg,
                provider="portkey",
                details=str(e)
            )

    async def _process_response(
        self,
        response_data: Dict[str, Any],
        project_path: str
    ) -> List[Dict[str, Any]]:
        """
        Process Portkey response and normalize to Claude CLI format.

        Converts Anthropic Messages API response (via Portkey) to
        Claude CLI stream-json event list format for compatibility.

        Args:
            response_data: Response data from Portkey
            project_path: Project path for security validation

        Returns:
            List of normalized events

        Event format transformation:
            Anthropic response structure is converted to event list:
            - {"type": "system", "subtype": "init"}
            - {"type": "assistant", "subtype": "content_start"}
            - {"type": "assistant", "subtype": "text_delta", "text": "..."}
            - {"type": "tool_use", "tool": {...}}
            - {"type": "assistant", "subtype": "content_stop"}
            - {"type": "message_stop", "stop_reason": "..."}
            - {"type": "result", "input_tokens": ..., "output_tokens": ...}
        """
        from app.core.security import SecurityValidator

        events = []
        timestamp = int(time.time() * 1000)

        try:
            # Add init event
            events.append({
                        "type": "system",
                        "subtype": "init",
                        "timestamp": timestamp
            })

            # Extract response components
            content_blocks = response_data.get('content', [])
            stop_reason = response_data.get('stop_reason', 'end_turn')

            # Get usage information
            usage = response_data.get('usage', {})
            input_tokens = usage.get('input_tokens', 0)
            output_tokens = usage.get('output_tokens', 0)

            # Process each content block
            for content_block in content_blocks:
                # Content start event
                events.append({
                        "type": "assistant",
                        "subtype": "content_start",
                        "timestamp": timestamp
                })

                block_type = content_block.get('type', '')

                # Text content
                if block_type == 'text':
                    text = content_block.get('text', '')
                    events.append({
                            "type": "assistant",
                            "subtype": "text_delta",
                            "text": text,
                        "timestamp": timestamp
                    })

                # Tool use content - SECURITY: Validate tool inputs before adding
                elif block_type == 'tool_use':
                    tool_name = content_block.get('name', '')
                    tool_input = content_block.get('input', {})
                    tool_use_id = content_block.get('id', '')

                    # CRITICAL SECURITY: Validate bash commands
                    if tool_name == 'bash':
                        command = tool_input.get('command', '')
                        if command:
                            try:
                                from app.core.config import get_settings
                                settings = get_settings()
                                
                                # Skip validation if disabled
                                if not settings.security.bash_command_validation_enabled:
                                    logger.warning(f"SECURITY: Bash validation disabled, allowing command: {command[:50]}...")
                                else:
                                    # Validate command with safe pipe and command chain support
                                    validated_command = SecurityValidator.validate_bash_command(
                                        command,
                                        allow_safe_pipes=settings.security.allow_safe_pipes,
                                        allow_safe_command_chains=settings.security.allow_safe_command_chains
                                    )
                                    logger.info(f"Validated bash command: {validated_command[:50]}...")
                            except ValueError as e:
                                # Command validation failed - log and add error event
                                logger.error(f"SECURITY: Rejected unsafe bash command: {e}")
                                events.append({
                                    "type": "error",
                                    "error": f"Security validation failed: {str(e)}",
                                    "timestamp": timestamp
                                })
                                continue

                    # CRITICAL SECURITY: Validate file paths
                    elif tool_name == 'code_editor':
                        file_path = tool_input.get('path', '')
                        if file_path:
                            try:
                                from app.core.config import get_settings
                                settings = get_settings()
                                
                                # Skip validation if disabled
                                if not settings.security.path_traversal_protection_enabled:
                                    logger.warning(f"SECURITY: Path validation disabled, allowing path: {file_path}")
                                else:
                                    # Check for path traversal using improved validation
                                    if '..' in file_path:
                                        raise ValueError(f"Path traversal detected (..): {file_path}")
                                    
                                    # Allow absolute paths if they're in approved directories
                                    if file_path.startswith('/'):
                                        if not SecurityValidator.is_safe_absolute_path(
                                            file_path,
                                            project_path,
                                            allowed_dirs=settings.security.get_allowed_directories_list()
                                        ):
                                            raise ValueError(
                                                f"Absolute path outside allowed directories: {file_path}"
                                            )
                                    
                                    logger.info(f"Validated file path: {file_path}")
                            except ValueError as e:
                                logger.error(f"SECURITY: Rejected unsafe file path: {e}")
                                events.append({
                                    "type": "error",
                                    "error": f"Security validation failed: {str(e)}",
                                    "timestamp": timestamp
                                })
                                continue

                    # Validation passed or not applicable - add tool use event
                    events.append({
                                "type": "tool_use",
                        "tool": {
                            "toolUseId": tool_use_id,
                            "name": tool_name,
                            "input": tool_input
                        },
                                "timestamp": timestamp
                    })

                # Content stop event
                events.append({
                        "type": "assistant",
                        "subtype": "content_stop",
                        "timestamp": timestamp
                })

            # Message stop event
            events.append({
                        "type": "message_stop",
                        "stop_reason": stop_reason,
                        "timestamp": timestamp
            })

            # Final result event (matches Java's stream-json format)
            events.append({
                        "type": "result",
                        "is_error": False,
                        "input_tokens": input_tokens,
                        "output_tokens": output_tokens,
                        "stop_reason": stop_reason,
                        "timestamp": timestamp
            })

            return events

        except Exception as e:
            logger.error(f"Error processing Portkey response: {str(e)}", exc_info=True)
            events.append({
                "type": "error",
                "error": str(e),
                "timestamp": int(time.time() * 1000)
            })
            return events

    def _get_completion_instructions(self, iteration: int, max_iterations: Optional[int] = None, unlimited: bool = False) -> str:
        """
        Generate completion instructions for the model.
        
        Args:
            iteration: Current iteration number (not used, kept for compatibility)
            max_iterations: Maximum iterations allowed (None if unlimited)
            unlimited: Whether unlimited iterations mode is enabled
            
        Returns:
            Completion instructions string
        """
        # Single unified instruction set focusing only on JSON output format
        base_instructions = """
═══════════════════════════════════════════════════════════════════════════════
🚨 MANDATORY FINAL OUTPUT FORMAT - NON-NEGOTIABLE 🚨
═══════════════════════════════════════════════════════════════════════════════

ABSOLUTE REQUIREMENT:
When you complete ALL your operations, you MUST output a JSON response in your final 
text message. This is NOT optional. This is NOT a suggestion. This MUST be done.

FORMAT SPECIFICATION (FOLLOW EXACTLY):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Step 1: Complete all required operations (read files, write files, run commands, etc.)

Step 2: Write your final summary/explanation text

Step 3: Output the JSON response wrapped in triple backticks with 'json' language tag:

```json
{
  ... your JSON output here following the EXACT schema from the prompt ...
}
```

CRITICAL CONSTRAINTS:
✓ Output JSON in your TEXT RESPONSE (conversational message)
✓ Use EXACTLY this format: ```json ... ``` (triple backticks with 'json' tag)
✓ Follow the EXACT JSON schema/structure specified in the original prompt
✓ Use the EXACT field names, types, and structure from the prompt template
✓ JSON must be valid, parseable, and match the prompt's schema
✗ DO NOT use code_editor tool to write JSON to files
✗ DO NOT omit the triple backticks
✗ DO NOT omit the 'json' language tag after opening backticks
✗ DO NOT modify or change the required JSON schema from the prompt
✗ DO NOT add extra fields not specified in the prompt schema
✗ DO NOT skip required fields from the prompt schema

SCHEMA SOURCE - READ CAREFULLY:
The JSON schema/template was provided in your original prompt above. 
Review the prompt to find the exact JSON structure you must output.
Match field names, data types, and structure EXACTLY as specified.

WHY THIS MATTERS:
• The entire system pipeline depends on extracting this JSON from your text response
• JSON parser expects the EXACT schema defined in the prompt
• Without properly formatted JSON output matching the schema, the operation FAILS completely
• This is the ONLY way results are captured, parsed, and returned to the user
• Wrong schema = Parser fails = No results = System failure

VERIFICATION CHECKLIST (before sending end_turn):
□ Have I completed all required operations?
□ Have I reviewed the JSON schema in the original prompt?
□ Have I included JSON in my final text response?
□ Is the JSON wrapped in ```json ... ``` triple backticks with 'json' tag?
□ Does my JSON match the EXACT schema/structure from the prompt?
□ Have I included ALL required fields from the prompt schema?
□ Are ALL field names and types correct per the prompt?

═══════════════════════════════════════════════════════════════════════════════
"""
        return base_instructions

    async def _invoke_single_turn_no_tools(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        process_response: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None,
        prepend_project_context: bool = True,
    ) -> List[Dict[str, Any]]:
        """One Portkey call with tools disabled — for JSON schema generation."""
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature
        user_text = (
            f"Project directory: {project_path}\n\n{prompt}"
            if prepend_project_context
            else prompt
        )
        request_body: Dict[str, Any] = {
            "model": self.model_id,
            "messages": [{"role": "user", "content": user_text}],
            "max_tokens": effective_max_tokens,
            "temperature": effective_temperature,
            "stream": False,
            "system": system_prompt
            or "Return valid JSON exactly as requested. Do not use tools.",
        }

        logger.info(
            "Single-turn Portkey call (tools disabled): model=%s max_tokens=%s "
            "prompt_chars=%s prepend_project=%s",
            self.model_id,
            effective_max_tokens,
            len(prompt),
            prepend_project_context,
        )
        started = time.monotonic()
        url = f"{self.base_url}/messages"
        async with portkey_llm_rate_limiter.acquire(
            estimated_tokens=effective_max_tokens
        ):
            async with httpx.AsyncClient(timeout=3600) as client:
                response = await client.post(
                    url, headers=self.headers, json=request_body
                )
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 60))
                    raise RateLimitError(
                        message="Portkey rate limit exceeded",
                        retry_after=retry_after,
                        details=f"Status: {response.status_code}",
                    )
                response.raise_for_status()
                response_data = response.json()

        logger.info(
            "Single-turn Portkey call completed in %.1fs (stop_reason=%s)",
            time.monotonic() - started,
            response_data.get("stop_reason"),
        )

        if process_response:
            events = await self._process_response(response_data, project_path)
        else:
            events = [response_data]
        if on_event:
            for event in events:
                on_event(event)
        return events

    async def invoke_with_tools_agentic(
        self,
        prompt: str,
        project_path: str,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        process_response: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None,
        prepend_project_context: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Invoke Portkey with agentic tool execution (multi-turn conversation).

        This method implements the full agentic loop using Anthropic Messages API:
        1. Send initial prompt to model
        2. If model requests tools, execute them
        3. Send results back to model
        4. Repeat until model finishes (stop_reason: end_turn)

        Args:
            prompt: User prompt content
            project_path: Project directory path (for context and tool execution)
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens per turn (default: from config)
            temperature: Model temperature (default: from config)
            enable_tools: Whether to enable tool use (default: True)
            process_response: Whether to normalize the raw API response through
                _process_response (security validation + event format conversion).
                Set to False to get the raw Anthropic response directly, useful for
                simple single-turn completions where normalization is unnecessary.
                Defaults to True to preserve existing behavior.
            on_event: Optional callback for event notifications

        Returns:
            List of all events from all iterations combined

        Raises:
            ProviderError: If Portkey API call fails
            AuthenticationError: If authentication fails
        """
        from app.services.tool_executor import ToolExecutor, format_tool_result_for_model
        from app.core.config import get_settings
        
        settings = get_settings()
        
        # Check if agentic mode is enabled
        if not settings.agentic.enabled:
            logger.info("Agentic mode disabled, falling back to single-turn")
            return await self.invoke_with_tools(
                prompt, project_path, system_prompt, max_tokens, temperature, enable_tools
            )

        if not enable_tools:
            logger.info("Tools disabled — single-turn path (skipping agentic loop)")
            return await self._invoke_single_turn_no_tools(
                prompt=prompt,
                project_path=project_path,
                system_prompt=system_prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                process_response=process_response,
                on_event=on_event,
                prepend_project_context=prepend_project_context,
            )
        
        logger.info("Starting agentic loop for tool execution (Portkey)")
        
        # Initialize tool executor
        tool_executor = ToolExecutor(
            project_path=project_path,
            working_directory=project_path,
            timeout=settings.agentic.tool_execution_timeout
        )
        
        # Track state across iterations
        all_events = []
        iteration = 0
        consecutive_errors = 0
        
        # Determine if unlimited mode is enabled
        unlimited_mode = settings.agentic.unlimited_iterations or settings.agentic.max_iterations == 0
        effective_max_iterations = settings.agentic.max_iterations if not unlimited_mode else None
        
        # Build initial messages (Anthropic format)
        messages = [
            {
                "role": "user",
                "content": f"Project directory: {project_path}\n\n{prompt}"
            }
        ]
        
        # Agentic loop - continue until end_turn or safety limits
        while True:
            # Check iteration limit (only if not unlimited)
            if not unlimited_mode and iteration >= settings.agentic.max_iterations:
                break
            
            iteration += 1
            if unlimited_mode:
                logger.info(f"Agentic iteration {iteration} (unlimited mode)")
            else:
                logger.info(f"Agentic iteration {iteration}/{settings.agentic.max_iterations}")
            
            try:
                # Build request for this iteration (Anthropic format)
                request_body = {
                    "model": self.model_id,
                    "messages": messages,
                    "max_tokens": max_tokens or self.max_tokens,
                    "temperature": temperature or self.temperature,
                    "stream": False
                }
                
                # Add system prompt with completion instructions
                completion_instructions = self._get_completion_instructions(
                    iteration, 
                    effective_max_iterations, 
                    unlimited_mode
                )
                if system_prompt:
                    # Append completion instructions to existing system prompt
                    request_body["system"] = f"{system_prompt}\n\n{completion_instructions}"
                else:
                    # Use completion instructions as system prompt
                    request_body["system"] = completion_instructions
                
                # Only add system prompt on first iteration or when approaching limits
                # (Portkey includes system in every request, so we always set it)
                
                # Add tools if enabled
                if enable_tools:
                    request_body["tools"] = [
                        self.CODE_EDITOR_TOOL,
                        self.BASH_TOOL
                    ]
                
                # Invoke Portkey — gated by LLM rate limiter (semaphore + RPM/TPM + adaptive delay).
                # The rate limiter holds the semaphore only for the duration of the HTTP call;
                # tool execution below is completely unaffected.
                logger.debug(f"Iteration {iteration}: Invoking Portkey")
                url = f"{self.base_url}/messages"

                try:
                    async with portkey_llm_rate_limiter.acquire(
                        estimated_tokens=max_tokens or self.max_tokens
                    ):
                        async with httpx.AsyncClient(timeout=3600) as client:
                            response = await client.post(
                                url,
                                headers=self.headers,
                                json=request_body
                            )
                            if response.status_code == 429:
                                retry_after = int(response.headers.get('Retry-After', 60))
                                raise RateLimitError(
                                    message="Portkey rate limit exceeded",
                                    retry_after=retry_after,
                                    details=f"Status: {response.status_code}"
                                )
                            response.raise_for_status()
                            response_data = response.json()
                except RateLimitError:
                    raise  # Rate limiter already recorded throttle; tenacity handles retry
                except httpx.HTTPStatusError as e:
                    status_code = e.response.status_code

                    logger.error(f"Portkey HTTP error in agentic iteration {iteration}: {status_code}")

                    if status_code in [401, 403]:
                        raise AuthenticationError(
                            message=f"Portkey authentication failed: {e.response.text}",
                            details=f"Status: {status_code}"
                        )
                    else:
                        raise ProviderError(
                            message=f"Portkey API error: {e.response.text}",
                            provider="portkey",
                            details=f"Status: {status_code}"
                        )
                
                # Process response — skip normalization when caller opts out
                if process_response:
                    events = await self._process_response(response_data, project_path)
                else:
                    events = [response_data]
                all_events.extend(events)
                if on_event:
                    for e in events:
                        on_event(e)
                
                # Extract stop reason
                if process_response:
                    result_event = next((e for e in reversed(events) if e.get("type") == "result"), None)
                    if result_event:
                        stop_reason = result_event.get("stop_reason")
                        logger.info(f"Iteration {iteration}: stop_reason={stop_reason}")
                    else:
                        logger.warning(f"Iteration {iteration}: No result event found")
                        stop_reason = "unknown"
                else:
                    # Raw Anthropic response — stop_reason is a top-level field
                    stop_reason = response_data.get("stop_reason", "unknown")
                    if stop_reason == "unknown":
                        logger.warning(f"Iteration {iteration}: stop_reason missing from raw response")
                    else:
                        logger.info(f"Iteration {iteration}: stop_reason={stop_reason} (raw response)")

                # Check stop reason
                if stop_reason == "end_turn":
                    logger.info(f"Agentic loop completed normally after {iteration} iterations")
                    break
                
                elif stop_reason == "tool_use":
                    logger.info(f"Iteration {iteration}: Tool use requested, executing tools")
                    
                    # Extract tool uses from events
                    tool_use_events = [e for e in events if e.get("type") == "tool_use"]
                    
                    if not tool_use_events:
                        logger.warning("stop_reason=tool_use but no tool_use events found")
                        break
                    
                    # Execute each tool
                    tool_results_content = []
                    tool_execution_success = False
                    file_write_detected = False
                    file_patch_detected = False
                    
                    for tool_event in tool_use_events:
                        tool = tool_event.get("tool", {})
                        tool_use_id = tool.get("toolUseId", "")
                        tool_name = tool.get("name", "")
                        tool_input = tool.get("input", {})
                        operation = tool_input.get("operation", "")
                        
                        logger.info(f"Executing tool: {tool_name} (ID: {tool_use_id})")
                        
                        # Track file modifications for progress detection
                        if tool_name == "code_editor":
                            if operation == "write":
                                file_write_detected = True
                                last_file_write_iteration = iteration
                            elif operation == "patch":
                                file_patch_detected = True
                                last_file_write_iteration = iteration
                        
                        # Execute the tool
                        result = tool_executor.execute_tool(tool_name, tool_input, tool_use_id)
                        
                        if result.success:
                            tool_execution_success = True
                            consecutive_errors = 0
                        else:
                            consecutive_errors += 1
                            logger.error(
                                f"Tool execution failed: {tool_name}, "
                                f"consecutive_errors={consecutive_errors}"
                            )
                        
                        # Format result for model
                        tool_result_content = format_tool_result_for_model(tool_use_id, result)
                        tool_results_content.append(tool_result_content)
                        
                        # Log execution
                        logger.info(
                            f"Tool {tool_name} executed: success={result.success}, "
                            f"time={result.execution_time_ms}ms, "
                            f"output_len={len(result.output)}"
                        )
                    
                    # Check consecutive errors
                    if consecutive_errors >= settings.agentic.max_consecutive_errors:
                        logger.error(
                            f"Max consecutive errors reached: {consecutive_errors}, stopping"
                        )
                        break
                    
                    # Add assistant message (from response) - Anthropic format
                    assistant_content = []
                    for content_block in response_data.get('content', []):
                        if content_block.get('type') == 'text':
                            assistant_content.append(content_block)
                        elif content_block.get('type') == 'tool_use':
                            assistant_content.append(content_block)
                    
                    messages.append({
                        "role": "assistant",
                        "content": assistant_content
                    })
                    
                    # Add tool results as user message - Anthropic format
                    messages.append({
                        "role": "user",
                        "content": tool_results_content
                    })
                    
                    logger.debug(f"Added tool results to conversation, continuing to iteration {iteration + 1}")
                
                elif stop_reason == "max_tokens":
                    logger.warning(f"Model reached max_tokens in iteration {iteration}")
                    break
                
                else:
                    logger.info(f"Unexpected stop_reason: {stop_reason}, ending loop")
                    break
            
            except httpx.HTTPStatusError as e:
                status_code = e.response.status_code
                logger.error(f"Portkey HTTP error in iteration {iteration}: {status_code}")
                consecutive_errors += 1
                
                if consecutive_errors >= settings.agentic.max_consecutive_errors:
                    logger.error("Max consecutive errors reached, stopping agentic loop")
                    break
                
                err_ev = {
                    "type": "error",
                    "error": f"HTTP error {status_code}: {e.response.text}",
                    "timestamp": int(time.time() * 1000)
                }
                all_events.append(err_ev)
                if on_event:
                    on_event(err_ev)
                break
            
            except Exception as e:
                logger.error(f"Error in agentic iteration {iteration}: {str(e)}", exc_info=True)
                consecutive_errors += 1
                
                if consecutive_errors >= settings.agentic.max_consecutive_errors:
                    logger.error("Max consecutive errors reached, stopping agentic loop")
                    break
                
                err_ev = {
                    "type": "error",
                    "error": f"Iteration {iteration} error: {str(e)}",
                    "timestamp": int(time.time() * 1000)
                }
                all_events.append(err_ev)
                if on_event:
                    on_event(err_ev)
                break
        
        # Add final event if loop ended due to max_iterations (only in limited mode)
        if not unlimited_mode and iteration >= settings.agentic.max_iterations:
            logger.warning(f"Agentic loop reached max_iterations ({settings.agentic.max_iterations}), task may be incomplete")
            max_ev = {
                "type": "system",
                "subtype": "max_iterations_reached",
                "message": f"Agentic loop reached maximum iterations ({settings.agentic.max_iterations}). Task may be incomplete.",
                "timestamp": int(time.time() * 1000)
            }
            all_events.append(max_ev)
            if on_event:
                on_event(max_ev)
        
        # Log final statistics
        logger.info(
            f"Agentic loop finished: iterations={iteration}, events={len(all_events)}"
        )
        
        return all_events

    async def invoke_with_tools_agentic_graph(
        self,
        prompt: str,
        project_path: str,
        provider_factory,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        on_event: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> List[Dict[str, Any]]:
        """
        Agentic execution using dependency graph (NO max_iterations).
        
        This method uses graph-based execution instead of max_iterations.
        Execution is bounded by graph size, not arbitrary iteration limits.
        Works deterministically with topological ordering.
        
        Identical to Bedrock version but works with Portkey provider.
        
        Args:
            prompt: User prompt content
            project_path: Project directory path
            provider_factory: ProviderFactory instance for creating providers
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens per turn (default: from config)
            temperature: Model temperature (default: from config)
            enable_tools: Whether to enable tool use (default: True)
            
        Returns:
            List of events from graph execution
            
        Raises:
            ValueError: If graph has circular dependencies or invalid structure
            ProviderError: If provider operations fail
        """
        from app.orchestrator.graph_orchestrator import GraphOrchestrator
        from app.core.config import get_settings
        import time
        
        settings = get_settings()
        
        logger.info("Starting graph-based agentic execution (Portkey)")
        
        # Create orchestrator
        orchestrator = GraphOrchestrator(
            project_path=project_path,
            provider_factory=provider_factory,
            max_retries=getattr(settings.agentic, 'max_module_retries', 3),
            validation_timeout=getattr(settings.agentic, 'validation_timeout', 300),
            skip_validation=getattr(settings.agentic, 'skip_validation', False)
        )
        
        # Execute orchestration
        try:
            state = await orchestrator.orchestrate(prompt, on_event=on_event)
        except Exception as e:
            logger.error(f"Graph orchestration failed: {e}", exc_info=True)
            raise
        
        # Convert state to events format (compatible with existing event structure)
        events = []
        
        # Add graph start event
        graph_start_ev = {
            "type": "system",
            "subtype": "graph_start",
            "message": f"Graph orchestration started: {state.total_modules} modules",
            "timestamp": int(time.time() * 1000)
        }
        events.append(graph_start_ev)
        if on_event:
            on_event(graph_start_ev)
        
        # Add module completion events AND all tool execution events
        for module in state.graph.values():
            # Add module summary event
            module_ev = {
                "type": "module_completed",
                "module": module.name,
                "path": module.path,
                "status": module.status.value,
                "retries": module.retries,
                "files_changed": module.files_changed,
                "error": module.last_error,
                "timestamp": int(time.time() * 1000)
            }
            events.append(module_ev)
            if on_event:
                on_event(module_ev)
            
            # Add all tool execution events from this module (already streamed via on_event in orchestrator)
            if module.events:
                # Add module context to events for clarity
                for event in module.events:
                    # Add module name to event for traceability
                    event_with_context = event.copy()
                    event_with_context["module"] = module.name
                    events.append(event_with_context)
        
        # Add graph completion event
        progress = state.get_progress()
        graph_complete_ev = {
            "type": "system",
            "subtype": "graph_complete",
            "message": (
                f"Graph orchestration complete: "
                f"{progress['locked']} succeeded, "
                f"{progress['failed']} failed, "
                f"{progress['skipped']} skipped, "
                f"{state.current_iteration} iterations"
            ),
            "progress": progress,
            "timestamp": int(time.time() * 1000)
        }
        events.append(graph_complete_ev)
        if on_event:
            on_event(graph_complete_ev)
        
        logger.info(
            f"Graph execution complete: {len(events)} events, "
            f"{progress['locked']} modules succeeded"
        )
        
        return events

    async def invoke_simple(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Simple invoke for read-only operations without tool use.

        Args:
            prompt: User prompt content
            max_tokens: Maximum tokens (default from config)
            temperature: Model temperature (default from config)

        Returns:
            Complete response dictionary

        Raises:
            ProviderError: If Portkey API call fails
        """
        effective_max_tokens = max_tokens or self.max_tokens
        effective_temperature = temperature or self.temperature

        logger.info("Invoking Portkey (simple mode, no tools)")

        messages = [
            {
                "role": "user",
                "content": prompt
            }
        ]

        request_body = {
            "model": self.model_id,
            "messages": messages,
            "max_tokens": effective_max_tokens,
            "temperature": effective_temperature,
            "stream": False
        }

        url = f"{self.base_url}/chat/completions"

        try:
            async with portkey_llm_rate_limiter.acquire(
                estimated_tokens=effective_max_tokens
            ):
                async with httpx.AsyncClient(timeout=300) as client:
                    response = await client.post(
                        url,
                        headers=self.headers,
                        json=request_body
                    )
                    if response.status_code == 429:
                        retry_after = int(response.headers.get('Retry-After', 60))
                        raise RateLimitError(
                            message="Portkey rate limit exceeded",
                            retry_after=retry_after,
                            details=f"Status: {response.status_code}"
                        )
                    response.raise_for_status()
                    logger.info("Portkey simple invocation completed")
                    return response.json()

        except RateLimitError:
            raise

        except httpx.HTTPStatusError as e:
            raise ProviderError(
                message=f"Portkey API error: {e.response.text}",
                provider="portkey",
                details=f"Status: {e.response.status_code}"
            )

    async def health_check(self) -> bool:
        """
        Check if Portkey API is reachable.

        Returns:
            True if API is healthy, False otherwise
        """
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(
                    f"{self.base_url}/health",
                    headers={"x-portkey-api-key": self.api_key}
                )

                if response.status_code == 200:
                    logger.info("Portkey health check: OK")
                    return True
                else:
                    logger.warning(f"Portkey health check failed: status={response.status_code}")
                    return False

        except Exception as e:
            logger.error(f"Portkey health check error: {str(e)}")
            return False
