"""
LLM Validator Service for credential validation.

Service for validating LLM credentials by testing connections to various LLM providers.
Supports AWS Bedrock, IAM Roles, Portkey, Azure AI, and Concierto Private LLM (CAI).
"""
import asyncio
import logging
from typing import Dict, Any, Tuple, Optional
from enum import Enum

import aiohttp
import boto3
from botocore.exceptions import ClientError, BotoCoreError

from app.core.exceptions import ValidationError
from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class AuthMethod(Enum):
    """Enum for authentication methods."""
    AWS_ACCESS_KEY = "AWS Access Key + Secret"
    ASSUMED_ROLE = "Assumed Role (ARN)"
    IAM_ROLE = "IAM Role (Service Role)"
    BEDROCK_API_KEY = "Bedrock API Key"
    PORTKEY = "Portkey"
    CONCIERTO_PRIVATE_LLM = "Concierto Private LLM (CAI)"
    AZURE_AI = "Azure AI"
    NONE = "None"


class LlmValidatorService:
    """Service for validating LLM credentials."""

    def __init__(self):
        """Initialize the LLM validator service."""
        self.timeout = 10  # 10 seconds timeout for validation
        logger.info("LlmValidatorService initialized")

    async def validate_credentials(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Validate LLM credentials.

        Args:
            credentials_dict: Dictionary containing credentials
            tenant_id: Tenant ID for logging

        Returns:
            Tuple of (is_valid, auth_method, error_message)
            - is_valid: True if credentials are valid
            - auth_method: Detected authentication method
            - error_message: Error message if validation failed, None if successful
        """
        try:
            # Detect authentication method
            auth_method = self._detect_auth_method(credentials_dict)
            logger.info(f"Detected auth method for tenant {tenant_id}: {auth_method.value}")

            if auth_method == AuthMethod.NONE:
                error_msg = "No valid authentication credentials provided"
                logger.warning(f"No credentials provided for tenant {tenant_id}")
                return False, auth_method.value, error_msg

            # Validate credentials based on auth method
            if auth_method == AuthMethod.AWS_ACCESS_KEY:
                is_valid, error_msg = await self._validate_aws_access_key(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.IAM_ROLE:
                is_valid, error_msg = await self._validate_iam_role(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.ASSUMED_ROLE:
                is_valid, error_msg = await self._validate_assumed_role(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.BEDROCK_API_KEY:
                is_valid, error_msg = await self._validate_bedrock_api_key(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.PORTKEY:
                is_valid, error_msg = await self._validate_portkey(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.CONCIERTO_PRIVATE_LLM:
                is_valid, error_msg = await self._validate_cai(credentials_dict, tenant_id)
            elif auth_method == AuthMethod.AZURE_AI:
                is_valid, error_msg = await self._validate_azure_ai(credentials_dict, tenant_id)
            else:
                error_msg = f"Unknown authentication method: {auth_method.value}"
                return False, auth_method.value, error_msg

            if is_valid:
                logger.info(f"Credentials validation successful for tenant {tenant_id}, "
                           f"auth_method: {auth_method.value}")
                return True, auth_method.value, None
            else:
                logger.warning(f"Credentials validation failed for tenant {tenant_id}: {error_msg}")
                return False, auth_method.value, error_msg

        except Exception as e:
            logger.error(f"Unexpected error validating credentials for tenant {tenant_id}: {str(e)}")
            return False, AuthMethod.NONE.value, str(e)

    def _detect_auth_method(self, credentials_dict: Dict[str, Any]) -> AuthMethod:
        """Detect which authentication method is being used."""
        if (credentials_dict.get("aws_access_key") and
            credentials_dict.get("aws_secret_key")):
            return AuthMethod.AWS_ACCESS_KEY

        if credentials_dict.get("assumed_role_arn"):
            return AuthMethod.ASSUMED_ROLE

        if credentials_dict.get("llm_arn"):
            return AuthMethod.IAM_ROLE

        if credentials_dict.get("bedrock_api_key"):
            return AuthMethod.BEDROCK_API_KEY

        if credentials_dict.get("portkey_api_key"):
            return AuthMethod.PORTKEY

        if (credentials_dict.get("cai_base_url") and
            credentials_dict.get("cai_api_key")):
            return AuthMethod.CONCIERTO_PRIVATE_LLM

        if credentials_dict.get("azure_ai_endpoint"):
            return AuthMethod.AZURE_AI

        return AuthMethod.NONE

    async def _validate_aws_access_key(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate AWS Access Key + Secret Key."""
        try:
            access_key = credentials_dict.get("aws_access_key")
            secret_key = credentials_dict.get("aws_secret_key")
            region = credentials_dict.get("aws_region")

            if not access_key or not secret_key:
                return False, "AWS Access Key and Secret Key cannot be empty"

            if not region:
                return False, "AWS Region is required"

            # Create Bedrock client with provided credentials
            client = boto3.client(
                "bedrock",
                region_name=region,
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key
            )

            # Test connection by listing foundation models
            await asyncio.wait_for(
                asyncio.to_thread(client.list_foundation_models),
                timeout=self.timeout
            )

            logger.info(f"AWS Access Key validation successful for tenant {tenant_id}")
            return True, None

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_msg = f"AWS Access Key validation failed: {error_code}"
            logger.error(f"AWS validation error for tenant {tenant_id}: {str(e)}")
            return False, error_msg
        except asyncio.TimeoutError:
            error_msg = "AWS credential validation timeout - took longer than 10 seconds"
            logger.error(f"Timeout validating AWS credentials for tenant {tenant_id}")
            return False, error_msg
        except Exception as e:
            error_msg = f"AWS validation error: {str(e)}"
            logger.error(f"Unexpected error validating AWS credentials for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_iam_role(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate IAM Role (Service Role / Instance Profile)."""
        try:
            llm_arn = credentials_dict.get("llm_arn")
            region = credentials_dict.get("aws_region")

            if not llm_arn:
                return False, "LLM ARN cannot be empty"

            if not region:
                return False, "AWS Region is required"

            # Create Bedrock client with default credentials (instance profile)
            client = boto3.client("bedrock", region_name=region)

            # Test connection
            await asyncio.wait_for(
                asyncio.to_thread(client.list_foundation_models),
                timeout=self.timeout
            )

            logger.info(f"IAM Role validation successful for tenant {tenant_id}")
            return True, None

        except ClientError as e:
            error_msg = "IAM Role validation failed: Unable to access Bedrock with current instance role"
            logger.error(f"IAM Role validation error for tenant {tenant_id}: {str(e)}")
            return False, error_msg
        except asyncio.TimeoutError:
            return False, "IAM Role validation timeout"
        except Exception as e:
            error_msg = f"IAM Role validation error: {str(e)}"
            logger.error(f"Unexpected error validating IAM Role for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_assumed_role(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate Assumed Role with STS AssumeRole."""
        try:
            assumed_role_arn = credentials_dict.get("assumed_role_arn")
            region = credentials_dict.get("aws_region")

            if not assumed_role_arn:
                return False, "Assumed Role ARN cannot be empty"

            if not region:
                return False, "AWS Region is required"

            # Create STS client and assume role
            sts_client = boto3.client("sts", region_name=region)

            assume_role_response = await asyncio.wait_for(
                asyncio.to_thread(
                    sts_client.assume_role,
                    RoleArn=assumed_role_arn,
                    RoleSessionName=f"credential-validation-{int(asyncio.get_event_loop().time())}",
                    DurationSeconds=900
                ),
                timeout=self.timeout
            )

            # Get temporary credentials
            credentials = assume_role_response["Credentials"]

            # Test Bedrock access with assumed role credentials
            bedrock_client = boto3.client(
                "bedrock",
                region_name=region,
                aws_access_key_id=credentials["AccessKeyId"],
                aws_secret_access_key=credentials["SecretAccessKey"],
                aws_session_token=credentials["SessionToken"]
            )

            await asyncio.wait_for(
                asyncio.to_thread(bedrock_client.list_foundation_models),
                timeout=self.timeout
            )

            logger.info(f"Assumed Role validation successful for tenant {tenant_id}")
            return True, None

        except ClientError as e:
            error_msg = "Assumed Role validation failed: Unable to assume the specified role"
            logger.error(f"Assumed Role validation error for tenant {tenant_id}: {str(e)}")
            return False, error_msg
        except asyncio.TimeoutError:
            return False, "Assumed Role validation timeout"
        except Exception as e:
            error_msg = f"Assumed Role validation error: {str(e)}"
            logger.error(f"Unexpected error validating Assumed Role for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_bedrock_api_key(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate Bedrock API Key."""
        try:
            api_key = credentials_dict.get("bedrock_api_key")
            region = credentials_dict.get("aws_region")

            if not api_key:
                return False, "Bedrock API Key cannot be empty"

            if not region:
                return False, "AWS Region is required"

            # Validate API key format (basic validation)
            import re
            if not re.match(r"^[A-Za-z0-9_-]{20,}$", api_key):
                return False, "Bedrock API Key format is invalid"

            logger.info(f"Bedrock API Key format validation successful for tenant {tenant_id}")
            return True, None

        except Exception as e:
            error_msg = f"Bedrock API Key validation error: {str(e)}"
            logger.error(f"Unexpected error validating Bedrock API Key for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_portkey(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate Portkey Connection via HTTP."""
        try:
            api_key = credentials_dict.get("portkey_api_key")
            base_url = credentials_dict.get("portkey_base_url") or "https://api.portkey.ai"

            if not api_key:
                return False, "Portkey API Key cannot be empty"

            logger.info(f"Validating Portkey connection for tenant {tenant_id}")

            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
                url = f"{base_url}/v1/models"

                try:
                    async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=self.timeout)) as response:
                        if response.status == 200:
                            logger.info(f"Portkey validation successful for tenant {tenant_id}")
                            return True, None
                        else:
                            error_msg = f"Portkey API returned status {response.status}"
                            logger.warning(f"Portkey validation failed for tenant {tenant_id}: {error_msg}")
                            return False, error_msg
                except asyncio.TimeoutError:
                    return False, "Portkey validation timeout"

        except Exception as e:
            error_msg = f"Portkey validation error: Invalid API key or base URL not accessible"
            logger.error(f"Unexpected error validating Portkey for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_cai(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate Concierto Private LLM (CAI) Connection."""
        try:
            base_url = credentials_dict.get("cai_base_url")
            api_key = credentials_dict.get("cai_api_key")
            model = credentials_dict.get("cai_model")

            if not base_url:
                return False, "CAI Base URL cannot be empty"

            if not api_key:
                return False, "CAI API Key cannot be empty"

            if not model:
                return False, "CAI Model cannot be empty"

            import re
            if not re.match(r"^https?://", base_url):
                return False, "CAI Base URL must start with http:// or https://"

            logger.info(f"Validating CAI connection for tenant {tenant_id}")

            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
                health_url = base_url.rstrip("/") + "/health"

                try:
                    async with session.get(health_url, headers=headers, timeout=aiohttp.ClientTimeout(total=self.timeout)) as response:
                        if response.status == 200:
                            logger.info(f"CAI validation successful for tenant {tenant_id}")
                            return True, None
                        else:
                            error_msg = f"CAI endpoint returned status {response.status}"
                            logger.warning(f"CAI validation failed for tenant {tenant_id}: {error_msg}")
                            return False, error_msg
                except asyncio.TimeoutError:
                    return False, "CAI validation timeout"

        except Exception as e:
            error_msg = "CAI validation failed: Invalid API key, base URL, or service not accessible"
            logger.error(f"Unexpected error validating CAI for tenant {tenant_id}: {str(e)}")
            return False, error_msg

    async def _validate_azure_ai(
        self,
        credentials_dict: Dict[str, Any],
        tenant_id: str
    ) -> Tuple[bool, Optional[str]]:
        """Validate Azure AI Connection."""
        try:
            endpoint = credentials_dict.get("azure_ai_endpoint")

            if not endpoint:
                return False, "Azure AI Endpoint cannot be empty"

            import re
            if not re.match(r"^https?://", endpoint):
                return False, "Azure AI Endpoint must start with http:// or https://"

            # Validate endpoint format
            if "openai.azure.com" not in endpoint and "cognitiveservices.azure.com" not in endpoint:
                return False, "Azure AI Endpoint must be a valid Azure OpenAI endpoint"

            logger.info(f"Validating Azure AI connection for tenant {tenant_id}")

            async with aiohttp.ClientSession() as session:
                headers = {"Content-Type": "application/json"}
                health_url = endpoint.rstrip("/") + "/health"

                try:
                    async with session.get(health_url, headers=headers, timeout=aiohttp.ClientTimeout(total=self.timeout)) as response:
                        if response.status == 200:
                            logger.info(f"Azure AI validation successful for tenant {tenant_id}")
                            return True, None
                        elif response.status == 404:
                            # Health endpoint might not exist, but endpoint is valid
                            logger.info(f"Azure AI endpoint format validation successful for tenant {tenant_id}")
                            return True, None
                        else:
                            error_msg = f"Azure AI endpoint returned status {response.status}"
                            logger.warning(f"Azure AI validation failed for tenant {tenant_id}: {error_msg}")
                            return False, error_msg
                except asyncio.TimeoutError:
                    return False, "Azure AI validation timeout"

        except Exception as e:
            error_msg = "Azure AI validation failed: Endpoint not accessible or invalid configuration"
            logger.error(f"Unexpected error validating Azure AI for tenant {tenant_id}: {str(e)}")
            return False, error_msg


# Dependency injection function
async def get_llm_validator_service() -> LlmValidatorService:
    """Get LLM validator service instance."""
    return LlmValidatorService()
