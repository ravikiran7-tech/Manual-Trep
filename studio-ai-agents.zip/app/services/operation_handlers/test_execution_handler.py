"""
Test Execution Handler - Java test execution operation.

Executes Maven/Gradle tests with specific Java versions.
Equivalent to Java's test execution capabilities in BuildCompilationService.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class TestExecutionHandler(BaseOperationHandler):
    """
    Handler for 'test-execution' operation.

    Executes tests with specific Java versions using SDKMAN.
    Focuses on running test suites without full compilation.

    Key Features:
    - Java version management (8, 11, 17, 21, 25)
    - Maven test execution (mvn test)
    - Gradle test execution (gradle test)
    - Test failure extraction
    - Test coverage reporting

    Timeout: 1800s (30 minutes)
    Output: validation/{analysisId}/test-execution-stream.json
    """

    # Supported Java versions mapped to SDKMAN versions
    JAVA_VERSION_MAPPING = {
        "8": "8.0.422-tem",
        "1.8": "8.0.422-tem",
        "11": "11.0.25-tem",
        "17": "17.0.13-tem",
        "21": "21.0.5-tem",
        "25": "25.0.4-tem"
    }

    def __init__(self, provider_factory):
        """
        Initialize test execution handler.

        Args:
            provider_factory: Provider factory for creating AI clients
        """
        super().__init__(provider_factory)
        self.sdkman_init_script = Path.home() / ".sdkman" / "bin" / "sdkman-init.sh"

    def get_timeout(self) -> int:
        """
        Get timeout for test execution operation.

        Returns:
            Timeout in seconds (1800s = 30 minutes)
        """
        return settings.timeouts.build_validation

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate test execution request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Test execution requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for test-execution operation",
                field="prompt"
            )

        # Validate Java version
        if not request.java_version:
            raise ValidationError(
                message="Java version is required for test-execution. "
                       f"Supported versions: {list(self.JAVA_VERSION_MAPPING.keys())}",
                field="javaVersion"
            )

        if request.java_version not in self.JAVA_VERSION_MAPPING:
            raise ValidationError(
                message=f"Unsupported Java version: {request.java_version}. "
                       f"Supported versions: {list(self.JAVA_VERSION_MAPPING.keys())}",
                field="javaVersion"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute test execution operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with test results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting test execution: analysisId={request.analysis_id}, "
            f"javaVersion={request.java_version}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get SDKMAN version for requested Java version
            sdkman_version = self.JAVA_VERSION_MAPPING[request.java_version]
            logger.info(f"Using SDKMAN Java version: {sdkman_version}")

            # Verify Java version is installed
            self._verify_java_version_installed(sdkman_version)

            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Enhance prompt with Java version and test context
            enhanced_prompt = self._enhance_prompt_with_test_context(
                prompt_content,
                request.java_version,
                sdkman_version
            )

            # Build output path
            output_path = self.build_output_path(request, "test-execution-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Create validation directory structure
            self._create_validation_directories(request)

            # Execute with provider
            logger.info("Invoking AI provider for test execution")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="test_execution_operation"
            )
            async def invoke_test_execution():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=enhanced_prompt,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable bash tool for test execution
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_test_execution()

            logger.info(f"Test execution completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file to _claude/ directory
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="test-execution-result.json"
            )
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")


            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Test execution failed"
                logger.error(f"Test execution operation failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Test execution operation completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message=f"Test execution completed successfully with Java {request.java_version}"
            )

        except Exception as e:
            error_msg = f"Test execution operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def _verify_java_version_installed(self, sdkman_version: str):
        """
        Verify that the requested Java version is installed via SDKMAN.

        Args:
            sdkman_version: SDKMAN version string (e.g., "17.0.13-tem")

        Raises:
            ValidationError: If Java version is not installed
        """
        java_home = Path.home() / ".sdkman" / "candidates" / "java" / sdkman_version

        if not java_home.exists():
            raise ValidationError(
                message=f"Java version {sdkman_version} is not installed via SDKMAN. "
                       f"Please install it using: sdk install java {sdkman_version}",
                field="javaVersion"
            )

        logger.info(f"Java version verified: {sdkman_version} at {java_home}")

    def _enhance_prompt_with_test_context(
        self,
        prompt: str,
        java_version: str,
        sdkman_version: str
    ) -> str:
        """
        Enhance prompt with Java version and test execution context.

        Args:
            prompt: Original prompt content
            java_version: Requested Java version (e.g., "17")
            sdkman_version: SDKMAN version string (e.g., "17.0.13-tem")

        Returns:
            Enhanced prompt with test execution instructions
        """
        test_context = f"""IMPORTANT: Test Execution Setup

Before running tests, you MUST configure the Java environment:

1. Source SDKMAN:
   source ~/.sdkman/bin/sdkman-init.sh

2. Switch to Java {java_version}:
   sdk use java {sdkman_version}

3. Verify Java version:
   java -version

4. Execute tests:
   For Maven: mvn test
   For Gradle: gradle test

5. Analyze test failures and provide recommendations

This ensures tests run with Java {java_version} as requested.

Focus on:
- Test failures and their root causes
- Flaky tests
- Performance issues
- Code coverage gaps
- Test infrastructure problems

---

"""
        return test_context + prompt

    def _create_validation_directories(self, request: ClaudeCliRequest):
        """
        Create validation directory structure for test execution.

        Creates:
        - validation/{analysisId}/
        - validation/{analysisId}/test-reports/
        - validation/{analysisId}/_claude/
        - validation/{analysisId}/coverage/

        Args:
            request: Claude CLI request
        """
        base_dir = Path(settings.workspace.base_path) / "validation" / request.analysis_id

        # Create subdirectories
        subdirs = ["test-reports", "_claude", "coverage"]
        for subdir in subdirs:
            dir_path = base_dir / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {dir_path}")

        logger.info(f"Test execution directories created: {base_dir}")

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for test execution.

        Overrides base handler to use 'validation' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "validation"
