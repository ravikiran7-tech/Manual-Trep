"""
.NET Test Handler - .NET test execution operation.

Executes .NET tests with specific framework versions.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class DotnetTestHandler(BaseOperationHandler):
    """
    Handler for 'dotnet-test-execution' operation.

    Executes .NET tests with specific framework versions:
    - xUnit, NUnit, MSTest support
    - dotnet test execution
    - Test failure extraction
    - Code coverage reporting
    - Parallel test execution

    Timeout: 1800s (30 minutes)
    Output: validation/{analysisId}/dotnet-test-execution-stream.json
    """

    # Supported .NET versions
    SUPPORTED_DOTNET_VERSIONS = ["6.0", "7.0", "8.0", "10.0"]

    def get_timeout(self) -> int:
        """
        Get timeout for .NET test operation.

        Returns:
            Timeout in seconds (1800s = 30 minutes)
        """
        return settings.timeouts.build_validation

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate .NET test request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # .NET test requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for dotnet-test-execution operation",
                field="prompt"
            )

        # Validate .NET version if provided
        if request.dotnet_version:
            if request.dotnet_version not in self.SUPPORTED_DOTNET_VERSIONS:
                raise ValidationError(
                    message=f"Unsupported .NET version: {request.dotnet_version}. "
                           f"Supported versions: {self.SUPPORTED_DOTNET_VERSIONS}",
                    field="dotnetVersion"
                )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute .NET test operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with test results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        dotnet_version = request.dotnet_version or "8.0"  # Default to .NET 8.0

        logger.info(
            f"Starting .NET test execution: analysisId={request.analysis_id}, "
            f"dotnetVersion={dotnet_version}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Enhance prompt with .NET test context
            enhanced_prompt = self._enhance_prompt_with_test_context(
                prompt_content,
                dotnet_version
            )

            # Build output path
            output_path = self.build_output_path(
                request,
                "test-execution-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Create validation directory structure
            self._create_validation_directories(request)

            # Execute with provider
            logger.info("Invoking AI provider for .NET test execution")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="dotnet_test_operation"
            )
            async def invoke_dotnet_test():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=enhanced_prompt,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable bash tool for test execution
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_dotnet_test()

            logger.info(f".NET test execution completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file to _claude/ directory
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="test-execution-result.json"
            )
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           ".NET test execution failed"
                logger.error(f".NET test execution failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info(".NET test execution completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message=f".NET test execution completed successfully with .NET {dotnet_version}"
            )

        except Exception as e:
            error_msg = f".NET test execution failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def _enhance_prompt_with_test_context(
        self,
        prompt: str,
        dotnet_version: str
    ) -> str:
        """
        Enhance prompt with .NET test execution context.

        Args:
            prompt: Original prompt content
            dotnet_version: Requested .NET version (e.g., "8.0")

        Returns:
            Enhanced prompt with test execution instructions
        """
        test_context = f"""IMPORTANT: .NET Test Execution Setup

Target .NET version: {dotnet_version}

Execute tests and analyze results:

1. Verify .NET SDK:
   dotnet --version

2. Restore packages:
   dotnet restore

3. Run tests:
   dotnet test --configuration Release

4. Run tests with coverage:
   dotnet test --collect:"XPlat Code Coverage"

5. Generate test report:
   dotnet test --logger "trx;LogFileName=test-results.trx"

Focus on:
- Test failures and their root causes
- Flaky tests
- Code coverage gaps
- Performance bottlenecks
- Test framework compatibility
- Assertion failures
- Integration test issues

---

"""
        return test_context + prompt

    def _create_validation_directories(self, request: ClaudeCliRequest):
        """
        Create validation directory structure for .NET tests.

        Creates:
        - validation/{analysisId}/
        - validation/{analysisId}/test-results/
        - validation/{analysisId}/_claude/
        - validation/{analysisId}/coverage/

        Args:
            request: Claude CLI request
        """
        base_dir = Path(settings.workspace.base_path) / "validation" / request.analysis_id

        # Create subdirectories
        subdirs = ["test-results", "_claude", "coverage"]
        for subdir in subdirs:
            dir_path = base_dir / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {dir_path}")

        logger.info(f".NET test directories created: {base_dir}")

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for .NET test execution.

        Overrides base handler to use 'validation' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "validation"
