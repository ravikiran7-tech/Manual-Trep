"""
Test Creation Handler - Generate unit tests for application code.

Analyzes existing application code and generates comprehensive unit tests
using appropriate testing frameworks for the project language/platform.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience


logger = logging.getLogger(__name__)
settings = get_settings()


class TestCreationHandler(BaseOperationHandler):
    """
    Handler for 'test-creation' operation.

    Analyzes application code and generates comprehensive unit tests:
    - Identifies testable components (classes, methods, functions)
    - Generates unit tests using appropriate testing framework
    - Creates test files with proper structure and naming conventions
    - Includes test cases for edge cases, error handling, and happy paths
    - Generates mocks/stubs for dependencies

    Supported Frameworks:
    - Java: JUnit 5, Mockito
    - .NET: xUnit, NUnit, MSTest, Moq
    - Python: pytest, unittest, mock
    
    The AI generates tests as complete file content in JSON format.
    Files are created by the calling service (Java) in the appropriate test directories.

    Timeout: 3600s (extended - test generation can be comprehensive)
    Output: testing/{analysisId}/test-creation-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for test-creation operation.

        Returns:
            Timeout in seconds (3600s = 1 hour for comprehensive test generation)
        """
        return settings.timeouts.upgrade_operations  # 3600s

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate test-creation request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Test-creation requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for test-creation operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute test creation operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with generated test files

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(f"Starting test-creation operation: analysisId={request.analysis_id}")
        logger.info(f"Extended timeout configured: {self.get_timeout()}s")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Detect project type for appropriate test framework selection
            project_type = self._detect_project_type(request)
            logger.info(f"Detected project type: {project_type}")
            
            # Enhance prompt with test framework guidance
            enhanced_prompt = self._enhance_prompt_with_framework_guidance(
                prompt_content,
                project_type,
                request
            )

            # Build output path
            output_path = self.build_output_path(request, "test-creation-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using extended timeout
            logger.info("Invoking AI provider for test generation")
            logger.info("AI will analyze code and generate comprehensive unit tests")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 3600s extended timeout
                operation_name="test_creation_operation"
            )
            async def invoke_test_creation():
                # Use helper method that chooses graph orchestration or max_iterations
                # Enable code_editor for reading source code and generating tests
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=enhanced_prompt,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor for project analysis
                    stream_output_path=output_path
                )
                return events

            # Execute invocation
            stream_events = await invoke_test_creation()

            logger.info(f"Test creation completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file to _claude/ directory
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="test-creation-result.json"
            )
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Test creation failed"
                logger.error(f"Test creation operation failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Test creation operation completed successfully")
            logger.info("Generated tests are available in JSON response")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Test creation completed successfully"
            )

        except Exception as e:
            error_msg = f"Test creation operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def _detect_project_type(self, request: ClaudeCliRequest) -> str:
        """
        Detect project type from request or project structure.
        
        Priority order:
        1. Explicit project_type field from payload (projectType)
        2. Infer from dotnet_version or java_version fields
        3. Auto-detect from project structure (.csproj, pom.xml, etc.)
        4. Default to "java" for backward compatibility
        
        Args:
            request: Claude CLI request
            
        Returns:
            Project type: "dotnet", "java", or "python"
        """
        # 1. Check if project_type is explicitly provided in payload
        if request.project_type:
            logger.info(f"Using explicit projectType from payload: {request.project_type}")
            return request.project_type.lower()
        
        # 2. Check if dotnet_version is specified
        if request.dotnet_version:
            logger.info("Inferred project type 'dotnet' from dotnetVersion field")
            return "dotnet"
        
        # 3. Check if java_version is specified
        if request.java_version:
            logger.info("Inferred project type 'java' from javaVersion field")
            return "java"
        
        # 4. Detect from project structure
        project_path = Path(request.project_path)
        
        # Check for .NET project files
        if list(project_path.rglob("*.csproj")) or list(project_path.rglob("*.sln")):
            logger.info("Auto-detected project type 'dotnet' from project files")
            return "dotnet"
        
        # Check for Java project files
        if (project_path / "pom.xml").exists() or (project_path / "build.gradle").exists():
            logger.info("Auto-detected project type 'java' from project files")
            return "java"
        
        # Check for Python project files
        if (project_path / "setup.py").exists() or (project_path / "pyproject.toml").exists() or list(project_path.rglob("requirements*.txt")):
            logger.info("Auto-detected project type 'python' from project files")
            return "python"
        
        # 5. Default to java for backward compatibility
        logger.warning(
            f"Could not detect project type for {request.project_path}, "
            "defaulting to 'java'"
        )
        return "java"

    def _enhance_prompt_with_framework_guidance(
        self,
        prompt: str,
        project_type: str,
        request: ClaudeCliRequest
    ) -> str:
        """
        Enhance the prompt with project-specific test framework guidance.
        
        Args:
            prompt: Original prompt content
            project_type: Detected project type
            request: Original request
            
        Returns:
            Enhanced prompt with framework-specific guidance
        """
        framework_guidance = self._get_framework_guidance(project_type, request)
        
        enhanced = f"""
{prompt}

---

# Test Framework Guidance for {project_type.upper()}

{framework_guidance}

## General Test Generation Guidelines

1. **Test Coverage**: Generate comprehensive tests covering:
   - Happy path scenarios
   - Edge cases and boundary conditions
   - Error handling and exception cases
   - Null/empty input handling
   - Integration points with dependencies

2. **Test Structure**: Follow best practices:
   - Use descriptive test names (e.g., `test_should_return_user_when_valid_id_provided()`)
   - Arrange-Act-Assert (AAA) pattern
   - One assertion per test (when possible)
   - Proper setup/teardown methods

3. **Mocking**: Use appropriate mocking strategies:
   - Mock external dependencies (databases, APIs, file systems)
   - Avoid mocking the unit under test
   - Use realistic test data

4. **Test Organization**:
   - Mirror source directory structure in test directory
   - Group related tests in test classes/modules
   - Use proper test file naming conventions

5. **Output Format**: Return tests as JSON with complete file content:
   ```json
   {{
     "tests": [
       {{
         "filePath": "tests/unit/UserServiceTest.java",
         "content": "complete test file content...",
         "description": "Tests for UserService class"
       }}
     ]
   }}
   ```

**Begin analyzing the codebase and generating comprehensive unit tests now.**
"""
        return enhanced

    def _get_framework_guidance(self, project_type: str, request: ClaudeCliRequest) -> str:
        """
        Get project-specific test framework guidance.
        
        Args:
            project_type: Detected project type
            request: Original request
            
        Returns:
            Framework-specific guidance text
        """
        if project_type == "dotnet":
            version = request.dotnet_version or "8.0"
            return f"""
**Target Framework**: .NET {version}

**Recommended Testing Stack**:
- **Test Framework**: xUnit (preferred) or NUnit or MSTest
- **Mocking**: Moq or NSubstitute
- **Assertions**: FluentAssertions (optional but recommended)

**Test File Structure**:
```csharp
using Xunit;
using Moq;
using FluentAssertions;

namespace MyProject.Tests.Unit
{{
    public class UserServiceTests
    {{
        [Fact]
        public void GetUser_WithValidId_ReturnsUser()
        {{
            // Arrange
            var mockRepo = new Mock<IUserRepository>();
            // ... setup

            // Act
            var result = service.GetUser(userId);

            // Assert
            result.Should().NotBeNull();
        }}
    }}
}}
```

**Test Directory**: Tests should be placed in:
- `test/` or `tests/` directory at project root
- Or `ProjectName.Tests/` parallel to source project
- Mirror namespace structure: `MyApp.Services` → `MyApp.Tests.Unit.Services`

**Naming Conventions**:
- Test files: `[ClassName]Tests.cs`
- Test methods: `[MethodName]_[Scenario]_[ExpectedResult]`
"""
        
        elif project_type == "java":
            version = request.java_version or "17"
            return f"""
**Target Version**: Java {version}

**Recommended Testing Stack**:
- **Test Framework**: JUnit 5 (Jupiter)
- **Mocking**: Mockito
- **Assertions**: AssertJ (optional but recommended)

**Test File Structure**:
```java
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class UserServiceTest {{
    
    @Mock
    private UserRepository userRepository;
    
    @InjectMocks
    private UserService userService;
    
    @Test
    void getUserById_withValidId_returnsUser() {{
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        
        // Act
        User result = userService.getUserById(1L);
        
        // Assert
        assertThat(result).isNotNull();
    }}
}}
```

**Test Directory**: Tests should be placed in:
- Maven: `src/test/java/` (mirroring `src/main/java/` structure)
- Gradle: `src/test/java/` (mirroring `src/main/java/` structure)

**Naming Conventions**:
- Test files: `[ClassName]Test.java`
- Test methods: `methodName_scenario_expectedResult`
"""
        
        elif project_type == "python":
            return """
**Recommended Testing Stack**:
- **Test Framework**: pytest (preferred) or unittest
- **Mocking**: unittest.mock or pytest-mock
- **Coverage**: pytest-cov

**Test File Structure**:
```python
import pytest
from unittest.mock import Mock, patch

class TestUserService:
    
    def test_get_user_with_valid_id_returns_user(self):
        # Arrange
        mock_repo = Mock()
        service = UserService(mock_repo)
        
        # Act
        result = service.get_user(user_id=1)
        
        # Assert
        assert result is not None
        mock_repo.find_by_id.assert_called_once_with(1)
```

**Test Directory**: Tests should be placed in:
- `tests/` directory at project root
- Or `test/` directory at project root
- Mirror module structure: `app/services/` → `tests/unit/services/`

**Naming Conventions**:
- Test files: `test_[module_name].py`
- Test classes: `Test[ClassName]`
- Test methods: `test_[method_name]_[scenario]_[expected_result]`
"""
        
        else:
            return """
**General Testing Guidance**:
- Use the project's existing test framework if detected
- Follow the project's existing test structure and patterns
- Generate idiomatic tests for the detected language
"""
