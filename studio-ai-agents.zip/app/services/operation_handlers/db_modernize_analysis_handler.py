"""
Database Modernize Analysis Handler - Database code analysis operation.

Analyzes database access patterns and identifies modernization opportunities.
"""
import logging

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class DbModernizeAnalysisHandler(BaseOperationHandler):
    """
    Handler for 'db-code-modernize-analysis' operation.

    Analyzes database code for modernization opportunities:
    - JDBC to JPA/Hibernate migration assessment
    - SQL injection vulnerabilities
    - Connection pooling issues
    - Transaction management patterns
    - N+1 query problems
    - Missing indexes
    - Inefficient queries
    - Database-specific features
    - ORM best practices violations

    Timeout: 3000s (default)
    Output: db-code-modernize/{analysisId}/db-code-modernize-analysis-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for database modernize analysis operation.

        Returns:
            Timeout in seconds (default: 3000)
        """
        return settings.timeouts.default

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate database modernize analysis request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Database modernize analysis requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for db-code-modernize-analysis operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute database modernize analysis operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with database analysis results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting database modernize analysis: analysisId={request.analysis_id}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(
                request,
                "db-code-modernize-analysis-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider
            logger.info("Invoking AI provider for database modernize analysis")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="db_modernize_analysis_operation"
            )
            async def invoke_db_modernize_analysis():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_db_modernize_analysis()

            logger.info(
                f"Database modernize analysis completed: {len(stream_events)} events received"
            )

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Database modernize analysis failed"
                logger.error(f"Database modernize analysis failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Database modernize analysis completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Database modernize analysis completed successfully"
            )

        except Exception as e:
            error_msg = f"Database modernize analysis failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for database modernize analysis.

        Overrides base handler to use 'db-code-modernize' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "db-code-modernize"
