"""
Cloud Readiness Analysis Handler - Cloud migration assessment operation.

Analyzes applications for cloud readiness and identifies migration blockers.
"""
import logging

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class CloudReadinessAnalysisHandler(BaseOperationHandler):
    """
    Handler for 'cloudreadiness-analysis' operation.

    Analyzes applications for cloud migration readiness:
    - 12-factor app compliance assessment
    - Stateful vs stateless components
    - Configuration externalization
    - Database connection patterns
    - File system dependencies
    - Environment-specific code
    - Containerization readiness
    - Microservices decomposition opportunities

    Timeout: 3000s (default)
    Output: cloudreadiness/{analysisId}/cloudreadiness-analysis-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for cloud readiness analysis operation.

        Returns:
            Timeout in seconds (default: 3000)
        """
        return settings.timeouts.default

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate cloud readiness analysis request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Cloud readiness analysis requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for cloudreadiness-analysis operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute cloud readiness analysis operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with cloud readiness assessment

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting cloud readiness analysis: analysisId={request.analysis_id}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(
                request,
                "cloudreadiness-analysis-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider
            logger.info("Invoking AI provider for cloud readiness analysis")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="cloudreadiness_analysis_operation"
            )
            async def invoke_cloudreadiness_analysis():
                # Use direct single-agent execution (bypass graph orchestrator)
                # Cloud readiness analysis doesn't need multi-module orchestration
                logger.info("Using direct single-agent execution (bypassing graph orchestrator)")
                events = await provider.invoke_with_tools_agentic(
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    #temperature=0.2,
                    enable_tools=True
                )
                return events

            # Execute invocation
            stream_events = await invoke_cloudreadiness_analysis()

            logger.info(
                f"Cloud readiness analysis completed: {len(stream_events)} events received"
            )

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="cloudreadiness-analysis-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Cloud readiness analysis failed"
                logger.error(f"Cloud readiness analysis failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Cloud readiness analysis completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Cloud readiness analysis completed successfully"
            )

        except Exception as e:
            error_msg = f"Cloud readiness analysis failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for cloud readiness analysis.

        Overrides base handler to use 'cloudreadiness' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "cloudreadiness"
