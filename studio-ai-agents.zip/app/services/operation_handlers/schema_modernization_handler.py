"""
Schema Modernization Handler - Database schema conversion.

Converts database schemas from one type to another (e.g., Oracle → PostgreSQL).
Supports two modes: file-access and content-in-prompt.
"""
import json
import logging
import re
from pathlib import Path
from typing import Optional

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import SchemaModernizationRequest
from app.models.responses import SchemaModernizationResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError, FileOperationError
from app.utils.stream_utils import StreamParser


logger = logging.getLogger(__name__)
settings = get_settings()

_SQL_OUTPUT_NAME = "schema-modernization-sql.sql"


def _extract_sql_from_bash_heredoc(command: str) -> Optional[str]:
    """
    Extract DDL from a bash `cat > ... schema-modernization-sql.sql << DELIM` heredoc.

    The model writes real SQL via bash; assistant chat may only contain summaries/JSON,
    so stream extraction must use the tool_use command body, not assistant text.

    If the command contains multiple such heredocs, the last non-empty body wins
    (same semantics as repeated `cat >` overwriting the file).
    """
    if _SQL_OUTPUT_NAME not in command:
        return None
    opener = re.compile(
        rf"{re.escape(_SQL_OUTPUT_NAME)}\s*['\"]?\s*<<\s*['\"]?(\w+)['\"]?\s*(?:\r?\n)",
        re.IGNORECASE | re.DOTALL,
    )
    last_body: Optional[str] = None
    for match in opener.finditer(command):
        delimiter = match.group(1)
        start = match.end()
        closing = re.compile(rf"\r?\n{re.escape(delimiter)}\s*(?:\r?\n|$)")
        end_m = closing.search(command, start)
        if not end_m:
            continue
        body = command[start : end_m.start()].strip()
        if body:
            last_body = body
    return last_body


class SchemaModernizationHandler(BaseOperationHandler):
    """
    Handler for 'schema-modernization' operation.

    Converts database schemas between different database types using AI.

    Two execution modes:
    1. File-access mode: AI reads schema file directly
       - sourceSchemaPath provided
       - AI uses code_editor tool to read file
       - Minimal prompt

    2. Content-in-prompt mode: Schema content in prompt
       - prompt contains full schema
       - No file access needed
       - Useful for small schemas

    Timeout: 3000s (default)
    Output: schema-modernization/{analysisId}/schema-modernization-output.sql
    """

    def get_timeout(self) -> int:
        """
        Get timeout for schema modernization operation.

        Returns:
            Timeout in seconds (default: 3000)
        """
        return settings.timeouts.schema_modernization

    def validate_request(self, request: SchemaModernizationRequest):
        """
        Validate schema modernization request.

        Args:
            request: Schema modernization request

        Raises:
            ValidationError: If validation fails
        """
        # Validate analysis ID
        if not request.analysis_id:
            raise ValidationError(
                message="Analysis ID is required",
                field="analysisId"
            )

        from app.core.security import SecurityValidator
        SecurityValidator.validate_alphanumeric(request.analysis_id, "analysisId")

        # Validate database types
        if not request.source_db_type:
            raise ValidationError(
                message="Source database type is required",
                field="sourceDbType"
            )

        if not request.target_db_type:
            raise ValidationError(
                message="Target database type is required",
                field="targetDbType"
            )

        # Must have either sourceSchemaPath or prompt (content-in-prompt mode)
        if not request.source_schema_path and not request.prompt:
            raise ValidationError(
                message="Either sourceSchemaPath or prompt must be provided",
                field="sourceSchemaPath"
            )

        # If sourceSchemaPath provided, validate it
        if request.source_schema_path:
            from app.core.security import SecurityValidator
            SecurityValidator.validate_path(request.source_schema_path, "sourceSchemaPath")

    async def execute(
        self,
        request: SchemaModernizationRequest
    ) -> SchemaModernizationResponse:
        """
        Execute schema modernization operation.

        Args:
            request: Schema modernization request

        Returns:
            Schema modernization response with SQL content

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting schema modernization: {request.source_db_type} → "
            f"{request.target_db_type}, analysisId={request.analysis_id}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Determine execution mode and build prompt
            if request.source_schema_path:
                # File-access mode
                mode = "file-access"
                prompt_content = self._build_file_access_prompt(request)
                project_path = request.project_path or str(
                    Path(request.source_schema_path).parent
                )
            else:
                # Content-in-prompt mode
                mode = "content-in-prompt"
                prompt_content = request.prompt
                if not request.project_path:
                    raise ValidationError(
                        message="projectPath is required for schema modernization in content-in-prompt mode",
                        field="projectPath",
                    )
                project_path = request.project_path

            logger.info(f"Execution mode: {mode}")

            # Build output path
            output_base = Path(settings.workspace.base_path) / "schema-modernization"
            output_dir = output_base / request.analysis_id
            output_dir.mkdir(parents=True, exist_ok=True)

            stream_file = output_dir / "_claude" / "schema-modernization-stream.json"
            sql_output_file = output_dir / "_claude" / "schema-modernization-sql.sql"
            migration_notes_file = output_dir / "_claude" / "migration-notes.md"
            migration_report_file = output_dir / "_claude" / "Migration_Change_Report.json"

            logger.info(f"Stream output: {stream_file}")
            logger.info(f"SQL output: {sql_output_file}")

            # Execute with provider
            logger.info("Invoking AI provider for schema modernization")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="schema_modernization_operation"
            )
            async def invoke_schema_modernization():
                # Always use agentic tools directly — bypass graph orchestration flag
                events = await provider.invoke_with_tools_agentic(
                    prompt=prompt_content,
                    project_path=project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True  # Always enable tools so AI can write files using bash
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_schema_modernization()

            logger.info(
                f"Schema modernization completed: {len(stream_events)} events received"
            )

            # Write stream output
            await self.write_stream_output(stream_file, stream_events)

            # Extract SQL: prefer on-disk file (bash wrote it), then bash heredoc in stream
            sql_content = self._extract_sql_from_stream(
                stream_events, sql_output_file=sql_output_file
            )

            if not sql_content:
                logger.error("No SQL content found in AI response")
                return SchemaModernizationResponse(
                    status="error",
                    message="No SQL content found in AI response",
                    analysis_id=request.analysis_id,
                    output_file_path=str(stream_file)
                )

            # Write SQL output file
            self._write_sql_output(sql_output_file, sql_content)

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Schema modernization failed"
                logger.error(f"Schema modernization failed: {error_msg}")

                return SchemaModernizationResponse(
                    status="error",
                    message=error_msg,
                    analysis_id=request.analysis_id,
                    output_file_path=str(stream_file),
                    error_details=error_msg
                )

            # Check if AI wrote all required files
            if migration_notes_file.exists():
                logger.info(f"Migration notes created: {migration_notes_file}")
            else:
                logger.warning(f"Migration notes not created by AI: {migration_notes_file}")

            if migration_report_file.exists():
                logger.info(f"Migration change report created: {migration_report_file}")
                await self._validate_and_fix_migration_report(
                    provider=provider,
                    migration_report_file=migration_report_file,
                    project_path=project_path,
                    analysis_id=request.analysis_id,
                )
            else:
                logger.warning(f"Migration change report not created by AI: {migration_report_file}")

            # Build success response
            logger.info("Schema modernization completed successfully")

            return SchemaModernizationResponse(
                status="success",
                message=f"Schema converted from {request.source_db_type} to "
                       f"{request.target_db_type}",
                analysis_id=request.analysis_id,
                content=sql_content,
                output_file_path=str(sql_output_file)
            )

        except Exception as e:
            error_msg = f"Schema modernization failed: {str(e)}"
            logger.error(error_msg, exc_info=True)

            return SchemaModernizationResponse(
                status="error",
                message=error_msg,
                analysis_id=request.analysis_id,
                error_details=str(e)
            )

    def _build_file_access_prompt(
        self,
        request: SchemaModernizationRequest
    ) -> str:
        """
        Build prompt for file-access mode.

        Note: this prompt is authoritative for the Migration_Change_Report.json shape —
        it embeds the required schema directly rather than relying on the caller's
        ``request.prompt`` (which is NOT used in file-access mode by default, since
        Java always sets sourceSchemaPath for this operation). Any ``request.prompt``
        content the caller does supply is appended as additional context/rules.

        Args:
            request: Schema modernization request

        Returns:
            Prompt content
        """
        source_file = Path(request.source_schema_path).name

        # Build absolute file paths for the AI to use (matching handler's expected paths)
        output_base = Path(settings.workspace.base_path) / "schema-modernization"
        output_dir = output_base / request.analysis_id / "_claude"

        sql_file = str(output_dir / "schema-modernization-sql.sql")
        notes_file = str(output_dir / "migration-notes.md")
        json_file = str(output_dir / "Migration_Change_Report.json")

        schema_block = self._migration_report_schema(
            request.source_db_type, request.target_db_type
        )

        extra_context = ""
        if request.prompt:
            extra_context = (
                "\n## Additional Migration Rules and Context\n\n"
                "The following rules/context were supplied for this migration and MUST "
                "be followed in addition to the instructions above (this does NOT change "
                "the required JSON schema for the change report below):\n\n"
                f"{request.prompt}\n"
            )

        prompt = f"""CRITICAL INSTRUCTIONS - READ FIRST:
You MUST write THREE files using bash commands. DO NOT return content in code blocks in your response.

Read the file '{source_file}' and convert the database schema from {request.source_db_type} to {request.target_db_type}.

MANDATORY: Use bash commands to write these THREE files:

1. PostgreSQL DDL file:
cat > '{sql_file}' << 'EOFSQL'
[Complete PostgreSQL DDL here]
EOFSQL

2. Migration notes file:
cat > '{notes_file}' << 'EOFMD'
[Migration notes in markdown format here]
EOFMD

3. Migration change report JSON file — REQUIRED SCHEMA (follow EXACTLY; do not invent a different shape):

{schema_block}

Now write the file following that schema exactly:
cat > '{json_file}' << 'EOFJSON'
[JSON content following the REQUIRED SCHEMA above exactly]
EOFJSON

IMPORTANT:
- You MUST use the bash commands above to write files
- DO NOT return SQL/JSON/Markdown in code blocks in your response
- Convert data types appropriately
- Adjust syntax for target database
- Preserve table relationships and constraints
- Document all changes in the JSON report using the REQUIRED SCHEMA above — the root key MUST be `migrationReport` (camelCase)
- Add comments in SQL for any manual review needed
{extra_context}
After writing all three files, confirm which files you created.
"""

        return prompt

    @staticmethod
    def _migration_report_schema(source_db_type: str, target_db_type: str) -> str:
        """
        Canonical JSON schema for Migration_Change_Report.json.

        Must stay aligned with the Java-side reader's preferred shape:
        - `migrationReport` / `summary.totalObjects` / `*Converted` counts are read by
          MigrationChangeReportTotals.resolveNestedMigrationReport and the TABLE_KEYS/
          VIEW_KEYS/... aliases in PostTransformationReportServiceImpl (required).
        - `tables`/`views`/`storedProcedures`/`triggers`/`constraints` detail arrays (with
          `original_name`/`new_name`/`columns`/`indexes`) are read by that same class's
          legacyTableSample/legacyViewSample/legacyIndexSample/legacyConstraintsSample to
          populate schemaComparison[].sampleTransformation before/after snippets
          (recommended — omitting them just means samples are blank, counts still work).
        """
        return f"""{{
  "migrationReport": {{
    "metadata": {{
      "sourceDatabase": "{source_db_type}",
      "targetDatabase": "{target_db_type}",
      "migrationDate": "YYYY-MM-DD"
    }},
    "summary": {{
      "totalObjects": <integer>,
      "tablesConverted": <integer>,
      "viewsConverted": <integer>,
      "storedProceduresConverted": <integer>,
      "functionsConverted": <integer>,
      "indexesConverted": <integer>,
      "triggersConverted": <integer>,
      "constraintsConverted": <integer>,
      "sequencesCreated": <integer>
    }},
    "dataTypeConversions": [
      {{"table": "...", "column": "...", "from": "...", "to": "..."}}
    ],
    "tables": [
      {{
        "original_name": "SourceTableName",
        "new_name": "target_table_name",
        "columns": [
          {{"original_name": "ColName", "new_name": "col_name", "original_type": "NVARCHAR(50)", "new_type": "VARCHAR(50)"}}
        ],
        "indexes": [
          {{"original_name": "IX_Source", "new_name": "ix_target"}}
        ]
      }}
    ],
    "views": [
      {{"original_name": "SourceViewName", "new_name": "target_view_name"}}
    ],
    "storedProcedures": [
      {{"original_name": "uspSourceProc", "new_name": "target_proc", "object_type": "function|refcursor"}}
    ],
    "triggers": [
      {{"original_name": "SourceTrigger", "new_name": "target_trigger"}}
    ],
    "constraints": [
      {{"type": "PRIMARY KEY|FOREIGN KEY|CHECK|UNIQUE", "status": "converted"}}
    ],
    "unsupported_constructs": [
      {{"construct": "...", "location": "...", "reason": "...", "recommendation": "..."}}
    ],
    "extensions_required": [
      {{"extension": "...", "reason": "..."}}
    ]
  }}
}}

RULES FOR THIS FILE:
- The root object key MUST be exactly "migrationReport" (camelCase) — never "migration_report", "migration_change_report", "Migration_Report", or a flat "migration_summary" at the root.
- "summary.totalObjects" is REQUIRED and MUST be an integer (use the sum of the *Converted/*Created counts below it if unsure).
- Use 0 for any category with no objects migrated — never omit a category key.
- Include at least the FIRST object of each of "tables"/"views"/"storedProcedures"/"triggers"/"constraints" you converted (used to show a before/after sample) — do not omit these arrays even if brief; use [] only when that category truly has zero objects.
- Put ALL detail sections inside "migrationReport" — do not add sibling root keys.""".strip()

    @staticmethod
    def _validate_migration_report(path: Path) -> Optional[str]:
        """
        Validate Migration_Change_Report.json against the required schema.

        Returns:
            None if the file matches the required shape, otherwise a short
            human-readable description of the problem (used to build a
            corrective follow-up prompt).
        """
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            return f"file is not valid JSON: {e}"

        if not isinstance(data, dict):
            return "root of the JSON is not an object"

        migration_report = data.get("migrationReport")
        if not isinstance(migration_report, dict):
            return (
                "root object is missing the required 'migrationReport' key "
                f"(found top-level keys: {list(data.keys())})"
            )

        summary = migration_report.get("summary")
        if not isinstance(summary, dict) or "totalObjects" not in summary:
            return "migrationReport.summary.totalObjects is missing"

        return None

    def _build_migration_report_fix_prompt(self, json_file: Path, validation_error: str) -> str:
        """Corrective follow-up prompt asking the model to rewrite only the change report file."""
        return f"""The file '{json_file}' you just wrote does not match the required schema: {validation_error}.

Rewrite ONLY this file — use a bash command:
cat > '{json_file}' << 'EOFJSON'
[corrected JSON here]
EOFJSON

so it matches this exact structure:

{self._migration_report_schema("<source database>", "<target database>")}

Keep the actual counts/values you already determined from the schema analysis; only fix the
structure/key names. Do NOT modify the SQL file or the migration notes file. After rewriting,
confirm the file was updated.
"""

    async def _validate_and_fix_migration_report(
        self,
        provider,
        migration_report_file: Path,
        project_path: str,
        analysis_id: str,
    ) -> None:
        """
        Validate Migration_Change_Report.json and, if it drifted from the required
        schema, ask the model for one corrective rewrite before giving up.

        Best-effort: failures here are logged but never fail the overall operation —
        the DDL/notes files are the primary deliverables.
        """
        validation_error = self._validate_migration_report(migration_report_file)
        if not validation_error:
            return

        logger.warning(
            f"Migration_Change_Report.json failed schema validation "
            f"(analysisId={analysis_id}): {validation_error}. Requesting one correction pass."
        )
        try:
            fix_prompt = self._build_migration_report_fix_prompt(
                migration_report_file, validation_error
            )
            await provider.invoke_with_tools_agentic(
                prompt=fix_prompt,
                project_path=project_path,
                max_tokens=settings.bedrock.max_tokens,
                temperature=settings.bedrock.temperature,
                enable_tools=True,
            )
        except Exception as e:
            logger.warning(
                f"Migration_Change_Report.json correction pass failed "
                f"(analysisId={analysis_id}): {e}"
            )
            return

        remaining_error = self._validate_migration_report(migration_report_file)
        if remaining_error:
            logger.warning(
                f"Migration_Change_Report.json still invalid after correction pass "
                f"(analysisId={analysis_id}): {remaining_error}. Continuing with best-effort report."
            )
        else:
            logger.info(
                f"Migration_Change_Report.json corrected successfully (analysisId={analysis_id})"
            )

    def _extract_sql_from_stream(
        self,
        stream_events: list,
        sql_output_file: Optional[Path] = None,
    ) -> Optional[str]:
        """
        Extract SQL content from stream events (and optionally the workspace file).

        Priority:
        1. Read ``sql_output_file`` if bash already wrote it (authoritative).
        2. Parse bash ``tool_use`` commands for ``cat ... << EOFSQL`` heredocs
           targeting schema-modernization-sql.sql (last match wins).
        3. First ```sql``` block in assistant text.
        4. Do not use full assistant text as SQL (often summary + JSON).

        Args:
            stream_events: List of stream events
            sql_output_file: Expected path for the DDL file under the workspace

        Returns:
            SQL content, or None if not found
        """
        if sql_output_file is not None and sql_output_file.exists():
            try:
                text = sql_output_file.read_text(encoding="utf-8")
                if text.strip():
                    logger.info(
                        "Using SQL from workspace file written by bash: %s",
                        sql_output_file,
                    )
                    return text.strip()
            except OSError as e:
                logger.warning("Could not read SQL output file %s: %s", sql_output_file, e)

        last_heredoc: Optional[str] = None
        for event in stream_events:
            if event.get("type") != "tool_use":
                continue
            tool = event.get("tool") or {}
            if tool.get("name") != "bash":
                continue
            inp = tool.get("input") or {}
            command = inp.get("command") or ""
            extracted = _extract_sql_from_bash_heredoc(command)
            if extracted:
                last_heredoc = extracted

        if last_heredoc:
            logger.info("Using SQL extracted from bash heredoc in stream (schema file)")
            return last_heredoc

        parser = StreamParser()
        response_text = parser.extract_full_assistant_response(stream_events)

        if not response_text:
            return None

        sql_pattern = r"```sql\s*(.*?)\s*```"
        matches = re.findall(sql_pattern, response_text, re.DOTALL | re.IGNORECASE)

        if matches:
            return matches[0].strip()

        logger.warning(
            "No SQL from file, bash heredoc, or ```sql``` block; assistant text is not used as DDL"
        )
        return None

    def _write_sql_output(self, output_file: Path, sql_content: str):
        """
        Write SQL content to output file.

        Args:
            output_file: Output file path
            sql_content: SQL content to write

        Raises:
            FileOperationError: If write fails
        """
        try:
            output_file.parent.mkdir(parents=True, exist_ok=True)

            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(sql_content)

            logger.info(f"SQL output written to: {output_file} ({len(sql_content)} chars)")

        except Exception as e:
            error_msg = f"Failed to write SQL output: {str(e)}"
            logger.error(error_msg)
            raise FileOperationError(
                message=error_msg,
                file_path=str(output_file),
                details=str(e)
            )

