"""
Generation Handler - Generate containerization artifacts (Dockerfile, K8s manifests, scripts).

Analyzes application and generates complete containerization artifacts as JSON response.
The AI generates JSON with complete file content embedded - does NOT write files directly.
Java calling service extracts files from JSON and writes them to project directory.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience


logger = logging.getLogger(__name__)
settings = get_settings()


class GenerationHandler(BaseOperationHandler):
    """
    Handler for 'generation' operation.

    Analyzes application and generates containerization artifacts as JSON:
    - Dockerfile (multi-stage build)
    - docker-compose.yml
    - .dockerignore
    - Kubernetes manifests (deployment, service, ingress, namespace)
    - Build and deployment scripts (.sh and .bat)

    CRITICAL: AI generates JSON with complete file content embedded.
    Files are NOT created in the project during this operation.
    JSON response includes complete file content for all artifacts.
    The calling service (Java ContainerizationService) reads the JSON and creates the actual files.

    Timeout: 3000s (default)
    Output: containerization/{analysisId}/generation-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for generation operation.

        Returns:
            Timeout in seconds (default: 3000)
        """
        return settings.timeouts.default

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate generation request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Generation requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for generation operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute artifact generation operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with artifact generation results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(f"Starting containerization artifact generation: analysisId={request.analysis_id}")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(request, "generation-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using resilience patterns
            logger.info("Invoking AI provider for artifact generation")
            logger.info("AI will analyze project and return JSON with complete file content embedded")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="generation_operation"
            )
            async def invoke_generation():
                # Use helper method that chooses graph orchestration or max_iterations
                # Enable code_editor for project analysis (read-only)
                # AI returns JSON with complete file content - does NOT write files
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor for project analysis
                    stream_output_path=output_path
                )
                return events

            # Execute invocation
            stream_events = await invoke_generation()

            logger.info(f"Artifact generation completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="generation-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Artifact generation failed"
                logger.error(f"Artifact generation operation failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Artifact generation operation completed successfully")
            logger.info("JSON response contains complete file content for all artifacts")
            logger.info("Java service will extract and create files in project directory")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Artifact generation completed successfully"
            )

        except Exception as e:
            error_msg = f"Artifact generation operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise
