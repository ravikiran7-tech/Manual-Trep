"""
Database Modernize Fix Handler - Apply database code fixes.

Applies code changes to modernize database access patterns and fix issues.
"""
import logging

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class DbModernizeFixHandler(BaseOperationHandler):
    """
    Handler for 'db-code-modernize-fix' operation.

    Applies database code modernization fixes:
    - JDBC to JPA/Hibernate migration
    - Fix SQL injection vulnerabilities
    - Implement connection pooling
    - Add proper transaction management
    - Fix N+1 query problems
    - Optimize queries
    - Add missing indexes recommendations
    - Convert to repository pattern
    - Implement prepared statements

    Timeout: 3600s (extended - 1 hour)
    Output: db-code-modernize/{analysisId}/db-code-modernize-fix-stream.json

    Note: Extended timeout as this involves complex code modifications.
    """

    def get_timeout(self) -> int:
        """
        Get timeout for database modernize fix operation.

        Returns:
            Timeout in seconds (3600s = 1 hour)
        """
        return settings.timeouts.upgrade_operations

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate database modernize fix request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Database modernize fix requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for db-code-modernize-fix operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute database modernize fix operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with fix results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting database modernize fix: analysisId={request.analysis_id}"
        )
        logger.info(f"Extended timeout configured: {self.get_timeout()}s")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(
                request,
                "db-code-modernize-fix-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using extended timeout
            logger.info("Invoking AI provider for database modernize fix with extended timeout")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 3600s extended timeout
                operation_name="db_modernize_fix_operation"
            )
            async def invoke_db_modernize_fix():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_db_modernize_fix()

            logger.info(
                f"Database modernize fix completed: {len(stream_events)} events received"
            )

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)
            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="db-code-modernize-fix-result.json"
            )

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Database modernize fix failed"
                logger.error(f"Database modernize fix failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Database modernize fix completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Database modernize fix completed successfully"
            )

        except Exception as e:
            error_msg = f"Database modernize fix failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for database modernize fix.

        Overrides base handler to use 'db-code-modernize' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "db-code-modernize"
