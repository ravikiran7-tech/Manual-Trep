"""
Fix Upgrade Handler - Apply version upgrade fixes.

Applies code fixes for version upgrades based on analysis results.
Includes automatic post-transformation compilation error fixing.
"""
import logging
import re
import subprocess
from pathlib import Path
from collections import defaultdict
from typing import Dict, List

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience


logger = logging.getLogger(__name__)
settings = get_settings()


class FixUpgradeHandler(BaseOperationHandler):
    """
    Handler for 'fix-upgrade' operation.

    Applies code fixes for version upgrades using AI to:
    - Update deprecated API calls
    - Refactor code for new patterns
    - Apply migration strategies
    - Fix breaking changes
    - Automatically fix compilation errors (up to 10 iterations)

    Timeout: 3600s (extended - 1 hour)
    Output: versionUpgrade/{analysisId}/fix-upgrade-stream.json

    Note: This operation has an extended timeout because it involves
    actual code modifications which can be time-consuming for large codebases.
    After transformation completes, automatically runs up to 10 iterations
    of build validation and error fixing.
    """

    MAX_FIX_ITERATIONS = 3   # Maximum iterations for post-transformation error fixing

    def get_timeout(self) -> int:
        """
        Get timeout for fix-upgrade operation.

        Returns:
            Timeout in seconds (3600s = 1 hour)
        """
        return settings.timeouts.upgrade_operations

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate fix-upgrade request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Fix-upgrade requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for fix-upgrade operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute fix-upgrade operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with fix results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(f"Starting fix-upgrade operation: analysisId={request.analysis_id}")
        logger.info(f"Extended timeout configured: {self.get_timeout()}s")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(request, "fix-upgrade-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using extended timeout
            logger.info("Invoking AI provider for fix-upgrade with extended timeout")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 3600s extended timeout
                operation_name="fix_upgrade_operation"
            )
            async def invoke_fix_upgrade():
                # Use helper method that chooses graph orchestration or max_iterations.
                # stream_output_path writes events to the file as they are produced (live).
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_fix_upgrade()

            logger.info(f"Fix-upgrade completed: {len(stream_events)} events received")

            # Check if transformation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Fix-upgrade failed"
                logger.error(f"Fix-upgrade operation failed: {error_msg}")
                await self.write_stream_output(output_path, stream_events)
                return self.build_error_response(error_msg, stream_events, output_path)

            # ========================================================================
            # AUTOMATIC POST-TRANSFORMATION ERROR FIXING (10 iterations max)
            # ========================================================================
            logger.info("Transformation complete. Starting automatic error fixing...")
            
            all_events = await self._run_post_transformation_fixes(
                request,
                provider,
                stream_events
            )
            
            # Write combined output (transformation + fixes)
            await self.write_stream_output(output_path, all_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=all_events,
                output_dir=output_path.parent,
                result_filename="fix-upgrade-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Build success response
            logger.info("Fix-upgrade with post-transformation fixes completed")
            return self.build_success_response(
                output_path,
                all_events,
                message="Fix-upgrade with automatic error fixing completed"
            )

        except Exception as e:
            error_msg = f"Fix-upgrade operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    async def _run_post_transformation_fixes(
        self,
        request: ClaudeCliRequest,
        provider,
        all_events: List[Dict]
    ) -> List[Dict]:
        """
        Automatically fix compilation errors after transformation.
        Runs up to 10 iterations of build → categorize → fix → verify.
        
        Args:
            request: Original request
            provider: AI provider instance
            all_events: Events from transformation phase
            
        Returns:
            Combined events (transformation + fixes)
        """
        logger.info("=" * 80)
        logger.info("POST-TRANSFORMATION: Starting automatic compilation error fixing")
        logger.info("=" * 80)
        
        # Detect project type
        project_type = self._detect_project_type(request)
        logger.info(f"Detected project type: {project_type}")
        
        for iteration in range(1, self.MAX_FIX_ITERATIONS + 1):
            logger.info(f"Fix iteration {iteration}/{self.MAX_FIX_ITERATIONS}")
            
            # Step 1: Run build and capture errors
            build_result = await self._run_build(
                request.project_path,
                project_type
            )
            
            if build_result["success"]:
                logger.info("✓ Build successful - all compilation errors resolved!")
                all_events.append({
                    "type": "build_success",
                    "iteration": iteration,
                    "message": "All compilation errors fixed"
                })
                break
            
            error_count = build_result["error_count"]
            logger.info(f"Build failed with {error_count} errors")
            
            # Step 2: Categorize errors
            error_categories = self._categorize_errors(
                build_result["errors"],
                project_type
            )
            
            logger.info(
                f"Categorized into {len(error_categories)} error types: "
                f"{list(error_categories.keys())}"
            )
            
            # Step 3: Generate fix prompt
            fix_prompt = self._generate_fix_prompt(
                error_categories,
                project_type,
                iteration,
                error_count
            )
            
            # Step 4: Apply fixes using AI
            try:
                @with_resilience(
                    retry_attempts=2,
                    timeout_seconds=1200,  # 20 min per iteration
                    operation_name=f"post_transform_fix_iter_{iteration}"
                )
                async def apply_fixes():
                    events = await self.invoke_with_provider(
                        provider=provider,
                        prompt=fix_prompt,
                        project_path=request.project_path,
                        max_tokens=settings.bedrock.max_tokens,
                        temperature=settings.bedrock.temperature,
                        enable_tools=True
                    )
                    return events
                
                iteration_events = await apply_fixes()
                all_events.extend(iteration_events)
                
                # Check if fixes were applied
                if not self.is_stream_successful(iteration_events):
                    logger.warning(f"Iteration {iteration} failed to apply fixes")
                    all_events.append({
                        "type": "fix_iteration_failed",
                        "iteration": iteration,
                        "message": "AI failed to apply fixes"
                    })
                    break
                
                all_events.append({
                    "type": "fix_iteration_complete",
                    "iteration": iteration,
                    "errors_found": error_count,
                    "categories": len(error_categories)
                })
                
            except Exception as e:
                logger.error(f"Fix iteration {iteration} error: {e}")
                all_events.append({
                    "type": "fix_iteration_error",
                    "iteration": iteration,
                    "error": str(e)
                })
                break
        
        # Final build summary
        final_build = await self._run_build(
            request.project_path,
            project_type
        )
        
        all_events.append({
            "type": "final_build_status",
            "success": final_build["success"],
            "remaining_errors": final_build["error_count"]
        })
        
        logger.info("=" * 80)
        status_msg = "SUCCESS" if final_build["success"] else f"{final_build['error_count']} errors remaining"
        logger.info(f"POST-TRANSFORMATION COMPLETE: {status_msg}")
        logger.info("=" * 80)
        
        return all_events

    def _detect_project_type(self, request: ClaudeCliRequest) -> str:
        """
        Detect project type from request or project structure.
        
        Priority order:
        1. Explicit project_type field from payload (projectType)
        2. Infer from dotnet_version or java_version fields
        3. Auto-detect from project structure (.csproj, pom.xml, etc.)
        4. Default to "java" for backward compatibility
        
        Args:
            request: Claude CLI request
            
        Returns:
            Project type: "dotnet" or "java"
        """
        # 1. Check if project_type is explicitly provided in payload
        if request.project_type:
            logger.info(f"Using explicit projectType from payload: {request.project_type}")
            return request.project_type.lower()
        
        # 2. Check if dotnet_version is specified
        if request.dotnet_version:
            logger.info("Inferred project type 'dotnet' from dotnetVersion field")
            return "dotnet"
        
        # 3. Check if java_version is specified
        if request.java_version:
            logger.info("Inferred project type 'java' from javaVersion field")
            return "java"
        
        # 4. Detect from project structure
        project_path = Path(request.project_path)
        
        # Check for .NET project files
        if list(project_path.rglob("*.csproj")) or list(project_path.rglob("*.sln")):
            logger.info("Auto-detected project type 'dotnet' from project files")
            return "dotnet"
        
        # Check for Java project files
        if (project_path / "pom.xml").exists() or (project_path / "build.gradle").exists():
            logger.info("Auto-detected project type 'java' from project files")
            return "java"
        
        # 5. Default to java for backward compatibility
        logger.warning(
            f"Could not detect project type for {request.project_path}, "
            "defaulting to 'java'"
        )
        return "java"

    async def _run_build(
        self,
        project_path: str,
        project_type: str
    ) -> Dict:
        """Run build and extract errors."""
        logger.info(f"Running {project_type} build at {project_path}")
        
        if project_type == "dotnet":
            cmd = ["dotnet", "build", "--no-restore", "--verbosity", "normal"]
        elif project_type == "java":
            cmd = ["mvn", "compile", "-B"]
        else:
            cmd = ["mvn", "compile", "-B"]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=600  # 10 min
            )
            
            output = result.stdout + "\n" + result.stderr
            errors = self._extract_error_lines(output, project_type)
            
            logger.info(f"Build exit code: {result.returncode}, Errors found: {len(errors)}")
            
            return {
                "success": result.returncode == 0 and len(errors) == 0,
                "errors": errors,
                "error_count": len(errors),
                "output": output[:5000]  # Keep sample for debugging
            }
        
        except subprocess.TimeoutExpired:
            logger.error("Build timeout after 600s")
            return {
                "success": False,
                "errors": ["Build timeout after 10 minutes"],
                "error_count": 1,
                "output": ""
            }
        except Exception as e:
            logger.error(f"Build execution failed: {e}")
            return {
                "success": False,
                "errors": [f"Build error: {str(e)}"],
                "error_count": 1,
                "output": ""
            }

    def _extract_error_lines(self, output: str, project_type: str) -> List[str]:
        """Extract error lines from build output."""
        lines = output.split('\n')
        errors = []
        
        if project_type == "dotnet":
            # Capture multiple .NET error patterns:
            # 1. C# compilation errors: file.cs(line,col): error CS####: message
            # 2. MSBuild project errors: file.csproj(line,col): error MSB####: message
            # 3. General MSBuild errors: error MSB####: message
            # 4. XML parsing errors: error : message
            for line in lines:
                # Match C# compilation errors (CS####)
                if re.search(r'\.cs\(\d+,\d+\): error CS\d+:', line):
                    errors.append(line.strip())
                # Match MSBuild project file errors (MSB####)
                elif re.search(r'\.(csproj|props|targets)\(\d+,\d+\): error MSB\d+:', line):
                    errors.append(line.strip())
                # Match general MSBuild errors without file reference
                elif re.search(r'\berror MSB\d+:', line):
                    errors.append(line.strip())
                # Match generic error patterns (for XML/parsing errors)
                elif re.search(r'\berror\s*:\s*.+?(mismatched tag|expected|parse|xml)', line, re.IGNORECASE):
                    errors.append(line.strip())
        else:  # Java
            # Pattern: [ERROR] or "error:" in line
            for line in lines:
                if '[ERROR]' in line or re.search(r'\berror:', line, re.IGNORECASE):
                    # Skip Maven plugin errors, focus on compilation
                    if 'compilation failure' in line.lower() or 'cannot find symbol' in line.lower():
                        errors.append(line.strip())
        
        # Deduplicate while preserving order
        seen = set()
        unique_errors = []
        for err in errors:
            if err not in seen:
                seen.add(err)
                unique_errors.append(err)
        
        return unique_errors[:100]  # Limit to first 100 unique errors

    def _categorize_errors(
        self,
        errors: List[str],
        project_type: str
    ) -> Dict[str, List[str]]:
        """Categorize errors by type/pattern."""
        categories = defaultdict(list)
        
        if project_type == "dotnet":
            for error in errors:
                # Extract error code (CS#### for C#, MSB#### for MSBuild)
                cs_match = re.search(r'error (CS\d+):', error)
                msb_match = re.search(r'error (MSB\d+):', error)
                
                if cs_match:
                    # C# compilation error
                    error_code = cs_match.group(1)
                    # Extract main error message
                    msg_match = re.search(r': error CS\d+: (.+?)(\s*\[|$)', error)
                    if msg_match:
                        msg = msg_match.group(1)[:50]
                        category = f"{error_code}_{self._sanitize_category_name(msg)}"
                    else:
                        category = error_code
                    categories[category].append(error)
                elif msb_match:
                    # MSBuild project error
                    error_code = msb_match.group(1)
                    # Extract main error message
                    msg_match = re.search(r': error MSB\d+: (.+?)(\s*\[|$)', error)
                    if msg_match:
                        msg = msg_match.group(1)[:50]
                        category = f"{error_code}_{self._sanitize_category_name(msg)}"
                    else:
                        category = error_code
                    categories[category].append(error)
                elif 'xml' in error.lower() or 'parse' in error.lower() or 'mismatched tag' in error.lower():
                    # XML/parsing errors (like malformed .csproj)
                    categories["XML_PARSE_ERROR"].append(error)
                else:
                    categories["DOTNET_OTHER"].append(error)
        else:  # Java
            for error in errors:
                if "cannot find symbol" in error.lower():
                    categories["SYMBOL_NOT_FOUND"].append(error)
                elif "package does not exist" in error.lower():
                    categories["PACKAGE_MISSING"].append(error)
                elif "incompatible types" in error.lower():
                    categories["TYPE_MISMATCH"].append(error)
                elif "method" in error.lower() and "cannot be applied" in error.lower():
                    categories["METHOD_SIGNATURE"].append(error)
                elif "class" in error.lower() and "is public" in error.lower():
                    categories["CLASS_FILE_MISMATCH"].append(error)
                else:
                    categories["JAVA_OTHER"].append(error)
        
        return dict(categories)

    def _sanitize_category_name(self, text: str) -> str:
        """Convert error message to safe category name."""
        # Remove special chars, spaces, keep alphanumeric
        safe = re.sub(r'[^a-zA-Z0-9]+', '_', text)
        return safe[:40].strip('_').upper()

    def _generate_fix_prompt(
        self,
        error_categories: Dict[str, List[str]],
        project_type: str,
        iteration: int,
        total_errors: int
    ) -> str:
        """Generate AI prompt with categorized errors."""
        
        # Sort categories by frequency (most common first)
        sorted_categories = sorted(
            error_categories.items(),
            key=lambda x: len(x[1]),
            reverse=True
        )
        
        # Build category sections
        category_sections = []
        for category, error_list in sorted_categories[:10]:  # Top 10 categories
            count = len(error_list)
            samples = error_list[:5]  # Show up to 5 examples
            
            section = f"""
### Category: {category}
**Occurrences:** {count} errors
**Sample Errors:**
```
{chr(10).join(samples)}
```
"""
            category_sections.append(section)
        
        prompt = f"""# POST-TRANSFORMATION: Compilation Error Fix - Iteration {iteration}/10

## Build Status
- **Project Type:** {project_type}
- **Total Errors:** {total_errors}
- **Error Categories:** {len(error_categories)}
- **Strategy:** Fix most frequent categories first (likely same root cause)

## Categorized Errors (By Frequency)

{chr(10).join(category_sections)}

---

## Your Mission

Fix the compilation errors by:

1. **Analyze Patterns**: The most frequent errors often share the same root cause
   - Example: 20x "CS0246 type not found" → probably missing using statement or namespace changed

2. **Fix by Category**: Start with the category that has the most occurrences
   - Fixing one category may resolve 10-20+ individual errors at once

3. **Use Code Editor**: Make surgical changes to source files
   - Update namespaces, using statements, type names, method signatures
   - Fix API migrations (old API → new API)

4. **Common Fixes for {project_type.upper()}:**
"""
        
        if project_type == "dotnet":
            prompt += """
   **C# Compilation Errors (CS####):**
   - **CS0246** (Type not found): Add missing `using` statements or update namespace
   - **CS1061** (Member not found): API changed - find new equivalent method/property
   - **CS0103** (Name doesn't exist): Variable/class renamed - update references
   - **CS0012** (Type defined in unreferenced assembly): Add package reference
   
   **MSBuild Project Errors (MSB####):**
   - **MSB4068/MSB3231** (XML parsing): Fix malformed XML in .csproj file (mismatched tags, unclosed elements)
   - **MSB3644** (Reference assemblies not found): Add missing package references or update TargetFramework
   - **MSB4019** (Imported project not found): Fix project reference paths in .csproj
   - **XML_PARSE_ERROR**: Check .csproj file for syntax errors (missing closing tags, invalid XML)
"""
        else:  # Java
            prompt += """
   - **Symbol not found**: Add missing imports or update package names
   - **Package missing**: Update import statements to new package structure
   - **Type mismatch**: Use proper generic types or casting
   - **Method signature**: Update method calls to match new API signatures
"""
        
        prompt += f"""

5. **Iteration {iteration}**: Focus on different errors if previous iteration didn't resolve them

## Tools Available

- `code_editor`: Read and write source files
- `bash`: Run quick checks (don't rebuild, that happens automatically)

## Output

Make targeted fixes using `code_editor`. Be systematic:
- Fix highest frequency category first
- One category at a time
- Verify your changes make sense

**Start fixing now!**
"""
        
        return prompt
