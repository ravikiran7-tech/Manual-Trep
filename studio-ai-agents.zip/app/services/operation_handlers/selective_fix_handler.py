"""
Selective Fix Handler - Apply selective fixes for containerization blockers.

Applies code fixes for specific containerization blockers based on analysis results.
Includes automatic post-transformation compilation error fixing.

Supports two execution modes controlled by SELECTIVE_FIX_BATCH_BY_RULE env var:

  SINGLE (default, batch_by_rule=False):
    Passes the entire prompt to the AI in one call — existing behaviour,
    zero changes to any downstream flow.

  BATCHED (batch_by_rule=True):
    1. Reads the prompt file and splits it on the
       "IMPORTANT: Fix ONLY these specific blockers:" separator.
    2. Parses the embedded blockers JSON array.
    3. Groups blockers by ruleId (one AI call per unique rule).
    4. For each rule group (sequentially):
         - Builds a focused sub-prompt = base instructions + rule occurrences.
         - Calls the AI model; streams events to a per-rule file.
    5. Merges all events into one selective-fix-stream.json.
    6. Runs the same automatic post-transformation error fixing as single mode.
"""
import json
import logging
import re
import subprocess
from pathlib import Path
from collections import defaultdict
from typing import Any, Dict, List, Tuple, Optional

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import FileOperationError
from app.utils.transformation_utils import merge_fix_result

logger = logging.getLogger(__name__)
settings = get_settings()


class SelectiveFixHandler(BaseOperationHandler):
    """
    Handler for 'selective-fix' operation.

    Applies code fixes for specific containerization blockers using AI to:
    - Fix hardcoded paths and configuration
    - Externalize configuration to environment variables
    - Update database connection patterns
    - Fix file system dependencies
    - Update port configurations
    - Automatically fix compilation errors (up to 10 iterations)

    Timeout: 3600s (extended - 1 hour)
    Output: containerization/{analysisId}/selective-fix-stream.json

    Note: This operation has an extended timeout because it involves
    actual code modifications which can be time-consuming for large codebases.
    After transformation completes, automatically runs up to 10 iterations
    of build validation and error fixing.
    """

    MAX_FIX_ITERATIONS = 3  # Maximum iterations for post-transformation error fixing

    def get_timeout(self) -> int:
        """
        Get timeout for selective fix operation.

        Returns:
            Timeout in seconds (3600s = 1 hour)
        """
        return settings.timeouts.upgrade_operations

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate selective fix request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Selective fix requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for selective-fix operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Route to batched or single-call execution based on config flag.

        Batched mode: SELECTIVE_FIX_BATCH_BY_RULE=true
        Single mode:  SELECTIVE_FIX_BATCH_BY_RULE=false (default)
        """
        logger.info(
            f"Starting selective fix operation: analysisId={request.analysis_id}, "
            f"batch_by_rule={settings.selective_fix.batch_by_rule}"
        )
        logger.info(f"Extended timeout configured: {self.get_timeout()}s")

        # Validate request
        self.validate_request(request)

        if settings.selective_fix.batch_by_rule:
            return await self._execute_batched(request)
        return await self._execute_single(request)

    # =========================================================================
    # SINGLE-CALL PATH  (original behaviour, unchanged)
    # =========================================================================

    async def _execute_single(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute selective fix operation with the full prompt in a single AI call.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with fix results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Selective fix (single mode): analysisId={request.analysis_id}, "
            f"extended timeout={self.get_timeout()}s"
        )

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(request, "selective-fix-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using extended timeout
            logger.info("Invoking AI provider for selective fix with extended timeout")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 3600s extended timeout
                operation_name="selective_fix_operation"
            )
            async def invoke_selective_fix():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_selective_fix()

            logger.info(f"Selective fix completed: {len(stream_events)} events received")

            # Check if transformation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Selective fix failed"
                logger.error(f"Selective fix operation failed: {error_msg}")
                await self.write_stream_output(output_path, stream_events)
                return self.build_error_response(error_msg, stream_events, output_path)

            # ========================================================================
            # AUTOMATIC POST-TRANSFORMATION ERROR FIXING (10 iterations max)
            # ========================================================================
            logger.info("Transformation complete. Starting automatic error fixing...")
            
            all_events = await self._run_post_transformation_fixes(
                request,
                provider,
                stream_events
            )
            
            # Write combined output (transformation + fixes)
            await self.write_stream_output(output_path, all_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="selective-fix-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Build success response
            logger.info("Selective fix with post-transformation fixes completed")
            return self.build_success_response(
                output_path,
                all_events,
                message="Selective fix with automatic error fixing completed"
            )

        except Exception as e:
            error_msg = f"Selective fix operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    # =========================================================================
    # BATCHED-BY-RULE PATH
    # =========================================================================

    async def _execute_batched(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Rule-batched execution.

        Steps:
          1. Read & split prompt file into base_prompt + blockers JSON array.
          2. Group blockers by ruleId.
          3. Get AI provider (one shared instance for all rule calls).
          4. For each ruleId group (sequential):
               - Build focused sub-prompt.
               - Invoke AI; stream events to per-rule file.
               - Accumulate events.
          5. Write merged stream file.
          6. Run the same automatic post-transformation error fixing as single mode.
          7. Return ClaudeCliResponse pointing to merged output.
        """
        logger.info(
            f"Selective fix (batched mode): analysisId={request.analysis_id}"
        )

        try:
            # ------------------------------------------------------------------
            # Step 1 — read & split prompt file
            # ------------------------------------------------------------------
            raw_prompt = self._read_raw_prompt_file(request.prompt)
            base_prompt, blockers_json_str = self._parse_prompt_sections(raw_prompt)

            # ------------------------------------------------------------------
            # Step 2 — parse blockers JSON array and group by ruleId
            # ------------------------------------------------------------------
            blockers = self._extract_blockers_json(blockers_json_str, request.prompt)

            if not blockers:
                logger.warning(
                    "No blockers found in prompt file — falling back to single mode"
                )
                return await self._execute_single(request)

            rule_groups = self._group_blockers_by_rule(blockers)
            logger.info(
                f"Grouped {len(blockers)} blockers into {len(rule_groups)} unique rules: "
                f"{list(rule_groups.keys())}"
            )

            # ------------------------------------------------------------------
            # Step 3 — get provider and build merged output path
            # ------------------------------------------------------------------
            provider = await self.provider_factory.get_provider()
            merged_output_path = self.build_output_path(
                request, "selective-fix-stream.json"
            )
            output_dir = merged_output_path.parent

            # ------------------------------------------------------------------
            # Step 4 — sequential per-rule AI calls
            # ------------------------------------------------------------------
            all_stream_events: List[Dict[str, Any]] = []
            failed_rules: List[str] = []

            batch_size = settings.selective_fix.max_occurrences_per_call

            for rule_id, rule_data in rule_groups.items():
                occurrences = rule_data.get("occurrences", [])
                occurrence_batches = [
                    occurrences[i:i + batch_size]
                    for i in range(0, len(occurrences), batch_size)
                ] or [[]]

                logger.info(
                    f"Processing rule {rule_id} "
                    f"({rule_data['severity'].upper()}): "
                    f"{len(occurrences)} occurrence(s) in {len(occurrence_batches)} sub-batch(es)"
                )

                rule_failed = False

                for batch_idx, occurrence_batch in enumerate(occurrence_batches, start=1):
                    batch_data = {**rule_data, "occurrences": occurrence_batch}

                    logger.info(
                        f"Processing rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)}: "
                        f"{len(occurrence_batch)} occurrence(s)"
                    )

                    rule_prompt = self._build_rule_prompt(base_prompt, rule_id, batch_data, request)

                    try:
                        # Note: stream_output_path is intentionally omitted here.
                        # stream_output_streaming() truncates whatever file it's
                        # given at the start of each call, which would wipe out
                        # prior batches' events if pointed at the shared merged
                        # file. Instead we rewrite the merged file ourselves
                        # (below) once this batch's events are known.
                        rule_events = await self.invoke_with_provider(
                            provider=provider,
                            prompt=rule_prompt,
                            project_path=request.project_path,
                            max_tokens=settings.bedrock.max_tokens,
                            temperature=settings.bedrock.temperature,
                            enable_tools=True
                        )

                        # Stamp each event with the originating ruleId for traceability
                        for event in rule_events:
                            event.setdefault("rule_id", rule_id)

                        all_stream_events.extend(rule_events)

                        # Persist the merged stream incrementally after every batch
                        await self.write_stream_output(merged_output_path, all_stream_events)

                        logger.info(
                            f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} completed: "
                            f"{len(rule_events)} events appended to merged stream: {merged_output_path}"
                        )

                    except Exception as rule_err:
                        logger.exception(
                            f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} "
                            f"AI call failed: {rule_err}", exc_info=True
                        )
                        rule_failed = True
                        # Append an error event so the merged stream records the failure
                        all_stream_events.append({
                            "type": "error",
                            "rule_id": rule_id,
                            "error": (
                                f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} "
                                f"processing failed: {str(rule_err)}"
                            )
                        })

                if rule_failed:
                    failed_rules.append(rule_id)

            logger.info(
                f"All rules processed. Total events: {len(all_stream_events)}, "
                f"failed rules: {failed_rules or 'none'}"
            )

            if len(failed_rules) == len(rule_groups):
                # Every rule call failed
                error_msg = f"All {len(rule_groups)} rule(s) failed: {failed_rules}"
                logger.error(error_msg)
                await self.write_stream_output(merged_output_path, all_stream_events)
                return self.build_error_response(error_msg, all_stream_events, merged_output_path)

            # ------------------------------------------------------------------
            # Step 5/6 — automatic post-transformation error fixing (same as single mode)
            # ------------------------------------------------------------------
            logger.info("Transformation complete. Starting automatic error fixing...")

            final_events = await self._run_post_transformation_fixes(
                request,
                provider,
                all_stream_events
            )

            await self.write_stream_output(merged_output_path, final_events)

            result_path = await self.extract_and_write_json_result(
                stream_events=all_stream_events,
                output_dir=output_dir,
                result_filename="selective-fix-result.json"
            )
            if result_path:
                logger.info(f"Merged JSON result written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from merged stream")

            # ------------------------------------------------------------------
            # Step 7 — build response
            # ------------------------------------------------------------------
            if failed_rules:
                message = (
                    f"Selective fix completed with partial success. "
                    f"Succeeded: {len(rule_groups) - len(failed_rules)}/{len(rule_groups)} rules. "
                    f"Failed rules: {failed_rules}"
                )
            else:
                message = (
                    f"Selective fix with automatic error fixing completed "
                    f"({len(rule_groups)} rule(s) processed)"
                )

            logger.info(message)
            return self.build_success_response(merged_output_path, final_events, message)

        except Exception as e:
            logger.exception(f"Selective fix (batched) failed: {str(e)}", exc_info=True)
            raise

    # =========================================================================
    # PROMPT PARSING HELPERS
    # =========================================================================

    def _read_raw_prompt_file(self, prompt_path: str) -> str:
        """
        Read the raw prompt file without applying the system-instruction enhancement.

        We need the raw text here so we can split on the separator ourselves.
        The per-rule prompts will be enhanced individually via
        _enhance_prompt_with_json_output_requirement inside _build_rule_prompt.
        """
        from app.core.security import SecurityValidator

        try:
            SecurityValidator.validate_path(prompt_path, "prompt")
            prompt_file = Path(prompt_path)

            if not prompt_file.exists():
                raise FileNotFoundError(f"Prompt file not found: {prompt_path}")
            if not prompt_file.is_file():
                raise ValueError(f"Prompt path is not a file: {prompt_path}")

            with open(prompt_file, "r", encoding="utf-8") as f:
                content = f.read()

            logger.info(f"Read raw prompt file: {prompt_path} ({len(content)} chars)")
            return content

        except FileNotFoundError as e:
            raise FileOperationError(
                message=str(e),
                file_path=prompt_path,
                details="Prompt file does not exist"
            )
        except Exception as e:
            raise FileOperationError(
                message=f"Failed to read prompt file: {str(e)}",
                file_path=prompt_path,
                details=str(e)
            )

    def _parse_prompt_sections(self, raw_text: str) -> Tuple[str, str]:
        """
        Extract the blockers JSON array from the prompt file.

        The prompt file may contain multiple sections, e.g.:

            system prompt
            ...
            user prompt
            ...
            project details
            ...
            IMPORTANT: Fix ONLY these specific blockers:
            [
              {"id": "...", "ruleId": "...", ...},
              ...
            ]
            Task :
            ...
            response format,
            ...

        This method:
          1. Finds the configured separator (default
             "IMPORTANT: Fix ONLY these specific blockers:").
          2. Locates the first '[' after the separator.
          3. Walks forward counting brackets to extract only the balanced
             JSON array — stopping exactly at the matching ']'.
          4. Re-assembles the base_prompt as:
               <everything before separator> + <everything after array close>
             so that sections like "Task :" and "response format" are
             preserved for the per-rule AI calls.

        Returns:
            (base_prompt, blockers_json_str) — both stripped strings.

        Fallback:
            If the separator is missing or no '[' is found after it,
            returns (raw_text, "") so the caller falls back to single mode.
        """
        separator = settings.selective_fix.blockers_separator
        sep_idx = raw_text.find(separator)

        if sep_idx == -1:
            logger.warning(
                f"Separator '{separator}' not found in prompt file — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        after_sep = raw_text[sep_idx + len(separator):]

        # Locate the first opening bracket after the separator
        bracket_start = after_sep.find("[")
        if bracket_start == -1:
            logger.warning(
                "No '[' found after the blockers separator — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        # Extract the balanced JSON array
        json_str, bracket_end = self._extract_balanced_json_block(
            after_sep, bracket_start, open_ch="[", close_ch="]"
        )

        if not json_str:
            logger.warning(
                "Could not find a balanced JSON array after the separator — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        # Reconstruct base_prompt: everything before the separator header +
        # everything after the closing ']' (Task, response format, etc.)
        pre_sep = raw_text[:sep_idx].strip()
        post_json = after_sep[bracket_end:].strip()

        if post_json:
            base_prompt = f"{pre_sep}\n\n{post_json}"
        else:
            base_prompt = pre_sep

        logger.info(
            f"Extracted blockers JSON ({len(json_str)} chars) from prompt. "
            f"Base prompt reconstructed: {len(base_prompt)} chars "
            f"(pre-sep={len(pre_sep)}, post-json={len(post_json)})."
        )
        return base_prompt.strip(), json_str

    def _extract_balanced_json_block(
        self, text: str, start: int, open_ch: str = "{", close_ch: str = "}"
    ) -> Tuple[str, int]:
        """
        Walk forward from *start* counting open_ch/close_ch to find the matching close.

        Handles strings (ignores brackets/braces inside double-quoted strings) and
        backslash escape sequences inside strings.

        Args:
            text:     The full string to scan.
            start:    Index of the opening bracket/brace within *text*.
            open_ch:  Opening character to count ('{' or '[').
            close_ch: Closing character that decrements depth ('}' or ']').

        Returns:
            (json_str, end_index) where end_index is the position just after
            the closing character. Returns ("", len(text)) when no balanced
            block is found (malformed JSON or unterminated string).
        """
        depth = 0
        in_string = False
        escape_next = False

        for i in range(start, len(text)):
            in_string, escape_next, depth, balanced = self._advance_json_state(
                text[i], in_string, escape_next, depth, open_ch, close_ch
            )
            if balanced:
                return text[start: i + 1], i + 1

        logger.warning(
            "Bracket extraction ended without finding a balanced close. "
            "The JSON block in the prompt file may be malformed."
        )
        return "", len(text)

    @staticmethod
    def _advance_json_state(
        ch: str, in_string: bool, escape_next: bool, depth: int,
        open_ch: str = "{", close_ch: str = "}"
    ) -> Tuple[bool, bool, int, bool]:
        """
        Advance the JSON-scanning state machine by one character.

        Returns:
            (in_string, escape_next, depth, balanced_close_found)
        """
        if escape_next:
            return in_string, False, depth, False

        if in_string and ch == "\\":
            return in_string, True, depth, False

        if ch == '"':
            return not in_string, False, depth, False

        if in_string:
            return in_string, False, depth, False

        if ch == open_ch:
            return in_string, False, depth + 1, False

        if ch == close_ch:
            depth -= 1
            return in_string, False, depth, depth == 0

        return in_string, False, depth, False

    def _extract_blockers_json(
        self, blockers_json_str: str, prompt_path: str
    ) -> List[Dict[str, Any]]:
        """
        JSON-parse the blockers array extracted from the prompt file.

        Raises:
            FileOperationError: If the extracted string is not valid JSON.
        """
        if not blockers_json_str:
            return []

        try:
            data = json.loads(blockers_json_str)
            if not isinstance(data, list):
                logger.warning(
                    "Blockers JSON block is not an array — falling back to single mode."
                )
                return []
            logger.info(f"Parsed blockers JSON: {len(data)} blocker(s)")
            return data
        except json.JSONDecodeError as e:
            raise FileOperationError(
                message=f"Failed to parse blockers JSON: {str(e)}",
                file_path=prompt_path,
                details=(
                    f"JSON decode error at line {e.lineno}, col {e.colno}. "
                    "Ensure the JSON array in the prompt file is valid."
                )
            )

    # =========================================================================
    # BLOCKER GROUPING HELPER
    # =========================================================================

    def _group_blockers_by_rule(
        self, blockers: List[Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Group blocker entries by ruleId.

        For each unique ruleId, produce a dict:
          {
            "ruleName":        str,
            "ruleDesc":        str,
            "category":        str,
            "severity":        str,
            "remediationName": str,
            "remediationDesc": str,
            "occurrences": [
                {"filePath": ..., "beginLine": ..., "endLine": ..., "id": ...},
                ...
            ]
          }

        Rule metadata is taken from the FIRST blocker encountered for that ruleId.
        Only "filePath", "beginLine", "endLine" vary across occurrences.
        """
        groups: Dict[str, Dict[str, Any]] = {}

        for blocker in blockers:
            rule_id = blocker.get("ruleId", "unknown")

            if rule_id not in groups:
                groups[rule_id] = {
                    "ruleName":        blocker.get("ruleName", ""),
                    "ruleDesc":        blocker.get("ruleDesc", ""),
                    "category":        blocker.get("category", ""),
                    "severity":        blocker.get("severity", ""),
                    "remediationName": blocker.get("remediationName", ""),
                    "remediationDesc": blocker.get("remediationDesc", ""),
                    "occurrences":     []
                }

            groups[rule_id]["occurrences"].append({
                "id":        blocker.get("id", ""),
                "filePath":  blocker.get("filePath", ""),
                "beginLine": blocker.get("beginLine"),
                "endLine":   blocker.get("endLine")
            })

        return groups

    # =========================================================================
    # PER-RULE PROMPT BUILDER
    # =========================================================================

    def _build_rule_prompt(
        self,
        base_prompt: str,
        rule_id: str,
        rule_data: Dict[str, Any],
        request: ClaudeCliRequest
    ) -> str:
        """
        Build the focused prompt for a single ruleId group.

        Structure:
            <system enhancement header>

            <base_prompt>

            ═══ CURRENT FIX TASK ═══
            Rule ID   : <rule_id>
            Rule Name : <ruleName>
            Severity  : <severity>  Category: <category>
            Description:
              <ruleDesc>

            Remediation Strategy : <remediationName>
            Remediation Details  :
              <remediationDesc>

            Occurrences to fix (fix EVERY entry below):
              1. File: <filePath>  Lines: <beginLine>–<endLine>
              2. ...

            Instructions:
              - Use code_editor to read each affected file before modifying it.
              - Apply the remediation to EVERY occurrence listed above.
              - Write the updated file content back using code_editor (write operation).
              - After all fixes are complete, output a JSON summary block.
            ════════════════════════
        """
        occurrences = rule_data.get("occurrences", [])
        occurrence_lines = "\n".join(
            f"  {i + 1}. File: {occ['filePath']}  "
            f"Lines: {occ['beginLine']}–{occ['endLine']}"
            for i, occ in enumerate(occurrences)
        )

        fix_task_section = f"""
{'═' * 79}
CURRENT FIX TASK

Rule ID          : {rule_id}
Rule Name        : {rule_data['ruleName']}
Severity         : {rule_data['severity'].upper()}    Category: {rule_data['category']}

Description:
  {rule_data['ruleDesc']}

Remediation Strategy : {rule_data['remediationName']}
Remediation Details  :
  {rule_data['remediationDesc']}

Occurrences to fix (you MUST fix EVERY entry listed below):
{occurrence_lines}

Instructions:
  1. Use code_editor (operation=read) to read each affected file before modifying it.
  2. Apply the remediation described above to EVERY occurrence listed.
  3. Use code_editor (operation=write or patch) to persist the changes.
  4. After completing ALL fixes for this rule, output a JSON summary in your text
     response using a ```json code block with at minimum:
       {{
         "ruleId": "{rule_id}",
         "ruleName": "{rule_data['ruleName']}",
         "status": "fixed" | "partial" | "failed",
         "fixedOccurrences": [...],
         "skippedOccurrences": [...],
         "notes": "..."
       }}
{'═' * 79}
""".strip()

        # Combine: system enhancement header + base prompt + per-rule task
        enhanced_base = self._enhance_prompt_with_json_output_requirement(
            user_prompt=base_prompt,
            operation=request.operation
        )

        return f"{enhanced_base}\n\n{fix_task_section}"

    async def _run_post_transformation_fixes(
        self,
        request: ClaudeCliRequest,
        provider,
        all_events: List[Dict]
    ) -> List[Dict]:
        """
        Automatically fix compilation errors after transformation.
        Runs up to 10 iterations of build → categorize → fix → verify.
        
        Args:
            request: Original request
            provider: AI provider instance
            all_events: Events from transformation phase
            
        Returns:
            Combined events (transformation + fixes)
        """
        logger.info("=" * 80)
        logger.info("POST-TRANSFORMATION: Starting automatic compilation error fixing")
        logger.info("=" * 80)
        
        # Detect project type
        project_type = self._detect_project_type(request)
        logger.info(f"Detected project type: {project_type}")
        
        for iteration in range(1, self.MAX_FIX_ITERATIONS + 1):
            logger.info(f"Fix iteration {iteration}/{self.MAX_FIX_ITERATIONS}")
            
            # Step 1: Run build and capture errors
            build_result = await self._run_build(
                request.project_path,
                project_type
            )
            
            if build_result["success"]:
                logger.info("✓ Build successful - all compilation errors resolved!")
                all_events.append({
                    "type": "build_success",
                    "iteration": iteration,
                    "message": "All compilation errors fixed"
                })
                break
            
            error_count = build_result["error_count"]
            logger.info(f"Build failed with {error_count} errors")
            
            # Step 2: Categorize errors
            error_categories = self._categorize_errors(
                build_result["errors"],
                project_type
            )
            
            logger.info(
                f"Categorized into {len(error_categories)} error types: "
                f"{list(error_categories.keys())}"
            )
            
            # Step 3: Generate fix prompt
            fix_prompt = self._generate_fix_prompt(
                error_categories,
                project_type,
                iteration,
                error_count
            )
            
            # Step 4: Apply fixes using AI
            try:
                @with_resilience(
                    retry_attempts=2,
                    timeout_seconds=1200,  # 20 min per iteration
                    operation_name=f"post_transform_fix_iter_{iteration}"
                )
                async def apply_fixes():
                    events = await self.invoke_with_provider(
                        provider=provider,
                        prompt=fix_prompt,
                        project_path=request.project_path,
                        max_tokens=settings.bedrock.max_tokens,
                        temperature=settings.bedrock.temperature,
                        enable_tools=True
                    )
                    return events
                
                iteration_events = await apply_fixes()
                all_events.extend(iteration_events)
                
                # Check if fixes were applied
                if not self.is_stream_successful(iteration_events):
                    logger.warning(f"Iteration {iteration} failed to apply fixes")
                    all_events.append({
                        "type": "fix_iteration_failed",
                        "iteration": iteration,
                        "message": "AI failed to apply fixes"
                    })
                    break
                
                all_events.append({
                    "type": "fix_iteration_complete",
                    "iteration": iteration,
                    "errors_found": error_count,
                    "categories": len(error_categories)
                })
                
            except Exception as e:
                logger.error(f"Fix iteration {iteration} error: {e}")
                all_events.append({
                    "type": "fix_iteration_error",
                    "iteration": iteration,
                    "error": str(e)
                })
                break
        
        # Final build summary
        final_build = await self._run_build(
            request.project_path,
            project_type
        )
        
        all_events.append({
            "type": "final_build_status",
            "success": final_build["success"],
            "remaining_errors": final_build["error_count"]
        })
        
        logger.info("=" * 80)
        status_msg = "SUCCESS" if final_build["success"] else f"{final_build['error_count']} errors remaining"
        logger.info(f"POST-TRANSFORMATION COMPLETE: {status_msg}")
        logger.info("=" * 80)
        
        return all_events

    def _detect_project_type(self, request: ClaudeCliRequest) -> str:
        """
        Detect project type from request or project structure.
        
        Priority order:
        1. Explicit project_type field from payload (projectType)
        2. Infer from dotnet_version or java_version fields
        3. Auto-detect from project structure (.csproj, pom.xml, etc.)
        4. Default to "java" for backward compatibility
        
        Args:
            request: Claude CLI request
            
        Returns:
            Project type: "dotnet" or "java"
        """
        # 1. Check if project_type is explicitly provided in payload
        if request.project_type:
            logger.info(f"Using explicit projectType from payload: {request.project_type}")
            return request.project_type.lower()
        
        # 2. Check if dotnet_version is specified
        if request.dotnet_version:
            logger.info("Inferred project type 'dotnet' from dotnetVersion field")
            return "dotnet"
        
        # 3. Check if java_version is specified
        if request.java_version:
            logger.info("Inferred project type 'java' from javaVersion field")
            return "java"
        
        # 4. Detect from project structure
        project_path = Path(request.project_path)
        
        # Check for .NET project files
        if list(project_path.rglob("*.csproj")) or list(project_path.rglob("*.sln")):
            logger.info("Auto-detected project type 'dotnet' from project files")
            return "dotnet"
        
        # Check for Java project files
        if (project_path / "pom.xml").exists() or (project_path / "build.gradle").exists():
            logger.info("Auto-detected project type 'java' from project files")
            return "java"
        
        # 5. Default to java for backward compatibility
        logger.warning(
            f"Could not detect project type for {request.project_path}, "
            "defaulting to 'java'"
        )
        return "java"

    async def _run_build(
        self,
        project_path: str,
        project_type: str
    ) -> Dict:
        """Run build and extract errors."""
        logger.info(f"Running {project_type} build at {project_path}")
        
        if project_type == "dotnet":
            cmd = ["dotnet", "build", "--no-restore", "--verbosity", "normal"]
        elif project_type == "java":
            cmd = ["mvn", "compile", "-B"]
        else:
            cmd = ["mvn", "compile", "-B"]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=600  # 10 min
            )
            
            output = result.stdout + "\n" + result.stderr
            errors = self._extract_error_lines(output, project_type)
            
            logger.info(f"Build exit code: {result.returncode}, Errors found: {len(errors)}")
            
            return {
                "success": result.returncode == 0 and len(errors) == 0,
                "errors": errors,
                "error_count": len(errors),
                "output": output[:5000]  # Keep sample for debugging
            }
        
        except subprocess.TimeoutExpired:
            logger.error("Build timeout after 600s")
            return {
                "success": False,
                "errors": ["Build timeout after 10 minutes"],
                "error_count": 1,
                "output": ""
            }
        except Exception as e:
            logger.error(f"Build execution failed: {e}")
            return {
                "success": False,
                "errors": [f"Build error: {str(e)}"],
                "error_count": 1,
                "output": ""
            }

    def _extract_error_lines(self, output: str, project_type: str) -> List[str]:
        """Extract error lines from build output."""
        lines = output.split('\n')
        errors = []
        
        if project_type == "dotnet":
            # Capture multiple .NET error patterns:
            # 1. C# compilation errors: file.cs(line,col): error CS####: message
            # 2. MSBuild project errors: file.csproj(line,col): error MSB####: message
            # 3. General MSBuild errors: error MSB####: message
            # 4. XML parsing errors: error : message
            for line in lines:
                # Match C# compilation errors (CS####)
                if re.search(r'\.cs\(\d+,\d+\): error CS\d+:', line):
                    errors.append(line.strip())
                # Match MSBuild project file errors (MSB####)
                elif re.search(r'\.(csproj|props|targets)\(\d+,\d+\): error MSB\d+:', line):
                    errors.append(line.strip())
                # Match general MSBuild errors without file reference
                elif re.search(r'\berror MSB\d+:', line):
                    errors.append(line.strip())
                # Match generic error patterns (for XML/parsing errors)
                elif re.search(r'\berror\s*:\s*.+?(mismatched tag|expected|parse|xml)', line, re.IGNORECASE):
                    errors.append(line.strip())
        else:  # Java
            # Pattern: [ERROR] or "error:" in line
            for line in lines:
                if '[ERROR]' in line or re.search(r'\berror:', line, re.IGNORECASE):
                    # Skip Maven plugin errors, focus on compilation
                    if 'compilation failure' in line.lower() or 'cannot find symbol' in line.lower():
                        errors.append(line.strip())
        
        # Deduplicate while preserving order
        seen = set()
        unique_errors = []
        for err in errors:
            if err not in seen:
                seen.add(err)
                unique_errors.append(err)
        
        return unique_errors[:100]  # Limit to first 100 unique errors

    def _categorize_errors(
        self,
        errors: List[str],
        project_type: str
    ) -> Dict[str, List[str]]:
        """Categorize errors by type/pattern."""
        categories = defaultdict(list)
        
        if project_type == "dotnet":
            for error in errors:
                # Extract error code (CS#### for C#, MSB#### for MSBuild)
                cs_match = re.search(r'error (CS\d+):', error)
                msb_match = re.search(r'error (MSB\d+):', error)
                
                if cs_match:
                    # C# compilation error
                    error_code = cs_match.group(1)
                    # Extract main error message
                    msg_match = re.search(r': error CS\d+: (.+?)(\s*\[|$)', error)
                    if msg_match:
                        msg = msg_match.group(1)[:50]
                        category = f"{error_code}_{self._sanitize_category_name(msg)}"
                    else:
                        category = error_code
                    categories[category].append(error)
                elif msb_match:
                    # MSBuild project error
                    error_code = msb_match.group(1)
                    # Extract main error message
                    msg_match = re.search(r': error MSB\d+: (.+?)(\s*\[|$)', error)
                    if msg_match:
                        msg = msg_match.group(1)[:50]
                        category = f"{error_code}_{self._sanitize_category_name(msg)}"
                    else:
                        category = error_code
                    categories[category].append(error)
                elif 'xml' in error.lower() or 'parse' in error.lower() or 'mismatched tag' in error.lower():
                    # XML/parsing errors (like malformed .csproj)
                    categories["XML_PARSE_ERROR"].append(error)
                else:
                    categories["DOTNET_OTHER"].append(error)
        else:  # Java
            for error in errors:
                if "cannot find symbol" in error.lower():
                    categories["SYMBOL_NOT_FOUND"].append(error)
                elif "package does not exist" in error.lower():
                    categories["PACKAGE_MISSING"].append(error)
                elif "incompatible types" in error.lower():
                    categories["TYPE_MISMATCH"].append(error)
                elif "method" in error.lower() and "cannot be applied" in error.lower():
                    categories["METHOD_SIGNATURE"].append(error)
                elif "class" in error.lower() and "is public" in error.lower():
                    categories["CLASS_FILE_MISMATCH"].append(error)
                else:
                    categories["JAVA_OTHER"].append(error)
        
        return dict(categories)

    def _sanitize_category_name(self, text: str) -> str:
        """Convert error message to safe category name."""
        # Remove special chars, spaces, keep alphanumeric
        safe = re.sub(r'[^a-zA-Z0-9]+', '_', text)
        return safe[:40].strip('_').upper()

    def _generate_fix_prompt(
        self,
        error_categories: Dict[str, List[str]],
        project_type: str,
        iteration: int,
        total_errors: int
    ) -> str:
        """Generate AI prompt with categorized errors."""
        
        # Sort categories by frequency (most common first)
        sorted_categories = sorted(
            error_categories.items(),
            key=lambda x: len(x[1]),
            reverse=True
        )
        
        # Build category sections
        category_sections = []
        for category, error_list in sorted_categories[:10]:  # Top 10 categories
            count = len(error_list)
            samples = error_list[:5]  # Show up to 5 examples
            
            section = f"""
### Category: {category}
**Occurrences:** {count} errors
**Sample Errors:**
```
{chr(10).join(samples)}
```
"""
            category_sections.append(section)
        
        prompt = f"""# POST-TRANSFORMATION: Compilation Error Fix - Iteration {iteration}/10

## Build Status
- **Project Type:** {project_type}
- **Total Errors:** {total_errors}
- **Error Categories:** {len(error_categories)}
- **Strategy:** Fix most frequent categories first (likely same root cause)

## Categorized Errors (By Frequency)

{chr(10).join(category_sections)}

---

## Your Mission

Fix the compilation errors by:

1. **Analyze Patterns**: The most frequent errors often share the same root cause
   - Example: 20x "CS0246 type not found" → probably missing using statement or namespace changed

2. **Fix by Category**: Start with the category that has the most occurrences
   - Fixing one category may resolve 10-20+ individual errors at once

3. **Use Code Editor**: Make surgical changes to source files
   - Update namespaces, using statements, type names, method signatures
   - Fix API migrations (old API → new API)

4. **Common Fixes for {project_type.upper()}:**
"""
        
        if project_type == "dotnet":
            prompt += """
   **C# Compilation Errors (CS####):**
   - **CS0246** (Type not found): Add missing `using` statements or update namespace
   - **CS1061** (Member not found): API changed - find new equivalent method/property
   - **CS0103** (Name doesn't exist): Variable/class renamed - update references
   - **CS0012** (Type defined in unreferenced assembly): Add package reference
   
   **MSBuild Project Errors (MSB####):**
   - **MSB4068/MSB3231** (XML parsing): Fix malformed XML in .csproj file (mismatched tags, unclosed elements)
   - **MSB3644** (Reference assemblies not found): Add missing package references or update TargetFramework
   - **MSB4019** (Imported project not found): Fix project reference paths in .csproj
   - **XML_PARSE_ERROR**: Check .csproj file for syntax errors (missing closing tags, invalid XML)
"""
        else:  # Java
            prompt += """
   - **Symbol not found**: Add missing imports or update package names
   - **Package missing**: Update import statements to new package structure
   - **Type mismatch**: Use proper generic types or casting
   - **Method signature**: Update method calls to match new API signatures
"""
        
        prompt += f"""

5. **Iteration {iteration}**: Focus on different errors if previous iteration didn't resolve them

## Tools Available

- `code_editor`: Read and write source files
- `bash`: Run quick checks (don't rebuild, that happens automatically)

## Output

Make targeted fixes using `code_editor`. Be systematic:
- Fix highest frequency category first
- One category at a time
- Verify your changes make sense

**Start fixing now!**
"""
        
        return prompt

    async def extract_and_write_json_result(
        self,
        stream_events: List[Dict[str, Any]],
        output_dir: Path,
        result_filename: str = "selective-fix-result.json"
    ) -> Optional[Path]:
        """
        Extract JSON content from stream events and write to separate result file.

        This method:
        1. Extracts all text from assistant responses
        2. Finds JSON blocks (```json ... ```)
        3. Parses and validates the JSON
        4. Writes to result file in the same directory

        Args:
            stream_events: List of stream events
            output_dir: Directory to write result file to
            result_filename: Name of result file (default: upgrade-analysis-result.json)

        Returns:
            Path to result file if successful, None otherwise
        """
        try:
            from app.utils.stream_utils import StreamParser

            # Extract complete assistant response
            full_response = StreamParser.extract_full_assistant_response(stream_events)

            if not full_response:
                logger.warning("No assistant response found in stream events")
                return None

            # Extract JSON blocks from response
            json_blocks = StreamParser.extract_all_json_blocks(full_response)
            logger.info(f"Json Blocks: {len(json_blocks)},\n {json_blocks}")
            if not json_blocks:
                logger.warning("No JSON blocks found in assistant response")
                return None

            # Parse and merge all valid JSON blocks into a single result
            json_content = merge_fix_result(json_blocks)

            if json_content is None:
                logger.warning("No valid JSON found in any blocks")
                return None

            # Write JSON to result file
            result_path = output_dir / result_filename
            result_path.parent.mkdir(parents=True, exist_ok=True)

            with open(result_path, 'w', encoding='utf-8') as f:
                json.dump(json_content, f, indent=2)

            logger.info(f"JSON result written to: {result_path}, JSON Content: {json_content}")
            return result_path

        except Exception as e:
            logger.error(f"Failed to extract and write JSON result: {str(e)}", exc_info=True)
            return None
