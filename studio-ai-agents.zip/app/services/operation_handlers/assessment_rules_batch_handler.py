"""
Batch generation of assessment-rule JSON objects from catalog rule metadata.

Invokes the AI provider with a fixed prompt template (see app.prompts.assessment_rules_batch).
"""
import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from app.core.config import get_settings
from app.core.exceptions import ProviderError, RateLimitError, ValidationError
from app.core.resilience import with_resilience
from app.core.security import SecurityValidator
from app.models.requests import AssessmentRuleInputItem, AssessmentRulesBatchRequest, ClaudeCliRequest
from app.models.responses import (
    AssessmentRuleBatchItem,
    AssessmentRulesBatchResponse,
    ClaudeCliResponse,
)
from app.prompts.assessment_rules_batch import (
    ASSESSMENT_RULES_BATCH_SYSTEM_PROMPT,
    build_assessment_rules_batch_prompt,
    format_rules_batch_for_prompt,
)
from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.utils.path_utils import resolve_secure_work_directory
from app.utils.stream_utils import StreamParser, _extract_single_json_block_robust


logger = logging.getLogger(__name__)
settings = get_settings()

# Process-wide gate so concurrent HTTP batch jobs queue instead of stampeding the model.
_batch_request_semaphore: Optional[asyncio.Semaphore] = None
_batch_request_semaphore_n: int = 0


def _get_batch_request_semaphore() -> asyncio.Semaphore:
    """Lazy semaphore sized from ASSESSMENT_RULES_BATCH_MAX_CONCURRENT_REQUESTS."""
    global _batch_request_semaphore, _batch_request_semaphore_n
    n = max(1, settings.assessment_rules_batch.max_concurrent_requests)
    if _batch_request_semaphore is None or _batch_request_semaphore_n != n:
        _batch_request_semaphore = asyncio.Semaphore(n)
        _batch_request_semaphore_n = n
    return _batch_request_semaphore


def _reset_batch_request_semaphore_for_tests() -> None:
    """Clear the process-wide batch semaphore (tests only)."""
    global _batch_request_semaphore, _batch_request_semaphore_n
    _batch_request_semaphore = None
    _batch_request_semaphore_n = 0


def _rate_limit_backoff_seconds(exc: RateLimitError) -> float:
    """Seconds to wait after a 429 before retrying the chunk LLM call."""
    retry_after = float(exc.retry_after) if exc.retry_after is not None else None
    recovery = float(
        getattr(settings.llm_rate_limiter, "throttle_recovery", 30.0) or 0.0
    )
    if retry_after is not None:
        return max(retry_after, recovery)
    if recovery > 0:
        return recovery
    return 30.0


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _log_timing_start(phase: str, analysis_id: str) -> tuple[str, float]:
    started_at_utc = _utc_now_iso()
    started_mono = time.monotonic()
    logger.info(
        "[detection-schema] %s START analysisId=%s started_at=%s",
        phase,
        analysis_id,
        started_at_utc,
    )
    return started_at_utc, started_mono


def _log_timing_complete(
    phase: str,
    analysis_id: str,
    started_at_utc: str,
    started_mono: float,
    *,
    status: str,
    detail: str = "",
) -> float:
    completed_at_utc = _utc_now_iso()
    duration_sec = time.monotonic() - started_mono
    suffix = f" {detail}" if detail else ""
    logger.info(
        "[detection-schema] %s COMPLETE analysisId=%s status=%s "
        "started_at=%s completed_at=%s duration_sec=%.2f%s",
        phase,
        analysis_id,
        status,
        started_at_utc,
        completed_at_utc,
        duration_sec,
        suffix,
    )
    return duration_sec

# Default file extensions (no leading dot) for detectionCriteria.fileType by language id.
_DEFAULT_FILE_TYPES_BY_LANGUAGE: Dict[str, List[str]] = {
    # Java, TypeScript, JSP
    "java": ["java"],
    "typescript": ["ts", "tsx"],
    "ts": ["ts", "tsx"],
    "jsp": ["jsp", "jspx"],
    # Markup / style
    "html": ["html", "htm"],
    "htm": ["html", "htm"],
    "css": ["css"],
    # Python
    "python": ["py"],
    "py": ["py"],
    # C++
    "c++": ["cpp", "cc", "cxx", "hpp", "hh", "hxx", "h", "inl", "ipp"],
    "cpp": ["cpp", "cc", "cxx", "hpp", "hh", "hxx", "h", "inl", "ipp"],
    "cplusplus": ["cpp", "cc", "cxx", "hpp", "hh", "hxx", "h", "inl", "ipp"],
    # C#
    "csharp": ["cs"],
    "c#": ["cs"],
    "cs": ["cs"],
    # JavaScript
    "javascript": ["js", "jsx", "mjs", "cjs"],
    "js": ["js", "jsx", "mjs", "cjs"],
    # PHP
    "php": ["php"],
    # VB.NET
    "vb.net": ["vb", "vbhtml"],
    "vbnet": ["vb", "vbhtml"],
    "vb": ["vb", "vbhtml"],
    "visual basic": ["vb", "vbhtml"],
    "visualbasic": ["vb", "vbhtml"],
}


def _language_name_for_detection(body: Dict[str, Any], det: Dict[str, Any]) -> str:
    lang = det.get("language")
    if isinstance(lang, dict) and lang.get("name"):
        return str(lang["name"]).strip().lower()
    if isinstance(lang, str) and lang.strip():
        return lang.strip().lower()
    br = body.get("language")
    if isinstance(br, dict) and br.get("name"):
        return str(br["name"]).strip().lower()
    if isinstance(br, str):
        return br.strip().lower()
    return ""


def _default_file_types_for_language(lang_name: str) -> List[str]:
    key = (lang_name or "").strip().lower()
    if key in _DEFAULT_FILE_TYPES_BY_LANGUAGE:
        return list(_DEFAULT_FILE_TYPES_BY_LANGUAGE[key])
    return [key] if key else []


def _is_new_detection_shape(det: Dict[str, Any]) -> bool:
    return isinstance(det.get("detectionCriteria"), dict)


def _finalize_new_detection_schema(
    det: Dict[str, Any], body: Dict[str, Any], rid: Any
) -> Dict[str, Any]:
    """Enforce fixed status/parser and required keys for the REGEX detection contract."""
    out = dict(det)
    out["status"] = "active"
    out["parser"] = "REGEX"
    if rid is not None:
        out.setdefault("ruleId", rid)
    if not out.get("ruleName") and body.get("name"):
        out["ruleName"] = body["name"]
    out.setdefault("version", "1.0")

    lang = out.get("language")
    if isinstance(lang, str):
        out["language"] = {"name": lang.strip().lower(), "versions": []}
    elif isinstance(lang, dict):
        lang_obj = dict(lang)
        lang_obj.setdefault("versions", [])
        if lang_obj.get("name") is not None:
            lang_obj["name"] = str(lang_obj["name"]).strip().lower()
        out["language"] = lang_obj
    else:
        ln = _language_name_for_detection(body, {})
        out["language"] = {"name": ln, "versions": []}

    dc = out.get("detectionCriteria")
    if not isinstance(dc, dict):
        ln = _language_name_for_detection(body, out)
        out["detectionCriteria"] = {
            "fileType": _default_file_types_for_language(ln),
            "searchPattern": [],
        }
    else:
        dc = dict(dc)
        dc.setdefault("fileType", [])
        dc.setdefault("searchPattern", [])
        if not dc["fileType"]:
            ln = _language_name_for_detection(body, out)
            dc["fileType"] = _default_file_types_for_language(ln)
        out["detectionCriteria"] = dc

    if not isinstance(out.get("scope"), list) or not out["scope"]:
        out["scope"] = ["function"]

    return out


def _legacy_detection_to_new_schema(
    det: Dict[str, Any], body: Dict[str, Any], rid: Any
) -> Dict[str, Any]:
    """Map old detectionSchema (summary, matchHints, schemaVersion, …) to the REGEX contract."""
    lang_raw = det.get("language")
    if isinstance(lang_raw, dict):
        lang_obj = dict(lang_raw)
        lang_obj.setdefault("versions", [])
        if lang_obj.get("name") is not None:
            lang_obj["name"] = str(lang_obj["name"]).strip().lower()
    elif isinstance(lang_raw, str) and lang_raw.strip():
        lang_obj = {"name": lang_raw.strip().lower(), "versions": []}
    else:
        br = body.get("language")
        if isinstance(br, dict):
            lang_obj = dict(br)
            lang_obj.setdefault("versions", [])
            if lang_obj.get("name") is not None:
                lang_obj["name"] = str(lang_obj["name"]).strip().lower()
        else:
            lang_obj = {
                "name": (br.strip().lower() if isinstance(br, str) else ""),
                "versions": [],
            }

    hints = det.get("matchHints") or []
    patterns = [h for h in hints if isinstance(h, str)]

    scope = det.get("scope")
    if not isinstance(scope, list) or not scope:
        scope = ["function"]

    ln = _language_name_for_detection(body, {**det, "language": lang_obj})
    return {
        "ruleId": rid,
        "ruleName": body.get("name") or det.get("ruleName"),
        "version": det.get("version") or "1.0",
        "status": "active",
        "parser": "REGEX",
        "language": lang_obj,
        "scope": scope,
        "detectionCriteria": {
            "fileType": _default_file_types_for_language(ln),
            "searchPattern": patterns,
        },
    }


def _parse_json_array_from_assistant_text(text: str) -> List[Dict[str, Any]]:
    """
    Parse a JSON array from model output; tolerate markdown fences and surrounding text.
    """
    stripped = (text or "").strip()
    candidates: List[str] = []
    if stripped:
        candidates.append(stripped)
    extracted = _extract_single_json_block_robust(stripped)
    if extracted:
        block, _ = extracted
        if block:
            candidates.append(block.strip())

    for candidate in candidates:
        try:
            data = json.loads(candidate)
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            continue

    start = stripped.find("[")
    end = stripped.rfind("]")
    if start != -1 and end > start:
        try:
            data = json.loads(stripped[start : end + 1])
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass

    raise ValueError("Model output did not contain a valid JSON array")


def _normalize_batch_rule_item_for_client(item: Any) -> Dict[str, Any]:
    """
    Java ``AssessmentRuleBatchItem`` expects ``ruleId``, ``detectionSchema``, and
    ``assessmentSchema``. ``detectionSchema`` uses the REGEX contract (status=active,
    parser=REGEX, detectionCriteria.fileType + searchPattern). Legacy model shapes
    are coerced into that structure.
    """
    if not isinstance(item, dict):
        return {
            "ruleId": None,
            "detectionSchema": {
                "ruleId": None,
                "ruleName": None,
                "version": "1.0",
                "status": "active",
                "parser": "REGEX",
                "language": {"name": "", "versions": []},
                "scope": ["function"],
                "detectionCriteria": {"fileType": [], "searchPattern": []},
            },
            "assessmentSchema": {},
        }

    det = item.get("detectionSchema")
    ass = item.get("assessmentSchema")
    body = {k: v for k, v in item.items() if k not in ("detectionSchema", "assessmentSchema")}
    rid = item.get("ruleId")
    if isinstance(ass, dict):
        assessment = dict(ass)
    else:
        assessment = dict(body)
    if rid is not None and assessment.get("ruleId") is None:
        assessment["ruleId"] = rid

    if isinstance(det, dict):
        if _is_new_detection_shape(det):
            detection = _finalize_new_detection_schema(det, body, rid)
        else:
            detection = _legacy_detection_to_new_schema(det, body, rid)
    else:
        detection = _legacy_detection_to_new_schema({}, body, rid)

    if rid is not None and detection.get("ruleId") is None:
        detection["ruleId"] = rid

    return {
        "ruleId": rid,
        "detectionSchema": detection,
        "assessmentSchema": assessment,
    }


def _normalize_batch_rules_for_client(rules: List[Any]) -> List[AssessmentRuleBatchItem]:
    return [
        AssessmentRuleBatchItem.model_validate(_normalize_batch_rule_item_for_client(r))
        for r in rules
    ]


def _apply_input_assessment_fields(
    items: List[AssessmentRuleBatchItem],
    sources: List[AssessmentRuleInputItem],
) -> None:
    """Copy client-owned category, issueType, and severity onto each assessment schema.

    A BOOSTER issue type has no remediation content; keep the key as an empty object.
    """
    for item, src in zip(items, sources):
        assessment = item.assessment_schema if isinstance(item.assessment_schema, dict) else {}
        assessment["category"] = src.category
        assessment["issueType"] = src.issue_type
        assessment["severity"] = src.severity
        if src.issue_type.strip().upper() == "BOOSTER":
            assessment["remediation"] = {}
        item.assessment_schema = assessment


def _log_detection_schema_summary(items: List[AssessmentRuleBatchItem]) -> None:
    """Log normalized detectionSchema fields per rule for observability."""
    for item in items:
        det = item.detection_schema if isinstance(item.detection_schema, dict) else {}
        dc = det.get("detectionCriteria") if isinstance(det.get("detectionCriteria"), dict) else {}
        patterns = dc.get("searchPattern")
        pattern_count = len(patterns) if isinstance(patterns, list) else 0
        logger.info(
            "[detection-schema] normalized ruleId=%s parser=%s status=%s "
            "language=%s fileTypes=%s searchPattern_count=%d",
            item.rule_id,
            det.get("parser"),
            det.get("status"),
            (det.get("language") or {}).get("name")
            if isinstance(det.get("language"), dict)
            else det.get("language"),
            dc.get("fileType"),
            pattern_count,
        )


def _split_rules_into_chunks(
    rules: List[AssessmentRuleInputItem], chunk_size: int
) -> List[List[AssessmentRuleInputItem]]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    return [rules[i : i + chunk_size] for i in range(0, len(rules), chunk_size)]


def _chunk_stream_file(output_dir: Path, chunk_index: int) -> Path:
    return (
        output_dir
        / "_claude"
        / f"assessment-rules-batch-stream-chunk-{chunk_index}.json"
    )


ProgressCallback = Callable[[AssessmentRulesBatchResponse], Awaitable[None]]


class AssessmentRulesBatchHandler(BaseOperationHandler):
    """
    Generates ASSESSMENT_RULES-shaped objects for each input catalog rule via the AI provider.

    Processes large batches in configurable chunks and can emit progressive partial results.
    """

    @property
    def max_rules(self) -> int:
        return settings.assessment_rules_batch.max_rules

    @property
    def chunk_size(self) -> int:
        return settings.assessment_rules_batch.chunk_size

    @property
    def max_parallel_chunks(self) -> int:
        """Per-batch chunk concurrency; LLM rate limiter still gates actual calls."""
        return max(1, settings.assessment_rules_batch.max_parallel_chunks)

    @property
    def rate_limit_max_retries(self) -> int:
        return max(0, settings.assessment_rules_batch.rate_limit_max_retries)

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        raise ValidationError(
            message="Assessment rules batch is only available via POST /assessment-rules-batch",
            field="operation",
        )

    def get_timeout(self) -> int:
        return settings.timeouts.assessment_rules_batch

    def validate_request(self, request: ClaudeCliRequest) -> None:
        pass

    def validate_batch_request(self, request: AssessmentRulesBatchRequest) -> None:
        if not request.analysis_id:
            raise ValidationError(message="analysisId is required", field="analysisId")
        try:
            SecurityValidator.validate_alphanumeric(request.analysis_id, "analysisId")
        except ValueError as e:
            raise ValidationError(message=str(e), field="analysisId") from e

        if len(request.rules) > self.max_rules:
            raise ValidationError(
                message=f"At most {self.max_rules} rules per request",
                field="rules",
            )

        for idx, rule in enumerate(request.rules):
            prefix = f"rules[{idx}]"
            if not rule.rule_id or not rule.rule_id.strip():
                raise ValidationError(
                    message="ruleId is required for each rule",
                    field=f"{prefix}.ruleId",
                )
            if not rule.name or not rule.name.strip():
                raise ValidationError(
                    message="name is required for each rule",
                    field=f"{prefix}.name",
                )
            if not rule.description or not rule.description.strip():
                raise ValidationError(
                    message="description is required for each rule",
                    field=f"{prefix}.description",
                )
            if not rule.domain or not rule.domain.strip():
                raise ValidationError(
                    message="domain is required for each rule",
                    field=f"{prefix}.domain",
                )
            if not rule.language or not rule.language.strip():
                raise ValidationError(
                    message="language is required for each rule",
                    field=f"{prefix}.language",
                )
            if not rule.category or not rule.category.strip():
                raise ValidationError(
                    message="category is required for each rule",
                    field=f"{prefix}.category",
                )
            if not rule.issue_type or not rule.issue_type.strip():
                raise ValidationError(
                    message="issueType is required for each rule",
                    field=f"{prefix}.issueType",
                )
            if not rule.severity or not rule.severity.strip():
                raise ValidationError(
                    message="severity is required for each rule",
                    field=f"{prefix}.severity",
                )

        if request.project_path:
            try:
                SecurityValidator.validate_path(request.project_path, "projectPath")
            except ValueError as e:
                raise ValidationError(
                    message=str(e), field="projectPath"
                ) from e

    async def _invoke_rules_chunk(
        self,
        *,
        provider: Any,
        chunk_rules: List[AssessmentRuleInputItem],
        chunk_index: int,
        chunk_count: int,
        analysis_id: str,
        project_path: str,
    ) -> tuple[Optional[List[AssessmentRuleBatchItem]], Optional[AssessmentRulesBatchResponse]]:
        """
        Run one LLM call for a chunk. Returns (rules_out, error_response).
        On success error_response is None; on failure rules_out is None.
        """
        chunk_rule_count = len(chunk_rules)
        rules_batch = format_rules_batch_for_prompt(chunk_rules)
        prompt_content = build_assessment_rules_batch_prompt(
            rules_batch=rules_batch,
            rule_count=chunk_rule_count,
        )
        output_base = Path(settings.workspace.base_path) / "assessment-rules-batch"
        output_dir = output_base / analysis_id
        stream_file = _chunk_stream_file(output_dir, chunk_index)

        @with_resilience(
            retry_attempts=3,
            # RateLimitError is handled by the dedicated outer retry loop below.
            retry_exceptions=(ProviderError, ConnectionError, TimeoutError),
            timeout_seconds=self.get_timeout(),
            operation_name="assessment_rules_batch",
        )
        async def invoke():
            llm_started_at, llm_started_mono = _log_timing_start(
                "LLM", analysis_id
            )
            detail = f"chunk={chunk_index}/{chunk_count} rules={chunk_rule_count}"
            try:
                return await provider.invoke_with_tools_agentic(
                    prompt=prompt_content,
                    project_path=project_path,
                    system_prompt=ASSESSMENT_RULES_BATCH_SYSTEM_PROMPT,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=False,
                    prepend_project_context=False,
                )
            except Exception as exc:
                _log_timing_complete(
                    "LLM",
                    analysis_id,
                    llm_started_at,
                    llm_started_mono,
                    status="error",
                    detail=f"{detail} reason={type(exc).__name__}",
                )
                raise
            else:
                _log_timing_complete(
                    "LLM",
                    analysis_id,
                    llm_started_at,
                    llm_started_mono,
                    status="success",
                    detail=detail,
                )

        stream_events = None
        rate_limit_attempts = 0
        max_rate_limit_retries = self.rate_limit_max_retries
        while True:
            try:
                stream_events = await invoke()
                break
            except RateLimitError as exc:
                rate_limit_attempts += 1
                if rate_limit_attempts > max_rate_limit_retries:
                    return None, AssessmentRulesBatchResponse(
                        status="error",
                        message=(
                            f"Chunk {chunk_index}/{chunk_count} failed: "
                            f"RateLimitError after {max_rate_limit_retries} retries"
                        ),
                        is_final=True,
                        chunk_index=chunk_index,
                        chunk_count=chunk_count,
                        analysis_id=analysis_id,
                        rule_count_expected=chunk_rule_count,
                        rule_count_returned=0,
                        rules=None,
                        error_details=str(exc),
                    )
                wait_s = _rate_limit_backoff_seconds(exc)
                logger.warning(
                    "[detection-schema] rate limited analysisId=%s chunk=%s/%s "
                    "attempt=%s/%s sleeping=%.1fs: %s",
                    analysis_id,
                    chunk_index,
                    chunk_count,
                    rate_limit_attempts,
                    max_rate_limit_retries,
                    wait_s,
                    exc,
                )
                await asyncio.sleep(wait_s)
            except Exception as exc:
                return None, AssessmentRulesBatchResponse(
                    status="error",
                    message=(
                        f"Chunk {chunk_index}/{chunk_count} failed: {type(exc).__name__}"
                    ),
                    is_final=True,
                    chunk_index=chunk_index,
                    chunk_count=chunk_count,
                    analysis_id=analysis_id,
                    rule_count_expected=chunk_rule_count,
                    rule_count_returned=0,
                    rules=None,
                    error_details=str(exc),
                )

        logger.info(
            "[detection-schema] LLM response analysisId=%s chunk=%s/%s stream_events=%s",
            analysis_id,
            chunk_index,
            chunk_count,
            len(stream_events),
        )

        assistant_text = StreamParser.extract_full_assistant_response(stream_events)
        raw_for_error: Optional[str] = (
            assistant_text[:20000] if len(assistant_text) > 20000 else assistant_text
        )

        parse_started_at, parse_started_mono = _log_timing_start("PARSE", analysis_id)
        try:
            rules_parsed = _parse_json_array_from_assistant_text(assistant_text)
        except ValueError as e:
            _log_timing_complete(
                "PARSE",
                analysis_id,
                parse_started_at,
                parse_started_mono,
                status="error",
                detail=f"chunk={chunk_index}/{chunk_count} error={e}",
            )
            logger.error(
                "[detection-schema] JSON parse failed analysisId=%s chunk=%s/%s: %s",
                analysis_id,
                chunk_index,
                chunk_count,
                e,
            )
            output_dir.mkdir(parents=True, exist_ok=True)
            stream_file.parent.mkdir(parents=True, exist_ok=True)
            await self.write_stream_output(stream_file, stream_events)
            return None, AssessmentRulesBatchResponse(
                status="error",
                message=(
                    f"Chunk {chunk_index}/{chunk_count}: model output was not a valid JSON array"
                ),
                is_final=True,
                chunk_index=chunk_index,
                chunk_count=chunk_count,
                analysis_id=analysis_id,
                rule_count_expected=chunk_rule_count,
                rule_count_returned=None,
                rules=None,
                raw_response=raw_for_error,
                output_file_path=str(stream_file),
                error_details=str(e),
            )

        _log_timing_complete(
            "PARSE",
            analysis_id,
            parse_started_at,
            parse_started_mono,
            status="success",
            detail=(
                f"chunk={chunk_index}/{chunk_count} parsed_count={len(rules_parsed)} "
                f"response_chars={len(assistant_text)}"
            ),
        )

        norm_started_at, norm_started_mono = _log_timing_start("NORMALIZE", analysis_id)
        rules_out = _normalize_batch_rules_for_client(rules_parsed)
        _apply_input_assessment_fields(rules_out, chunk_rules)
        _log_detection_schema_summary(rules_out)
        _log_timing_complete(
            "NORMALIZE",
            analysis_id,
            norm_started_at,
            norm_started_mono,
            status="success",
            detail=f"chunk={chunk_index}/{chunk_count} rule_count={len(rules_out)}",
        )

        returned = len(rules_out)
        if returned != chunk_rule_count:
            logger.warning(
                "[detection-schema] count mismatch analysisId=%s chunk=%s/%s "
                "expected=%s got=%s",
                analysis_id,
                chunk_index,
                chunk_count,
                chunk_rule_count,
                returned,
            )
            output_dir.mkdir(parents=True, exist_ok=True)
            stream_file.parent.mkdir(parents=True, exist_ok=True)
            await self.write_stream_output(stream_file, stream_events)
            return None, AssessmentRulesBatchResponse(
                status="error",
                message=(
                    f"Chunk {chunk_index}/{chunk_count}: JSON array length mismatch: "
                    f"expected {chunk_rule_count}, got {returned}"
                ),
                is_final=True,
                chunk_index=chunk_index,
                chunk_count=chunk_count,
                analysis_id=analysis_id,
                rule_count_expected=chunk_rule_count,
                rule_count_returned=returned,
                rules=rules_out,
                raw_response=None,
                output_file_path=str(stream_file),
                error_details=(
                    f"Expected exactly {chunk_rule_count} objects; model returned {returned}"
                ),
            )

        return rules_out, None

    async def _emit_progress(
        self,
        response: AssessmentRulesBatchResponse,
        on_progress: Optional[ProgressCallback],
    ) -> None:
        if on_progress is not None:
            await on_progress(response)

    async def execute_batch(
        self,
        request: AssessmentRulesBatchRequest,
        on_progress: Optional[ProgressCallback] = None,
    ) -> AssessmentRulesBatchResponse:
        self.validate_batch_request(request)

        batch_slot = _get_batch_request_semaphore()
        logger.info(
            "[detection-schema] waiting for batch request slot analysisId=%s "
            "max_concurrent_requests=%s",
            request.analysis_id,
            settings.assessment_rules_batch.max_concurrent_requests,
        )
        async with batch_slot:
            logger.info(
                "[detection-schema] acquired batch request slot analysisId=%s",
                request.analysis_id,
            )
            return await self._execute_batch_with_slot(request, on_progress)

    async def _execute_batch_with_slot(
        self,
        request: AssessmentRulesBatchRequest,
        on_progress: Optional[ProgressCallback] = None,
    ) -> AssessmentRulesBatchResponse:
        rule_count = len(request.rules)
        project_path = resolve_secure_work_directory(
            request.analysis_id, request.project_path
        )
        chunk_size = self.chunk_size
        max_parallel = self.max_parallel_chunks
        chunks = _split_rules_into_chunks(request.rules, chunk_size)
        chunk_count = len(chunks)

        batch_started_at, batch_started_mono = _log_timing_start(
            "BATCH", request.analysis_id
        )
        logger.info(
            "[detection-schema] batch context analysisId=%s rule_count=%s "
            "chunk_size=%s chunk_count=%s max_parallel_chunks=%s project_path=%s",
            request.analysis_id,
            rule_count,
            chunk_size,
            chunk_count,
            max_parallel,
            project_path,
        )

        rules_by_chunk: Dict[int, List[AssessmentRuleBatchItem]] = {}
        rules_completed_so_far = 0
        successful_chunk_count = 0

        try:
            provider = await self.provider_factory.get_provider()
            semaphore = asyncio.Semaphore(max_parallel)
            progress_lock = asyncio.Lock()

            async def run_chunk(
                chunk_index: int,
                chunk_rules: List[AssessmentRuleInputItem],
            ) -> Tuple[
                int,
                Optional[List[AssessmentRuleBatchItem]],
                Optional[AssessmentRulesBatchResponse],
            ]:
                async with semaphore:
                    chunk_started_at, chunk_started_mono = _log_timing_start(
                        "CHUNK", request.analysis_id
                    )
                    logger.info(
                        "[detection-schema] chunk START analysisId=%s "
                        "chunk=%s/%s rules=%s",
                        request.analysis_id,
                        chunk_index,
                        chunk_count,
                        len(chunk_rules),
                    )
                    rules_out, error_response = await self._invoke_rules_chunk(
                        provider=provider,
                        chunk_rules=chunk_rules,
                        chunk_index=chunk_index,
                        chunk_count=chunk_count,
                        analysis_id=request.analysis_id,
                        project_path=project_path,
                    )
                    if error_response is not None:
                        _log_timing_complete(
                            "CHUNK",
                            request.analysis_id,
                            chunk_started_at,
                            chunk_started_mono,
                            status="error",
                            detail=f"chunk={chunk_index}/{chunk_count}",
                        )
                        return chunk_index, None, error_response

                    _log_timing_complete(
                        "CHUNK",
                        request.analysis_id,
                        chunk_started_at,
                        chunk_started_mono,
                        status="success",
                        detail=(
                            f"chunk={chunk_index}/{chunk_count} "
                            f"rules={len(rules_out)}"
                        ),
                    )
                    return chunk_index, rules_out, None

            pending: Dict[asyncio.Task, int] = {
                asyncio.create_task(
                    run_chunk(chunk_index, chunk_rules),
                    name=f"assessment-rules-chunk-{chunk_index}",
                ): chunk_index
                for chunk_index, chunk_rules in enumerate(chunks, start=1)
            }

            while pending:
                done, _ = await asyncio.wait(
                    pending.keys(),
                    return_when=asyncio.FIRST_COMPLETED,
                )
                successes: List[
                    Tuple[int, List[AssessmentRuleBatchItem]]
                ] = []
                errors: List[Tuple[int, AssessmentRulesBatchResponse]] = []

                for task in done:
                    chunk_index_hint = pending.pop(task, 0)
                    try:
                        chunk_index, rules_out, error_response = task.result()
                    except asyncio.CancelledError:
                        continue
                    except Exception as exc:
                        errors.append(
                            (
                                chunk_index_hint,
                                AssessmentRulesBatchResponse(
                                    status="error",
                                    message=(
                                        f"Chunk {chunk_index_hint}/{chunk_count} "
                                        f"failed: {type(exc).__name__}"
                                    ),
                                    is_final=True,
                                    chunk_index=chunk_index_hint or None,
                                    chunk_count=chunk_count,
                                    analysis_id=request.analysis_id,
                                    rule_count_expected=rule_count,
                                    rule_count_returned=0,
                                    rules=None,
                                    error_details=str(exc),
                                ),
                            )
                        )
                        continue
                    if error_response is not None:
                        errors.append((chunk_index, error_response))
                    else:
                        successes.append((chunk_index, rules_out or []))

                # Apply successful completions first so fail-fast reports accurate progress.
                # Emit in chunk_index order when several finish in the same wait wave.
                for chunk_index, rules_out in sorted(successes, key=lambda item: item[0]):
                    async with progress_lock:
                        rules_by_chunk[chunk_index] = rules_out
                        rules_completed_so_far += len(rules_out)
                        successful_chunk_count += 1
                        is_final = successful_chunk_count == chunk_count
                        so_far = rules_completed_so_far
                        chunk_response = AssessmentRulesBatchResponse(
                            status="success" if is_final else "partial",
                            message=(
                                f"Generated chunk {chunk_index}/{chunk_count} "
                                f"({len(rules_out)} rule(s))"
                                + ("; batch complete" if is_final else "")
                            ),
                            is_final=is_final,
                            chunk_index=chunk_index,
                            chunk_count=chunk_count,
                            analysis_id=request.analysis_id,
                            rule_count_expected=rule_count,
                            rule_count_returned=len(rules_out),
                            rules_completed_so_far=so_far,
                            rules=rules_out,
                            raw_response=None,
                            output_file_path=None,
                            error_details=None,
                        )
                    await self._emit_progress(chunk_response, on_progress)

                if errors:
                    chunk_index, error_response = errors[0]
                    error_response.rule_count_expected = rule_count
                    error_response.rules_completed_so_far = rules_completed_so_far
                    for remaining in pending:
                        remaining.cancel()
                    if pending:
                        await asyncio.gather(
                            *pending.keys(),
                            return_exceptions=True,
                        )
                        pending.clear()
                    _log_timing_complete(
                        "BATCH",
                        request.analysis_id,
                        batch_started_at,
                        batch_started_mono,
                        status="error",
                        detail=(
                            f"reason=chunk_failed chunk={chunk_index}/{chunk_count} "
                            f"completed={rules_completed_so_far}"
                        ),
                    )
                    await self._emit_progress(error_response, on_progress)
                    return error_response

            all_rules_out: List[AssessmentRuleBatchItem] = []
            for idx in range(1, chunk_count + 1):
                all_rules_out.extend(rules_by_chunk.get(idx, []))

            total_sec = _log_timing_complete(
                "BATCH",
                request.analysis_id,
                batch_started_at,
                batch_started_mono,
                status="success",
                detail=f"rules={len(all_rules_out)} chunks={chunk_count}",
            )
            logger.info(
                "[detection-schema] batch summary analysisId=%s total_duration_sec=%.2f "
                "chunks=%s rules=%s",
                request.analysis_id,
                total_sec,
                chunk_count,
                len(all_rules_out),
            )
            return AssessmentRulesBatchResponse(
                status="success",
                message=f"Generated {len(all_rules_out)} assessment rule object(s)",
                is_final=True,
                chunk_index=chunk_count,
                chunk_count=chunk_count,
                analysis_id=request.analysis_id,
                rule_count_expected=rule_count,
                rule_count_returned=len(all_rules_out),
                rules_completed_so_far=len(all_rules_out),
                rules=all_rules_out,
                raw_response=None,
                output_file_path=None,
                error_details=None,
            )

        except Exception as e:
            error_msg = f"Assessment rules batch failed: {str(e)}"
            _log_timing_complete(
                "BATCH",
                request.analysis_id,
                batch_started_at,
                batch_started_mono,
                status="error",
                detail=f"reason={type(e).__name__}",
            )
            logger.error(
                "[detection-schema] batch failed analysisId=%s: %s",
                request.analysis_id,
                error_msg,
                exc_info=True,
            )
            completed = sum(len(v) for v in rules_by_chunk.values())
            failure = AssessmentRulesBatchResponse(
                status="error",
                message=error_msg,
                is_final=True,
                chunk_index=1,
                chunk_count=chunk_count,
                analysis_id=request.analysis_id,
                rule_count_expected=rule_count,
                rule_count_returned=0,
                rules_completed_so_far=completed,
                rules=None,
                error_details=str(e),
            )
            await self._emit_progress(failure, on_progress)
            return failure
