"""
Summary Handler - Create comprehensive summary of containerization process.

Analyzes containerization analysis, selective fix, and generation reports to create
an executive summary with metrics, recommendations, and risk assessment.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience


logger = logging.getLogger(__name__)
settings = get_settings()


class SummaryHandler(BaseOperationHandler):
    """
    Handler for 'summary' operation.

    Creates comprehensive summary of containerization process by analyzing:
    - Containerization analysis report (blockers identified)
    - Selective fix report (blockers fixed)
    - Generation report (artifacts created)

    Generates executive summary with:
    - Containerization readiness assessment
    - Effort and complexity metrics
    - Success rate and project health indicators
    - Technical challenges and solutions
    - Recommendations and risk assessment

    Timeout: uses settings.timeouts.default (3000s)
    Output: containerization/{analysisId}/summary-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for summary operation.

        Returns:
            Timeout in seconds (uses settings.timeouts.default)
        """
        return settings.timeouts.default

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate summary request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Summary requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for summary operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute summary generation operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with summary report

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(f"Starting containerization summary generation: analysisId={request.analysis_id}")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(request, "summary-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using resilience patterns
            logger.info("Invoking AI provider for summary generation")
            logger.info("AI will analyze analysis, fix, and generation reports to create comprehensive summary")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="summary_operation"
            )
            async def invoke_summary():
                # Use direct single-agent execution (bypass graph orchestrator)
                logger.info("Using direct single-agent execution (bypassing graph orchestrator)")
                events = await provider.invoke_with_tools_agentic(
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True
                )
                return events

            # Execute invocation
            stream_events = await invoke_summary()

            logger.info(f"Summary generation completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="summary-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")


            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Summary generation failed"
                logger.error(f"Summary generation operation failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Summary generation operation completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Summary generation completed successfully"
            )

        except Exception as e:
            error_msg = f"Summary generation operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise
