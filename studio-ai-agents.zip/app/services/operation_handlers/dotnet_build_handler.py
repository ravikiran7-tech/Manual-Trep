"""
.NET Build Handler - .NET build compilation operation.

Executes .NET builds with specific framework versions.
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class DotnetBuildHandler(BaseOperationHandler):
    """
    Handler for 'dotnet-build-compilation' operation.

    Executes .NET builds with specific framework versions:
    - .NET 6.0, 7.0, 8.0, 10.0 support
    - dotnet build execution
    - Compilation error extraction
    - NuGet package restoration
    - Multi-target framework support

    Timeout: 1800s (30 minutes)
    Output: validation/{analysisId}/build-compilation-stream.json
    """

    # Supported .NET versions
    SUPPORTED_DOTNET_VERSIONS = ["6.0", "7.0", "8.0", "10.0"]

    def get_timeout(self) -> int:
        """
        Get timeout for .NET build operation.

        Returns:
            Timeout in seconds (1800s = 30 minutes)
        """
        return settings.timeouts.build_validation

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate .NET build request.

        Args:
            request: Build request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # .NET build requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for dotnet-build-compilation operation",
                field="prompt"
            )

        # Validate .NET version if provided
        if request.dotnet_version:
            if request.dotnet_version not in self.SUPPORTED_DOTNET_VERSIONS:
                raise ValidationError(
                    message=f"Unsupported .NET version: {request.dotnet_version}. "
                           f"Supported versions: {self.SUPPORTED_DOTNET_VERSIONS}",
                    field="dotnetVersion"
                )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute .NET build operation.

        Args:
            request: Build request

        Returns:
            Build compilation response with results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        dotnet_version = request.dotnet_version or "8.0"  # Default to .NET 8.0

        logger.info(
            f"Starting .NET build: analysisId={request.analysis_id}, "
            f"dotnetVersion={dotnet_version}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Enhance prompt with .NET version context
            enhanced_prompt = self._enhance_prompt_with_dotnet_context(
                prompt_content,
                dotnet_version
            )

            # Build output path
            output_path = self.build_output_path(
                request,
                "build-compilation-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Create validation directory structure
            self._create_validation_directories(request)

            # Execute with provider
            logger.info("Invoking AI provider for .NET build")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="dotnet_build_operation"
            )
            async def invoke_dotnet_build():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=enhanced_prompt,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_dotnet_build()

            logger.info(f".NET build completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write full JSON output to build-compilation.json
            reports_dir = self._get_reports_dir(request)
            compilation_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=reports_dir,
                result_filename="build-compilation.json"
            )

            if compilation_path:
                logger.info(f"build-compilation.json written to: {compilation_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Transform build-compilation.json into the flat build-result.json Java expects
            build_result_path = None
            build_status = "SUCCESS"
            if compilation_path:
                build_result_path, build_status = await self._write_build_result_json(
                    compilation_path, reports_dir
                )

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           ".NET build failed"
                logger.error(f".NET build operation failed: {error_msg}")
                return ClaudeCliResponse(
                    status="error",
                    message=error_msg,
                    exit_code=1,
                    output_file_path=str(build_result_path) if build_result_path else None,
                    summary={"buildStatus": "FAILED"}
                )

            top_status = "success" if build_status == "SUCCESS" else "partial"
            logger.info(f".NET build operation completed: buildStatus={build_status}")
            return ClaudeCliResponse(
                status=top_status,
                message=f".NET build completed successfully with .NET {dotnet_version}",
                exit_code=0,
                output_file_path=str(build_result_path) if build_result_path else str(output_path),
                summary={"buildStatus": build_status}
            )

        except Exception as e:
            error_msg = f".NET build operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def _enhance_prompt_with_dotnet_context(
        self,
        prompt: str,
        dotnet_version: str
    ) -> str:
        """
        Enhance prompt with .NET version context.

        Args:
            prompt: Original prompt content
            dotnet_version: Requested .NET version (e.g., "8.0")

        Returns:
            Enhanced prompt with .NET build instructions
        """
        dotnet_context = f"""IMPORTANT: .NET Build Setup

Target .NET version: {dotnet_version}

Before running build commands, verify the .NET environment:

1. Check .NET SDK version:
   dotnet --version

2. Restore NuGet packages:
   dotnet restore

3. Build the project:
   dotnet build --configuration Release

4. Run tests (if applicable):
   dotnet test

Key considerations:
- Ensure project targets .NET {dotnet_version} or compatible version
- Check for deprecated APIs
- Verify NuGet package compatibility
- Look for build warnings and errors
- Assess multi-target framework issues

---

"""
        return dotnet_context + prompt

    async def _write_build_result_json(
        self,
        compilation_path: Path,
        reports_dir: Path
    ):
        """
        Transform build-compilation.json (full schema) into the flat
        build-result.json that Java's BuildResult class expects.

        Expected output fields:
            exitCode, success, buildStatus, compilationErrors,
            testFailures, errors, warnings, totalTime

        Args:
            compilation_path: Path to build-compilation.json
            reports_dir: Directory to write build-result.json into

        Returns:
            Tuple of (Path to build-result.json, buildStatus string)
        """
        import json as _json

        try:
            with open(compilation_path, "r", encoding="utf-8") as f:
                compilation_json = _json.load(f)

            summary = compilation_json.get("summary", {})
            issues  = compilation_json.get("issues", [])
            failed  = compilation_json.get("failedIssues", [])
            meta    = compilation_json.get("metadata", {})

            build_status = summary.get("buildStatus", "SUCCESS").upper()

            # Collect error messages from issues and failed issues
            compilation_errors = [
                i["errorMessage"] for i in issues if i.get("errorMessage")
            ] + [
                i.get("errorDetails") or i.get("title", "")
                for i in failed if i
            ]

            # Convert executionTimeMs to "Xm Ys" string
            exec_ms = meta.get("executionTimeMs", 0) or 0
            if exec_ms >= 60000:
                total_time = f"{exec_ms // 60000}m {(exec_ms % 60000) // 1000}s"
            elif exec_ms > 0:
                total_time = f"{exec_ms // 1000}s"
            else:
                total_time = "0s"

            build_result = {
                "exitCode":          0 if build_status == "SUCCESS" else 1,
                "success":           build_status == "SUCCESS",
                "buildStatus":       build_status,
                "compilationErrors": compilation_errors,
                "testFailures":      [],
                "errors":            summary.get("issuesFailed", 0),
                "warnings":          summary.get("issuesSkipped", 0),
                "totalTime":         total_time,
            }

            result_path = reports_dir / "build-result.json"
            with open(result_path, "w", encoding="utf-8") as f:
                _json.dump(build_result, f, indent=2)

            logger.info(f"build-result.json written to: {result_path}")
            return result_path, build_status

        except Exception as e:
            logger.error(f"Failed to write build-result.json: {e}", exc_info=True)
            return None, "SUCCESS"

    def _get_reports_dir(self, request: ClaudeCliRequest) -> Path:
        """
        Return the reports/ directory for this analysis.

        Path: {workspace}/validation/{analysisId}/reports/

        Args:
            request: Build request

        Returns:
            Path to the reports directory
        """
        return Path(settings.workspace.base_path) / "validation" / request.analysis_id / "reports"

    def _create_validation_directories(self, request: ClaudeCliRequest):
        """
        Create validation directory structure for .NET builds.

        Creates:
        - validation/{analysisId}/
        - validation/{analysisId}/build-artifacts/
        - validation/{analysisId}/_claude/
        - validation/{analysisId}/reports/

        Args:
            request: Build request
        """
        base_dir = Path(settings.workspace.base_path) / "validation" / request.analysis_id

        subdirs = ["build-artifacts", "_claude", "reports"]
        for subdir in subdirs:
            dir_path = base_dir / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {dir_path}")

        logger.info(f".NET build directories created: {base_dir}")

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for .NET build.

        Overrides base handler to use 'validation' directory.

        Args:
            request: Build request

        Returns:
            Output directory name
        """
        return "validation"
