"""
Build Compilation Handler - Java build validation operation.

Executes Maven/Gradle builds with specific Java versions to validate compilation.
Equivalent to Java's ValidationClaudeServiceLinux/Windows and BuildCompilationService.
"""
import json
import logging
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError


logger = logging.getLogger(__name__)
settings = get_settings()


class BuildCompilationHandler(BaseOperationHandler):
    """
    Handler for 'build-compilation' operation.

    Executes build compilation with specific Java versions using SDKMAN.
    Supports Maven (Gradle support pending).

    Key Features:
    - Java version management (8, 11, 17, 21, 25)
    - SDKMAN integration for Java version switching
    - Maven build execution
    - Compilation error extraction
    - Test failure detection

    Timeout: 1800s (30 minutes)
    Output: validation/{analysisId}/build-compilation-stream.json

    Equivalent to Java's:
    - ValidationClaudeServiceLinux
    - ValidationClaudeServiceWindows (WSL)
    - BuildCompilationService
    """

    # Supported Java versions mapped to SDKMAN versions
    JAVA_VERSION_MAPPING = {
        "8": "8.0.422-tem",
        "1.8": "8.0.422-tem",
        "11": "11.0.25-tem",
        "17": "17.0.13-tem",
        "21": "21.0.5-tem",
        "25": "25.0.4-tem"
    }

    def __init__(self, provider_factory):
        """
        Initialize build compilation handler.

        Args:
            provider_factory: Provider factory for creating AI clients
        """
        super().__init__(provider_factory)
        self.sdkman_init_script = Path.home() / ".sdkman" / "bin" / "sdkman-init.sh"

    def get_timeout(self) -> int:
        """
        Get timeout for build compilation operation.

        Returns:
            Timeout in seconds (1800s = 30 minutes)
        """
        return settings.timeouts.build_validation

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate build compilation request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Build compilation requires a prompt
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for build-compilation operation",
                field="prompt"
            )

        # Validate Java version
        if not request.java_version:
            raise ValidationError(
                message="Java version is required for build-compilation. "
                       f"Supported versions: {list(self.JAVA_VERSION_MAPPING.keys())}",
                field="javaVersion"
            )

        if request.java_version not in self.JAVA_VERSION_MAPPING:
            raise ValidationError(
                message=f"Unsupported Java version: {request.java_version}. "
                       f"Supported versions: {list(self.JAVA_VERSION_MAPPING.keys())}",
                field="javaVersion"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute build compilation operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with build results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(
            f"Starting build compilation: analysisId={request.analysis_id}, "
            f"javaVersion={request.java_version}"
        )

        # Validate request
        self.validate_request(request)

        try:
            # Get SDKMAN version for requested Java version
            sdkman_version = self.JAVA_VERSION_MAPPING[request.java_version]
            logger.info(f"Using SDKMAN Java version: {sdkman_version}")

            # Verify Java version is installed
            self._verify_java_version_installed(sdkman_version)

            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Enhance prompt with Java version context
            enhanced_prompt = self._enhance_prompt_with_java_context(
                prompt_content,
                request.java_version,
                sdkman_version
            )

            # Build output path
            output_path = self.build_output_path(request, "build-compilation-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Create validation directory structure
            self._create_validation_directories(request)

            # Execute with provider using build timeout
            logger.info("Invoking AI provider for build compilation")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 1800s timeout
                operation_name="build_compilation_operation"
            )
            async def invoke_build_compilation():
                # Use helper method that chooses graph orchestration or max_iterations
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=enhanced_prompt,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

                # Return events list
                return events

            # Execute invocation
            stream_events = await invoke_build_compilation()

            logger.info(f"Build compilation completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract the LLM's JSON output into build-compilation.json
            reports_dir = self._get_reports_dir(request)
            compilation_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=reports_dir,
                result_filename="build-compilation.json"
            )

            if compilation_path:
                logger.info(f"build-compilation.json written to: {compilation_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Transform build-compilation.json into the flat build-result.json Java expects
            build_result_path = None
            build_status = "SUCCESS"
            if compilation_path:
                build_result_path, build_status = await self._write_build_result_json(
                    compilation_path, reports_dir
                )

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or \
                           "Build compilation failed"
                logger.error(f"Build compilation operation failed: {error_msg}")
                return ClaudeCliResponse(
                    status="error",
                    message=error_msg,
                    exit_code=1,
                    output_file_path=str(build_result_path) if build_result_path else None,
                    summary={"buildStatus": "FAILED"}
                )

            top_status = "success" if build_status == "SUCCESS" else "partial"
            logger.info(f"Build compilation completed: buildStatus={build_status}")
            return ClaudeCliResponse(
                status=top_status,
                message=f"Build compilation completed successfully with Java {request.java_version}",
                exit_code=0,
                output_file_path=str(build_result_path) if build_result_path else str(output_path),
                summary={"buildStatus": build_status}
            )

        except Exception as e:
            error_msg = f"Build compilation operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    def _verify_java_version_installed(self, sdkman_version: str):
        """
        Verify that the requested Java version is installed via SDKMAN.

        Args:
            sdkman_version: SDKMAN version string (e.g., "17.0.13-tem")

        Raises:
            ValidationError: If Java version is not installed
        """
        java_home = Path.home() / ".sdkman" / "candidates" / "java" / sdkman_version

        if not java_home.exists():
            raise ValidationError(
                message=f"Java version {sdkman_version} is not installed via SDKMAN. "
                       f"Please install it using: sdk install java {sdkman_version}",
                field="javaVersion"
            )

        logger.info(f"Java version verified: {sdkman_version} at {java_home}")

    def _enhance_prompt_with_java_context(
        self,
        prompt: str,
        java_version: str,
        sdkman_version: str
    ) -> str:
        """
        Enhance prompt with Java version context.

        Prepends system instructions for Java version setup before executing build.

        Args:
            prompt: Original prompt content
            java_version: Requested Java version (e.g., "17")
            sdkman_version: SDKMAN version string (e.g., "17.0.13-tem")

        Returns:
            Enhanced prompt with Java setup instructions
        """
        java_setup_context = f"""IMPORTANT: Java Version Setup

Before running any build commands (Maven/Gradle), you MUST configure the Java environment:

1. Source SDKMAN:
   source ~/.sdkman/bin/sdkman-init.sh

2. Switch to Java {java_version}:
   sdk use java {sdkman_version}

3. Verify Java version:
   java -version

4. Then proceed with the build:
   mvn clean install
   OR
   gradle build

This ensures the build runs with Java {java_version} as requested.

---

"""
        return java_setup_context + prompt

    def _create_validation_directories(self, request: ClaudeCliRequest):
        """
        Create validation directory structure.

        Creates:
        - validation/{analysisId}/
        - validation/{analysisId}/artifacts/
        - validation/{analysisId}/_claude/
        - validation/{analysisId}/reports/

        Args:
            request: Claude CLI request
        """
        base_dir = Path(settings.workspace.base_path) / "validation" / request.analysis_id

        # Create subdirectories
        subdirs = ["artifacts", "_claude", "reports"]
        for subdir in subdirs:
            dir_path = base_dir / subdir
            dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {dir_path}")

        logger.info(f"Validation directories created: {base_dir}")

    def _get_reports_dir(self, request: ClaudeCliRequest) -> Path:
        """Return the reports/ directory: {workspace}/validation/{analysisId}/reports/"""
        return Path(settings.workspace.base_path) / "validation" / request.analysis_id / "reports"

    async def _write_build_result_json(
        self,
        compilation_path: Path,
        reports_dir: Path
    ) -> Tuple[Optional[Path], str]:
        """
        Transform build-compilation.json into the flat build-result.json Java expects.

        Returns:
            Tuple of (Path to build-result.json or None, buildStatus string)
        """
        try:
            with open(compilation_path, "r", encoding="utf-8") as f:
                compilation_json = json.load(f)

            summary = compilation_json.get("summary", {})
            issues  = compilation_json.get("issues", [])
            failed  = compilation_json.get("failedIssues", [])
            meta    = compilation_json.get("metadata", {})

            build_status = summary.get("buildStatus", "SUCCESS").upper()

            compilation_errors = [
                i["errorMessage"] for i in issues if i.get("errorMessage")
            ] + [
                i.get("errorDetails") or i.get("title", "")
                for i in failed if i
            ]

            exec_ms = meta.get("executionTimeMs", 0) or 0
            if exec_ms >= 60000:
                total_time = f"{exec_ms // 60000}m {(exec_ms % 60000) // 1000}s"
            elif exec_ms > 0:
                total_time = f"{exec_ms // 1000}s"
            else:
                total_time = "0s"

            build_result = {
                "exitCode":          0 if build_status == "SUCCESS" else 1,
                "success":           build_status == "SUCCESS",
                "buildStatus":       build_status,
                "compilationErrors": compilation_errors,
                "testFailures":      [],
                "errors":            summary.get("issuesFailed", 0),
                "warnings":          summary.get("issuesSkipped", 0),
                "totalTime":         total_time,
            }

            result_path = reports_dir / "build-result.json"
            with open(result_path, "w", encoding="utf-8") as f:
                json.dump(build_result, f, indent=2)

            logger.info(f"build-result.json written to: {result_path}")
            return result_path, build_status

        except Exception as e:
            logger.error(f"Failed to write build-result.json: {e}", exc_info=True)
            return None, "SUCCESS"

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Get output directory for build compilation.

        Overrides base handler to use 'validation' directory.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name
        """
        return "validation"
