"""
Base operation handler for all Claude CLI operation types.

Defines the abstract interface and common functionality for operation handlers.
All 11 operation types inherit from this base class.
"""
import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable
from contextlib import asynccontextmanager

from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.services.provider_factory import ProviderFactory, get_provider_factory
from app.core.config import get_settings
from app.core.security import SecurityValidator
from app.core.exceptions import (
    ValidationError,
    FileOperationError,
    OperationTimeoutError
)
from app.utils.transformation_utils import merge_fix_result


logger = logging.getLogger(__name__)
settings = get_settings()


class BaseOperationHandler(ABC):
    """
    Abstract base class for operation handlers.

    Defines common patterns for:
    - Output directory determination
    - Timeout management
    - Stream processing and file writing
    - Security validation
    - Provider selection

    Concrete handlers must implement:
    - execute(): Main operation logic
    - get_timeout(): Operation-specific timeout
    - validate_request(): Request validation

    Example:
        class AnalysisHandler(BaseOperationHandler):
            async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
                # Implementation
                pass

            def get_timeout(self) -> int:
                return settings.timeouts.default

            def validate_request(self, request: ClaudeCliRequest):
                # Validation logic
                pass
    """

    def __init__(
        self,
        provider_factory: Optional[ProviderFactory] = None
    ):
        """
        Initialize operation handler.

        Args:
            provider_factory: Provider factory for creating AI clients
        """
        self.provider_factory = provider_factory or get_provider_factory()
        self.settings = settings

    @abstractmethod
    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute the operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with operation results

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        pass

    @abstractmethod
    def get_timeout(self) -> int:
        """
        Get operation-specific timeout in seconds.

        Returns:
            Timeout in seconds
        """
        pass

    @abstractmethod
    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate request parameters.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        pass

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        """
        Determine output directory based on operation type.

        Maps operation types to output directory names matching Java's logic.

        Args:
            request: Claude CLI request

        Returns:
            Output directory name

        Example:
            analysis          -> versionUpgrade
            fix-upgrade       -> versionUpgrade
            build-compilation -> validation
g            test-creation     -> validation
            cloudreadiness-*  -> cloudreadiness
        """
        operation = request.operation

        if operation in ["analysis", "fix-upgrade"]:
            return "versionUpgrade"
        elif operation in ["build-compilation", "test-execution", "test-creation"]:
            return "validation"
        elif operation in ["cloudreadiness-analysis", "cloudreadiness-fix"]:
            return "cloudreadiness"
        elif operation in ["db-code-modernize-analysis", "db-code-modernize-fix"]:
            return "db-code-modernize"
        elif operation == "schema-modernization":
            return "schema-modernization"
        elif operation in ["dotnet-build-compilation", "dotnet-test-execution"]:
            return "dotnet-validation"
        elif operation in ["test-executionbuild"]:
            return "validation"
        elif operation in ["containerization-analysis", "selective-fix", "generation", "summary"]:
            return "containerization"
        else:
            # Default fallback
            logger.warning(f"Unknown operation type: {operation}, using default directory")
            return "containerization"

    def build_output_path(
        self,
        request: ClaudeCliRequest,
        filename: str = "stream.json"
    ) -> Path:
        """
        Build full output file path.

        Constructs path: {workspace}/{operation_dir}/{analysis_id}/{filename}

        Args:
            request: Claude CLI request
            filename: Output filename (default: stream.json)

        Returns:
            Full output file path

        Example:
            /studio-app/claude-workspace/versionUpgrade/analysis-123/_claude/stream.json
        """
        # Use claudeWorkspace from request if provided, otherwise use default workspace
        if request.claude_workspace:
            output_base = Path(request.claude_workspace)
            logger.debug(f"Using claudeWorkspace from request: {output_base}")
        else:
            output_base = Path(settings.workspace.base_path)
            logger.debug(f"Using default workspace from settings: {output_base}")
        
        operation_dir = self.get_output_directory(request)
        analysis_id = request.analysis_id or "default"

        output_path = output_base / operation_dir / analysis_id / "_claude" / filename

        # Ensure parent directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        return output_path

    async def write_stream_output(
        self,
        output_path: Path,
        stream_events: List[Dict[str, Any]]
    ):
        """
        Write stream events to output file.

        Writes events as JSON array to match Java's stream.json format.

        Args:
            output_path: Output file path
            stream_events: List of stream events

        Raises:
            FileOperationError: If file write fails
        """
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, 'w') as f:
                json.dump(stream_events, f, indent=2)

            logger.info(f"Stream output written: {output_path} ({len(stream_events)} events)")

        except Exception as e:
            error_msg = f"Failed to write stream output: {str(e)}"
            logger.error(error_msg)
            raise FileOperationError(
                message=error_msg,
                file_path=str(output_path),
                details=str(e)
            )

    @asynccontextmanager
    async def stream_output_streaming(self, output_path: Path):
        """
        Context manager for writing stream events live to a file as they are produced.

        Opens the file, writes '[' then yields a callback. Each call to the callback
        appends one event (JSON) to the file. On exit writes ']'. This allows
        the stream file to be read while the operation is still running.

        Yields:
            on_event: Callable[[Dict], None] - call with each event as it is produced.
        """
        output_path.parent.mkdir(parents=True, exist_ok=True)
        first = [True]

        def on_event(event: Dict[str, Any]) -> None:
            try:
                with open(output_path, "a", encoding="utf-8") as f:
                    if not first[0]:
                        f.write(",\n  ")
                    else:
                        f.write("[\n  ")
                    first[0] = False
                    f.write(json.dumps(event, ensure_ascii=False))
                    f.flush()
            except Exception as e:
                logger.warning(f"Failed to append event to stream file: {e}")

        try:
            # Truncate so we start with a fresh file
            output_path.write_text("", encoding="utf-8")
            yield on_event
        finally:
            if not first[0]:
                with open(output_path, "a", encoding="utf-8") as f:
                    f.write("\n]\n")
            else:
                with open(output_path, "a", encoding="utf-8") as f:
                    f.write("[]\n")

    async def collect_stream(
        self,
        events: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Return events list (no longer needs to collect from stream).

        This method is kept for backwards compatibility but now just returns
        the events list directly since providers return lists instead of streams.

        Args:
            events: List of events from provider

        Returns:
            List of all events
        """
        logger.debug(f"Received {len(events)} events from provider")
        return events

    def validate_common_fields(self, request: ClaudeCliRequest):
        """
        Validate common request fields.

        Validates fields that are common to most/all operations:
        - project_path
        - analysis_id (if present)

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate project path
        if not request.project_path:
            raise ValidationError(
                message="Project path is required",
                field="projectPath"
            )

        try:
            SecurityValidator.validate_path(request.project_path, "project")
        except ValueError as e:
            raise ValidationError(
                message=str(e),
                field="projectPath"
            )

        # Validate analysis ID if present
        if request.analysis_id:
            try:
                SecurityValidator.validate_alphanumeric(request.analysis_id, "analysisId")
            except ValueError as e:
                raise ValidationError(
                    message=str(e),
                    field="analysisId"
                )

    def _enhance_prompt_with_json_output_requirement(
        self,
        user_prompt: str,
        operation: str
    ) -> str:
        """
        Enhance user prompt with critical system requirements.
        
        Adds instructions for:
        1. Rules enforcement (if rules file mentioned in prompt)
        2. JSON output format (always display in text response)
        
        Args:
            user_prompt: Original prompt from request.prompt file
            operation: Operation type
            
        Returns:
            Enhanced prompt with system requirements
        """
        
        # Minimal system instructions covering BOTH concerns
        system_instructions = """
═══════════════════════════════════════════════════════════════════════════════
CRITICAL SYSTEM REQUIREMENTS:

1. RULES ENFORCEMENT (If rules file is mentioned in prompt below):
   - Read and apply ONLY the rules specified in that file
   - Follow detection patterns and remediation from rules exactly
   - Do NOT use default assumptions

2. JSON OUTPUT FORMAT:
   - At the END, output JSON summary in your TEXT RESPONSE
   - Wrap in ```json code blocks like this:
   
   ```json
   {"analysisId": "...", "summary": {...}, "issues": [...]}
   ```
   
   - Display in conversational text, NOT using code_editor to write files
   - User must SEE the JSON directly in your response

═══════════════════════════════════════════════════════════════════════════════

""".strip()
        
        enhanced_prompt = f"{system_instructions}\n\n{user_prompt}"
        
        logger.info(
            f"Enhanced prompt for '{operation}': +{len(system_instructions)} chars "
            f"(total: {len(enhanced_prompt)} chars)"
        )
        
        return enhanced_prompt

    def read_prompt_file(self, prompt_path: str, request: ClaudeCliRequest = None) -> str:
        """
        Read prompt content from file and enhance with system requirements.

        Args:
            prompt_path: Path to prompt file
            request: Optional request object to extract operation type

        Returns:
            Enhanced prompt content

        Raises:
            FileOperationError: If file read fails
            ValidationError: If path validation fails
        """
        try:
            # Validate path
            SecurityValidator.validate_path(prompt_path, "prompt")

            # Read file
            prompt_file = Path(prompt_path)

            if not prompt_file.exists():
                raise FileNotFoundError(f"Prompt file not found: {prompt_path}")

            if not prompt_file.is_file():
                raise ValueError(f"Prompt path is not a file: {prompt_path}")

            with open(prompt_file, 'r', encoding='utf-8') as f:
                user_prompt = f.read()

            logger.info(f"Read prompt file: {prompt_path} ({len(user_prompt)} chars)")
            
            # Extract operation type from request
            operation = request.operation if request else "unknown"
            
            # Enhance with system requirements
            enhanced_prompt = self._enhance_prompt_with_json_output_requirement(
                user_prompt=user_prompt,
                operation=operation
            )
            
            logger.info(f"Enhanced prompt ready for '{operation}': {len(enhanced_prompt)} chars")
            
            return enhanced_prompt

        except FileNotFoundError as e:
            raise FileOperationError(
                message=str(e),
                file_path=prompt_path,
                details="Prompt file does not exist"
            )
        except ValueError as e:
            raise ValidationError(
                message=str(e),
                field="prompt"
            )
        except Exception as e:
            raise FileOperationError(
                message=f"Failed to read prompt file: {str(e)}",
                file_path=prompt_path,
                details=str(e)
            )

    def extract_result_from_stream(
        self,
        stream_events: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """
        Extract final result event from stream.

        Args:
            stream_events: List of stream events

        Returns:
            Result event dict, or None if not found
        """
        for event in reversed(stream_events):
            if event.get("type") == "result":
                return event

        return None

    def is_stream_successful(
        self,
        stream_events: List[Dict[str, Any]]
    ) -> bool:
        """
        Check if stream completed successfully.

        Args:
            stream_events: List of stream events

        Returns:
            True if successful, False if error occurred
        """
        result = self.extract_result_from_stream(stream_events)

        if not result:
            logger.warning("No result event found in stream")
            return False

        is_error = result.get("is_error", False)
        return not is_error

    def get_error_from_stream(
        self,
        stream_events: List[Dict[str, Any]]
    ) -> Optional[str]:
        """
        Extract error message from stream if present.

        Args:
            stream_events: List of stream events

        Returns:
            Error message, or None if no error
        """
        # Check for error events
        for event in stream_events:
            if event.get("type") == "error":
                return event.get("error", "Unknown error")

        # Check result event
        result = self.extract_result_from_stream(stream_events)
        if result and result.get("is_error"):
            return result.get("error", "Operation failed")

        return None

    def build_success_response(
        self,
        output_path: Path,
        stream_events: List[Dict[str, Any]],
        message: str = "Operation completed successfully"
    ) -> ClaudeCliResponse:
        """
        Build success response from stream events.

        Args:
            output_path: Output file path
            stream_events: List of stream events
            message: Success message

        Returns:
            ClaudeCliResponse with success status
        """
        result = self.extract_result_from_stream(stream_events)

        return ClaudeCliResponse(
            status="success",
            message=message,
            exit_code=0,
            output=str(output_path),
            output_file_path=str(output_path),
            input_tokens=result.get("input_tokens") if result else None,
            output_tokens=result.get("output_tokens") if result else None
        )

    def build_error_response(
        self,
        error_message: str,
        stream_events: Optional[List[Dict[str, Any]]] = None,
        output_path: Optional[Path] = None
    ) -> ClaudeCliResponse:
        """
        Build error response.

        Args:
            error_message: Error message
            stream_events: Optional stream events
            output_path: Optional output file path

        Returns:
            ClaudeCliResponse with error status
        """
        return ClaudeCliResponse(
            status="error",
            message=error_message,
            exit_code=1,
            output="",
            error=error_message,
            output_file_path=str(output_path) if output_path else ""
        )

    async def invoke_with_provider(
        self,
        provider,
        prompt: str,
        project_path: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        enable_tools: bool = True,
        stream_output_path: Optional[Path] = None
    ) -> List[Dict[str, Any]]:
        """
        Invoke provider with graph orchestration or max_iterations based on config.
        
        This helper method automatically chooses between:
        - invoke_with_tools_agentic_graph (graph-based, no max_iterations)
        - invoke_with_tools_agentic (legacy max_iterations-based)

        When stream_output_path is set, events are written to the file as they are
        produced (live streaming). The file is still overwritten with the full list
        if the handler calls write_stream_output at the end.
        
        Args:
            provider: AI provider (BedrockClient or PortkeyClient)
            prompt: Prompt content
            project_path: Project directory path
            max_tokens: Maximum tokens per turn
            temperature: Model temperature
            enable_tools: Whether to enable tool use
            stream_output_path: If set, append each event to this file as it is produced.
            
        Returns:
            List of events from provider
        """
        if stream_output_path is not None:
            async with self.stream_output_streaming(stream_output_path) as on_event:
                if settings.agentic.graph_orchestration_enabled:
                    logger.info("Using graph-based orchestration (no max_iterations)")
                    return await provider.invoke_with_tools_agentic_graph(
                        prompt=prompt,
                        project_path=project_path,
                        provider_factory=self.provider_factory,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        enable_tools=enable_tools,
                        on_event=on_event
                    )
                else:
                    logger.info("Using legacy max_iterations-based execution")
                    return await provider.invoke_with_tools_agentic(
                        prompt=prompt,
                        project_path=project_path,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        enable_tools=enable_tools,
                        on_event=on_event
                    )
        if settings.agentic.graph_orchestration_enabled:
            logger.info("Using graph-based orchestration (no max_iterations)")
            return await provider.invoke_with_tools_agentic_graph(
                prompt=prompt,
                project_path=project_path,
                provider_factory=self.provider_factory,
                max_tokens=max_tokens,
                temperature=temperature,
                enable_tools=enable_tools
            )
        else:
            logger.info("Using legacy max_iterations-based execution")
            return await provider.invoke_with_tools_agentic(
                prompt=prompt,
                project_path=project_path,
                max_tokens=max_tokens,
                temperature=temperature,
                enable_tools=enable_tools
            )

    async def extract_and_write_json_result(
        self,
        stream_events: List[Dict[str, Any]],
        output_dir: Path,
        result_filename: str = "analysis-result.json"
    ) -> Optional[Path]:
        """
        Extract JSON content from stream events and write to separate result file.

        This method:
        1. Extracts all text from assistant responses
        2. Finds JSON blocks (```json ... ```)
        3. Parses and validates the JSON
        4. Writes to result file in the same directory

        Args:
            stream_events: List of stream events
            output_dir: Directory to write result file to
            result_filename: Name of result file (default: analysis-result.json)

        Returns:
            Path to result file if successful, None otherwise
        """
        try:
            from app.utils.stream_utils import StreamParser

            # Extract complete assistant response
            full_response = StreamParser.extract_full_assistant_response(stream_events)

            if not full_response:
                logger.warning("No assistant response found in stream events")
                return None

            # Extract JSON blocks from response
            json_blocks = StreamParser.extract_json_blocks(full_response)

            if not json_blocks:
                logger.warning("No JSON blocks found in assistant response")
                return None

            # Parse the first JSON block
            json_content = None
            for block in json_blocks:
                try:
                    json_content = json.loads(block)
                    break  # Use first valid JSON block
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse JSON block: {e}")
                    continue

            if json_content is None:
                logger.warning("No valid JSON found in any blocks")
                return None

            # Write JSON to result file
            result_path = output_dir / result_filename
            result_path.parent.mkdir(parents=True, exist_ok=True)

            with open(result_path, 'w', encoding='utf-8') as f:
                json.dump(json_content, f, indent=2)

            logger.info(f"JSON result written to: {result_path}")
            return result_path

        except Exception as e:
            logger.error(f"Failed to extract and write JSON result: {str(e)}", exc_info=True)
            return None
