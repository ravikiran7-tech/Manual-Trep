"""
Cloud Readiness Fix Handler - Apply cloud migration fixes.

Applies code changes to make applications cloud-ready based on analysis results.

Supports two execution modes controlled by CLOUDREADINESS_BATCH_BY_RULE env var:

  SINGLE (default, batch_by_rule=False):
    Passes the entire prompt to the AI in one call — existing behaviour,
    zero changes to any downstream flow.

  BATCHED (batch_by_rule=True):
    1. Reads the prompt file and splits it on the "ANALYSIS REPORT:" separator.
    2. Parses the embedded analysis JSON to extract all blockers.
    3. Groups blockers by ruleId (one AI call per unique rule).
    4. For each rule group (sequentially):
         - Builds a focused sub-prompt = base instructions + rule occurrences.
         - Calls the AI model; appends events directly to the single merged
           cloudreadiness-fix-stream.json (rewritten after every batch).
    5. Extracts JSON summaries and writes cloudreadiness-fix-result.json.
"""
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience
from app.core.exceptions import ValidationError, FileOperationError
from app.utils.transformation_utils import merge_fix_result

logger = logging.getLogger(__name__)
settings = get_settings()


class CloudReadinessFixHandler(BaseOperationHandler):
    """
    Handler for 'cloudreadiness-fix' operation.

    Applies cloud migration fixes to applications:
    - Externalize configuration (environment variables)
    - Remove file system dependencies
    - Implement health check endpoints
    - Add graceful shutdown
    - Stateless component conversion
    - Database connection pooling
    - Logging to stdout/stderr
    - Containerization preparation

    Timeout: 3600s (extended - 1 hour)
    Output: cloudreadiness/{analysisId}/cloudreadiness-fix-stream.json

    Batch mode output (when CLOUDREADINESS_BATCH_BY_RULE=true):
      cloudreadiness/{analysisId}/_claude/
        cloudreadiness-fix-stream.json   ← single merged stream (written
                                            incrementally, one rewrite per batch)
        cloudreadiness-fix-result.json   ← merged JSON summaries
    """

    def get_timeout(self) -> int:
        return settings.timeouts.upgrade_operations

    def validate_request(self, request: ClaudeCliRequest):
        self.validate_common_fields(request)
        if not request.prompt:
            raise ValidationError(
                message="Prompt is required for cloudreadiness-fix operation",
                field="prompt"
            )

    # =========================================================================
    # MAIN ENTRY POINT
    # =========================================================================

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Route to batched or single-call execution based on config flag.

        Batched mode: CLOUDREADINESS_BATCH_BY_RULE=true
        Single mode:  CLOUDREADINESS_BATCH_BY_RULE=false (default)
        """
        logger.info(
            f"Starting cloud readiness fix: analysisId={request.analysis_id}, "
            f"batch_by_rule={settings.cloudreadiness.batch_by_rule}"
        )
        logger.info(f"Extended timeout configured: {self.get_timeout()}s")

        # Validate request
        self.validate_request(request)

        if settings.cloudreadiness.batch_by_rule:
            return await self._execute_batched(request)
        return await self._execute_single(request)

    # =========================================================================
    # SINGLE-CALL PATH  (original behaviour, unchanged)
    # =========================================================================

    async def _execute_single(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """Original single-call execution — passes full prompt to AI in one go."""
        logger.info(
            f"Cloud readiness fix (single mode): analysisId={request.analysis_id}, "
            f"extended timeout={self.get_timeout()}s"
        )

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(
                request,
                "cloudreadiness-fix-stream.json"
            )
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using extended timeout
            logger.info("Invoking AI provider for cloud readiness fix with extended timeout")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),  # 3600s extended timeout
                operation_name="cloudreadiness_fix_operation"
            )
            async def invoke_cloudreadiness_fix():
                return await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,  # Enable code_editor and bash tools
                    stream_output_path=output_path
                )

            stream_events = await invoke_cloudreadiness_fix()

            logger.info(
                f"Cloud readiness fix completed: {len(stream_events)} events received"
            )

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="cloudreadiness-fix-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = (
                    self.get_error_from_stream(stream_events) or "Cloud readiness fix failed"
                )
                logger.error(f"Cloud readiness fix failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Cloud readiness fix (single) completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Cloud readiness fix completed successfully"
            )

        except Exception as e:
            logger.exception(f"Cloud readiness fix (single) failed: {str(e)}", exc_info=True)
            raise

    # =========================================================================
    # BATCHED-BY-RULE PATH
    # =========================================================================

    async def _execute_batched(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Rule-batched execution.

        Steps:
          1. Read & split prompt file into base_prompt + analysis JSON.
          2. Parse analysis JSON and group blockers by ruleId.
          3. Get AI provider (one shared instance for all rule calls).
          4. For each ruleId group (sequential):
               - Build focused sub-prompt.
               - Invoke AI; accumulate events and rewrite the single merged
                 stream file after every batch.
          5. Extract and write the merged JSON result file.
          6. Return ClaudeCliResponse pointing to merged output.
        """
        logger.info(
            f"Cloud readiness fix (batched mode): analysisId={request.analysis_id}"
        )

        try:
            # ------------------------------------------------------------------
            # Step 1 — read & split prompt file
            # ------------------------------------------------------------------
            raw_prompt = self._read_raw_prompt_file(request.prompt)
            base_prompt, analysis_json_str = self._parse_prompt_sections(raw_prompt)

            # ------------------------------------------------------------------
            # Step 2 — parse analysis JSON and group blockers by ruleId
            # ------------------------------------------------------------------
            analysis_data = self._extract_analysis_json(analysis_json_str, request.prompt)
            blockers = analysis_data.get("blockers", [])

            if not blockers:
                logger.warning(
                    "No blockers found in analysis JSON — falling back to single mode"
                )
                return await self._execute_single(request)

            rule_groups = self._group_blockers_by_rule(blockers)
            logger.info(
                f"Grouped {len(blockers)} blockers into {len(rule_groups)} unique rules: "
                f"{list(rule_groups.keys())}"
            )

            # ------------------------------------------------------------------
            # Step 3 — get provider and build merged output path
            # ------------------------------------------------------------------
            provider = await self.provider_factory.get_provider()
            merged_output_path = self.build_output_path(
                request, "cloudreadiness-fix-stream.json"
            )
            output_dir = merged_output_path.parent

            # ------------------------------------------------------------------
            # Step 4 — sequential per-rule AI calls
            # ------------------------------------------------------------------
            all_stream_events: List[Dict[str, Any]] = []
            failed_rules: List[str] = []

            batch_size = settings.cloudreadiness.max_occurrences_per_call

            for rule_id, rule_data in rule_groups.items():
                occurrences = rule_data.get("occurrences", [])
                occurrence_batches = [
                    occurrences[i:i + batch_size]
                    for i in range(0, len(occurrences), batch_size)
                ] or [[]]

                logger.info(
                    f"Processing rule {rule_id} "
                    f"({rule_data['severity'].upper()}): "
                    f"{len(occurrences)} occurrence(s) in {len(occurrence_batches)} sub-batch(es)"
                )

                rule_failed = False

                for batch_idx, occurrence_batch in enumerate(occurrence_batches, start=1):
                    batch_data = {**rule_data, "occurrences": occurrence_batch}

                    logger.info(
                        f"Processing rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)}: "
                        f"{len(occurrence_batch)} occurrence(s)"
                    )

                    rule_prompt = self._build_rule_prompt(base_prompt, rule_id, batch_data)

                    try:
                        # Note: stream_output_path is intentionally omitted here.
                        # stream_output_streaming() truncates whatever file it's
                        # given at the start of each call, which would wipe out
                        # prior batches' events if pointed at the shared merged
                        # file. Instead we rewrite the merged file ourselves
                        # (below) once this batch's events are known.
                        rule_events = await self.invoke_with_provider(
                            provider=provider,
                            prompt=rule_prompt,
                            project_path=request.project_path,
                            max_tokens=settings.bedrock.max_tokens,
                            temperature=settings.bedrock.temperature,
                            enable_tools=True
                        )

                        # Stamp each event with the originating ruleId for traceability
                        for event in rule_events:
                            event.setdefault("rule_id", rule_id)

                        all_stream_events.extend(rule_events)

                        # Persist the merged stream incrementally after every batch
                        await self.write_stream_output(merged_output_path, all_stream_events)

                        logger.info(
                            f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} completed: "
                            f"{len(rule_events)} events appended to merged stream: {merged_output_path}"
                        )

                    except Exception as rule_err:
                        logger.exception(
                            f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} "
                            f"AI call failed: {rule_err}", exc_info=True
                        )
                        rule_failed = True
                        # Append an error event so the merged stream records the failure
                        all_stream_events.append({
                            "type": "error",
                            "rule_id": rule_id,
                            "error": (
                                f"Rule {rule_id} sub-batch {batch_idx}/{len(occurrence_batches)} "
                                f"processing failed: {str(rule_err)}"
                            )
                        })

                if rule_failed:
                    failed_rules.append(rule_id)

            # ------------------------------------------------------------------
            # Step 5 — extract merged JSON result (stream file already written
            # incrementally after each batch)
            # ------------------------------------------------------------------
            logger.info(
                f"All rules processed. Total events: {len(all_stream_events)}, "
                f"failed rules: {failed_rules or 'none'}"
            )

            result_path = await self.extract_and_write_json_result(
                stream_events=all_stream_events,
                output_dir=output_dir,
                result_filename="cloudreadiness-fix-result.json"
            )
            if result_path:
                logger.info(f"Merged JSON result written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from merged stream")

            # ------------------------------------------------------------------
            # Step 6 — build response
            # ------------------------------------------------------------------
            if len(failed_rules) == len(rule_groups):
                # Every rule call failed
                error_msg = (
                    f"All {len(rule_groups)} rule(s) failed: {failed_rules}"
                )
                logger.error(error_msg)
                return self.build_error_response(error_msg, all_stream_events, merged_output_path)

            if failed_rules:
                message = (
                    f"Cloud readiness fix completed with partial success. "
                    f"Succeeded: {len(rule_groups) - len(failed_rules)}/{len(rule_groups)} rules. "
                    f"Failed rules: {failed_rules}"
                )
            else:
                message = (
                    f"Cloud readiness fix completed successfully "
                    f"({len(rule_groups)} rule(s) processed)"
                )

            logger.info(message)
            return self.build_success_response(merged_output_path, all_stream_events, message)

        except Exception as e:
            logger.exception(f"Cloud readiness fix (batched) failed: {str(e)}", exc_info=True)
            raise

    # =========================================================================
    # PROMPT PARSING HELPERS
    # =========================================================================

    def _read_raw_prompt_file(self, prompt_path: str) -> str:
        """
        Read the raw prompt file without applying the system-instruction enhancement.

        We need the raw text here so we can split on the separator ourselves.
        The per-rule prompts will be enhanced individually via
        _enhance_prompt_with_json_output_requirement inside _build_rule_prompt.
        """
        from app.core.security import SecurityValidator
        from app.core.exceptions import FileOperationError

        try:
            SecurityValidator.validate_path(prompt_path, "prompt")
            prompt_file = Path(prompt_path)

            if not prompt_file.exists():
                raise FileNotFoundError(f"Prompt file not found: {prompt_path}")
            if not prompt_file.is_file():
                raise ValueError(f"Prompt path is not a file: {prompt_path}")

            with open(prompt_file, "r", encoding="utf-8") as f:
                content = f.read()

            logger.info(f"Read raw prompt file: {prompt_path} ({len(content)} chars)")
            return content

        except FileNotFoundError as e:
            raise FileOperationError(
                message=str(e),
                file_path=prompt_path,
                details="Prompt file does not exist"
            )
        except Exception as e:
            raise FileOperationError(
                message=f"Failed to read prompt file: {str(e)}",
                file_path=prompt_path,
                details=str(e)
            )

    def _parse_prompt_sections(self, raw_text: str) -> Tuple[str, str]:
        """
        Extract the analysis JSON block from the prompt file.

        The prompt file may contain multiple named sections, e.g.:

            system prompt
            ...
            user prompt
            ...
            project details
            ...
            ANALYSIS REPORT:
            {
              "analysisId": "...",
              "blockers": [...]
            }
            Task :
            ...
            response format,
            ...

        This method:
          1. Finds the configured separator (default "ANALYSIS REPORT:").
          2. Locates the first '{' after the separator.
          3. Walks forward counting braces to extract only the balanced
             JSON object — stopping exactly at the matching '}'.
          4. Re-assembles the base_prompt as:
               <everything before separator> + <everything after JSON close>
             so that sections like "Task :" and "response format" are
             preserved for the per-rule AI calls.

        Returns:
            (base_prompt, analysis_json_str) — both stripped strings.

        Fallback:
            If the separator is missing or no '{' is found after it,
            returns (raw_text, "") so the caller falls back to single mode.
        """
        separator = settings.cloudreadiness.analysis_separator
        sep_idx = raw_text.find(separator)

        if sep_idx == -1:
            logger.warning(
                f"Separator '{separator}' not found in prompt file — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        after_sep = raw_text[sep_idx + len(separator):]

        # Locate the first opening brace after the separator
        brace_start = after_sep.find("{")
        if brace_start == -1:
            logger.warning(
                "No '{' found after the analysis separator — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        # Extract the balanced JSON block
        json_str, brace_end = self._extract_balanced_json_block(after_sep, brace_start)

        if not json_str:
            logger.warning(
                "Could not find a balanced JSON object after the separator — "
                "falling back to single-call mode."
            )
            return raw_text.strip(), ""

        # Reconstruct base_prompt: everything before the separator header +
        # everything after the closing '}' (Task, response format, etc.)
        pre_sep = raw_text[:sep_idx].strip()
        post_json = after_sep[brace_end:].strip()

        if post_json:
            base_prompt = f"{pre_sep}\n\n{post_json}"
        else:
            base_prompt = pre_sep

        logger.info(
            f"Extracted analysis JSON ({len(json_str)} chars) from prompt. "
            f"Base prompt reconstructed: {len(base_prompt)} chars "
            f"(pre-sep={len(pre_sep)}, post-json={len(post_json)})."
        )
        return base_prompt.strip(), json_str

    def _extract_balanced_json_block(
        self, text: str, start: int
    ) -> Tuple[str, int]:
        """
        Walk forward from *start* counting '{' / '}' to find the matching close.

        Handles strings (ignores braces inside double-quoted strings) and
        backslash escape sequences inside strings.

        Args:
            text:  The full string to scan.
            start: Index of the opening '{' within *text*.

        Returns:
            (json_str, end_index) where end_index is the position just after
            the closing '}'. Returns ("", len(text)) when no balanced block
            is found (malformed JSON or unterminated string).
        """
        depth = 0
        in_string = False
        escape_next = False

        for i in range(start, len(text)):
            in_string, escape_next, depth, balanced = self._advance_json_state(
                text[i], in_string, escape_next, depth
            )
            if balanced:
                return text[start: i + 1], i + 1

        logger.warning(
            "Brace extraction ended without finding a balanced '}'. "
            "The JSON object in the prompt file may be malformed."
        )
        return "", len(text)

    @staticmethod
    def _advance_json_state(
        ch: str, in_string: bool, escape_next: bool, depth: int
    ) -> Tuple[bool, bool, int, bool]:
        """
        Advance the JSON-scanning state machine by one character.

        Returns:
            (in_string, escape_next, depth, balanced_close_found)
        """
        if escape_next:
            return in_string, False, depth, False

        if in_string and ch == "\\":
            return in_string, True, depth, False

        if ch == '"':
            return not in_string, False, depth, False

        if in_string:
            return in_string, False, depth, False

        if ch == "{":
            return in_string, False, depth + 1, False

        if ch == "}":
            depth -= 1
            return in_string, False, depth, depth == 0

        return in_string, False, depth, False

    def _extract_analysis_json(
        self, analysis_json_str: str, prompt_path: str
    ) -> Dict[str, Any]:
        """
        JSON-parse the analysis block extracted from the prompt file.

        Raises:
            FileOperationError: If the extracted string is empty or not valid JSON.
        """
        if not analysis_json_str:
            raise FileOperationError(
                message="Analysis JSON section is empty — no balanced JSON object was found",
                file_path=prompt_path,
                details=(
                    f"Expected a JSON object after '{settings.cloudreadiness.analysis_separator}' "
                    "but none was extracted. Check the prompt file format."
                )
            )

        try:
            data = json.loads(analysis_json_str)
            logger.info(
                f"Parsed analysis JSON: analysisId={data.get('analysisId')}, "
                f"blockers={len(data.get('blockers', []))}"
            )
            return data
        except json.JSONDecodeError as e:
            raise FileOperationError(
                message=f"Failed to parse analysis JSON: {str(e)}",
                file_path=prompt_path,
                details=(
                    f"JSON decode error at line {e.lineno}, col {e.colno}. "
                    "Ensure the JSON object in the prompt file is valid."
                )
            )

    # =========================================================================
    # BLOCKER GROUPING HELPER
    # =========================================================================

    def _group_blockers_by_rule(
        self, blockers: List[Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Group blocker entries by ruleId.

        For each unique ruleId, produce a dict:
          {
            "ruleName":        str,
            "ruleDesc":        str,
            "category":        str,
            "severity":        str,
            "remediationName": str,
            "remediationDesc": str,
            "occurrences": [
                {"filePath": ..., "beginLine": ..., "endLine": ..., "id": ...},
                ...
            ]
          }

        Rule metadata is taken from the FIRST blocker encountered for that ruleId.
        Only "filePath", "beginLine", "endLine" vary across occurrences.
        """
        groups: Dict[str, Dict[str, Any]] = {}

        for blocker in blockers:
            rule_id = blocker.get("ruleId", "unknown")

            if rule_id not in groups:
                groups[rule_id] = {
                    "ruleName":        blocker.get("ruleName", ""),
                    "ruleDesc":        blocker.get("ruleDesc", ""),
                    "category":        blocker.get("category", ""),
                    "severity":        blocker.get("severity", ""),
                    "remediationName": blocker.get("remediationName", ""),
                    "remediationDesc": blocker.get("remediationDesc", ""),
                    "occurrences":     []
                }

            groups[rule_id]["occurrences"].append({
                "id":        blocker.get("id", ""),
                "filePath":  blocker.get("filePath", ""),
                "beginLine": blocker.get("beginLine"),
                "endLine":   blocker.get("endLine")
            })

        return groups

    # =========================================================================
    # PER-RULE PROMPT BUILDER
    # =========================================================================

    def _build_rule_prompt(
        self,
        base_prompt: str,
        rule_id: str,
        rule_data: Dict[str, Any]
    ) -> str:
        """
        Build the focused prompt for a single ruleId group.

        Structure:
            <system enhancement header>

            <base_prompt>

            ═══ CURRENT FIX TASK ═══
            Rule ID   : <rule_id>
            Rule Name : <ruleName>
            Severity  : <severity>  Category: <category>
            Description:
              <ruleDesc>

            Remediation Strategy : <remediationName>
            Remediation Details  :
              <remediationDesc>

            Occurrences to fix (fix EVERY entry below):
              1. File: <filePath>  Lines: <beginLine>–<endLine>
              2. ...

            Instructions:
              - Use code_editor to read each affected file before modifying it.
              - Apply the remediation to EVERY occurrence listed above.
              - Write the updated file content back using code_editor (write operation).
              - After all fixes are complete, output a JSON summary block.
            ════════════════════════
        """
        occurrences = rule_data.get("occurrences", [])
        occurrence_lines = "\n".join(
            f"  {i + 1}. File: {occ['filePath']}  "
            f"Lines: {occ['beginLine']}–{occ['endLine']}"
            for i, occ in enumerate(occurrences)
        )

        fix_task_section = f"""
{'═' * 79}
CURRENT FIX TASK

Rule ID          : {rule_id}
Rule Name        : {rule_data['ruleName']}
Severity         : {rule_data['severity'].upper()}    Category: {rule_data['category']}

Description:
  {rule_data['ruleDesc']}

Remediation Strategy : {rule_data['remediationName']}
Remediation Details  :
  {rule_data['remediationDesc']}

Occurrences to fix (you MUST fix EVERY entry listed below):
{occurrence_lines}

Instructions:
  1. Use code_editor (operation=read) to read each affected file before modifying it.
  2. Apply the remediation described above to EVERY occurrence listed.
  3. Use code_editor (operation=write or patch) to persist the changes.
  4. After completing ALL fixes for this rule, output a JSON summary in your text
     response using a ```json code block with at minimum:
       {{
         "ruleId": "{rule_id}",
         "ruleName": "{rule_data['ruleName']}",
         "status": "fixed" | "partial" | "failed",
         "fixedOccurrences": [...],
         "skippedOccurrences": [...],
         "notes": "..."
       }}
{'═' * 79}
""".strip()

        # Combine: system enhancement header + base prompt + per-rule task
        enhanced_base = self._enhance_prompt_with_json_output_requirement(
            user_prompt=base_prompt,
            operation="cloudreadiness-fix"
        )

        return f"{enhanced_base}\n\n{fix_task_section}"

    # =========================================================================
    # OUTPUT DIRECTORY OVERRIDE
    # =========================================================================

    def get_output_directory(self, request: ClaudeCliRequest) -> str:
        return "cloudreadiness"

    async def extract_and_write_json_result(
        self,
        stream_events: List[Dict[str, Any]],
        output_dir: Path,
        result_filename: str = "upgrade-analysis-result.json"
    ) -> Optional[Path]:
        """
        Extract JSON content from stream events and write to separate result file.

        This method:
        1. Extracts all text from assistant responses
        2. Finds JSON blocks (```json ... ```)
        3. Parses and validates the JSON
        4. Writes to result file in the same directory

        Args:
            stream_events: List of stream events
            output_dir: Directory to write result file to
            result_filename: Name of result file (default: upgrade-analysis-result.json)

        Returns:
            Path to result file if successful, None otherwise
        """
        try:
            from app.utils.stream_utils import StreamParser

            # Extract complete assistant response
            full_response = StreamParser.extract_full_assistant_response(stream_events)

            if not full_response:
                logger.warning("No assistant response found in stream events")
                return None

            # Extract JSON blocks from response
            json_blocks = StreamParser.extract_all_json_blocks(full_response)
            logger.info(f"Json Blocks: {len(json_blocks)},\n {json_blocks}")
            if not json_blocks:
                logger.warning("No JSON blocks found in assistant response")
                return None

            # Parse and merge all valid JSON blocks into a single result
            json_content = merge_fix_result(json_blocks)

            if json_content is None:
                logger.warning("No valid JSON found in any blocks")
                return None

            # Write JSON to result file
            result_path = output_dir / result_filename
            result_path.parent.mkdir(parents=True, exist_ok=True)

            with open(result_path, 'w', encoding='utf-8') as f:
                json.dump(json_content, f, indent=2)

            logger.info(f"JSON result written to: {result_path}, JSON Content: {json_content}")
            return result_path

        except Exception as e:
            logger.error(f"Failed to extract and write JSON result: {str(e)}", exc_info=True)
            return None

