"""
Containerization Analysis Handler - Analyze applications for containerization blockers.

Performs containerization readiness analysis of application code using AI to identify:
- Hardcoded paths and file system dependencies
- Database connection configuration issues
- Configuration externalization needs
- Environment-specific code
- Port and networking issues
- Stateful vs stateless patterns
"""
import logging
from pathlib import Path

from app.services.operation_handlers.base_handler import BaseOperationHandler
from app.models.requests import ClaudeCliRequest
from app.models.responses import ClaudeCliResponse
from app.core.config import get_settings
from app.core.resilience import with_resilience


logger = logging.getLogger(__name__)
settings = get_settings()


class ContainerizationAnalysisHandler(BaseOperationHandler):
    """
    Handler for 'containerization-analysis' operation.

    Performs containerization readiness analysis of application code using AI to identify:
    - Hardcoded paths and configuration
    - Database connection patterns
    - File system dependencies
    - Environment-specific code
    - Port configuration issues
    - Stateful components
    - 12-factor app compliance

    Timeout: 3000s (default)
    Output: containerization/{analysisId}/containerization-analysis-stream.json
    """

    def get_timeout(self) -> int:
        """
        Get timeout for containerization analysis operation.

        Returns:
            Timeout in seconds (default: 3000)
        """
        return settings.timeouts.default

    def validate_request(self, request: ClaudeCliRequest):
        """
        Validate containerization analysis request.

        Args:
            request: Claude CLI request

        Raises:
            ValidationError: If validation fails
        """
        # Validate common fields
        self.validate_common_fields(request)

        # Containerization analysis requires a prompt
        if not request.prompt:
            from app.core.exceptions import ValidationError
            raise ValidationError(
                message="Prompt is required for containerization-analysis operation",
                field="prompt"
            )

    async def execute(self, request: ClaudeCliRequest) -> ClaudeCliResponse:
        """
        Execute containerization analysis operation.

        Args:
            request: Claude CLI request

        Returns:
            Claude CLI response with containerization blocker analysis

        Raises:
            ValidationError: If request validation fails
            ProviderError: If AI provider invocation fails
            OperationTimeoutError: If operation times out
        """
        logger.info(f"Starting containerization analysis: analysisId={request.analysis_id}")

        # Validate request
        self.validate_request(request)

        try:
            # Get AI provider
            logger.info("Getting AI provider from factory")
            provider = await self.provider_factory.get_provider()

            # Read prompt file
            logger.info(f"Reading prompt from: {request.prompt}")
            prompt_content = self.read_prompt_file(request.prompt, request)

            # Build output path
            output_path = self.build_output_path(request, "containerization-analysis-stream.json")
            logger.info(f"Output will be written to: {output_path}")

            # Execute with provider using resilience patterns
            logger.info("Invoking AI provider for containerization analysis")

            @with_resilience(
                retry_attempts=3,
                timeout_seconds=self.get_timeout(),
                operation_name="containerization_analysis_operation"
            )
            async def invoke_analysis():
                events = await self.invoke_with_provider(
                    provider=provider,
                    prompt=prompt_content,
                    project_path=request.project_path,
                    max_tokens=settings.bedrock.max_tokens,
                    temperature=settings.bedrock.temperature,
                    enable_tools=True,
                    stream_output_path=output_path
                )
                return events

            # Execute invocation
            stream_events = await invoke_analysis()

            logger.info(f"Containerization analysis completed: {len(stream_events)} events received")

            # Write stream output to file
            await self.write_stream_output(output_path, stream_events)

            # Extract and write JSON result file
            result_path = await self.extract_and_write_json_result(
                stream_events=stream_events,
                output_dir=output_path.parent,
                result_filename="containerization-analysis-result.json"
            )
            
            if result_path:
                logger.info(f"JSON result extracted and written to: {result_path}")
            else:
                logger.warning("Could not extract JSON result from stream")

            # Check if operation was successful
            if not self.is_stream_successful(stream_events):
                error_msg = self.get_error_from_stream(stream_events) or "Containerization analysis failed"
                logger.error(f"Containerization analysis operation failed: {error_msg}")
                return self.build_error_response(error_msg, stream_events, output_path)

            # Build success response
            logger.info("Containerization analysis operation completed successfully")
            return self.build_success_response(
                output_path,
                stream_events,
                message="Containerization analysis completed successfully"
            )

        except Exception as e:
            error_msg = f"Containerization analysis operation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise
