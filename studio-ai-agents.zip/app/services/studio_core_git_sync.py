"""Ask studio-core to sync the branch before an AI step and to commit and push it after a successful one."""
import logging
from typing import Any, Optional

import httpx

from app.core.config import get_settings

logger = logging.getLogger(__name__)

GIT_PUSH_REJECTED_MESSAGE = (
    "Git push was rejected for this step; the changes are kept on the server copy. "
    "Pull the latest branch, fix the conflict on the server copy, and re-run the step."
)


async def _post(endpoint: str, body: dict[str, Any], read_timeout_seconds: float) -> Optional[int]:
    """POST to studio-core and log the answer; return its HTTP status, or None when skipped or failed. Never raises."""
    try:
        settings = get_settings()
        if not settings.git_step_sync_enabled or not body["analysisId"]:
            return None
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(read_timeout_seconds, connect=15.0),
            headers={"Accept": "application/json"},
        ) as client:
            response = await client.post(f"{settings.studio_core.base_url.rstrip('/')}{endpoint}", json=body)
        logger.info("analysisId=%s %s answered HTTP %s: %s", body["analysisId"], endpoint, response.status_code, response.text[:500])
        return response.status_code
    except Exception as exc:
        logger.warning("analysisId=%s %s failed, continuing the step: %r", body.get("analysisId"), endpoint, exc)
        return None


async def sync_before_step(analysis_id: Optional[str], project_path: Optional[str]) -> None:
    body = {"analysisId": analysis_id, "projectPath": project_path}
    await _post("/v1/git/step/sync", body, get_settings().git_step_sync_timeout_seconds)


async def commit_and_push_after_step(analysis_id: Optional[str], project_path: Optional[str], operation: str) -> bool:
    """Return True only when studio-core answers HTTP 409 (push rejected); the caller then fails the step."""
    commit_message = f"studio: {operation} analysisId={analysis_id}"
    body = {"analysisId": analysis_id, "projectPath": project_path, "commitMessage": commit_message}
    timeout = get_settings().git_step_commit_push_timeout_seconds
    return await _post("/v1/git/step/commit-and-push", body, timeout) == 409
