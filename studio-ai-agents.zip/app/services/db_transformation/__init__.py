"""Job lookup so Oracle read URLs can serve an MSSQL job after launch."""
