"""Locate a transformation job by jobId and bind the matching engine adapter.

Oracle and MSSQL both write ``schema-modernization/{dbName}/``. The frozen
``job_config.json`` ``engine`` field says which reader to use. After launch,
every read URL is the existing Oracle path.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

from app.core.config import get_settings

JOB_ENGINE_FIELD = "engine"
JOB_ENGINE_MSSQL = "mssql"


class SourceType(str, Enum):
    ORACLE = "oracle"
    MSSQL = "mssql"


@dataclass(frozen=True)
class SourceAdapter:
    """Everything the shared router needs, bound to one engine's service modules."""

    name: str
    get_status: Callable[[str], dict[str, Any]]
    get_job_config: Callable[[str], dict[str, Any]]
    resolve_folder_key: Callable[[str], Optional[str]]
    list_objects: Callable[..., dict[str, Any]]
    load_transformation_summary: Callable[[str], Optional[dict[str, Any]]]
    is_summary_available: Callable[[str], bool]
    output_dir: Callable[[str], Path]
    list_artifacts: Callable[[str, str], list[dict[str, Any]]]
    artifact_name_key: Callable[[dict[str, Any]], str]
    events_path: Callable[[str], Path]
    logs_path: Callable[[str], Path]
    subscribe: Callable[[str, Callable[[dict[str, Any]], Awaitable[None]]], None]
    unsubscribe_all: Callable[[str], None]
    subscribe_logs: Callable[[str, Callable[[dict[str, Any]], Awaitable[None]]], None]
    unsubscribe_logs: Callable[[str], None]
    is_job_terminal: Callable[[str], bool]
    is_terminal_progress_event: Callable[[dict[str, Any]], bool]
    is_ui_stream_event: Callable[..., bool]


def _oracle_adapter() -> SourceAdapter:
    from app.services.oracle_pg.artifact_packager import list_artifacts
    from app.services.oracle_pg.hooks import is_ui_stream_event, subscribe, subscribe_logs, unsubscribe_all, unsubscribe_logs
    from app.services.oracle_pg.job_manager import get_job_manager
    from app.services.oracle_pg.progress import STATUS_COMPLETED, is_job_terminal, is_terminal_progress_event
    from app.services.oracle_pg.report_metrics import load_transformation_summary_file
    from app.services.oracle_pg.workspace import events_path, logs_path, output_dir, resolve_folder_key

    manager = get_job_manager()
    settings = get_settings()

    def _resolve(job_id: str) -> Optional[str]:
        return resolve_folder_key(job_id, settings.claude_workspace)

    return SourceAdapter(
        name=SourceType.ORACLE.value,
        get_status=manager.get_status,
        get_job_config=manager.get_job_config,
        resolve_folder_key=_resolve,
        list_objects=manager.list_objects,
        load_transformation_summary=load_transformation_summary_file,
        is_summary_available=lambda s: s == STATUS_COMPLETED,
        output_dir=output_dir,
        list_artifacts=list_artifacts,
        artifact_name_key=lambda config: str(config.get("dbName") or "database"),
        events_path=events_path,
        logs_path=logs_path,
        subscribe=subscribe,
        unsubscribe_all=unsubscribe_all,
        subscribe_logs=subscribe_logs,
        unsubscribe_logs=unsubscribe_logs,
        is_job_terminal=is_job_terminal,
        is_terminal_progress_event=is_terminal_progress_event,
        is_ui_stream_event=is_ui_stream_event,
    )


def _mssql_adapter() -> SourceAdapter:
    from app.services.mssql_pg.artifact_packager import TRANSFORMATION_SUMMARY_JSON, list_artifacts
    from app.services.mssql_pg.hooks import is_ui_stream_event, subscribe, subscribe_logs, unsubscribe_all, unsubscribe_logs
    from app.services.mssql_pg.job_manager import get_job_manager
    from app.services.mssql_pg.progress import (
        STATUS_COMPLETED,
        STATUS_COMPLETED_WITH_WARNINGS,
        is_job_terminal,
        is_terminal_progress_event,
    )
    from app.services.mssql_pg.workspace import events_path, logs_path, output_dir, read_json_file, resolve_folder_key

    manager = get_job_manager()
    settings = get_settings()
    summary_statuses = frozenset({STATUS_COMPLETED, STATUS_COMPLETED_WITH_WARNINGS})

    def _resolve(job_id: str) -> Optional[str]:
        return resolve_folder_key(job_id, settings.claude_workspace)

    def _load_summary(folder_key: str) -> Optional[dict[str, Any]]:
        return read_json_file(output_dir(folder_key) / TRANSFORMATION_SUMMARY_JSON)

    return SourceAdapter(
        name=SourceType.MSSQL.value,
        get_status=manager.get_status,
        get_job_config=manager.get_job_config,
        resolve_folder_key=_resolve,
        list_objects=manager.list_objects,
        load_transformation_summary=_load_summary,
        is_summary_available=lambda s: s in summary_statuses,
        output_dir=output_dir,
        list_artifacts=list_artifacts,
        artifact_name_key=lambda config: str(config.get("dbId") or config.get("dbName") or "database"),
        events_path=events_path,
        logs_path=logs_path,
        subscribe=subscribe,
        unsubscribe_all=unsubscribe_all,
        subscribe_logs=subscribe_logs,
        unsubscribe_logs=unsubscribe_logs,
        is_job_terminal=is_job_terminal,
        is_terminal_progress_event=is_terminal_progress_event,
        is_ui_stream_event=is_ui_stream_event,
    )


_ADAPTERS: dict[SourceType, SourceAdapter] = {}


def get_adapter(source_type: SourceType) -> SourceAdapter:
    """Build each adapter once; the underlying job managers are themselves singletons."""
    cached = _ADAPTERS.get(source_type)
    if cached is not None:
        return cached
    if source_type == SourceType.ORACLE:
        adapter = _oracle_adapter()
    elif source_type == SourceType.MSSQL:
        adapter = _mssql_adapter()
    else:
        raise ValueError(f"Unknown source type: {source_type}")
    _ADAPTERS[source_type] = adapter
    return adapter


def reset_adapter_cache() -> None:
    """Test helper: clear cached adapters so a fresh job_manager singleton is bound."""
    _ADAPTERS.clear()


@dataclass(frozen=True)
class LocatedJob:
    """A jobId resolved to one on-disk folder and the engine that owns it."""

    source: SourceType
    folder_key: str
    adapter: SourceAdapter


def _configured_engine(folder_key: str) -> Optional[str]:
    """Read the engine marker from the shared schema-modernization job folder."""
    from app.services.oracle_pg.workspace import job_config_path

    path = job_config_path(folder_key, get_settings().claude_workspace)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    engine = data.get(JOB_ENGINE_FIELD)
    return str(engine) if engine else None


def require_job(job_id: str) -> LocatedJob:
    """Resolve ``jobId`` or raise ``FileNotFoundError``."""
    located = locate_job(job_id)
    if located is None:
        raise FileNotFoundError(f"Job not found: {job_id}")
    return located


def locate_job(job_id: str) -> Optional[LocatedJob]:
    """Find ``jobId`` under schema-modernization and bind the engine from job_config.

    Folders with no engine marker stay on the Oracle reader so existing Oracle
    jobs keep their current behavior. An MSSQL launch writes ``engine: mssql``.
    """
    oracle = get_adapter(SourceType.ORACLE)
    folder_key = oracle.resolve_folder_key(job_id)
    if not folder_key:
        return None

    if _configured_engine(folder_key) == JOB_ENGINE_MSSQL:
        mssql = get_adapter(SourceType.MSSQL)
        try:
            mssql.get_status(job_id)
        except FileNotFoundError:
            return None
        return LocatedJob(
            source=SourceType.MSSQL,
            folder_key=mssql.resolve_folder_key(job_id) or folder_key,
            adapter=mssql,
        )

    try:
        oracle.get_status(job_id)
    except FileNotFoundError:
        return None
    return LocatedJob(
        source=SourceType.ORACLE,
        folder_key=folder_key,
        adapter=oracle,
    )
