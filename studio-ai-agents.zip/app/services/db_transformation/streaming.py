"""Engine-aware SSE tails for schema modernization (Oracle + MSSQL share paths)."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator

from app.services.db_transformation.sources import SourceAdapter, SourceType


def _parse_stream_event(payload: str) -> dict | None:
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return None
    return event if isinstance(event, dict) else None


def _yield_new_log_lines(path, offset: int) -> tuple[list[str], int]:
    if not path.exists():
        return [], offset
    lines = path.read_text(encoding="utf-8").splitlines()
    chunk: list[str] = []
    while offset < len(lines):
        chunk.append(lines[offset])
        offset += 1
    return chunk, offset


def _progress_snapshot_event(
    adapter: SourceAdapter,
    job_id: str,
    folder_key: str,
) -> dict | None:
    """Rebuild a single ``progress_updated`` when JSONL replay is empty (e.g. after page refresh)."""
    try:
        progress = adapter.get_status(job_id)
    except FileNotFoundError:
        return None
    if adapter.name == SourceType.MSSQL.value:
        from app.services.mssql_pg.hooks import progress_updated_event

        return progress_updated_event(folder_key, progress)
    from app.services.oracle_pg.hooks import progress_updated_event

    return progress_updated_event(folder_key, progress)


def _human_log_snapshot(
    adapter: SourceAdapter,
    job_id: str,
    folder_key: str,
) -> dict | None:
    """Single log line from current progress when ``logs.jsonl`` has no rows."""
    try:
        progress = adapter.get_status(job_id)
    except FileNotFoundError:
        return None
    message = str(progress.get("message") or "").strip()
    if not message:
        return None
    phase = str(progress.get("phase") or "")
    if adapter.name == SourceType.MSSQL.value:
        from datetime import datetime, timezone

        from app.services.oracle_pg.live_logs import icon_color

        return {
            "seq": 0,
            "timestamp": datetime.now(timezone.utc).strftime("%H:%M:%S"),
            "phase": phase,
            "icon": "check" if str(progress.get("status")) in {"completed", "completed_with_warnings"} else "info",
            "message": message,
            "color": icon_color("check"),
            "jobId": str(progress.get("jobId") or job_id),
        }
    from app.services.oracle_pg.live_logs import build_log_entry

    return build_log_entry(folder_key, phase=phase, message=message)


async def tail_progress_events(
    job_id: str,
    folder_key: str,
    adapter: SourceAdapter,
    *,
    verbose: bool = False,
) -> AsyncIterator[str]:
    path = adapter.events_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_event(event: dict) -> None:
        if not adapter.is_ui_stream_event(event, verbose=verbose):
            return
        await queue.put(json.dumps(event))

    adapter.subscribe(folder_key, on_event)
    if job_id != folder_key:
        adapter.subscribe(job_id, on_event)

    offset = 0
    data_events_yielded = 0
    try:
        while True:
            new_lines, offset = _yield_new_log_lines(path, offset)
            for line in new_lines:
                event: dict | None
                if not verbose:
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if not adapter.is_ui_stream_event(event, verbose=False):
                        continue
                else:
                    event = _parse_stream_event(line)

                yield f"data: {line}\n\n"
                data_events_yielded += 1
                if event and adapter.is_terminal_progress_event(event):
                    return

            if adapter.is_job_terminal(folder_key):
                new_lines, offset = _yield_new_log_lines(path, offset)
                for line in new_lines:
                    yield f"data: {line}\n\n"
                    data_events_yielded += 1
                if data_events_yielded == 0:
                    snapshot = _progress_snapshot_event(adapter, job_id, folder_key)
                    if snapshot is not None:
                        yield f"data: {json.dumps(snapshot)}\n\n"
                return

            try:
                event_json = await asyncio.wait_for(queue.get(), timeout=2.0)
                yield f"data: {event_json}\n\n"
                data_events_yielded += 1
                event = _parse_stream_event(event_json)
                if event and adapter.is_terminal_progress_event(event):
                    return
            except asyncio.TimeoutError:
                if adapter.is_job_terminal(folder_key):
                    new_lines, offset = _yield_new_log_lines(path, offset)
                    for line in new_lines:
                        yield f"data: {line}\n\n"
                        data_events_yielded += 1
                    if data_events_yielded == 0:
                        snapshot = _progress_snapshot_event(adapter, job_id, folder_key)
                        if snapshot is not None:
                            yield f"data: {json.dumps(snapshot)}\n\n"
                    return
                yield ": keepalive\n\n"
    finally:
        adapter.unsubscribe_all(folder_key)
        if job_id != folder_key:
            adapter.unsubscribe_all(job_id)


async def tail_human_logs(
    job_id: str,
    folder_key: str,
    adapter: SourceAdapter,
) -> AsyncIterator[str]:
    path = adapter.logs_path(folder_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()

    queue: asyncio.Queue[str] = asyncio.Queue()

    async def on_log(entry: dict) -> None:
        await queue.put(json.dumps(entry))

    adapter.subscribe_logs(folder_key, on_log)
    if job_id != folder_key:
        adapter.subscribe_logs(job_id, on_log)

    offset = 0
    log_lines_yielded = 0
    try:
        while True:
            new_lines, offset = _yield_new_log_lines(path, offset)
            for line in new_lines:
                yield f"data: {line}\n\n"
                log_lines_yielded += 1

            if adapter.is_job_terminal(folder_key):
                new_lines, offset = _yield_new_log_lines(path, offset)
                for line in new_lines:
                    yield f"data: {line}\n\n"
                    log_lines_yielded += 1
                if log_lines_yielded == 0:
                    snapshot = _human_log_snapshot(adapter, job_id, folder_key)
                    if snapshot is not None:
                        yield f"data: {json.dumps(snapshot)}\n\n"
                return

            try:
                entry_json = await asyncio.wait_for(queue.get(), timeout=2.0)
                yield f"data: {entry_json}\n\n"
                log_lines_yielded += 1
            except asyncio.TimeoutError:
                if adapter.is_job_terminal(folder_key):
                    new_lines, offset = _yield_new_log_lines(path, offset)
                    for line in new_lines:
                        yield f"data: {line}\n\n"
                        log_lines_yielded += 1
                    if log_lines_yielded == 0:
                        snapshot = _human_log_snapshot(adapter, job_id, folder_key)
                        if snapshot is not None:
                            yield f"data: {json.dumps(snapshot)}\n\n"
                    return
                yield ": keepalive\n\n"
    finally:
        adapter.unsubscribe_logs(folder_key)
        if job_id != folder_key:
            adapter.unsubscribe_logs(job_id)
