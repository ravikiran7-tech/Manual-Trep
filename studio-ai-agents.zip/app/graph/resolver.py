"""
Graph resolver for topological ordering and module locking.

Determines which modules are ready for execution based on
dependency completion status.
"""
import logging
from typing import List, Dict
from app.state.models import ModuleNode, ModuleStatus

logger = logging.getLogger(__name__)


class GraphResolver:
    """
    Resolves which modules are ready for execution.
    
    Uses topological ordering: a module is ready when all its
    dependencies are LOCKED (successfully completed).
    """
    
    @staticmethod
    def get_ready_modules(graph: Dict[str, ModuleNode]) -> List[ModuleNode]:
        """
        Get modules that are ready for execution.
        
        A module is ready if:
        1. Status is PENDING
        2. All dependencies are LOCKED (successfully completed)
        
        Args:
            graph: Dictionary mapping module names to ModuleNode objects
            
        Returns:
            List of ModuleNode objects ready for execution
        """
        ready = []
        
        for module in graph.values():
            # Only consider pending modules
            if module.status != ModuleStatus.PENDING:
                continue
            
            # Check if all dependencies are locked
            all_deps_locked = True
            missing_deps = []
            
            for dep_name in module.dependencies:
                if dep_name not in graph:
                    # Missing dependency - could be external dependency or parent POM
                    # Log as debug (not warning) since parent POMs are expected to be missing
                    logger.debug(
                        f"Module {module.name} depends on {dep_name} "
                        f"which is not in graph (may be external dependency or parent POM)"
                    )
                    # Skip missing dependencies - they're likely external or parent POMs
                    # Only block if ALL dependencies are missing AND module has dependencies
                    continue
                
                dep_module = graph[dep_name]
                
                # Dependency must be locked (successfully completed)
                if dep_module.status != ModuleStatus.LOCKED:
                    all_deps_locked = False
                    logger.debug(
                        f"Module {module.name} waiting for {dep_name} "
                        f"(status: {dep_module.status.value})"
                    )
                    break
            
            # Module is ready if:
            # 1. All dependencies that exist in graph are LOCKED
            # 2. Missing dependencies are ignored (they're external or parent POMs)
            if all_deps_locked:
                ready.append(module)
        
        if ready:
            logger.info(
                f"Found {len(ready)} ready modules: {[m.name for m in ready]}"
            )
        else:
            logger.debug("No ready modules found")
        
        return ready
    
    @staticmethod
    def validate_graph(graph: Dict[str, ModuleNode]) -> bool:
        """
        Validate that graph has no circular dependencies.
        
        Uses DFS to detect cycles.
        
        Args:
            graph: Dictionary mapping module names to ModuleNode objects
            
        Returns:
            True if graph is valid (no cycles), False otherwise
        """
        visited = set()
        rec_stack = set()
        cycles = []
        
        def has_cycle(node_name: str, path: List[str]) -> bool:
            """
            Check for cycles using DFS.
            
            Args:
                node_name: Current node being visited
                path: Current path in DFS traversal
                
            Returns:
                True if cycle detected, False otherwise
            """
            if node_name in rec_stack:
                # Cycle detected
                cycle_start = path.index(node_name)
                cycle = path[cycle_start:] + [node_name]
                cycles.append(cycle)
                return True
            
            if node_name in visited:
                return False
            
            visited.add(node_name)
            rec_stack.add(node_name)
            path.append(node_name)
            
            if node_name in graph:
                node = graph[node_name]
                for dep in node.dependencies:
                    if dep in graph:  # Only check dependencies that exist in graph
                        if has_cycle(dep, path):
                            return True
            
            rec_stack.remove(node_name)
            path.pop()
            return False
        
        # Check all nodes for cycles
        for module_name in graph:
            if module_name not in visited:
                if has_cycle(module_name, []):
                    logger.error(
                        f"Circular dependency detected: {' -> '.join(cycles[-1])}"
                    )
                    return False
        
        logger.info("Graph validation passed: no circular dependencies")
        return True
    
    @staticmethod
    def get_execution_order(graph: Dict[str, ModuleNode]) -> List[List[str]]:
        """
        Get topological execution order.
        
        Returns modules in layers, where each layer can be executed
        in parallel (modules in same layer have no dependencies on each other).
        
        Args:
            graph: Dictionary mapping module names to ModuleNode objects
            
        Returns:
            List of layers, where each layer is a list of module names
        """
        layers = []
        remaining = set(graph.keys())
        processed = set()
        
        while remaining:
            # Find modules with no unprocessed dependencies
            current_layer = []
            for module_name in remaining:
                module = graph[module_name]
                deps_processed = all(
                    dep in processed or dep not in graph
                    for dep in module.dependencies
                )
                
                if deps_processed:
                    current_layer.append(module_name)
            
            if not current_layer:
                # Circular dependency or missing dependencies
                logger.warning(
                    f"Cannot resolve execution order. "
                    f"Remaining modules: {remaining}"
                )
                break
            
            layers.append(current_layer)
            processed.update(current_layer)
            remaining -= set(current_layer)
        
        logger.info(f"Execution order: {len(layers)} layers")
        for i, layer in enumerate(layers):
            logger.debug(f"Layer {i+1}: {layer}")
        
        return layers
