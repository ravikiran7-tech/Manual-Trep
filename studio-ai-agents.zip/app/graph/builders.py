"""
Dependency graph builders for Maven and .NET projects.

Builds dependency graphs from project structure to enable
deterministic, topological execution order.
"""
import defusedxml.ElementTree as ET
import logging
from pathlib import Path
from typing import Dict, List
from app.state.models import ModuleNode

logger = logging.getLogger(__name__)


class DependencyGraphBuilder:
    """
    Base class for building dependency graphs.
    
    Supports:
    - Maven projects (pom.xml)
    - .NET projects (.csproj)
    - JavaScript / Node.js projects (package.json) — M-Basic pathway
    """
    
    @staticmethod
    def detect_project_type(project_path: Path) -> str:
        """
        Detect project type from project structure.
        
        Args:
            project_path: Root path of the project
            
        Returns:
            Project type: "maven", "dotnet", or "javascript"
            
        Raises:
            ValueError: If project type cannot be determined
        """
        project_path = Path(project_path)
        
        # Check for Maven
        if (project_path / "pom.xml").exists():
            return "maven"
        
        # Check for .NET
        csproj_files = list(project_path.rglob("*.csproj"))
        if csproj_files:
            return "dotnet"

        # Check for JavaScript / Node.js
        if (project_path / "package.json").exists():
            return "javascript"
        
        raise ValueError(
            f"Unknown project type in {project_path}. "
            f"Supported types: Maven (pom.xml), .NET (*.csproj), JavaScript (package.json)"
        )
    
    @staticmethod
    def build_graph(project_path: Path) -> Dict[str, ModuleNode]:
        """
        Build dependency graph based on project type.
        
        Args:
            project_path: Root path of the project
            
        Returns:
            Dictionary mapping module names to ModuleNode objects
            
        Raises:
            ValueError: If project type is unsupported or no modules found
        """
        project_path = Path(project_path)
        project_type = DependencyGraphBuilder.detect_project_type(project_path)
        
        logger.info(f"Building {project_type} dependency graph for {project_path}")
        
        if project_type == "maven":
            return MavenGraphBuilder.build_graph(project_path)
        elif project_type == "dotnet":
            return DotnetGraphBuilder.build_graph(project_path)
        elif project_type == "javascript":
            return JavaScriptGraphBuilder.build_graph(project_path)
        else:
            raise ValueError(f"Unsupported project type: {project_type}")


class MavenGraphBuilder:
    """Build dependency graph for Maven projects."""
    
    @staticmethod
    def parse_pom_dependencies(pom_path: Path) -> List[str]:
        """
        Parse Maven pom.xml to extract module dependencies.
        
        For multi-module projects, extracts child modules from parent POM.
        NOTE: Parent POM references are NOT included as dependencies because
        parent POMs are inheritance mechanisms, not actual module dependencies.
        
        Args:
            pom_path: Path to pom.xml file
            
        Returns:
            List of module names this module depends on (excluding parent POMs)
        """
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            
            # Handle Maven namespace
            ns = {'maven': 'http://maven.apache.org/POM/4.0.0'}
            
            dependencies = []
            
            # Check for parent POM (multi-module project)
            # Look for <modules><module>...</module></modules>
            # These are actual child modules that this parent manages
            modules_elem = root.find(".//maven:modules", ns)
            if modules_elem is not None:
                module_elems = modules_elem.findall(".//maven:module", ns)
                for module_elem in module_elems:
                    if module_elem.text:
                        module_name = module_elem.text.strip()
                        dependencies.append(module_name)
            
            # NOTE: We do NOT include parent POM references as dependencies because:
            # 1. Parent POMs are inheritance mechanisms, not module dependencies
            # 2. Parent POMs are typically external (e.g., spring-boot-starter-parent)
            # 3. They are not modules in the project graph
            # Child modules can be processed independently of their parent POM
            
            return dependencies
        except ET.ParseError as e:
            logger.warning(f"Failed to parse pom.xml {pom_path}: {e}")
            return []
        except Exception as e:
            logger.warning(f"Error parsing pom.xml {pom_path}: {e}")
            return []
    
    @staticmethod
    def build_graph(project_path: Path) -> Dict[str, ModuleNode]:
        """
        Build Maven dependency graph.
        
        Finds all pom.xml files and creates ModuleNode for each module.
        
        Args:
            project_path: Root path of the Maven project
            
        Returns:
            Dictionary mapping module names to ModuleNode objects
            
        Raises:
            ValueError: If no pom.xml files found
        """
        graph = {}
        project_path = Path(project_path)
        
        # Find all pom.xml files
        pom_files = list(project_path.rglob("pom.xml"))
        
        if not pom_files:
            raise ValueError(f"No pom.xml files found in {project_path}")
        
        logger.info(f"Found {len(pom_files)} pom.xml files")
        
        # Build nodes for each pom.xml
        for pom_file in pom_files:
            # Use directory name as module name
            module_name = pom_file.parent.name
            
            # Skip if already processed (handle duplicate names)
            if module_name in graph:
                logger.debug(f"Module {module_name} already exists, skipping {pom_file}")
                continue
            
            # Parse dependencies
            dependencies = MavenGraphBuilder.parse_pom_dependencies(pom_file)
            
            # Create module node
            graph[module_name] = ModuleNode(
                name=module_name,
                path=str(pom_file.parent),
                dependencies=dependencies
            )
            
            logger.debug(
                f"Created module node: {module_name} "
                f"(path={pom_file.parent}, deps={dependencies})"
            )
        
        logger.info(f"Built Maven graph with {len(graph)} modules")
        return graph


class DotnetGraphBuilder:
    """Build dependency graph for .NET projects."""
    
    @staticmethod
    def is_web_sdk_project(csproj_path: Path) -> bool:
        """
        Check if .csproj uses Microsoft.NET.Sdk.Web SDK.
        
        Args:
            csproj_path: Path to .csproj file
            
        Returns:
            True if project uses Web SDK, False otherwise
        """
        try:
            tree = ET.parse(csproj_path)
            root = tree.getroot()
            sdk = root.get("Sdk", "")
            return "Microsoft.NET.Sdk.Web" in sdk
        except Exception as e:
            logger.warning(f"Error checking SDK for {csproj_path}: {e}")
            return False
    
    @staticmethod
    def parse_csproj_dependencies(csproj_path: Path) -> List[str]:
        """
        Parse .csproj to extract ProjectReference dependencies.
        
        Args:
            csproj_path: Path to .csproj file
            
        Returns:
            List of project names this project depends on
        """
        try:
            tree = ET.parse(csproj_path)
            root = tree.getroot()
            
            dependencies = []
            
            # Find all ProjectReference elements
            # Format: <ProjectReference Include="../OtherProject/OtherProject.csproj" />
            for ref in root.findall(".//ProjectReference"):
                include = ref.get("Include", "")
                if include:
                    # Extract project name from path
                    # Path format: "../OtherProject/OtherProject.csproj" or "..\\OtherProject\\OtherProject.csproj"
                    project_path = Path(include)
                    project_name = project_path.stem  # Remove .csproj extension
                    dependencies.append(project_name)
            
            return dependencies
        except ET.ParseError as e:
            logger.warning(f"Failed to parse .csproj {csproj_path}: {e}")
            return []
        except Exception as e:
            logger.warning(f"Error parsing .csproj {csproj_path}: {e}")
            return []
    
    @staticmethod
    def build_graph(project_path: Path) -> Dict[str, ModuleNode]:
        """
        Build .NET dependency graph.
        
        Finds all .csproj files and creates ModuleNode for each project.
        
        Logic:
        1. If 1 .csproj found → Single module
        2. If >1 .csproj found → Check for Web SDK projects
           - If N Web SDK projects found → Use only those N projects
           - If 0 Web SDK projects found → Use all .csproj files
        
        Args:
            project_path: Root path of the .NET solution/project
            
        Returns:
            Dictionary mapping project names to ModuleNode objects
            
        Raises:
            ValueError: If no .csproj files found
        """
        graph = {}
        project_path = Path(project_path)
        
        # Find all .csproj files
        csproj_files = list(project_path.rglob("*.csproj"))
        
        if not csproj_files:
            raise ValueError(f"No .csproj files found in {project_path}")
        
        logger.info(f"Found {len(csproj_files)} .csproj files")
        
        # ✨ NEW: Determine which projects to process
        projects_to_process = csproj_files
        
        if len(csproj_files) == 1:
            # Single .csproj → Single module
            logger.info("Single .csproj detected - treating as single-module project")
        else:
            # Multiple .csproj → Check for Web SDK projects
            web_sdk_projects = [
                f for f in csproj_files 
                if DotnetGraphBuilder.is_web_sdk_project(f)
            ]
            
            logger.info(f"Found {len(web_sdk_projects)} Web SDK projects (Microsoft.NET.Sdk.Web)")
            
            if len(web_sdk_projects) > 0:
                # Use only Web SDK projects
                projects_to_process = web_sdk_projects
                logger.info(
                    f"Using {len(web_sdk_projects)} Web SDK project(s) as module(s) "
                    f"(ignoring {len(csproj_files) - len(web_sdk_projects)} library/test projects)"
                )
            else:
                # No Web SDK found, use all projects
                logger.info("No Web SDK projects found - using all .csproj files")
        
        # Build nodes for selected projects
        for csproj_file in projects_to_process:
            # Use project name (filename without extension) as module name
            module_name = csproj_file.stem
            
            # Skip if already processed
            if module_name in graph:
                logger.debug(f"Project {module_name} already exists, skipping {csproj_file}")
                continue
            
            # Parse dependencies
            dependencies = DotnetGraphBuilder.parse_csproj_dependencies(csproj_file)
            
            # Create module node
            graph[module_name] = ModuleNode(
                name=module_name,
                path=str(csproj_file.parent),
                dependencies=dependencies
            )
            
            logger.debug(
                f"Created project node: {module_name} "
                f"(path={csproj_file.parent}, deps={dependencies})"
            )
        
        logger.info(f"Built .NET graph with {len(graph)} projects")
        return graph


class JavaScriptGraphBuilder:
    """Build dependency graph for JavaScript / Node.js projects (M-Basic pathway)."""

    @staticmethod
    def build_graph(project_path: Path) -> Dict[str, ModuleNode]:
        """
        Build JavaScript dependency graph.

        M-Basic Node.js apps are treated as a single module rooted at package.json.

        Args:
            project_path: Root path of the Node.js project

        Returns:
            Dictionary with one ModuleNode keyed by directory name

        Raises:
            ValueError: If package.json is not found at the project root
        """
        project_path = Path(project_path)
        package_json = project_path / "package.json"

        if not package_json.exists():
            raise ValueError(f"No package.json found in {project_path}")

        module_name = project_path.name
        graph = {
            module_name: ModuleNode(
                name=module_name,
                path=str(project_path),
                dependencies=[],
            )
        }

        logger.info(f"Built JavaScript graph with 1 module: {module_name}")
        return graph
