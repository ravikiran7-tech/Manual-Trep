"""
Production-grade prompt builder for AI agent transformations.

Creates structured, enforceable prompts that guide the AI agent through
systematic code transformations with clear success criteria.
"""
import logging
from typing import Optional
from app.state.models import ModuleNode

logger = logging.getLogger(__name__)


class TransformationPromptBuilder:
    """
    Builds production-grade prompts for code transformations.
    
    Ensures the AI agent follows a systematic workflow and enforces
    proper behavior through clear, structured instructions.
    """
    
    @staticmethod
    def build_transformation_prompt(
        base_prompt: str,
        module: ModuleNode,
        project_type: str,
        is_retry: bool = False,
        last_error: Optional[str] = None,
        retry_count: int = 0
    ) -> str:
        """
        Build a comprehensive transformation prompt with enforced workflow.
        
        Args:
            base_prompt: Original user prompt/requirements
            module: ModuleNode being transformed
            project_type: Project type ("maven", "dotnet", or "javascript")
            is_retry: Whether this is a retry attempt
            last_error: Error message from previous attempt (if retry)
            retry_count: Number of retry attempts
            
        Returns:
            Complete transformation prompt with enforced workflow
        """
        
        # Build structured prompt sections
        sections = []
        
        # 1. Mission Statement
        sections.append(TransformationPromptBuilder._build_mission_statement(base_prompt, module))
        
        # 2. Mandatory Workflow
        sections.append(TransformationPromptBuilder._build_mandatory_workflow())
        
        # 3. File Write Requirements (CRITICAL)
        sections.append(TransformationPromptBuilder._build_write_requirements())
        
        # 4. Project-Specific Guidance
        if project_type == "maven":
            sections.append(TransformationPromptBuilder._build_maven_guidance())
        elif project_type == "dotnet":
            sections.append(TransformationPromptBuilder._build_dotnet_guidance())
        elif project_type == "javascript":
            sections.append(TransformationPromptBuilder._build_javascript_guidance())
        
        # 5. Completion Criteria
        sections.append(TransformationPromptBuilder._build_completion_criteria())
        
        # 6. Retry Guidance (if applicable)
        if is_retry and last_error:
            sections.append(TransformationPromptBuilder._build_retry_guidance(
                last_error, retry_count
            ))
        
        # Combine all sections
        full_prompt = "\n\n".join(sections)
        
        logger.debug(f"Built transformation prompt for module {module.name}: {len(full_prompt)} chars")
        return full_prompt
    
    @staticmethod
    def _build_mission_statement(base_prompt: str, module: ModuleNode) -> str:
        """Build mission statement section."""
        deps_str = ', '.join(module.dependencies) if module.dependencies else 'None'
        
        # Ensure base_prompt is properly formatted and prominent
        formatted_prompt = base_prompt.strip()
        if not formatted_prompt:
            formatted_prompt = "Transform the codebase according to the requirements specified in the original request."
        
        # Extract architecture guidance from prompt
        architecture_note = ""
        prompt_lower = formatted_prompt.lower()
        
        if "clean architecture" in prompt_lower:
            architecture_note = "\n\n**ARCHITECTURE REQUIREMENT**: This requires CLEAN ARCHITECTURE with layered structure (Domain/Infrastructure/Application/Web). Create complete new architecture, not just modifications."
        
        return f"""# TRANSFORMATION MISSION

## PRIMARY OBJECTIVE (FROM REQUEST)
{formatted_prompt}{architecture_note}

## Module Context
- **Module Name**: {module.name}
- **Module Path**: {module.path}
- **Dependencies**: {deps_str}

## Your Task
You are a code transformation agent. Your job is to MODIFY code files to meet the PRIMARY OBJECTIVE above.
This is NOT an analysis task - you MUST make actual code changes by writing files.

## Critical Reminder
The PRIMARY OBJECTIVE above contains the specific transformation requirements from the user's request.
You MUST ensure all changes address these requirements, including any architecture patterns specified.
Refer back to the PRIMARY OBJECTIVE throughout your work."""
    
    @staticmethod
    def _build_mandatory_workflow() -> str:
        """Build mandatory workflow section."""
        return """# MANDATORY WORKFLOW (YOU MUST FOLLOW THIS EXACTLY)

## Phase 1: Discovery (Iterations 1-3)
1. **Review the PRIMARY OBJECTIVE** from the mission statement - understand what needs to be transformed
2. **Scan the module directory** using bash: `find <module_path> -type f -name "*.java" | head -50`
3. **Read key files** to understand the codebase structure:
   - Configuration files (pom.xml, application.properties, etc.)
   - Main source files that likely need changes based on the PRIMARY OBJECTIVE
   - Files mentioned in the transformation requirements
4. **Identify transformation targets**: List all files that need modification to meet the PRIMARY OBJECTIVE

## Phase 2: Transformation (Iterations 4+)
5. **For EACH file that needs changes** (based on PRIMARY OBJECTIVE):
   - Read the current file content
   - Analyze what needs to be changed to meet the PRIMARY OBJECTIVE
   - **REQUEST code_editor write operation** with the modified content
   - Ensure changes align with the PRIMARY OBJECTIVE requirements
   - Do NOT skip any files that need changes
6. **Process files systematically**:
   - Start with configuration files (pom.xml, .csproj) if they need changes per PRIMARY OBJECTIVE
   - Then process source code files that need transformation
   - Complete ALL required changes to fulfill the PRIMARY OBJECTIVE

## Phase 3: Completion (After all writes)
6. **Verify all transformations are complete**
7. **Provide a brief summary** of changes made
8. **Send end_turn** to complete the transformation

## CRITICAL RULES
- You MUST complete Phase 2 (write operations) before Phase 3 (completion)
- You CANNOT skip Phase 2 - reading files is NOT sufficient
- You MUST write files using code_editor with operation="write"
- You CANNOT send end_turn until you have written files"""
    
    @staticmethod
    def _build_write_requirements() -> str:
        """Build file write requirements section."""
        return """# FILE MODIFICATION REQUIREMENTS (MANDATORY - NO EXCEPTIONS)

## What You MUST Do
You MUST request code_editor operations to modify files. This is NOT optional.

## Operation Types

### 1. **PATCH Operation** (PREFERRED for small changes) ✅
Use patch operation when making small, targeted changes to existing files.
This is more efficient and reduces token usage.

**Format for unified_diff:**
```json
{{
  "name": "code_editor",
  "input": {{
    "path": "/full/path/to/file.java",
    "operation": "patch",
    "patch_format": "unified_diff",
    "patch_data": "@@ -10,3 +10,4 @@\\n old line\\n-old line to remove\\n+new line to add\\n context line"
  }}
}}
```

**Format for line_edits:**
```json
{{
  "name": "code_editor",
  "input": {{
    "path": "/full/path/to/file.java",
    "operation": "patch",
    "patch_format": "line_edits",
    "patch_data": [
      {{"type": "replace", "line": 10, "old_text": "old code", "new_text": "new code"}},
      {{"type": "insert", "line": 15, "text": "new line to insert"}},
      {{"type": "delete", "line": 20}}
    ]
  }}
}}
```

### 2. **WRITE Operation** (Use for large changes or new files)
Use write operation when:
- Creating a new file
- Making extensive changes (>50% of file)
- The file is small (<100 lines)

**Format:**
```json
{{
  "name": "code_editor",
  "input": {{
    "path": "/full/path/to/file.java",
    "operation": "write",
    "content": "// Complete file content here..."
  }}
}}
```

## Decision Guidelines
- ✅ **Use PATCH** if: Changing <10 lines, modifying existing code, updating imports
- ✅ **Use WRITE** if: Creating new file, rewriting >50% of file, file is small

## What Counts as Progress
✅ **PROGRESS**: Requesting code_editor with operation="write" OR operation="patch"
❌ **NO PROGRESS**: Reading files (operation="read")
❌ **NO PROGRESS**: Running bash commands
❌ **NO PROGRESS**: Sending end_turn without modifying files

## Enforcement Rules
1. **Minimum Requirement**: You MUST request at least ONE write or patch operation
2. **Completeness Requirement**: You MUST modify ALL files that need changes
3. **Completion Block**: You CANNOT send end_turn until writes/patches are complete
4. **Failure Condition**: If you send end_turn without modifying files, the system will force you to continue

## Success Criteria
Your transformation is successful ONLY when:
- ✅ You have identified all files that need changes
- ✅ You have requested write/patch operations for ALL those files
- ✅ The modified files address the transformation requirements
- ✅ You have sent end_turn AFTER completing all operations

## Common Mistakes to Avoid
❌ Reading files and then immediately sending end_turn
❌ Analyzing code but not writing changes
❌ Modifying some files but skipping others that need changes
❌ Sending end_turn before completing all write/patch operations
❌ Using write operation for small changes (use patch instead)"""
    
    @staticmethod
    def _build_maven_guidance() -> str:
        """Build Maven-specific guidance."""
        return """# MAVEN POM.XML GUIDANCE (CRITICAL)

## When Modifying pom.xml

### Dependency Structure Rules
Every dependency MUST have ALL required fields:
```xml
<dependency>
    <groupId>org.example</groupId>      <!-- REQUIRED -->
    <artifactId>example-artifact</artifactId>  <!-- REQUIRED -->
    <version>1.0.0</version>            <!-- REQUIRED (unless parent manages it) -->
</dependency>
```

### Critical Rules
1. **NEVER remove required tags**: groupId, artifactId, version
2. **ALWAYS include version** unless parent POM explicitly manages it
3. **Preserve existing structure**: Only modify what needs changing
4. **Verify XML well-formedness**: Matching tags, proper nesting
5. **Check parent POM**: If parent manages versions, verify they're defined

### Common Errors to Avoid
- Missing <version> tag → Causes: "'dependencies.dependency.version' is missing"
- Missing <groupId> or <artifactId> → Causes: "Malformed POM"
- Incorrect XML structure → Causes: "The build could not read 1 project"

### Validation Checklist Before Writing
- [ ] All opening/closing tags match
- [ ] All dependencies have groupId, artifactId, and version (or parent manages it)
- [ ] XML is well-formed (proper nesting, no unclosed tags)
- [ ] Existing dependencies are preserved (only modified, not removed)

## Java File Transformations
- Update deprecated API calls
- Fix Java version compatibility issues
- Update import statements if needed
- Ensure all changes are syntactically correct"""
    
    @staticmethod
    def _build_dotnet_guidance() -> str:
        """Build .NET-specific guidance."""
        return """# .NET PROJECT GUIDANCE (CRITICAL)

## When Modifying .csproj Files

### Package Reference Structure
Every PackageReference MUST have required attributes:
```xml
<PackageReference Include="Package.Name" Version="1.0.0" />
```

### Critical Rules
1. **Preserve existing structure**: Only modify what needs changing
2. **Verify XML well-formedness**: Matching tags, proper nesting
3. **Check framework version**: Ensure compatibility with target framework
4. **Update package versions**: Use compatible versions

### Common Errors to Avoid
- Missing Version attribute → Causes: "Package restore failed"
- Incorrect XML structure → Causes: "The project file could not be loaded"
- Framework mismatch → Causes: "Package not compatible with target framework"

## C# File Transformations
- Update deprecated API calls
- Fix .NET version compatibility issues
- Update using statements if needed
- Ensure all changes are syntactically correct"""
    
    @staticmethod
    def _build_javascript_guidance() -> str:
        """Build JavaScript / Node.js guidance for M-Basic pathway."""
        return """# JAVASCRIPT / NODE.JS PROJECT GUIDANCE (M-BASIC)

## When Modifying package.json

### Critical Rules
1. **Preserve valid JSON**: No trailing commas, matching braces/brackets
2. **Keep required fields**: `name` and `version` should remain present
3. **Update dependencies carefully**: Use compatible semver ranges
4. **Scripts**: Preserve existing `scripts` entries unless the PRIMARY OBJECTIVE requires changes

### Common Errors to Avoid
- Invalid JSON syntax → Causes: `npm ERR!` parse errors
- Missing dependency → Causes: `Cannot find module`
- Incompatible Node API usage → Causes: runtime or build failures

## JavaScript / TypeScript File Transformations
- Scan for `*.js`, `*.jsx`, `*.mjs`, `*.cjs`, `*.ts`, `*.tsx` files
- Update deprecated Node.js or framework API calls
- Fix `require`/`import` paths when modules move
- Externalize hardcoded config to environment variables when required by blockers
- Ensure all changes are syntactically correct

## Build Commands (DO NOT RUN during transformation)
- `npm install`, `npm run build`, `npm test`, `yarn build`
- Builds are handled separately after transformation completes"""
    
    @staticmethod
    def _build_completion_criteria() -> str:
        """Build completion criteria section."""
        return """# COMPLETION CRITERIA (YOU MUST MEET ALL)

## Before You Can Send end_turn

You MUST have completed ALL of the following:

### 1. File Discovery ✅
- [ ] Scanned the module directory for all relevant files
- [ ] Identified which files need transformation
- [ ] Read and analyzed those files

### 2. Architecture Compliance ✅
- [ ] If PRIMARY OBJECTIVE mentions "clean architecture": Created proper layered structure (Domain/Infrastructure/Application/Web)
- [ ] If PRIMARY OBJECTIVE mentions specific architecture patterns: Implemented those patterns completely
- [ ] Created NEW architecture structure as required (not just modified existing files)
- [ ] Verified folder structure matches architecture requirements from PRIMARY OBJECTIVE

### 3. File Modifications ✅
- [ ] Requested code_editor write operations for ALL files that need changes
- [ ] Provided complete, correct file content for each write
- [ ] Ensured all transformations address the requirements
- [ ] Created all new files required by target architecture

### 4. Verification ✅
- [ ] Reviewed that all required changes are complete
- [ ] Confirmed no files were skipped that need changes
- [ ] Verified transformations are correct
- [ ] Validated architecture structure matches PRIMARY OBJECTIVE requirements

### 5. Completion ✅
- [ ] Provided a brief summary of changes made
- [ ] Sent end_turn signal

## When to Send end_turn

✅ **SEND end_turn WHEN**:
- You have written ALL files that need changes
- Architecture pattern from PRIMARY OBJECTIVE is fully implemented
- All transformations are complete
- You have verified completeness

❌ **DO NOT SEND end_turn WHEN**:
- You have only read files (no writes yet)
- You have written some files but not all
- Architecture requirements from PRIMARY OBJECTIVE are incomplete
- You are still analyzing or planning changes

## Build Commands (DO NOT RUN)
🚫 **FORBIDDEN COMMANDS**:
- `mvn clean compile`, `mvn build`, `mvn install`
- `dotnet build`, `dotnet restore`
- Any compilation or build verification commands

**Reason**: This is the TRANSFORMATION phase. Builds happen separately after transformation completes."""
    
    @staticmethod
    def _build_retry_guidance(error_message: str, retry_count: int) -> str:
        """Build retry guidance section."""
        # Format error message for readability
        error_lines = error_message.split('\n')[:20]  # Limit to first 20 lines
        formatted_error = '\n'.join(f"  {line}" for line in error_lines if line.strip())
        
        return f"""# RETRY ATTEMPT {retry_count + 1}

## Previous Attempt Failed

The previous transformation attempt did not complete successfully. You must fix the issues and try again.

## Error Information
```
{formatted_error}
```

## What You Must Do Differently

1. **Analyze the error**: Understand what went wrong
2. **Identify root causes**: 
   - Missing imports or packages?
   - Syntax errors?
   - Type mismatches?
   - Incorrect API usage?
3. **Fix systematically**: Address each issue methodically
4. **Verify fixes**: Ensure changes resolve the problems
5. **Write corrected files**: Request write operations with fixes

## Critical Reminders
- Do NOT repeat the same approach that failed
- Make targeted fixes based on the error messages
- Ensure all referenced classes/methods exist
- Verify imports are correct and available
- Check that types match expected signatures

## Success This Time
- Fix ALL issues identified in the error
- Write corrected files using code_editor
- Complete the transformation successfully"""
    
    @staticmethod
    def format_module_path(module_path: str) -> str:
        """Format module path for use in prompts."""
        return module_path
