"""
Graph-based orchestrator replacing max_iterations loop.

Deterministic, bounded execution with compiler-based validation.
Works with both Bedrock and Portkey providers.
"""
import logging
import time
from pathlib import Path
from typing import List, Dict, Optional, Callable
from app.state.models import ModuleNode, ModuleStatus, GraphState
from app.graph.builders import DependencyGraphBuilder
from app.graph.resolver import GraphResolver
from app.execution.artifact_manager import ArtifactManager
from app.execution.validator import CompilerValidator
from app.services.tool_executor import ToolExecutor
from app.core.config import get_settings
from app.orchestrator.prompt_builder import TransformationPromptBuilder

logger = logging.getLogger(__name__)
settings = get_settings()


class GraphOrchestrator:
    """
    Orchestrates module transformations using dependency graph.
    
    Replaces max_iterations with deterministic graph execution.
    Works with both Bedrock and Portkey providers through provider_factory.
    
    Key Features:
    - Topological execution order (respects dependencies)
    - Compiler-based validation (optional, disabled by default during transformation)
    - Artifact hashing for progress detection
    - Bounded retries per module
    - No infinite loops (graph size is the bound)
    - No builds during transformation (skip_validation=True by default)
    """
    
    def __init__(
        self,
        project_path: str,
        provider_factory,
        max_retries: int = 3,
        validation_timeout: int = 300,
        skip_validation: bool = False
    ):
        """
        Initialize graph orchestrator.
        
        Args:
            project_path: Root path of the project
            provider_factory: ProviderFactory instance for getting AI provider
            max_retries: Maximum retries per module (default: 3)
            validation_timeout: Timeout for compiler validation in seconds (default: 300)
            skip_validation: Skip compiler validation/builds (default: True for transformation phase)
        """
        self.project_path = Path(project_path)
        self.provider_factory = provider_factory
        self.max_retries = max_retries
        self.validation_timeout = validation_timeout
        self.skip_validation = skip_validation
        self.tool_executor = ToolExecutor(
            project_path=str(project_path),
            working_directory=str(project_path)
        )
        
        logger.info(
            f"GraphOrchestrator initialized: project={project_path}, "
            f"max_retries={max_retries}, validation_timeout={validation_timeout}s, "
            f"skip_validation={skip_validation}"
        )
    
    async def orchestrate(
        self, prompt: str, on_event: Optional[Callable[[Dict], None]] = None
    ) -> GraphState:
        """
        Orchestrate transformation across all modules.
        
        This replaces the max_iterations loop with deterministic graph execution.
        Execution is bounded by graph size, not arbitrary iteration limits.
        
        Args:
            prompt: Transformation prompt for AI model
            on_event: Optional callback called with each event as it is produced (for live streaming).
            
        Returns:
            GraphState with final execution status
            
        Raises:
            ValueError: If graph has circular dependencies or invalid structure
        """
        start_time = time.time()
        
        # Build dependency graph
        logger.info(f"Building dependency graph for {self.project_path}")
        try:
            graph = DependencyGraphBuilder.build_graph(self.project_path)
        except Exception as e:
            logger.error(f"Failed to build dependency graph: {e}")
            raise ValueError(f"Failed to build dependency graph: {e}")
        
        # Validate graph (check for cycles)
        if not GraphResolver.validate_graph(graph):
            raise ValueError("Circular dependencies detected in project graph")
        
        # Detect project type
        try:
            project_type = DependencyGraphBuilder.detect_project_type(self.project_path)
        except Exception as e:
            logger.error(f"Failed to detect project type: {e}")
            raise ValueError(f"Failed to detect project type: {e}")
        
        # Initialize state
        state = GraphState(
            graph=graph,
            project_path=str(self.project_path),
            project_type=project_type,
            total_modules=len(graph),
            max_retries=self.max_retries
        )
        
        logger.info(
            f"Starting orchestration: {state.total_modules} modules, "
            f"project type: {project_type}"
        )
        
        # Initialize artifact hashes for all modules
        for module in graph.values():
            ArtifactManager.hash_directory(module.path)
            if module.artifacts_hash:
                logger.debug(f"Initial hash for {module.name}: {module.artifacts_hash[:16]}...")
        
        # Main execution loop - NO MAX_ITERATIONS!
        # Loop until all modules are processed (bounded by graph size)
        # No safety limit - let modules retry as needed until they succeed or fail
        
        while not state.is_complete():
            state.current_iteration += 1
            
            logger.info(
                f"Orchestration iteration {state.current_iteration} "
                f"(progress: {state.get_progress()})"
            )
            
            # Get ready modules (topological order)
            ready_modules = GraphResolver.get_ready_modules(state.graph)
            
            if not ready_modules:
                # Check if we're stuck
                pending = [
                    m for m in state.graph.values()
                    if m.status == ModuleStatus.PENDING
                ]
                
                if pending:
                    logger.error(
                        f"No ready modules but {len(pending)} still pending: "
                        f"{[m.name for m in pending]}. "
                        f"Possible dependency issue or missing dependencies."
                    )
                    # Mark remaining as failed
                    for module in pending:
                        module.status = ModuleStatus.FAILED
                        module.last_error = "Dependency resolution failed - no ready modules"
                    break
                else:
                    # All modules processed
                    logger.info("All modules processed")
                    break
            
            # Process ready modules sequentially
            # (Can be parallelized in future if needed)
            for module in ready_modules:
                await self._transform_module(module, state, prompt, on_event=on_event)
        
        # Final status
        elapsed_time = time.time() - start_time
        progress = state.get_progress()
        
        logger.info(
            f"Orchestration complete in {elapsed_time:.2f}s: "
            f"{progress['locked']} succeeded, {progress['failed']} failed, "
            f"{progress['skipped']} skipped, {state.current_iteration} iterations"
        )
        
        return state
    
    async def _transform_module(
        self,
        module: ModuleNode,
        state: GraphState,
        prompt: str,
        on_event: Optional[Callable[[Dict], None]] = None
    ):
        """
        Transform a single module.
        
        Steps:
        1. Check for progress (artifact hashing)
        2. Apply transformation using AI
        3. Validate using compiler
        4. Lock if successful, retry if failed
        
        Args:
            module: ModuleNode to transform
            state: GraphState tracking overall progress
            prompt: Transformation prompt
            on_event: Optional callback for live event streaming.
        """
        logger.info(f"Transforming module: {module.name} (attempt {module.retries + 1})")
        module.status = ModuleStatus.IN_PROGRESS
        
        try:
            # Check for progress before transformation
            # Skip if no progress detected (prevents infinite loops)
            if module.retries > 0:
                if not ArtifactManager.has_progress(module):
                    logger.warning(
                        f"Module {module.name} shows no progress after retry - skipping"
                    )
                    module.status = ModuleStatus.SKIPPED
                    state.completed_modules += 1
                    return
            
            # Apply transformation using AI
            transformation_success = await self._apply_transformation(
                module, prompt, on_event=on_event
            )
            
            if not transformation_success:
                raise Exception("Transformation returned failure")
            
            # Validate using compiler (NOT LLM!) - unless validation is skipped
            # During transformation phase, builds are skipped to allow systematic completion
            # without waiting for builds. Builds can be enabled later if needed.
            if self.skip_validation:
                logger.info(
                    f"Build/validation skipped for module {module.name} "
                    f"(skip_validation=True - transformation phase)"
                )
                # Lock module without validation (no build executed)
                # This allows transformation to complete systematically without building
                module.status = ModuleStatus.LOCKED
                ArtifactManager.update_hash(module)
                state.completed_modules += 1
                logger.info(
                    f"Module {module.name} locked without build/validation "
                    f"(transformation complete, retries: {module.retries})"
                )
            else:
                is_valid, error_msg = CompilerValidator.validate(
                    module,
                    state.project_type,
                    timeout=self.validation_timeout
                )
                
                if is_valid:
                    # Lock module (mark as successfully completed)
                    module.status = ModuleStatus.LOCKED
                    ArtifactManager.update_hash(module)
                    state.completed_modules += 1
                    logger.info(
                        f"Module {module.name} locked successfully "
                        f"(retries: {module.retries})"
                    )
                else:
                    # Validation failed - rollback and retry
                    logger.warning(
                        f"Module {module.name} validation failed: {error_msg[:200]}"
                    )
                    await self._rollback_module(module)
                    module.retries += 1
                    module.last_error = error_msg[:500]  # Limit error message length
                    
                    if module.retries >= state.max_retries:
                        module.status = ModuleStatus.FAILED
                        state.failed_modules += 1
                        logger.error(
                            f"Module {module.name} failed after {module.retries} retries"
                        )
                    else:
                        module.status = ModuleStatus.PENDING
                        logger.info(
                            f"Module {module.name} will retry "
                            f"(attempt {module.retries + 1}/{state.max_retries})"
                        )
        
        except Exception as e:
            logger.error(
                f"Error transforming module {module.name}: {e}",
                exc_info=True
            )
            module.retries += 1
            module.last_error = str(e)[:500]
            
            if module.retries >= state.max_retries:
                module.status = ModuleStatus.FAILED
                state.failed_modules += 1
                logger.error(
                    f"Module {module.name} failed after {module.retries} retries: {e}"
                )
            else:
                module.status = ModuleStatus.PENDING
                logger.info(
                    f"Module {module.name} will retry after error "
                    f"(attempt {module.retries + 1}/{state.max_retries})"
                )
    
    async def _apply_transformation(
        self,
        module: ModuleNode,
        prompt: str,
        on_event: Optional[Callable[[Dict], None]] = None
    ) -> bool:
        """
        Apply transformation to module using AI.
        
        Works with both Bedrock and Portkey providers through provider_factory.
        Uses existing agentic method but scoped to this module.
        
        Args:
            module: ModuleNode to transform
            prompt: Base transformation prompt
            on_event: Optional callback for live event streaming.
            
        Returns:
            True if transformation was applied, False otherwise
        """
        try:
            # Get provider (could be Bedrock or Portkey)
            provider = await self.provider_factory.get_provider()
            
            # Detect project type from module path
            import os
            project_type = "unknown"
            if os.path.exists(os.path.join(module.path, "pom.xml")):
                project_type = "maven"
            elif any(f.endswith(".csproj") for f in os.listdir(module.path) if os.path.isfile(os.path.join(module.path, f))):
                project_type = "dotnet"
            elif os.path.exists(os.path.join(module.path, "package.json")):
                project_type = "javascript"
            
            # Build production-grade transformation prompt
            is_retry = module.retries > 0
            last_error = module.last_error if is_retry else None
            
            module_prompt = TransformationPromptBuilder.build_transformation_prompt(
                base_prompt=prompt,
                module=module,
                project_type=project_type,
                is_retry=is_retry and not self.skip_validation,
                last_error=last_error if not self.skip_validation else None,
                retry_count=module.retries
            )
            
            # Add retry guidance for skipped validation case
            if self.skip_validation and module.retries > 0:
                # If validation is skipped, provide general retry guidance without compilation errors
                module_prompt += f"""

# RETRY ATTEMPT {module.retries + 1} of {self.max_retries}

## Previous Attempt Status
This is a retry attempt. Build validation is disabled during transformation phase.

## What You Must Do
1. Review your previous changes and ensure completeness
2. Verify all required files have been transformed
3. Check that file modifications are correct and complete
4. Ensure no syntax errors or obvious issues were introduced
5. Verify all dependencies and imports are properly updated

## Focus
Complete all required code changes systematically. Focus on transformation completeness.
"""
            
            # Use agentic method for multi-turn transformations within each module.
            # The graph orchestrator handles module-level retries (based on compiler validation),
            # while the agentic loop handles transformation complexity within each module.
            # Unlimited iterations mode allows systematic completion of large transformations.
            logger.info(f"Invoking AI provider for module {module.name} (unlimited iterations mode)")
            
            # Use invoke_with_tools_agentic for multi-turn transformations.
            # The graph orchestrator handles module-level retries, while the agentic loop
            # continues until end_turn or safety limits (progress-based stopping).
            # This enables systematic transformation of large codebases without iteration limits.
            events = await provider.invoke_with_tools_agentic(
                prompt=module_prompt,
                project_path=module.path,
                enable_tools=True,
                on_event=on_event
            )
            
            # Check if transformation produced events
            if not events:
                logger.warning(f"No events returned for module {module.name}")
                return False
            
            # Store all events for stream file output
            # ACCUMULATE events across retries (don't overwrite)
            # This ensures all attempts are captured in the stream file
            if not module.events:
                module.events = []
            module.events.extend(events)
            
            # Extract files changed from events
            write_operations_found = False
            patch_operations_found = False
            write_count = 0
            patch_count = 0
            
            for event in events:
                if event.get("type") == "tool_use":
                    tool = event.get("tool", {})
                    tool_input = tool.get("input", {})
                    tool_name = tool.get("name", "")
                    operation = tool_input.get("operation", "")
                    
                    # Check for code_editor operations
                    if tool_name == "code_editor":
                        if operation == "write":
                            write_operations_found = True
                            write_count += 1
                            file_path = tool_input.get("path", "")
                            if file_path and file_path not in module.files_changed:
                                module.files_changed.append(file_path)
                        elif operation == "patch":
                            patch_operations_found = True
                            patch_count += 1
                            file_path = tool_input.get("path", "")
                            if file_path and file_path not in module.files_changed:
                                module.files_changed.append(file_path)
            
            # Warn if no write or patch operations found (critical issue)
            if not write_operations_found and not patch_operations_found:
                logger.warning(
                    f"⚠️ CRITICAL: Module {module.name} completed with NO write or patch operations! "
                    f"The model explored but did not modify any files. "
                    f"This will cause validation to fail."
                )
            
            logger.info(
                f"Transformation applied to module {module.name}: "
                f"{len(module.files_changed)} files changed, {len(events)} events captured, "
                f"writes={write_count}, patches={patch_count}"
            )
            
            return True
            
        except Exception as e:
            logger.error(
                f"Error applying transformation to module {module.name}: {e}",
                exc_info=True
            )
            return False
    
    def _format_compilation_errors(self, error_msg: str, retry_count: int) -> str:
        """
        Format compilation error message for better readability and actionability.
        
        Extracts key information from Maven/.NET compiler output:
        - Error types and messages
        - File names and line numbers
        - Specific issues (missing imports, type mismatches, etc.)
        
        Args:
            error_msg: Raw compilation error message
            retry_count: Current retry attempt number
            
        Returns:
            Formatted error message with actionable information
        """
        if not error_msg:
            return "No detailed error information available."
        
        # Clean up ANSI color codes from Maven output
        import re
        cleaned_error = re.sub(r'\x1b\[[0-9;]*m', '', error_msg)
        
        # Extract key error patterns
        lines = cleaned_error.split('\n')
        formatted_lines = []
        in_error_section = False
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Look for error indicators
            if any(keyword in line.lower() for keyword in ['error', 'failed', 'cannot', 'unable', 'missing']):
                in_error_section = True
                formatted_lines.append(f"  ❌ {line}")
            elif in_error_section and (line.startswith('[') or ':' in line):
                # Likely a file path or detailed error
                formatted_lines.append(f"     {line}")
            elif any(keyword in line.lower() for keyword in ['symbol', 'method', 'class', 'package', 'import']):
                # Important error details
                formatted_lines.append(f"  → {line}")
        
        if formatted_lines:
            return '\n'.join(formatted_lines[:50])  # Limit to first 50 lines
        else:
            # Fallback: return cleaned error message
            return cleaned_error[:2000]  # Limit length
    
    async def _rollback_module(self, module: ModuleNode):
        """
        Rollback module to previous state.
        
        Currently a placeholder - would use diff_manager for rollback.
        In production, this would restore files from checkpoints.
        
        Args:
            module: ModuleNode to rollback
        """
        logger.info(f"Rolling back module {module.name}")
        
        # TODO: Implement actual rollback using checkpoints/diffs
        # For now, just log the rollback
        # In production, would restore files from before transformation
        
        if module.files_changed:
            logger.warning(
                f"Module {module.name} had {len(module.files_changed)} files changed. "
                f"Rollback not yet implemented - files may be in inconsistent state."
            )
